instanceid: 652dd1d9f2e35
collectorid: 7e19cc9f8c2b15f32c6b92d7
pluginid: inspector_bws
name: BWS配置基线巡检
content: |-
  #!/usr/local/easyops/python/bin/python
  # coding:utf-8
  import json
  import subprocess
  import re

  install_path = EASYOPS_installPath
  bws_port = bws_port

  if not bws_port:
      bws_port = "80"
  else:
      bws_port = str(bws_port)

  bws_bin = (install_path + "/bin/bws") if install_path else "bws"


  class Inspector:
      def __init__(self):
          self.result = []

      def run_cmd(self, cmd):
          cmd = 'export LD_LIBRARY_PATH==$LD_LIBRARY_PATH:{}/luajit/lib/; '.format(install_path) + cmd
          try:
              p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
              out, err = p.communicate()
              # print cmd,out
              return out.strip(), err.strip(), p.returncode
          except Exception:
              return "", "", -1

      def collect_basic(self):
          out, err, code = self.run_cmd(bws_bin + " -V 2>&1")
          ver_out = (err + "\n" + out) if err else out
          version = ""
          ver_match = re.search(r"([\d.]+)", ver_out)
          if ver_match:
              version = ver_match.group(1)
          conf_path = ""
          conf_match = re.search(r"conf-path=(\S+)", ver_out)
          if conf_match:
              conf_path = conf_match.group(1)
          modules = ver_out.replace("\n", " ").strip()
          if len(modules) > 500:
              modules = modules[-500:]
          self.result.append({
              "id": "basic",
              "dims": [],
              "vals": [
                  {"id": "version", "value": version},
                  {"id": "conf_path", "value": conf_path},
                  {"id": "modules", "value": modules}
              ]
          })

      def collect_service(self):
          out, _, _ = self.run_cmd('ps -ef | grep -E "BWS.*master" | wc -l')
          process_count = 0
          try:
              process_count = int(out.strip())
          except ValueError:
              pass
          process_status = "RUNNING" if process_count > 0 else "STOPPED"

          out, _, _ = self.run_cmd('ps -ef | grep -E "BWS.*worker" | wc -l')
          worker_count = 0
          try:
              worker_count = int(out.strip())
          except ValueError:
              pass

          _, err, code = self.run_cmd(bws_bin + " -t 2>&1")
          conf_check = "OK" if code == 0 else "FAIL"
          conf_msg = err if code != 0 else ""

          out_ver, err_ver, _ = self.run_cmd(bws_bin + " -V 2>&1")
          ver_all = out_ver + "\n" + err_ver
          # print ver_all
          stub_available = "YES" if "stub_status" in ver_all else "NO"
          vhost_available = "YES" if "vhost_traffic_status" in ver_all else "NO"

          self.result.append({
              "id": "service",
              "dims": [],
              "vals": [
                  {"id": "process_status", "value": process_status},
                  {"id": "worker_processes", "value": worker_count},
                  {"id": "conf_check", "value": conf_check},
                  {"id": "conf_check_msg", "value": conf_msg},
                  {"id": "stub_status_available", "value": stub_available},
                  {"id": "vhost_status_available", "value": vhost_available}
              ]
          })

      def collect_connections(self):
          out, _, _ = self.run_cmd("curl -s --connect-timeout 5 http://127.0.0.1:" + bws_port + "/bws_status")
          active = 0
          reading = 0
          writing = 0
          waiting = 0
          dropped = 0

          if out and "Active connections" in out:
              m = re.search(r"Active connections:\s*(\d+)", out)
              if m:
                  active = int(m.group(1))
              m = re.search(r"server accepts handled requests\s*\n\s*(\d+)\s+(\d+)\s+(\d+)", out)
              if m:
                  accepted = int(m.group(1))
                  handled = int(m.group(2))
                  dropped = accepted - handled
              m = re.search(r"Reading:\s*(\d+)\s+Writing:\s*(\d+)\s+Waiting:\s*(\d+)", out)
              if m:
                  reading = int(m.group(1))
                  writing = int(m.group(2))
                  waiting = int(m.group(3))
          else:
              out2, _, _ = self.run_cmd("curl -s --connect-timeout 5 http://127.0.0.1:" + bws_port + "/vhost_status")
              if out2:
                  try:
                      data = json.loads(out2)
                      conn = data.get("connections", {})
                      active = conn.get("active", 0)
                      reading = conn.get("reading", 0)
                      writing = conn.get("writing", 0)
                      waiting = conn.get("waiting", 0)
                      accepted = conn.get("accepted", 0)
                      handled = conn.get("handled", 0)
                      dropped = accepted - handled
                  except Exception:
                      pass

          self.result.append({
              "id": "connections",
              "dims": [],
              "vals": [
                  {"id": "active", "value": active},
                  {"id": "reading", "value": reading},
                  {"id": "writing", "value": writing},
                  {"id": "waiting", "value": waiting},
                  {"id": "dropped", "value": dropped}
              ]
          })

      def collect_server_zones(self):
          out, _, _ = self.run_cmd("curl -s --connect-timeout 5 http://127.0.0.1:" + bws_port + "/vhost_status")
          if not out:
              return
          try:
              data = json.loads(out)
          except Exception:
              return
          server_zones = data.get("serverZones", {})
          for zone_name, zone_data in server_zones.items():
              responses = zone_data.get("responses", {})
              self.result.append({
                  "id": "server_zones",
                  "dims": [{"id": "server_zone", "value": zone_name}],
                  "vals": [
                      {"id": "requests", "value": zone_data.get("requestCounter", 0)},
                      {"id": "response_2xx", "value": responses.get("2xx", 0)},
                      {"id": "response_4xx", "value": responses.get("4xx", 0)},
                      {"id": "response_5xx", "value": responses.get("5xx", 0)},
                      {"id": "request_msec", "value": zone_data.get("requestMsec", 0)}
                  ]
              })

      def collect_upstream(self):
          out, _, _ = self.run_cmd("curl -s --connect-timeout 5 http://127.0.0.1:" + bws_port + "/vhost_status")
          if not out:
              return
          try:
              data = json.loads(out)
          except Exception:
              return
          upstream_zones = data.get("upstreamZones", {})
          for group_name, servers in upstream_zones.items():
              for server_data in servers:
                  responses = server_data.get("responses", {})
                  self.result.append({
                      "id": "upstream_health",
                      "dims": [
                          {"id": "upstream_group", "value": group_name},
                          {"id": "upstream_server", "value": server_data.get("server", "unknown")}
                      ],
                      "vals": [
                          {"id": "requests", "value": server_data.get("requestCounter", 0)},
                          {"id": "response_5xx", "value": responses.get("5xx", 0)},
                          {"id": "request_msec", "value": server_data.get("requestMsec", 0)},
                          {"id": "response_msec", "value": server_data.get("responseMsec", 0)}
                      ]
                  })

      def print_result(self):
          print "-------start-------"
          print json.dumps(self.result)
          print "-------end-------"


  if __name__ == "__main__":
      inspector = Inspector()
      inspector.collect_basic()
      inspector.collect_service()
      inspector.collect_connections()
      inspector.collect_server_zones()
      inspector.collect_upstream()
      inspector.print_result()
args:
- key: installPath
  alias: 安装路径
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
- key: bws_port
  alias: HTTP端口
  type: text
  require: false
  source: custom
  default: "80"
  memo: BWS HTTP服务端口,用于状态接口采集
script: python
