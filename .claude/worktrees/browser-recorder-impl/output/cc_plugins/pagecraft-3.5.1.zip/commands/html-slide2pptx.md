---
name: html-slide2pptx
description: 导出演示稿为 PPTX 文件（支持 editable / image 两种模式）
skill: html-slide-gen
argument-hint: [演示稿目录路径]
---

# 导出 PPTX

演示稿目录：$ARGUMENTS

> 属于 pagecraft `html-slide-gen` skill 的导出入口。

## 执行

> **首次使用**：导出依赖 Node 模块，而 plugin 分发包不含 `node_modules`。**无需手动安装**——首次导出时脚本会自动把 playwright/pptxgenjs/sharp 装到 `~/.cache/html-slide-gen` 并下载 Chromium；后续命中缓存秒过。若自举失败（如无网络/无 npm），再手动：`npm install --prefix ~/.cache/html-slide-gen playwright pptxgenjs sharp`。

1. 确认目录存在且包含 `export/<name>-live/slides/` 子目录（有 HTML 文件）
2. 询问用户导出模式：
   - **editable**：文字可编辑，要求 HTML 符合 2 条硬约束（文字用 p/h 包裹 + 背景只在 div 上）
   - **image**：视觉 100% 保真，文字不可编辑
3. editable 模式运行轻量校验（F6 精简：主流程已跑过 strict，此处只补导出特有的图片嵌入 + runtime 检查）：
   ```bash
   node ${CLAUDE_PLUGIN_ROOT}/skills/html-slide-gen/scripts/validate.mjs --deck <dir>/export/<name>-live --check img-embed
   node ${CLAUDE_PLUGIN_ROOT}/skills/html-slide-gen/scripts/validate.mjs --deck <dir>/export/<name>-live --check runtime
   ```
   不通过则修复后重试，通过后再导出。如确需完整校验（例如直接对未经主流程的 deck 导出），仍可跑 `--mode editable-strict`。
4. 运行导出脚本：

```bash
node ${CLAUDE_PLUGIN_ROOT}/skills/html-slide-gen/scripts/export_pptx.mjs --slides <dir>/export/<name>-live/slides --out <dir>/export/<标题>.pptx --mode <editable|image>
```

5. editable 模式报错时自动降级到 image 模式并告知用户
6. 导出成功后告知用户文件路径
