---
name: ppt-gen
description: 把源文档（PDF/URL/Markdown/Word）或需求转换为原生可编辑 PPTX 文件（PowerPoint 可直接二次编辑）。擅长传统方案类、架构图类、企业汇报类规整 PPT。
skill: ppt-generator
argument-hint: [源文档路径/URL，或 PPT 主题描述]
---

# 生成可编辑 PPTX — 文档转 PPT 全流程

$ARGUMENTS

> 属于 pagecraft `ppt-generator` skill 的入口。完整工作流定义见 `${CLAUDE_SKILL_DIR}/SKILL.md`。

## 执行

读取 `${CLAUDE_SKILL_DIR}/SKILL.md` 获取完整工作流定义，**从头执行全部 10 个 Phase**：

**Phase 0** 前置检查（8 项确认 + 项目目录初始化）→ **Phase 1** 源文档解析（PDF/URL/MD/Word → `sources/input.md`）→ **Phase 2** 模板设计规范 → **Phase 3** 设计规范细化（12 章节 `design_spec.md`）→ **Phase 4** 图片生成（可选）→ **Phase 5** SVG 页面生成 → **Phase 5.5** 预览图 → **Phase 6** 视觉验收 → **Phase 7** PPTX 导出（原生可编辑）→ 后处理。

每个 Phase 完成后执行对应 Gate（bash 脚本校验产出文件存在），不通过不进下一 Phase。

## 关键约束（按 SKILL.md，此处仅提示）

- **8 项确认**（Phase 0）：页数、配色、字体、logo、风格、图片、动画、导出格式——与用户对齐后再开工
- **Gate 硬检查点**：每 Phase 产出文件必须存在，缺失即回补，不跳过
- **产物是原生可编辑 PPTX**：文字/形状/版式可在 PowerPoint/WPS/Keynote 直接二次编辑
- **断点恢复**：每 Phase 开始前检查 `$PPT_DIR/` 下对应产出，已存在则从缺失处继续

## 产出

- `<标题>.pptx` — 原生可编辑 PowerPoint 文件（最终交付物）
- `design_spec.md` — 设计规范（12 章节）
- `svg_output/*.svg` — 每页 SVG 源
- `previews/*.png` — 预览图
- `notes/*.md` — 演讲备注（可选）

## 与 html-slide-gen 的分工

本命令产 **PPTX 文件**（为二次编辑/文件交付/文档转换/方案架构类 PPT 而生）。若用户要的是**现场演示、丰富动画、视觉效果、网页展示**，改用 `/gen-html-slide`（HTML 演示稿）。
