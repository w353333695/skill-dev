---
name: gen-html-slide
description: 从需求开始执行完整演示稿制作流程（策略→故事线→内容→视觉设计与 HTML 交付）
skill: html-slide-gen
argument-hint: [演示主题或需求描述]
---

# 生成演示稿 — 全流程

$ARGUMENTS

> 属于 pagecraft `html-slide-gen` skill 的入口之一。完整工作流定义见 `${CLAUDE_SKILL_DIR}/SKILL.md`。

## 执行

读取 `${CLAUDE_SKILL_DIR}/SKILL.md` 获取完整工作流定义，**从头执行全部 4 个 Phase**：

**前置动作**（扫描上下文 + 快速通道判断 + 确认篇幅）→ **Phase 1** 策略与规划 → **Phase 2** 搭建骨架 → **Phase 3** 内容填充 → **Phase 4** 视觉设计与交付（4.1 品牌资产 + 4.2 逐页规格 + 4.3 生成 HTML + 4.3.x 校验 + 4.4 用户确认与按需导出）。

## 关键约束（按 SKILL.md，此处仅提示）

- **3 处硬阻塞用户确认**：确认篇幅、Phase 3 讲稿确认、Phase 4.1 设计方向确认。其余 Gate 内部自检自动推进
- **断点恢复**：每个 Phase 开始前检查对应产出文件（strategy.md / outline.md / speech.md / export/.../slides/），已存在则从缺失章节继续——未指定 `$ARGUMENTS` 时扫描 `slides-output/` 下已有目录
- **视觉验收只走程序静态分析**（validate + post-process），不调浏览器截图/AI 看图；观感交用户
- **单文件自动导出**：4.3.4 Gate 通过后自动运行 `export_single.mjs`
- **多入口展示**：完成后输出单文件 Markdown 链接 + Elevo 预览 URL（如有）+ `present_result`（如可用）

## 产出

- `index.html` — 单文件 HTML（默认展示入口）
- `export/<name>-live/` — 多页版本（独立文件夹，可直接迁移）
  - `index.html` + `index-runtime.js` — 入口壳 + 运行时
  - `slides/*.html` — 每页独立 HTML
  - `shared/tokens.css` — 设计 token
  - `assets/` — 品牌图片
- `strategy.md` / `outline.md` / `speech.md` / `brand-spec.md` — 过程产物（跨会话恢复用）

按需导出 PPTX / PDF 到 `export/` 目录（详见 SKILL.md §4.4，或用 `/html-slide2pptx`、`/html-slide2pdf` 命令）。
