---
name: md2pdf
description: 将 Markdown 文件转换为 PDF
skill: doc-convert
---

# md2pdf — Markdown → PDF

将 Markdown 文件转换为高质量 PDF。完整转换策略、主题切换和错误处理参见 `doc-convert` skill。

## 用法

```text
/md2pdf <source.md> [-o output.pdf] [--theme <name>]
```

## 参数

| 参数 | 必需 | 说明 |
|------|------|------|
| `source.md` | 是 | 源 Markdown 文件路径（.md 或 .markdown） |
| `-o` | 否 | 输出 PDF 路径。未指定时使用源文件名 + `.pdf` |
| `--theme` | 否 | 主题名称：`default`（默认）或 `minimal`（紧凑无衬线） |

## 示例

```text
/md2pdf readme.md
/md2pdf docs/design.md -o output/design.pdf
/md2pdf notes.md --theme minimal
/md2pdf report.md -o /tmp/report.pdf --theme default
```
