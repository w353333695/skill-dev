---
name: html-slide2pdf
description: 导出演示稿为 PDF 文件（逐页截图，视觉 100% 保真）
skill: html-slide-gen
argument-hint: [演示稿目录路径]
---

# 导出 PDF

演示稿目录：$ARGUMENTS

> 属于 pagecraft `html-slide-gen` skill 的导出入口。

## 执行

> **首次使用**：导出依赖 Node 模块，而 plugin 分发包不含 `node_modules`。**无需手动安装**——首次导出时脚本会自动把 playwright/pdf-lib 装到 `~/.cache/html-slide-gen` 并下载 Chromium；后续命中缓存秒过。若自举失败（如无网络/无 npm），再手动：`npm install --prefix ~/.cache/html-slide-gen playwright pdf-lib`。

1. 确认目录存在且包含 `export/<name>-live/slides/` 子目录（有 HTML 文件）
2. 运行导出脚本：

```bash
node ${CLAUDE_PLUGIN_ROOT}/skills/html-slide-gen/scripts/export_pdf.mjs --slides <dir>/export/<name>-live/slides --out <dir>/export/<标题>.pdf
```

3. 导出成功后告知用户文件路径
