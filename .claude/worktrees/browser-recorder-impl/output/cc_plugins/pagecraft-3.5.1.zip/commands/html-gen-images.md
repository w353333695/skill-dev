---
name: html-gen-images
description: AI 图片生成命令 — 独立命令，读取大纲标注后调用内置生图脚本为演示稿生成配图
skill: html-slide-gen
argument-hint: （无参数，自动从当前 slides-output 目录读取）
---

# AI 图片生成

> **本命令独立于主流程**。可手动调用为已有项目补生成图片（主流程生图由 Phase 4.1.5 触发）。属于 pagecraft `html-slide-gen` skill。

## 前置条件

1. 当前工作目录下存在 `slides-output/` 子目录
2. `slides-output/` 下有且仅有一个项目目录（如有多个，报错让用户指定）
3. 该项目目录下存在 `outline.md`（含 `[visual: ...]` 标注）
4. 该项目目录下存在 `brand-spec.md`
5. 生图环境（二选一，按优先级探测）：
   - **内置（推荐，零外部依赖）**：`ANTHROPIC_AUTH_TOKEN` + `ANTHROPIC_BASE_URL` 环境变量已设置 → 用本 skill 自带的 `${CLAUDE_SKILL_DIR}/scripts/generate-image.mjs`（Node 18+ 内置 fetch）
   - **可选回退**：`PAGECRAFT_PATH` 环境变量已设置，或 `~/.ppt-generator.json` 中有 `pagecraft_path` → 用 pagecraft 的 `image-gen` skill 的 generate.py（接口完全兼容）

## 执行步骤

### 1. 定位项目目录和输出路径

扫描 `slides-output/` 下所有子目录，找到包含 `outline.md` 的项目目录 `<name>`。如果有多个，选择最近修改的那个。

**确定图片输出目录**：所有生成的图片必须保存到 `<name>-live/assets/` 目录，因为这是 HTML slides 通过 `../assets/` 相对路径引用的位置。执行以下步骤确保目录存在：

```bash
# 先检查 -live 目录是否已存在，不存在则创建完整结构
ls "slides-output/<name>/export/<name>-live/slides/" 2>/dev/null && echo "LIVE_EXISTS" || echo "LIVE_NOT_FOUND"
```

- 如果输出 `LIVE_EXISTS`：目录已就绪，直接使用
- 如果输出 `LIVE_NOT_FOUND`：先创建目录结构，再继续：
```bash
mkdir -p "slides-output/<name>/export/<name>-live/assets/"
```

**后续所有 `-o` 参数统一使用**：`slides-output/<name>/export/<name>-live/assets/<filename>.png`

### 2. 提取视觉标注

读取 `slides-output/<name>/outline.md`，提取所有视觉标注。标注分两级：

**页面级标注**：`[visual: <type>]`，过滤掉 `[visual: none]`。每页最多一个。

**元素级标注**（紧跟页面级标注之后）：
- `[card-bg: N]` — N 个卡片需要 AI 背景
- `[decor: position]` — 装饰元素（position: corner-bl/corner-tr/corner-br/corner-tl/side-left/side-right）
- `[section-bg]` — 区块背景氛围图

**注意**：`[visual: none]` 的页面仍然可能有元素级标注（如 `[visual: none] [section-bg]`），不要跳过。

如果整份大纲没有任何视觉标注（页面级和元素级均为空），输出"无需生图"并结束。

### 3. 确认生图环境（内置优先，可选回退）

按优先级探测可用生图后端，命中即用，记为 `$GEN_CMD`（后续步骤统一调 `$GEN_CMD`）：

**优先级 A — 内置（零外部依赖）**：检查 `ANTHROPIC_AUTH_TOKEN` 和 `ANTHROPIC_BASE_URL` 是否都已设置。若都有：

```bash
node "${CLAUDE_SKILL_DIR}/scripts/generate-image.mjs" --help && export GEN_CMD="node ${CLAUDE_SKILL_DIR}/scripts/generate-image.mjs"
```

**优先级 B — 可选回退**：若 A 缺环境变量，读 `~/.ppt-generator.json` 的 `pagecraft_path`（或 `PAGECRAFT_PATH` 环境变量）。若存在：

```bash
python3 $PAGECRAFT_PATH/skills/image-gen/scripts/generate.py --help && export GEN_CMD="python3 $PAGECRAFT_PATH/skills/image-gen/scripts/generate.py"
```

**两者都不可用**：报错中止，提示用户「设置 `ANTHROPIC_AUTH_TOKEN` + `ANTHROPIC_BASE_URL` 用内置生图，或配置 `PAGECRAFT_PATH` 走回退」。**不要静默跳过**。

> 两个后端 CLI 接口完全兼容（prompt 位置参数 + `-o`/`-m`/`-s`/`-n`/`--timeout`，退出码 0/1/2 语义一致），后续步骤无需区分。

### 4. 读取参考资料

> **Prompt 构造的完整知识（场景分类、A/B 复杂度、6 段式/3 段式模板、风格关键词、尺寸表、中文渲染、品牌色注入、CSS 降级方案）一律以 `visual-content-guide.md` 为准**——本命令不再重述，只负责"按标注 → 选模板 → 调生图后端 → 写 manifest"的执行编排。

按以下优先级读取：

- **必读（Prompt 知识库）**：`${CLAUDE_SKILL_DIR}/references/visual-content-guide.md` — 重点 §二（场景模板，按标注类型匹配 prompt 格式）、§三（Prompt 工程）、§4.3（品牌色注入）、§4.4（失败降级 CSS 方案）
- **必读**：`slides-output/<name>/brand-spec.md` — 主色 hex、气质关键词
- **必读**：`slides-output/<name>/speech.md` — 每页标题和核心信息（用于构造 prompt 主体，不需逐字稿细节）
- **必读**：`slides-output/<name>/outline.md` — 已在步骤 2 读取

### 5. 确定风格锚点

基于 brand-spec.md 的气质关键词 + 色板，按 **visual-content-guide.md §1.5「风格维度锁」**确定透视 / 质感 / 光影三维度，输出一行风格前缀，后续所有 prompt（A/B 类）继承。具体维度取值与示例见 §1.5，**不在此重复**。

### 6. 品牌色注入

从 brand-spec.md 读取主色 hex，按 **visual-content-guide.md §4.3** 转换为 prompt 色彩描述注入所有 prompt。

### 7. 逐条生成图片

对所有标注（页面级 + 元素级），按标注类型选 prompt 模板和尺寸。**A/B 类划分、对应标注类型、6 段式/3 段式模板、尺寸表、文件名规则、同组风格一致性约束——全部查 visual-content-guide.md §二（A 类各维度）和 §2.11-§2.13（B 类 card-bg/decor/section-bg）**，本命令不重述。

调用生图后端（`$GEN_CMD` 在步骤 3 已确定——内置 `generate-image.mjs` 或回退 `generate.py`，接口完全兼容）：

```bash
$GEN_CMD \
  "<prompt>" \
  -o "slides-output/<name>/export/<name>-live/assets/<filename>.png" \
  -s <size> -m gpt-image-2
```

**并行执行**：所有图片互相独立，同时启动多个 Bash 调用（包括 A 类和 B 类混合并行）。

**⚠️ 你必须实际执行生图命令（用 Bash 工具）。不要模拟、不要跳过、不要只写 manifest 不生成图片。如果你的输出中没有出现 `$GEN_CMD ...` 这样的 Bash 命令执行记录，则你失败了。**

### 8. 校验并修正图片路径

所有生图调用完成后，执行以下 Bash 命令**校验图片实际位置**：

```bash
# 目标目录
TARGET="slides-output/<name>/export/<name>-live/assets/"

# 检查是否有图片被保存到了错误目录（缺少 -live 后缀）
WRONG_DIR="slides-output/<name>/export/<name>/assets/"
if [ -d "$WRONG_DIR" ] && ls "$WRONG_DIR"*.png 1>/dev/null 2>&1; then
  echo "FOUND_IN_WRONG_DIR"
else
  echo "ALL_CORRECT"
fi
```

- 如果输出 `ALL_CORRECT`：所有图片在正确位置，继续步骤 9
- 如果输出 `FOUND_IN_WRONG_DIR`：执行修正，将图片移到正确目录：
```bash
mkdir -p "slides-output/<name>/export/<name>-live/assets/"
mv "slides-output/<name>/export/<name>/assets/"*.png "slides-output/<name>/export/<name>-live/assets/"
echo "MOVED"
```

**此步骤不可跳过。** 即使你认为路径写对了，也必须执行校验。

### 8.5 逐页比对 outline.md [img:] 文件名与 assets/ 实际文件

在步骤 10（更新 outline.md）之前，先逐页比对确保图片文件名与 assets/ 目录中实际存在的文件一致。

```bash
# 对 outline.md 中已标注的 [img:] 文件名，逐个检查 assets/ 下是否存在
# 同时检查 assets/ 目录中有多余的文件未被任何 [img:] 引用
cd "slides-output/<name>/export/<name>-live/assets/"
echo "=== Assets files ==="
ls -1 *.png 2>/dev/null || echo "NO_PNG"
```

然后读取 outline.md 中所有 `[img: ...]` 标注的文件名，与 assets/ 目录实际文件逐个对比：

1. **outline.md 中标注但 assets/ 中不存在** → 标记该图片为 FAILED（可能是生图脚本输出路径错误）
2. **assets/ 中存在但 outline.md 未标注** → 可能是前次遗留，如果是本次生成的则追加到对应页的 [img:] 标注
3. **文件名不一致**（如 outline.md 写 `cover-01.png`，实际文件叫 `cover-p01.png`）→ 以实际文件名为准，修正 outline.md 标注

**此步骤的作用**：防止 subagent 在 Phase 4.4 嵌入图片时因路径不匹配导致 ASSET_MISSING ERROR（validate Check 10）。

### 8.6 种子图片质量自检

生图脚本输出的图片，在写入 image-manifest.md 之前必须通过以下自检。任一项不通过，标记为 FAILED 并触发 CSS 降级。

> 当前**已实现**文件大小检查（纯 bash，零依赖）。**宽高比 / 颜色标准差**两项需图像解析能力，未在本命令实现——如未来接入 sharp/PIL，可在下方补齐；现阶段仅靠文件大小 + 生图脚本退出码判断成败。

```bash
# 已实现：文件大小检查（< 10KB 视为空白/错误图）
cd "slides-output/<name>/export/<name>-live/assets/"

for f in *.png; do
  SIZE=$(stat -f%z "$f" 2>/dev/null || stat -c%s "$f" 2>/dev/null)
  if [ "$SIZE" -lt 10240 ]; then
    echo "FAILED_SMALL: $f (${SIZE}B < 10KB)"
  fi
done
```

| 自检项 | 阈值 | 失败原因 | 处理 | 状态 |
|--------|------|---------|------|------|
| 文件大小 | > 10KB | 可能是空白/错误图 | 标记 FAILED，CSS 降级 | ✅ 已实现 |
| 宽高比 | 与目标偏差 < 5% | 变形/裁切错误 | 标记 FAILED，CSS 降级 | ⏳ 未实现（依赖图像库） |
| 平均颜色标准差 | > 5 | 可能为纯色/空白 | 标记 FAILED，CSS 降级 | ⏳ 未实现（依赖图像库） |

> 生图脚本自身退出码非 0 也应判为 FAILED（脚本层面捕获）。

CSS 降级方案：参考 `visual-content-guide.md` §4.4 的具体模板库（封面→§4.4.1、概念配图→§4.4.2、图标→§4.4.3 等），按视觉类型选择对应模板直接使用。

### 9. 写入 image-manifest.md

所有图片生成完成后，写入 `slides-output/<name>/image-manifest.md`：

```markdown
# AI 生图清单
> 生成日期：YYYY-MM-DD
> 风格锚点：<风格描述>

| 页码 | 标注 | 文件名 | 尺寸 | 状态 | 用途 |
|------|------|--------|------|------|------|
| P01  | cover | cover-01.png | 1792x1024 | OK | 封面背景 |
| P03  | card-bg | card-bg-p03-01.png | 1024x1024 | OK | 痛点卡片1背景 |
| P03  | card-bg | card-bg-p03-02.png | 1024x1024 | OK | 痛点卡片2背景 |
| P03  | card-bg | card-bg-p03-03.png | 1024x1024 | OK | 痛点卡片3背景 |
| P05  | arch-infographic | arch-01.png | 1792x1024 | OK | 架构图 |
| P05  | decor | decor-p05-corner-bl.png | 1024x1024 | OK | 左下角装饰 |
| P07  | data-bg | data-bg-01.png | 1792x1024 | OK | 数据页背景 |
| P09  | ending | ending-01.png | 1792x1024 | OK | 结尾愿景 |
```

状态列：`OK`（成功）、`FAILED`（生图失败）。

用途列：简要描述图片用途，便于 subagent 在 Phase 4.4 定位使用。

### 10. 更新 outline.md 追加图片文件名

将 OK 状态的图片文件名直接写入 outline.md 的对应页面行，让 Phase 4.4 的 subagent 在读 outline 时就能看到每页需要嵌入哪些图片。

**执行步骤**：

1. 读取刚写入的 `slides-output/<name>/image-manifest.md`，按页码分组所有 OK 状态的图片文件名
2. 读取 `slides-output/<name>/outline.md`，逐行处理：
   - 找到 `P<数字>` 开头的行（即逐页大纲行）
   - 如果该行末尾已有 `[img: ...]`（重跑场景），先删除该标注
   - 如果 image-manifest 中该页码有 OK 图片，在行尾追加 `[img: file1.png, file2.png]`
   - 如果该页码无 OK 图片，不追加
3. 写回 outline.md

**示例效果**：

```markdown
P01  专业航拍，让项目展示高出一个身位 [visual: cover] [img: cover-01.png]
P02  870万台消费级无人机出货 [visual: none]
P03  消费级航拍三大硬伤 [visual: comparison] [card-bg: 3] [img: comparison-01.png, card-bg-p03-01.png, card-bg-p03-02.png, card-bg-p03-03.png]
P10  预约免费试拍 [visual: none] [section-bg] [img: section-bg-p10.png]
```

**⚠️ 此步骤不可跳过。** outline.md 中的 `[img:]` 标注是 Phase 4.4 subagent 嵌入图片的权威来源，validate Check 10 会据此校验。

### 11. 输出报告

输出摘要：
- 总标注数（页面级 + 元素级）、成功数、失败数
- A 类/B 类分别多少张
- image-manifest.md 路径
- 如有失败图片，列出原因
