#!/usr/bin/env python3
"""调用图片生成接口，将返回的 base64 或 URL 结果保存为本地 PNG 文件。"""
from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from pathlib import Path

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

ENV_TOKEN = "ANTHROPIC_AUTH_TOKEN"
ENV_BASE_URL = "ANTHROPIC_BASE_URL"
API_PATH = "/v1/images/generations"
MIN_TIMEOUT = 1800
DEFAULT_OUTPUT_DIR = Path("/workspace/tmp")


def resolve_api_url() -> str:
    base = os.environ.get(ENV_BASE_URL, "").strip().rstrip("/")
    if not base:
        raise SystemExit(f"Error: environment variable {ENV_BASE_URL} is not set.")
    # 兼容 base url 自身已含 /v1 的场景
    if base.endswith("/v1"):
        return base + "/images/generations"
    return base + API_PATH


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Generate images via image-gen API and save locally.",
    )
    p.add_argument("prompt", help="Image generation prompt (required)")
    p.add_argument(
        "-o", "--output",
        help="Output file path or directory. Default: /workspace/tmp/ with auto-named file.",
    )
    p.add_argument("-m", "--model", default="gpt-image-2", help="Model name (default: gpt-image-2)")
    p.add_argument("-s", "--size", default="1024x1024", help="Image size (default: 1024x1024)")
    p.add_argument("-n", "--count", type=int, default=1, help="Number of images (default: 1)")
    p.add_argument("--timeout", type=int, default=1800, help="Request timeout seconds (default: 1800)")
    return p


def resolve_output_paths(output: str | None, count: int, prompt: str) -> list[Path]:
    ts = time.strftime("%Y%m%d-%H%M%S")
    slug = "".join(c if c.isalnum() else "_" for c in prompt[:30]).strip("_") or "image"

    if output is None:
        base_dir = DEFAULT_OUTPUT_DIR
        base_dir.mkdir(parents=True, exist_ok=True)
        if count == 1:
            return [base_dir / f"{ts}_{slug}.png"]
        return [base_dir / f"{ts}_{slug}_{i+1}.png" for i in range(count)]

    out_path = Path(output).expanduser()
    if out_path.is_dir() or output.endswith(("/", os.sep)):
        out_path.mkdir(parents=True, exist_ok=True)
        if count == 1:
            return [out_path / f"{ts}_{slug}.png"]
        return [out_path / f"{ts}_{slug}_{i+1}.png" for i in range(count)]

    out_path.parent.mkdir(parents=True, exist_ok=True)
    if count == 1:
        return [out_path]
    stem, suffix = out_path.stem, out_path.suffix or ".png"
    return [out_path.with_name(f"{stem}_{i+1}{suffix}") for i in range(count)]


def call_api(token: str, payload: dict, timeout: int) -> dict:
    api_url = resolve_api_url()
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    try:
        resp = requests.post(api_url, json=payload, headers=headers, timeout=timeout, verify=False)
    except requests.RequestException as e:
        raise SystemExit(f"Network error: {e}") from e

    if not resp.ok:
        raise SystemExit(f"HTTP {resp.status_code} error: {resp.text}")

    try:
        return resp.json()
    except json.JSONDecodeError as e:
        raise SystemExit(f"Invalid JSON response: {resp.text[:500]}") from e


def download_image(url: str, timeout: int) -> bytes:
    """从 URL 下载图片，返回原始字节。"""
    try:
        resp = requests.get(url, timeout=timeout, verify=False)
    except requests.RequestException as e:
        raise SystemExit(f"Download network error: {e}") from e

    if not resp.ok:
        raise SystemExit(f"Download HTTP {resp.status_code} error: {resp.text[:500]}")

    return resp.content


def save_item(item: dict, path: Path, timeout: int) -> None:
    """将单个返回项（b64_json 或 url）保存为本地文件。"""
    b64 = item.get("b64_json")
    if b64:
        path.write_bytes(base64.b64decode(b64))
        return

    url = item.get("url")
    if url:
        path.write_bytes(download_image(url, timeout))
        return

    raise ValueError("item missing both b64_json and url")


def main() -> int:
    args = build_parser().parse_args()

    token = os.environ.get(ENV_TOKEN)
    if not token:
        print(f"Error: environment variable {ENV_TOKEN} is not set.", file=sys.stderr)
        return 2

    if args.count < 1:
        print("Error: --count must be >= 1", file=sys.stderr)
        return 2

    if args.timeout < MIN_TIMEOUT:
        print(f"Warning: timeout {args.timeout}s too low, clamped to {MIN_TIMEOUT}s", file=sys.stderr)
        args.timeout = MIN_TIMEOUT

    payload = {
        "model": args.model,
        "prompt": args.prompt,
        "n": args.count,
        "size": args.size,
    }

    data = call_api(token, payload, args.timeout)
    items = data.get("data") or []
    if not items:
        print(f"Error: no images returned. Raw response: {json.dumps(data)[:500]}", file=sys.stderr)
        return 1

    paths = resolve_output_paths(args.output, len(items), args.prompt)
    saved: list[str] = []
    for item, path in zip(items, paths):
        try:
            save_item(item, path, args.timeout)
            saved.append(str(path))
        except Exception as exc:
            print(f"Warning: failed to save image: {exc}", file=sys.stderr)
            continue

    if not saved:
        return 1

    for p in saved:
        print(p)
    return 0


if __name__ == "__main__":
    sys.exit(main())
