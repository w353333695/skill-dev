// 一次性脚本：为 color-schemes.json 每个 scheme 补 hi-strong（CTA）+ data-1..6 预设。
// 治 C1/D14：不依赖 style_advisor 运气，每个 scheme 自带与底色协调的强调三元组 + 数据系列色。
// 调和策略：
//   - hi-strong（CTA）：取该 scheme 的 brand-accent 作为 CTA 基（已是设计选定的强调色）；
//     若 accent 与 brand-bg 对比不足（WCAG AA 大字 ≥ 3:1），向高饱和/深色微调 HSL。
//   - data-1..6：Okabe-Ito 色盲安全 6 色（全 scheme 统一，保证图表可读 + 一致性）。
// 幂等：已有 hi-strong 的 scheme 不覆盖。
// 用法：node scripts/harmonize-color-presets.mjs  （原地改写 color-schemes.json，先备份）
import { readFileSync, writeFileSync, copyFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PATH = join(__dirname, 'color-schemes.json');

// Okabe-Ito 色盲安全 6 色（全 scheme 统一）
const OKABE_ITO = ['#0072B2', '#E69F00', '#009E73', '#CC79A7', '#56B4E9', '#D55E00'];

// hex → {h,s,l} 转换
function hexToHsl(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  const r = parseInt(m[1].slice(0, 2), 16) / 255;
  const g = parseInt(m[1].slice(2, 4), 16) / 255;
  const b = parseInt(m[1].slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0; const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) * 60;
    else if (max === g) h = ((b - r) / d + 4) * 60;
    else h = ((r - g) / d + 2) * 60;
  }
  return { h, s: s * 100, l: l * 100 };
}
function hslToHex(h, s, l) {
  s /= 100; l /= 100;
  const a = s * Math.min(l, 1 - l);
  const f = n => { const k = (n + h / 30) % 12; const c = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); return Math.round(255 * c).toString(16).padStart(2, '0'); };
  return `#${f(0)}${f(8)}${f(4)}`;
}
// 相对亮度（WCAG）
function lum(hex) {
  const h = hexToHsl(hex); if (!h) return 0.5;
  // 近似：用 HSL 的 L 作对比代理（精确 WCAG 需线性 RGB，这里够用）
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim()); if (!m) return 0.5;
  const rgb = [0, 2, 4].map(o => parseInt(m[1].slice(o, o + 2), 16) / 255).map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4));
  return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
}
function contrast(fg, bg) {
  const l1 = lum(fg), l2 = lum(bg);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}
function hexToRgbTriple(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return '0,0,0';
  return [0, 2, 4].map(o => parseInt(m[1].slice(o, o + 2), 16)).join(',');
}

const raw = readFileSync(PATH, 'utf8');
const json = JSON.parse(raw);
const schemes = json.schemes;
let added = 0, skipped = 0;
for (const [name, sch] of Object.entries(schemes)) {
  if (!sch.tokens) continue;
  if (sch.tokens['hi-strong']) { skipped++; continue; }
  const accent = sch.tokens['brand-accent'];
  const bg = sch.tokens['brand-bg'];
  let cta = accent;
  if (accent && bg) {
    const hsl = hexToHsl(accent);
    if (hsl) {
      // 先确保饱和度 ≥ 58%（CTA 要够"亮"），再迭代调明度直到对比度 ≥ 3.5（AA 大字 + 投影可读）
      let { h, s } = hsl;
      s = Math.max(s, 58);
      const bgLum = lum(bg);
      const wantDark = bgLum > 0.45; // 底色亮 → CTA 加深；底色暗 → CTA 提亮
      let l = wantDark ? Math.min(hsl.l, 42) : Math.max(hsl.l, 58);
      let cand = hslToHex(h, s, l);
      // 迭代逼近对比度 ≥ 3.5（步长 6%，最多 8 步，clamp 到 [18, 82]）
      for (let step = 0; step < 8 && contrast(cand, bg) < 3.5; step++) {
        l = wantDark ? Math.max(18, l - 6) : Math.min(82, l + 6);
        cand = hslToHex(h, s, l);
      }
      cta = cand;
    }
  }
  sch.tokens['hi-strong'] = cta;
  sch.tokens['hi-strong-rgb'] = hexToRgbTriple(cta);
  // data-1..6：Okabe-Ito（深底/暗主题可选降亮，这里统一用标准色保证图表一致）
  for (let i = 0; i < 6; i++) sch.tokens[`data-${i + 1}`] = OKABE_ITO[i];
  added++;
}
writeFileSync(PATH, JSON.stringify(json, null, 2) + '\n', 'utf8');
console.log(`✓ 已为 ${added} 个 scheme 补 hi-strong + data-1..6 预设（跳过 ${skipped} 个已有）`);
console.log('  示例 evergreen hi-strong:', schemes.evergreen.tokens['hi-strong']);
console.log('  示例 ocean-depths hi-strong:', schemes['ocean-depths'].tokens['hi-strong']);
