# spec-format.md — T1/T2 规格文件格式（Phase 4.2 按需读）

> Phase 4.2 为每页生成 `specs/PPT-NN.md` 规格文件。T1/T2 格式不同——T1 是 data-replace key→value 映射，T2 是骨架引用 + Style Transfer delta + 占位符映射。本文件是格式模板，4.2 生成 spec 时读。

## T1 规格格式（模板骨架——内容映射为 data-replace key → value）

```markdown
# PPT-NN：[页面标题]
- 骨架来源：T1（<模板名> / <角色ID>）

## 骨架源
- 模板文件：templates/starter-decks/<模板名>/slides/<源文件>
- 角色：<角色ID>
- 适配：[无 / 3卡扩为4卡 / ...]

## 内容映射（data-replace key → 真实内容）
- section_num → "01"
- section_tag → "PROBLEM"
- section_title → "具体标题"
- card_1_title → "卡片标题"
- card_1_body → "卡片正文（≤80 字，超了拆卡片或精简——见 subagent-rules 陷阱清单）"
- ...

## 重点页强调（可选——仅重点页标）
- `[emph: kpi-strong]` 挂在 card_1_body 的核心数字上（动作白名单见 subagent-rules §重点页强调）
- `[emph: positive]` 挂在增长指标上
- 无强调需求则省略本段

## 逐字稿
见 speech.md PPT-NN。（指针引用，不内联全文；生成时从 speech.md 取该页讲稿填入 <aside class="notes">）

## 内容适配检查
- [卡片数/标题长度/内容均匀度等检查项]
```

## T2 规格格式（通用骨架——不内嵌完整 HTML 骨架，仅记录骨架引用 + Style Transfer delta + 内容映射）

```markdown
# PPT-NN：[页面标题]
- 骨架来源：[T2-prebaked（t2-skeletons.md#pitch-deck-l19） | T2（layout-catalog L21 @ offset=410）]  ← 有预置必须用前者
- 骨架：[预置锚点 / 布局编号 + 名称]
- Style Transfer：从 <模板名> 继承 composition 特征

## 骨架源
- **有预置**：`references/t2-skeletons.md#<template>-<layout>`（subagent 复制整段 HTML，仅替换 [占位符]）
- **无预置（回退）**：`layout-catalog.md` Lxx <名称> `@ offset=N`（subagent 直接按 offset 局部读，limit≈44；offset 见 `layout-catalog-index.md` offset 列。勿整文件加载 catalog）

## Style Transfer 注入（delta 必须逐项对齐 <模板名>/slide-roles.md 的 Style Transfer 段——从 slide-roles.md **复制**数值，不要凭记忆）
- 空间密度：body padding（如 pitch-deck `118px 165px` / 架构图页 `80px 150px 60px`）
- 排版层级：内容页标题 h2 字号/字重/字距（如 pitch-deck 82px / 800 / -0.03em）
- 装饰模式：.section-num（如 pitch-deck 293px 水印）+ .num-tag + 分隔线
- 组件统一：卡片圆角（如 pitch-deck var(--radius)=27px）、grid gap（如 32px）
- 禁止元素：[从 slide-roles.md 的「禁止引入的视觉元素」表复制]
- [其他该页需要的 delta...]

## 幻灯片可见内容（占位符 → 真实内容映射）
- [xxx] → "真实内容"
- card_N_body → "卡片正文（≤80 字，超了拆卡片或精简）"
- ...

## 逐字稿
见 speech.md PPT-NN。（指针引用，不内联全文）

## Style Transfer 注入检查
- [ ] 空间密度对齐模板 body padding（数值与 slide-roles.md 一致）
- [ ] 排版层级对齐（h2 字号/字重/字距）
- [ ] 装饰模式继承（.section-num / .num-tag 等）
- [ ] 无模板禁止的视觉元素
```

> **spec 瘦身**：T1 spec 只有内容映射（无骨架）；T2 spec 是「布局引用 + Style Transfer delta + 内容映射」——HTML 骨架不序列化进 spec，生成时从 layout-catalog 局部读取。HTML 只写一次（最终 slide 文件），不再 spec/各 slide 双写。

## 批量生成许可

spec 文件之间**无 page 间依赖**：节奏检查（`_rhythm-check.md`）和容量预检（`check-spec-capacity.mjs`）都是**事后产物**，不阻塞单页 spec 的写入。

因此生成 spec 时**允许批量**：

- 在 1-2 个 turn 内用 heredoc 一次写出 `specs/PPT-01.md` … `specs/PPT-NN.md` 全部文件，而非逐页一个 turn 串行
- 先整体规划"骨架来源分配 + 图表选型 + 冲击页识别"（这些决策对全 deck 一次性算完），再批量落 spec
- 节奏检查 + 容量预检**全部写完后统一跑一次**（Gate 校验批量后一次性做）

少数需要页间或容量决策的页（Adapt / 拆页 / 冲击页）可单独留到批量写完后处理。详见 SKILL.md Phase 4.2「批量生成许可」段。
