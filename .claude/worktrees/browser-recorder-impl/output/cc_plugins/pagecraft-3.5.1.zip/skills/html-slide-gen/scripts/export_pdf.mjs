#!/usr/bin/env node
/**
 * export_pdf.mjs — 把多文件演示稿导出为 PDF
 *
 * 串行渲染每张 slide 为 PNG，再用 pdf-lib 合并为 PDF。
 * 不使用 page.pdf()（Chromium 打印渲染器与屏幕渲染有差异）。
 *
 * 用法：
 *   node export_pdf.mjs --slides <dir> --out <file.pdf> [--width 1440] [--height 900]
 *
 * 依赖：npm install playwright pdf-lib（plugin 分发包不含 node_modules，缺失时脚本会打印安装命令）
 *
 * 按文件名排序（01-xxx.html → 02-xxx.html → ...）。
 */

import fs from 'fs/promises';
import path from 'path';
import { dep } from './_resolve.mjs';

function parseArgs() {
  const args = { width: 1920, height: 1080 };
  const a = process.argv.slice(2);
  for (let i = 0; i < a.length; i += 2) {
    const k = a[i].replace(/^--/, '');
    args[k] = a[i + 1];
  }
  if (!args.slides || !args.out) {
    console.error('用法: node export_pdf.mjs --slides <dir> --out <file.pdf> [--width 1920] [--height 1080]');
    process.exit(1);
  }
  args.width = parseInt(args.width);
  args.height = parseInt(args.height);
  return args;
}

async function main() {
  const { slides, out, width, height } = parseArgs();
  const slidesDir = path.resolve(slides);
  const outFile = path.resolve(out);

  const chromium = dep('playwright').chromium;
  const { PDFDocument } = dep('pdf-lib');

  const files = (await fs.readdir(slidesDir))
    .filter(f => f.endsWith('.html'))
    .sort();
  if (!files.length) {
    console.error(`No .html files found in ${slidesDir}`);
    process.exit(1);
  }

  console.log(`Rendering ${files.length} slides to PDF...`);

  const browser = await chromium.launch();
  const pngBuffers = [];

  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    const url = 'file://' + path.join(slidesDir, f);
    const page = await browser.newPage({ viewport: { width, height } });
    await page.goto(url, { waitUntil: 'networkidle' }).catch(() => page.goto(url, { waitUntil: 'networkidle' }));
    await page.evaluate(() => document.fonts.ready);
    // finish() 对 infinite 动画（iterations: Infinity）会抛 InvalidStateError，与 export_pptx 一致地兜底。
    await page.evaluate(() => document.getAnimations().forEach(a => {
      try {
        const t = a.effect?.getTiming?.();
        const infinite = t && !isFinite(t.iterations);
        if (infinite) a.cancel(); else a.finish();
      } catch { try { a.cancel(); } catch {} }
    }));
    await page.evaluate(() => Promise.all(
      Array.from(document.images).map(img => img.complete ? Promise.resolve() :
        new Promise(r => { img.onload = r; img.onerror = r; }))
    ));
    const buf = await page.screenshot({ fullPage: false, type: 'png' });
    pngBuffers.push(buf);
    await page.close();
    console.log(`  [${i + 1}/${files.length}] ${f}`);
  }

  await browser.close();

  const pdfDoc = await PDFDocument.create();
  const pdfWidth = width * 0.75;
  const pdfHeight = height * 0.75;

  for (let i = 0; i < pngBuffers.length; i++) {
    const pngImage = await pdfDoc.embedPng(pngBuffers[i]);
    const page = pdfDoc.addPage([pdfWidth, pdfHeight]);
    page.drawImage(pngImage, { x: 0, y: 0, width: pdfWidth, height: pdfHeight });
  }

  await fs.mkdir(path.dirname(outFile), { recursive: true });
  await pdfDoc.save();
  const pdfBytes = await pdfDoc.save();
  await fs.writeFile(outFile, pdfBytes);

  const sizeKB = (pdfBytes.length / 1024).toFixed(0);
  console.log(`\n✓ Wrote ${outFile}  (${files.length} pages, ${sizeKB} KB)`);
}

main().catch(e => { console.error(e); process.exit(1); });
