# 风格预设 Details — 23 套模板的完整设计语言

> 本文件是 `style-presets.md` 的详情拆分（H1 减负）。每个 `## <deck-name>` 块含 8 维度（空间密度/装饰等级分布/组件偏好/排版基调/页面节奏/专属组件/禁用模式/稀疏空间策略）。Phase 4.1 选定模板后**按锚点局部读取**对应块，勿整文件加载 298 行。

## pitch-deck

- **空间密度**：低密度 — body padding: 88px 112px, grid gap: 24px，VC 路演式大留白
- **装饰等级分布**：封面/结束页 L3（cover-bg 渐变柔光 bg + cover-blob 超大半径），内容页 L1（section-num 220px 水印数字），the-ask 页 L2（ask-box 深色渐变 bg + 重阴影）。不用 ambient-glow 或 grid-texture——用 `section-num` 做水印替代
- **组件偏好**：优先 `.card`（所有内容页）、`.card-accent`（Pro tier）、`.metric`、`.pill-accent`（方案标签）、`.section-num`（装饰数字）、`.gradient-text`（行内渐变高亮）、`.deck-footer`。避免全局 `.kicker`——用自定义 `.num-tag` 做章节标签
- **排版基调**：h1: 86px/900wt, h2: 62px/800wt, mega: 180px/900wt, big-q: 56px serif, lede: 22px。衬线仅用于 big-q（Playfair Display）
- **页面节奏**：Cover(L3) → Problem(card grid) → Solution(pills) → Product(card grid) → Market(metrics) → Business Model(3 tiers) → Traction(bar chart) → Team(avatar cards) → The Ask(dark gradient box) → Thanks(mega text)。数据冲击页与叙事过渡页交替，不用章节分隔
- **专属组件**：`.tpl-pitch-deck`, `.cover-bg`, `.cover-blob`, `.brand-dot`, `.brand`, `.mega`, `.mega-sub`, `.num-tag`, `.big-q`, `.metric`, `.team-card`, `.avatar`, `.ask-box`, `.traction-bar`, `.section-num`, `.card-hover`, `.pill-accent`
- **禁用**：白色文字浅色背景、无边框排版、小字号、水平条不带 `.traction-bar`、无阴影卡片、正文用衬线、亮色超出渐变范围
- **稀疏空间策略**：视觉放大 — 内容少时放大字号（h2→h1）、增大 padding（26→48px）、gap 翻倍（20→40px）、装饰升级 L1→L2（加 ambient-glow + card-elevated）

---

## weekly-report

- **空间密度**：高密度 — body padding: 64px 88px, kpi-card padding: 24px 26px，强调信息密度
- **装饰等级分布**：全 L1（kpi 左侧 ::before 3px 色条），封面 L2（低调），无 ambient-glow/grid-texture。body 用 `background: var(--bg)`（微灰 #fafbfc）
- **封面 V6 装饰包（数据感，L3）**：封面允许 L3 装饰——`.bar-top` 顶条 + `.cover-grid-bg`（48px 浅网格 opacity .04 底纹）+ 底部 `.kpi-mini-strip`（4 个 `.kpi-mini` 呼应内容页 KPI 预览）+ `.gradient-text` 标题 accent 词。封面 L3 = 数据感包示范（见 `style-presets.md` §封面装饰等级 V6）
- **组件偏好**：优先 `.kpi`（自定义，替代全局 .kpi-card）、`.grid.g4`（8 KPI 卡）、`.ship-item`（交付列表 + tag 徽章）、`.chart` + `.chart-bars`（自定义柱状图）、`.blocker`（红色左边框告警卡）、`.next-row`（团队分配 grid）、`.tag.feat/.fix/.exp/.infra`（类型徽章）、`.week-chip`（mono 周标签）。不用全局 `.card`——用自定义 `.kpi`、`.chart`、`.blocker`
- **排版基调**：h1: 64px/800wt, h2: 42px/700wt, kpi value: 48px/800wt, kpi label: 12px caps, body: 13-14px。Mono 用于 owner 名和图表标签
- **页面节奏**：Cover → KPIs(4×2 grid) → Shipped(线性列表) → Metrics(图表+注释) → Blockers(告警卡) → Next Week(grid 行) → Thanks。每页用 `.kicker` 做章节标签，均匀密度无呼吸页
- **专属组件**：`.tpl-weekly-report`, `.cover-head`, `.logo`, `.week-chip`, `.kpi`（含 ::before accent bar）、`.ship-item`, `.tag.feat/.fix/.exp/.infra`, `.chart`, `.chart-bars .col`, `.blocker`, `.next-row`
- **禁用**：全局 `.card`（用自定义 `.kpi`）、全局 `.kpi-card`（有自己的）、暗色主题、gradient-text（用纯色 accent）、过度装饰（L1 only）、非 grid 的 KPI 布局、非语义化 tag 颜色
- **稀疏空间策略**：内容丰富 — 内容少时补充子信息（负责人、日期、状态、关联指标），考虑布局降格（3 列→2 列），底部加 KPI 汇总行

---

## tech-sharing

- **空间密度**：中低密度 — body padding: 72px 96px, gap: 24px，暗色背景促进开阔感
- **装饰等级分布**：L3 body 级（::before 双 radial blob 右上+左下），L2 terminal 卡片（阴影+边框），L1 内容（card-accent 绿色顶部色条）。全暗色 #0d1117 + 双 radial ambient
- **组件偏好**：优先 `.terminal`（代码块 + macOS 圆点）、`.card-accent`（3/3 context 卡、3/3 takeaways）、`.tag`（mono 行内技术标签）、`.agenda-row`（虚线底边编号行）、`.speaker`（头像+信息）、`.mono`（大量行内使用）、`.kicker`（::before "> " 前缀）。绿 accent 用于关键文字
- **排版基调**：h1: 78px/800wt, h2: 54px/700wt, kicker: 13px mono, terminal: 15px mono, body: 全 #fff/#e6edf3 暗色。语法高亮：kw=red, fn=purple, str=blue, cmt=gray, num=cyan
- **页面节奏**：Cover(hero+speaker) → Agenda(编号行) → Context(3 卡+tag) → Deep Dive 1(左 lede+右 terminal) → Deep Dive 2(分栏+scheduler) → Code(全 terminal) → Takeaways(3 卡+reading) → Q&A(emoji+tag)。内容为主，无呼吸页，统一暗色 terminal 美学
- **专属组件**：`.tpl-tech-sharing`, `.terminal`（含 `.bar`, `.dot`）、`.kw/.fn/.str/.cmt/.num`（语法色）、`.tag`, `.agenda-row`, `.speaker`, `body::before` ambient radial
- **禁用**：浅色背景、全局 `.kpi-card`/`.card-soft`、白色文字浅色、亮渐变、非 mono kicker、卡片阴影（card class 设 box-shadow:none）
- **稀疏空间策略**：内容丰富 — 补充子信息、布局降格、底部加辅助信息行

---

## product-launch

- **空间密度**：低密度 — body padding: 80px 112px, feature-card padding: 40px 36px，高端感
- **装饰等级分布**：L3 封面（`.hero-shot` absolute 定位 640px 模糊渐变 orb + 产品 mockup），L2 pricing（`.pro` 卡深色 bg + 彩色阴影），L1 内容（`.feature-card` + 渐变 icon 方块）。不用 ambient-glow 或 grid-texture
- **组件偏好**：优先 `.feature-card`（自定义 + `.icon` 渐变方块）、`.hero-shot`（封面）、`.step`（编号步骤水平排列）、`.price-card`（分层定价 + `.pro`）、`.cta-btn`（pill 形渐变 CTA 按钮）、`.testimonial`（衬线 44px 引用）、`.brand`（logo 文字）。暖橙色/桃色渐变（#ff5a36）
- **排版基调**：h1: 96px/900wt（封面）, h2: 64px/800wt, h4: 16px caps, price amount: 64px/900wt, testimonial: 44px serif, body: Inter sans。极致大号 hero 字号
- **页面节奏**：Cover(hero-shot+h1) → Introducing(居中 140px h1) → Sound(3 feature-cards) → Fit(3 cards) → Intelligence(2 feature-cards) → How it works(3 steps) → Pricing(3 tiers + .pro 高亮) → Ship(testimonial+CTA 并排)。3 列 feature 展开与线性内容交替
- **专属组件**：`.tpl-product-launch`, `.hero-shot`, `.brand`, `.feature-card`（含 `.icon`）、`.step`（含 `.n`）、`.price-card`（含 `.pro`）、`.cta-btn`, `.testimonial`, `body.tpl-product-launch.dark` 模式
- **禁用**：Mono 字体（应用 Inter/Noto Sans SC）、全局 `.card`（用 `.feature-card` 或 `.price-card`）、蓝色 accent（只用暖橙）、正文衬线（仅 testimonial）、白底白字、小字号
- **稀疏空间策略**：视觉放大 — 组件放大、字号升级、gap 翻倍、装饰升级

---

## course-module

- **空间密度**：中密度 — body padding: 64px 80px, sidebar 260px + main gap 56px，sidebar 固定宽度
- **装饰等级分布**：全 L1 — 无 L2/L3 装饰。sidebar border-right 提供视觉结构。`.concept-box` 卡片微阴影。`.callout` 琥珀色左边框。`.exercise` 虚线边框琥珀色。最克制的模板
- **组件偏好**：优先 `.sidebar`（左 260px 固定 + brand + objectives 列表）、`.obj-list`（bullet + done/current 状态）、`.concept-box`（白卡微阴影）、`.callout`（左边框暖色告警）、`.exercise`（虚线琥珀框）、`.code`（暗色代码块绿/琥珀语法）、`.mcq`（多选题 + `.correct` 状态）、`.pill-academic`（矩形 pill，非圆形）。不用全局 `.card`——全自定义
- **排版基调**：h1: 72px serif（Playfair Display）, h2: 48px serif, h4: 22px, lede: 20px, sidebar: 13px。Body 用 Inter。暖土色调（accent: #2d7d6e 绿, accent-2: #d88a3a 琥珀）
- **页面节奏**：Cover(无 sidebar，全宽) → Objectives(sidebar+4 concept-boxes) → Concept(sidebar+callout+2×2 grid) → Example(sidebar+code+callout) → Exercise(sidebar+exercise box) → Check(sidebar+3 mcq cards) → Summary(无 sidebar，全宽 grid)。Sidebar 跟踪模块进度，除封面/总结外每页都有
- **专属组件**：`.tpl-course-module`, `.sidebar`, `.brand`（::before star）、`.obj-list`（done/current 伪状态）、`.main`, `.concept-box`, `.callout`, `.exercise`, `.code .cmt/.kw/.str`, `.mcq`（含 `.letter`, `.correct`）、`.pill-academic`, `body.tpl-course-module.full`（无 sidebar 页）
- **禁用**：全局 `.card`（用 `.concept-box` 或 `.exercise`）、全局 `.kicker`（用模板专用琥珀 kicker）、圆形 pill（用 `.pill-academic` 矩形）、ambient-glow、grid-texture、L2/L3 装饰、暗色主题、非衬线标题
- **稀疏空间策略**：内容丰富 — 补充子信息、布局降格、底部加辅助信息行

---

## xhs-pastel-card

- **空间密度**：极低密度 — body padding: 76px 90px, xp-card padding: 30px 34px, gap: 20px。大而通透，马卡龙色块
- **装饰等级分布**：L3 全页（`.xp-blob` 每页 3-4 个浮动渐变 orb），封面/结束页: 3 blobs + 大号排版。章节分隔: 2 blobs + 120px h1。Quote: hero-card 带阴影。不用 L1 渐变条——视觉深度来自 blobs 和纯色马卡龙卡片
- **组件偏好**：优先 `.xp-blob`（absolute 定位彩色 radial orb）、`.xp-chip`（pill + 彩色 dot ::before）、`.xp-topbar`（chip + 页码）、`.xp-kicker`（桃色）、`.xp-h1/.xp-h2`（Playfair Display 衬线）、`.xp-card.peach/.mint/.sky/.lilac/.lemon/.rose`（纯色马卡龙背景）、`.xp-hero-card`（白色 + 重阴影）、`.xp-quote`（衬线 italic + 巨型 " 引号 pseudo）、`.xp-codebox`（暗色代码块）、`.xp-divider`（渐变水平条）、`.xp-footer`（底部条）。全自定义——零全局组件
- **排版基调**：h1: 96px/900wt serif（Playfair Display）, h2: 60px/800wt serif, sub: 21px Inter, quote: 40px serif italic, code: 14px mono。锚点 accent: 桃色（#f48b5c）
- **页面节奏**：Cover(3 blobs + 超大 h1) → Section(章节分隔，120px h1) → Content(2×2 纯色卡) → Quote(hero-card + 引用) → Code Prompt(暗色代码框) → Chart(SVG donut + mini cards) → CTA(3 彩色活动卡) → Thanks(160px 居中文字)。大面积纯色矩形构成节奏感
- **专属组件**：`.tpl-xhs-pastel-card`, `.xp-blob`（`.b1/.b2/.b3`）、`.xp-chip`（`.mint/.sky/.lilac/.rose`）、`.xp-topbar`, `.xp-page`, `.xp-kicker`, `.xp-h1/.xp-h2`（含 `.em`, `.rose`, `.mint`）、`.xp-sub`, `.xp-card`（`.peach/.mint/.sky/.lilac/.lemon/.rose`）、`.xp-hero-card`, `.xp-quote`, `.xp-footer`, `.xp-divider`, `.xp-codebox`, `.xp-grid-2/.xp-grid-3/.xp-grid-4`
- **禁用**：全局 `.card`/`.kicker`/`.h1`（全部用 xp- 前缀替代）、暗色主题、mono 字体（仅代码框）、锐利边框（全圆角 28px+）、中性背景（必须用马卡龙填色）、白色卡片无色、轻阴影、L1 装饰系统（用 blobs 替代）
- **稀疏空间策略**：留白保留 — 填充率 < 60% 是预期行为，不做任何填充。可选字号微调。禁止加装饰、紧凑排版、加卡片

---

## xhs-white-editorial

- **空间密度**：中低密度 — body padding: 72px 88px, grid gap: 18px/16px，整洁白色空间
- **装饰等级分布**：L2 全页（`.xw-topline` 顶部 5px 彩虹渐变条），封面/结束页: 章节分隔 110px 标题。无 ambient glow——gradient text 替代。装饰极简但高影响：xw-topline 是唯一持久装饰元素
- **组件偏好**：`.xw-topline`（彩虹渐变条）、`.xw-topbar`（tag + 页码）、`.xw-tag`（大 pill + 彩虹 dot）、`.xw-page`, `.xw-kicker`, `.xw-title/.xw-title-md`（极暗 850+ weight）、`.xw-grad`（彩虹渐变文字）、`.xw-focus/.xw-focus-blue/.xw-focus-pink/.xw-focus-orange/.xw-focus-green`（彩色高亮 pill）、`.xw-hero`（hero card 渐变 bg + 阴影）、`.xw-card`（`.soft-purple/.soft-pink/.soft-blue/.soft-green/.soft-orange`）、`.xw-grid-2/.xw-grid-3`, `.xw-steps/.xw-step/.xw-num/.xw-txt`, `.xw-codebox`, `.xw-footer`, `.xw-pill`, `.xw-big-stat`
- **排版基调**：title: 84px/850wt, title-md: 60px/800wt, sub: 24px, quote: 38px/800wt, card main: 28px/850wt, big-stat: 96px/900wt。极粗字重，-2px/-4px 字间距
- **页面节奏**：Cover(topline + hero quote) → Section Divider(110px title) → Content(2×2 soft color cards) → Steps(4 编号步骤 + hero quote) → Code Example(code block) → Chart(SVG 水平条形) → CTA(3 cards + hero) → Thanks(96px stat + pills)。Section divider 在 cover 后做章节分隔
- **专属组件**：`.tpl-xhs-white-editorial`, `.xw-topline`, `.xw-topbar`, `.xw-tag`（含 `.dot`）、`.xw-page`, `.xw-kicker`, `.xw-title/.xw-title-md`, `.xw-grad`, `.xw-sub`, `.xw-focus` + color variants, `.xw-hero`, `.xw-quote`, `.xw-grid-2/.xw-grid-3`, `.xw-card` + soft color variants, `.xw-label`, `.xw-steps/.xw-step/.xw-num/.xw-txt`, `.xw-codebox`, `.xw-footer`, `.xw-pill`, `.xw-big-stat`
- **禁用**：全局组件（全用 xw- 前缀替代）、暗色背景、轻字重（全 850/900）、纯黑文字（用近黑 #111318）、mono 字体（代码框外）、小字号（最小 16px body）、怯懦渐变（用全彩虹）、body 阴影（仅 xw-hero）
- **稀疏空间策略**：留白保留 — 不做填充，可选字号微调

---


## knowledge-arch-blueprint

- **空间密度**：中密度 — body padding: 64px 80px, kb-grid-2 gap: 20px, kb-pipeline gap: 14px
- **装饰等级分布**：L3 全页（`.kb-grid-bg` 48px grid overlay + radial mask fade），L2 pipeline steps（rust accent hero card），L1 无渐变条。装饰来自 grid-bg + 2px 粗黑边框
- **组件偏好**：`.kb-grid-bg`（网格 overlay）、`.kb-kicker`（rust 色，4px 字间距）、`.kb-h1`（66px/900wt）、`.kb-sub`, `.kb-insight`（rust bg 反色 pill）、`.kb-section-label`（::after 线）、`.kb-pipeline/.kb-step`（2px 黑边框卡，`.hero` 变体 rust bg）、`.kb-grid-2/.kb-card`（2px 边框白卡）、`.kb-legend`（彩色指示器）、`.kb-mono`, `.kb-codebox`（暗色代码 + 语法）、`.kb-big-num`（200px serif）、`.kb-footer`（top-border 底部条）
- **排版基调**：h1: 66px/900wt, h2: 52px/700wt, sub: 20px, step-title: 22px/900wt, big-num: 200px serif（Playfair Display）, code: 14px mono。Rust accent（#B5392A）
- **页面节奏**：Cover(grid-bg+pipeline+insight) → Section Divider(grid-bg+120px h1) → Content(2×2 compare cards+legend) → Code(manifest skill code) → Diagram(SVG 系统架构) → Stats(big-num+2 cards+2 compare) → CTA(pipeline steps) → Thanks(居中 140px h1)。除 thanks 外每页有 grid-bg。Pipeline 组件在 cover 和 CTA 复用
- **专属组件**：`.tpl-knowledge-arch-blueprint`, `.kb-grid-bg`, `.kb-kicker`, `.kb-h1/.kb-h2`, `.kb-sub`, `.kb-insight`, `.kb-section-label`, `.kb-pipeline`, `.kb-step`（`.hero`）、`.kb-grid-2`, `.kb-card`, `.kb-legend`, `.kb-mono`, `.kb-codebox`, `.kb-big-num`, `.kb-footer`
- **禁用**：全局组件（全用 kb- 前缀替代）、圆角（用 2px solid black 直角矩形）、轻阴影、gradient-text（用纯色 rust）、card-accent（用 2px 边框替代顶部 accent）、L1/L2 装饰系统（用 grid-bg 替代）
- **稀疏空间策略**：内容丰富 — 补充子信息、布局降格、底部加辅助信息行

---

## consultant-strategy

- **空间密度**：中高密度 — body padding: 90px 60px 80px, grid gap: 28px, cs-pipeline gap: 20px, cs-table cell padding: 14px 18px。信息密集但靠留白分层
- **装饰等级分布**：L1 全页（`.bar-top` 5px 蓝顶条 + `.bar-left` 8px 蓝竖条），L2 amber 强调卡（`.card-amber` 左 5px amber 边 + `.card-accent` 顶 4px 蓝边），L3 章节页（蓝全屏 + amber 分隔条）。无 ambient glow、无 gradient blob——装饰即细线 + 色块
- **封面 V6 装饰包（商务感，L3）**：封面允许 L3 装饰——`.bar-top` 顶条 + 4 角 `.cs-corner-deco.tl/.tr/.bl/.br`（硬边 L 型直角线 2px `var(--border-strong)`，非光球）+ 右上 `.cs-cover-logo`（logo 位）+ `.gradient-text` 标题 accent 词。封面 L3 = 商务感包示范（见 `style-presets.md` §封面装饰等级 V6）
- **组件偏好**：`.cs-pagehead`（kicker + h2）、`.cs-fact`（大数字卡 `.cs-num` 88px / `.cs-label` / `.cs-delta` 红绿）、`.cs-matrix` + `.cs-cell.hero`（2×2 战略矩阵）、`.cs-pipeline` + `.cs-step.hero`（4-step 管道，首步 amber）、`.cs-table` + `.col-hero`（硬边对比表，推荐列 amber 底）、`.cs-quarter` + `.cs-rag-dot` + `.cs-q-progress`（季度 RAG 复盘卡）、`.cs-risk`（风险/缓释红绿双栏）、`.cs-tree-node`（MECE 分解节点）、`.cs-cover-meta`（封面元数据）、`.pill`/`.pill-amber`/`.pill-accent`（状态标签）
- **排版基调**：h1: 78px/800wt, h2: 54px/700wt, h3: 38px/700wt, h4: 26px/700wt, lede: 27px, cs-num: 88px/800wt, cs-step-num: 15px mono。Arial/Helvetica 字体栈。McKinsey Blue（#005587）主色 + Amber（#f5a623）数据强调
- **页面节奏**：Cover(蓝竖条+渐变标题+元数据) → Agenda(6 章节双栏) → Exec Summary(amber 结论条+3 支柱卡) → Situation(4 数据卡) → Complication(3 痛点 amber 卡) → Question(MECE 树+SVG 连线) → Chapter Divider(蓝屏 110px h1) → Framework(2×2 矩阵+图例) → Recommendation(3 方案对比,B 推荐 amber) → Data Deep Dive(大数字+mini bar+3 杠杆) → Comparison Table(6 维度硬边表) → Process Flow(3 波次时间轴) → Quarterly Review(4 RAG 季度卡) → Risks(3 风险双栏) → Next Steps(4-step 90 天管道) → Thanks(130px h1+4 联系人)。每内容页 `.bar-top` 顶条统一
- **专属组件**：`.tpl-consultant-strategy`, `.cs-pagehead`, `.cs-fact`/`.cs-num`/`.cs-label`/`.cs-delta`, `.cs-matrix`/`.cs-cell.hero`/`.cs-quadrant-*`/`.cs-axis-x`/`.cs-axis-y`, `.cs-pipeline`/`.cs-step`/`.cs-step.hero`, `.cs-table`/`.col-hero`, `.cs-quarter`/`.cs-rag-dot`/`.cs-q-progress`/`.cs-q-bar`/`.cs-q-pct`, `.cs-risk`/`.cs-risk-risk`/`.cs-risk-mit`, `.cs-tree-node`, `.cs-cover-meta`, `.bar-top`/`.bar-left`/`.card-amber`/`.card-accent`
- **禁用**：box-shadow（用 1.5px 硬边框替代）、大圆角（radius 4px 极小）、gradient-text 正文用（仅 cover 标题 accent 词可用）、ambient-glow/deco-circle/blob（咨询风无装饰光球）、emoji（用 pill 标签或色块替代）、margin-top:auto+absolute（禁止重叠，见 design-system 禁止模式）
- **稀疏空间策略**：内容丰富 — 补充证据脚注（`.dim2` 小字）、增列对比维度、底部加 insight/action 卡

---

## government-formal-red

- **空间密度**：中高密度 — body padding: 96px 60px 72px, grid gap: 28px, gov-resp-table cell: 12px 14px。庄重克制，靠红蓝色块与双线分层
- **装饰等级分布**：L1 全页（`.gov-redbar` 6px 红蓝双色渐变顶饰 + `.gov-redbar-bottom` 4px 底饰），L2 政策依据块/责任分工表（红竖条 + 双红线落款），L3 章节页（`.gov-chapter-bg` 深蓝全屏 + 半透明大号章号 + 金线）。红头文件版心语言——双色条 + 文号 + 印章
- **组件偏好**：`.gov-redbar`/`.gov-redbar-bottom`（双色顶底饰）、`.gov-doc-title`/`.gov-seal`（红头标题+印章）、`.gov-chapnum`（红色序号块）、`.gov-policy-cite`（政策依据·带文号）、`.gov-checklist`（三清单·问题/影响/整改）、`.gov-principle`（三化工作原则）、`.gov-goal-bar`（约束性+预期性目标）、`.gov-resp-table`（责任分工矩阵表5列）、`.gov-safeguard`（组织保障四宫格）、`.gov-fact`/`.gov-quarter`/`.gov-risk`（通用政务数据/复盘/风险）、`.gov-signband`/`.gov-channelbar`（署名带+服务渠道条）
- **排版基调**：h1: 92-108px/800wt, h2: 54px/700wt, gov-num: 84-96px/800wt, 雅黑栈优先（Microsoft YaHei）。政府红（#8B0000）+ 政府蓝（#003366）+ 金（#DAA520）三色体系
- **页面节奏**：Cover(红头版心+文号+印章) → 目录(红序号块) → 工作综述 → 政策依据与基本盘(政策引用块+4数据卡) → 主要成效(排名跃升+亮点) → 存在问题(三清单) → 章节切换(深蓝全屏) → 总体要求与目标(三化+目标条) → 重点任务分解 → 数据深潜 → 对标先进 → 实施路径(时间轴) → 阶段成效(RAG) → 风险防控 → 责任分工与组织保障 → 结束(居中表态+署名带+渠道条)。政务叙事=工作回顾→成效→问题→部署→保障（非SCQA）
- **专属组件**：`.tpl-government-formal-red`, `.gov-redbar`/`.gov-redbar-bottom`, `.gov-doc-title`/`.gov-seal`/`.gov-chapter-bg`/`.gov-chapnum`/`.gov-goldline`, `.gov-policy-cite`, `.gov-checklist`, `.gov-principle`/`.gov-goal-bar`, `.gov-resp-table`/`.gov-safeguard`, `.gov-fact`/`.gov-quarter`/`.gov-risk`, `.gov-signband`/`.gov-channelbar`/`.gov-pledge`
- **禁用**：box-shadow（用边框/色块分层）、MECE树/2×2矩阵/方案择优（咨询框架，政务不用）、人员卡片网格尾页（用署名带+渠道条）、gradient blob
- **稀疏空间策略**：政策依据块带文号+引文+要求三段；责任分工表5列（任务/牵头/配合/时限/考核）；三清单问题/影响/整改一一对应

---

## soe-engineering-blue

- **空间密度**：中密度宽间距 — 模块间距 40px, 卡片间距 20px, 内部留白 32px（4px 精密网格）。深色底需更大留白透气
- **装饰等级分布**：L1 全页（`.soe-grid-bg` 经纬网格底纹 opacity .05-.1 + 8px 深蓝顶条 + `.soe-corner-mark` 四角瞄准框），L2 科技卡片（`.soe-tech-card` glowing 边框），L3 章节页（stroke-only 巨型轮廓字章号）。现代精工 + 数字科技
- **封面 V6 装饰包（科技感，L3）**：封面允许 L3 装饰——`.soe-grid-bg` 经纬网格 + `.ambient-glow`（蓝 radial 光晕）+ `.soe-corner-mark`×4 四角瞄准框 + `.gradient-text` 标题 accent 词。封面 L3 = 科技感包示范（见 `style-presets.md` §封面装饰等级 V6）。soe 封面本就接近 L3，V6 补全 ambient-glow 光晕层
- **组件偏好**：`.soe-grid-bg`（经纬网格）、`.soe-corner-mark`（四角瞄准框）、`.soe-gantt`（甘特图·工序×月份·计划vs实际双色条）、`.soe-fourcontrol`（安全/质量/进度/投资四控制仪表盘+状态灯）、`.soe-tech-card`（科技卡 glowing）、`.soe-param-table`（工程技术参数表）、`.soe-milestone`（里程碑形象进度%）
- **排版基调**：h1: 60px/800wt 白字, h2: 36px/700wt 电建蓝, 巨型装饰数字 120px/opacity 5%。深海蓝底（#001F45）+ 电建蓝（#00418D）+ 光辉金（#FFD700）+ 中国红点睛
- **页面节奏**：Cover(基石概念·深蓝网格+工程剪影+参建三联+参数角标) → 目录(工程里程碑) → 项目综述 → 项目概况(参数角标) → 建设挑战 → 技术主线 → 章节切换(轮廓字) → 技术方案路线图 → 关键技术(科技卡) → 工程数据深潜 → 对标同类 → 施工进度甘特图 → 四控制阶段进展 → 风险管控 → 下一步(投产/验收/移交) → 结束(工程全景+致谢建设者)。工程叙事=概况→方案→进度→质量安全→效益
- **专属组件**：`.tpl-soe-engineering-blue`, `.soe-grid-bg`/`.soe-corner-mark`, `.soe-gantt`, `.soe-fourcontrol`, `.soe-tech-card`/`.soe-param-table`/`.soe-milestone`
- **禁用**：浅灰卡片硬套深底（用 rgba(255,255,255,.06) 玻璃感）、通用时间轴（用甘特图）、RAG季度卡（用四控制仪表盘）、2×2矩阵（用技术路线图）
- **稀疏空间策略**：深色底透气；甘特图工序条+里程碑节点；四控制每格状态灯+关键指标

---

## bank-vip-gold

- **空间密度**：中低密度留白 — 模块间距 40px, 卡片间距 24px, 内部留白 20px（4px 网格）。极简轻奢，开放空间
- **装饰等级分布**：L1 全页（红条 + `.bank-doubleline` 精致双线 1px+3px 印刷感 + 四角淡金定位点），L2 卡片（`.bank-shelf` 货架 + 浅红/暖灰底），L3 章节页（全屏深红 #9A0E26 + 金色阶梯 + 半透明大号章号）。多层圆环 + 菱形分割
- **组件偏好**：`.bank-doubleline`（精致双线）、`.bank-rings`（多层同心圆·向日葵）、`.bank-diamond`（菱形分割）、`.bank-kyc`（客户画像多维标签）、`.bank-alloc`（资产配置环形图 conic-gradient）、`.bank-nav-curve`（净值曲线 SVG）、`.bank-shelf`（产品货架）、`.bank-risk-matrix`（风险评级矩阵）
- **排版基调**：h1: 52px/800wt, h3(章节): 52px/800wt, 章节背景字 320px/低透明度。招行红（#C41230）+ 辅助金（#C9A962）+ 深红（#9A0E26）+ 暖灰装饰
- **页面节奏**：Cover(精致轻奢·红条金双线+多层圆环+菱形+顾问卡) → 目录(清单式金下划线) → 客户全景 → 客户画像与资产现状(KYC+配置环形图) → 市场挑战 → 配置主线 → 章节切换(深红+金阶梯) → 资产配置框架(核心-卫星) → 产品推荐货架 → 业绩深潜(净值曲线) → 产品对比 → 投资路径/定投 → 季度业绩 → 风险合规 → 财富规划 → 结束(专属预约大卡+私行承诺+风险提示+圆环呼应)。金融叙事=全景→配置→市场→产品→规划
- **专属组件**：`.tpl-bank-vip-gold`, `.bank-doubleline`/`.bank-rings`/`.bank-diamond`, `.bank-kyc`/`.bank-alloc`, `.bank-nav-curve`, `.bank-shelf`/`.bank-risk-matrix`
- **禁用**：人员卡片网格尾页（用专属预约大卡）、2×2矩阵（用核心-卫星配置图）、方案卡网格（用产品货架）、通用stat卡（用KYC+配置环形图）
- **稀疏空间策略**：轻奢留白；资产配置环形图+图例；产品货架分类层板；首尾圆环呼应闭环

---

## academic-defense

- **空间密度**：中密度 — 卡片间距 20px, 内容块 24px, 卡片内边距 20px, 圆角 8px。严谨清晰
- **装饰等级分布**：L1 全页（`.aca-header` 70px 深蓝页眉条 + 6px 红竖条），L2 观点条（浅蓝灰 #E8F4FC + 蓝竖条）+ 卡片（浅蓝灰底 + 左彩色竖条），L3 章节页（深蓝 #003366 全屏 + 几何装饰 + 半透明大号编号 + 红装饰横线）。科研克制
- **组件偏好**：`.aca-header`（深蓝页眉条+红竖条）、`.aca-info`（答辩人信息块·姓名/学号/导师/机构/日期）、`.aca-litcard`（文献综述编号卡·[1]+作者年+观点+来源）、`.aca-cite`（上标引用标记）、`.aca-formula`（公式块·居中mono+编号）、`.aca-baseline`（baseline vs ours对比）、`.aca-roadmap`（研究路线图）
- **排版基调**：h1: 56px/800wt, h2: 28px/700wt, h3(章节): 56px/800wt, high数据: 36px/800wt。主导深蓝（#003366）+ 辅助蓝（#0066CC）+ 强调红（#CC0000）+ 浅蓝灰底
- **页面节奏**：Cover(答辩严谨·深蓝页眉条+红竖条+答辩人/导师/学号/校徽) → 目录(卡片双列) → 研究综述(贡献+创新点) → 选题背景 → 文献综述(编号卡) → 研究问题 → 章节切换(深蓝全屏) → 技术路线图 → 研究方法 → 实验结果(公式+baseline) → 方法对比表(baseline vs ours) → 研究路线 → 研究进度 → 局限与未来 → 后续计划 → 结束(致谢正文·导师/课题组/基金号+论文链接+Q&A)。学术叙事=选题→文献→方法→实验→结论
- **专属组件**：`.tpl-academic-defense`, `.aca-header`, `.aca-info`, `.aca-litcard`/`.aca-cite`, `.aca-formula`, `.aca-baseline`, `.aca-roadmap`
- **禁用**：人员卡片网格尾页（用致谢正文段）、2×2矩阵（用技术路线图）、通用问题卡（用文献综述卡）、通用数据卡（用实验结果+公式块）；公式暂用 .mono 占位，不引入 KaTeX 重依赖
- **稀疏空间策略**：文献综述编号引用；公式块居中+编号；baseline对比红高亮本文方法

---

## insight-report

- **空间密度**：中高密度 — 信息密集但靠留白与分隔分层，模块间距 28-32px。可打印导向，避免满铺深底
- **装饰等级分布**：L1 全页（细顶饰条 + 页脚来源标注），L2 BLUF 执行摘要框 + 发现卡（编号①②③ + 边框分层），L3 章节分隔。克制——无 ambient glow，装饰即细线 + 编号
- **组件偏好**：`.exec-summary`（BLUF：一句话结论 + 支撑要点 + 关键数字）、`.finding-card`（编号发现 + 证据 + 启示）、`.ir-method-grid`/`.ir-method-item`（研究方法网格）、`.research-chart`（图表带 Fig.编号 + 来源）、`.appendix-block`（附录·小字可打印）、`.ir-keynums`、`.ir-colophon`（版权页）
- **排版基调**：h1 60-72px/800wt, h2 36px/700wt, 正文 18px, 数据 36px/800wt。克制深墨蓝（#0A2540）主色，白底高对比，可打印
- **页面节奏**：Cover(报告标题+机构+编号) → 执行摘要(BLUF) → 背景 → 方法论 → 发现×3 → 数据深潜 → 对比 → 影响 → 建议 → 下一步 → 附录。叙事=BLUF 结论先行（非 SCQA）
- **专属组件**：`.tpl-insight-report`, `.exec-summary`, `.finding-card`, `.ir-method-grid`/`.ir-method-item`, `.research-chart`, `.appendix-block`, `.ir-keynums`, `.ir-colophon`
- **禁用**：深色满铺背景（破坏可打印）、SCQA 咨询骨架、人员卡片网格尾页
- **稀疏空间策略**：BLUF 框承载结论先行；方法论网格透明化研究过程；附录块承载可打印细节

---

## biz-review

- **空间密度**：中高密度 — 大容量数据导向，KPI 墙密集，靠色块与归因条分层
- **装饰等级分布**：L1 全页（顶饰条 + 页脚），L2 KPI 总览墙 + 归因条（多段色 + 图例），L3 资源审批块（高亮待批项）。商务稳重
- **组件偏好**：`.kpi-wall`（6-8 KPI 网格：当期/环比/同比/达标）、`.br-attrib`/`.br-attrib-bar`/`.br-attrib-seg`/`.br-attrib-legend`（KPI 归因条）、`.br-chart-card`/`.br-chart-head`（图表卡）、`.br-callout`（成果高亮）、`.br-approval`/`.br-approval-col`/`.br-approval-item`（资源审批块）
- **排版基调**：h1 56-64px/800wt, h2 36px/700wt, KPI 数字 40-56px/800wt tnum。商务深蓝，专业稳重
- **页面节奏**：Cover(周期+业务线+汇报对象) → 周期回顾 → 核心成果 → KPI 总览墙 → 亮点展开 → 差距分析 → 挑战风险 → 下阶段计划 → 资源审批 → 结束(决议)。叙事=直线递进（回顾→规划→要资源）
- **专属组件**：`.tpl-biz-review`, `.kpi-wall`, `.br-attrib`/`.br-attrib-bar`/`.br-attrib-seg`/`.br-attrib-legend`, `.br-chart-card`, `.br-callout`, `.br-approval`/`.br-approval-col`/`.br-approval-item`
- **禁用**：weekly-report 的细粒度 ship-item/blockers（那是团队同步粒度，这是高管级）、SCQA、人员卡片网格尾页
- **稀疏空间策略**：KPI 墙汇总核心指标；归因条展示目标→实际→根因；资源审批块承载向高管要资源

---

## compare-eval

- **空间密度**：中密度 — 矩阵为主，靠评分单元格与权重列分层
- **装饰等级分布**：L1 全页（顶饰条 + 页脚），L2 评测矩阵（评分单元格 + 勾✓叉✗ + 权重列高亮），L3 裁决卡（推荐结论）。客观克制不偏袒
- **组件偏好**：`.ce-cand-grid`/`.ce-cand-col`/`.ce-cand-head`/`.ce-cand-list`/`.ce-cand-logo`（参评方档案）、`.ce-cand-fit`/`.ce-cand-tagrow`（适配度/标签）、`.ce-dd-bar-row`/`.ce-dd-bar-fill`（维度深挖进度条）、评测矩阵（评分单元格 + 勾叉 + 权重）、裁决卡
- **排版基调**：h1 52-60px/800wt, h2 32px/700wt, 评分数字 32-40px/800wt tnum。中性墨蓝（#1E3A5F），客观
- **页面节奏**：Cover(评测对象+评测方+日期) → 评测维度说明 → 参评方档案×N → 对比矩阵 → 维度深挖 → 优劣对照 → 综合裁决 → 推荐结论 → 附录。叙事=对比评测（维度→矩阵→裁决）
- **专属组件**：`.tpl-compare-eval`, `.ce-cand-grid`/`.ce-cand-col`/`.ce-cand-head`/`.ce-cand-list`/`.ce-cand-logo`/`.ce-cand-fit`/`.ce-cand-tagrow`, `.ce-dd-bar-row`/`.ce-dd-bar-fill`, 评测矩阵
- **禁用**：hermes 的 CRT 扫描线/终端主题（CLI 绑死）、纯文字对比表（评测需评分单元格）、人员卡片网格尾页
- **稀疏空间策略**：矩阵承载多维评分；维度深挖聚焦关键差异；裁决卡给明确推荐

---

## keynote-formal

- **空间密度**：低密度大留白 — 叙事演讲靠留白与大字制造分量，每页一个节拍
- **装饰等级分布**：L1 极简（细饰条 + 节拍编号），L2 叙事节拍页（大字金句 + 一张图 + 大量留白），L3 信念宣言/大引语（极大字情感高潮）。庄重克制
- **组件偏好**：`.slide-body`（叙事节拍页容器）、`.accent-text`（金句强调）、`.counter`/`.slide-number`（节拍编号）、`.notes`（逐字稿·观众不可见）、`.tpl-keynote-beat-text`/`.tpl-keynote-beat-figure`（节拍图文）、`.tpl-keystone-grid`（拱心石布局）。信念宣言/大引语/行动号召是 slide 角色页（由 `.slide-body`+`.accent-text`+大字实现，非独立组件类）
- **排版基调**：h1 80-120px/800wt（信念页更大），大引语 72-96px，正文克制。庄重金（#D4AF37）+ 黑，单色有分量
- **页面节奏**：Cover(主题+演讲人+大会+日期) → 信念宣言(Why) → 挣扎故事 → 转折点 → 新的理解 → 大引语(高潮) → 叙事节拍×N → 行动号召 → 结束(金句回响)。叙事=黄金圈/英雄之旅（信念→故事→号召）
- **专属组件**：`.tpl-keynote-formal`, `.slide-body`, `.accent-text`, `.counter`/`.slide-number`, `.notes`, `.tpl-keynote-beat-text`/`.tpl-keynote-beat-figure`, `.tpl-keystone-grid`
- **禁用**：逐点列表（dir-key 的逐点递进，keynote 是叙事弧非清单）、演讲者工具壳（presenter 的 S键/逐字稿）、产品发布戏剧感、人员卡片网格尾页
- **稀疏空间策略**：每页一个叙事节拍；大字金句 + 留白制造分量；信念→故事→号召的情感曲线

---

## dir-key-nav-minimal

- **空间密度**：中密度 — padding: 80px 104px，但因极简主义视觉稀疏，文字为主
- **装饰等级分布**：L3 全页通过背景颜色（`.dk-accent` 跟随背景色），8 种不同 bg 颜色（indigo/cream/crimson/emerald/slate/violet/white/charcoal），L2 水平分隔线。无 ambient glow、无 grid-texture、无渐变条——装饰即背景颜色本身
- **组件偏好**：`.dk-snum`（右上 mono 页码）、`.dk-eyebrow`（::after 线）、`.dk-h0/.dk-h1/.dk-h2`（100-160px 超大字）、`.dk-lede`（300wt 大字）、`.dk-big`（240px mono 数字）、`.dk-line`（4px 水平条）、`.dk-accent`（每 bg 色变体）、`.dk-list`（箭头 bullet mono 列表）、`.dk-grid-2/.dk-col`, `.dk-code`（mono 代码框）、`.dk-keyhint/.dk-page`（底部条）。零全局组件
- **排版基调**：h0: 160px/900wt, h1: 100px/900wt, h2: 72px/800wt, lede: 26px/300wt, list: 22px mono, big-num: 240px mono。极致极简——超大字重，轻字重正文
- **页面节奏**：Cover(indigo bg+160px h1) → Section(章节分隔，不同 bg) → Content(list slide) → Content(compare grid) → Code(code block) → Chart(big-num+SVG bar) → CTA(h1+code block) → Thanks(end)。每页切换背景色（8 页=8 色）。箭头列表、双栏 grid
- **专属组件**：`.tpl-dir-key-nav-minimal`, `.t-indigo/.t-cream/.t-crimson/.t-emerald/.t-slate/.t-violet/.t-white/.t-charcoal`（背景主题）、`.dk-snum`, `.dk-eyebrow`, `.dk-h0/.dk-h1/.dk-h2`, `.dk-lede`, `.dk-big`, `.dk-line`, `.dk-accent`（每主题颜色变体）、`.dk-list`, `.dk-grid-2/.dk-col`, `.dk-code`, `.dk-keyhint`, `.dk-page`
- **禁用**：全局组件（全用 dk- 前缀替代）、小字号（最小 22px/26px）、低对比度（文字与 bg 必须无歧义）、复杂装饰、卡片/边框模式、gradient-text、mono 字体标题、动画
- **稀疏空间策略**：视觉放大 — 字号升级、间距增大

---

## graphify-dark-graph

- **空间密度**：中低密度 — body padding: 64px 88px, gd-grid-3 gap: 16px, gd-grid-4 gap: 14px
- **装饰等级分布**：L3 全页（`.gd-ambient` + 3 个 `.gd-orb` 浮动模糊 radial orb + drift 动画），Cover 额外有 SVG 力导向图 bg opacity .38。L2 玻璃卡片（`.gd-glass` + backdrop-filter blur + saturate + 渐变上半部）。无 L1 渐变条
- **组件偏好**：`.gd-orb`（3 个模糊 radial orb 动画）、`.gd-snum`（右上）、`.gd-eyebrow`（caps muted）、`.gd-h1/.gd-h2`, `.gd-lede`（300wt 大字）、`.gd-rainbow`（animated HSV 彩虹渐变文字）、`.gd-grad`（暖色渐变文字）、`.gd-accent/.gd-green/.gd-blue/.gd-dim/.gd-mono`, `.gd-glass`（`.gd-glass-warm/.gd-glass-green/.gd-glass-blue`）、`.gd-grid-3/.gd-grid-4`, `.gd-tag`（muted pill）、`.gd-cmd`（terminal 绿色 glow 文字）、`.gd-big`（120px stat）、`.gd-codebox`（代码 + 语法色）。全自定义
- **排版基调**：h1: 74px/800wt（封面 88px）, h2: 52px/700wt, lede: 22px/300wt, cmd: 32px mono green glow, big: 120px/900wt, code: 14px mono
- **页面节奏**：Cover(SVG force graph+rainbow h1) → Section Divider(120px h1+gradient) → Content(4 glass cards+quote) → Code(config YAML+cmd) → Chart(comparison lanes+3 big-num stats) → Pipeline(4 step cards+arrows) → CTA(commands+tags) → Thanks(180px rainbow)。除 thanks 外每页有 ambient orbs
- **专属组件**：`.tpl-graphify-dark-graph`, `.gd-ambient`, `.gd-orb`（`.gd-orb-1/-2/-3`）、`.gd-snum`, `.gd-eyebrow`, `.gd-h1/.gd-h2`, `.gd-lede`, `.gd-rainbow`, `.gd-grad`, `.gd-accent/.gd-green/.gd-blue/.gd-dim/.gd-mono`, `.gd-glass` + color variants, `.gd-grid-3/.gd-grid-4`, `.gd-tag`, `.gd-cmd`, `.gd-big`, `.gd-codebox`, `@keyframes gdDrift`, `@keyframes gdRainbow`
- **禁用**：全局组件（全用 gd- 前缀替代）、浅色主题、card/card-accent（用 gd-glass）、白色背景、mono 正文（用 Inter/Noto Sans）、轻文字阴影（用 glow 明确声明）、无动画背景
- **稀疏空间策略**：视觉放大 — 组件放大、字号升级、装饰升级

---

## hermes-cyber-terminal

- **空间密度**：中密度 — body padding: 60px 84px, hc-grid-3 gap: 16px, hc-grid-2 gap: 20px
- **装饰等级分布**：L3 全页（`.hc-grid` + `.hc-scanlines` + `.hc-vignette` 每页都有），Cover 三者全有，内容页 hc-grid+scanlines，section 加 chrome。L2 卡片 ::before 绿色 glow 顶部线。无 ambient-glow 或渐变条——terminal 美学
- **组件偏好**：`.hc-grid`（56px 网格 overlay）、`.hc-scanlines`（重复 3px 扫描线 screen blend）、`.hc-vignette`（radial 边缘变暗）、`.hc-chrome`（macOS 风格标题栏 + 圆点）、`.hc-prompt`（绿色 `$ ` 提示符）、`.hc-h1`（绿色 glow mono 72px + text-shadow）、`.hc-h2`（46px）、`.hc-lede`（Inter sans body 18px）、`.hc-cursor`（blinking block）、`.hc-card`（::before 绿色 glow 顶部线）、`.hc-grid-3/.hc-grid-2`, `.hc-tag`（`.amber/.red`）、`.hc-codebox`（暗色 + 语法色 + inset glow box-shadow）、`.hc-big`（140px green glow mono）、`.hc-footer`（top-border 底部条）
- **排版基调**：h1: 72px mono green glow + text-shadow, h2: 46px mono, h3: 22px amber mono, lede: 18px Inter sans, card value: 22px mono green, big-stat: 140px mono green glow。全 mono 字体系列包括标题。锚点：绿色 glow
- **页面节奏**：Cover(chrome+prompt+h1+tags) → Section Divider(chrome+prompt+110px code-comment h1) → Content(chrome+3 stats cards+2 verdict cards) → Code(chrome+prompt h3+trace code block) → Chart(bar chart SVG+hermes vs openclaw) → Stats(big-num score+pros/cons grid) → CTA(chrome+install commands code block) → Thanks(chrome+prompt exit 0+h1+cursor)。每页有 chrome+grid+scanlines
- **专属组件**：`.tpl-hermes-cyber-terminal`, `.hc-scanlines`, `.hc-grid`, `.hc-vignette`, `.hc-chrome` + dots, `.hc-prompt`, `.hc-h1/.hc-h2/.hc-h3`, `.hc-lede`, `.hc-cursor`, `@keyframes hcBlink`, `.hc-card`（::before glow）、`.hc-grid-3/.hc-grid-2`, `.hc-codebox`（syntax: `.cm/.kw/.st/.fn/.var/.hl`）、`.hc-tag`（`.amber/.red`）、`.hc-big`, `.hc-footer`
- **禁用**：全局组件（全用 hc- 前缀替代）、浅色主题、sans-serif 标题（全 mono）、圆角卡片无 glow、无 scanlines/grid 纯色背景、无阴影文字（绿色 glow 必需）、标准代码块（需要 inset box-shadow 绿色）
- **稀疏空间策略**：内容丰富 — 补充子信息、布局降格

---

## obsidian-claude-gradient

- **空间密度**：中密度 — body padding: 64px 88px, grid gap: 18px，居中排版 text-align: center 为主
- **装饰等级分布**：L3 全页（`.oc-cbg` 双 radial 紫色+蓝色 orb + `.oc-cgrid` 60px grid overlay + radial mask），L2 卡片 ::before 渐变顶部线紫色。Cover/end: 都有 cbg+cgrid。Section divider: cbg+cgrid。无 ambient-glow——紫色/蓝色宇宙背景
- **组件偏好**：`.oc-cbg`（双 radial orb）、`.oc-cgrid`（grid overlay）、`.oc-snum`（右上页码）、`.oc-tag`（紫色边框 pill）、`.oc-h1/.oc-h2`（80px/44px 居中）、`.oc-sub`（居中 dim）、`.oc-g`（紫-蓝-绿渐变文字）、`.oc-card`（::before 紫色渐变顶部线）、`.oc-grid-2/.oc-grid-3`, `.oc-badge`（`.oc-bp/.oc-bb/.oc-bg/.oc-bo`）、`.oc-code`（暗色代码 + 语法色）、`.oc-hl`（高亮框 + 紫色左边框）、`.oc-steps/.oc-step/.oc-sn/.oc-sc`, `.oc-pill`, `.oc-quote`（" 引号 pseudo）、`.oc-big`（140px 居中）。全自定义，居中排版
- **排版基调**：h1: 72px/800wt（section 110px）, h2: 44px/700wt, sub: 19px, card h4: 17-20px, quote: 26px, big-stat: 140px/900wt。紫色渐变 accent（#a855f7 → #60a5fa → #34d399）
- **页面节奏**：Cover(cbg+cgrid+tag+h1+pills) → Section(cbg+cgrid+big h1) → Content(oc-card compare 2×2+hl highlighted box) → Steps(4 oc-steps vertical) → Code(MCP config JSON) → Stats(3 big-num cards+hl box) → Quote CTA(blockquote+pills) → Thanks(140px big text)。Section divider 在 slide 2。统一居中排版
- **专属组件**：`.tpl-obsidian-claude-gradient`, `.oc-cbg`, `.oc-cgrid`, `.oc-snum`, `.oc-tag`, `.oc-h1/.oc-h2`, `.oc-sub`, `.oc-g`（渐变文字）、`.oc-card`（::before）、`.oc-grid-2/.oc-grid-3`, `.oc-badge` + color variants, `.oc-code`（syntax: `.cp/.cc/.ca/.cm/.cs`）、`.oc-hl`, `.oc-steps/.oc-step/.oc-sn/.oc-sc`, `.oc-pill`, `.oc-quote`, `.oc-big`
- **禁用**：全局组件（全用 oc- 前缀替代）、浅色主题、无边框卡片（需要 ::before 渐变线）、mono 正文（用 Inter/Noto Sans）、白色背景、L1 渐变条（用 cbg/cgrid 替代）、左对齐（当居中更合适时）
- **稀疏空间策略**：内容丰富 — 补充子信息、布局降格

---

## presenter-mode-reveal

- **空间密度**：中密度 — body padding: 72px 96px, grid gap: 20px，标准演示
- **装饰等级分布**：全 L1 — 极简装饰。无 L2/L3 模板级装饰。card-accent 提供 L1 顶部色条。code-block 提供暗色框。此模板有意平淡以不干扰演讲者模式功能
- **组件偏好**：`.kicker`（mono，模板级）、`.h1/.h2`（模板覆盖 clamp 尺寸）、`.lede`, `.mono`（行内代码 + bg）、`.accent`（粗体 accent 色工具类）、`.speaker`（头像+信息）、`.agenda-row`（编号行 + 边框）、`.card/.card-accent`（标准卡片 + 模板级覆盖）、`.feature-row`（编号 features + 彩色 num bullet）、`.rule-row`（编号规则 + 边框）、`.code-block`（暗色代码块 + 语法）、`.stack`, `.grid.g2/.g3`, `.mt-*`, `.tc`。最通用的模板——大量复用全局组件
- **排版基调**：h1: clamp(44px, 5.6vw, 76px), h2: clamp(32px, 3.6vw, 48px), lede: 20px, agenda row title: 17px, card h4: 18px, code: 15px。用 clamp() 做响应式
- **页面节奏**：Cover(kicker+h1+lede+speaker+notes) → Agenda(5 numbered rows+notes) → Problem(3 card-accent cards+notes) → Presenter View(feature-rows 4 items+notes) → Script(3 rule-rows+notes) → Demo Close(code-block+lede+notes)。每页含 `<aside class="notes">` 完整逐字稿。序列跟随 talk arc: cover → agenda → problem → solution features → core content → demo/conclusion
- **专属组件**：`.tpl-presenter-mode-reveal`（最小——仅 body padding 覆盖 + 排版缩放 + card/agenda/code 自定义样式）、`.kicker`（mono）、`.h1/.h2`（clamp）、`.lede`（20px）、`.mono`（行内代码 + bg）、`.accent`（粗体彩色工具）、`.speaker`（含 `.av`）、`.agenda-row`（grid + `.num/.t/.d`）、`.card/.card-accent`（覆盖）、`.feature-row`（flex + 彩色 `.num`）、`.rule-row`（grid + 粗体 `.num`）、`.code-block`（暗色 + `.comment/.cmd/.flag`）、`.blue/.green/.orange/.purple/.red`（数字颜色类）
- **禁用**：重装饰（有意极简）、模板专属组件类（此模板有意通用/展示）、暗色主题装饰、非 clamp 字号、无 `<aside class="notes">` 的页面（此模板存在即展示它）、ambient glow、grid texture、L2/L3 装饰
- **稀疏空间策略**：中等密度默认 — 间距微调（gap: 20→28px），可选字号微调一档

---

## testing-safety-alert

- **空间密度**：中密度 — body padding: 64px 84px, grid gap: 16-20px
- **装饰等级分布**：L3 全页（`.ts-stripe` 顶部危险斜条纹 bar + `.ts-stripe-b` 底部 6px stripe），L2 `.ts-alert-box`（红色渐变 bg + box-shadow + ::before 天花板 dot），L1 彩色顶部边框卡片（4px solid）。无 ambient glow、无 grid-texture——warning stripe 是核心装饰
- **组件偏好**：`.ts-stripe`（重复 45deg 红/黑 hazard stripes）、`.ts-alert-tag`（红/琥珀/绿 + icon ::before + box-shadow）、`.ts-page`（muted 页码）、`.ts-kicker`（红色 uppercase）、`.ts-h1`（含 `.red`, `.strike`）、`.ts-h2`（54px/900wt）、`.ts-sub`, `.ts-highlight-red/.ts-highlight-amber/.ts-highlight-green`（彩色行内高亮块）、`.ts-alert-box`（`.amber/.green`）+ ::before dot 指示器、`.ts-grid-2/.ts-grid-3`, `.ts-card`（含 `.lbl`, 4px border-top 彩色）、`.ts-checklist/.ts-check`（含 `.box`）、`.ts-codebox`（暗色 + 6px 红色左边框 + 语法）、`.ts-footer`（底部条）。每个元素通过颜色传达告警等级
- **排版基调**：h1: 88px/900wt（::after strikethrough 特效）, h2: 54px/900wt, sub: 22px, card h4: 26px/900wt, checklist: 18px/600wt, alert h3: 34px/900wt。RED 是元色（#e0314a）。全极端字重（900）
- **页面节奏**：Cover(stripe+alert-tag+h1 with strike+alert-box) → Section(stripe+amber tag+130px h1 with red) → Content Risk Levels(stripe+3 cards with L1/L2/L3 border-tops+amber alert-box) → Code(stripe+h2+red codebox with 6px left-border+forbidden commands highlighted red) → Chart(stripe+incident SVG bar chart) → Checklist(stripe+green tag+7 check items with red/green boxes) → CTA(stripe+green tag+3 cards+green alert-box) → Thanks(stripe+amber tag+140px h1)。每页红色警示美学，无平静页
- **专属组件**：`.tpl-testing-safety-alert`, `.ts-stripe/.ts-stripe-b`, `.ts-alert-tag`（`.amber/.green`）、`.ts-page`, `.ts-kicker`, `.ts-h1`（含 `.red`, `.strike`）、`.ts-h2`, `.ts-sub`, `.ts-highlight-red/.ts-highlight-amber/.ts-highlight-green`, `.ts-alert-box`（`.amber/.green`）、`.ts-grid-2/.ts-grid-3`, `.ts-card`（含 `.lbl`）、`.ts-checklist`, `.ts-check`（`.ok`，含 `.box/.txt`）、`.ts-codebox`（syntax: `.cm/.kw/.st/.bad`）、`.ts-footer`
- **禁用**：平静色（绿/蓝不配红色上下文）、轻字重（必须 900wt 标题）、无边框卡片（需要 4px 彩色顶部边框）、非告警代码块（需要红色左边框）、纯排版无颜色强调（红色高亮是强制性的）、ambient glow 或 grid texture（stripe 替代一切）、L1 装饰系统（ts-stripe 替代）
- **稀疏空间策略**：内容丰富 — 补充子信息、布局降格、底部加告警信息行

