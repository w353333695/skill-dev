// _html-model.mjs — Shared HTML tag/token model for the validator family.
//
// validate.mjs / batch-fix.mjs / validate-pptx.mjs all walk slide HTML with the
// same tokenizer primitives and the same notion of "what is a text-bearing tag".
// Defining these once here removes the three-way copy that silently drifted
// whenever one file added a whitelist class and the others didn't.
//
// NOTE: `tokenize()` and `isT1Page()` are intentionally NOT shared — they have
// real behavioral differences across files (batch-fix's tokenizer emits extra
// offsets for in-place rewriting; isT1Page's T1 detection regex differs).
// Reconciling those is a behavior change, not a refactor, so they stay local.

'use strict';

// Void / self-closing elements — never have children or textContent.
export const VOID_ELEMENTS = new Set([
  'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
  'link', 'meta', 'source', 'track', 'wbr',
]);

// Tags that legitimately own direct text content. When the tokenizer descends
// into one of these, bare text inside is expected (not a "div with loose text").
export const TEXT_CONTAINER_TAGS = new Set([
  'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'dd', 'dt',
  'blockquote', 'pre', 'td', 'th', 'figcaption', 'label', 'button',
  'summary', 'caption', 'address', 'header', 'footer', 'main',
  'nav', 'article', 'aside', 'section', 'span', 'a', 'strong',
  'em', 'b', 'i', 'u', 'code', 'small', 'mark', 'sub', 'sup',
]);

// Tags whose inner text is not slide content (scripts, styles, etc.) — skipped
// during the text-bearing walk.
export const IGNORED_TAGS = new Set(['script', 'style', 'textarea', 'title', 'noscript']);

// Template-native classes that legitimately contain bare text (div.textContent).
// These are part of template skeleton designs — subagents cannot change element
// tags, so the validator/fixer must not flag text inside them as "bare div text".
//
// Only validate.mjs and batch-fix.mjs consult this set. validate-pptx.mjs runs a
// stricter PPTX pre-check with no whitelist exemption, so it does NOT import it.
export const DIV_TEXT_WHITELIST_CLASSES = new Set([
  'n', 'l',             // pitch-deck .metric .n / .l
  'tl-title', 'tl-meta', 'tl-desc',  // T2 custom timeline
  'arch-box', 'sub',    // T2 custom architecture
  'q-label',            // matrix-2x2 quadrant label
]);

// Extract the lowercase tag name from a raw tag slice `str[start..end]`,
// stopping at the first whitespace, '/', or '>'.
export function extractTagName(str, start, end) {
  for (let i = start; i < end; i++) {
    const ch = str[i];
    if (ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r' || ch === '/' || ch === '>') {
      return str.slice(start, i).toLowerCase();
    }
  }
  return str.slice(start, end).toLowerCase();
}

// Tokenize raw HTML into a flat token stream for structural walks
// (div-bare-text detection, in-place rewriting, PPTX pre-checks).
//
// Token shapes:
//   { type: 'TAG_OPEN'|'TAG_SELF_CLOSE', tagName, offset, tagEnd }  // tagEnd = index after '>'
//   { type: 'TAG_CLOSE', tagName, offset }
//   { type: 'TEXT', text, offset, end }                              // end = index of next '<'
//
// `tagEnd` (on tags) and `end` (on text) are always emitted even though only
// batch-fix.mjs reads them — it does in-place rewriting via html.slice(offset,
// tagEnd). validate.mjs / validate-pptx.mjs ignore the extra fields. Emitting
// them unconditionally keeps the three consumers on one tokenizer with no drift
// (the previous split caused subtle offset bugs when one file's tokenizer
// diverged). extractTagName + the VOID/CONTAINER/IGNORED sets above are used by
// the walkers that consume this stream.
export function tokenize(html) {
  const tokens = [];
  let i = 0;
  while (i < html.length) {
    if (html[i] === '<') {
      // Comment
      if (html.startsWith('<!--', i)) {
        const end = html.indexOf('-->', i + 4);
        i = end >= 0 ? end + 3 : html.length;
        continue;
      }
      // Closing tag
      if (html[i + 1] === '/') {
        const end = html.indexOf('>', i);
        if (end < 0) break;
        tokens.push({ type: 'TAG_CLOSE', tagName: extractTagName(html, i + 2, end), offset: i });
        i = end + 1;
        continue;
      }
      // DOCTYPE / declaration
      if (html[i + 1] === '!' || html[i + 1] === '?') {
        const end = html.indexOf('>', i);
        i = end >= 0 ? end + 1 : html.length;
        continue;
      }
      // Opening or self-closing tag
      const end = html.indexOf('>', i);
      if (end < 0) break;
      const tagContent = html.slice(i + 1, end);
      const selfClosing = tagContent.endsWith('/') || html[end - 1] === '/';
      tokens.push({ type: selfClosing ? 'TAG_SELF_CLOSE' : 'TAG_OPEN', tagName: extractTagName(tagContent, 0, tagContent.length), offset: i, tagEnd: end + 1 });
      i = end + 1;
    } else {
      // Text node
      const end = html.indexOf('<', i);
      const text = end >= 0 ? html.slice(i, end) : html.slice(i);
      if (text.length > 0) tokens.push({ type: 'TEXT', text, offset: i, end: end >= 0 ? end : html.length });
      i = end >= 0 ? end : html.length;
    }
  }
  return tokens;
}

// Detect a T1 (template-native skeleton) page. A page is T1 if it carries
// either the explicit `data-skeleton="t1"` marker OR the newer
// `<body class="tpl-<deck>">` convention.
//
// Both signals must be recognized: the B-end/horizontal decks
// (consultant-strategy, academic-defense, bank-vip-gold, soe-engineering-blue,
// ...) use `tpl-` body classes exclusively and have NO data-skeleton attribute.
// If only data-skeleton is recognized, validate.mjs's `t1-unreplaced` /
// `t1-structure` checks hit `if (!isT1Page(html)) continue` and silently skip
// every one of those pages (false PASS on empty data-replace slots), while the
// PPTX pre-check fails to exempt their template-native SVG/bare text. Keeping
// this shared kills the drift that caused exactly that bug.
//
// validate-pptx.mjs intentionally does NOT import this — its C2 div-bare-text
// pre-check runs with no T1 exemption by design.
export function isT1Page(html) {
  return /data-skeleton\s*=\s*["']t1["']/.test(html)
    || /<body[^>]*class\s*=\s*["'][^"']*\btpl-[a-z0-9-]+/i.test(html);
}
