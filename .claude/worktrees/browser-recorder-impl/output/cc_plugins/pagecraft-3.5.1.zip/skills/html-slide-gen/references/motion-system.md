# 动效系统（Motion System）

> 本文件是 html-slide-gen **动效的唯一真相源**，Phase 4 生成 slide 时按此挂 `.anim-*` class。
> 设计思路见 `docs/motion-system-plan.md`。本文件只讲规则。
>
> **核心原则**：纯 CSS class 驱动，不用 `data-anim` 属性（已弃用）。iframe 重载即重播，无需 JS。

---

## 1. 核心机制：为什么不用 JS

本架构是多文件 iframe：`index-runtime.js` 切页时执行 `frame.src = deck[idx].file`，**每次切页都重新加载该 slide 的 iframe**。CSS animation 在 document 解析时即开始计时，配合 `animation-fill-mode: both`，元素在 delay 窗口期保持 `from` 态（opacity:0），动画结束后保持 `to` 态。

**因果链**：切到第 N 页 → iframe 重建 → stylesheet 重新解析 → 该页 `.anim-*` 元素从 t0 重播 stagger。**回到已看过的页也会重播**（演示场景需要「每次切到都演一遍」）。

→ 不需要 IntersectionObserver、不需要 `.is-visible` toggle、不需要 JS recipe 引擎。**只挂 class 就够**。

> ⚠️ 单文件导出版（`export_single.mjs`）用 `display:none/block` 切换，动画只在首次加载播一次。演示建议用多页 iframe 版（`export/<name>-live/`）。

---

## 2. Token 体系

定义在 `templates/shared/tokens.css :root`（全 23 deck 共享）。`--dur-*`/`--ease-*` 不受 switch-theme 影响（换颜色不改动画速度）。

```css
/* 时长档位 */
--dur-instant: .07s;  --dur-fast-1: .15s;  --dur-fast-2: .25s;
--dur-mod-1:   .4s;   --dur-mod-2:   .55s;
--dur-slow-1:  .7s;   --dur-slow-2:  .9s;
/* 缓动曲线 */
--ease-prod:  cubic-bezier(.2,0,.38,.9);   /* productive: 短锐, UI/数据 */
--ease-expr:  cubic-bezier(0,0,.3,1);      /* expressive: 长软, 标题/装饰 */
--ease-entry: cubic-bezier(0,0,.2,1);      /* 入场专用 */
/* stagger 节拍 */
--stagger-step: 90ms;   /* 卡片/KPI/列表 */
--stagger-soft: 60ms;   /* 紧凑列表/标签 */
/* 向后兼容别名（RICH 系统原有引用）*/
--anim-dur: var(--dur-mod-1);
--anim-ease: var(--ease-prod);
```

两套现有工具类并存，**类名不冲突**：
- RICH 系统（6 模板）：`.anim-fade-up/.anim-rise-in/.anim-zoom-pop/.anim-blur-in/.anim-stagger-list`（引用 `var(--anim-dur)`）
- T2-OLD 系统（`shared/tokens.css` + course-module/dir-key）：`.anim-fade/.anim-up/.anim-scale` + `.anim-d1..d14`

---

## 3. 挂载契约

语法：`class="语义class anim-class delay-class"`

例：
```html
<h1 class="h1 anim-fade-up">封面标题</h1>
<p class="kicker anim-fade anim-d1">小标</p>
<div class="card anim-fade-up anim-d4">卡片3</div>
<ul class="anim-stagger-list">  <!-- 子项自动 nth-child stagger -->
```

**delay-class 选择规则**：
- **卡片网格 / KPI 网格 / 列表** → 优先用 `.anim-stagger-list` 容器方案（子项自动 stagger，少写代码）
- **跨容器分散元素 / 需不同动画的卡片** → 用 `.anim-d1..d14` 手写 delay（d1=0.1s, d2=0.2s ... d14=1.4s）

**强度规则**：动效强度 ∝ 注意力权重 × 视觉层级。
- 「舞台」元素（watermark / 图表 axis / footer）→ 永远只 `anim-fade`，绝不 rise/zoom
- 「主角」元素（h1 / KPI / CTA / 结尾大字）→ 重动效（rise/zoom/blur）
- 「论据」元素（卡片 / 列表 / 时间线）→ 中等动效 + stagger

---

## 4. 内容语义角色 → 动画 映射表

| 内容角色 | class 钩子 | 强档 | 轻档 | 时长 | 缓动 |
|---|---|---|---|---|---|
| eyebrow/kicker | `.eyebrow .kicker .num-tag` | `anim-fade` | `anim-fade` | fast-1 | prod |
| cover h1/hero | `.h1 .mega .dk-h0` | `anim-rise-in` | `anim-fade-up` | slow-1 | entry |
| section-num 水印 | `.section-num` | `anim-fade` | `anim-fade` | mod-2 | prod |
| lede/副标题 | `.lede .sub` | `anim-fade-up` | `anim-fade` | mod-1 | entry |
| 卡片网格 2-6 张 | `.card .card-hover` | `anim-fade-up` + 90ms | `anim-fade` + 60ms | mod-2 | prod |
| pill/标签组 | `.pill` | `anim-fade` + 60ms | `anim-fade` | fast-2 | prod |
| KPI/大数字 | `.metric .n .big-num .dk-big` | `anim-zoom-pop` | `anim-scale` | mod-2 | 弹性 |
| 定价推荐档 | `.card-accent` | `anim-rise-in`（两侧 `anim-fade-up`） | 同 | mod-2 | expr |
| 柱状图 bar | `.bar` | `growHeight`（从底长） | 同 | mod-2 + 80ms | expr |
| 时间线节点 | `.timeline li .dk-steps li` | `anim-fade-up` + 120ms | `anim-fade` + 90ms | mod-1 | prod |
| 团队头像 | `.avatar` | `anim-zoom-pop` + 100ms | `anim-fade` | mod-1 | 弹性 |
| 引语/quote | `blockquote .dk-quote` | `anim-blur-in` | `anim-fade-up` | slow-2 | expr |
| 宣言/manifesto | `.h1` 单句 | `anim-blur-in` | `anim-fade-up` | slow-2 | expr |
| CTA/ask-box | `.ask-box` | `anim-rise-in`（整块） | `anim-fade-up` | slow-1 | expr |
| CTA 内数字 | `.ask-box .metric .n` | `anim-zoom-pop` + delay | 同 | mod-2 | 弹性 |
| 结尾 thanks | `.mega`(thanks) | `anim-blur-in` | `anim-fade-up` | slow-2 | expr |
| footer/页码 | `.tech-footer .deck-footer` | `anim-fade`（最后，delay 800ms+） | 不加 | fast-2 | prod |
| 图表 axis/grid | chart 容器 | `anim-fade`（先于 bar） | 不加 | fast-1 | prod |
| 代码块 | `.kb-codebox dk-code` | `anim-fade`（整块） | 不加 | mod-1 | prod |
| typewriter（仅 hermes） | `.anim-typewriter` | 同 | — | 2.4s steps | — |

---

## 5. Stagger 配方（8 种 slide 类型时序）

`t0` = iframe 加载完成。所有配方（除 cover/CTA）≤1.5s 内播完。

### 5.1 封面 cover
```
brand-dot fade@0(150ms) → cover-blob fade@0(900ms)
h1 rise-in@150ms(700ms) → lede fade-up@650ms(400ms) → presenter fade@900ms(250ms)
```
总 1.15s。h1 延迟 150ms 让背景先就位。

### 5.2 章节分隔 divider
```
section-num 水印 fade@0 → num-tag fade@100ms → h2 fade-up@250ms → lede fade-up@600ms
```
水印永远只 fade（环境，不抢戏）。

### 5.3 内容列表 / 议程
```
kicker fade d1@100 → title up d2@200 → lede fade d3@300 → 列表 .anim-stagger-list（子项 450+90×N ms）
```
5 项 = 450/540/630/720/810ms。列表项幅度小（上移 20px）。

### 5.4 卡片网格
```
kicker fade d1@100 → title up d2@200 → lede fade d3@300 → 卡片N anim-fade-up anim-d(N+3)，400+90×(N-1) ms
```
3 张 = d4/d5/d6；6 张 = d4~d9，总 ~900ms。卡片幅度 = 标题 60%（上移 20px）。

### 5.5 KPI 数据墙
```
kicker fade d1 → title up d2 → metric.n anim-zoom-pop anim-d(N+2)，300+120×(N-1) ms → footnote fade d8@800ms
```
间隔 120ms（比卡片大）让数字独立砸。

### 5.6 图表页（柱状/条形/时间线）
```
kicker fade d1@100 → title up d2@200 → axis/grid fade d3@300 → bar growHeight anim-d(N+3)，400+80×(N-1) ms → footnote fade d10@1000ms
```
**axis 先于 bar**（300 vs 400）建坐标系。时间线节点同理：连线 fade@300 → 节点 fade-up@400 + 120ms stagger。

### 5.7 对比页 split
```
kicker fade d1 → title up d2 → lede fade d3@300 → 左列 anim-fade-left d4@400 → 右列 anim-fade-right d5@500
```
方向暗示对立，右晚 100ms（旧的先到，新的覆盖）。

### 5.8 CTA / 总结
```
num-tag fade d1@100 → ask-box rise-in d2@200(700ms) → 内部数字 zoom-pop 800+120×N ms
（独立 thanks 页：mega blur-in@0(900ms)）
```
框架先立、论据再砸。

---

## 6. 模板强度分级（23 个）

| # | 模板 | 档位 | 动作 |
|---|---|---|---|
| 1 | pitch-deck | 强 | 全套配方 |
| 2 | presenter-mode-reveal | 强 | 全套，封面已有 fade-up 保留 |
| 3 | product-launch | 强 | 全套，产品亮相多用 zoom-pop |
| 4 | tech-sharing | 强 | 全套，代码块保守 fade |
| 5 | weekly-report | 强 | KPI 墙 + bar 主力 |
| 6 | xhs-pastel-card | 强 | 全套但卡片柔，stagger 120ms、fade 幅度减半 |
| 7 | course-module | 中 | header 三件套 + 列表 stagger，不用 rise/zoom/blur |
| 8 | xhs-white-editorial | 中 | header 三件套 + 卡片/列表 stagger（编辑克制） |
| 9 | graphify-dark-graph | 中 | header + 卡片 stagger，保留 gd-orb 环境动画 |
| 10 | hermes-cyber-terminal | 中 | header + 卡片 stagger，保留 cursor/scanline 环境动画 |
| 11 | testing-safety-alert | 中 | header + 卡片 stagger，克制避免警报感 |
| 12 | obsidian-claude-gradient | 中 | header + 卡片 stagger，保留渐变背景层 |
| 13 | dir-key-nav-minimal | 中 | header + 列表 stagger（极简，仅 fade/fade-up-soft） |
| 14 | knowledge-arch-blueprint | 中 | header + 卡片 stagger（蓝图精确感，仅 fade/fade-up-soft） |
| 15 | consultant-strategy | 中 | header + 卡片 stagger，咨询克制（仅 fade/fade-up + d1..d14） |
| 16 | government-formal-red | 中 | header + 卡片 stagger，政务庄重（fade/fade-up + d1..d14，动效克制不浮夸） |
| 17 | soe-engineering-blue | 中 | header + 科技卡 stagger，深色底 glowing 入场（fade/fade-up + d1..d14） |
| 18 | bank-vip-gold | 中 | header + 卡片 stagger，轻奢克制（fade/fade-up + d1..d14） |
| 19 | academic-defense | 中 | header + 卡片 stagger，学术严谨（fade/fade-up + d1..d14） |
| 20 | insight-report | 中 | header + 卡片 stagger + 图表 bar-grow，研究报告克制（fade/fade-up + d1..d14，可打印） |
| 21 | biz-review | 中 | header + KPI 墙 stagger + 归因条，业务复盘（fade/fade-up/scale + d1..d14） |
| 22 | compare-eval | 中 | header + 矩阵 stagger，评测克制客观（fade/fade-up + d1..d14） |
| 23 | keynote-formal | 中 | 叙事节拍逐页 fade/blur-in + 大字 emphasis，庄重演讲（节拍式，非整页 stagger） |

**档位定义**：
- **强** = rise/zoom/blur/neon 全开（deck 自有 RICH 动效库），整页 stagger 严格执行。6 个强档 deck 有 `.anim-rise-in/.anim-zoom-pop/.anim-blur-in/.anim-stagger-list` 等 deck-native 类。
- **中** = 仅 `.anim-fade`/`.anim-fade-up-soft`/`.anim-bar-grow` + `.anim-d1..d14` 手动 stagger（来自 SHARED_MOTION_LAYER 注入），不用 rise/zoom/blur。17 个中档 deck（含 5 个 B2B 领域 deck：consultant/government/soe/bank/academic + 4 个横向体裁 deck：insight-report/biz-review/compare-eval/keynote-formal）没有 RICH 动效库，只有注入的通用类。

---

## 7. Fallback 与导出

### 7.1 reduced-motion（`shared/tokens.css` 全局兜底）
```css
@media (prefers-reduced-motion: reduce){
  [class*="anim-"], .gd-orb, .gd-rainbow, .hc-cursor {
    animation: none !important; transition: none !important;
  }
  * { animation-delay: 0s !important; }
}
```

### 7.2 PDF / PPTX 导出（脚本已内置，无需改）
- PDF（`export_pdf.mjs:63`）：`getAnimations().forEach(a => a.finish())` → 截图为动画终态
- PPTX（`export_pptx.mjs:78-84`）：`finish()`（有限动画）/ `cancel()`（infinite 动画）→ 截图终态
- → 导出不会出现「动画卡 opacity:0 的空白页」

### 7.3 print 兜底（冗余安全网，防浏览器原生 Ctrl+P）
```css
@media print{
  [class*="anim-"]{opacity:1!important;transform:none!important;filter:none!important;animation:none!important}
}
```

---

## 8. 弃用清单

- ❌ `data-anim="fade-up"` 属性 —— 无 JS 消费，死代码。生成 slide 时删除，只保留同名 `.anim-fade-up` class
- ❌ 非 hermes 模板使用 `.anim-typewriter` —— 终端调性专属

---

## 9. 动效 × SVG 两个根治级陷阱（生成前必看）

`fill-mode: both` 让 `.anim-fade`/`.anim-fade-up-soft` 的末态 `opacity:1` 被钉住。这本身是对的，但它和 inline SVG 的两种常见写法冲突，会产出**渲染才暴露、git diff 看不出**的 bug。两条都已被 CSS 兜底 + 文档约束根治，生成时遵守即可。

### 9.1 陷阱 A：动画元素上用元素级 `opacity` 做静态色块淡色 → 末态变实心、同色文字隐形

`.anim-fade` 动画 `opacity` 0→1，CSS 动画优先级 **高于** SVG 的 `opacity="..."` 属性。所以一个既要淡入、又想保持 10% 淡色填充的色块：

```html
<!-- ❌ 错：动画结束后 opacity 被 to{opacity:1} 覆盖，色块变全不透明 -->
<rect class="anim-fade anim-d4" fill="#067647" opacity=".10"/>

<!-- ✅ 对：淡色用 fill-opacity（填充层，不被 opacity 动画影响），两者解耦 -->
<rect class="anim-fade anim-d4" fill="#067647" fill-opacity=".10"/>
```

**症状**：象限/分区/卡片底色在动画结束后突然变全不透明实心，叠在上面的同色标签文字瞬间看不见（testing-safety-alert 风险矩阵曾中此坑）。

**规则**：**凡挂 `.anim-fade` / `.anim-fade-up-soft` 的 SVG 元素，静态淡色一律 `fill-opacity`，绝不用元素级 `opacity`。** 纯静态（无 anim class）的装饰线/网格线/文字 alpha 不受此限，`opacity` 可用。

### 9.2 陷阱 B：SVG 几何贴 `viewBox` 边 → 末端点/粗描边/轴标被默认 `overflow:hidden` 裁切

SVG 默认 `overflow:hidden`（裁到 viewport）。圆点 `r`、描边 `stroke-width`、轴标文字若落在 viewBox 边界上，外半圈/外半描边被静默切掉（折线末端圆点、曲线收尾、环形图端点是重灾区）。

```html
<!-- ❌ 错：末端圆点 cx=320 r=9 贴 viewBox 右边，右半圈 + 4px 描边被裁 -->
<svg viewBox="0 0 320 200"> … <circle cx="320" cy="6" r="9" stroke-width="4"/> … </svg>

<!-- ✅ 对 A：几何内缩，离边 ≥ r + stroke-width/2 -->
<circle cx="306" cy="20" r="9" stroke-width="4"/>

<!-- ✅ 对 B：给 viewBox 加负原点 padding（不动任何坐标，各边留 16 单位） -->
<svg viewBox="-16 -16 352 232"> … 原坐标不变 … </svg>
```

**兜底**：每个 deck 的 tokens.css overlay 已加 `svg{overflow:visible}`（见各 deck `slide-roles.md` 的「SVG 插图页规则」），越界几何会显出来而非被裁——但**这只是安全网，生成时仍应按上面 A/B 留 padding**，否则越界部分可能压到相邻元素。

**自检**：改完 SVG 跑 `preview_slides.mjs` 截图或 playwright `getBBox()`，确认 `bbox` 在 `[vx,vy,vw,vh]` 内且关键元素完整。
