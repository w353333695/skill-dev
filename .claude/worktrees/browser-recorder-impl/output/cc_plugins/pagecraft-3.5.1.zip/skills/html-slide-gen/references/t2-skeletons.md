# T2 预置骨架速查（Pre-baked T2 Skeletons）

> 每个锚点对应"某个模板 × 某个 layout-catalog 布局"的**已合并 Style Transfer 的完整可粘贴骨架**——subagent 原样复制 + 替换占位符即可，**不再从 layout-catalog + slide-roles 两处拼装、不再凭记忆套 Style Transfer delta**。
>
> **何时用**：spec 的「骨架源」指向 `T2-prebaked（t2-skeletons.md#<template>-<layout>）` 时，本文件是该页的**唯一骨架来源**。无预置的 T2 页面回退到 `layout-catalog.md`（按 `layout-catalog-index.md` 的 offset 列局部读对应 Lxx 段）+ 模板 `slide-roles.md` 的 Style Transfer 段。
>
> **使用纪律**：
> 1. 找到对应锚点，复制整段 HTML（`<!DOCTYPE html>` → `</html>`）。
> 2. 只替换 `[占位符]`（`[SECTION_NUM]`、`[CARD_1_TITLE]` 等），**不改任何 class / 标签 / inline style**。
> 3. `<body>` 必须保留 `tpl-<deck>` class（`tpl-pitch-deck` / `tpl-tech-sharing` / `tpl-weekly-report`，与锚点对应的模板一致）与 `data-skeleton="t2"`——前者激活该 deck 的 overlay（字号/间距/装饰），后者让校验器正确识别骨架来源。
> 4. 把逐字稿填进 `<aside class="notes">`。

---

## 锚点索引

| 锚点 | 模板 | 布局 | 适用 |
|------|------|------|------|
| [`#pitch-deck-l19`](#pitch-deck-l19) | pitch-deck | L19 路线图 | 4 阶段固定路线图 / 时间排期 |
| [`#pitch-deck-l21`](#pitch-deck-l21) | pitch-deck | L21 架构图 | 2-4 层分层架构 / 系统组成 |
| [`#tech-sharing-l21`](#tech-sharing-l21) | tech-sharing | L21 架构图 | 暗底技术架构 / 系统组成 |
| [`#tech-sharing-l17`](#tech-sharing-l17) | tech-sharing | L17 流程图 | 请求/编译/CI 管线 / 暗底流程 |
| [`#weekly-report-l11`](#weekly-report-l11) | weekly-report | L11 KPI 网格 | 周报 KPI 八宫格 / 指标脉搏 |
| [`#weekly-report-l18`](#weekly-report-l18) | weekly-report | L18 时间线 | 交付里程碑 / Sprint 速度节点 |
| [`#consultant-strategy-gantt`](#consultant-strategy-gantt) | consultant-strategy | L23 甘特（变体） | 排期/甘特/多阶段实施计划 / 月度路线图 |

> **consultant-strategy 的 gantt 角色已预置**（见 `#consultant-strategy-gantt`，对应角色 17 甘特变体）。其余未预置模板（product-launch 等）的 T2 页面仍走 `layout-catalog.md`（offset 局部读）通用路径。

---

## Style Transfer delta 速查（pitch-deck T2 共用）

下列值已硬编码进两个预置骨架。subagent **不要改**；主 agent 在 4.2 spec 里列 delta 时直接从 `pitch-deck/slide-roles.md` §Style Transfer **复制**这些字段，不要凭记忆：

| 字段 | 值 | 出处 |
|------|-----|------|
| 内容区 body padding | `118px 165px` | 空间密度对齐 |
| 卡片间距（grid gap） | `32px` | 空间密度对齐 |
| 内容页标题 | h2, `82px`, weight `800`, letter-spacing `-0.03em` | 排版层级对齐 |
| `.section-num` 水印 | `293px`, letter-spacing `-0.05em`, color `var(--surface-2)` | 章节标识 |
| 卡片圆角 | `var(--radius)` = 27px | 组件类名统一 |
| 分隔线 | `.divider-accent`（4px 高，106px 宽，var(--accent)） | 装饰模式继承 |

**禁止引入的视觉元素**（pitch-deck T2 页面不得出现）：

| 禁止 | 原因 |
|------|------|
| `.pill` 标签 | pitch-deck 仅 solution/thanks 页用 `.pill-accent` |
| `.glass` / 玻璃拟态卡片 | pitch-deck 无此视觉语言 |
| `.icon-halo` / `.dot-cluster` | 装饰靠 `.cover-blob` + `.section-num` 水印 |
| `.slide-top-bar` / `.slide-bottom-bar` | pitch-deck 无渐变顶/底条 |
| `.btn-gradient` | CTA 用 `.ask-box`，无独立按钮 |
| 自定义 class（`.arch-*` 等） | 只用 tokens.css 已定义的 class |

---

<a id="pitch-deck-l19"></a>

## `#pitch-deck-l19` — pitch-deck × L19 路线图

**容量**：固定 4 列，**不可加列**（grid 列数固定 4）。5+ 阶段 → 拆两页或改 L18 时间线。
**当前阶段**：给 `.col.now` 高亮（一个 `.col` 加 `now` class）。
**逐字稿**：填进 `<aside class="notes">`。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>[PAGE_TITLE]</title>
<link rel="stylesheet" href="../shared/tokens.css">
</head>
<body class="tpl-pitch-deck" data-skeleton="t2" style="padding:118px 165px;">

  <!-- ST: 章节标识 —— pitch-deck T2 页顶必须有 .section-num 水印 + .num-tag -->
  <div class="section-num" aria-hidden="true">[SECTION_NUM]</div>
  <p class="num-tag">[SECTION_TAG]</p>

  <h2 class="h2" style="font-size:82px;font-weight:800;letter-spacing:-0.03em;">[SECTION_TITLE]</h2>
  <div class="divider-accent" style="width:106px;height:4px;background:var(--accent);margin:25px 0;"></div>
  <p class="lede dim" style="max-width:62ch;">[LEDE_TEXT]</p>

  <!-- L19 roadmap：4 列无缝网格，gap:0 共享 border。当前阶段给 .col.now -->
  <div class="rm">
    <div class="col now">
      <span class="tag">[PHASE_1_TAG]</span>
      <h4 style="font-size:21px;margin:12px 0 8px;">[PHASE_1_TITLE]</h4>
      <p class="dim" style="font-size:16px;line-height:1.5;margin:0;">[PHASE_1_DESC]</p>
    </div>
    <div class="col">
      <span class="tag">[PHASE_2_TAG]</span>
      <h4 style="font-size:21px;margin:12px 0 8px;">[PHASE_2_TITLE]</h4>
      <p class="dim" style="font-size:16px;line-height:1.5;margin:0;">[PHASE_2_DESC]</p>
    </div>
    <div class="col">
      <span class="tag">[PHASE_3_TAG]</span>
      <h4 style="font-size:21px;margin:12px 0 8px;">[PHASE_3_TITLE]</h4>
      <p class="dim" style="font-size:16px;line-height:1.5;margin:0;">[PHASE_3_DESC]</p>
    </div>
    <div class="col">
      <span class="tag">[PHASE_4_TAG]</span>
      <h4 style="font-size:21px;margin:12px 0 8px;">[PHASE_4_TITLE]</h4>
      <p class="dim" style="font-size:16px;line-height:1.5;margin:0;">[PHASE_4_DESC]</p>
    </div>
  </div>

  <aside class="notes"><p>[SPEECH_NOTES]</p></aside>
</body>
</html>
```

**配套 CSS**（`.rm` 系列来自 `layout-catalog.md` L19，pitch-deck tokens.css 已含 `--border` `--radius` `--surface` `--surface-2` `--accent` `--text-2`）：

```css
.rm { display:grid; grid-template-columns:repeat(4,1fr); gap:0; margin-top:28px; border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; }
.rm .col { padding:20px 22px; border-right:1px solid var(--border); }
.rm .col:last-child { border-right:none; }
.rm .col .tag { display:inline-block; padding:3px 12px; border-radius:999px; font-size:11px; background:var(--surface-2); color:var(--text-2); }
.rm .col.now { background:color-mix(in srgb,var(--accent) 6%,var(--surface)); }
.rm .col.now .tag { background:var(--accent); color:#fff; }
```

> **delta 子列**：padding `118px 165px`、`.section-num` 293px、h2 82px/800、divider 106×4、卡片 `--radius` 27px、gap 32px（rm 内部用 border 共享，无 gap）。
> **forbidden**：无 `.slide-top-bar`、无 `.pill`、无 `.glass`、无自定义 `.arch-*`。

---

<a id="pitch-deck-l21"></a>

## `#pitch-deck-l21` — pitch-deck × L21 架构图

**容量**：2-4 层，每层 2-4 cell。5+ 层 → 拆两页或改表格。
**高亮层**：给 `.tier.hl` 加顶部 3px var(--accent) 色条（核心层用）。
**body 布局**：架构图页顶对齐 `padding:80px 150px 60px`（**与 L19 的 118px 165px 不同**——架构图要把垂直空间留给图，标题区压紧）。
**逐字稿**：填进 `<aside class="notes">`。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>[PAGE_TITLE]</title>
<link rel="stylesheet" href="../shared/tokens.css">
</head>
<body class="tpl-pitch-deck" data-skeleton="t2" style="justify-content:flex-start;padding:80px 150px 60px;">

  <!-- ST: 章节标识（架构图可省略 section-num 水印以让出空间；保留 num-tag 章节标签即可） -->
  <p class="num-tag">[SECTION_TAG]</p>

  <h2 class="h2" style="font-size:82px;font-weight:800;letter-spacing:-0.03em;">[SECTION_TITLE]</h2>
  <p class="lede dim" style="max-width:62ch;margin-top:11px;">[LEDE_TEXT]</p>

  <!-- L21 架构图：多行分层网格，每层 140px tname + cells。.cells/.cells.three/.cells.two 控制列数 -->
  <div class="arch">
    <div class="tier hl">
      <div class="tname">[TIER_1_NAME]</div>
      <div class="cells">
        <div class="cell"><div class="ic">[IC_1]</div><h4>[CELL_1_TITLE]</h4><p>[CELL_1_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_2]</div><h4>[CELL_2_TITLE]</h4><p>[CELL_2_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_3]</div><h4>[CELL_3_TITLE]</h4><p>[CELL_3_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_4]</div><h4>[CELL_4_TITLE]</h4><p>[CELL_4_DESC]</p></div>
      </div>
    </div>
    <div class="tier">
      <div class="tname">[TIER_2_NAME]</div>
      <div class="cells three">
        <div class="cell"><div class="ic">[IC_5]</div><h4>[CELL_5_TITLE]</h4><p>[CELL_5_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_6]</div><h4>[CELL_6_TITLE]</h4><p>[CELL_6_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_7]</div><h4>[CELL_7_TITLE]</h4><p>[CELL_7_DESC]</p></div>
      </div>
    </div>
    <div class="tier">
      <div class="tname">[TIER_3_NAME]</div>
      <div class="cells two">
        <div class="cell"><div class="ic">[IC_8]</div><h4>[CELL_8_TITLE]</h4><p>[CELL_8_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_9]</div><h4>[CELL_9_TITLE]</h4><p>[CELL_9_DESC]</p></div>
      </div>
    </div>
  </div>

  <aside class="notes"><p>[SPEECH_NOTES]</p></aside>
</body>
</html>
```

**配套 CSS**（`.arch` 系列来自 `layout-catalog.md` L21）：

```css
.arch { margin-top:28px; display:grid; grid-template-rows:auto auto auto; gap:32px; flex:1; }
.arch .tier { display:grid; grid-template-columns:140px 1fr; align-items:stretch; gap:28px; }
.arch .tname { display:flex; align-items:center; justify-content:center; background:var(--surface-2); border-radius:var(--radius); padding:24px 18px; font-weight:600; font-size:18px; color:var(--text-2); text-transform:uppercase; letter-spacing:.1em; text-align:center; }
.arch .cells { display:grid; grid-template-columns:repeat(4,1fr); gap:22px; }
.arch .cells.three { grid-template-columns:repeat(3,1fr); }
.arch .cells.two { grid-template-columns:repeat(2,1fr); }
.arch .cell { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:28px 24px; text-align:center; box-shadow:var(--shadow); }
.arch .cell .ic { font-size:34px; }
.arch .cell h4 { font-size:21px; margin:0 0 8px; }
.arch .cell p { font-size:16px; color:var(--text-2); margin:0; line-height:1.5; }
.arch .tier.hl .cell { border-top:3px solid var(--accent); }
```

> **delta 子列**：body `padding:80px 150px 60px`（顶对齐）、h2 82px/800、cell padding 28×24、cell h4 21px / p 16px、gap 32px、`.section-num` 水印**可省**（架构图让出空间）。
> **forbidden**：cell `<p>` 颜色不得用 `var(--text-3)`（投影看不清），用 `var(--text-2)`（即 class `.dim`）；无 `.slide-top-bar`、无 `.glass`、无自定义 class。

---

<a id="tech-sharing-l21"></a>

## `#tech-sharing-l21` — tech-sharing × L21 架构图

**容量**：2-4 层，每层 2-4 cell。5+ 层 → 拆两页或改表格。
**高亮层**：给 `.tier.hl` 加顶部 3px var(--accent) 色条（核心层用）。
**body 布局**：架构图页顶对齐 `padding:80px 142px 60px`（与内容页的 96px 142px 不同——架构图要把垂直空间留给图，标题区压紧）。
**逐字稿**：填进 `<aside class="notes">`。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>[PAGE_TITLE]</title>
<link rel="stylesheet" href="../shared/tokens.css">
</head>
<body class="tpl-tech-sharing" data-skeleton="t2" style="justify-content:flex-start;padding:80px 142px 60px;">

  <!-- ST: 章节标识 —— tech-sharing 用 .kicker（mono "> " 前缀），不使用 .section-num 水印 -->
  <p class="kicker">[SECTION_TAG]</p>

  <h2 class="h2" style="font-size:72px;font-weight:700;letter-spacing:-0.025em;color:#fff;">[SECTION_TITLE]</h2>
  <p class="lede dim" style="max-width:62ch;margin-top:11px;">[LEDE_TEXT]</p>

  <!-- L21 架构图：多行分层网格，每层 140px tname + cells。.cells/.cells.three/.cells.two 控制列数 -->
  <div class="arch">
    <div class="tier hl">
      <div class="tname">[TIER_1_NAME]</div>
      <div class="cells">
        <div class="cell"><div class="ic">[IC_1]</div><h4>[CELL_1_TITLE]</h4><p>[CELL_1_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_2]</div><h4>[CELL_2_TITLE]</h4><p>[CELL_2_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_3]</div><h4>[CELL_3_TITLE]</h4><p>[CELL_3_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_4]</div><h4>[CELL_4_TITLE]</h4><p>[CELL_4_DESC]</p></div>
      </div>
    </div>
    <div class="tier">
      <div class="tname">[TIER_2_NAME]</div>
      <div class="cells three">
        <div class="cell"><div class="ic">[IC_5]</div><h4>[CELL_5_TITLE]</h4><p>[CELL_5_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_6]</div><h4>[CELL_6_TITLE]</h4><p>[CELL_6_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_7]</div><h4>[CELL_7_TITLE]</h4><p>[CELL_7_DESC]</p></div>
      </div>
    </div>
    <div class="tier">
      <div class="tname">[TIER_3_NAME]</div>
      <div class="cells two">
        <div class="cell"><div class="ic">[IC_8]</div><h4>[CELL_8_TITLE]</h4><p>[CELL_8_DESC]</p></div>
        <div class="cell"><div class="ic">[IC_9]</div><h4>[CELL_9_TITLE]</h4><p>[CELL_9_DESC]</p></div>
      </div>
    </div>
  </div>

  <aside class="notes"><p>[SPEECH_NOTES]</p></aside>
</body>
</html>
```

**配套 CSS**（`.arch` 系列来自 `layout-catalog.md` L21；tech-sharing tokens.css 已含 `--border` `--radius`(=19px) `--surface` `--surface-2` `--accent` `--text-2` 等）：

```css
.arch { margin-top:28px; display:grid; grid-template-rows:auto auto auto; gap:32px; flex:1; }
.arch .tier { display:grid; grid-template-columns:140px 1fr; align-items:stretch; gap:28px; }
.arch .tname { display:flex; align-items:center; justify-content:center; background:var(--surface-2); border-radius:var(--radius); padding:24px 18px; font-weight:600; font-size:18px; color:var(--text-2); text-transform:uppercase; letter-spacing:.1em; text-align:center; }
.arch .cells { display:grid; grid-template-columns:repeat(4,1fr); gap:22px; }
.arch .cells.three { grid-template-columns:repeat(3,1fr); }
.arch .cells.two { grid-template-columns:repeat(2,1fr); }
.arch .cell { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:28px 24px; text-align:center; box-shadow:var(--shadow); }
.arch .cell .ic { font-size:34px; }
.arch .cell h4 { font-size:21px; margin:0 0 8px; }
.arch .cell p { font-size:16px; color:var(--text-2); margin:0; line-height:1.5; }
.arch .tier.hl .cell { border-top:3px solid var(--accent); }
```

> **delta 子列**：body `padding:80px 142px 60px`（顶对齐）、章节标识用 `.kicker`（mono `> ` 前缀）不用 `.section-num` 水印、h2 72px/700/-0.025em/#fff、cell padding 28×24、cell h4 21px / p 16px、tier gap 32px、卡片 `--radius` = 19px（来自 `.tpl-tech-sharing` overlay）。
> **forbidden**：无 `.section-num` 水印（用 `.kicker`）、无 `.pill`（用 `.tag`）、无 `.glass`/`.slide-top-bar`/`.ambient-glow`、cell `<p>` 颜色不得用 `var(--text-3)`（暗底看不清），用 `var(--text-2)`（class `.dim`）；icon/色一律走 `var(--accent)`/`var(--bad)` 等语义 token，禁写死字面 hex 或字面 rgba。

---

<a id="tech-sharing-l17"></a>

## `#tech-sharing-l17` — tech-sharing × L17 流程图

**容量**：3-5 节点。6+ 节点 → 拆为子流程（"总览 + 详情 A + 详情 B"）。
**高亮节点**：给 `.node.hl` 加 accent 边框 + halo（关键步骤/瓶颈节点用）。
**body 布局**：流程图页保持内容页标准 padding `96px 142px`，垂直居中由 body 默认 flex `justify-content:center` 完成。
**逐字稿**：填进 `<aside class="notes">`。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>[PAGE_TITLE]</title>
<link rel="stylesheet" href="../shared/tokens.css">
</head>
<body class="tpl-tech-sharing" data-skeleton="t2" style="padding:96px 142px;">

  <p class="kicker">[SECTION_TAG]</p>

  <h2 class="h2" style="font-size:72px;font-weight:700;letter-spacing:-0.025em;color:#fff;">[SECTION_TITLE]</h2>
  <p class="lede dim" style="max-width:62ch;margin-top:11px;">[LEDE_TEXT]</p>

  <!-- L17 流程图：水平 flex 管道，3-5 节点。关键/瓶颈节点加 .hl -->
  <div class="flow">
    <div class="node">
      <div class="ic">[IC_1]</div>
      <h4>[NODE_1_TITLE]</h4>
      <p>[NODE_1_DESC]</p>
    </div>
    <div class="arr">→</div>
    <div class="node hl">
      <div class="ic">[IC_2]</div>
      <h4>[NODE_2_TITLE]</h4>
      <p>[NODE_2_DESC]</p>
    </div>
    <div class="arr">→</div>
    <div class="node">
      <div class="ic">[IC_3]</div>
      <h4>[NODE_3_TITLE]</h4>
      <p>[NODE_3_DESC]</p>
    </div>
    <div class="arr">→</div>
    <div class="node">
      <div class="ic">[IC_4]</div>
      <h4>[NODE_4_TITLE]</h4>
      <p>[NODE_4_DESC]</p>
    </div>
  </div>

  <aside class="notes"><p>[SPEECH_NOTES]</p></aside>
</body>
</html>
```

**配套 CSS**（`.flow` 系列来自 `layout-catalog.md` L17；tech-sharing tokens.css 已含全部所需 token；cell `<p>` 颜色从原 `var(--text-3)` 提升到 `var(--text-2)` 以适配 tech-sharing 暗底）：

```css
.flow { display:flex; align-items:center; gap:16px; margin-top:40px; max-width:1200px; }
.flow .node { flex:1; background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:22px; text-align:center; box-shadow:var(--shadow); }
.flow .node .ic { font-size:32px; margin-bottom:6px; }
.flow .node h4 { font-size:16px; }
.flow .node p { font-size:12px; color:var(--text-2); margin:0; }
.flow .arr { color:var(--text-3); font-size:28px; flex-shrink:0; }
.flow .node.hl { border-color:var(--accent); box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 18%,transparent),var(--shadow); }
```

> **delta 子列**：body `padding:96px 142px`（内容页标准）、章节标识用 `.kicker` 不用 `.section-num` 水印、h2 72px/700/-0.025em/#fff、cell padding 22px、node 圆角 `--radius` = 19px、`.node.hl` halo 用 `color-mix` + `var(--accent)`。
> **forbidden**：无 `.section-num` 水印、无 `.pill`、无 `.glass`/`.slide-top-bar`/`.ambient-glow`、`.arr` 箭头可保留 `var(--text-3)` 但 node `<p>` 必须用 `var(--text-2)`；icon/色一律走语义 token，禁写死字面 hex 或字面 rgba。

---

## Style Transfer delta 速查（weekly-report T2 共用）

下列值已硬编码进两个预置骨架。subagent **不要改**；主 agent 在 4.2 spec 里列 delta 时直接从 `weekly-report/slide-roles.md` §Style Transfer **复制**这些字段，不要凭记忆：

| 字段 | 值 | 出处 |
|------|-----|------|
| 内容区 body padding | `85px 130px` | 空间密度对齐 |
| 卡片间距（grid gap） | `32px`（tokens.css `.grid` 原值） | 空间密度对齐 |
| 内容页标题 | `.h2`，56px / weight 700 / letter-spacing -0.02em | overlay `.tpl-weekly-report .h2` |
| 章节标识 | `.kicker`（accent 色，大写小标签，如 `HIGHLIGHTS · KPIs`）——**取代** `.section-num` 水印 | 装饰模式继承 |
| KPI 卡左侧色条 | `.kpi::before` 4.5px，`.kpi.good/.warn/.bad` 切色 | 组件类名统一 |
| 扁平容器圆角 | `--radius` = 19px（overlay 覆盖） | 组件类名统一 |
| 数据强调 | accent 色数字 + mono 字体标签（FEAT/FIX/EXP/INFRA） | 排版层级 |

**禁止引入的视觉元素**（weekly-report T2 页面不得出现）：

| 禁止 | 原因 |
|------|------|
| `.card` / `.card-accent` / `.card-amber` | weekly-report 用扁平 `.wr-panel`/`.wr-tile`/`.kpi`（细边框、几乎无阴影）替代重阴影卡片 |
| `.section-num` 水印 | weekly-report 用 `.kicker` 做章节标识 |
| `.terminal` | weekly-report 无代码展示 |
| `.gradient-text` | 用 accent 色高亮数字，无渐变文字 |
| `box-shadow` 重阴影 | 扁平气质；`.kpi`/`.wr-*` 均只极轻投影 |
| `.kpi-card`（layout-catalog L11 原值） | weekly-report 自有 `.kpi`（左色条 + status class），是签名组件，禁用通用 `.kpi-card` |

> 注：`.wr-panel`/`.wr-tile`/`.wr-win` 等 `.wr-*` 扁平容器是 weekly-report 原生组件（**允许**），区别于被禁的重阴影 `.card*`。

---

<a id="weekly-report-l11"></a>

## `#weekly-report-l11` — weekly-report × L11 KPI 网格

**何时用**：周报/月报的 KPI 八宫格、指标脉搏页（叙事弧中的「成果脉搏」节）。
**容量**：固定 4 列 `.grid.g4`。4 卡直接用；5-8 卡用第二行 `.grid.g4`（每行独立）——**不要改成 5 列**（grid-template-columns 固定）。
**状态着色**：`.kpi.good`（绿条，正向指标）/ `.kpi.warn`（琥珀条，持平或临界）/ `.kpi.bad`（红条，负向）。`.delta.up/.down/.flat` 同色编码。
**逐字稿**：填进 `<aside class="notes">`。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>[PAGE_TITLE]</title>
<link rel="stylesheet" href="../shared/tokens.css">
</head>
<body class="tpl-weekly-report" data-skeleton="t2" style="padding:85px 130px;">

  <!-- ST: 章节标识 —— weekly-report 用 .kicker（accent 色大写小标签），不用 .section-num 水印 -->
  <p class="kicker">[SECTION_TAG]</p>

  <h2 class="h2" style="font-size:56px;font-weight:700;letter-spacing:-0.02em;margin-bottom:11px;">[SECTION_TITLE]</h2>
  <p class="lede dim" style="max-width:62ch;">[LEDE_TEXT]</p>

  <!-- L11 KPI 网格：固定 4 列 .grid.g4。每卡用 weekly-report 原生 .kpi（左 4.5px 色条 + status class），禁用通用 .kpi-card -->
  <div class="grid g4 mt-l">
    <div class="kpi good">
      <p class="label">[KPI_1_LABEL]</p>
      <div class="value">[KPI_1_VALUE]</div>
      <span class="delta up">[KPI_1_DELTA]</span>
    </div>
    <div class="kpi good">
      <p class="label">[KPI_2_LABEL]</p>
      <div class="value">[KPI_2_VALUE]</div>
      <span class="delta up">[KPI_2_DELTA]</span>
    </div>
    <div class="kpi warn">
      <p class="label">[KPI_3_LABEL]</p>
      <div class="value">[KPI_3_VALUE]</div>
      <span class="delta flat">[KPI_3_DELTA]</span>
    </div>
    <div class="kpi bad">
      <p class="label">[KPI_4_LABEL]</p>
      <div class="value">[KPI_4_VALUE]</div>
      <span class="delta down">[KPI_4_DELTA]</span>
    </div>
  </div>

  <!-- 5-8 卡：再加一行 .grid.g4（不要改列数）；≤4 卡时删本块 -->
  <div class="grid g4 mt-m">
    <div class="kpi good">
      <p class="label">[KPI_5_LABEL]</p>
      <div class="value">[KPI_5_VALUE]</div>
      <span class="delta up">[KPI_5_DELTA]</span>
    </div>
    <div class="kpi good">
      <p class="label">[KPI_6_LABEL]</p>
      <div class="value">[KPI_6_VALUE]</div>
      <span class="delta up">[KPI_6_DELTA]</span>
    </div>
    <div class="kpi warn">
      <p class="label">[KPI_7_LABEL]</p>
      <div class="value">[KPI_7_VALUE]</div>
      <span class="delta flat">[KPI_7_DELTA]</span>
    </div>
    <div class="kpi">
      <p class="label">[KPI_8_LABEL]</p>
      <div class="value">[KPI_8_VALUE]</div>
      <span class="delta flat">[KPI_8_DELTA]</span>
    </div>
  </div>

  <aside class="notes"><p>[SPEECH_NOTES]</p></aside>
</body>
</html>
```

**配套 CSS**（全部来自 `weekly-report/shared/tokens.css` 的 `.tpl-weekly-report` overlay，无需 layout-catalog 注入）：
- `.grid` / `.g4` / `.mt-l` / `.mt-m` — layout primitives（base 层，已含）
- `.kpi` / `.kpi.good` / `.kpi.warn` / `.kpi.bad` — KPI 卡（左 4.5px 色条，flat 细边框）
- `.kpi .label` / `.kpi .value` / `.kpi .delta.up` / `.delta.down` / `.delta.flat` — 卡内层级
- `.kicker` / `.h2` / `.lede` / `.dim` — typography（overlay 覆盖 `.kicker`=16px/700/accent、`.h2`=56px/700）

> **delta 子列**：body `85px 130px`、`.h2` 56px/700/-0.02em、`.kicker` 取代 `.section-num`、`.kpi` 左条 4.5px（status 切色）、容器 `--radius` 19px、grid gap 32px。
> **forbidden**：无 `.section-num` 水印、无 `.card`/`.card-accent`、无 `.kpi-card`（layout-catalog 原值）、无 `box-shadow` 重阴影、无 `.gradient-text`。

---

<a id="weekly-report-l18"></a>

## `#weekly-report-l18` — weekly-report × L18 时间线（交付里程碑）

**何时用**：周报里的「本周发布」「Sprint 速度里程碑」「季度交付节奏」页——把 shipped/velocity/next-week 这类线性叙事压成一页时间轴。
**容量**：水平 5 列（`.grid` 内 5 个 `.tl-item`），列数固定 5——里程碑 3-4 个时仍铺满（无项处留空点），6+ 个 → 拆两页或改纵向 `.timeline`。
**状态着色**：`.tl-item.done`（绿实点，已完成交付）/ `.tl-item.active`（accent 实点 + 光环，本周进行中）/ 默认（灰空心点，计划中）。
**逐字稿**：填进 `<aside class="notes">`。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>[PAGE_TITLE]</title>
<link rel="stylesheet" href="../shared/tokens.css">
</head>
<body class="tpl-weekly-report" data-skeleton="t2" style="padding:85px 130px;">

  <p class="kicker">[SECTION_TAG]</p>

  <h2 class="h2" style="font-size:56px;font-weight:700;letter-spacing:-0.02em;margin-bottom:11px;">[SECTION_TITLE]</h2>
  <p class="lede dim" style="max-width:62ch;">[LEDE_TEXT]</p>

  <!-- L18 水平时间线：5 列固定，gap:0 共享连接线。状态 .done/.active/默认控制圆点配色 -->
  <div class="tl grid" style="grid-template-columns:repeat(5,1fr);gap:0;margin-top:43px;">
    <div class="tl-item done">
      <span class="tl-dot"></span>
      <h4 class="tl-date">[MILESTONE_1_DATE]</h4>
      <p class="tl-title">[MILESTONE_1_TITLE]</p>
      <p class="tl-desc dim">[MILESTONE_1_DESC]</p>
    </div>
    <div class="tl-item done">
      <span class="tl-dot"></span>
      <h4 class="tl-date">[MILESTONE_2_DATE]</h4>
      <p class="tl-title">[MILESTONE_2_TITLE]</p>
      <p class="tl-desc dim">[MILESTONE_2_DESC]</p>
    </div>
    <div class="tl-item active">
      <span class="tl-dot"></span>
      <h4 class="tl-date">[MILESTONE_3_DATE]</h4>
      <p class="tl-title">[MILESTONE_3_TITLE]</p>
      <p class="tl-desc dim">[MILESTONE_3_DESC]</p>
    </div>
    <div class="tl-item">
      <span class="tl-dot"></span>
      <h4 class="tl-date">[MILESTONE_4_DATE]</h4>
      <p class="tl-title">[MILESTONE_4_TITLE]</p>
      <p class="tl-desc dim">[MILESTONE_4_DESC]</p>
    </div>
    <div class="tl-item">
      <span class="tl-dot"></span>
      <h4 class="tl-date">[MILESTONE_5_DATE]</h4>
      <p class="tl-title">[MILESTONE_5_TITLE]</p>
      <p class="tl-desc dim">[MILESTONE_5_DESC]</p>
    </div>
  </div>

  <aside class="notes"><p>[SPEECH_NOTES]</p></aside>
</body>
</html>
```

**配套 CSS**（`.tl-*` 系列由本骨架注入——基于 `layout-catalog.md` L18（offset 350）的水平 5 列时间线骨架 + `templates/charts/timeline.html` 的 done/active 状态语义，色值 token 化对齐 weekly-report 扁平气质）：

```css
.tpl-weekly-report .tl { position:relative; }
.tpl-weekly-report .tl::before { content:""; position:absolute; top:21px; left:8%; right:8%; height:2px; background:var(--border); z-index:0; }
.tpl-weekly-report .tl-item { position:relative; text-align:center; padding:0 14px; }
.tpl-weekly-report .tl-item .tl-dot { position:relative; display:inline-block; width:24px; height:24px; border-radius:50%; background:var(--surface-2); border:3px solid var(--border); box-shadow:0 0 0 3px var(--bg); z-index:1; }
.tpl-weekly-report .tl-item.done .tl-dot { background:var(--good); border-color:var(--good); }
.tpl-weekly-report .tl-item.active .tl-dot { background:var(--accent); border-color:var(--accent); box-shadow:0 0 0 3px var(--bg),0 0 0 7px color-mix(in srgb,var(--accent) 20%,transparent); }
.tpl-weekly-report .tl-item .tl-date { font-family:'SF Mono','Cascadia Code',Consolas,monospace; font-size:16px; font-weight:700; color:var(--text-3); margin:16px 0 6px; }
.tpl-weekly-report .tl-item.active .tl-date { color:var(--accent); }
.tpl-weekly-report .tl-item.done .tl-date { color:var(--good); }
.tpl-weekly-report .tl-item .tl-title { font-size:20px; font-weight:600; color:var(--text-1); margin:0 0 4px; line-height:1.25; }
.tpl-weekly-report .tl-item .tl-desc { font-size:16px; line-height:1.5; margin:0; }
.tpl-weekly-report .tl-item:not(.done):not(.active) .tl-title { color:var(--text-2); }
```

> **delta 子列**：body `85px 130px`、`.h2` 56px/700/-0.02em、`.kicker` 取代 `.section-num`、连接线 2px `var(--border)`、点 24px + `--bg` 双层光环、mono 字体日期、容器无圆角无阴影。
> **forbidden**：无 `.section-num` 水印、无 `.card`/`.card-accent`、无 `box-shadow` 重阴影（`.tl-dot` 仅用 `var(--bg)` 描边层 + active 的 color-mix 光环，不是 drop-shadow）、无 `.gradient-text`、无 `.ship-item` 混用。

---

## Style Transfer delta 速查（consultant-strategy T2 共用）

下列值已硬编码进 consultant-strategy 的预置骨架。subagent **不要改**；主 agent 在 4.2 spec 里列 delta 时直接从 `consultant-strategy/slide-roles.md` §Style Transfer **复制**这些字段：

| 字段 | 值 | 出处 |
|------|-----|------|
| 内容区 body padding | `80px 110px`（`--deck-padding` 默认） | 空间密度对齐 |
| 卡片间距（grid gap） | `28px`（tokens.css `.grid`） | 空间密度对齐 |
| 内容页标题 | `.h2`，54px / weight 700 / letter-spacing `-0.02em` | overlay `.tpl-consultant-strategy` |
| 章节标识 | `.kicker`（mono 小标签）+ `.bar-top` 5px 蓝条 | 装饰模式继承 |
| 扁平容器圆角 | `--radius` = 4px（consultant 偏小，硬边感） | 组件类名统一 |
| 数据强调 | `.cs-table` 表头蓝底白字 / `.cs-quarter` 左色条 / `.cs-g-bar.actual` amber 实心 | 排版层级 |

**禁止引入的视觉元素**（consultant-strategy T2 页面不得出现）：

| 禁止 | 原因 |
|------|------|
| `box-shadow` / 重阴影 | consultant 是浅色硬边 deck，靠 border 表达层级，不用阴影 |
| 大圆角 > 8px | 硬边商务感，圆角偏小 |
| `.ambient-glow` / `.glass` / blob / rgba 玻璃感 | 那是 soe 深色玻璃感 deck 的语言，consultant 不用 |
| 渐变条背景（linear-gradient 填充 .cs-g-bar） | 用实色 var(--accent-3)/var(--bad)，非渐变 |
| 自定义 class（`.gantt-*` 等） | 只用 tokens.css 已定义的 `.cs-gantt` 系列 |

---

<a id="consultant-strategy-gantt"></a>

## `#consultant-strategy-gantt` — consultant-strategy × L23 甘特（变体）

**何时用**：排期/甘特/多阶段实施计划 / 月度路线图（叙事弧中的「落地路径」节）。当 outline 含 `[visual: gantt]` / `[visual: timeline]` 或标题/正文关键词（排期/甘特/月份/阶段/路线图/里程碑/波次/Sprint/季度交付/N 阶段）时，phase4-workflow 4.2 的强制分流闸会把该页判为 T2 并指向本锚点。
**容量**：列数 = 项目周期月数（由 `data-gantt-months` 驱动，`190px repeat(N,1fr)`，post-process 自动设 `--gantt-cols`）× 4-6 工序行 + 3-4 里程碑。工序 > 6 → 拆两页（前 6 + 后 6）。
**周期适配（关键，治 G1/G2/G4）**：subagent 只需①在 `.cs-gantt` 设 `data-gantt-start="起始月"` + `data-gantt-months="月数"`（如 6 月项目 7 月起：`start="7" months="6"`，跨年自动回绕）②每条 `.cs-g-bar` 设 `data-mstart="第几月开始"` + `data-mspan="跨几月"`。**月份表头与 bar 的 left/width% 由 post-process `fixGanttMonths` 自动生成，禁止手填**。里程碑 `[MS_n_DATE]` 须落在 `start..start+months-1` 月范围内。详见 subagent-brief「甘特图周期适配硬约束」段。
**配色**（浅色硬边，仿 `.cs-table`/`.cs-quarter`，**非 soe 深色玻璃感**）：plan 条 `rgba(var(--brand-secondary-rgb),.2)` 浅蓝底 + 1px 硬边；actual 条 `var(--accent-3)` amber 实心；lag 条 `var(--bad)` 红；里程碑 `.done/.cur/.plan` 左色条 good/accent-3/border-strong。
**逐字稿**：填进 `<aside class="notes">`。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1920px">
<title>[PAGE_TITLE]</title>
<link rel="stylesheet" href="../shared/tokens.css">
</head>
<body class="tpl-consultant-strategy" data-skeleton="t2" style="padding:80px 110px;">

  <div class="bar-top"></div>
  <div class="cs-pagehead">
    <p class="kicker anim-fade anim-d1">[SECTION_TAG]</p>
    <h2 class="h2 anim-fade-up anim-d2">[SECTION_TITLE]</h2>
  </div>
  <p class="lede dim anim-fade-up anim-d3" style="margin-bottom:24px;max-width:none">[LEDE_TEXT]</p>

  <!-- L23 甘特：周期由 data-gantt-start/months 驱动，月份表头+bar 百分比由 post-process fixGanttMonths 生成。
       ⚠️ 不要手填月份表头 [G_M1..]，不要手算 left/width——只声明周期 + 每条 bar 的 mstart/mspan。 -->
  <div class="cs-gantt" data-gantt-start="7" data-gantt-months="6">
    <div class="cs-g-corner">[G_HEAD]</div>
    <!-- GANTT_MONTHS_AUTO（fixGanttMonths 自动填充月份头，留此注释占位） -->

    <div class="cs-g-rowlabel"><span class="cs-g-idx">01</span>[G_R1]</div>
    <div class="cs-g-track">
      <div class="cs-g-bar plan" data-mstart="1" data-mspan="1"><span>计划</span></div>
      <div class="cs-g-bar actual" data-mstart="1" data-mspan="1"><span>实际</span></div>
    </div>
    <!-- 行 2-6 同结构：G_R2~G_R6 + 每条 bar 的 data-mstart/data-mspan（按真实工序月份） -->
  </div>

  <div class="cs-gantt-legend">
    <div><span class="lg-sw plan"></span><span class="dim2">[LG_PLAN]</span></div>
    <div><span class="lg-sw actual"></span><span class="dim2">[LG_ACTUAL]</span></div>
    <div><span class="lg-sw lag"></span><span class="dim2">[LG_LAG]</span></div>
  </div>

  <p class="eyebrow dim2" style="margin-top:30px;margin-bottom:14px">[MS_LABEL]</p>
  <div class="grid g3" style="gap:18px">
    <div class="cs-milestone done">
      <div><div class="cs-ms-date">[MS_1_DATE]</div><div class="cs-ms-name">[MS_1_NAME]</div><div class="cs-ms-prog">[MS_1_PROG]</div></div>
      <div class="cs-ms-pct">[MS_1_PCT]</div>
    </div>
    <div class="cs-milestone cur">
      <div><div class="cs-ms-date">[MS_2_DATE]</div><div class="cs-ms-name">[MS_2_NAME]</div><div class="cs-ms-prog">[MS_2_PROG]</div></div>
      <div class="cs-ms-pct">[MS_2_PCT]</div>
    </div>
    <div class="cs-milestone plan">
      <div><div class="cs-ms-date">[MS_3_DATE]</div><div class="cs-ms-name">[MS_3_NAME]</div><div class="cs-ms-prog">[MS_3_PROG]</div></div>
      <div class="cs-ms-pct">[MS_3_PCT]</div>
    </div>
  </div>

  <aside class="notes"><p>[SPEECH_NOTES]</p></aside>
</body>
</html>
```

**配套 CSS**（`.cs-gantt` 系列已在 `consultant-strategy/shared/tokens.css` 注册，T1.2 落地；无需 layout-catalog 注入）：
- `.cs-gantt`（`grid-template-columns:190px repeat(var(--gantt-cols,12),1fr)`，列数随周期）/ `.cs-g-corner` / `.cs-g-head`(.gold) / `.cs-g-rowlabel` / `.cs-g-idx` / `.cs-g-track` / `.cs-g-bar`(.plan/.actual/.lag) / `.cs-gantt-legend`(.lg-sw) / `.cs-milestone`(.done/.cur/.plan) / `.cs-ms-*`

**空间利用率指引（V2）**：甘特网格占 page-body 高度 ≥ 80%（按 subagent-rules「空间利用率硬约束」内容页阈值）。N 月头 + 4-6 工序行填满主体，里程碑卡区占底部；不足时增工序行或放大行高（`.cs-g-track` min-height 50→60px），**不留底部空白**。

> **delta 子列**：body `80px 110px`、`.h2` 54px/700、`.bar-top` 5px 蓝、`.cs-gantt` 2px 硬边 + 12 列网格底纹、表头 `.cs-g-corner` 蓝底白字、双色条 plan(浅蓝)/actual(amber)/lag(红) 全 var token、里程碑左色条硬边无阴影。
> **forbidden**：无 `box-shadow`/glow、无渐变条背景、无玻璃感 rgba、无大圆角（>8px）、无自定义 `.gantt-*` class（只用 `.cs-gantt` 系列）。
