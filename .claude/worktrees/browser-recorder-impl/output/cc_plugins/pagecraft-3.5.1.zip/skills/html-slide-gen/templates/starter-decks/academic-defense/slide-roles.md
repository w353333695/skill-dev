# academic-defense — Slide Role Catalog

> **模板气质**：学位论文答辩风（pagecraft academic_defense 调性）—— 白底 + 深蓝 #003366 页眉带 + 红色 #CC0000 左竖条/强调、浅蓝灰 #E8F4FC 卡片（圆角 8px、左侧彩色竖条）、观点条、严谨克制、科研感、结论先行。
> **默认 color-scheme**：`academic-green`（深蓝 #003366 + 红 #cc0000 + 浅蓝灰 #e8f4fc，白底）。
>   ⚠️ scheme 名「学术墨绿」为历史遗留，实际 token 为深蓝+红，与 pagecraft academic_defense/design_spec 一致；如需改名单独立项，不改 JSON。
> **switch-theme**：已接入。`shared/tokens.css` §2 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 为换肤入口；所有 `aca-*` 组件与语义 token 均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 一键切换。可切为 `government-blue`（同系深蓝）、`consulting-navy` 等。
> **适用文稿类型**：学位论文答辩 / 课题中期检查 / 研究成果汇报 / 开题报告。
> **叙事结构（16 页，按出现顺序）**：cover → toc → research-summary → background → research-gap → research-question → chapter-divider → framework → methodology → experiments → method-comparison → technical-roadmap → phased-results → limitations → future-research → acknowledgements。
>
> 01–03 为「开篇」（封面 + 目录 + 研究综述/核心贡献）；04–06 为「研究问题」（背景现状 + 研究空白 + MECE 问题分解）；07 为「章节切换」；08–12 为「方法与实验」（研究框架 2×2 矩阵 + 核心方法 + 实验结果 + 方法对比 + 技术路线）；13–15 为「结论与展望」（阶段成果 + 研究局限 + 后续研究计划）；16 为「致谢」。其中 **07（chapter-divider）/ 10（experiments，含公式块）/ 13（phased-results）为本 deck 特色角色页**。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 封面：深蓝页眉条 + 论文标题 + 蓝点分割线 + 答辩人信息块 + 校徽位 + 论文编号 | `.aca-header`(70px深蓝带+红竖条+校徽位), `.aca-info-tag`+`.aca-info-pubid`, `.h1`(含 `.gradient-text`), `.aca-dot-divider`, `.aca-info`(姓名/学号/导师/机构/答辩日期) |
| 02 | `toc` | 目录：6 章节双栏列表 + 编号 + 描述 | `.aca-pagehead`(深蓝带), `.h3.mono`(编号), `.h4`(章节标题), `border-bottom` 分隔 |
| 03 | `research-summary` | 研究综述（核心贡献）：一句话核心贡献 + 3 创新点卡 | `.card.card-amber`(贡献条), `.grid.g3`, `.card.card-accent`, `.pill-accent`, `.h3.mono`(指标), `.aca-cite` |
| 04 | `background` | 选题背景/意义：4 列数据卡（领域现状）+ 研究意义观点条 | `.grid.g4`, `.aca-fact`(`.aca-num`/`.aca-label`/`.aca-delta`), `.aca-insight`(观点条), `.aca-cite` |
| 05 | `lit-review` | **文献综述**（特色页）：4 张文献综述编号卡 + 研究空白观点条 | `.aca-litcard`(`.aca-litcard-num`[n] / `.aca-litcard-cite` 作者年 / `.aca-litcard-claim` 观点), `.aca-cite`, `.aca-insight` |
| 06 | `research-question` | 研究问题：MECE 树状分解（1 root → 3 leaf） | `.aca-tree-node.root`/`.leaf`, inline SVG 连接线 |
| 07 | `chapter-divider` | 章节切换：深蓝全屏 + 红左竖条 + 半透明大号编号 | `background:var(--accent)`, `.aca-bignum`(半透明), `.h1`(108px 白), red 分隔条 |
| 08 | `tech-roadmap` | **研究技术路线**（特色页）：3 阶段路线图（数据→模型→验证）+ 路线说明 + 状态图例 | `.aca-roadmap`(`.aca-rm-stage`/`.is-core`/`.aca-rm-num`/`.aca-rm-io`), `.aca-insight`, `.card-soft` |
| 09 | `methodology` | 研究方法：3 方法卡 + 核心方法红高亮（BAM-Net） + 选择理由观点条 | `.grid.g3`, `.card-amber`(核心方法), `.pill-amber`(★标), `.aca-insight`(理由), `.aca-cite` |
| 10 | `experiments` | **实验结果**（特色页）：核心大数字 + 编号公式块(1)(2) + baseline 对比 + 结论 | `.card-accent`, `.h1.mono`, `.aca-formula`(`.aca-eq-wrap`/`.aca-eq`/`.aca-eq-num`), `.aca-baseline`(红高亮 ours), `.aca-cite`, `.aca-insight` |
| 11 | `method-comparison` | **方法对比表**（baseline vs ours）：6 指标 SOTA 对比，本文列红高亮 | `.aca-table`(硬边, 表头蓝底白字, `.col-hero` 红列), `.aca-cite`, `caption` |
| 12 | `technical-roadmap` | 实验流程：3 阶段时间轴 + 里程碑 + 图例 | 时间轴(绝对定位线 + 圆点节点), `.card`/`.card-amber`(阶段卡), `.eyebrow`(阶段标签) |
| 13 | `phased-results` | 阶段成果（特色页）：4 阶段卡 + RAG 状态点 + 完成率进度条 + 关注项 | `.aca-quarter`, `.aca-rag-dot`(G/A), `.aca-q-progress`/`.aca-q-bar`, `.aca-q-pct`, `.aca-insight`(关注项) |
| 14 | `limitations` | 研究局限：3 局限卡，每卡局限/未来工作双栏对照 | `.card`(局限行), `.aca-risk`(`.aca-risk-risk`/`.aca-risk-mit`), 局限等级 pill |
| 15 | `future-research` | 后续研究计划：4-step pipeline（首步 hero） + 总体目标 | `.aca-pipeline`, `.aca-step.hero`, `.aca-step-num`/`.title`/`.body`/`.owner`, `.pill-accent`(目标) |
| 16 | `acknowledgements` | 致谢：深蓝页眉条 + 致谢块(导师/课题组/答辩委员会/资助基金号) + DOI/代码链接 + Q&A + 版权 | `.aca-header`, `.aca-dot-divider`, `.aca-info`×2(致谢块+资助/链接), `.aca-insight`(Q&A), `.card-soft`(版权) |

---

## 角色详情

### 01 — `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`project_code`, `client_label`, `headline`, `headline_accent`, `subtitle`, `kpi_1~3_value/label`, `meta_code`, `meta_date`, `meta_partner`, `meta_confidential`, `footer_source`
- **不可改动**：`.bar-left` 左侧蓝竖条、顶部 14px 深蓝装饰条、`.h1` 字号(74px)/字重(800)、`.aca-cover-meta` 底部绝对定位(left:90px;bottom:80px)
- **内容适配规则**：
  - `headline` 含一个 `<span class="gradient-text">` 渐变 accent 词(key: `headline_accent`)，替换时保留 span
  - `meta_*` 四项为"标签+加粗值"结构（答辩人/导师/单位/日期），增减时同步调整 `.aca-cover-meta` gap
  - `meta_confidential` 用 `.confidential` 红色大写放答辩日期

### 02 — `toc`
- **可替换键**：`kicker`, `title`, `item_1~6_num/title/desc`, `footer_source`（6 组 ×3 字段 + 2）
- **不可改动**：`.aca-pagehead` 深蓝页眉带（满宽 + 红左竖条）、`.grid.g2` 双栏、每项 `border-bottom` 分隔线、编号用 `.h3.mono` 蓝
- **内容适配规则**：议程项 4~6 个，增删 `.row` 元素，标题控制在 12 字内

### 03 — `research-summary`（核心贡献）
- **可替换键**：`kicker`, `title`, `core_conclusion`(含 5 个内嵌 `<b>`/`<span>` 高亮), `pillars_label`, `pillar_1~3_tag/metric/title/body`, `footer_source`
- **不可改动**：`.card.card-amber` 贡献条字号(30px)、3 创新点卡等宽(`.grid.g3`)、指标用 `.h3.mono` 红
- **内容适配规则**：
  - `core_conclusion` 是整 deck 的"核心贡献一句话"，必须含方法名 + 量化结果
  - 内嵌高亮词用 `<span style="color:var(--accent-3)">` 或 `<b>`，替换时保留标记
  - 创新点固定 3 个（对应 04-06 问题 + 08-12 方法/实验）

### 04 — `background`
- **可替换键**：`kicker`, `title`, `subtitle`, `stat_1~4_value/label/delta`, `insight_tag`, `insight_body`, `footer_source`
- **不可改动**：4 列等宽(`.grid.g4`)、`.aca-num` 88px Bold、delta 用 `.aca-delta.down`/`.up` 红/绿、研究意义用 `.aca-insight` 观点条（浅蓝灰 + 蓝左竖条）
- **内容适配规则**：4 个数据卡，`stat_*_value` 控制在 6 字内，delta 含方向箭头

### 05 — `lit-review`（特色页 · 文献综述编号卡）
- **可替换键**：`kicker`, `title`, `subtitle`, `lit1~4_num/cite/claim`, `gap_tag`, `gap_body`, `footer_source`
- **不可改动**：`.aca-litcard`（左竖条 + `.aca-litcard-num`[n] 编号 + `.aca-litcard-cite` 作者年·来源 + `.aca-litcard-claim` 观点），文中上标引用用 `.aca-cite`
- **内容适配规则**：4 张文献卡按引用编号 [1]-[6] 对应参考文献表；`border-left-color` 区分路线（蓝=基线/Transformer、红=边界感知、辅助蓝=综述）；`gap_body` 定位本文研究空白

### 06 — `research-question`（MECE 分解）
- **可替换键**：`kicker`, `title`, `subtitle`, `root_question`, `leaf_1~3_tag/title/body`, `footer_source`
- **不可改动**：`.aca-tree-node.root` 深蓝底白字、inline SVG 三叉连接线坐标、3 leaf 等宽
- **内容适配规则**：1 root + 3 leaf（MECE 互斥穷尽），leaf 的 body 用"→ 指标"格式回链目标

### 07 — `chapter-divider`（特色页）
- **可替换键**：`bignum`, `chapter_num`, `chapter_title`, `chapter_sub`, `footer_source`
- **不可改动**：全屏 `background:var(--accent)`(深蓝)、`.aca-bignum` 半透明大号编号、`.h1` 108px 白字、red 分隔条、red 左竖条 10px
- **内容适配规则**：用于切换到"研究方法与实验"大章节，`chapter_title` 不写 `<br>`（用 `<wbr>`），`bignum` 是半透明背景大编号

### 08 — `tech-roadmap`（特色页 · 研究技术路线图）
- **可替换键**：`kicker`, `title`, `subtitle`, `rm1~3_num/title` + `_in/_method/_out`, `note_tag`, `note_body`, `legend_title`, `legend_1~3`, `footer_source`
- **不可改动**：`.aca-roadmap`（3 阶段卡 + 阶段间 → 箭头）、`.aca-rm-stage.is-core`（核心阶段红高亮顶边）、`.aca-rm-io` 三行（输入/方法/产出，带 `.aca-rm-tag` 标签）
- **内容适配规则**：3 阶段（数据构建→BAM-Net 模型[核心]→系统验证），每阶段三段式（输入→方法→产出）；核心创新集中在阶段 2

### 09 — `methodology`
- **可替换键**：`kicker`, `title`, `opt_a~c_tag/risk/title/body/invest_label/invest/gmv_label/gmv/irr_label/irr`, `opt_b_tag/subtype/horizon`, `reason_tag`, `reason_body`, `footer_source`（3 方法 × ~9 字段）
- **不可改动**：核心方法(默认 B)用 `.card-amber` + 顶部居中红 pill、指标红/绿着色、选择理由用 `.aca-insight` 观点条
- **内容适配规则**：
  - 3 方法：A 基线 / B 核心方法(红高亮) / C 对照，`opt_b_*` 整组高亮
  - 若核心方法变更（如改主推 C），需把 `.card-amber` class 迁移到对应卡

### 10 — `experiments`（特色页 · 公式块 + baseline 对比）
- **可替换键**：`kicker`, `title`, `big_label`, `big_value`, `big_unit`, `big_note`, `eq1`/`eq1_num`, `eq2`/`eq2_num`, `eq_caption`, `bl_title`, `bl_h_metric/base/ours/delta`, `r1~5_metric/base/ours/delta`, `bl_note`, `conc_tag`, `conc_body`, `footer_source`
- **不可改动**：左 `.card-accent` 大数字 + `.aca-formula`（`.aca-eq-wrap` 含 `.aca-eq` 等宽公式 + `.aca-eq-num` 编号 (1)(2)）、右 `.aca-baseline`（列头深蓝/ours 列红高亮/提升% 列红字）、结论用 `.aca-insight`
- **内容适配规则**：
  - `eq*` 是 `.mono` 占位公式（暂不用 katex，后续单独立项），含 `<sub>`/`<b>` 标记，替换时保留；`.aca-eq-num` 是公式编号 (1)(2)
  - `.aca-baseline` 4 列结构（指标 / baseline / ours[红] / 提升[红]），ours 列与 delta 列用 `aca-bl-ours` / `aca-bl-delta` 着色

### 11 — `method-comparison`
- **可替换键**：`kicker`, `title`, `subtitle`, `col_metric/unet/trans/bound/ours/gap`（6 列头）, `r1~6_metric/unet/trans/bound/ours/gap`（6 行 ×6）, `caption`, `footer_source`
- **不可改动**：`.aca-table` 硬边、表头蓝底白字、`.col-hero` 列红高亮（本文方法）、gap 列绿色 ▲；列头/方法名带 `.aca-cite` 引用标记
- **内容适配规则**：6 指标行 × 4 方法（U-Net/TransUNet/BoundaryLoss/本文），`col-hero` 默认指第 5 列（本文 BAM-Net），最优值加粗

### 12 — `technical-roadmap`
- **可替换键**：`kicker`, `title`, `wave_1~3_tag/title/body/ms`, `legend_done/cur/plan`, `footer_source`
- **不可改动**：时间轴主线(绝对定位, 实线=已完成 var(--accent) / 虚线背景=计划)、3 阶段等宽、圆点节点颜色对应状态
- **内容适配规则**：3 阶段（数据构建→模型设计→验证消融），每阶段 `wave_*_ms` 是可验证里程碑

### 13 — `phased-results`（特色页）
- **可替换键**：`kicker`, `title`, `subtitle`, `q1~4_label/rag/title/pct/status/event`, `action_tag`, `action_body`, `footer_source`（4 阶段 ×5）
- **不可改动**：`.aca-quarter` 4 卡等宽、`.aca-rag-dot` G/A/R 状态点、`.aca-q-progress`/`.aca-q-bar` 进度条颜色随 RAG(good/warn/bad)、关注项用 `.aca-insight` 观点条
- **内容适配规则**：
  - `q*_rag` 值为 "G"/"A"/"R"，需与 `.aca-rag-dot` class(good/warn/bad) + `.aca-q-bar` class 同步
  - `q*_pct` 数字 + `.aca-q-bar` width:% 需一致
  - `subtitle` 含内嵌 RAG 图例 dot，保留 `<span class="aca-rag-dot good">`

### 14 — `limitations`
- **可替换键**：`kicker`, `title`, `risk_1~3_level/title/prob/risk_head/risk_body/mit_head/mit_body`, `footer_source`（3 局限 ×7）
- **不可改动**：`.aca-risk` 双栏（左红 `.aca-risk-risk` 局限 / 右绿 `.aca-risk-mit` 未来工作）、局限等级 pill 颜色(主要=红/次要=红弱)
- **内容适配规则**：3 局限卡，每卡"研究局限 + 未来工作"对照，`prob` 格式"影响：…"

### 15 — `future-research`
- **可替换键**：`kicker`, `title`, `subtitle`, `step_1~4_num/title/body/owner/due`, `decision_tag`, `decision_body`, `footer_source`（4 步 ×5）
- **不可改动**：`.aca-pipeline` 4 步等宽、`.aca-step.hero`（首步红顶边 + 浅底）、owner 用 `.aca-step-owner` 加粗
- **内容适配规则**：4 步后续研究（多中心数据集/3D扩展/域自适应/可解释基准），每步 owner(角色) + due(T+Nd) + 可验证产出

### 16 — `acknowledgements`
- **可替换键**：`ack_header`, `crest`, `headline`, `ack_advisor`, `ack_lab`, `ack_committee`, `ack_hospital`, `ack_fund`(基金号), `ack_doi`, `ack_code`, `ack_data`, `qa_tag`, `qa_body`, `copy_role`, `copy_school`, `copy_email`, `footer_source`
- **不可改动**：`.aca-header`（70px 深蓝顶条 + 红竖条 + 校徽位）、`.aca-dot-divider`、双 `.aca-info` 致谢块（左：导师/课题组/答辩委员会/合作医院；右[红竖条]：资助项目基金号 / DOI / 代码 / 数据）、Q&A 用 `.aca-insight`、版权用 `.card-soft`
- **内容适配规则**：致谢对象 3~4 项 + 资助基金号 + 论文 DOI/代码/数据链接 + Q&A 邀请；基金号用 `.mono` 红色

---

## 组件层（`shared/tokens.css` `.tpl-academic-defense` overlay）

| class | 作用 |
|------|------|
| `.aca-pagehead` | **学术页眉带**：深蓝 #003366 满宽底 + 红 #CC0000 左 6px 竖条 + 白色 kicker/页标题（核心装饰，替代 .bar-top） |
| `.aca-fact` / `.aca-num` / `.aca-label` / `.aca-delta` | 大数字卡（值/标签/增减） |
| `.aca-matrix` / `.aca-cell.hero` / `.aca-quadrant-*` / `.aca-axis-x` / `.aca-axis-y` | 2×2 研究矩阵 |
| `.aca-pipeline` / `.aca-step` / `.aca-step.hero` | 4-step 研究计划管道 |
| `.aca-table` / `.col-hero` | 硬边对比表（本文方法列红高亮） |
| `.aca-quarter` / `.aca-rag-dot` / `.aca-q-progress` / `.aca-q-bar` / `.aca-q-pct` | 阶段成果卡（RAG + 进度） |
| `.aca-risk` / `.aca-risk-risk` / `.aca-risk-mit` | 局限/未来工作双栏 |
| `.aca-tree-node.root` / `.leaf` | MECE 树节点 |
| `.aca-cover-meta` | 封面论文元数据 |
| `.aca-insight` | **观点条**：浅蓝灰 #E8F4FC 底 + 蓝色左竖条（研究意义/理由/关注项/结论） |
| `.aca-dot-divider` / `.aca-dot` | 装饰分割线：蓝色 + 装饰圆点 |
| `.aca-formula` / `.aca-eq-wrap` / `.aca-eq` / `.aca-eq-num` / `.aca-eq-caption` | **公式块**：`.mono` 占位 + 编号 (1)(2)（暂不用 katex） |
| `.aca-bignum` | 半透明大号编号（章节切换页背景装饰） |
| `.aca-header` / `.aca-header-org` / `.aca-header-crest` | **学术页眉条**：70px 深蓝 + 红 6px 竖条 + 机构栏 + 校徽位（封面/致谢签名） |
| `.aca-info` / `.aca-info-row` / `.aca-info-k` / `.aca-info-v` | **答辩人/致谢信息块**：姓名/学号/导师/机构/日期（封面）/ 致谢块（致谢） |
| `.aca-info-tag` / `.aca-info-pubid` | 研究方向标签 + 论文编号（封面角标） |
| `.aca-litcard` / `.aca-litcard-num` / `.aca-litcard-cite` / `.aca-litcard-claim` | **文献综述编号卡**：[n] + 作者年 + 观点 + 来源（05 文献综述身份证） |
| `.aca-cite` | **文中上标引用** [n]（全 deck 内联引用） |
| `.aca-baseline` / `.aca-bl-head` / `.aca-bl-ours` / `.aca-bl-delta` / `.aca-bl-metric` | **baseline vs ours 对比**：ours 列红高亮 + 提升% 红字（10 实验对比） |
| `.aca-roadmap` / `.aca-rm-stage` / `.aca-rm-io` / `.aca-rm-tag` | **研究技术路线图**：阶段卡 + 输入/方法/产出 + 箭头（08 身份证） |
| `.bar-left` / `.card-amber` / `.card-accent` / `.card-soft` | 装饰条 + 强调卡（通用层定义） |

> 所有 `aca-*` 组件颜色均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 切换时自动联动。推荐配套方案：`academic-green`（默认）、`government-blue`（同系深蓝）、`consulting-navy`（深蓝投行）。
