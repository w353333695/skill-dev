#!/usr/bin/env node
// validate-pptx.mjs — PPTX editable 导出预检工具
// 零依赖静态 HTML 扫描，在 html2pptx 转换前快速发现兼容性问题

'use strict';

import { readdirSync, readFileSync } from 'fs';
import { join, relative, basename } from 'path';
import { VOID_ELEMENTS, TEXT_CONTAINER_TAGS, IGNORED_TAGS, extractTagName, tokenize } from './_html-model.mjs';

// ── CLI ──────────────────────────────────────────────────────────────

function parseArgs(argv) {
  const args = { slidesDir: null, mode: 'all', quiet: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--slides' && argv[i + 1]) { args.slidesDir = argv[++i]; continue; }
    if (a === '--mode' && argv[i + 1]) { args.mode = argv[++i]; continue; }
    if (a === '--quiet') { args.quiet = true; }
    if (a === '--help' || a === '-h') {
      printUsage();
      process.exit(0);
    }
  }
  return args;
}

function printUsage() {
  console.log('Usage: node validate-pptx.mjs --slides <dir> [--mode editable|all] [--quiet]');
  console.log('');
  console.log('  --slides <dir>   Directory containing slide HTML files (required)');
  console.log('  --mode editable  Hybrid mode (default): CSS_GRADIENT/DIV_BG_IMAGE/SVG are WARNINGs');
  console.log('  --mode all       All checks are WARNINGs except DIV_BARE_TEXT/TEXT_STYLING');
  console.log('  --quiet          Only show ERRORs, suppress WARNINGs');
}

// ── Severity ─────────────────────────────────────────────────────────

// These checks are auto-handled by hybrid v2 export (screenshot background or native shapes).
// They remain WARNINGs — informational, never blocking.
const WARNING_SEVERITY_IN_EDITABLE_MODE = new Set([
  'SVG', 'MANUAL_BULLETS', 'CSS_GRADIENT', 'DIV_BG_IMAGE',
  'TEXT_EXTRACTION_FRAGMENTED', 'TEXT_EXTRACTION_LOW_COVERAGE', 'TEXT_STYLING'
]);
const WARNING_SEVERITY_IN_ALL_MODE = new Set(['SVG', 'MANUAL_BULLETS', 'CSS_GRADIENT', 'DIV_BG_IMAGE']);

function getSeverity(ruleId, mode) {
  if (mode === 'editable') {
    // hybrid mode: only text structure issues are hard errors
    if (WARNING_SEVERITY_IN_EDITABLE_MODE.has(ruleId)) return 'WARNING';
    return 'ERROR';
  }
  if (WARNING_SEVERITY_IN_ALL_MODE.has(ruleId)) return 'WARNING';
  return 'ERROR';
}

// ── Utilities ────────────────────────────────────────────────────────

function getLineNumber(html, offset) {
  let line = 1;
  for (let i = 0; i < offset && i < html.length; i++) {
    if (html[i] === '\n') line++;
  }
  return line;
}

function getColumnNumber(html, offset) {
  let col = 1;
  for (let i = offset - 1; i >= 0; i--) {
    if (html[i] === '\n') break;
    col++;
  }
  return col;
}

function loadHTMLFiles(dir) {
  const files = readdirSync(dir).filter(f => f.endsWith('.html')).sort();
  return files.map(f => ({
    name: f,
    path: join(dir, f),
    html: readFileSync(join(dir, f), 'utf-8'),
  }));
}

// ── C1: SVG Elements ────────────────────────────────────────────────

function checkSVG(html) {
  const findings = [];
  const re = /<svg[\s>]/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    findings.push({
      offset: m.index,
      rule: 'SVG',
      message: 'SVG element found. Not supported in editable PPTX export — use <img> with pre-rendered PNG instead.',
    });
  }
  return findings;
}

// ── C2: DIV Bare Text ───────────────────────────────────────────────

function checkDivBareText(html) {
  const findings = [];
  const tokens = tokenize(html);
  const tagStack = [];

  for (const token of tokens) {
    if (token.type === 'TAG_OPEN') {
      tagStack.push({ tagName: token.tagName, offset: token.offset });
    } else if (token.type === 'TAG_CLOSE') {
      const idx = tagStack.findLastIndex(t => t.tagName === token.tagName);
      if (idx >= 0) tagStack.splice(idx, 1);
    } else if (token.type === 'TEXT') {
      const trimmed = token.text.trim();
      if (!trimmed) continue;

      for (let i = tagStack.length - 1; i >= 0; i--) {
        const { tagName } = tagStack[i];
        if (VOID_ELEMENTS.has(tagName)) continue;
        if (IGNORED_TAGS.has(tagName)) break;
        if (TEXT_CONTAINER_TAGS.has(tagName)) break;

        if (tagName === 'div') {
          const preview = trimmed.substring(0, 50) + (trimmed.length > 50 ? '...' : '');
          findings.push({
            offset: token.offset,
            rule: 'DIV_BARE_TEXT',
            message: `DIV contains unwrapped text "${preview}". All text must be wrapped in <p>, <h1>-<h6>, <ul>, or <ol>.`,
          });
        }
        break;
      }
    }
  }
  return findings;
}

// ── C3: CSS Gradients ───────────────────────────────────────────────

function checkCSSGradients(html) {
  const findings = [];
  const gradientRe = /linear-gradient\s*\(|radial-gradient\s*\(/gi;

  // Check <style> blocks
  const styleBlockRe = /<style[^>]*>([\s\S]*?)<\/style>/gi;
  let sm;
  while ((sm = styleBlockRe.exec(html)) !== null) {
    const blockContent = sm[1];
    const blockOffset = sm.index + sm[0].indexOf('>') + 1;
    let gm;
    gradientRe.lastIndex = 0;
    while ((gm = gradientRe.exec(blockContent)) !== null) {
      findings.push({
        offset: blockOffset + gm.index,
        rule: 'CSS_GRADIENT',
        message: `CSS gradient (${gm[0].replace(/\s*\(.*$/, '')}) found in <style> block. Gradients are not supported — use solid colors or pre-rendered PNG.`,
      });
    }
  }

  // Check inline style attributes
  gradientRe.lastIndex = 0;
  const inlineStyleRe = /<([a-zA-Z][a-zA-Z0-9]*)[^>]*style="([^"]*)"/gi;
  let im;
  while ((im = inlineStyleRe.exec(html)) !== null) {
    const styleVal = im[2];
    gradientRe.lastIndex = 0;
    let gm;
    while ((gm = gradientRe.exec(styleVal)) !== null) {
      findings.push({
        offset: im.index,
        rule: 'CSS_GRADIENT',
        message: `CSS gradient found in inline style on <${im[1]}>. Gradients are not supported — use solid colors or pre-rendered PNG.`,
      });
    }
  }
  return findings;
}

// ── C4: Text Elements with bg/border/shadow ────────────────────────

const TEXT_TAGS_RE = /<(p|h[1-6]|li|ul|ol)(?:\s[^>]*)?style="([^"]*)"/gi;

function checkTextElementStyles(html) {
  const findings = [];
  let m;
  while ((m = TEXT_TAGS_RE.exec(html)) !== null) {
    const tag = m[1].toLowerCase();
    const style = m[2];

    const violations = [];
    // Check background (not 'none' or 'transparent')
    if (/\bbackground(?:-color)?\s*:\s*(?!transparent|none)/i.test(style) && !/\bbackground(?:-color)?\s*:\s*transparent/i.test(style)) {
      violations.push('background');
    }
    // Check border with width
    if (/\bborder(?:-\w+)?\s*:\s*[^;]*\d/.test(style)) {
      violations.push('border');
    }
    // Check box-shadow
    if (/\bbox-shadow\s*:\s*(?!none)/i.test(style)) {
      violations.push('box-shadow');
    }

    if (violations.length > 0) {
      findings.push({
        offset: m.index,
        rule: 'TEXT_STYLING',
        message: `Text element <${tag}> has ${violations.join('/')}. Move styling to a wrapping <div> instead.`,
      });
    }
  }
  return findings;
}

// ── C5: DIV with background-image ───────────────────────────────────

const DIV_BGIMG_RE = /<div(?:\s[^>]*)?style="([^"]*)"/gi;

function checkDivBackgroundImage(html) {
  const findings = [];
  let m;
  while ((m = DIV_BGIMG_RE.exec(html)) !== null) {
    const style = m[1];
    if (/(?:^|;)\s*background(?:-image)?\s*:[^;]*url\s*\(/i.test(style)) {
      findings.push({
        offset: m.index,
        rule: 'DIV_BG_IMAGE',
        message: 'DIV has background-image. Use <img> tag instead — background-image on DIV is not supported in PPTX.',
      });
    }
  }
  return findings;
}

// ── C6: Manual Bullet Symbols ──────────────────────────────────────

const BULLET_RE = /^\s*[•\-*▪▸○●◆◇■□]\s/;
const BULLET_TEXT_TAGS_RE = /<(p|h[1-6])(?:\s[^>]*)?>([\s\S]*?)<\/\1>/gi;

function checkManualBullets(html) {
  const findings = [];
  let m;
  while ((m = BULLET_TEXT_TAGS_RE.exec(html)) !== null) {
    const tag = m[1].toLowerCase();
    // Strip child tags to get raw text
    const inner = m[2].replace(/<[^>]*>/g, '').trim();
    if (BULLET_RE.test(inner)) {
      const preview = inner.substring(0, 30) + (inner.length > 30 ? '...' : '');
      findings.push({
        offset: m.index,
        rule: 'MANUAL_BULLETS',
        message: `Text element <${tag}> starts with manual bullet symbol "${preview}". Use <ul>/<ol> lists instead.`,
      });
    }
  }
  return findings;
}

// ── Run all checks ───────────────────────────────────────────────────

function runChecks(html) {
  return [
    ...checkSVG(html),
    ...checkCSSGradients(html),
    ...checkTextElementStyles(html),
    ...checkDivBackgroundImage(html),
    ...checkManualBullets(html),
    ...checkTextExtractionCoverage(html),
  ];
}

// ── C7: Text extraction coverage simulation ───────────────────────────
// Simulates what html2pptx.js would extract — p/h*/li text from body.
// Flags cases where visible text is much larger than extractable text,
// suggesting content in divs/spans that would be lost in PPTX export.

function extractTextFromBody(html) {
  const bodyMatch = html.match(/<body[^>]*>([\s\S]*)<\/body>/i)
    || html.match(/<body[^>]*>([\s\S]*)$/i);
  if (!bodyMatch) return '';
  let body = bodyMatch[1];
  // Remove aside.notes (speaker notes — not for PPTX)
  body = body.replace(/<aside[^>]*class\s*=\s*["'][^"']*\bnotes\b[^"']*["'][^>]*>[\s\S]*?<\/aside\s*>/gi, '');
  body = body.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  body = body.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
  return body;
}

function extractExtractableText(html) {
  // Simulate html2pptx.js extraction: only p, h1-h6, li text content.
  // Uses tokenize() for proper tag-depth-aware extraction — handles nested
  // div>div>p structures correctly, unlike simple regex which can miss or
  // duplicate text when same tags are nested.
  const body = extractTextFromBody(html);
  const tokens = tokenize(body);
  const textRuns = [];
  const TEXT_TAGS = new Set(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li']);
  const stack = []; // { tagName, textContent: [] }

  for (const token of tokens) {
    if (token.type === 'TAG_OPEN' && TEXT_TAGS.has(token.tagName)) {
      stack.push({ tagName: token.tagName, texts: [] });
    } else if (token.type === 'TAG_CLOSE' && TEXT_TAGS.has(token.tagName)) {
      // Find matching open tag (innermost matching tag name)
      let idx = -1;
      for (let i = stack.length - 1; i >= 0; i--) {
        if (stack[i].tagName === token.tagName) { idx = i; break; }
      }
      if (idx >= 0) {
        const entry = stack[idx];
        const inner = entry.texts.join('').replace(/\s+/g, ' ').trim();
        if (inner.length > 0) textRuns.push(inner);
        // Pop this and any nested entries
        stack.splice(idx);
      }
    } else if (token.type === 'TEXT' && stack.length > 0) {
      // Strip HTML tags from text (child elements' text is captured separately)
      const clean = token.text.replace(/<[^>]+>/g, '');
      if (clean.trim().length > 0) {
        stack[stack.length - 1].texts.push(clean);
      }
    }
    // Non-text-container open/close tags: ignore (text falls to innermost text container on stack)
  }

  return textRuns;
}

function countVisibleTextChars(html) {
  const body = extractTextFromBody(html);
  return body.replace(/<[^>]+>/g, '').replace(/\s/g, '').length;
}

function checkTextExtractionCoverage(html) {
  const findings = [];
  const extractableRuns = extractExtractableText(html);
  const extractableChars = extractableRuns.reduce((s, t) => s + t.replace(/\s/g, '').length, 0);
  const visibleChars = countVisibleTextChars(html);

  // If visible text exists but extraction found nothing, flag it
  if (visibleChars >= 20 && extractableRuns.length === 0) {
    findings.push({
      offset: 0,
      rule: 'TEXT_EXTRACTION_EMPTY',
      message: `Visible text is ${visibleChars} chars but no extractable p/h*/li text found. PPTX will lose all slide content.`,
    });
  }

  // If extractable text covers < 50% of visible text, content may be lost
  if (extractableChars > 0 && visibleChars > 50) {
    const coverage = Math.round((extractableChars / visibleChars) * 100);
    if (coverage < 50) {
      findings.push({
        offset: 0,
        rule: 'TEXT_EXTRACTION_LOW_COVERAGE',
        message: `Extractable text covers only ${coverage}% of visible text (${extractableChars}/${visibleChars} chars). Content in divs/spans will be lost in editable PPTX.`,
      });
    }
  }

  // Check for deeply nested text: p inside div inside div — extraction should still work
  // but flag cases with suspiciously many text runs (fragmented extraction)
  if (extractableRuns.length > 30) {
    findings.push({
      offset: 0,
      rule: 'TEXT_EXTRACTION_FRAGMENTED',
      message: `${extractableRuns.length} individual text runs extracted. Text may appear fragmented in PPTX. Consider consolidating into fewer p/h* blocks.`,
    });
  }

  return findings;
}

// ── Reporter ─────────────────────────────────────────────────────────

const SEVERITY_COLORS = { ERROR: '\x1b[31m', WARNING: '\x1b[33m' };
const RESET = '\x1b[0m';

function report(fileFindings, mode, quiet) {
  let totalErrors = 0;
  let totalWarnings = 0;

  for (const { name, html, findings } of fileFindings) {
    const classified = findings.map(f => ({
      ...f,
      line: getLineNumber(html, f.offset),
      col: getColumnNumber(html, f.offset),
      severity: getSeverity(f.rule, mode),
    }));

    const errors = classified.filter(f => f.severity === 'ERROR');
    const warnings = classified.filter(f => f.severity === 'WARNING');

    if (errors.length === 0 && (quiet || warnings.length === 0)) continue;

    console.log(`\n${name}:`);

    for (const f of classified) {
      if (quiet && f.severity === 'WARNING') continue;
      const color = SEVERITY_COLORS[f.severity];
      const tag = f.severity.padEnd(7);
      console.log(`  L${String(f.line).padStart(4)}  ${color}${tag}${RESET}  ${f.rule}: ${f.message}`);
    }

    totalErrors += errors.length;
    totalWarnings += warnings.length;
  }

  if (totalErrors === 0 && totalWarnings === 0) {
    console.log('\n✓ All checks passed — no PPTX compatibility issues found.');
  } else {
    const parts = [];
    if (totalErrors > 0) parts.push(`${totalErrors} error${totalErrors > 1 ? 's' : ''}`);
    if (totalWarnings > 0) parts.push(`${totalWarnings} warning${totalWarnings > 1 ? 's' : ''}`);
    console.log(`\n✗ ${parts.join(', ')} found.`);
  }

  return totalErrors;
}

// ── Main ─────────────────────────────────────────────────────────────

function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.slidesDir) {
    console.error('Error: --slides <dir> is required.\n');
    printUsage();
    process.exit(1);
  }

  if (args.mode !== 'editable' && args.mode !== 'all') {
    console.error(`Error: unknown mode "${args.mode}". Use "editable" or "all".\n`);
    printUsage();
    process.exit(1);
  }

  let files;
  try {
    files = loadHTMLFiles(args.slidesDir);
  } catch (e) {
    console.error(`Error: cannot read directory "${args.slidesDir}": ${e.message}`);
    process.exit(1);
  }

  if (files.length === 0) {
    console.error(`Error: no HTML files found in "${args.slidesDir}".`);
    process.exit(1);
  }

  const fileFindings = files.map(f => ({
    name: f.name,
    html: f.html,
    findings: runChecks(f.html),
  }));

  const totalFindings = fileFindings.reduce((s, f) => s + f.findings.length, 0);
  console.log(`Scanning ${files.length} HTML file${files.length > 1 ? 's' : ''} in ${args.slidesDir}...`);

  const errorCount = report(fileFindings, args.mode, args.quiet);
  process.exit(errorCount > 0 ? 1 : 0);
}

main();
