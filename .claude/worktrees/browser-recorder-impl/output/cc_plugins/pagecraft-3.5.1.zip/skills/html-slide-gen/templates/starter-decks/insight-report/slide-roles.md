# insight-report — Slide Role Catalog

> **模板气质**：行业/数据研究报告体裁（McKinsey/BCG 行业洞察 + 学术报告的克制可打印调性）—— 白底（省墨可打印）+ 深海蓝墨色主色 + 蓝色数据色 + 少量 amber 强调（仅 BLUF 关键数字）、**结论先行（BLUF）**、图表为主、Fig./Source 标注规范、近直角硬边、无阴影、扫描可读。
> **默认 color-scheme**：`ocean-depths`（深海蓝 `#0a2540` + 数据蓝 `#1d4ed8` + slate + amber 强调，白底，可打印）。
> **switch-theme**：已接入。`shared/tokens.css` 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 为换肤入口；所有 `ir-*` 组件与语义 token 均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 一键切换。适合切换为 `consulting-navy`（深蓝投行）、`mckinsey-blue`、`midnight-ink` 等。
> **适用文稿类型**：信息同步（观点输出）—— 行业洞察报告、市场/数据研究报告、趋势白皮书、年度行业复盘（面向决策者输出观点）。
> **叙事结构（14 页，BLUF 结论先行，非 SCQA）**：cover → toc → executive-summary(BLUF) → background(背景) → methodology(方法论) → finding-1/2/3(发现①②③) → data-deepdive(数据深挖) → comparison(厂商对比) → impact(趋势与影响) → recommendations(建议) → next-steps(局限与展望) → appendix(附录+封底)。
>
> 03（BLUF 执行摘要）/ 05（方法论）/ 14（附录+封底）为本 deck **特色/身份证角色页**，是区别于 consultant-strategy 的核心标志。**标志组件**：`.exec-summary`(BLUF 框) / `.research-chart`(Fig.图表容器) / `.appendix-block`(附录) / `.finding-card`(发现卡) —— 四者共同构成研究报告的版式身份证。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 研究报告封面：刊头(机构+系列) + 报告标题/副标题 + BLUF 预告 + 右侧渗透率曲线 + 底部报告元数据(机构/日期/编号/版本) | `.bar-top`, `.eyebrow`, `.h1`(含 `<wbr>` CJK), `.lede`, 抽象 SVG 曲线, `.ir-cover-meta` |
| 02 | `toc` | 目录：12 章双栏编号列表 + 页码 | `.ir-pagehead`, `.ir-toc-item`(`.ir-toc-n`/`title`/`desc`/`page`) |
| 03 | `executive-summary` | **BLUF 执行摘要（身份证）**：一句话核心结论 + 3 关键数字条 + 3 支撑要点 | **`.exec-summary`**(`.ir-bluf-tag`/`.ir-conclusion`/`.ir-keynums`/`.ir-support`) |
| 04 | `background` | 市场背景：左 mega 数字 + 右 4 项结构 stat(2×2) + 观察条 | `.ir-stat`(`.ir-stat-val`/`lbl`/`delta`), `.card.card-accent`, `.card.card-warn`, `.gradient-text` |
| 05 | `methodology` | **方法论（独有页）**：4 宫格(范围/方法/样本/模型) + 研究局限 + 数据来源索引 | `.ir-method-grid`/`.ir-method-item`, `.appendix-block`(局限+来源) |
| 06 | `finding-1` | 发现①：左 `.finding-card` + 右 `.research-chart`(补贴 vs 渗透率 Fig.1) | **`.finding-card`**(`.ir-find-num`/`stat`/`evidence`/`impl`), **`.research-chart`**(`.ir-fig`/`.ir-source`/`.ir-legend`) |
| 07 | `finding-2` | 发现②：左 `.research-chart`(价格带堆叠 Fig.2) + 右 `.finding-card` | **`.research-chart`**, **`.finding-card`** |
| 08 | `finding-3` | 发现③：左 `.finding-card` + 右 `.research-chart`(出口区域堆叠 Fig.3) | **`.finding-card`**, **`.research-chart`** |
| 09 | `data-deepdive` | 数据深挖：大幅 `.research-chart`(BEV vs PHEV 双线+预测带 Fig.4) | **`.research-chart`**, 预测区间 `<rect>`, 双色线 |
| 10 | `comparison` | 厂商对比：TOP8 市场结构表 + 三类玩家洞察卡 | `.ir-cmptable`(硬边表, 表头蓝底白字), `.card.card-accent`×3 |
| 11 | `impact` | 趋势与影响：L27 bento 6 变量(1 大+4 小+1 宽，1 个 amber 大卡) | bento `grid`, `.card.card-warn`(最大变量), `.card.card-accent` |
| 12 | `recommendations` | 行动建议：4 ir-rec 行(编号+建议+依据发现+优先级+预期影响) + 角色映射条 | `.ir-rec-row`(`.ir-rec-n`/`title`/`body`/`pri`/`impact`), `.pill-accent` |
| 13 | `next-steps` | 局限与展望：3 阶段时间轴(局限/短期跟进/中长期) + 三情景表 + 订阅 | `.ir-stp-row`/`.ir-stp`, 三情景列, `.card.card-accent` |
| 14 | `appendix` | **附录+封底（身份证）**：3 栏附录(假设/来源/术语) + 封底报告信息(作者/联系/免责/版本) | **`.appendix-block`**(`.ir-appx-list`/`.ir-gloss`), **`.ir-colophon`** |

---

## 角色详情

### 01 — `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`institute`, `series`, `report_type`, `headline`, `subtitle`, `bluf_tag`, `bluf_preview`, `bluf_num`, `meta_inst/date/no/ver`（+ 各 `_lbl`）, `footer_source`
- **不可改动**：顶部刊头分隔线(absolute)、`.h1` 78px、右侧 SVG 渗透率曲线 viewBox 坐标、`.ir-cover-meta` 4 列网格(absolute bottom:74px)、报告式刊头（**非** consultant 的 bar-left+项目代码结构）
- **内容适配规则**：
  - `headline` CJK 大标题用 `<wbr>` 接管换行（不写 `<br>`），保持 keep-all+balance
  - `bluf_num` 为封面预告的关键数字，用 amber 强调（与内页 BLUF 一致）
  - `meta_*` 四项是报告身份证（机构/日期/编号/版本），增减同步调整 grid 列数

### 02 — `toc`
- **可替换键**：`kicker`, `title`, `t1~12_title/desc`（12 章）, `footer_source`（页码写死 03–14，随章节调整）
- **不可改动**：`.grid.g2` 双栏、`.ir-toc-item` 编号+标题+描述+页码四段式、`border-bottom` 分隔
- **内容适配规则**：12 个章节项，增删同步动 `index.html` iframe 列表与各页 `page-num`

### 03 — `executive-summary`（BLUF · 身份证页）
- **可替换键**：`kicker`, `title`, `bluf_tag`, `conclusion`（含内嵌 `<span class="hl">`/`hl-blue` 高亮）, `c_pen`/`c_sales`/`c_yoy`/`c_shift`, `kn1~3_val/lbl`, `sup1~3`
- **不可改动**：`.exec-summary` 左 5px 蓝竖边 + 硬边框、`.ir-bluf-tag` 蓝底白字标签、`.ir-conclusion` 33px、`.ir-keynums` 3 等分数字条、`.ir-support` 3 列编号要点
- **内容适配规则**：
  - `conclusion` 是整报告的"金字塔顶/BLUF"，必须一句话含核心判断 + 量化结论，内嵌 `<span class="hl">`(amber) / `<span class="hl-blue">`(蓝) 高亮关键数据，替换时保留 span
  - `kn*` 3 个关键数字（值+单位+标签），`warn`/默认/`good` 三色对应负向/中性/正向
  - `sup1~3` 是结论的 3 条证据骨架，编号 01/02/03（对应后续发现页）

### 04 — `background`
- **可替换键**：`kicker`, `title`, `big_lbl/val/delta/note`, `s1~4_val/lbl/d`, `ins_tag/ins_body`, `footer_source`
- **可替换键**：4 项结构 stat 每项含 值/标签/delta（`.ir-stat-delta.up`/`.down` 绿/红）
- **不可改动**：左 mega 数字 138px + `.gradient-text`、右 2×2 stat 网格、`.card.card-warn` 观察条
- **内容适配规则**：4 stat 卡，`s*_val` 控制在 6 字内（如"1,720万辆"），delta 含方向箭头

### 05 — `methodology`（独有页）
- **可替换键**：`kicker`, `title`, `sub`, `m1~4_tag/title/body`（4 宫格）, `lim_head`, `lim1~3`, `src_head`, `src1~5`, `src_meta`, `footer_source`
- **不可改动**：`.ir-method-grid` 4 等宽宫格(顶 3px 蓝边)、`.appendix-block` 双栏(局限+来源)、`.ir-appx-list` 的 `k`(D1–D5/L1–L3) 编号
- **内容适配规则**：方法论页是研究报告区别于咨询 deck 的标志（咨询无方法论页）；4 宫格固定（范围/方法/样本/模型），`m*_body` 内 `<span class="n">` 标注量化（样本量/阈值）

### 06~08 — `finding-1/2/3`（发现①②③）
- **可替换键**：`kicker`, `title`, `find_num`(①/②/③), `find_tag`, `find_title`, `find_stat`(+`u`), `find_evidence`, `impl_lbl`, `impl_body`, 图表侧 `fig`/`chart_title`/`leg1~4`/`chart_src`/`chart_body`, `footer_source`
- **不可改动**：`.finding-card` 圆形编号徽章(`.ir-find-num` 46px)、`.ir-find-stat` 40px、`.ir-find-impl` 蓝底启示条、`.research-chart` 的 Fig.编号 + 来源标注 + 图例三段式结构
- **内容适配规则**：
  - 三页左右镜像（06/08 图在右，07 图在左），保持视觉节奏
  - `find_num` = ①/②/③（U+2460，非 emoji），`find_stat` 用 `warn`/`good`/默认色
  - 每页 `.research-chart` 必须有 `Fig.N` 编号 + `.ir-source` 来源 + `.ir-legend` 图例
  - 图表 SVG 内所有颜色用 `var(--accent)`/`var(--accent-2)`/`var(--warn)`/`var(--grid-line)`/`var(--axis-line)`，不写死 hex

### 09 — `data-deepdive`
- **可替换键**：`kicker`, `title`, `sub`, `fig`(Fig.4), `chart_title`, `leg1~3`, `chart_src`, SVG 内数据点, `footer_source`
- **不可改动**：大幅 `.research-chart` 横跨全宽、预测区间 `<rect>`+虚线分隔、BEV(navy)/PHEV(amber) 双线
- **内容适配规则**：预测线落在"预测区间"灰带内（2025 之后），`leg3` 标注情景；Y 轴标签 + 轴标题"销量（万辆）"

### 10 — `comparison`
- **可替换键**：`kicker`, `title`, `sub`, `h_rank/name/share/vol/yoy/tech/band`（7 列头）, `r1~8_rank/name/share/vol/yoy/tech/band`（8 行）, `g1~3_tag/body`, `footer_source`
- **不可改动**：`.ir-cmptable` 表头蓝底白字、同比列 `.up`(绿)/`.down`(红)、底部 3 卡三类玩家
- **内容适配规则**：TOP8 厂商市场结构表（份额/销量/同比/技术/价格带），如增删行同步调整排名色；这是研究报告市场结构分析表（**非** consultant 的方案择优表）

### 11 — `impact`
- **可替换键**：`kicker`, `title`, `b1_tag/title/body/n1/n1l/n2/n2l`（大卡）, `b2~5_tag/title/body`（4 小卡）, `b6_n/title/body`（宽卡）, `footer_source`
- **不可改动**：L27 bento `grid-template-columns:repeat(4,1fr)` + `grid-auto-rows:175px`、大卡 `span 2/2`、宽卡 `span 2`、`.card.card-warn` 标记最大变量
- **内容适配规则**：6 个 2026 趋势变量（1 大 + 4 小 + 1 宽），大卡含 2 个量化数字；最大变量用 amber 大卡突出

### 12 — `recommendations`
- **可替换键**：`kicker`, `title`, `sub`, `r1~4_n/t/b/p/i`（4 行 ×5）, `map_tag/map_body`, `footer_source`
- **不可改动**：`.ir-rec-row` 4 列(编号/建议/优先级/影响) + 左 4px 蓝边、`.ir-rec-pri.p0`(amber)/`p1`(蓝)/`p2`(灰) 三级优先级
- **内容适配规则**：4 项建议，每项 `r*_b` 标注"依据发现 N"回链证据；`r*_i` 预期影响用 `<b>` 加粗关键数字

### 13 — `next-steps`
- **可替换键**：`kicker`, `title`, `track_lbl`, `q1/q2/q3`（阶段标签/标题/正文）, `sc_tag`, `sc1~3_l/v/d`, `sc_note`, `sub_tag/title/body/contact/cta`, `footer_source`
- **不可改动**：`.ir-stp-row` 3 阶段等宽时间轴（左红=局限/中蓝=跟进/右深蓝=中长期）、三情景列(悲/基/乐 = bad/accent/good)
- **内容适配规则**：研究局限明确披露（ESOMAR），三情景对应悲观/基准/乐观，`sc2` 标注"本报告采用"

### 14 — `appendix`（附录+封底 · 身份证页）
- **可替换键**：`kicker`, `title`, `a1_head`, `a1_1~5`(假设), `a2_head`, `a2_1~7`(来源) + `a2_note`, `a3_head`, `a3_t1~6`/`a3_d1~6`(术语), `c1~4_tag/body`(封底 4 块: 作者/联系/免责/版本), `footer_source`
- **不可改动**：`.appendix-block` 3 栏(假设/来源/术语)、`.ir-gloss` 术语 `<dl>` 双列、`.ir-colophon` 封底 4 块 + 上下双线分隔
- **内容适配规则**：
  - 附录是研究报告身份证（**非** consultant 的 16-thanks 4 联系人卡）
  - `.ir-colophon` 封底报告信息（作者团队/联系方式/免责声明/版本号）—— 一眼可辨是研究报告而非咨询/政务
  - 术语表用 `<dl>`，来源用 `.ir-appx-list` 的 `k`(H/D) 编号

---

## 组件层（`shared/tokens.css` `.tpl-insight-report` overlay）

| class | 作用 |
|------|------|
| **`.exec-summary`** / `.ir-bluf-tag` / `.ir-conclusion` / `.ir-keynums` / `.ir-support` | **标志组件①**：BLUF 执行摘要框（结论先行） |
| **`.research-chart`** / `.ir-fig` / `.ir-chart-title` / `.ir-source` / `.ir-legend` / `.ir-axis` | **标志组件②**：研究报告图表容器（Fig.编号 + 来源 + 图例） |
| **`.appendix-block`** / `.ir-appx-head` / `.ir-appx-list` / `.ir-gloss` | **标志组件③**：附录块（方法论/来源/术语，小字可打印） |
| **`.finding-card`** / `.ir-find-num` / `.ir-find-stat` / `.ir-find-evidence` / `.ir-find-impl` | **标志组件④**：发现卡（编号①②③ + 证据 + 启示） |
| `.ir-pagehead` | 页头（kicker + h2 + sub） |
| `.ir-method-grid` / `.ir-method-item` | 方法论 4 宫格（独有页） |
| `.ir-toc-item` | 目录条目（编号+标题+描述+页码） |
| `.ir-rec-row` / `.ir-rec-pri` | 建议行（优先级 P0/P1/P2） |
| `.ir-stp-row` / `.ir-stp` | 下一步三阶段时间轴 |
| `.ir-cover-meta` | 封面报告元数据（机构/日期/编号/版本） |
| `.ir-colophon` | 封底报告信息（作者/联系/免责/版本） |
| `.ir-stat` | 背景 stat 块（大数字 + 标签 + delta） |
| `.ir-cmptable` | 厂商对比表（硬边 + 蓝表头） |
| `.card` / `.card-accent` / `.card-warn` / `.pill` / `.pill-accent` / `.pill-warn` | 通用卡片/药丸（覆盖层重定义观感） |
| `.bar-top` / `.divider-accent` / `.gradient-text` | 装饰条/分割/渐变字（通用层） |

> 所有 `ir-*` 组件颜色均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 切换时自动联动。推荐配套方案：`ocean-depths`（默认，深海蓝可打印）、`mckinsey-blue`（麦肯锡蓝）、`consulting-navy`（深蓝投行）、`midnight-ink`（午夜墨蓝）。

---

## 差异化声明（vs 现有 deck）

- **≠ consultant-strategy**：咨询用 SCQA + 2×2矩阵 + 方案择优；本 deck 用 BLUF 结论先行 + 方法论页 + 发现卡 + 附录页，有咨询所没有的方法论页(p.05)和附录页(p.14)
- **≠ xhs-white-editorial**：那是轻图文风；本 deck 是严肃可打印研究报告（白底深墨蓝 + Fig./Source 规范 + 小字附录）
- **≠ weekly-report**：那是内部团队同步（细粒度 KPI）；本 deck 面向决策者输出观点（BLUF + 研究）
- **封面**：研究报告式（机构+系列+报告标题+编号+版本+渗透率曲线），非红头文件非人员卡
- **封底**：报告信息块（作者团队/联系方式/免责声明/版本号）+ 附录，非人员小卡片网格
