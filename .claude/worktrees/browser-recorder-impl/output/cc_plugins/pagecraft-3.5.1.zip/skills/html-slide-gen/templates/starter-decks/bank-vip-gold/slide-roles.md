# bank-vip-gold — Slide Role Catalog

> **模板气质**：金融 VIP 高端汇报风（极简轻奢）—— 白底 + 招行红 + 辅助金、精致双线装饰、多层同心圆、微点阵纹理、菱形分割、四角安全区定位点、顶部观点条、暖灰/浅红卡片、克制留白、结论先行。
> **默认 color-scheme**：`cmb-gold-red`（招行红 `#c41230` + 辅助金 `#c9a962` + 深红 `#9a0e26` + 白底）。
> **switch-theme**：已接入。`shared/tokens.css` §2 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 为换肤入口；所有 `bank-*` 组件与语义 token 均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 一键切换。适合切换为 `consulting-navy`（深蓝投行风）等。
> **适用文稿类型**：说服 / 决策（VIP 客户年度财富汇报、私人银行资产配置建议书、家族财富规划、高净值客户服务）。
> **叙事骨架（财富管理汇报体裁，非 SCQA）**：客户全景 → 资产配置 → 市场展望 → 产品推荐 → 财富规划。
> **叙事结构（16 页，按出现顺序）**：cover → toc → executive-summary → situation → complication → question → chapter-divider → framework → recommendation → data-deepdive → comparison-table → process-flow → quarterly-review → risks-mitigation → next-steps → thanks。
>
> 01–03 为「开篇」（精致轻奢封面 + 议程 + 客户全景综述）；04 为「客户画像/资产现状」（KYC + 配置环形图，**金融身份证**）；05–06 为「市场诊断」（挑战 + 财富主线 MECE）；07 为「章节切换」（深红全屏）；08–12 为「配置方案」（**核心-卫星配置图** + **产品货架** + **净值曲线** + 对比 + 投资路径）；13–15 为「治理」（季度复盘 + 风险矩阵/应对 + 90 天规划）；16 为「收束」（顾问团队 + 预约 + 合规）。**标志版式（金融身份证）：04 配置环形图 / 08 核心-卫星图 / 09 产品货架 / 10 净值曲线**，取代 consultant 的矩阵+方案卡。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 精致轻奢封面：白底+底部暖灰带 + 红条金双线 + 左上多层圆环 + 右侧竖装饰线 + 圆角框标题(菱形分割) + 客户尊享标识 + 财富顾问卡 + 私密等级 | `.bank-warmband`, `.bank-dbl-top`, `.bank-rings`, `.bank-vline`, `.bank-title-box`, `.bank-diamond`, `.bank-vip-badge`, `.bank-advisor`, `.bank-privacy`, `.bank-doubleline` |
| 02 | `toc` | 议程：6 章节双栏清单 + 大号红字编号 + 金色下划线 | `.bank-pagehead`, `.bank-goldline`, `.h2.mono`(编号), `.h3`(章节标题), `border-bottom` 金线 |
| 03 | `executive-summary` | 客户全景综述（金字塔顶）：一句话核心结论 + 3 配置支柱卡 | `.card.card-amber`(结论条), `.grid.g3`, `.card.card-accent`, `.pill-accent`, `.h3.mono`(指标) |
| 04 | `situation` | **客户画像/资产现状（金融身份证）**：左 KYC 画像多维标签 + 右资产配置环形图 + 洞察条 | `.bank-kyc`(`.bank-kyc-tag`), `.bank-alloc`(`.bank-alloc-donut` conic-gradient + `.bank-alloc-legend`), `.card-soft`(洞察) |
| 05 | `complication` | 市场挑战：3 列挑战卡（利率下行/波动/通胀） + 影响数字 + 证据脚注 | `.grid.g3`, `.card-amber`, `.pill-amber`, `.h2.mono`(影响) |
| 06 | `question` | 财富主线：MECE 树状分解（1 root → 3 leaf） | `.bank-tree-node.root`/`.leaf`, inline SVG 连接线 |
| 07 | `chapter-divider` | 章节切换：深红全屏 + 居中大字章节号/标题 + 左侧金竖条 + 右侧金阶梯 | `background:var(--accent-2)`, `.h1`(110px 白), 金色装饰条 |
| 08 | `framework` | **资产配置框架（核心-卫星，金融身份证）**：同心三层圆配置图（核心/压舱/卫星）+ 右侧三层逻辑卡 | `.bank-coresat`(`.bank-cs-ring`×3 + `.bank-cs-core` + `.bank-cs-asset` 资产标), `.card` 三层逻辑 |
| 09 | `recommendation` | **产品推荐货架（金融身份证）**：分层货架（稳健层 R2 + 进取层 R3-R4）+ 产品卡陈列 + 主推 hero 金标 | `.bank-shelf`(`.bank-shelf-row`/`.bank-shelf-board`/`.bank-product.hero`), `.bank-product-flag`(★主推), `.card-soft`(理由) |
| 10 | `data-deepdive` | 业绩深潜：左净值/收益曲线（SVG） + 右大数字 + 3 收益来源拆解卡 | `.bank-nav-curve`(SVG inline 净值曲线 + 基准 + 通胀), `.card-accent`, `.card-amber`(来源) |
| 11 | `comparison-table` | 配置对比表：6 维度硬边表，推荐列金高亮 | `.bank-table`(硬边, 表头红底白字, `.col-hero` 金列), `caption` |
| 12 | `process-flow` | 投资路径：3 阶段时间轴 + 里程碑 + 图例 | 时间轴(绝对定位线 + 圆点节点), `.card`/`.card-amber`(阶段卡), `.eyebrow`(阶段标签) |
| 13 | `quarterly-review` | 季度业绩复盘（特色页）：4 季度卡 + RAG 状态点 + 完成率进度条 + 关注项 | `.bank-quarter`, `.bank-rag-dot`(G/A), `.bank-q-progress`/`.bank-q-bar`, `.bank-q-pct`, `.card-soft`(关注项) |
| 14 | `risks-mitigation` | 风险提示：顶部风险等级×收益定位矩阵 + 3 风险卡风险/应对合规双栏 | `.bank-risk-matrix`(`.bank-rm-cell`/`.bank-rm-low`/`.bank-rm-high`), `.bank-risk`(`.bank-risk-risk`/`.bank-risk-mit`) |
| 15 | `next-steps` | 财富规划：4-step pipeline（首步 hero） + 确认清单 | `.bank-pipeline`, `.bank-step.hero`, `.bank-step-num`/`.title`/`.body`/`.owner`, `.pill-accent`(确认) |
| 16 | `thanks` | 致谢（专属服务承诺收束）：白底+红条金双线+多层圆环呼应封面 + 「感谢您的信赖与托付」+ **1 张专属预约大卡**（专属顾问 + 私行服务承诺 + 预约渠道条）+ 合规小字 | `.bank-dbl-top`, `.bank-rings`, `.bank-vline`, `.bank-doubleline`, `.bank-booking-hero`(`.bank-hero-advisor`/`.bank-hero-promise`/`.bank-hero-channels`), `.bank-disclaimer` |


---

## 角色详情

### 01 — `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`project_code`, `client_label`, `headline`, `headline_accent`, `subtitle`, `meta_code`, `meta_date`, `meta_partner`, `meta_confidential`, `footer_source`, `kpi_1~3_value/label`
- **不可改动**：`.bank-dbl-top` 顶部红条金双线、`.bank-rings` 左上多层同心圆装饰（5 环）、`.h1` 字号(84px)/字重(800)、`.bank-cover-meta` 底部绝对定位(left:90px;bottom:80px)
- **内容适配规则**：
  - `headline` 含一个 `<span class="gradient-text">` 渐变 accent 词(key: `headline_accent`)，替换时保留 span
  - `meta_*` 四项为"标签+加粗值"结构，增减时同步调整 `.bank-cover-meta` gap
  - `meta_confidential` 用 `.confidential` 红色大写

### 02 — `toc`
- **可替换键**：`kicker`, `title`, `item_1~6_num/title/desc`, `footer_source`（6 组 ×3 字段 + 2）
- **不可改动**：`.grid.g2` 双栏、每项 `border-bottom:2px solid var(--accent-3)` 金色下划线、编号用 `.h2.mono` 红色
- **内容适配规则**：议程项 4~6 个，增删 `.row` 元素，标题控制在 12 字内

### 03 — `executive-summary`（金字塔顶）
- **可替换键**：`kicker`, `title`, `core_conclusion`(含内嵌 `<b>`/`<span>` 高亮), `pillars_label`, `pillar_1~3_tag/metric/title/body`, `footer_source`
- **不可改动**：`.card.card-amber` 结论条字号(31px)、3 支柱卡等宽(`.grid.g3`)、指标用 `.h3.mono` 金色
- **内容适配规则**：
  - `core_conclusion` 是整 deck 的"金字塔顶"，必须一句话含核心动作 + 量化目标
  - 内嵌高亮词用 `<span style="color:var(--accent-3)">` 或 `<b>`，替换时保留标记
  - 支柱固定 3 个（对应配置框架）

### 04 — `situation`
- **可替换键**：`kicker`, `title`, `subtitle`, `stat_1~4_value/label/delta`, `insight_tag`, `insight_body`, `footer_source`
- **不可改动**：4 列等宽(`.grid.g4`)、`.bank-num` 84px Bold、delta 用 `.bank-delta.down`/`.up` 红/绿
- **内容适配规则**：4 个数据卡，`stat_*_value` 控制在 6 字内（如"¥1.28亿"），delta 含方向箭头

### 05 — `complication`
- **可替换键**：`kicker`, `title`, `prob_1~3_tag/impact/title/body/evidence`, `footer_source`
- **不可改动**：3 列 `.card-amber`、影响数字用 `.h2.mono` 红色(`var(--bad)`)
- **内容适配规则**：3 个挑战卡，`prob_*_impact` 是量化影响（红），`evidence` 是脚注证据

### 06 — `question`（MECE 分解）
- **可替换键**：`kicker`, `title`, `subtitle`, `root_question`, `leaf_1~3_tag/title/body`, `footer_source`
- **不可改动**：`.bank-tree-node.root` 红底白字、inline SVG 三叉连接线坐标、3 leaf 等宽
- **内容适配规则**：1 root + 3 leaf（MECE 互斥穷尽），leaf 的 body 用"→ 指标"格式回链目标

### 07 — `chapter-divider`（特色页）
- **可替换键**：`chapter_num`, `chapter_title`, `chapter_sub`, `footer_source`
- **不可改动**：全屏 `background:var(--accent-2)`（深红 #9a0e26）、`.h1` 110px 白字、左侧金竖条 + 右侧金阶梯装饰
- **内容适配规则**：用于切换到"资产配置框架与产品"大章节

### 08 — `framework`（2×2 矩阵）
- **可替换键**：`kicker`, `title`, `axis_x`, `axis_y`, `q1~4_label/title/desc`, `legend_title`, `legend_1~4_tag/body`, `legend_note`, `footer_source`
- **不可改动**：`.bank-matrix` 2×2 grid、`.bank-cell.hero`（Q1 高亮象限用 `rgba(brand-primary,.05)`）、`.bank-axis-y` 竖排文字
- **内容适配规则**：4 象限按"高收益高波动(Q1,hero)→低收益低波动(Q2)→中收益中波动(Q3)→低收益极低波动(Q4)"填充，右侧图例对应配置角色

### 09 — `recommendation`
- **可替换键**：`kicker`, `title`, `opt_a~c_tag/risk/title/body/invest_label/invest/gmv_label/gmv/irr_label/irr`, `opt_b_tag/subtype/horizon`, `reason_tag`, `reason_body`, `footer_source`（3 产品 × ~9 字段）
- **不可改动**：主推产品(默认 B)用 `.card-amber` + 顶部居中金色 pill、回撤红绿着色
- **内容适配规则**：
  - 3 产品：A 保守 / B 主推 / C 进取，`opt_b_*` 整组高亮
  - 若主推变更，需把 `.card-amber` class 迁移到对应卡

### 10 — `data-deepdive`
- **可替换键**：`kicker`, `title`, `big_label`, `big_value`, `big_unit`, `bar_now/goal/top_label` + `_value`, `break_1~3_tag/impact/title/body`, `footer_source`
- **不可改动**：左 `.card-accent` 大数字(120px) + 内联 3 行 bar、右 3 `.card-amber` 收益来源卡
- **内容适配规则**：bar 宽度需手动按值调整 `width:%`（当前 36/82/67 对应 2.8%/6.5%/5.3%）

### 11 — `comparison-table`
- **可替换键**：`kicker`, `title`, `col_dim/now/plan/top/gap`（5 列头）, `row_1~6_dim/now/plan/top/gap`（6 行 ×5）, `caption`, `footer_source`
- **不可改动**：`.bank-table` 硬边、表头红底白字、`.col-hero` 列金高亮、gap 列绿色
- **内容适配规则**：6 维度行，`col-hero` 默认指第 3 列（推荐配置），如改对比列需迁移 class

### 12 — `process-flow`
- **可替换键**：`kicker`, `title`, `wave_1~3_tag/title/body/ms`, `legend_done/cur/plan`, `footer_source`
- **不可改动**：时间轴主线(绝对定位, 实线=已启动 var(--accent) / 虚线背景=计划)、3 阶段等宽、圆点节点颜色对应状态
- **内容适配规则**：3 阶段，每阶段 `wave_*_ms` 是可验证里程碑

### 13 — `quarterly-review`（特色页）
- **可替换键**：`kicker`, `title`, `subtitle`, `q1~4_label/rag/title/pct/status/event`, `action_tag`, `action_body`, `footer_source`（4 季度 ×5）
- **不可改动**：`.bank-quarter` 4 卡等宽、`.bank-rag-dot` G/A/R 状态点、`.bank-q-progress`/`.bank-q-bar` 进度条颜色随 RAG(good/warn/bad)
- **内容适配规则**：
  - `q*_rag` 值为 "G"/"A"/"R"，需与 `.bank-rag-dot` class(good/warn/bad) + `.bank-q-bar` class 同步
  - `q*_pct` 数字 + `.bank-q-bar` width:% 需一致
  - `subtitle` 含内嵌 RAG 图例 dot，保留 `<span class="bank-rag-dot good">`

### 14 — `risks-mitigation`
- **可替换键**：`kicker`, `title`, `risk_1~3_level/title/prob/risk_head/risk_body/mit_head/mit_body`, `footer_source`（3 风险 ×7）
- **不可改动**：`.bank-risk` 双栏（左红 `.bank-risk-risk` / 右绿 `.bank-risk-mit`）、风险等级 pill 颜色(高=红/中=金)
- **内容适配规则**：3 风险卡，每卡"风险描述 + 应对措施"合规对照，`prob` 格式"概率 X% · 影响 Y"

### 15 — `next-steps`
- **可替换键**：`kicker`, `title`, `subtitle`, `step_1~4_num/title/body/owner/due`, `decision_tag`, `decision_body`, `footer_source`（4 步 ×5）
- **不可改动**：`.bank-pipeline` 4 步等宽、`.bank-step.hero`（首步金色顶边 + 浅底）、owner 用 `.bank-step-owner` 加粗
- **内容适配规则**：4 步财富规划，每步 owner(角色) + due(T+Nd) + 可验证交付

### 16 — `thanks`
- **可替换键**：`kicker`, `headline`, `subtitle`, `contact_1~4_role/name/email`, `footer_confidential`, `footer_code`
- **不可改动**：`.h1` 130px、4 联系人 `.card-soft` 等宽、`.bank-rings` 右下多层金圆环呼应封面
- **内容适配规则**：联系人 2~4 个，email/电话用 `.mono`

---

## 组件层（`shared/tokens.css` `.tpl-bank-vip-gold` overlay）

> **差异化签名组件**（spec §6.2 / §3.5，其他 deck + consultant 均无）

| class | 作用 |
|------|------|
| `.bank-doubleline` | 1px+3px 精致金色双线（印刷感，封面/致谢分隔） |
| `.bank-rings` | 多层同心圆（向日葵抽象，封面左上/致谢右下呼应） |
| `.bank-diamond` | 菱形分割节点（标题处，旋转 45° 金方块） |
| `.bank-warmband` / `.bank-vline` | 封面底部暖灰装饰带 / 右侧竖装饰线 |
| `.bank-title-box` | 圆角框标题（spec §3.5.1 主标题容器） |
| `.bank-vip-badge` / `.bank-privacy` | 客户尊享标识（私行/VIP）/ 私密等级 |
| `.bank-advisor` | 财富顾问卡（姓名/职级/电话，封面用） |
| `.bank-booking-hero` / `.bank-hero-advisor` / `.bank-hero-promise` / `.bank-hero-channels` | 致谢专属预约大卡（顾问 + 私行服务承诺 + 预约渠道，非卡片网格） |
| `.bank-disclaimer` | 风险提示合规小字 |
| `.bank-kyc` / `.bank-kyc-tag` | 客户画像 KYC（风险偏好/规模/收益/流动性 多维标签） |
| `.bank-alloc` / `.bank-alloc-donut` / `.bank-alloc-legend` | 资产配置环形图（CSS conic-gradient + 图例） |
| `.bank-coresat` / `.bank-cs-ring` / `.bank-cs-core` / `.bank-cs-asset` | 核心-卫星资产配置图（同心三层圆） |
| `.bank-nav-curve` | 净值/收益曲线（SVG inline） |
| `.bank-shelf` / `.bank-shelf-board` / `.bank-product.hero` / `.bank-product-flag` | 产品货架（分类层板 + 产品卡陈列 + 主推金标） |
| `.bank-risk-matrix` / `.bank-rm-cell` / `.bank-rm-low` / `.bank-rm-high` | 风险等级 × 收益定位矩阵 |

> **通用/装饰组件**

| class | 作用 |
|------|------|
| `.bank-dbl-top` | 顶部红条 + 金双线（内容页顶饰，组合 bank-dbl-top+伪元素） |
| `.bank-gold-bottom` / `.bank-goldline` / `.bank-double-line` | 底部金线 / 金细线 / 精致双线 |
| `.bank-chapnum` | 招行红序号块（金细边） |
| `.bank-corner` | 四角安全区定位点 |
| `.bank-opinion` / `.bank-dotgrid` / `.bank-chapter-bg` | 观点条 / 微点阵 / 章节深红全屏 |
| `.bank-pagehead` | 页头：kicker + h2.title |
| `.bank-fact` / `.bank-num` / `.bank-label` / `.bank-delta` | 大数字卡 |
| `.bank-pipeline` / `.bank-step.hero` | 4-step 行动管道 |
| `.bank-table` / `.col-hero` | 硬边对比表（推荐列金高亮） |
| `.bank-quarter` / `.bank-rag-dot` / `.bank-q-*` | 季度复盘卡（RAG + 进度） |
| `.bank-risk` / `.bank-risk-risk` / `.bank-risk-mit` | 风险/应对双栏 |
| `.bank-tree-node.root` / `.leaf` | MECE 树节点 |
| `.bank-cover-meta` | 封面客户元数据 |
| `.bar-top` / `.bar-left` / `.card-amber` / `.card-accent` | 装饰条 + 强调卡（通用层） |

> 所有 `bank-*` 组件颜色均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 切换时自动联动。推荐配套方案：`cmb-gold-red`（默认）、`consulting-navy`（深蓝投行）、`government-red`（政务红金）。

> **差异化说明**（spec §6）：本 deck 用「配置环形图 + 核心-卫星图 + 产品货架 + 净值曲线」取代 consultant 的「2×2 矩阵 + 方案 A/B/C 卡 + stat 卡」——财富管理的报告体裁决定了其标志版式。封面/致谢元素集（双线·圆环·菱形·顾问卡·尊享标识·私密等级 / 顾问团队卡·预约方式·私行服务·合规提示）与其他 3 deck 完全不重叠。

