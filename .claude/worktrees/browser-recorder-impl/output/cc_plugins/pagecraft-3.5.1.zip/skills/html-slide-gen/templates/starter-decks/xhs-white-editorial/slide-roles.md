# xhs-white-editorial — Slide Role Catalog

> **模板气质**：白底杂志风、10 色彩虹顶条、渐变大标题、马卡龙软色卡片、黑色强调框
> **默认 color-scheme**：本 deck 的 `--xw-*` 在 overlay 内 `var(--brand-*)` 链路，可通过 `switch-theme` 联动换肤；AI 在 Phase 4.1 改 `--brand-*` 即改 default 换肤起点（详见 `docs/template-editing-rules.md`）。SVG 插图（chart / timeline / illustration / icon）直接用 brand hex 字面色，保持自包含、PPTX 友好。
> **适用文稿类型**：观点/洞察/知识分享
> **叙事结构（16 页，按出现顺序）**：cover → toc → section-divider → stats → content(2×2) → timeline → illustration → quote → steps → definition → code → comparison → icon-list → chart → cta → thanks。

## 模板结构特征

本模板包含以下**不可修改的结构性元素**（详见各角色详情中的"不可改动"规则）：

| 结构性元素 | CSS 类名 | 特征 |
|-----------|---------|------|
| 10 色彩虹顶条 | `.xw-topline` | `position:absolute; top:0; height:6.5px; background:linear-gradient(90deg, #6366f1, #8b5cf6, #a855f7, #ec4899, #f43f5e, #f97316, #eab308, #22c55e, #06b6d4, #6366f1)` |
| 五色渐变品牌文字 | `.xw-grad` | `linear-gradient(90deg, #7b61ff 0%, #4e8cff 25%, #17b26a 48%, #ff9d42 72%, #ff5fa2 100%)` + `background-clip:text` |
| 黑色强调框 | `.xw-focus` | `inline-block; padding:8px 21px; border-radius:19px; background:#111318; color:#fff; font-weight:700` |
| 彩色强调框 | `.xw-focus-blue/.xw-focus-pink/.xw-focus-orange/.xw-focus-green` | 各色软底 + 对应深色文字 |
| 马卡龙软色卡片 | `.xw-card.soft-purple/.soft-pink/.soft-blue/.soft-green/.soft-orange` | `border:1px solid var(--xw-line); border-radius:32px; padding:32px 39px` + 各色 `background` |
| 超大标题 | `.xw-title` | `font-size:112px; line-height:1.02; letter-spacing:-2px; font-weight:850` |
| 中号标题 | `.xw-title-md` | `font-size:80px; line-height:1.05; letter-spacing:-1.5px; font-weight:800` |
| 英雄引用框 | `.xw-hero` | `border:1px solid var(--xw-line); border-radius:38px; padding:40px 50px; box-shadow:0 25px 65px rgba(17,19,24,.08)` |
| 标签 pill | `.xw-tag` | `border-radius:1330px; border:1px solid var(--xw-line)` + `.dot` 五色渐变圆点 |
| 代码块 | `.xw-codebox` | `background:#0f1117; color:#e4e2d8; border-radius:25px; font-family:'JetBrains Mono'` |
| 步骤编号圆 | `.xw-num` | `flex:0 0 65px; height:65px; border-radius:50%; background:#111318; color:#fff; font-weight:900` |
| 巨号数字 | `.xw-big-stat` / `.xw-stat-num` | `128px` / `96px`，`font-weight:900`，负字距 |
| 议程编号 | `.xw-toc-num` | 渐变文字编号（五色），等宽字体 |
| 横向时间线 | `.xw-tl-track` + `.xw-tl-dot` | `grid 5 列`，伪元素五色渐变轨道，节点圆点按列变色 |
| 金句装饰 | `.xw-quote-mark` | 300px 半透明引号（左上 / 右下镜像） |
| 金字塔插图 | `<svg>` | 五层 polygon（执行/组装/判断/兜底/签字），左轴价值箭头，brand hex |
| 概念定义卡 | `.xw-def` | hero 风格大卡 + `.xw-def-term`(72px) + `.xw-def-traits` 强调框组 |
| 对比双栏 | `.xw-compare` | `grid 1fr 90px 1fr`，`.before` 灰底 / `.after` 紫底高亮，中间 VS |
| 图标列表 | `.xw-ili` / `.xw-ili-icon.c-*` | 横向 row，64px 圆角图标盒（currentColor + macaron 五色背景） + 标题 + 说明 |
| SVG 柱状图 | `<svg>` | 五组水平柱状对比条（纯执行/内容生产/数据分析/测试验收/安全风控）|
| 底部信息栏 | `.xw-footer` | `position:absolute; left:130px; right:130px; bottom:59px; color:var(--xw-muted)` |
| 页面编号 | `.xw-page` | 右上角页码 `font-size:19px; color:var(--xw-muted)`，格式 `NN / 16` |

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面 | .xw-kicker, .xw-title(112px), .xw-grad, .xw-sub, .xw-hero .xw-quote, .xw-focus |
| 02 | `toc` | 议程：4 条编号章节（双栏），渐变编号 + 标题 + 一句说明 | .xw-title-md, .xw-grad, .xw-toc / .xw-toc-row / .xw-toc-num / .xw-toc-title / .xw-toc-desc |
| 03 | `section-divider` | 章节分隔页 | .xw-kicker(uppercase), .xw-title(146px), .xw-grad, .xw-sub(38px) |
| 04 | `stats` | 巨号指标冲击：3 个大数字 macaron 卡 + delta + 金句 | .xw-title-md, .xw-grad, .xw-statgrid / .xw-statcard.soft-* / .xw-stat-num / .xw-stat-label / .xw-stat-delta, .xw-hero .xw-quote |
| 05 | `content-grid-2x2` | 内容页 — 2x2 卡片网格 | .xw-title-md, .xw-grad, .xw-grid-2, .xw-card.soft-* |
| 06 | `timeline` | 横向时间线：5 阶段节点，五色渐变轨道 + 圆点 + 阶段标签 | .xw-title-md, .xw-grad, .xw-timeline / .xw-tl-track / .xw-tl-dot / .xw-tl-phase / .xw-tl-title / .xw-tl-desc |
| 07 | `illustration` | SVG 主视觉：能力金字塔（5 层 polygon + 价值轴）+ 侧栏 3 条说明 | .xw-title-md, .xw-grad, .xw-pywrap / `<svg>`(金字塔) / .xw-pylayer / .sw / .t / .d |
| 08 | `quote` | 全屏金句页：一句重磅观点 + 左上/右下装饰引号 | .xw-tag, .xw-quote-page / .xw-quote-mark(.tl/.br) / .xw-quote-big / .xw-quote-bywho |
| 09 | `content-steps` | 内容页 — 编号步骤 + 金句 | .xw-title-md, .xw-grad, .xw-steps/.xw-step/.xw-num, .xw-hero .xw-quote |
| 10 | `definition` | 概念定义卡：大 term + 释义 + 4 个特征强调框 | .xw-title-md, .xw-grad, .xw-def / .xw-def-term / .xw-def-body / .xw-def-traits (.xw-focus-*) |
| 11 | `content-code` | 内容页 — 代码块展示 | .xw-title-md, .xw-grad, .xw-codebox |
| 12 | `comparison` | 对比双栏：Before vs After，中间 VS 分隔 | .xw-title-md, .xw-grad, .xw-compare / .xw-compare-col(.before/.after) / .xw-compare-vs / .xw-compare-list |
| 13 | `icon-list` | 图标原则列表：5 条，每条 = SVG 图标 + 标题 + 说明 | .xw-title-md, .xw-grad, .xw-ili / .xw-ili-row / .xw-ili-icon.c-* (内联 16×16 SVG) / .xw-ili-title / .xw-ili-desc |
| 14 | `content-chart` | 内容页 — 柱状对比图 | .xw-title-md, .xw-focus-pink, .xw-focus-green, SVG chart |
| 15 | `cta` | 行动号召 — 三卡片 + 金句 | .xw-title-md, .xw-grad, .xw-grid-3, .xw-card.soft-*, .xw-hero .xw-quote |
| 16 | `thanks` | 感谢/结束 | .xw-big-stat .xw-grad(128px), .xw-sub(38px), .xw-pill |

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **页面类型**：封面
- **视觉等级**：L3
- **可替换键**：`tagline`, `kicker`, `headline`, `headline_accent`, `subtitle`, `subtitle_focus_1`, `subtitle_focus_2`, `subtitle_focus_3`, `quote`, `quote_accent_production`, `quote_accent_acceptance`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-tag .dot` 渐变圆点样式、`.xw-grad` 五色渐变样式、`.xw-focus` 黑底白字强调框样式（含 `.xw-focus-orange` 变体）、`.xw-hero` 引用框样式、`.xw-footer` 位置、`.xw-title` 字号(112px)/字距(-2px)/字重(850)、body padding(96px 130px)
- **内容适配规则**：
  - `headline` 控制在 15 字以内（含 `headline_accent`），保留 `<br>` 用于拆行
  - `headline_accent` 必须在 `<span class="xw-grad">` 内，通常 3-6 字
  - `subtitle` 控制在 50 字以内，其中 `.xw-focus` 强调词各 2-4 字，共 2-4 个强调词
  - `quote` 控制在 30 字以内，保留 `<br>` 拆行和两个 accent span
  - `tagline` 控制在 15 字以内，格式 `"主题 · 子题"`
  - `kicker` 控制在 15 字以内，如 `"我越来越确定的一件事"`
- **卡片扩展/收缩**：不适用

### `toc`
- **源文件**：`slides/02-toc.html`
- **页面类型**：议程 / 目录
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `toc_1_num`, `toc_1_title`, `toc_1_desc`, `toc_2_num`, `toc_2_title`, `toc_2_desc`, `toc_3_num`, `toc_3_title`, `toc_3_desc`, `toc_4_num`, `toc_4_title`, `toc_4_desc`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-toc` 双栏 grid 布局(gap:21px 38px)、`.xw-toc-num` 渐变文字编号样式(等宽/五色渐变)、`.xw-toc-row` 底部 `border-bottom` 分隔线
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `toc_N_num` 为两位编号字符串（"01"-"06"），等宽字体显示
  - `toc_N_title` 控制在 8 字以内
  - `toc_N_desc` 控制在 15 字以内，一句话概括该章
  - 各行标题字数应均匀
- **卡片扩展/收缩**：
  - 收缩为 3 条：`.xw-toc` 双栏仍可（3 行留一空位）或改单栏
  - 扩展为 6 条：双栏正好 3×2；超过 6 条建议拆为两个 toc 页

### `section-divider`
- **源文件**：`slides/03-section-divider.html`
- **页面类型**：章节分隔
- **视觉等级**：L3
- **可替换键**：`chapter_label`, `chapter_subtitle`, `section_title`, `section_title_accent`, `tagline`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-title` 字号(146px)、`.xw-kicker` 字号(27px)/字距(.2em)/大写变换/颜色(#98a2b3)、`.xw-sub` 字号(38px)、内联 `margin-top` 值(160px)
- **内容适配规则**：
  - `chapter_label` 格式 `"Chapter · NN"` 如 `"Chapter · 01"`，保留 `·` 分隔符
  - `chapter_subtitle` 控制在 6 字以内（如 "第一章"），保留大写和字距样式
  - `section_title` 控制在 10 字以内，`section_title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `tagline` 控制在 25 字以内，简洁有力
- **卡片扩展/收缩**：不适用

### `stats`
- **源文件**：`slides/04-stats.html`
- **页面类型**：巨号指标冲击
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `stat_1_num`, `stat_1_unit`, `stat_1_label`, `stat_1_delta`, `stat_2_num`, `stat_2_unit`, `stat_2_label`, `stat_2_delta`, `stat_3_num`, `stat_3_unit`, `stat_3_label`, `stat_3_delta`, `quote`, `quote_accent_make`, `quote_accent_guarantee`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-statgrid` 三列 grid(gap:25px)、`.xw-statcard.soft-*` macaron 卡片色、`.xw-stat-num` 字号(96px)/字重(900)/字距(-3px) 及 `small` 单位样式、`.xw-hero` 引用框、`.xw-quote`(40px)
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `stat_N_num` 为短数字（"-65"/"+110"/"60"），`stat_N_unit` 为 1-2 字符单位（"%"/"秒"），单位在 `<small>` 内
  - `stat_N_label` 控制在 12 字以内
  - `stat_N_delta` 控制在 10 字以内；下行用 `.xw-stat-delta.down`（粉），上行用 `.up`（绿）
  - `quote` 控制在 30 字以内，保留两个 accent span（`.xw-focus-blue` / `.xw-focus`）
- **卡片扩展/收缩**：
  - 收缩为 2 卡：`.xw-statgrid` 改 `grid-template-columns:repeat(2,1fr)`，删第 3 卡
  - 扩展为 4 卡：`.xw-statgrid` 改 `repeat(4,1fr)`；超过 4 个建议降级到 `content-grid-2x2`
  - **不可收缩为 1 卡**（1 个数字改用 `quote` 角色）

### `content-grid-2x2`
- **源文件**：`slides/05-content.html`
- **页面类型**：内容页 — 2x2 卡片网格
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `card_1_label`, `card_1_main`, `card_1_desc`, `card_2_label`, `card_2_main`, `card_2_desc`, `card_3_label`, `card_3_main`, `card_3_desc`, `card_4_label`, `card_4_main`, `card_4_desc`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-grid-2` 布局(gap:25px)、`.xw-card` 卡片样式(border-radius:32px; padding:32px 39px)、`.xw-card.soft-*` 各色背景色、`.xw-label` 字号(19px)/字重(800)/大写样式
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `card_N_label` 控制在 4 字以内，保持大写/单行
  - `card_N_main` 控制在 20 字以内，保留 `·` 分隔符连接三个要点
  - `card_N_desc` 控制在 20 字以内
  - 四张卡片内容量应均匀（最长与最短 desc 差异不超过 50%）
  - 卡片颜色固定顺序：soft-pink → soft-blue → soft-green → soft-orange
- **卡片扩展/收缩**：
  - 收缩为 2 卡：`.xw-grid-2` 不变，保留 2 张卡片即可
  - 扩展为 6 卡：`.xw-grid-2`(2 列) → `.xw-grid-3`(3 列)，每行 3 张，颜色从 macaron 五个颜色中轮换
  - **不可收缩为 1 卡**（1 卡改用 `content-steps` 角色或 T2 fallback）

### `timeline`
- **源文件**：`slides/06-timeline.html`
- **页面类型**：横向时间线（5 阶段）
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `tl_1_phase`, `tl_1_title`, `tl_1_desc`, `tl_2_phase`, `tl_2_title`, `tl_2_desc`, `tl_3_phase`, `tl_3_title`, `tl_3_desc`, `tl_4_phase`, `tl_4_title`, `tl_4_desc`, `tl_5_phase`, `tl_5_title`, `tl_5_desc`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-tl-track` 5 列 grid、`::before` 五色渐变轨道线、`.xw-tl-dot` 节点圆点及 `:nth-child` 按列变色规则（紫/蓝/绿/橙/粉）、`.xw-tl-phase` 大写标签样式
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `tl_N_phase` 为阶段标记（年份/Phase N），控制在 6 字以内，大写
  - `tl_N_title` 控制在 6 字以内（如"写代码"/"做验收"）
  - `tl_N_desc` 控制在 12 字以内
  - 5 个节点应呈递进/演变关系
- **卡片扩展/收缩**：
  - 收缩为 3-4 节点：`.xw-tl-track` 改 `grid-template-columns:repeat(N,1fr)`，删多余节点；轨道 `::before` 自动按列居中
  - 扩展为 6 节点：改 `repeat(6,1fr)`，但 6 列字会挤，建议不超过 5
  - **不可少于 3 节点**（< 3 失去"线"的意义）

### `illustration`
- **源文件**：`slides/07-illustration.html`
- **页面类型**：SVG 主视觉插图（能力金字塔）
- **视觉等级**：L3
- **可替换键**：`tag`, `title`, `title_accent`, `py_1_title`, `py_1_desc`, `py_2_title`, `py_2_desc`, `py_3_title`, `py_3_desc`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-pywrap` 双栏 grid、`<svg>` 金字塔 polygon 结构（5 层 + 价值轴箭头）、各层 brand hex 取色（粉/蓝/橙/紫/绿）、`.xw-pylayer` 侧栏卡样式
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - SVG 五层文字（执行/组装/判断/兜底/签字）为**结构性元素**，不通过 data-replace 替换；如需改层名，替换整个 `<svg>` 块
  - `py_N_title` 控制在 10 字以内，`py_N_desc` 控制在 18 字以内
  - 侧栏 `.sw` 色块需与 SVG 对应层颜色一致（手写 inline background）
- **卡片扩展/收缩**：
  - 侧栏 `.xw-pylayer` 2-4 条均可
  - SVG 金字塔层数固定 5 层；改层数需重绘整个 `<svg>`，并同步左侧价值轴
  - 如需完全换插图（环形/流程图），替换 `<svg>` 块但保留 `.xw-pywrap` 容器

### `quote`
- **源文件**：`slides/08-quote.html`
- **页面类型**：全屏金句 / Pull Quote
- **视觉等级**：L3
- **可替换键**：`tag`, `quote`, `quote_accent`, `bywho`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-quote-page` 全屏居中布局、`.xw-quote-mark` 300px 半透明引号装饰（`.tl` 左上 / `.br` 右下镜像）、`.xw-quote-big` 字号(88px)/字重(850)/字距(-1.5px)
- **内容适配规则**：
  - `quote` 控制在 35 字以内，最多 2 行；`quote_accent` 在 `<span class="xw-grad">` 内，4-10 字
  - 标题超长换行交给 CSS（`.xw-quote-big` 已 `letter-spacing` 负值，配 `text-wrap:balance`），**不写 `<br>`**；确需控制断点用 `<wbr>`
  - `bywho` 控制在 15 字以内，"— " 起首
- **卡片扩展/收缩**：不适用（金句页单观点）

### `content-steps`
- **源文件**：`slides/09-steps.html`
- **页面类型**：内容页 — 编号步骤 + 金句
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `step_1_text`, `step_2_text`, `step_3_text`, `step_4_text`, `step_4_accent`, `quote`, `quote_accent_cheap`, `quote_accent_expensive`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-num` 圆形编号(65x65px, 黑底白字, border-radius:50%)、`.xw-step` flex 布局(gap:25px)、`.xw-focus` 黑底强调框、`.xw-focus-blue` 蓝底强调框、`.xw-hero` 引用框、`.xw-quote` 字号(40px)
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `step_N_text` 各控制在 30 字以内，按逻辑递进排列（因果链）
  - `step_4_accent` 是第 4 步中的 `.xw-focus` 强调词，2-4 字
  - `quote` 控制在 40 字以内，保留 `<br>` 拆行和两个 accent span
  - `quote_accent_cheap` 在 `.xw-focus-blue` 内（变便宜的事），`quote_accent_expensive` 在 `.xw-focus` 内（变更贵的事）
- **卡片扩展/收缩**：
  - 收缩为 3 步：删除最后一个 `.xw-step`，保留 1-3
  - 收缩为 2 步：删除最后两个 `.xw-step`
  - 扩展为 5-6 步：复制 `.xw-step` 模板，编号依次递增

### `definition`
- **源文件**：`slides/10-definition.html`
- **页面类型**：概念定义卡
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `def_term`, `def_body`, `trait_1`, `trait_2`, `trait_3`, `trait_4`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-def` hero 风格大卡（border-radius:38px + 阴影 + 渐变白底）、`.xw-def-term` 字号(72px)/字重(900)/字距(-1.5px)、`.xw-def-body` 字号(30px)
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `def_term` 格式 `"中文词 · English"`，控制在 12 字以内
  - `def_body` 控制在 80 字以内，2-3 句定义
  - `trait_N` 各 2-4 字，用 `.xw-focus` / `.xw-focus-blue` / `.xw-focus-green` / `.xw-focus-orange` 轮换强调框
- **卡片扩展/收缩**：
  - `trait` 数量 3-5 个，按需增删 `<span class="xw-focus-*">`
  - **不可去掉所有 trait**（定义卡至少 3 个特征才丰满）

### `content-code`
- **源文件**：`slides/11-code-example.html`
- **页面类型**：内容页 — 代码块展示
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `code`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-codebox` 代码块样式（深色背景 #0f1117、等宽字体、border-radius:25px、padding:29px 39px）、代码高亮 class 体系（`.cm` 注释灰色、`.kw` 关键字橙色、`.st` 字符串绿色、`.hl` 高亮黄色）
- **内容适配规则**：
  - `title` 控制在 15 字以内，保留 `<br>` 拆行，`title_accent` 2-4 字
  - `code` 内容不超过 15 行，保持 YAML/代码风格
  - 保留 `<span class="cm">`、`<span class="kw">`、`<span class="st">`、`<span class="hl">` 的高亮 class 结构
  - 代码块内容不应包含敏感信息（密钥、PII）
- **卡片扩展/收缩**：不适用（代码块不可分拆）

### `comparison`
- **源文件**：`slides/12-comparison.html`
- **页面类型**：对比双栏（Before / After）
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `before_tag`, `before_h`, `before_1`, `before_2`, `before_3`, `before_4`, `vs`, `after_tag`, `after_h`, `after_1`, `after_2`, `after_3`, `after_4`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-compare` `grid 1fr 90px 1fr` 布局、`.xw-compare-col.before` 灰底 / `.after` 紫底高亮(brand 边)、`.xw-compare-vs` 中间分隔、`.xw-compare-list li::before` 圆点（before 灰 / after 绿）
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `before_tag` / `after_tag` 格式 `"Before · 标签"` / `"After · 标签"`，控制在 8 字以内
  - `before_h` / `after_h` 控制在 8 字以内，呈对照关系
  - `before_N` / `after_N` 各控制在 14 字以内，两栏条数相等、逐条对应
  - `vs` 固定 `"VS"`，可改 `"→"` 表演进
- **卡片扩展/收缩**：
  - 列表项 3-5 条均可，两栏数量必须相等
  - **不可单栏**（对比页至少两栏；单观点用 `quote` 或 `definition`）

### `icon-list`
- **源文件**：`slides/13-icon-list.html`
- **页面类型**：图标原则列表
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `ili_1_title`, `ili_1_desc`, `ili_2_title`, `ili_2_desc`, `ili_3_title`, `ili_3_desc`, `ili_4_title`, `ili_4_desc`, `ili_5_title`, `ili_5_desc`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-ili` 列表布局、`.xw-ili-row` 卡片样式（border-radius:26px + 阴影）、`.xw-ili-icon.c-*` 五色图标盒（64px 圆角，currentColor SVG）、内联 `<svg>` 图标 path 结构
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent` 在 `<span class="xw-grad">` 内，2-4 字
  - `ili_N_title` 控制在 8 字以内
  - `ili_N_desc` 控制在 16 字以内
  - 图标颜色类轮换：`.c-purple` → `.c-blue` → `.c-green` → `.c-orange` → `.c-pink`
  - 换图标：替换 `.xw-ili-icon` 内的 `<svg>` path（建议 16×16 viewBox，`fill="currentColor"`），盒色保持不变
- **卡片扩展/收缩**：
  - 行数 3-6 条均可，增删 `.xw-ili-row`
  - **不可少于 3 条**（< 3 失去列表节奏）

### `content-chart`
- **源文件**：`slides/14-chart.html`
- **页面类型**：内容页 — 柱状对比图
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent_cheap`, `title_accent_expensive`
- **不可改动**：`.xw-topline` 彩虹顶条、SVG 图表整体结构（viewBox 960x380、五个 `<g>` 行组、baseline 线、bar 的 rect 尺寸/颜色/圆角、label 位置和字体）、`.xw-focus-pink` 粉底强调框、`.xw-focus-green` 绿底强调框
- **内容适配规则**：
  - `title` 控制在 15 字以内，`title_accent_cheap` 2-3 字（变便宜的方向），`title_accent_expensive` 1-2 字（变贵的方向）
  - SVG 图表数据为结构性元素，**不通过 data-replace 替换**。如需更新图表数据，替换整个 `<svg>` 块
  - 图表五组数据行标签顺序：纯执行 → 内容生产 → 数据分析 → 测试/验收 → 安全/风控（从降价值到升价值）
- **卡片扩展/收缩**：SVG 图表固定 5 行，不可增减；如需其他数量，替换整个 `<svg>`

### `cta`
- **源文件**：`slides/15-cta.html`
- **页面类型**：行动号召 — 三卡片 + 金句
- **视觉等级**：L2
- **可替换键**：`tag`, `title`, `title_accent`, `card_1_label`, `card_1_main`, `card_1_desc`, `card_2_label`, `card_2_main`, `card_2_desc`, `card_3_label`, `card_3_main`, `card_3_desc`, `quote`, `quote_accent`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-grad` 五色渐变样式、`.xw-grid-3` 布局(gap:21px)、`.xw-card.soft-*` 三色背景（固定 soft-purple → soft-blue → soft-green）、`.xw-hero` 引用框、`.xw-focus` 黑底强调框、`.xw-quote` 字号(43px)
- **内容适配规则**：
  - `title` 控制在 15 字以内，保留 `<br>` 拆行，`title_accent` 2-3 字
  - `card_N_label` 控制在 15 字以内（英文时间标签 "Tonight" / "This week" / "This month"）
  - `card_N_main` 控制在 15 字以内，保留 `<br>` 拆行，每个卡片描述一个行动项
  - `card_N_desc` 控制在 25 字以内，补充行动意图或效果
  - `quote` 控制在 40 字以内，`quote_accent` 在 `.xw-focus` 内，5-10 字
  - 三张卡片呈现递进关系（短期→中期→长期，或简单→复杂→改变）
- **卡片扩展/收缩**：
  - 收缩为 2 卡：`.xw-grid-3` → `.xw-grid-2`，删除最后一张卡片
  - 扩展为 4 卡：`.xw-grid-3` → `.xw-grid-2` + 2 行（2×2），或使用 `.xw-grid-3` + 最后一张居中
  - **不可收缩为 1 卡**（CTA 最少 2 项行动）

### `thanks`
- **源文件**：`slides/16-thanks.html`
- **页面类型**：感谢/结束
- **视觉等级**：L3
- **可替换键**：`tag`, `thanks_word`, `thanks_subtitle`, `closing_message`, `pill_1`, `pill_2`, `pill_3`
- **不可改动**：`.xw-topline` 彩虹顶条、`.xw-big-stat` 字号(128px)/字距(-4px)/字重(900)、`.xw-grad` 五色渐变样式、`.xw-big-stat small` 字号(29px)/颜色样式、`.xw-pill` 标签样式(border-radius:1330px; border:1px solid var(--xw-line))、内联 `margin-top` 值(133px 和 53px)
- **内容适配规则**：
  - `thanks_word` 控制在 5 字以内（如 "谢谢" "Thank you" "Thanks"），保留在 `.xw-grad` 内
  - `thanks_subtitle` 格式 `" · english"` 如 `" · thanks"`，控制在 15 字符以内
  - `closing_message` 控制在 80 字以内，保留 `<br>` 拆行，以互动邀请/开放性问题结尾
  - `pill_N` 各控制在 20 字以内，格式：`@handle` / `平台 · 风格` / `技术栈 · 类型`
  - pills 数量 2-4 个
- **卡片扩展/收缩**：pills 数量 2-4，按需增删 `<span class="xw-pill">` 元素

---

## 角色匹配决策树

1. 用户 slide 是封面 → `cover`
2. 用户 slide 是议程/目录 → `toc`
3. 用户 slide 是结束/感谢 → `thanks`
4. 用户 slide 是行动号召/步骤计划 → `cta`
5. 用户 slide 是章节/板块分隔 → `section-divider`
6. 用户 slide 是一句重磅金句/观点（无其它要素）→ `quote`
7. 用户 slide 是单个概念的定义（术语 + 释义 + 特征）→ `definition`
8. 用户 slide 有大数字冲击（3 个指标卡）→ `stats`
9. 用户 slide 是 Before/After 或 A vs B 对比 → `comparison`
10. 用户 slide 是阶段/时间演进（3-5 节点）→ `timeline`
11. 用户 slide 是一张概念模型/示意图作主视觉 → `illustration`
12. 用户 slide 是带图标的清单/原则（3-6 条）→ `icon-list`
13. 用户 slide 有 4 张卡片（2×2 网格）→ `content-grid-2x2`
14. 用户 slide 有 3 张卡片（1×3 网格，含金句）→ `cta`（复用 CTA 角色卡片区）
15. 用户 slide 有编号步骤（3-6 步）+ 结论金句 → `content-steps`
16. 用户 slide 需要展示代码/配置/命令行 → `content-code`
17. 用户 slide 需要展示对比柱状图（5 组数据）→ `content-chart`
18. 以上都不匹配 → 降级到 T2 layout-catalog 通用骨架（应用下方 Style Transfer 规则）

---

## Style Transfer — T2 页面继承规则

当 deck 中存在 T2 页面（从 layout-catalog 生成的非模板页面）时，以下规则确保它们与 xhs-white-editorial 模板页面的视觉语言一致。

### 空间密度对齐
- 内容区 body padding：对齐 `96px 130px`
- 卡片间距：`.xw-grid-2` gap = 25px，`.xw-grid-3` gap = 21px，`.xw-statgrid` gap = 25px，`.xw-compare` 中列 90px
- 标题与内容间距：margin-top 25-34px

### 装饰模式继承
- **顶部装饰**：T2 页面必须添加 `.xw-topline`（10 色彩虹顶条）
- **顶部栏**：必须包含 `.xw-topbar` > `.xw-tag` + `.xw-page`，tag 内带 `.dot` 渐变圆点
- **底部栏**：必须包含 `.xw-footer`（左右双栏，left:130px; right:130px; bottom:59px）
- **不使用封面 hero**：`.xw-hero` 引用框仅限于有金句/引用的页面（如 `cover`、`stats`、`content-steps`、`cta`），T2 页面不引入
- **金句页装饰**：`.xw-quote-mark` 半透明大引号仅用于 `quote` 角色，T2 不引入

### 组件类名统一
- 标题用 `.xw-title`（112px, 850wt）或 `.xw-title-md`（80px, 800wt），统一 `letter-spacing` 负值
- 强调文字用 `.xw-grad`（五色渐变，仅用于标题中的 accent 词）或 `.xw-focus`（黑底白字，用于正文中的强调词）
- 卡片用 `.xw-card` + `.soft-*` 颜色变体（purple/pink/blue/green/orange 五选一），不用 `.card` 基类；指标卡用 `.xw-statcard.soft-*`
- 标签用 `.xw-tag`（带 `.dot` 圆点），不用 `.pill` 基类
- 正文用 `.xw-sub` (32px) 或 `.xw-txt` (29px)
- 新版式组件：`.xw-toc*`（议程）、`.xw-stat*`（指标）、`.xw-tl-*`（时间线）、`.xw-quote-*`（金句）、`.xw-py*`（金字塔）、`.xw-def*`（定义）、`.xw-compare*`（对比）、`.xw-ili*`（图标列表）

### 排版层级对齐
- 封面/分隔标题：`.xw-title`，112-146px，weight 850-800，letter-spacing -2px
- 内容页标题：`.xw-title-md`，80px，weight 800，letter-spacing -1.5px
- 金句页：`.xw-quote-big`，88px，weight 850；`.xw-quote`，40-51px
- 指标数字：`.xw-stat-num` 96px / `.xw-big-stat` 128px，weight 900，letter-spacing -3 ~ -4px
- 正文：`.xw-sub` 32px / `.xw-txt` 29px，color `#1f2937` 或 `--xw-ink`
- 字体：'Inter', 'Noto Sans SC', 'PingFang SC', sans-serif
- 代码字体：'JetBrains Mono', monospace

### SVG 插图取色（不可替换，对齐 brand hex）
| 用途 | 色值 |
|------|------|
| 紫 / 渐变起点 / soft-purple | `#7b61ff` |
| 蓝 / soft-blue | `#4e8cff` |
| 绿 / soft-green / 上行 delta | `#17b26a` / 文字 `#067647` |
| 橙 / soft-orange | `#ff9d42` / 文字 `#b54708` |
| 粉 / soft-pink / 下行 delta | `#ff5fa2` / 文字 `#c11574` |
| ink / 黑底强调 | `#111318` |
| 边框线 | `#eaecf3` |

### 颜色色板（语义层，跟随 brand 换肤）
| 元素 | 颜色值 | 用途 |
|------|-------|------|
| `--xw-purple` | `var(--brand-primary)` | 渐变起点、soft-purple 卡片底 |
| `--xw-blue` | `var(--brand-accent)` | 渐变 25%、soft-blue 卡片底 |
| `--xw-green` | `var(--brand-good)` | 渐变 48%、soft-green 卡片底 |
| `--xw-orange` | `var(--brand-warn)` | 渐变 72%、soft-orange 卡片底 |
| `--xw-pink` | `var(--brand-secondary)` | 渐变终点、soft-pink 卡片底 |
| `--xw-ink` | `var(--brand-text)` | 主文字色（接近黑） |
| `--xw-ink2` | `var(--brand-text-dim)` | 次要文字色 |
| `--xw-muted` | `var(--brand-text-faint)` | 辅助/页码色 |
| `--xw-line` | `var(--brand-border)` | 边框线色 |
| `.xw-focus bg` | `var(--brand-text)` | 黑色强调框背景色 |

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| `.section-num` 超大数字水印 | xhs-white-editorial 用 `.xw-topline` 彩虹顶条作页面标识，无章节水印传统 |
| `.num-tag` 章节标签 | 用 `.xw-tag` + `.dot` 代替 |
| `.gradient-text` 通用渐变类 | 用 `.xw-grad` 代替（五色渐变，不同于通用三色渐变） |
| `.card` / `.card-accent` / `.card-hover` 基类卡片 | 用 `.xw-card.soft-*`（或 `.xw-statcard.soft-*`）代替（马卡龙软色风格） |
| `.pill` / `.pill-accent` 标签 | 用 `.xw-tag`（顶部栏）或 `.xw-pill`（thanks 页）代替 |
| `.divider-accent` 分隔线 | xhs-white-editorial 用 `.xw-hero` 引用框或空白间距分隔 |
| `.glass` / 玻璃拟态 | xhs-white-editorial 无此视觉语言 |
| `.btn-gradient` 渐变按钮 | xhs-white-editorial 用 hero quote / pill 标签作 CTA |
| `.metric` / `.n` 大数字指标 | xhs-white-editorial 用 `.xw-big-stat`(128px) / `.xw-stat-num`(96px) + `.xw-grad` |
