# Deck Gallery — 完整 Deck 模板参考

> 本文档是 `templates/starter-decks/` 中 23 个多文件 iframe 架构 deck 模板的索引与设计参考。
> 每个模板都是可运行的多文件 HTML 演示，通过 `index.html` 在浏览器中打开查看。
> 当用户需求匹配某个模板时，读取对应 `shared/tokens.css` 和 `slides/*.html` 提取布局、配色和组件模式。

## 目录

- [快速匹配表](#快速匹配表)
- [匹配规则：语义场景匹配](#匹配规则语义场景匹配semantic-scene-matching)
- [部分使用策略](#部分使用策略)
- [高频模板](#高频模板场景覆盖广优先考虑完整复制)
- [低频模板](#低频模板场景窄但组件独特优先提取组件)
- [模板详情](#模板详情)
  - [pitch-deck](#pitch-deck)
  - [weekly-report](#weekly-report)
  - [tech-sharing](#tech-sharing)
  - [product-launch](#product-launch)
  - [course-module](#course-module)
  - [dir-key-nav-minimal](#dir-key-nav-minimal)
  - [graphify-dark-graph](#graphify-dark-graph)
  - [hermes-cyber-terminal](#hermes-cyber-terminal)
  - [knowledge-arch-blueprint](#knowledge-arch-blueprint)
  - [consultant-strategy](#consultant-strategy)
  - [government-formal-red](#government-formal-red)
  - [soe-engineering-blue](#soe-engineering-blue)
  - [bank-vip-gold](#bank-vip-gold)
  - [academic-defense](#academic-defense)
  - [insight-report](#insight-report)
  - [biz-review](#biz-review)
  - [compare-eval](#compare-eval)
  - [keynote-formal](#keynote-formal)
  - [obsidian-claude-gradient](#obsidian-claude-gradient)
  - [presenter-mode-reveal](#presenter-mode-reveal)
  - [testing-safety-alert](#testing-safety-alert)
  - [xhs-pastel-card](#xhs-pastel-card)
  - [xhs-white-editorial](#xhs-white-editorial)
- [使用方法](#使用方法)

---
> 模板可直接作为脚手架起点，复制到产出目录后修改。

## 快速匹配表

> **颜色分离**：本表中不列出颜色信息。所有模板的默认色板均可通过颜色方案替换（见 `scripts/color-schemes.json`，`--accent`/`--bg`/`--text-1`/`--grad` 等 15 个 token 一键切换）。匹配只按**场景结构 + 组件模式**，不管颜色。

| 场景 | 推荐模板 | 关键词标签 | 页数 | 结构特征 | 气质 |
|------|---------|-----------|------|------|------|
| VC 融资路演 / 话说 | pitch-deck | 路演, 融资, pitch, VC, startup, 投资, 商业计划 | 10 | Problem→Solution→Product→Traction→Ask | 自信、数据驱动 |
| 周报 / 团队汇报 | weekly-report | 周报, 汇报, 团队, KPI, 进度, weekly, 同步 | 14 | Cover→Agenda→KPIs→Wins→Shipped→Velocity→Funnel→Metrics→OKR→Blockers→Decisions→Next→Team→Thanks | 严肃、可扫描 |
| 技术分享 / brown-bag talk | tech-sharing | 技术, 分享, 代码, brown-bag, conference, 工程师 | 18 | Agenda→Context→DeepDive→Code→Takeaways | GitHub 工程师风 |
| 产品发布 / all-hands | product-launch | 发布, launch, 产品, all-hands, event, 发布会 | 12 | 白+暗交替页、Feature→HowItWorks→Pricing→CTA | Apple-event 风 |
| 在线教学 / 课程模块 | course-module | 教学, 课程, 培训, 教育, 讲义, workshop, 学习 | 11 | 左侧 sidebar 学习目标、模块化讲义 | 教科书风 |
| 系统架构 / 技术白皮书 | knowledge-arch-blueprint | 架构, 白皮书, 系统, 蓝图, 技术文档, 流程 | 16 | 蓝图网格背景、pipeline step-box、工程图标注 | 建筑蓝图 |
| 战略咨询 / 董事会汇报 | consultant-strategy | 咨询, 战略, 麦肯锡, 董事会, 投行, 商业提案, 转型, 季度复盘 | 16 | SCQA+金字塔、2×2矩阵、RAG季度卡、90天计划 | 高端咨询、数据驱动 |
| 政府 / 政务工作汇报 | government-formal-red | 政务, 政府, 工作汇报, 工作总结, 政策, 营商环境, 改革, 招商 | 16 | 红头文件版心、政策依据块、责任分工表、三清单、组织保障 | 庄重权威、政务规范 |
| 央企 / 国企工程汇报 | soe-engineering-blue | 央企, 国企, 工程, 项目, 基建, 电建, 里程碑, 投产 | 16 | 深蓝科技底、甘特图、四控制仪表盘、工程参数 | 宏大精工、深色科技 |
| 金融 / VIP 财富管理 | bank-vip-gold | 金融, 银行, 财富, VIP, 私行, 资产配置, 理财, 净值 | 16 | 精致双线圆环、资产配置环形图、产品货架、KYC画像 | 极简轻奢、红金 |
| 学术 / 学位答辩 | academic-defense | 学术, 答辩, 论文, 学位, 研究, 毕业, 文献, 实验 | 16 | 深蓝页眉条、文献综述卡、公式块、baseline对比 | 严谨科研、深蓝学术 |
| 行业研究 / 数据报告 | insight-report | 研究报告, 行业报告, 数据, 洞察, 白皮书, BLUF, 调研 | 14 | BLUF执行摘要框、研究发现卡、方法论网格、附录块、可打印 | 克制深墨、结论先行 |
| 季度复盘 / 业务回顾 | biz-review | 复盘, 业务回顾, 季度, 年度, 述职, KPI, 规划, 述职报告 | 14 | KPI总览墙、亮点展开、差距分析、资源审批块 | 商务稳重、大容量 |
| 对比评测 / 选型报告 | compare-eval | 评测, 选型, 对比, 评分, 矩阵, benchmark, 横评, 推荐 | 10 | 评测矩阵(评分+勾叉+权重)、参评方档案、维度深挖、裁决卡 | 客观克制、墨蓝 |
| 庄重演讲 / 主题大会 | keynote-formal | 主题演讲, 大会, keynote, 致辞, 年会, 叙事, 黄金圈, 信念 | 10 | 叙事节拍页、信念宣言、大引语、行动号召 | 庄重叙事、金黑分量 |
| 极简 keynote / 演讲稿 | dir-key-nav-minimal | 极简, keynote, 演讲, 留白, 排版, 呼吸感 | 13 | 每页独立配色、超大标题、极简排版 | 每页一色、呼吸留白 |
| 开发者工具介绍 / 知识图谱 | graphify-dark-graph | 开发者, 工具, 知识图谱, 数据可视化, AI, dark | 12 | SVG力导向图背景、玻璃拟态卡片、cmd-glow终端 | 力导向图 + 玻璃拟态 |
| CLI / Agent 评测 | hermes-cyber-terminal | CLI, 评测, 终端, agent, 命令行, benchmark | 14 | CRT 扫描线、窗口 chrome、blinking cursor、$ prompt | CRT 扫描线 + 薄荷绿 |
| Dev workflow / Agent 教程 | obsidian-claude-gradient | workflow, agent, 教程, 开发流程, MCP, DevOps | 14 | 紫→蓝→绿渐变标题、居中对齐、pill tag、紫色左边框 | GitHub-dark 质感 |
| 带逐字稿的正式演讲 | presenter-mode-reveal | 正式, 演讲, 逐字稿, presenter, 主会场, 主题切换 | 15 | S键演讲者窗口、多主题热切换(T键)、BroadcastChannel同步 | 磁吸卡片演讲者视图 |
| 安全 / 风控 / 事故复盘 | testing-safety-alert | 安全, 风控, 事故, 复盘, 警示, 红线, audit | 16 | 红黑斜条纹警示带、strike-through、L1/L2/L3色卡、policy-yaml | 警示、严肃 |
| 生活方式 / 个人成长 | xhs-pastel-card | 生活方式, 个人成长, 温柔, 杂志, 休闲, 情感 | 14 | 柔光blob背景、马卡龙整色卡片、Playfair衬线混排 | 马卡龙色卡、杂志风 |
| 白底干货帖 / 知识总结 | xhs-white-editorial | 干货, 总结, 知识, 白底, 彩虹, editorial, 教程 | 16 | 顶部10色彩虹条、渐变brand文字、超大标题、macaron色卡 | 彩虹条 + 渐变字 |

### 匹配规则：语义场景匹配（Semantic Scene Matching）

> **首选方法：下面的「结构化选型矩阵」**——先按文稿类型分流（4 选 1），再在组内按选型判据定。把 23 选 1 降成两步小决策。三步语义推理（§后）作为矩阵判不清时的详细推理兜底。

#### Step 0：二级分类决策树（先分流）

Phase 1 已锁定文稿类型（说服/传授/信息同步/启发）。**先用类型分流到对应模板组**，再在组内选——这是最强且免费的匹配信号：

```
用户文稿类型？（Phase 1 已定）
├─ 说服/促动 ──→ A 组（4）：pitch-deck · product-launch · consultant-strategy · testing-safety-alert
├─ 传授/赋能 ──→ B 组（6）：tech-sharing · course-module · knowledge-arch-blueprint · academic-defense · obsidian-claude-gradient · presenter-mode-reveal
├─ 信息同步 ──→ C 组（10）：weekly-report · government-formal-red · soe-engineering-blue · bank-vip-gold · insight-report · biz-review · compare-eval · graphify-dark-graph · hermes-cyber-terminal · xhs-white-editorial
└─ 启发/共鸣 ──→ D 组（3）：keynote-formal · dir-key-nav-minimal · xhs-pastel-card
```

> 若用户文稿类型**不在四类标准**内（如安全警示=testing-safety、生活美学=xhs-pastel 的感性说服），不要硬过滤——把最接近的组也纳入候选，用下面的选型判据区分。

#### Step 1：组内结构化选型矩阵（按选型判据定）

进入对应组后，用「**选型判据**」（一句话：何时选我 vs 同类）定夺。这是同类模板区分的核心——不再靠读散文「匹配条件」。

**A 组 · 说服/促动**（场景都=说服决策者，靠"说服什么"区分）

| 模板 | 页 | 说服什么 | 选型判据（何时选我） |
|------|----|---------|-------------------|
| pitch-deck | 10 | 融资/商业提案 | 要钱——Problem→Traction→Ask，给投资人 |
| product-launch | 12 | 买产品/认可发布 | 要市场——dark/light 交替戏剧感，hero-shot+pricing |
| consultant-strategy | 16 | 采纳战略方案 | 要决策——SCQA 诊断→方案择优→90 天行动，给董事会 |
| testing-safety-alert | 16 | 引起警觉/促合规 | 要重视——红黑警示带+strike-through，安全/风控/事故复盘 |

**B 组 · 传授/赋能**（场景都=教/分享，靠"教什么+给谁"区分）

| 模板 | 页 | 传授什么 | 选型判据（何时选我） |
|------|----|---------|-------------------|
| tech-sharing | 18 | 技术深度/代码 | 讲代码/技术细节——GitHub 暗黑风+终端代码块，给工程师 |
| course-module | 11 | 系统课程/培训 | 讲体系——sidebar 学习目标+模块化讲义，教学场景 |
| knowledge-arch-blueprint | 16 | 架构/系统设计 | 讲架构图——蓝图网格+工程图标注，白皮书质感 |
| academic-defense | 16 | 学术研究/答辩 | 讲论文——文献综述卡+公式块+baseline，学位答辩 |
| obsidian-claude-gradient | 14 | 工作流/配置教程 | 讲步骤——紫蓝绿渐变文字，配置+步骤的 Dev 教程 |
| presenter-mode-reveal | 15 | 正式带稿演讲 | 要逐字稿——S 键演讲者磁吸卡+BroadcastChannel，照着讲 |

**C 组 · 信息同步**（场景都=汇报/同步，靠"汇报什么体量+给谁"区分）

| 模板 | 页 | 同步什么 | 选型判据（何时选我） |
|------|----|---------|-------------------|
| weekly-report | 14 | 团队周报/squad | 细粒度团队同步——KPI 8-grid+ship-item+blockers |
| government-formal-red | 16 | 政务工作汇报 | 政府场景——红头文件版心+责任分工表+三清单，庄重 |
| soe-engineering-blue | 16 | 央企工程项目 | 工程场景——深蓝科技底+甘特图+四控制，宏大精工 |
| bank-vip-gold | 16 | 金融/VIP 财富 | 金融场景——双线圆环+配置饼图+产品货架，轻奢 |
| insight-report | 14 | 行业/数据研究报告 | 研究输出——BLUF 执行摘要+研究发现+方法论+附录，可打印，给决策者 |
| biz-review | 14 | 季度/年度业务复盘 | 业务回顾——KPI 墙+亮点展开+差距分析+资源审批，大容量给高管 |
| compare-eval | 10 | 对比评测/选型报告 | 客观评测——评分矩阵(勾叉+权重)+参评方档案+维度深挖+裁决，给选型委员会 |
| graphify-dark-graph | 12 | 开发者工具介绍 | 关系网可视化是内容——力导向图+玻璃拟态 |
| hermes-cyber-terminal | 14 | CLI/Agent 评测 | 跑分/trace/diff 是内容——CRT 扫描线+终端 |
| xhs-white-editorial | 16 | 干货帖/知识总结 | 中文图文为主——彩虹条+渐变字，小红书风 |

**D 组 · 启发/共鸣**（场景都=感染观众，靠"氛围"区分）

| 模板 | 页 | 共鸣什么 | 选型判据（何时选我） |
|------|----|---------|-------------------|
| keynote-formal | 10 | 庄重主题演讲 | 叙事弧——信念→故事→转折→号召，黄金圈/英雄之旅，大字金句 |
| dir-key-nav-minimal | 13 | 逐点递进观点 | 极简留白——每页独立配色+超大标题+键盘提示 |
| xhs-pastel-card | 14 | 生活方式/情感 | 温暖杂志——柔光 blob+马卡龙色卡+Playfair 衬线 |

> **匹配信号优先级**：选型判据 > 受众 > 内容形态 > 调性 > 页数。颜色永远不参与（Phase 4.1 独立注入）。

#### Step 2：三步语义推理（当矩阵判不清时兜底）

> 当组内仍有 2-3 个候选难分（如 B 组 tech-sharing vs course-module vs knowledge-arch 都像"技术培训"），用详细语义推理细辨。**矩阵已能解决 80% 场景，此步只在判不清时用。**

> **颜色不作为匹配因子**。所有模板的默认色板均可独立替换——`templates/shared/tokens.css` 中 15 个 `--brand-*` token 值决定颜色，布局/间距/圆角/组件类决定结构，两者正交。匹配时**只看结构和组件模式**，颜色方案在 Phase 4.1 单独匹配（见 SKILL.md §4.1 颜色方案匹配表）。

**(a) 从用户需求中提取场景要素**

阅读用户描述，提取以下四维信息（每维 1-2 句话）：
- **做什么**：演示的目的（融资/汇报/教学/发布/复盘...）
- **给谁看**：受众身份（投资人/高管/工程师/学生/大众...）
- **有什么**：内容特征（有大量数据/有代码/有产品图/有对比表/文字为主...）
- **要什么氛围**：气质诉求（专业严肃/科技前沿/温暖亲切/冲击力强/极简留白...）——这是排版语言层面的，不是颜色

**(b) 语义匹配——逐个模板排除**

对每个模板，用以下检查点做匹配（不是打分，是排除法）：

| 检查点 | 判断逻辑 | 权重 |
|--------|---------|------|
| **场景契合** | 模板设计的核心场景是否与用户需求一致？ | 高 — 直接不符则排除 |
| **受众匹配** | 模板排版气质是否匹配受众期望？（注意：不是颜色——颜色可独立替换） | 高 — 给工程师看终端排版风是加分，给投资人看是减分 |
| **内容结构** | 模板内置的 slide 结构（问题→方案→市场 / 周报→成果→风险→计划）是否匹配用户的内容弧？ | 高 — 结构对齐是最强信号，决定了完整复制还是仅提取组件 |
| **页数适配** | 模板页数是否在用户篇幅需求的 ±30% 范围内？（页数以上方矩阵为准） | 低 — 可增减页 |
| **排除信号** | 模板是否有明确不适用的特征（如竖版画布、特殊组件依赖）？ | 一票否决 |

> 以上 5 个检查点均不涉及颜色。所有模板的默认色板在匹配阶段忽略——颜色方案在 Phase 4.1 通过 `scripts/color-schemes.json` 独立选择并注入 tokens.css。

**(c) 输出候选 + 零匹配预警**

选出 2-3 个最有说服力的候选，每个附一句话理由（必须引用具体场景要素，不能说"匹配度高"）。按推荐度排序。如果只有 1 个模板有意义匹配，只输出 1 个并说明为什么其他不适用。

> ⚠️ **零匹配预警（F4，最高 ROI）**：若候选模板都不达「完整复制/提取组件」门槛（没有任何模板与用户场景重合 >50%），**必须显式预警**：
> - 告知用户：「此 deck 与现有模板重合度低，预计高比例走 T2 替换路径，单页校验较重」
> - 给出降级选项菜单，让用户选，而非默默回退：
>   1. **接受高 T2**：选最近似模板提取组件，逐页替换（校验重，但可定制）
>   2. **裁剪篇幅**：把内容压缩到能完整匹配某模板的页数区间
>   3. **等横向报告 deck**：若是研究报告/业务复盘类（用例 8/5），提示 insight-report/biz-review 即将上线
> - 典型零匹配场景：行业深度研究报告（25 页）、纯文字长稿、超长技术白皮书

**示例**：

用户说"给技术团队做个内部培训，讲我们的新架构设计，大约 15 页"

→ 提取场景要素：
- 做什么：内部技术培训
- 给谁看：工程师团队
- 有什么：架构图、技术概念、可能有代码
- 要什么氛围：专业但不要太营销

→ 模板语义排除：
- `pitch-deck` → 排除：融资场景不匹配
- `tech-sharing` → **候选第一名**：工程师受众 + 代码展示 + 技术深度
- `course-module` → **候选第二名**：培训场景，但偏教学而非架构
- `knowledge-arch-blueprint` → **候选第三名**：架构白皮书场景完美匹配，气质严肃

→ 输出：
1. `knowledge-arch-blueprint`（推荐）— 架构白皮书是最匹配的场景，蓝图视觉语言天然适合架构讲解
2. `tech-sharing` — GitHub 暗黑风受工程师欢迎，代码展示组件完整
3. `course-module` — 培训场景适配，教科书风格适合系统讲授

### 部分使用策略

**不要求 100% 匹配才使用模板**。即使用户场景与模板不完全重叠，模板的组件和结构仍然有价值（颜色由颜色方案独立注入，不依赖模板）：

| 策略 | 何时使用 |
|------|---------|
| **完整复制** | 场景高度一致 + 页数接近 + 内容结构对齐，直接复制模板目录作为脚手架（颜色通过 color-schemes.json 替换） |
| **提取组件 + 结构** | 场景部分重叠，使用模板的关键组件（如 `.kpi`、`.terminal`、`.ship-item`）和 slide 结构，颜色独立注入 |
| **仅提取组件模式** | 场景不同但某个组件高度可复用（如评测模板的终端组件用于技术分享的代码演示） |
| **容量降级** | 场景匹配但模板页数超出用户篇幅 ±30%：①优先换更高容量同类模板（如 weekly-report 装不下→待上线的 biz-review）；②仍不够则拆成双 deck；③别硬扩单模板到 2× 页数（角色页结构会崩，大面积退 T2） |
| **回退到通用模板** | 找不到任何有意义的场景重合（零匹配，见 §Step 2(c) 零匹配预警），使用 `templates/shared/tokens.css` 通用模板 + 颜色方案 |

**原则**：宁可复用现有模板的成熟组件，不要从零造轮子。

**高频模板（场景覆盖广，优先考虑完整复制）**：
| 模板 | 核心场景 |
|------|---------|
| pitch-deck | 说服决策者（融资、商业提案、战略汇报） |
| weekly-report | 定期信息同步（周报、月报、squad review） |
| tech-sharing | 技术深度分享（brown-bag、conference、code review） |
| product-launch | 产品亮相（发布会、all-hands reveal、新功能展示） |
| course-module | 系统教学（培训课程、onboarding、workshop） |

**低频模板（场景窄但组件独特，优先提取组件）**：
| 模板 | 核心可复用组件 |
|------|---------------|
| dir-key-nav-minimal | 独立配色页、呼吸留白间距 |
| graphify-dark-graph | SVG 力导向图、玻璃拟态卡片 |
| hermes-cyber-terminal | CRT 扫描线效果、终端绿配色 |
| knowledge-arch-blueprint | 蓝图网格背景、工程图标注线 |
| obsidian-claude-gradient | 紫蓝绿三色渐变文字、GitHub-dark 配色 |
| presenter-mode-reveal | 多主题切换、演讲者磁吸卡片 |
| testing-safety-alert | 红黑警示条纹、severity 色标 |
| xhs-pastel-card | 马卡龙色卡、杂志风排版 |
| xhs-white-editorial | 彩虹渐变条、白底极简 editorial |


## 模板详情（按需局部读取）

选定模板后，**按 `### <deck-name>` 锚点局部读取** [`slides-gallery-details.md`](./slides-gallery-details.md)（勿整文件加载 395 行）——每个 deck 的完整色板、组件模式、适用场景、匹配条件在详情文件对应锚点下。本文件只保留匹配表与规则，供 Phase 4.1 选型。

## 使用方法

### Phase 4 视觉设计阶段

1. **匹配模板**: 根据用户文稿类型 + 受众 + 场景，用上方快速匹配表找到 2-3 个候选模板（不看颜色，只看结构和组件）
2. **读取详情**: 局部读 [`slides-gallery-details.md`](./slides-gallery-details.md) 的 `### <候选模板名>` 段取色板/组件/匹配条件；再打开对应 `templates/starter-decks/<name>/slides/*.html` 提取布局结构和组件模式
3. **复制脚手架**: 将匹配的模板目录复制到产出目录。颜色方案独立于模板——通过 `scripts/color-schemes.json` 选择并注入到 `shared/tokens.css` 的 `:root` 变量中，不动模板的 HTML 结构

### 所有模板均为多文件 iframe 架构

全部 23 个模板已转换为多文件 iframe 架构（`index.html` + `slides/*.html` + `shared/tokens.css`），可直接作为脚手架使用：

| 模板 | 路径 | 页数 |
|------|------|------|
| pitch-deck | `templates/starter-decks/pitch-deck/` | 10 |
| weekly-report | `templates/starter-decks/weekly-report/` | 14 |
| tech-sharing | `templates/starter-decks/tech-sharing/` | 18 |
| product-launch | `templates/starter-decks/product-launch/` | 12 |
| course-module | `templates/starter-decks/course-module/` | 11 |
| dir-key-nav-minimal | `templates/starter-decks/dir-key-nav-minimal/` | 13 |
| graphify-dark-graph | `templates/starter-decks/graphify-dark-graph/` | 12 |
| hermes-cyber-terminal | `templates/starter-decks/hermes-cyber-terminal/` | 14 |
| knowledge-arch-blueprint | `templates/starter-decks/knowledge-arch-blueprint/` | 16 |
| consultant-strategy | `templates/starter-decks/consultant-strategy/` | 16 |
| government-formal-red | `templates/starter-decks/government-formal-red/` | 16 |
| soe-engineering-blue | `templates/starter-decks/soe-engineering-blue/` | 16 |
| bank-vip-gold | `templates/starter-decks/bank-vip-gold/` | 16 |
| academic-defense | `templates/starter-decks/academic-defense/` | 16 |
| insight-report | `templates/starter-decks/insight-report/` | 14 |
| biz-review | `templates/starter-decks/biz-review/` | 14 |
| compare-eval | `templates/starter-decks/compare-eval/` | 10 |
| keynote-formal | `templates/starter-decks/keynote-formal/` | 10 |
| obsidian-claude-gradient | `templates/starter-decks/obsidian-claude-gradient/` | 14 |
| presenter-mode-reveal | `templates/starter-decks/presenter-mode-reveal/` | 15 |
| testing-safety-alert | `templates/starter-decks/testing-safety-alert/` | 16 |
| xhs-pastel-card | `templates/starter-decks/xhs-pastel-card/` | 14 |
| xhs-white-editorial | `templates/starter-decks/xhs-white-editorial/` | 16 |
