# soe-engineering-blue · 央企国企工程汇报

16-slide SOE (state-owned enterprise) engineering-report deck: cover (大坝基石), milestone agenda, project summary (pyramid), project overview, construction challenges, technical MECE tree, chapter divider (stroke-only outline numeral), 2×2 technical framework, 4 key innovations, engineering data deep dive, world benchmark table, 3-phase construction schedule, four-control RAG stage review, risk control, deployment pipeline (commission/acceptance/handover/O&M), thank-you.

Dark engineering palette — PowerChina Blue (`#00418d`) + Honor Gold (`#ffd700`) + China Red accent (`#C41E3A`) on deep-sea blue (`#001f45`) with a precision latitude/longitude grid, glowing tech cards, four-corner targeting marks, and stroke-only giant outline chapter numerals. Data-driven, restrained, emphasizing 大国重器 (national-scale infrastructure) and technical innovation.

**Use when:** state-owned enterprise project progress reports, major infrastructure (hydropower / bridge / pumped-storage) construction briefings, annual SOE work reports, technology innovation achievement reports.
**Feel:** PowerChina corporate deck meets a precision engineering blueprint — heavy, data-driven, every page carries authority.

---

## 配色

默认 `powerchina-modern`（电建蓝 + 光辉金 + 中国红，深蓝底）。**这是深色 deck**。已接入 `switch-theme.mjs`，可一键切换：

```bash
node scripts/switch-theme.mjs --deck templates/starter-decks/soe-engineering-blue --scheme government-blue  # 政务蓝
node scripts/switch-theme.mjs --deck templates/starter-decks/soe-engineering-blue --scheme consulting-navy  # 深蓝投行
```

配套方案见 `scripts/color-schemes.json`（40 个预设）。

## 结构

16 页叙事弧 = **项目概况 → 技术方案 → 建设进度 → 质量安全 → 效益分析**（工程项目汇报体裁，非 SCQA）：

| 段落 | 页 | 角色 |
|------|-----|------|
| 开篇 | 01-03 | cover（**基石概念·居中**）· toc（里程碑式）· executive-summary（金字塔顶） |
| 概况与挑战 | 04-06 | situation（概况+**参数表**）· complication · question（技术主线 MECE） |
| 章节切换 | 07 | chapter-divider（stroke-only 巨型轮廓字） |
| 技术方案与进度 | 08-12 | framework（**技术路线图**，取代矩阵）· recommendation（**科技卡片 glowing**）· data-deepdive · comparison-table（工程对标）· process-flow（**甘特图**） |
| 管控治理 | 13-15 | quarterly-review（**四控制仪表盘**，取代 RAG 卡）· risks-mitigation · next-steps（部署） |
| 收束 | 16 | thanks（合作共赢+全景图+二维码） |

**标志版式（工程身份证，spec §5）**：甘特图（12）· 四控制仪表盘（13）· 技术路线图（08）· 科技卡片（09）—— 区别于 consultant 的 2×2 矩阵/通用时间轴/RAG 季度卡。封面（基石概念·居中）与致谢（参建联系人+全景图+二维码）元素集与政府/金融/学术完全不重叠。

完整角色目录与替换键见 [`slide-roles.md`](slide-roles.md)。

## 用法

复制本目录到产出目录后修改 `slides/*.html` 中的 `data-replace="key"` 内容。示例填充为「白鹤滩·西抽水蓄能电站工程建设汇报」（典型央企重大工程场景，覆盖投资/工期/装机/发电量/技术创新/对标/四控/风险/部署全部要素）。

```bash
# 预览
open index.html
# 截图所有页
node scripts/preview_slides.mjs --slides slides --out /tmp/preview
# 导出单文件 HTML
node scripts/export_single.mjs --deck . --out ../soe-engineering-blue.html
# 导出 PPTX
node scripts/export_pptx.mjs --slides slides --out ../soe-engineering-blue.pptx --mode editable
```

## 设计依据

参考 pagecraft-2.0.0 `layouts/中国电建_现代/design_spec.md`（深蓝科技渐变 + 精密经纬网格 + 金色高光 + 瞄准框 + stroke-only 轮廓字装饰语言）经 HTML 多文件 iframe 架构重做。详见 `docs/starter-decks-expansion-plan.md`。
