# Subagent 生成规则

> **本文件用途**：subagent 规则的**完整版深度参考**。subagent 启动只读 [`subagent-brief.md`](./subagent-brief.md)（速查），需要展开看重点页强调 / 复合骨架组合 / Anti_Patterns / 空间利用率硬约束的完整规则时按段局部读本文件。
>
> **顺序**：操作步骤与 trap rules 的权威顺序以 `subagent-brief.md` 为准；本文件按主题分段，顺序与 brief 不一定一致，差异一律以 brief 为准。

Subagent 的角色是**替换占位符**，不是"读 spec + 写 HTML"。根据骨架来源（T1/T2），操作方式不同：

- **T1（模板骨架）**：复制模板 slide HTML，替换 `data-replace="key"` 元素的 textContent
- **T2（通用骨架）**：替换路由表骨架 HTML 中的 `[xxx]` 占位符

## 参考文件加载纪律（硬约束）

> 以下「按需局部读」纪律已在 `subagent-brief.md` 的「启动纪律」段重述。subagent 启动读 brief 一份；下列大参考仅在 brief 指示该页骨架源为预置锚点/offset 时**局部读一次**。

Subagent 启动只需读 brief + 路由表给出的骨架源。**禁止整文件加载**以下大参考——按需局部读取（grep / offset）：

- **`layout-catalog.md`（741 行）**：32 个布局**全部**有独立 `### Lxx` 块。**优先**用 spec 骨架源里已写的 `@ offset=N` 直接 `Read layout-catalog.md offset=N limit≈44` 局部读（M5 减负——spec 已带 offset，无需再读 index）。仅当 spec 缺 offset（手工/旧 spec）时才回退读 `layout-catalog-index.md`（~140 行）的 `offset` 列查行号。**严禁整文件加载** catalog。
- **`visual-content-guide.md`（1186 行）**：构造 AI 生图 Prompt 时才读对应维度章节，平时用 `visual-content-index.md` 速查即可。
- **`tokens.css`**：不需要读——所需样式已在 spec 骨架的 inline style 和 class 中。

spec 文件已包含该页全部 HTML 骨架，subagent 无需从外部参考文件拼装 HTML。

---

## 文件写入约定

- 所有新建产出文件（slides/ 下）使用 Bash heredoc 写入。**关键：EOF 必须加引号禁止 shell 展开**（防止 Markdown 中的反引号、`$` 符号被 shell 解释）：
  ```bash
  cat > slides/NN-slug.html << 'ENDOFFILE'
  ...HTML content...
  ENDOFFILE
  ```
- 修改已有文件使用 Edit 工具
- 模板文件复制使用 `cp`

## data-skeleton 属性要求

**T1 页面 `<body>` 必须包含 `data-skeleton="t1"` 属性**。该属性是校验器（validate.mjs）、后处理（post-process.mjs）和批量修复（batch-fix.mjs）识别 T1/T2 骨架来源的唯一依据——缺少它会触发大量误报 ERROR（DIV_BARE_TEXT、compact-header 等）。

T2 页面建议设置 `data-skeleton="t2"`，方便后续工具区分处理。

---

## T1 操作规则（模板骨架——优先路径）

### T1 四条核心规则（违反任何一条则该页无效）

### 1. 复制模板源文件 HTML，替换 data-replace 区域
从 spec 中的"骨架源"指向的模板文件复制完整 HTML（`<!DOCTYPE html>` 到 `</html>`）。找到所有 `data-replace="key"` 元素，将 textContent 替换为 spec 中"内容映射"的对应值。

### 2. 禁止修改结构和样式
所有 class、标签结构、CSS 变量、inline style **原样保留**。不添加 `<style>` 块。不发明 class 名。不修改 `data-replace` 属性所在的元素标签（如把 `<h2>` 改成 `<h1>`）。

> **动效 class 必须随模板源保留**：模板源 HTML 上的 `.anim-*`（如 `.anim-fade-up`、`.anim-rise-in`、`.anim-d4`）和 `.anim-stagger-list` 是该页的入场动效编排（见 `references/motion-system.md`），属于模板视觉语言的一部分。复制模板源时**连同这些 class 一起保留**，绝不要只复制 `data-replace` 结构而丢掉 anim class——那会让内容页失去入场动画。同时**删除 `data-anim="..."` 属性**（已弃用的死代码，无 JS 消费）。

> **唯一例外**：`<aside class="notes">` 是逐字稿的必需容器，属于演讲基础设施而非视觉结构。当模板源文件缺少该元素时，按步骤 5 在 `</body>` 前注入一个空 `<aside class="notes">` 是允许的——它 `display:none`，不影响任何视觉呈现。除此之外的结构/样式改动一律禁止。

### 3. 结构元素零触碰
以下元素不标注 data-replace，也绝不修改：
- 装饰层（`.cover-bg`、`.ambient-glow`、`.hero-shot`、SVG 元素等）
- 容器结构（`.grid`、`.card`、`.deck-footer`、`.sidebar` 等）
- body class 和属性

### 4. 颜色保持 var(--xxx)
模板骨架已全部使用 CSS 变量。替换内容时，不引入 `#xxxxxx` 或 `rgb()`。
> 强调色同样走 token：`--hi-strong`（CTA 强调）/ `--hi-positive`·`--hi-warning`（正负向语义）/ `--data-1..6`（图表系列）均为官方预置 token，可用。挂强调走预置 class（见下「重点页强调」段），不自己写颜色。

### T1 操作步骤

1. 从 spec 的"骨架源"读取模板文件路径，复制其完整 HTML
2. 读取 spec 的"内容映射"表（data-replace key → 真实内容）
3. 对每个 `data-replace="key"` 元素，替换其 textContent
4. 如有 Adapt 需求（如卡片数不匹配），按 spec 中"适配"指令调整：
   - 增删卡片：复制/删除 `.card` 元素，保留其内部结构
   - 改 grid 列数：`.grid.g3` → `.grid.g2` 或 `.grid.g4`
   - 增删柱子：复制/删除 `.bar` 元素，按数据比例调整 `style.height`
5. 将 spec 中的"逐字稿"内容放入 `<aside class="notes">`（如 slide 模板中无此元素，在 `</body>` 前添加）
6. 写入 `slides/NN-slug.html`
7. **最后一步硬检查**：确认 `<body>` 带有 `data-skeleton="t1"` 属性。这是写入文件后的**收尾必查**——缺它会让校验器把该页当 T2 处理，触发 DIV_BARE_TEXT / compact-header / SVG 等一整片误报 ERROR。模板源文件多数已自带；若缺失，必须手补 `<body ... data-skeleton="t1">` 再交付。（也可由 `batch-fix.mjs --fix inject-data-skeleton` 兜底，但 subagent 应在写入时就带齐。）

完成即报 `DONE: slides XX-YY replaced (T1)`。

### T1 自检

- [ ] 所有 `data-replace` 元素的 textContent 已替换为真实内容？
- [ ] 没有删除或修改任何 class / inline style？
- [ ] 没有添加 `<style>` 块或新 class 名？
- [ ] 没有修改 SVG / 装饰层 / 容器结构？
- [ ] footer 页码正确？
- [ ] `<aside class="notes">` 已填入逐字稿？
- [ ] 没有残留的模板原文字（未替换的 data-replace 元素）？
- [ ] `<body>` 已设置 `data-skeleton="t1"`？

---

## 已知 validate 陷阱（写入时主动避开，避免 post-process 后仍报错）

<!-- BEGIN TRAP_RULES -->
这些规则在 validate.mjs 里是硬 ERROR（或永久 WARNING），但都是"机械格式"问题，写对一次就不再犯。**别等校验报错再回头改**——生成时直接按下方格式。

### 1. 裸文字 div：包 `<span>`，绝不改成 `<p>` 或 `<h>`

- ✗ `<div>裸文字</div>`
- ✗ `<div>裸文字</div> → <p>裸文字</p>（禁止改标签）`
- ✓ `<div><span>裸文字</span></div>（class/属性原样留外层 div）`

> 模板自带白名单 class（.n .l .tl-title .tl-meta .tl-desc .arch-box .sub .q-label）可保留裸文字。批量兜底：batch-fix.mjs --fix div-bare-text。

### 2. 别把单边 border + border-radius 混用

- ✗ `<div style="border-left:1px solid red;border-radius:8px">`
- ✓ `四边 border: 1px solid red + border-radius`
- ✓ `或干脆不加单边 border，用独立装饰元素`

> 单边 border + 圆角在 PPTX 渲染时方角不跟弧。

### 3. `<p>/<h>/<li>` 不带 border/background/box-shadow

- ✗ `<p style="border-left:1px solid var(--border)">文本</p>`
- ✗ `<p style="background:#f00">文本</p>`
- ✓ `<div class="insight-line"><p>文本</p></div>（border 移到外层 div）`
- ✓ `装饰线用外层 div 或 padding`

> 为 PPTX 转换高效：hybrid v2 原生重建 <p> 时不处理 border。全插件统一禁 <p> border。

### 4. 可见区不用 emoji

- ✗ `<p>© 2024</p>`
- ✗ `<span>★ 推荐</span>`
- ✗ `<div>✓ 已完成</div>`
- ✓ `用文字 "©" 写成 "Copyright" 或用 SVG 图标`
- ✓ `★/✓ 用 SVG icon 或 CSS 图形`

> emoji 仅限：data-replace 占位槽（将被替换）或 <code>/<pre> 代码字面量——这两类自动豁免。xhs-pastel-card 等美学模板的 emoji 占位也属豁免。

### 5. 封面/结束页不放 `.slide-number`（T2 手写页）

- ✗ `<div class="slide-number">1</div> 放在 01-cover.html`
- ✓ `内容页才用 .slide-number；封面/结束页用 D 骨架居中排版`

> T1 模板自带封面页码是设计选择，已豁免；此条针对 T2 手写页。

### 6. 标题换行不用连续 `<br>`

- ✗ `<h2>第一行<br><br>第二行</h2>（≥2 连续 <br>）`
- ✓ `CJK 大标题用 CSS keep-all + balance + overflow-wrap 接管换行`
- ✓ `确需断点用 <wbr> 而非 <br>`

> 误判用 <wbr>（零宽换行机会），不触发 CONSECUTIVE_BR。

### 7. T1 模板的 data-replace 槽必须填内容

- ✗ `<div data-replace="title"></div>（空）`
- ✓ `<div data-replace="title">实际标题</div>`
- ✓ `icon 槽可填 <svg>/<img>（无文字也算非空）`

> subagent 复制 T1 模板后必须替换所有 data-replace 区域。

### 8. 不在 slide 的 `<style>` 里重定义标准组件类

- ✗ `<style>.card { ... }</style>（重定义 tokens.css 的 .card）`
- ✓ `标准组件类（.card/.point/.takeaway/.pill 等）只引用不重定义`
- ✓ `自定义样式用独立 class 名`

### 9. `<!-- role: xxx -->` 用裸 ID，别带说明文字

- ✗ `<!-- role: cover — 开场钩子 -->`
- ✓ `<!-- role: cover -->（ID 字符仅 [A-Za-z0-9_-]）`

> 多余文字曾导致"唯一角色数"统计虚高 → ROLE_DIVERSITY_LOW 误报。

### 10. image-manifest：CSS-only deck 也要交一份

- ✗ `全 CSS deck 不写 image-manifest.md`
- ✗ `写空表留 0 OK`
- ✓ `每个 [visual: xxx]（非 none）页标 SKIPPED`
- ✓ `真实生图失败的页如实标 FAILED（全 FAILED 会报 VISUAL_ALL_FAILED）`

> 批量兜底：batch-fix.mjs --fix sync-image-manifest（仅 manifest 缺失时生成全 SKIPPED，绝不覆盖已有）。
<!-- END TRAP_RULES -->

### 11. 内容保真：逐字稿/outline 的数字与阶段数 1:1 保留（CONTENT_FIDELITY）

> 这是**内容层规则**（非 HTML 写法陷阱），单独维护。validate 的 `content-fidelity` check 从 DECK_NOTES 逐字稿提取「数字+量词」锚点（如「9 阶段」「31 项」「1036」），缺锚点报 WARNING。

- ✗ 逐字稿「九大阶段」→ slide 画成 3 波次时间轴（丢 67% 明细）
- ✗ 逐字稿「31 个子任务」→ 压成 8 条 bullet
- ✗ 逐字稿「1036 台」→ 算成 636（渲染阶段自作主张改数字）
- ✓ 逐字稿「9 阶段」→ slide 保留 9 个阶段节点（用甘特/多阶段时间线承载）
- ✓ 逐字稿「1036」→ slide 原样 1036

**执行**：压缩发生在画 HTML 这一步。每页写完，对照该页逐字稿的关键数字/阶段数/子任务数，1:1 保留，不合并、不概括、不改数字。结构承载不下时（slot 不够），换更密集的布局（甘特/矩阵/分层），而非压缩内容。

**节点 gloss 规则**：结构页（甘特工序/时间线节点/流程步骤/架构层/矩阵单元）的**每个节点** = **name**（≤8字标题）+ **gloss**（15-25字一句话说明）。

---

## T2 操作规则（通用骨架——fallback 路径）

### T2 四条核心规则（违反任何一条则该页无效）

### 1. 只替换占位符
spec 的 HTML 骨架中所有 `[xxx]` 标记是你要替换的内容。其他一切——class 名、标签结构、CSS 变量、inline style——**原样保留**。

### 2. 禁止写 CSS
不要在 `<style>` 中定义任何样式。不要添加 inline style。骨架中的 inline style 已足够。所有 class 样式已在 `tokens.css` 中。

### 3. 禁止发明 class 名
骨架中的 class（`.card`、`.kpi-grid`、`.timeline`、`.slide-top-bar` 等）原样保留。不要添加新 class，不要重命名。

### 4. 颜色保持 var(--xxx)
骨架中已全部使用 CSS 变量。替换 `[xxx]` 内容时，不要引入 `#xxxxxx` 或 `rgb()`。
> 强调色走官方 token + 预置 class（见下「重点页强调」段）：`--hi-strong`/`--hi-positive`/`--hi-warning`/`--data-1..6` 均可用，仍属 `var(--xxx)`，不算自由 CSS。

### T2 操作步骤

1. 读取分配的 `specs/PPT-NN.md`
2. 读「## 骨架源」段 → **优先级**：
   - 若指向 **`T2-prebaked（t2-skeletons.md#<template>-<layout>）`**（首选）：打开 `references/t2-skeletons.md`，定位该锚点，**原样复制整段 HTML**（已合并 Style Transfer delta + 配套 CSS）。**不要重推理、不要从别处拼骨架**——直接进入步骤 5 替换占位符。
   - 若指向 **layout-catalog Lxx**（回退，无预置时）：局部读 layout-catalog.md 中该布局的 HTML 骨架段（grep/offset，勿整文件加载），再读「## Style Transfer 注入」段把 delta 应用上去。
3. （仅回退路径）读「## Style Transfer 注入」段 → 把列出的 delta（空间密度/排版层级/装饰模式/禁止元素）应用到骨架上。**预置路径跳过此步**——delta 已在骨架里。
4. 读「## 幻灯片可见内容」段 → 这是占位符到真实内容的映射
5. 将骨架中的每个 `[xxx]` 替换为映射表中对应的真实内容（预置骨架占位符如 `[SECTION_NUM]` `[PHASE_1_TITLE]` `[CELL_1_DESC]` 等）
6. 将「## 逐字稿」段的内容放入 `<aside class="notes">`
7. 写入 `slides/NN-slug.html`

完成即报 `DONE: slides XX-YY generated (T2)`。

### T2 自检

- [ ] 所有 `[xxx]` 已替换为真实内容？
- [ ] 没有添加 `<style>` 块？
- [ ] 没有添加新的 class 名？
- [ ] 没有硬编码颜色（`#xxx` / `rgb()`）？
- [ ] footer 页码正确？
- [ ] `<aside class="notes">` 已填入逐字稿？
- [ ] 没有引入模板禁止的视觉元素（参考 spec 中"Style Transfer 注入检查"段）？
- [ ] `<body>` 已设置 `data-skeleton="t2"`（建议）？

---

## 骨架速查（仅供参考——T1 骨架在模板原件，T2 骨架在 layout-catalog 对应布局段）

| 骨架 | 外观 |
|------|------|
| A（标准） | `.slide-top-bar` + `.page-header`(kicker+title+lede) + `.page-body`(内容) + `.tech-footer` |
| B（紧凑） | 同上 + `body.compact-header` + page-body gap:14px |
| C（数据） | `.slide-top-bar` + `.page-header`(kicker+title) + `.page-body`(图表组件) + `.tech-footer` |
| D（封面/结束） | 居中排版 + `.cover-content`（不用 page-header/tech-footer，**不放 `.slide-number`**——封面/结束页不编号是设计约定） |

---

## 数据页（角色 C）图表组件选型与使用

骨架 C 的 `.page-body` 是图表组件。生成数据页时（无论 T1/T2），按以下流程，**不要从零手写图表**：

### 1. 选型（以 charts-index.json 为唯一真相源）

**spec 的 `chart:` 字段为权威**——主 agent 在 Phase 4.2 已按 `templates/charts/charts-index.json` 的 `quickLookup`（15 意图键全覆盖）选好图表写进 spec。subagent **照抄 `templates/charts/<key>.html` 即可，不自行重推**（quickLookup 表不在本文件重复，主 agent 与 subagent 共用 charts-index.json 这一个真相源）。

意图重叠时，主 agent 用下方 tiebreaker 消歧（SKILL.md §4.2 指向此处）；subagent 只在 spec 真的缺 `chart:` 字段时才回退参考：

**tiebreaker 决策规则**（意图重叠时按此消歧）：

- **单值达成**：要"进度感"用 `progress`；要"仪表盘视觉"用 `gauge`；要"目标线+及格/优秀区间"用 `bullet`
- **占比**：≤6 类且要中心数字 → `donut`；纯占比无中心 → `pie`；>6 类或层级 → `treemap`
- **趋势**：普通时间序列 → `line`；强调累积总量/堆叠 → `area`
- **对比**：单系列 → `bar`；多系列 → `grouped_bar`；含构成 → `stacked_bar`
- **多维**：维度≤8 且要雷达视觉 → `radar`；要带评分进度条 → `rating_score`

不确定时看 `charts-index.json` 每条的 `useCases`/`avoidFor`/`keywords` 字段，或人工浏览 `templates/charts/README.md`。

### 2. 使用（复制 + 替换）
1. 读 `templates/charts/<选中>.html`
2. 复制 HTML 片段（不含注释）到 slide `<body>` 的 `.page-body`
3. 替换 `{{}}` 占位符与示例数值
4. **CSS 类无需重写**——已在 `shared/tokens.css` 预置，slide 已 `<link>` 它

### 3. 硬约束（与 T1/T2 颜色规则一致）
- **颜色一律 `var(--accent)` 等 token**，禁止硬编码 `#xxx`（否则换肤失效）
- **多系列分色用 `var(--data-1..6)`**（Okabe-Ito 色盲安全 6 色，由 switch-theme --palette 注入），不再全 `--accent` 单色循环——多系列柱/堆叠/对比图，第 N 系列用 `--data-N`
- 高度/宽度/位置百分比按模板注释公式换算（如柱图 `height:%` 需容器确定高度；瀑布 `bottom%/height%` 按量程算）
- 曲线类（line/area/radar/scatter）是内联 SVG，改数据时按注释给的坐标公式重算
- **PPTX 导出**：全部 `render=css` 或 `svg-inline`，导出友好；**优先用本库，而非 Chart.js**（后者导出会 rasterize 失真）。layout-catalog 的 L13/L14/L15/L16 若嵌了 Chart.js canvas，仅作参考，实际复制 `templates/charts/` 对应模板

---

## 重点页强调（受控逃生舱：预置强调 class + 语义 token）

> 解决 HTML 产物「重点不突出、强调色与主色同色系」问题。
> 不放开自由 CSS——强调走**官方预置 class + token**，subagent 只引用不发明。强调**决策集中在主 agent 路由表**（`[emph:]` 标注），subagent 只执行。

### 强调动作白名单（全部预置在 `templates/shared/semantic-tokens.css`，由 switch-theme 幂等并入 tokens.css）

| `[emph:]` 标注 | 挂的 class | 用 token | 适用 |
|---------------|-----------|---------|------|
| `kpi-strong` | `.kpi-emph` | `--hi-strong`（CTA） | 关键数字放大 + CTA 强调色：KPI / 核心数据页 |
| `takeaway` | `.takeaway-emph` | `--grad-emph`（CTA 渐变底） | 结论/金句强调底：核心结论页 |
| `data-strong` | `.data-emph` | `--hi-strong` | 行内数据强调：高亮单个指标/数字 |
| `positive` | `.metric-positive` | `--hi-positive`（稳定绿） | 正向：增长/达成/成功 |
| `warning` | `.metric-warning` | `--hi-warning`（稳定红） | 警示：风险/下降/未达 |
| `emph-border` | `.emph-border` | `--hi-strong` 半透 | 次级重点框（弱强调，不抢 CTA） |

**关键**：
- `--hi-strong`（CTA）与 `--data-1..6` 是 **per-palette**，随行业色板变（switch-theme --palette 注入，与 15 brand key 同批）。
- `--hi-positive`（绿）/ `--hi-warning`（红）是**稳定语义层**，跨 deck 不变（红永远=负向、绿永远=正向）。
- 全走 token + 预置 class，**零字面色** → `validate.mjs` 仍能检出硬编码色（无 `#xxx` 回潮）。

### `[emph:]` 标注规则（主 agent 在 spec/路由表写，subagent 读到即挂对应 class）

- 主 agent 在 4.2 路由时，对「重点页/重点元素」标 `[emph: <动作>]`，如 `[emph: kpi-strong]`、`[emph: takeaway]`、`[emph: positive]`。
- spec 在「内容映射」或「幻灯片可见内容」段写明：`[emph: kpi-strong] 挂在 {{核心数字}} 上`。
- subagent 见 `[emph:]` 即按上表挂对应 class 到对应元素——**不自行决定强调级别**，不发明 class。
- T1/T2 均可挂：T1 在 `data-replace` 替换的元素上挂 class（保留外层结构）；T2 在占位符替换处挂。

### Anti_Patterns 约束（来自 advisor ui-reasoning，进 brief/brand-spec，subagent 必须遵守）

- **禁 AI purple/pink gradients**（ui-reasoning 多行业 Anti_Patterns 共识，防 AI 退化默认审美）——subagent 不引入紫粉渐变，即使模板有渐变也只用 `--grad-soft`/`--grad-emph` 等官方 token 渐变。
- 行业特定 Anti_Patterns（如金融「禁活泼设计 + 隐藏凭证」、医疗「禁 bright neon + motion overload」）由 advisor 检索结果写入 brief，subagent 照约束执行。
- Style_Priority 里的 Glassmorphism / Liquid Glass / Claymorphism 等 SVG 专属风格**仅作建议文本，不自动落地**（HTML 模板画不出，渲染 gap）——subagent 不尝试实现这些风格。

---

## 复合骨架组合白名单（003 主线三 F）

> 单页 page-body 需承载两类异类组件时，主 agent 在 outline 标 `[composite: x+y]`（见 `annotation-spec.md` §三），路由表 `骨架源` 指向 `layout-catalog.md` §九对应形态。subagent 见 `[composite:]` 即按下表组合——**class 全部来自 tokens.css 已有，不发明新 class**（与 T1 规则2「禁发明 class」、T2 规则2/3「禁 CSS」一致）。

| `[composite:]` 标注 | 形态 | 组合的现有 class | offset |
|--------------------|------|-----------------|--------|
| `cards+flow` | 上半卡 + 下半流程 | `.grid.g3` + `.card` ×3 + `.flow`/`.node` ×3-5 | layout-catalog §九形态1 |
| `list+flow` | 左列表 + 右流程 | `.grid.g2` + `.point` ×3-5 + `.flow`/`.node` ×3-5 | §九形态2 |
| `kpi+table` | 顶 KPI + 底明细 | `.grid.g4` + `.kpi` ×4 + `.cs-table`/`.table`/`.info-bar` | §九形态3 |

**执行纪律**：
- 两区域间用 `.mt-l`（margin-top 40px）或 deck overlay 分区间距，**不新增容器 class**。
- **一页一个 composite**，不 `cards+flow+kpi` 三类混用（容量爆炸 + 视觉混乱）。
- **复合骨架是溢出处理优先级第 2 档**（见下方「空间利用率硬约束」③）：内容超出单组件承载时优先用 composite 组合承载，而非压缩单组件到一半空间。

---

## 空间利用率硬约束（V2，防过度压缩丢空间）

> 原则：**宁可让内容撑满再考虑拆页，不可为"安全"而压缩到只用一半**（如架构图只用上半页、时间线降级成小卡片）。

### ① 硬阈值表（生成时即做对，违反即改）

| 类型 | 阈值 | 理由 |
|------|------|------|
| **page-body 高度占比** | ≥ 80%（内容页）/ ≥ 70%（封面） | 架构图/时间线应撑满主体，不可只占一半 |
| **gap 下限** | ≥ 16px（卡片间）/ ≥ 12px（卡片内元素） | gap:6px 是过度压缩信号 |
| **padding 下限** | ≥ 16px（卡片内）/ ≥ 24px（page-body 外边距） | padding:6-10px 是过度压缩信号 |
| **字号下限** | 正文 ≥ 15px / 标题 ≥ 20px / KPI 大数字 ≥ 36px | 防"缩字塞内容" |

### ② 生成时自检（画完一页即查）
1. 目测：内容是否撑满 page-body 主体区（非底部留大块空白）？
2. 检查 gap/padding：有没有 < 阈值的？（有则放大到阈值）
3. 架构/分层类页：层数是否撑满 page-body 高度？（只画 3 层却留半页空白 = 错）

### ③ 溢出处理优先级（防"压缩逃避"，不可直接压缩到只剩一半）
1. **优先用密集布局承载**（预置的 gantt / flow / arch 骨架）
2. **用复合 page-body**（F，`cards+flow` 等 composite 组合）
3. **实在放不下 → 拆页**（两页比一页挤一半好）
4. **最后才考虑微调字号/padding**（且不低于①表阈值）

### ④ 反模式（命中即改）
- ✗ `gap:6px` / `padding:6px 10px`（过度压缩）
- ✗ 架构图只画上半页，下半页空白
- ✗ 时间线/甘特缩成 3 个小卡片塞角落
- ✗ 为"安全"主动留 50% 空白
- ✓ 内容撑满 page-body，留白均匀（顶部/底部对称，非底部大块空）

> 规格/预置骨架已应用空间策略的（大间距、大字号、多装饰）**不要改小**——那是主 agent 有意为之。
> 本段是**指引性规则**（subagent 自检 + 主 agent 抽查），不进 `validate.mjs` 自动校验（避免误报，留人工判断空间）。
