#!/usr/bin/env node
/**
 * export_pptx.mjs — 把多文件演示稿导出为 PPTX
 *
 * 两种模式：
 *   --mode image     图片铺底，视觉 100% 保真，文字不可编辑
 *   --mode editable  hybrid 模式：全页截图做背景（保留渐变/SVG/装饰）+ 可编辑文本框叠加
 *
 * 用法：
 *   # 图片模式
 *   node export_pptx.mjs --slides <dir> --out <file.pptx> --mode image
 *   # hybrid 模式（默认）
 *   node export_pptx.mjs --slides <dir> --out <file.pptx>
 *
 * --mode image 特点：
 *   - 每张 slide 截图成 PNG，满铺一张 PPTX 页面
 *   - 视觉 100% 保真（因为就是图片）
 *   - 文字不可编辑
 *   - HTML 随便写，不挑格式
 *
 * --mode editable 特点（hybrid）：
 *   - Playwright 隐藏文本元素后截取纯装饰背景（渐变、SVG、background-image 等）
 *   - 文本元素（p/h1-h6/ul/ol）提取为可编辑文本框叠加在截图上
 *   - 截图中不含文字，确保 PPT 中双击即可编辑、不会出现文字重叠
 *   - 仅 2 条硬约束：1) 文字必须用 <p>/<h1>-<h6> 包裹  2) <p>/<h*> 不能有 background/border/shadow
 *
 * 依赖（plugin 分发包不含 node_modules，缺失时脚本会打印安装命令）：
 *   --mode image:    npm install playwright pptxgenjs
 *   --mode editable: npm install playwright pptxgenjs sharp
 *
 * 按文件名排序（01-xxx.html → 02-xxx.html → ...）。
 */

import fs from 'fs/promises';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { dep } from './_resolve.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function parseArgs() {
  const args = { width: 1920, height: 1080, mode: 'editable' };
  const a = process.argv.slice(2);
  for (let i = 0; i < a.length; i += 2) {
    const k = a[i].replace(/^--/, '');
    args[k] = a[i + 1];
  }
  if (!args.slides || !args.out) {
    console.error('用法: node export_pptx.mjs --slides <dir> --out <file.pptx> [--mode image|editable] [--width 1920] [--height 1080]');
    process.exit(1);
  }
  args.width = parseInt(args.width);
  args.height = parseInt(args.height);
  args.parallel = parseInt(args.parallel) || 0;  // 0 = serial, N = concurrent pages
  if (!['image', 'editable'].includes(args.mode)) {
    console.error(`未知 --mode: ${args.mode}。支持: image, editable`);
    process.exit(1);
  }
  return args;
}

async function exportImage({ slidesDir, outFile, files, width, height }) {
  console.log(`[image mode] Rendering ${files.length} slides as PNG...`);

  const { chromium, pptxgen } = globalThis.__deps;
  const browser = await chromium.launch();
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'slides-pptx-'));
  const pngs = files.map(f => path.join(tmpDir, f.replace(/\.html$/, '.png')));

  // Serial rendering to avoid Playwright screenshot timing issues
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    const url = 'file://' + path.join(slidesDir, f);
    const page = await browser.newPage({ viewport: { width, height } });
    await page.goto(url, { waitUntil: 'networkidle' }).catch(() => page.goto(url, { waitUntil: 'networkidle' }));
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(() => document.getAnimations().forEach(a => {
      // finish() throws InvalidStateError for infinite animations (iterations: Infinity)
      try {
        const t = a.effect?.getTiming?.();
        const infinite = t && !isFinite(t.iterations);
        if (infinite) a.cancel(); else a.finish();
      } catch { try { a.cancel(); } catch {} }
    }));
    // Wait for all images (e.g. large background.png) to finish loading
    await page.evaluate(() => Promise.all(
      Array.from(document.images).map(img => img.complete ? Promise.resolve() :
        new Promise(r => { img.onload = r; img.onerror = r; }))
    ));
    await page.screenshot({ path: pngs[i], fullPage: false });
    await page.close();
    console.log(`  [${i + 1}/${files.length}] ${f}`);
  }

  await browser.close();

  const pres = new pptxgen();
  const slideW = width / 96;
  const slideH = height / 96;
  pres.defineLayout({ name: 'DECK', width: slideW, height: slideH });
  pres.layout = 'DECK';
  for (const png of pngs) {
    const s = pres.addSlide();
    s.addImage({ path: png, x: 0, y: 0, w: slideW, h: slideH });
  }
  await pres.writeFile({ fileName: outFile });

  for (const p of pngs) await fs.unlink(p).catch(() => {});
  await fs.rmdir(tmpDir).catch(() => {});

  console.log(`\n✓ Wrote ${outFile}  (${files.length} slides, image mode, 文字不可编辑)`);
}

async function exportEditable({ slidesDir, outFile, files, parallel }) {
  console.log(`[hybrid v2] System-font aligned backgrounds + universal text extraction for ${files.length} slides...`);

  const { chromium, pptxgen } = globalThis.__deps;

  // 动态 require html2pptx.js（CommonJS 模块）
  const { createRequire } = await import('module');
  const require = createRequire(import.meta.url);
  let html2pptx;
  try {
    html2pptx = require(path.join(__dirname, 'html2pptx.js'));
  } catch (e) {
    console.error(`✗ 加载 html2pptx.js 失败：${e.message}`);
    console.error(`  html2pptx.js 是本地模块；若报缺 sharp/playwright，依赖经 _resolve.mjs 的缓存目录解析。`);
    process.exit(1);
  }

  const pres = new pptxgen();

  // 自动从第一页 HTML 的 body 尺寸推导 PPTX layout（chromium 已在 main() 前置加载）
  const browser = await chromium.launch();

  const probePage = await browser.newPage();
  const firstFile = path.join(slidesDir, files[0]);
  await probePage.goto('file://' + firstFile, { waitUntil: 'networkidle' }).catch(() => {});
  // Inject system fonts on probe page too so dimensions are correct
  await html2pptx.injectSystemFonts(probePage);
  const bodyBox = await probePage.evaluate(() => {
    const s = getComputedStyle(document.body);
    return { w: parseFloat(s.width), h: parseFloat(s.height) };
  });
  await probePage.close();
  const slideW = bodyBox.w / 96;
  const slideH = bodyBox.h / 96;
  pres.defineLayout({ name: 'DECK', width: slideW, height: slideH });
  pres.layout = 'DECK';
  console.log(`  Auto-detected slide size: ${bodyBox.w}px × ${bodyBox.h}px → PPTX ${slideW.toFixed(3)}" × ${slideH.toFixed(3)}"`);

  const { extractSlideData, addBackground, addElements } = html2pptx;

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'slides-hybrid-'));
  const errors = [];

  // 预分配所有 slide 以保证顺序
  const slides = files.map(() => pres.addSlide());

  // 处理单张 slide
  async function processSlide(i) {
    const f = files[i];
    const fullPath = path.join(slidesDir, f);
    const screenshotPath = path.join(tmpDir, f.replace(/\.html$/, '.png'));

    const page = await browser.newPage();
    await page.setViewportSize({ width: Math.round(bodyBox.w), height: Math.round(bodyBox.h) });
    await page.goto('file://' + fullPath, { waitUntil: 'networkidle' }).catch(() => page.goto('file://' + fullPath, { waitUntil: 'networkidle' }));

    // V2: Inject system fonts BEFORE extraction → positions match PPTX rendering
    await html2pptx.injectSystemFonts(page);
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(() => document.getAnimations().forEach(a => {
      // finish() throws InvalidStateError for infinite animations (iterations: Infinity)
      try {
        const t = a.effect?.getTiming?.();
        const infinite = t && !isFinite(t.iterations);
        if (infinite) a.cancel(); else a.finish();
      } catch { try { a.cancel(); } catch {} }
    }));
    await page.evaluate(() => Promise.all(
      Array.from(document.images).map(img => img.complete ? Promise.resolve() :
        new Promise(r => { img.onload = r; img.onerror = r; }))
    ));

    // Extract slide data with TreeWalker-based universal text extraction
    const slideData = await extractSlideData(page);

    // V2: Hide ALL text elements with visibility:hidden (not color:transparent)
    // This properly hides text-shadow, text-stroke, and gradient text
    // Also hide native shapes from screenshot (they'll be PPTX native elements)
    const { textCount, shapeNativeCount, shapeComplexCount, gradCount } = await page.evaluate(() => {
      const TEXT_TAGS = new Set(['P', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'LI', 'UL', 'OL']);
      const INLINE_TAGS = new Set(['SPAN', 'B', 'I', 'U', 'EM', 'STRONG', 'A', 'CODE', 'SMALL', 'MARK', 'SUB', 'SUP']);
      let textCount = 0, shapeNativeCount = 0, shapeComplexCount = 0, gradCount = 0;

      // Hide all text-bearing elements (use visibility:hidden to fully hide text-shadow/stroke too)
      document.querySelectorAll('*').forEach(el => {
        const tag = el.tagName;
        if (TEXT_TAGS.has(tag) || INLINE_TAGS.has(tag)) {
          // Code blocks (<pre>) are kept fully in the screenshot (multi-line monospace
          // syntax highlighting can't be reproduced as native PPTX text). Don't hide
          // any element inside a <pre> — that would strip the highlight colors from
          // the screenshot. The extractor also skips native text emission for <pre>.
          if (el.closest('pre')) return;
          // Check if element has visible text content
          const text = el.textContent?.trim();
          const hasPseudoText = (() => {
            // Bug #1: elements whose ONLY visible text is in ::before/::after content.
            // These have empty textContent but produce rendered text (page numbers,
            // shell prompts, alert icons, chart value labels). Hide them so the
            // screenshot doesn't double-render the pseudo text alongside the native
            // text element the extractor emits.
            if (text) return false;
            for (const p of ['::before', '::after']) {
              const c = window.getComputedStyle(el, p).content;
              if (c && c !== 'none' && c !== 'normal' && c !== '""' && c !== "''") return true;
            }
            return false;
          })();
          if (!text && !hasPseudoText && tag !== 'BR') return;
          // Skip elements inside excluded containers
          if (el.closest('aside.notes, script, style')) return;
          // Bug #4 (revised): gradient/rainbow text is now degraded to a SOLID color
          // (middle gradient stop) and emitted as normal native text. So we hide it
          // from the screenshot just like any other text — no special-casing needed.
          // visibility:hidden properly hides text including shadow/stroke/gradient-text
          el.style.visibility = 'hidden';
          textCount++;
          return;
        }
      });

      // Hide div/span elements that directly contain text and aren't text-tagged
      document.querySelectorAll('*').forEach(el => {
        if (el.style.visibility === 'hidden') return;
        const tag = el.tagName;
        if (TEXT_TAGS.has(tag) || INLINE_TAGS.has(tag)) return;
        // Code blocks (<pre>) are kept fully in the screenshot (multi-line monospace
        // syntax highlighting can't be reproduced as native PPTX text). Don't hide <pre>
        // or anything inside it. (Matches the guard in the text-tag loop above.)
        if (tag === 'PRE' || el.closest('pre')) return;
        // Check for direct text content (not inside already-hidden child text elements)
        let hasDirectText = false;
        for (const child of el.childNodes) {
          if (child.nodeType === Node.TEXT_NODE && child.textContent.trim()) {
            hasDirectText = true;
            break;
          }
        }
        if (hasDirectText && el.style.visibility !== 'hidden') {
          el.style.visibility = 'hidden';
          textCount++;
        }
      });

      // Bug #3: hide SVG <text> labels — they're emitted as native PPTX text by
      // the SVG-text pass, so leaving them in the screenshot would double-render.
      // The rest of the SVG (circles, lines, paths) stays visible as decoration.
      document.querySelectorAll('svg text').forEach(el => {
        if (!el.textContent.trim()) return;
        if (el.closest('aside.notes, script, style')) return;
        if (el.style.visibility !== 'hidden') {
          el.style.visibility = 'hidden';
          textCount++;
        }
      });

      // Hide native shapes from screenshot (they become PPTX native elements).
      // Bug #5: include inline-block SPAN shapes (tags/pills with bg) — without this
      // they double-render (screenshot pill + native shape overlay). Their text is
      // already hidden by the text-hide loop above; this hides the bg pill too so the
      // native shape is the single source.
      const viewW = document.documentElement.clientWidth || window.innerWidth;
      const viewH = document.documentElement.clientHeight || window.innerHeight;
      const shapeSelector = 'DIV, SECTION, ARTICLE, HEADER, FOOTER, MAIN, NAV, ASIDE, SPAN';
      document.querySelectorAll(shapeSelector).forEach(el => {
        if (el.style.visibility === 'hidden') return; // already hidden (e.g. text-bearing span)
        const computed = window.getComputedStyle(el);
        const hasBg = computed.backgroundColor && computed.backgroundColor !== 'rgba(0, 0, 0, 0)';
        // For SPANs specifically, only hide if it's an inline-block/block pill with bg
        // (avoids hiding text-only spans whose bg is transparent — they have no pill to hide).
        if (el.tagName === 'SPAN') {
          const disp = computed.display;
          if (!(disp === 'inline-block' || disp === 'block' || disp === 'inline-flex' || disp === 'flex')) return;
        }
        if (!hasBg) return;
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return;
        // Skip full-body backgrounds
        if (rect.width > viewW * 0.95 && rect.height > viewH * 0.95) return;

        const bgImage = computed.backgroundImage;
        const hasGradient = bgImage && bgImage !== 'none' &&
          (bgImage.includes('linear-gradient') || bgImage.includes('radial-gradient'));
        const hasBackdropFilter = computed.backdropFilter && computed.backdropFilter !== 'none';
        const hasBgImage = bgImage && bgImage !== 'none' && !hasGradient;

        if (hasBackdropFilter || hasBgImage || hasGradient) {
          shapeComplexCount++;
          if (hasGradient) gradCount++;
          return;
        }
        // Don't hide a plain-bg container if it DESCENDS FROM or CONTAINS complex
        // visual effects (gradient bars, backdrop-filter cards, bg-image). Hiding it
        // would erase those descendants from the screenshot even though they're meant
        // to stay as screenshot pixels. E.g. .chart (plain surface bg) wrapping
        // gradient-filled .chart-bars must stay visible. (weekly bar-chart fix.)
        let hasComplexDescendant = false;
        const desc = el.querySelectorAll('*');
        for (let k = 0; k < desc.length && k < 200; k++) {
          const ds = window.getComputedStyle(desc[k]);
          const dbg = ds.backgroundImage;
          if (dbg && dbg !== 'none' && (dbg.includes('gradient') || dbg.includes('url('))) { hasComplexDescendant = true; break; }
          if (ds.backdropFilter && ds.backdropFilter !== 'none') { hasComplexDescendant = true; break; }
        }
        if (hasComplexDescendant) return;
        el.style.opacity = '0';
        el.style.visibility = 'hidden';
        shapeNativeCount++;
      });

      return { textCount, shapeNativeCount, shapeComplexCount, gradCount };
    });

    await page.evaluate(() => new Promise(r => requestAnimationFrame(r)));
    await page.screenshot({ path: screenshotPath, fullPage: false });
    await page.close();

    await addBackground(slideData, slides[i], tmpDir, screenshotPath);
    addElements(slideData, slides[i], pres, screenshotPath, true);

    const covered = slideData.textCoveredCount || 0;
    console.log(`  [${i + 1}/${files.length}] ${f} ✓ (${textCount} text hidden, ${shapeNativeCount} shapes native${gradCount > 0 ? ` + ${gradCount} gradient` : ''}, ${shapeComplexCount} complex in bg, ${covered} text blocks extracted)`);
  }

  // Parallel or serial rendering
  if (parallel > 1) {
    // Parallel: process N slides concurrently.
    const concurrency = Math.min(parallel, files.length);
    console.log(`  Parallel mode: ${concurrency} concurrent pages`);
    let nextIdx = 0;
    const workers = Array.from({ length: concurrency }, async () => {
      while (nextIdx < files.length) {
        const i = nextIdx++;
        try {
          await processSlide(i);
        } catch (e) {
          console.error(`  [${i + 1}/${files.length}] ${files[i]} ✗  ${e.message}`);
          errors.push({ file: files[i], error: e.message });
        }
      }
    });
    await Promise.all(workers);
  } else {
    // Serial rendering (default) — avoids Playwright screenshot timing issues
    for (let i = 0; i < files.length; i++) {
      try {
        await processSlide(i);
      } catch (e) {
        console.error(`  [${i + 1}/${files.length}] ${files[i]} ✗  ${e.message}`);
        errors.push({ file: files[i], error: e.message });
      }
    }
  }

  await browser.close();

  if (errors.length) {
    const contentErrors = errors.filter(e =>
      e.error.includes('overflow') || e.error.includes('dimensions') || e.error.includes('bottom')
    );
    const otherErrors = errors.filter(e => !contentErrors.includes(e));
    if (contentErrors.length > 0) {
      console.error(`\n⚠️ ${contentErrors.length} 张 slide 因内容溢出或尺寸问题失败。`);
    }
    if (otherErrors.length > 0) {
      console.error(`\n⚠️ ${otherErrors.length} 张 slide 转换失败。`);
      otherErrors.forEach(e => console.error(`   - ${e.file}: ${e.error}`));
    }
    if (errors.length === files.length) {
      console.error(`✗ 全部失败，不生成 PPTX。`);
      process.exit(1);
    }
  }

  await pres.writeFile({ fileName: outFile });
  const successCount = files.length - errors.length;
  console.log(`\n✓ Wrote ${outFile}  (${successCount}/${files.length} slides, hybrid v2, 系统字体对齐 + 全元素文本提取)`);

  // 清理临时 PNG（在 writeFile 之后）
  for (const f of files) {
    await fs.unlink(path.join(tmpDir, f.replace(/\.html$/, '.png'))).catch(() => {});
  }
  await fs.rmdir(tmpDir).catch(() => {});
}

async function main() {
  const { slides, out, width, height, mode, parallel } = parseArgs();
  const slidesDir = path.resolve(slides);
  const outFile = path.resolve(out);

  // 前置加载 npm 依赖（只读环境无 node_modules 时，dep() 自动装到 ~/.cache/html-slide-gen）
  // 注：dep() 用 CJS createRequire，直接返回 module.exports；pptxgenjs 的构造器即
  // module.exports 本身（非 .default，与旧 ESM import() 的 .default 包一层不同）。
  const chromium = dep('playwright').chromium;
  const pptxgen = dep('pptxgenjs');
  globalThis.__deps = { chromium, pptxgen };

  const files = (await fs.readdir(slidesDir))
    .filter(f => f.endsWith('.html'))
    .sort();
  if (!files.length) {
    console.error(`No .html files found in ${slidesDir}`);
    process.exit(1);
  }

  if (mode === 'image') {
    await exportImage({ slidesDir, outFile, files, width, height });
  } else {
    await exportEditable({ slidesDir, outFile, files, parallel });
  }
}

main().catch(e => { console.error(e); process.exit(1); });
