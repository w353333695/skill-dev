# Subagent Brief（启动必读，唯一一份）

> 你是 html-slide-gen 的 subagent。**启动只读本 brief 一份**，按主 agent 在 prompt 里给出的「路由表 + 内容映射」执行。不再"先读 subagent-rules 再按情况读 t2-skeletons / layout-catalog / slide-roles"。

## 启动纪律（硬约束）

- **骨架「数据」不并入 brief**——`t2-skeletons.md`（预置锚点）/ `layout-catalog.md`（回退骨架，按 offset 局部读 limit≈44）仍是按锚点/offset 局部读的大文件，本 brief 只收敛「规则」。
- **T2 页**：brief 的「T2 操作步骤」会告诉你该页骨架源是预置锚点还是 offset；按指示**局部读一次**对应骨架段（brief 1 次 + 骨架局部 1 次 = Read ≤ 2 次）。
- **T1 页**：模板源 HTML 路径由主 agent 在路由表里给出。按路由表 cp 模板源 → 替换 data-replace → 注入逐字稿。
- **不需要读 tokens.css**——所需样式已在骨架的 inline style 和 class 中。

## 文件写入约定

- 所有新建产出文件（slides/ 下）使用 Bash heredoc 写入。**关键：EOF 必须加引号禁用 shell 展开**（防止 Markdown 中的反引号、`$` 符号被 shell 解释）：
  ```bash
  cat > slides/NN-slug.html << 'ENDOFFILE'
  ...HTML content...
  ENDOFFILE
  ```
- 修改已有文件使用 Edit 工具
- 模板文件复制使用 `cp`

## data-skeleton 属性要求

**T1 页面 `<body>` 必须包含 `data-skeleton="t1"` 属性**。该属性是校验器（validate.mjs）、后处理（post-process.mjs）和批量修复（batch-fix.mjs）识别 T1/T2 骨架来源的唯一依据——缺少它会触发大量误报 ERROR（DIV_BARE_TEXT、compact-header 等）。模板源多数自带；若缺失，必须手补 `<body ... data-skeleton="t1">` 再交付。

T2 页面建议设置 `data-skeleton="t2"`，方便后续工具区分处理。

---

## 生成期硬约束：trap rules 是「写时首要约束」，不是事后校验清单

> trap rules 在本 brief 里排在操作步骤之前——写每页 HTML 前先看，生成时即做对，不让它进 post-process 才暴露。

### 7 类高频 ERROR：生成期一票否决（写完一页前自检，命中即当场改，不交付给 post-process）

| 高频 ERROR | 生成期约束（写时即做对） |
|-----------|----------------------|
| EMOJI_IN_SLIDE | 可见区禁 emoji，图标一律内联 SVG（currentColor→accent）。emoji 仅 data-replace 占位槽 / `<code>`/`<pre>` 字面量豁免 |
| `<p>/<h>/<li>` + border/background | 装饰线/border 移外层 `<div>`，`<p>/<h>/<li>` 只装文字不装样式 |
| ROLE_UNANNOTATED | 每页 `<!-- role: xxx -->` 用裸 ID（仅 `[A-Za-z0-9_-]`），别带说明文字——生成时即加。**注释放 `<body ...>` 闭合之后**，不可塞进 body 开标签内（否则注释变属性、`>` 泄露成文本） |
| NOTES_ASIDE_MISSING | 每页 `</body>` 前必有 `<aside class="notes">`（逐字稿注入），生成时即加 |
| NONUNIFORM_BORDER_RADIUS | 单边 border 不配 border-radius；要圆角就四边 border |
| data-skeleton 双写 | T1 设 `data-skeleton="t1"`、T2 设 `data-skeleton="t2"`，body 只有一个 data-skeleton（post-process 的 inject 只补缺、不覆盖——你别重复设） |
| **内容保真（CONTENT_FIDELITY）** | 逐字稿（DECK_NOTES）/ outline 里的**阶段数、子任务数、关键数字必须 1:1 保留**，禁止渲染阶段合并/概括。例：逐字稿「九大阶段、31 个子任务、1036 台、4 地、22 项、100%」→ slide 必须出现这些**数字+量词组合**（「9 阶段」/「31 项」/「1036」），不可压成「4 波次」「8 条」。压缩精确发生在渲染最后一步（模型已读懂 outline，画 HTML 时偷懒）——**你在画 HTML 这一步守住** |

### 强调 class 使用（V1，复刻 PPTX 按信息类型常态分色）

PPTX「配色丰富」本质是「按信息类型常态分色」（痛点红卡/目标蓝模块/数据系列色）。**你在写每页时主动挂强调 class**：

| 内容类型 | 挂的 class | 何时挂 |
|---------|-----------|--------|
| KPI 大数字/统计卡 | `.kpi-emph` | 现状全景/成果/规模页的每个核心数字 |
| 关键 takeaway/结论 | `.takeaway-emph` | 每页核心结论句 |
| 数据系列/多系列对比 | `.data-emph`（+ `var(--data-1..6)`） | POC 表/对比矩阵/多系列图 |
| 正向指标（达成/通过） | `.metric-positive` | 100% 通过率/达标项 |
| 警示指标（风险/未达） | `.metric-warning` | 痛点/挑战/未达标 |

**硬约束**：含 KPI/数据/关键 takeaway 的页**至少挂一个**强调 class。全 deck 总使用次数应 ≥ 页数 × 0.5（validate 的 `accent-usage-minimum` check 会查，不足报 WARNING）。class 白名单见 subagent-rules.md「重点页强调」段。

### 生成后即时自检（每写完一页 slide HTML，post-process 之前）

**不要"生成全部 → post-process 报一堆 ERROR → 逐页重写"**。每写完一页 `slides/NN-slug.html`，立即对照下方 trap rules + 上表 7 类一票否决项自检一遍，命中当场 Edit 修掉，再写下一页。这样 ERROR 循环从"多页结构级重写"降为"单页微调"，post-process 首跑即接近 0 ERROR。

自检最小集（T1/T2 通用，逐页过）：
- [ ] 无 emoji 残留（可见区）？
- [ ] `<p>/<h>/<li>` 无 border/background/box-shadow？
- [ ] `<!-- role: xxx -->` 是裸 ID？
- [ ] `</body>` 前有 `<aside class="notes">` 且已填逐字稿？
- [ ] 单边 border 没配 border-radius？
- [ ] body 只有一个 `data-skeleton`（t1 或 t2），无重复属性？
- [ ] 无裸文字 div（裸文字已包 `<span>`，且没改成 `<p>`/`<h>`）？
- [ ] 无硬编码颜色（`#xxx`/`rgb()`）？
- [ ] **内容保真**：该页逐字稿提到的关键数字/阶段数/子任务数，slide 上 1:1 保留（没把「9 阶段」压成「3 波次」，没把「1036」算成「636」）？
- [ ] **强调 class**：含 KPI/数据/takeaway 的页挂了至少一个强调 class（kpi-emph/data-emph/takeaway-emph/metric-positive/metric-warning）？
- [ ] **页码**：该页 `.page-num` 文本 = slide 序号（不是模板源页码或随机数）？
- [ ] **body 干净**：`<!-- role: -->` 注释在 `<body ...>` 闭合**之后**，没塞进 body 开标签内？
- [ ] **甘特图周期**：该页若用 17-gantt 骨架，`data-gantt-start`+`data-gantt-months` 已按**项目实际周期**填（如 6 个月项目 = `start="7" months="6"`）？每条 bar 的 `data-mstart`/`data-mspan` 已按真实工序月份填？**不要手填月份表头、不要手算 left/width%**——这些由 post-process `fixGanttMonths` 自动生成。

完整 trap rules（含正反例）见下一段，写时即参照。

## 甘特图（17-process-flow-gantt）周期适配硬约束

> 甘特骨架是按固定列数写死的，项目实际周期常为 3-6 月。**月份表头与 bar 的百分比由 post-process 接管，你只需声明周期与工序月份。**

**你只做两件事**（其余交给 post-process）：

1. **声明周期**：在 `.cs-gantt` 元素上设 `data-gantt-start="起始月"` + `data-gantt-months="月数"`（如 6 个月项目 7 月起：`start="7" months="6"`）。**跨年自动回绕**（12月→1月），无需特殊处理。
2. **声明每条 bar 的月份**：每个 `.cs-g-bar` 设 `data-mstart="第几月开始(1-based)"` + `data-mspan="跨几个月"`。如「平台部署第2月开工、跨2个月」= `data-mstart="2" data-mspan="2"`。

**禁止**：
- ✗ 手写月份表头（`7月 8月 ...`）—— post-process 按 start/months 自动生成
- ✗ 手算 `style="left:X%;width:Y%"` —— post-process 按 mstart/mspan 重算
- ✗ 保留模板示例月份（7月→次年6月）或里程碑默认日期（9/11/12月）—— 全部按真实项目改
- ✗ 丢弃甘特骨架改用 card —— 排期页必须用 17-gantt 骨架，validate 的 `gantt-skeleton-missing` 会拦

**里程碑**：`ms_1/2/3_date` 填**真实里程碑月份**，须落在 `start..start+months-1` 范围内（如 7-12 月周期的里程碑只能在 7-12 月之间），validate 的 `gantt-month-sequence` 会校验里程碑日期范围。

## 节点 gloss 规则

**硬约束**：结构页（甘特工序 / 时间线节点 / 流程步骤 / 架构层 / 矩阵单元）的**每个节点**必须是：
- **name**（≤8 字标题，如「现状调研」「CMDB 建模」）
- **gloss**（15-25 字一句话说明，如「摸清资产家底，建立 CI 关联拓扑」）

**执行**：写结构页前，先从逐字稿/outline 提取该页的「阶段名 + 一句话」对，再 1:1 映射到节点。宁可节点多+排版密（走密集布局/拆页），不可合并丢明细。


## 已知 validate 陷阱（写入时主动避开，避免 post-process 后仍报错）

<!-- BEGIN TRAP_RULES -->

这些规则在 validate.mjs 里是硬 ERROR（或永久 WARNING），但都是"机械格式"问题，写对一次就不再犯。**别等校验报错再回头改**——生成时直接按下方格式。

### 1. 裸文字 div：包 `<span>`，绝不改成 `<p>` 或 `<h>`

- ✗ `<div>裸文字</div>`
- ✗ `<div>裸文字</div> → <p>裸文字</p>（禁止改标签）`
- ✓ `<div><span>裸文字</span></div>（class/属性原样留外层 div）`

> 模板自带白名单 class（.n .l .tl-title .tl-meta .tl-desc .arch-box .sub .q-label）可保留裸文字。批量兜底：batch-fix.mjs --fix div-bare-text。

### 2. 别把单边 border + border-radius 混用

- ✗ `<div style="border-left:1px solid red;border-radius:8px">`
- ✓ `四边 border: 1px solid red + border-radius`
- ✓ `或干脆不加单边 border，用独立装饰元素`

> 单边 border + 圆角在 PPTX 渲染时方角不跟弧。

### 3. `<p>/<h>/<li>` 不带 border/background/box-shadow

- ✗ `<p style="border-left:1px solid var(--border)">文本</p>`
- ✗ `<p style="background:#f00">文本</p>`
- ✓ `<div class="insight-line"><p>文本</p></div>（border 移到外层 div）`
- ✓ `装饰线用外层 div 或 padding`

> 为 PPTX 转换高效：hybrid v2 原生重建 <p> 时不处理 border。全插件统一禁 <p> border。

### 4. 可见区不用 emoji

- ✗ `<p>© 2024</p>`
- ✗ `<span>★ 推荐</span>`
- ✗ `<div>✓ 已完成</div>`
- ✓ `用文字 "©" 写成 "Copyright" 或用 SVG 图标`
- ✓ `★/✓ 用 SVG icon 或 CSS 图形`

> emoji 仅限：data-replace 占位槽（将被替换）或 <code>/<pre> 代码字面量——这两类自动豁免。xhs-pastel-card 等美学模板的 emoji 占位也属豁免。

### 5. 封面/结束页不放 `.slide-number`（T2 手写页）

- ✗ `<div class="slide-number">1</div> 放在 01-cover.html`
- ✓ `内容页才用 .slide-number；封面/结束页用 D 骨架居中排版`

> T1 模板自带封面页码是设计选择，已豁免；此条针对 T2 手写页。

### 6. 标题换行不用连续 `<br>`

- ✗ `<h2>第一行<br><br>第二行</h2>（≥2 连续 <br>）`
- ✓ `CJK 大标题用 CSS keep-all + balance + overflow-wrap 接管换行`
- ✓ `确需断点用 <wbr> 而非 <br>`

> 误判用 <wbr>（零宽换行机会），不触发 CONSECUTIVE_BR。

### 7. T1 模板的 data-replace 槽必须填内容

- ✗ `<div data-replace="title"></div>（空）`
- ✓ `<div data-replace="title">实际标题</div>`
- ✓ `icon 槽可填 <svg>/<img>（无文字也算非空）`

> subagent 复制 T1 模板后必须替换所有 data-replace 区域。

### 8. 不在 slide 的 `<style>` 里重定义标准组件类

- ✗ `<style>.card { ... }</style>（重定义 tokens.css 的 .card）`
- ✓ `标准组件类（.card/.point/.takeaway/.pill 等）只引用不重定义`
- ✓ `自定义样式用独立 class 名`

### 9. `<!-- role: xxx -->` 用裸 ID，别带说明文字

- ✗ `<!-- role: cover — 开场钩子 -->`
- ✓ `<!-- role: cover -->（ID 字符仅 [A-Za-z0-9_-]）`

> 多余文字曾导致"唯一角色数"统计虚高 → ROLE_DIVERSITY_LOW 误报。

### 10. image-manifest：CSS-only deck 也要交一份

- ✗ `全 CSS deck 不写 image-manifest.md`
- ✗ `写空表留 0 OK`
- ✓ `每个 [visual: xxx]（非 none）页标 SKIPPED`
- ✓ `真实生图失败的页如实标 FAILED（全 FAILED 会报 VISUAL_ALL_FAILED）`

> 批量兜底：batch-fix.mjs --fix sync-image-manifest（仅 manifest 缺失时生成全 SKIPPED，绝不覆盖已有）。
<!-- END TRAP_RULES -->

---

## T1 / T2 操作步骤（合并——按骨架来源分支执行）

Subagent 的角色是**替换占位符**，不是"读 spec + 写 HTML"。根据骨架来源（T1 模板骨架 / T2 通用骨架），操作方式不同。以下四条核心规则违反任何一条则该页无效：

1. **只替换占位符**：T1 替换 `data-replace="key"` 元素的 textContent；T2 替换骨架 HTML 中的 `[xxx]` 标记。其他一切——class、标签结构、CSS 变量、inline style——**原样保留**。
2. **禁止写 CSS / 不发明 class**：不要在 `<style>` 中定义样式、不要加新 class 名。骨架中的 class（`.card`/`.kpi-grid`/`.timeline`/`.slide-top-bar` 等）原样保留。
3. **结构元素零触碰**：装饰层（`.cover-bg`/`.ambient-glow`/`.hero-shot`/SVG）、容器结构（`.grid`/`.card`/`.deck-footer`/`.sidebar`）、body class 和属性——不标注占位符的绝不修改。`<aside class="notes">` 是唯一允许新增的元素（演讲基础设施，`display:none` 不影响视觉）。
4. **颜色保持 var(--xxx)**：骨架已全部使用 CSS 变量。替换内容时不引入 `#xxxxxx` 或 `rgb()`。

### T1 操作步骤（模板骨架——优先路径）

1. 按主 agent 路由表给出的模板文件路径，复制其完整 HTML（`<!DOCTYPE html>` 到 `</html>`）到 `slides/NN-slug.html`
2. 按路由表的「内容映射」段，对每个 `data-replace="key"` 元素替换 textContent：
   - 纯文本槽（`<p data-replace="kicker">旧</p>`）：替换 textContent
   - 带子标签槽（`<div data-replace="stat"><span>旧</span></div>`）：**保留 `<span>`/`<b>` 包装**，替换其内文本节点（子标签无 class，class 在外层 data-replace 元素上）
3. 如有 Adapt 需求（如卡片数不匹配），按路由表「适配」指令调整：
   - 增删卡片：复制/删除 `.card` 元素，保留其内部结构
   - 改 grid 列数：`.grid.g3` → `.grid.g2` 或 `.grid.g4`
   - 增删柱子：复制/删除 `.bar` 元素，按数据比例调整 `style.height`
4. 将路由表「逐字稿」指针（`见 speech.md PPT-NN`）对应的讲稿放入 `<aside class="notes">`（如 slide 模板中无此元素，在 `</body>` 前添加）
5. **动效 class 随模板源保留**：`.anim-*`（如 `.anim-fade-up`/`.anim-rise-in`/`.anim-d4`）和 `.anim-stagger-list` 属模板视觉语言，复制模板源时连同保留；**删除 `data-anim="..."` 属性**（已弃用死代码）
6. **最后一步硬检查**：确认 `<body>` 带有 `data-skeleton="t1"` 属性（缺它会让校验器把该页当 T2 处理，触发一整片误报 ERROR）

完成即报 `DONE: slides XX-YY replaced (T1)`。

### T2 操作步骤（通用骨架——fallback 路径）

1. 读路由表该页的「骨架源」段 → **优先级**：
   - 若指向 **`t2-skeletons.md#<template>-<layout>`（首选预置）**：打开 `references/t2-skeletons.md`，定位该锚点，**原样复制整段 HTML**（已合并 Style Transfer delta + 配套 CSS）。**不要重推理、不要从别处拼骨架**——直接进入步骤 4 替换占位符。
   - 若指向 **layout-catalog Lxx @ offset=N（回退）**：按 offset 局部读 `references/layout-catalog.md`（`Read ... offset=N limit≈44`，**勿整文件加载**），再按路由表「Style Transfer delta」段把 delta 应用上去。
2. （仅回退路径）读路由表「Style Transfer delta」段 → 把列出的 delta（空间密度/排版层级/装饰模式/禁止元素）应用到骨架上。**预置路径跳过此步**——delta 已在骨架里。
3. 读路由表「占位符映射」段 → 这是 `[xxx]` 占位符到真实内容的映射
4. 将骨架中的每个 `[xxx]` 替换为映射表中对应的真实内容（预置骨架占位符如 `[SECTION_NUM]` `[PHASE_1_TITLE]` `[CELL_1_DESC]` 等）
5. 将路由表「逐字稿」指针对应的讲稿放入 `<aside class="notes">`
6. **最后一步硬检查**：T2 页建议 `<body>` 设置 `data-skeleton="t2"`

完成即报 `DONE: slides XX-YY generated (T2)`。

### 自检（T1/T2 通用）

- [ ] 所有占位符（T1 的 `data-replace` / T2 的 `[xxx]`）已替换为真实内容？
- [ ] 没有删除或修改任何 class / inline style？
- [ ] 没有添加 `<style>` 块或新 class 名？
- [ ] 没有修改 SVG / 装饰层 / 容器结构？
- [ ] 没有引入硬编码颜色（`#xxx` / `rgb()`）？
- [ ] footer 页码正确？
- [ ] `<aside class="notes">` 已填入逐字稿？
- [ ] T1：`<body>` 已设置 `data-skeleton="t1"`（必查）；T2：建议 `data-skeleton="t2"`？

---

## 骨架速查（仅供参考——T1 骨架在模板原件，T2 骨架在 layout-catalog 对应布局段）

| 骨架 | 外观 |
|------|------|
| A（标准） | `.slide-top-bar` + `.page-header`(kicker+title+lede) + `.page-body`(内容) + `.tech-footer` |
| B（紧凑） | 同上 + `body.compact-header` + page-body gap:14px |
| C（数据） | `.slide-top-bar` + `.page-header`(kicker+title) + `.page-body`(图表组件) + `.tech-footer` |
| D（封面/结束） | 居中排版 + `.cover-content`（不用 page-header/tech-footer，**不放 `.slide-number`**——封面/结束页不编号是设计约定） |

---

## 数据页（角色 C）图表组件使用要点

骨架 C 的 `.page-body` 是图表组件。生成数据页时（无论 T1/T2），按以下流程，**不要从零手写图表**：

1. **选型以路由表 `chart:` 字段为准**——主 agent 在 Phase 4.2 已按 `templates/charts/charts-index.json` 的 `quickLookup`（15 意图键全覆盖）选好图表写进路由表。subagent **照抄 `templates/charts/<key>.html` 即可，不自行重推**（quickLookup 表不在 brief 重复，主 agent 与 subagent 共用 charts-index.json 这一个真相源）。
2. **使用**：读 `templates/charts/<选中>.html` → 复制 HTML 片段（不含注释）到 slide `<body>` 的 `.page-body` → 替换 `{{}}` 占位符与示例数值。**CSS 类无需重写**——已在 `shared/tokens.css` 预置，slide 已 `<link>` 它。
3. **硬约束（与颜色规则一致）**：颜色一律 `var(--accent)` 等 token，禁止硬编码 `#xxx`；高度/宽度/位置百分比按模板注释公式换算；曲线类（line/area/radar/scatter）是内联 SVG，改数据时按注释给的坐标公式重算。
4. **PPTX 导出**：全部 `render=css` 或 `svg-inline`，导出友好；**优先用本库，而非 Chart.js**（后者导出会 rasterize 失真）。layout-catalog 的 L13/L14/L15/L16 若嵌了 Chart.js canvas，仅作参考，实际复制 `templates/charts/` 对应模板。

> 意图重叠时主 agent 用 tiebreaker 消歧，subagent 只在路由表真的缺 `chart:` 字段时才回退参考 tiebreaker：

- **单值达成**：要"进度感"用 `progress`；要"仪表盘视觉"用 `gauge`；要"目标线+及格/优秀区间"用 `bullet`
- **占比**：≤6 类且要中心数字 → `donut`；纯占比无中心 → `pie`；>6 类或层级 → `treemap`
- **趋势**：普通时间序列 → `line`；强调累积总量/堆叠 → `area`
- **对比**：单系列 → `bar`；多系列 → `grouped_bar`；含构成 → `stacked_bar`
- **多维**：维度≤8 且要雷达视觉 → `radar`；要带评分进度条 → `rating_score`

不确定时看 `charts-index.json` 每条的 `useCases`/`avoidFor`/`keywords` 字段，或人工浏览 `templates/charts/README.md`。

---

## 空间利用率硬约束（V2，防过度压缩丢空间）

> 常见反模式：架构图只用页面一半、时间线降级成小卡片——怕溢出而极致压缩（gap:6px/padding:6px）白丢空间。原则：**宁可撑满再拆页，不可压缩到只用一半**。完整版见 `subagent-rules.md`「空间利用率硬约束」。

**硬阈值（生成时即做对，违反即改）**：

| 类型 | 阈值 |
|------|------|
| page-body 高度占比 | ≥ 80%（内容页）/ ≥ 70%（封面） |
| gap 下限 | ≥ 16px（卡片间）/ ≥ 12px（卡片内） |
| padding 下限 | ≥ 16px（卡片内）/ ≥ 24px（page-body 外边距） |
| 字号下限 | 正文 ≥ 15px / 标题 ≥ 20px / KPI ≥ 36px |

**生成时自检（画完一页）**：①目测内容撑满 page-body 主体（非底部留大块空白）②查 gap/padding 有无 < 阈值（有则放大）③架构/分层页层数撑满 page-body 高度（只画 3 层留半页空白=错）。

**溢出处理优先级（不可直接压缩到只剩一半）**：①密集布局（gantt/A' 预置骨架）→ ②复合 page-body（F，composite 组合）→ ③拆页（两页比一页挤一半好）→ ④最后才微调字号/padding（不低于上表阈值）。

**反模式（命中即改）**：✗ gap:6px / padding:6px 10px；✗ 架构图只画上半页；✗ 时间线/甘特缩成 3 小卡；✗ 主动留 50% 空白。✓ 内容撑满、留白均匀。

路由表/预置骨架已应用空间策略的（大间距、大字号、多装饰）**不要改小**——主 agent 有意为之。本段是指引性规则（自检 + 抽查），不进 validate.mjs。
