# dir-key-nav-minimal

13 张幻灯片，每张一个纯色/渐变 mono-background（indigo / cream / crimson / emerald / slate / violet / white / charcoal，8 色在 13 张里轮换）。灵感直接来自 `20260405 演示幻灯片【方向键版】.html` —— 八个 `t-*` 主题类，方向键切换，极简 editorial 气质。

**Visual traits:** 每张独立背景色 + 单一 accent、巨大无衬线标题自然换行（无强制断行）、4px 短粗 accent line divider、arrow-prefixed mono list、右下 page label、全屏 breathing negative space、mono 字体做数字 / 代码、`content_diagram` 角色可用单色内联 SVG 线条示意图、`content_quote` 角色用 serif 大字做编辑式停顿。键盘提示统一收敛到 index.html 底部 hint-bar，页内不再出现键盘符号。

**Use when:** 有话要说、没太多图、希望用排版节奏推进观众注意力；keynote 式的极简讲稿；每张幻灯只讲一件事；公开分享 / keynote / 演讲稿。

**Source inspiration:** `20260405-Karpathy-知识库/20260405 演示幻灯片【方向键版】.html`.

**Path:** `templates/starter-decks/dir-key-nav-minimal/index.html`
