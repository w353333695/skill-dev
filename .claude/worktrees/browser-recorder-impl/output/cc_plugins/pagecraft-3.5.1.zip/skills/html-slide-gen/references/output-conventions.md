# 产出物目录命名规范

Phase 1.4 创建输出目录时，按以下规则规范化子目录名。

---

## 目录名来源

目录名 `<name>` 来自核心信息（或用户确认的短标题），支持中英文。

## 规范化规则

| 步骤 | 规则 | 示例 |
|------|------|------|
| 1. Trim | 去除首尾空格 | `" 产品发布 "` → `"产品发布"` |
| 2. 合并空格 | 连续空格合并为单个空格 | `"Q4  策略  汇报"` → `"Q4 策略 汇报"` |
| 3. 去除特殊字符 | 移除 `/\:*?"<>|` | `"Q4: 策略/汇报"` → `"Q4 策略汇报"` |
| 4. 禁止隐藏目录 | 不以 `.` 开头 | `.hidden` → 无效 |
| 5. 禁止纯数字 | 目录名不能全是数字 | `2024` → 无效 |
| 6. 长度限制 | 最多 50 字符 | 超出则截断 |
| 7. 空值兜底 | 若处理后为空字符串 | 使用 `presentation` |

## 同名冲突处理

检查 `slides-output/<name>/` 是否已存在：

- 不存在 → 直接使用
- 已存在 → 后缀 `-v2` 递增：检查 `name-v2`、`name-v3`...直到找到不存在的

示例：`slides-output/产品发布/` 已存在 → 尝试 `产品发布-v2` → 如仍存在 → `产品发布-v3`...

> 使用 `-vN` 而非 `-N`（如 `-2`），避免与标题本身含数字混淆（如 "2024策略" → "2024策略-2" 含义模糊，"2024策略-v2" 明确是版本号）。

## 创建目录

确认名称后，一次性创建完整目录树：

```
slides-output/<name>/
├── export/
│   └── <name>-live/
│       ├── slides/
│       ├── shared/
│       └── assets/
```

## 其他命名规范

### Spec 文件

`specs/NN-slug.md`，如 `03-architecture.md`、`07-monitoring.md`。NN 为两位数字页码，slug 为英文短标识。

### Slide HTML 文件

`slides/NN-slug.html`，与 spec 文件保持 slug 一致。

### Assets 文件

`assets/type-description.ext`，如 `logo-primary.svg`、`product-hero.png`、`ui-dashboard.png`。SVG 优先于 PNG。

### 导出文件

PPTX / PDF 使用演讲标题作为文件名：`slides-output/<name>/export/<演讲标题>.pptx`。
