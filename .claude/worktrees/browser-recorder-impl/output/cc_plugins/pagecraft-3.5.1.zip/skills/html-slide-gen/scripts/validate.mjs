#!/usr/bin/env node
// validate.mjs — Deck 产物完整性与正确性校验
// 零依赖静态扫描，在交付/导出前拦截常见错误

'use strict';

import { readdirSync, readFileSync, existsSync, statSync } from 'fs';
import { join, resolve } from 'path';
import { fileURLToPath } from 'url';
import { VOID_ELEMENTS, TEXT_CONTAINER_TAGS, IGNORED_TAGS, DIV_TEXT_WHITELIST_CLASSES, extractTagName, isT1Page, tokenize } from './_html-model.mjs';

// ── ANSI ───────────────────────────────────────────────────────────

const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const GREEN = '\x1b[32m';
const RESET = '\x1b[0m';

// ── CLI ────────────────────────────────────────────────────────────

const CHECK_IDS = ['runtime', 'asset', 'manifest', 'notes', 'css', 'html', 'pptx', 'content', 'emoji', 'visual', 'img-embed', 'layout-rhythm', 'layout-diversity', 'accent-density', 'theme-compliance', 'takeaway-coverage', 'theme-annotation', 'comp-annotation', 'outline-rhythm', 'slide-number', 'forced-br', 'visual-layout', 'comp-redefinition', 'comp-rhythm', 't1-unreplaced', 't1-structure', 'content-fidelity', 'body-tag-clean', 'page-num-correct', 't1-table-rows', 'accent-usage-minimum', 'gantt-month-sequence', 'gantt-skeleton-missing', 'arch-layer-named', 'table-empty-column', 'style-semicolon-corruption', 'cta-placeholder', 'bare-grid-no-columns', 'process-integrity', 'unsized-icon-img'];

function parseArgs(argv) {
  const args = { deck: null, mode: 'all', quiet: false, check: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--deck' && argv[i + 1]) { args.deck = argv[++i]; continue; }
    if (a === '--mode' && argv[i + 1]) { args.mode = argv[++i]; continue; }
    if (a === '--check' && argv[i + 1]) { args.check = argv[++i]; continue; }
    if (a === '--quiet') { args.quiet = true; continue; }
    if (a === '--help' || a === '-h') { printUsage(); process.exit(0); }
    // 拒绝未知 flag（杜绝 --engine v2 等"幽灵 flag"被静默丢弃、调用方误以为生效）
    if (a.startsWith('--')) {
      const base = a.split('=')[0];
      console.error(`Error: 未知 flag "${a}"。`);
      if (base === '--engine') {
        console.error('  提示：`--engine` 已废弃（v2 引擎现已是默认行为，无需指定）。请直接去掉该 flag。');
      }
      console.error('  已知 flag：--deck, --mode, --check, --quiet, --help');
      process.exit(2);
    }
  }
  return args;
}

function printUsage() {
  console.log('Usage: node validate.mjs --deck <dir> [--mode all|strict|editable-strict] [--quiet] [--check <id>]');
  console.log('');
  console.log('  --mode all            P0/P1=ERROR, P2=WARNING (default)');
  console.log('  --mode strict         All checks are ERROR');
  console.log('  --mode editable-strict Like strict, but also promotes CSS_GRADIENT/LOW_ALPHA_BG to ERROR');
  console.log(' Use this before editable PPTX export.');
  console.log('  --quiet               Suppress WARNINGs');
  console.log(`  --check <id>          Run only one check: ${CHECK_IDS.join(', ')}`);
}

// ── Severity ───────────────────────────────────────────────────────

const P2_CHECKS = new Set(['html', 'pptx', 'emoji', 'layout-diversity', 'accent-density', 'takeaway-coverage', 'outline-rhythm', 'visual-layout', 'slide-number', 'comp-annotation']);
const ALWAYS_WARNING = new Set(['content', 'content-fidelity', 'accent-usage-minimum', 'gantt-skeleton-missing', 'arch-layer-named', 'table-empty-column']);  // Content density & fidelity & accent usage & heuristic structural advisory (003 主线二/五/六: 起步 WARNING)
// Rules whose own messages declare them a design choice, not a defect. These stay
// WARNING even in strict mode so they never block. (SLIDE_NUM_ON_COVER message:
// "this is a design choice, not a bug" — but without this it escalates to ERROR in
// strict mode via the 'slide-number' checkId, contradicting its own wording.)
// NOTE: scoped to the *rule*, so genuine slide-number bugs (WRONG_TAG/CHILD_CONTENT/
// INLINE_STYLE) still ERROR.
const ALWAYS_WARNING_RULES = new Set(['SLIDE_NUM_ON_COVER', 'VISUAL_MANIFEST_MISSING']);

// CSS_GRADIENT and LOW_ALPHA_BG are P2 in hybrid/image mode (auto-screenshot preserves them).
// Promote to P0 only in editable-strict mode (editable PPTX can't render them).
const PPTX_PRESERVED_CHECKS = new Set(['CSS_GRADIENT', 'LOW_ALPHA_BG']);

function getEffectiveSeverity(checkId, mode, rule) {
  if (ALWAYS_WARNING.has(checkId)) return 'WARNING';
  if (rule && ALWAYS_WARNING_RULES.has(rule)) return 'WARNING';
  // CSS_GRADIENT and LOW_ALPHA_BG: WARNING in all/default mode, ERROR only in editable-strict
  if (PPTX_PRESERVED_CHECKS.has(rule) && mode !== 'editable-strict') return 'WARNING';
  if (P2_CHECKS.has(checkId) && mode === 'all') return 'WARNING';
  return 'ERROR';
}

// ── Utilities ──────────────────────────────────────────────────────

function getLineNumber(text, offset) {
  let line = 1;
  for (let i = 0; i < offset && i < text.length; i++) {
    if (text[i] === '\n') line++;
  }
  return line;
}

// F4 (2026-06-22): module-level read cache. A single strict run invokes ~26 check
// functions, each formerly calling loadText() independently — a 12-slide deck hit
// ~312 readFileSync calls (26×). validate is read-only (no file mutation during a
// run — post-process fixers write before validate starts), so caching every path
// is safe and collapses the 26× amplification to 1× per file. This replaces the
// "pass slideHTMLCache into every check signature" approach with zero signature
// churn and zero regression surface.
const _textCache = new Map();
function loadText(filePath) {
  let v = _textCache.get(filePath);
  if (v === undefined) {
    v = readFileSync(filePath, 'utf-8');
    _textCache.set(filePath, v);
  }
  return v;
}

function slideFiles(slidesDir) {
  return readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();
}

// ── T1/T2 skeleton detection utilities ─────────────────────────────

function isT1Deck(slidesDir) {
  // Scan up to 3 slides to determine if deck uses T1 template system
  const files = slideFiles(slidesDir);
  const sample = files.slice(0, 3);
  for (const f of sample) {
    const html = loadText(join(slidesDir, f));
    if (isT1Page(html)) return true;
  }
  return false;
}

// ── Parse index.html data ─────────────────────────────────────────

function safeEval(expr) {
  return new Function('return (' + expr + ')')();
}

function parseDeckManifest(indexHtml) {
  const re = /window\.DECK_MANIFEST\s*=\s*(\[[\s\S]*?\])\s*;/;
  const m = indexHtml.match(re);
  if (!m) return null;
  try { return safeEval(m[1]); } catch (e) {
    const line = getLineNumber(indexHtml, m.index);
    throw new Error(`DECK_MANIFEST parse error at index.html L${line}: ${e.message}`);
  }
}

function parseDeckNotes(indexHtml) {
  const startRe = /window\.DECK_NOTES\s*=\s*\{/;
  const startM = startRe.exec(indexHtml);
  if (!startM) return null;
  const openBrace = indexHtml.indexOf('{', startM.index);
  let depth = 0;
  let end = openBrace;
  for (let i = openBrace; i < indexHtml.length; i++) {
    if (indexHtml[i] === '{') depth++;
    else if (indexHtml[i] === '}') {
      depth--;
      if (depth === 0) { end = i + 1; break; }
    }
  }
  try { return safeEval(indexHtml.slice(openBrace, end)); } catch (e) {
    const line = getLineNumber(indexHtml, startM.index);
    throw new Error(`DECK_NOTES parse error at index.html L${line}: ${e.message}`);
  }
}

// ── Check 1: Asset path integrity (P0) ────────────────────────────

function checkAssetPaths(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const deckResolved = resolve(deckPath);

  for (const file of slides) {
    const raw = loadText(join(slidesDir, file));
    // Strip HTML comments before scanning — template source legitimately contains
    // commented-out examples like `<!-- replace with <img src="../assets/..."> -->`
    // which the imgRe would otherwise match as a real (missing) asset reference.
    // (Discovered 2026-06-22 via course-module / hermes template self-checks.)
    const html = raw.replace(/<!--[\s\S]*?-->/g, '');

    // <img src="...">
    const imgRe = /<img[^>]+src=["']([^"']+)["']/gi;
    let m;
    while ((m = imgRe.exec(html)) !== null) {
      validateAssetRef(findings, file, html, m.index, m[1], slidesDir, deckResolved);
    }

    // CSS url() in <style> blocks
    const styleRe = /<style[^>]*>([\s\S]*?)<\/style>/gi;
    let sm;
    while ((sm = styleRe.exec(html)) !== null) {
      const urlRe = /url\s*\(\s*["']?([^"')]+)["']?\s*\)/gi;
      const blockStart = sm.index + sm[0].indexOf('>') + 1;
      let um;
      while ((um = urlRe.exec(sm[1])) !== null) {
        validateAssetRef(findings, file, html, blockStart + um.index, um[1], slidesDir, deckResolved);
      }
    }

    // CSS url() in inline style=""
    const inlineRe = /style="([^"]*)"/gi;
    let im;
    while ((im = inlineRe.exec(html)) !== null) {
      const urlRe = /url\s*\(\s*["']?([^"')]+)["']?\s*\)/gi;
      let um;
      while ((um = urlRe.exec(im[1])) !== null) {
        validateAssetRef(findings, file, html, im.index, um[1], slidesDir, deckResolved);
      }
    }
  }
  return findings;
}

function validateAssetRef(findings, file, html, offset, src, slidesDir, deckResolved) {
  const fileKey = 'slides/' + file;
  // Skip non-file references
  if (src.startsWith('data:') || src.startsWith('#')) return;

  const isExternal = src.startsWith('http://') || src.startsWith('https://');
  const isAbsolute = src.startsWith('/');

  if (isExternal || isAbsolute) {
    findings.push({
      checkId: 'asset', file: fileKey, offset,
      rule: 'ASSET_EXTERNAL',
      message: `"${src}" is ${isExternal ? 'an external URL' : 'an absolute path'}. All assets must be in assets/ or shared/.`,
    });
    return;
  }

  const resolved = resolve(slidesDir, src);
  if (!resolved.startsWith(deckResolved + '/')) {
    findings.push({
      checkId: 'asset', file: fileKey, offset,
      rule: 'ASSET_TRAVERSAL',
      message: `"${src}" escapes deck directory via path traversal.`,
    });
    return;
  }

  if (!existsSync(resolved)) {
    findings.push({
      checkId: 'asset', file: fileKey, offset,
      rule: 'ASSET_MISSING',
      message: `"${src}" -> file not found: ${resolved}`,
    });
  }
}

// ── Check 2: DECK_MANIFEST consistency (P0) ──────────────────────

function checkManifest(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];

  if (manifest === null) {
    findings.push({
      checkId: 'manifest', file: 'index.html', offset: null,
      rule: 'MANIFEST_MISSING',
      message: 'window.DECK_MANIFEST not found in index.html.',
    });
    return findings;
  }

  const manifestFiles = new Set(manifest.map(e => e.file));
  const actualFiles = new Set(slides.map(f => 'slides/' + f));

  for (const entry of manifest) {
    if (!actualFiles.has(entry.file)) {
      findings.push({
        checkId: 'manifest', file: 'index.html', offset: null,
        rule: 'MANIFEST_FILE_MISSING',
        message: `Manifest lists "${entry.file}" but file does not exist in slides/.`,
      });
    }
  }

  for (const af of slides) {
    const key = 'slides/' + af;
    if (!manifestFiles.has(key)) {
      findings.push({
        checkId: 'manifest', file: key, offset: null,
        rule: 'MANIFEST_FILE_UNLISTED',
        message: `"${key}" exists in slides/ but is not listed in DECK_MANIFEST.`,
      });
    }
  }

  return findings;
}

// ── Check 3: DECK_NOTES completeness (P1) ─────────────────────────

function checkNotes(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];

  if (notes === null) {
    findings.push({
      checkId: 'notes', file: 'index.html', offset: null,
      rule: 'NOTES_MISSING',
      message: 'window.DECK_NOTES not found in index.html.',
    });
    return findings;
  }

  if (manifest === null) return findings;

  const manifestFiles = new Set(manifest.map(e => e.file));
  const noteKeySet = new Set(Object.keys(notes));

  for (const entry of manifest) {
    if (!noteKeySet.has(entry.file)) {
      findings.push({
        checkId: 'notes', file: 'index.html', offset: null,
        rule: 'NOTES_MISSING_FOR_SLIDE',
        message: `"${entry.file}" in DECK_MANIFEST but no entry in DECK_NOTES.`,
      });
    } else {
      const val = notes[entry.file];
      if (!val || val.trim().length === 0) {
        findings.push({
          checkId: 'notes', file: 'index.html', offset: null,
          rule: 'NOTES_EMPTY',
          message: `"${entry.file}" has empty notes in DECK_NOTES.`,
        });
      }
    }
  }

  for (const key of noteKeySet) {
    if (!manifestFiles.has(key)) {
      findings.push({
        checkId: 'notes', file: 'index.html', offset: null,
        rule: 'NOTES_ORPHAN',
        message: `"${key}" in DECK_NOTES but not in DECK_MANIFEST.`,
      });
    }
  }

  return findings;
}

// ── Check 3.5: index-runtime.js existence (P0) ─────────────────────

function checkRuntimeJS(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const runtimePath = join(deckPath, 'index-runtime.js');

  // Check file exists on disk
  if (!existsSync(runtimePath)) {
    findings.push({
      checkId: 'runtime', file: 'index.html', offset: null,
      rule: 'RUNTIME_FILE_MISSING',
      message: 'index-runtime.js not found on disk. Copy templates/index-runtime.js AS-IS to the deck directory.',
    });
    return findings;
  }

  // Check file is not empty/stub (< 5000 bytes indicates a stub or broken copy)
  const stat = statSync(runtimePath);
  if (stat.size < 5000) {
    findings.push({
      checkId: 'runtime', file: 'index-runtime.js', offset: null,
      rule: 'RUNTIME_FILE_STUB',
      message: `index-runtime.js is only ${stat.size} bytes (expected >= 5000). File may be a stub or corrupted.`,
    });
  }

  // Check index.html references runtime as external file (not inline)
  if (!/<script\s+src=["']index-runtime\.js["'][^>]*><\/script>/i.test(indexHtml)) {
    findings.push({
      checkId: 'runtime', file: 'index.html', offset: null,
      rule: 'RUNTIME_SCRIPT_MISSING',
      message: 'index.html must reference index-runtime.js via <script src="index-runtime.js"></script>. Do NOT inline the runtime JS.',
    });
  }

  return findings;
}

// ── Check 4: CSS reference consistency (P1) ───────────────────────

function checkCSSRefs(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const themeExists = existsSync(join(deckPath, 'shared', 'theme.css'));

  for (const file of slides) {
    const html = loadText(join(slidesDir, file));

    if (!/<link[^>]+href=["'][^"']*tokens\.css["']/i.test(html)) {
      findings.push({
        checkId: 'css', file: 'slides/' + file, offset: null,
        rule: 'CSS_TOKENS_MISSING',
        message: 'Missing <link> for tokens.css.',
      });
    }

    if (themeExists && !/<link[^>]+href=["'][^"']*theme\.css["']/i.test(html)) {
      findings.push({
        checkId: 'css', file: 'slides/' + file, offset: null,
        rule: 'CSS_THEME_MISSING',
        message: 'shared/theme.css exists but this slide does not link to it.',
      });
    }
  }

  return findings;
}

// ── Check 5: HTML structure basics (P2) ───────────────────────────

function checkHTMLStructure(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');

  // F9 (2026-06-22): NOTES_ASIDE_MISSING fires on every page of a bare template
  // skeleton (starter-decks have no <aside class="notes"> — that's filled at deck
  // generation time). Suppress the notes-aside checks when the deck has no
  // accompanying outline.md/speech.md (i.e. a template self-check, not a generated
  // deck). DOCTYPE/LANG/VIEWPORT still apply — those are skeleton requirements.
  const projectDir = resolve(deckPath, '..', '..');
  const isBareSkeleton = !existsSync(join(projectDir, 'outline.md'))
                      && !existsSync(join(projectDir, 'speech.md'));

  for (const file of slides) {
    const html = loadText(join(slidesDir, file));

    if (!/<!DOCTYPE\s+html>/i.test(html)) {
      findings.push({ checkId: 'html', file: 'slides/' + file, offset: 0, rule: 'HTML_DOCTYPE', message: 'Missing <!DOCTYPE html>.' });
    }
    if (!/<html[^>]*\slang\s*=/i.test(html)) {
      findings.push({ checkId: 'html', file: 'slides/' + file, offset: null, rule: 'HTML_LANG', message: '<html> missing lang attribute.' });
    }
    if (!/<meta[^>]+name\s*=\s*["']viewport["']/i.test(html)) {
      findings.push({ checkId: 'html', file: 'slides/' + file, offset: null, rule: 'HTML_VIEWPORT', message: 'Missing <meta name="viewport">.' });
    }

    if (isBareSkeleton) continue;  // F9: skip notes-aside checks for bare template skeletons

    // Check for <aside class="notes"> — prevents speech content leaking into visible area
    const notesMatch = html.match(/<aside[^>]*\bclass\s*=\s*["'][^"']*\bnotes\b[^"']*["'][^>]*>([\s\S]*?)<\/aside\s*>/i);
    if (!notesMatch) {
      findings.push({ checkId: 'html', file: 'slides/' + file, offset: null, rule: 'NOTES_ASIDE_MISSING',
        message: 'Missing <aside class="notes">. Speech content must go inside this element to stay hidden from the audience.' });
    } else {
      const notesText = notesMatch[1].replace(/<[^>]+>/g, '').replace(/\s/g, '');
      if (notesText.length < 5) {
        findings.push({ checkId: 'html', file: 'slides/' + file, offset: null, rule: 'NOTES_ASIDE_EMPTY',
          message: '<aside class="notes"> exists but is empty or nearly empty. Embed the page speech content here.' });
      }
    }
  }

  return findings;
}

// ── Check 6: PPTX editable pre-check (P2) ────────────────────────
// C1-C5 from validate-pptx.mjs (zero the MANUAL_BULLETS check)

function pptxCheckSVG(html) {
  const findings = [];
  const re = /<svg[\s>]/gi;
  let m;
  // Template-native SVG whitelist (complexity P2.8 / plan L1.1.4): T1 template
  // pages carry their own diagram SVGs as part of the skeleton (force-directed
  // graphs, architecture blueprints, etc.). These are design tokens the subagent
  // cannot replace with <img>, so exempt them from the PPTX pre-check. Only flag
  // SVGs on non-template (T2/hand-written) pages, where an inline SVG is a real
  // PPTX-incompatible choice.
  const isTemplateNative = isT1Page(html);
  while ((m = re.exec(html)) !== null) {
    if (isTemplateNative) continue;
    findings.push({ offset: m.index, rule: 'SVG', message: 'SVG element found. Use <img> with pre-rendered PNG for PPTX.' });
  }
  return findings;
}

function pptxCheckDivBareText(html) {
  // Skip T1 pages — template HTML structure is correct by design
  if (isT1Page(html)) return [];

  const findings = [];
  const tokens = tokenize(html);
  const tagStack = [];
  for (const token of tokens) {
    if (token.type === 'TAG_OPEN') {
      tagStack.push({ tagName: token.tagName, offset: token.offset });
    } else if (token.type === 'TAG_CLOSE') {
      const idx = tagStack.findLastIndex(t => t.tagName === token.tagName);
      if (idx >= 0) tagStack.splice(idx, 1);
    } else if (token.type === 'TEXT') {
      const trimmed = token.text.trim();
      if (!trimmed) continue;
      for (let i = tagStack.length - 1; i >= 0; i--) {
        const { tagName } = tagStack[i];
        if (VOID_ELEMENTS.has(tagName)) continue;
        if (IGNORED_TAGS.has(tagName)) break;
        if (TEXT_CONTAINER_TAGS.has(tagName)) break;
        if (tagName === 'div') {
          // Check if this div's class is in the template-native whitelist
          const tagEnd = html.indexOf('>', tagStack[i].offset);
          const tagHtml = tagEnd >= 0 ? html.slice(tagStack[i].offset, tagEnd + 1) : '';
          const classMatch = tagHtml.match(/class\s*=\s*["']([^"']*)["']/);
          if (classMatch) {
            const classes = classMatch[1].split(/\s+/);
            if (classes.some(c => DIV_TEXT_WHITELIST_CLASSES.has(c))) break;
          }
          const preview = trimmed.substring(0, 50) + (trimmed.length > 50 ? '...' : '');
          findings.push({ offset: token.offset, rule: 'DIV_BARE_TEXT', message: `DIV has bare text "${preview}". Wrap in <p>/<h1>-<h6>/<ul>/<ol>.` });
        }
        break;
      }
    }
  }
  return findings;
}

function pptxCheckGradients(html) {
  // F3 (2026-06-22): T1 template pages exempt — gradients are part of the template's
  // visual DNA (keynote hero overlays, soe progress bars, etc.) and editable hybrid v2
  // preserves them via screenshot. Only flag gradients on T2/hand-written pages.
  // This also covers F11's tokens.css blind spot: T1 decks that centralize gradients
  // in shared/tokens.css (obsidian) are no longer flagged, removing the inconsistency
  // where inline gradients were caught but token-defined ones were invisible.
  if (isT1Page(html)) return [];
  const findings = [];
  const gradientRe = /linear-gradient\s*\(|radial-gradient\s*\(/gi;
  const styleBlockRe = /<style[^>]*>([\s\S]*?)<\/style>/gi;
  let sm;
  while ((sm = styleBlockRe.exec(html)) !== null) {
    const blockStart = sm.index + sm[0].indexOf('>') + 1;
    gradientRe.lastIndex = 0;
    let gm;
    while ((gm = gradientRe.exec(sm[1])) !== null) {
      findings.push({ offset: blockStart + gm.index, rule: 'CSS_GRADIENT', message: `CSS gradient found. Use solid colors or pre-rendered PNG.` });
    }
  }
  gradientRe.lastIndex = 0;
  const inlineRe = /<([a-zA-Z][a-zA-Z0-9]*)[^>]*style="([^"]*)"/gi;
  let im;
  while ((im = inlineRe.exec(html)) !== null) {
    gradientRe.lastIndex = 0;
    let gm;
    while ((gm = gradientRe.exec(im[2])) !== null) {
      findings.push({ offset: im.index, rule: 'CSS_GRADIENT', message: `CSS gradient in inline style on <${im[1]}>. Use solid colors.` });
    }
  }
  return findings;
}

function pptxCheckTextStyles(html) {
  const findings = [];
  const re = /<(p|h[1-6]|li|ul|ol)(?:\s[^>]*)?style="([^"]*)"/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const tag = m[1].toLowerCase();
    const style = m[2];
    const violations = [];
    if (/\bbackground(?:-color)?\s*:\s*(?!transparent|none)/i.test(style) && !/\bbackground(?:-color)?\s*:\s*transparent/i.test(style)) violations.push('background');
    if (/\bborder(?:-\w+)?\s*:\s*[^;]*\d/.test(style)) violations.push('border');
    if (/\bbox-shadow\s*:\s*(?!none)/i.test(style)) violations.push('box-shadow');
    if (violations.length > 0) {
      findings.push({ offset: m.index, rule: 'TEXT_STYLING', message: `<${tag}> has ${violations.join('/')}. Move to wrapping <div>.` });
    }
  }
  return findings;
}

function pptxCheckDivBgImage(html) {
  const findings = [];
  const re = /<div(?:\s[^>]*)?style="([^"]*)"/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    if (/(?:^|;)\s*background(?:-image)?\s*:[^;]*url\s*\(/i.test(m[1])) {
      findings.push({ offset: m.index, rule: 'DIV_BG_IMAGE', message: 'DIV has background-image. Use <img> tag instead.' });
    }
  }
  return findings;
}

function pptxCheckLowAlphaBg(html) {
  // F3 (2026-06-22): T1 template pages exempt — low-alpha backgrounds are part of
  // the template's glass/frosted visual language (obsidian, hermes) and hybrid v2
  // preserves them via screenshot. Covers F11's tokens.css blind spot for T1 decks.
  if (isT1Page(html)) return [];
  const findings = [];
  // Check <style> blocks
  const styleBlockRe = /<style[^>]*>([\s\S]*?)<\/style>/gi;
  let sm;
  while ((sm = styleBlockRe.exec(html)) !== null) {
    const alphaRe = /background(?:-color)?\s*:\s*rgba?\s*\([^)]*,\s*([\d.]+)\s*\)/gi;
    let am;
    while ((am = alphaRe.exec(sm[1])) !== null) {
      const alpha = parseFloat(am[1]);
      if (alpha > 0 && alpha < 0.2) {
        findings.push({ offset: sm.index + am.index, rule: 'LOW_ALPHA_BG', message: `Background alpha=${alpha} in <style> composites differently in PPTX. Pre-compute composited color.` });
      }
    }
  }
  // Check inline style=""
  const inlineRe = /style="([^"]*)"/gi;
  let m;
  while ((m = inlineRe.exec(html)) !== null) {
    const bgMatch = m[1].match(/background(?:-color)?\s*:\s*rgba?\s*\([^)]*,\s*([\d.]+)\s*\)/i);
    if (bgMatch) {
      const alpha = parseFloat(bgMatch[1]);
      if (alpha > 0 && alpha < 0.2) {
        findings.push({ offset: m.index, rule: 'LOW_ALPHA_BG', message: `Background alpha=${alpha} composites differently in PPTX. Pre-compute composited color.` });
      }
    }
  }
  return findings;
}

function pptxCheckNonUniformBorderRadius(html) {
  const findings = [];
  // Check <style> blocks for CSS rule blocks with both border-radius and directional border
  const styleBlockRe = /<style[^>]*>([\s\S]*?)<\/style>/gi;
  let sm;
  while ((sm = styleBlockRe.exec(html)) !== null) {
    const ruleRe = /[^{}]+\{([^}]*)\}/g;
    let rm;
    while ((rm = ruleRe.exec(sm[1])) !== null) {
      const decls = rm[1];
      const hasRadius = /border-radius\s*:\s*[^;]/i.test(decls);
      const hasNonUniform = /(?:^|;)\s*border-(top|bottom|left|right)\s*:\s*\d/i.test(decls);
      if (hasRadius && hasNonUniform) {
        findings.push({ offset: sm.index + rm.index, rule: 'NONUNIFORM_BORDER_RADIUS', message: 'CSS rule has non-uniform border + border-radius. Accent line won\'t follow curve in PPTX. Use uniform border + separate accent div.' });
      }
    }
  }
  // Check inline styles on divs
  const inlineRe = /<div(?:\s[^>]*)?style="([^"]*)"/gi;
  let m;
  while ((m = inlineRe.exec(html)) !== null) {
    const style = m[1];
    const hasRadius = /border-radius\s*:\s*[^;]/i.test(style);
    const hasNonUniform = /(?:^|;)\s*border-(top|bottom|left|right)\s*:\s*\d/i.test(style);
    if (hasRadius && hasNonUniform) {
      findings.push({ offset: m.index, rule: 'NONUNIFORM_BORDER_RADIUS', message: 'Non-uniform border + border-radius won\'t follow curve in PPTX.' });
    }
  }
  return findings;
}

function checkPPTXPrecheck(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  for (const file of slides) {
    const html = loadText(join(slidesDir, file));
    const fns = [pptxCheckSVG, pptxCheckDivBareText, pptxCheckGradients, pptxCheckTextStyles, pptxCheckDivBgImage, pptxCheckLowAlphaBg, pptxCheckNonUniformBorderRadius];
    for (const fn of fns) {
      for (const f of fn(html)) {
        findings.push({ ...f, checkId: 'pptx', file: 'slides/' + file });
      }
    }
  }
  return findings;
}

// ── Check 7: Content overflow detection (P2) ────────────────────────
// Static heuristics — zero dependencies, no browser needed.
// Catches ~80% of overflow cases that would be clipped by overflow:hidden.

const CONTENT_THRESHOLDS = {
  // F12 (2026-06-22): unified to 800. The old 400/600 (card-grid) split was too
  // tight for information-dense templates (consultant/academic/bank/insight) whose
  // executive-summary / data-deepdive pages are intentionally dense. Density control
  // now relies on the subagent-rules "card body ≤ 80 chars" guidance + this hard
  // ceiling. isCardGrid distinction kept for message clarity only.
  maxSlideChars: 800,         // Total visible text per slide (chars, excl. whitespace).
  maxCardPageChars: 800,      // Card-grid pages — unified with maxSlideChars (F12)
  overflowHintChars: 900,     // F19: above this, emit an INFO hint to eyeball overflow after delivery
  maxTableRows: 7,            // <tr> count (incl. header)
  maxListItems: 6,            // <li> count per slide
  maxTodoItems: 8,            // <li> for todo-checklist layout
  minFontSizePt: 9,           // Inline font-size floor
  maxHeadingChars: { h1: 60, h2: 40, h3: 30 },  // Per heading element. Raised — large display headings (≥80px) are visual focal points, not reading text.
};

function stripTags(html) {
  return html.replace(/<[^>]+>/g, '');
}

function countVisibleChars(html) {
  const bodyMatch = html.match(/<body[^>]*>([\s\S]*)<\/body>/i)
    || html.match(/<body[^>]*>([\s\S]*)$/i);
  if (!bodyMatch) return 0;
  const text = stripTags(bodyMatch[1]);
  return text.replace(/\s/g, '').length;
}

function countElements(html, tagName) {
  const re = new RegExp(`<${tagName}[\\s>]`, 'gi');
  return (html.match(re) || []).length;
}

function extractHeadings(html) {
  const headings = [];
  for (const tag of ['h1', 'h2', 'h3']) {
    const re = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'gi');
    let m;
    while ((m = re.exec(html)) !== null) {
      const text = stripTags(m[1]).replace(/\s/g, '');
      headings.push({ tag, text, offset: m.index });
    }
  }
  return headings;
}

function extractInlineFontSizes(html) {
  const results = [];
  const re = /font-size\s*:\s*(\d+(?:\.\d+)?)\s*(pt|px)/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    let pt = parseFloat(m[1]);
    if (m[2] === 'px') pt = pt / 1.333;
    results.push({ pt, offset: m.index, raw: m[0] });
  }
  return results;
}

function detectLayoutClass(html) {
  if (/class="[^"]*\btodo\b/i.test(html) || /\.todo\b/i.test(html)) return 'todo-checklist';
  return null;
}

function checkContentOverflow(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');

  for (const file of slides) {
    const html = loadText(join(slidesDir, file));
    const fileKey = 'slides/' + file;
    const T = CONTENT_THRESHOLDS;

    // 1. Character density — F12: unified threshold 800 (was 400/600 split).
    const chars = countVisibleChars(html);
    const isCardGrid = /\bgrid\s+[^"]*\b[g][3-4]\b/.test(html) || /class="[^"]*\b[g][3-4]\b/.test(html);
    const maxChars = isCardGrid ? T.maxCardPageChars : T.maxSlideChars;
    if (chars > maxChars) {
      findings.push({
        checkId: 'content', file: fileKey, offset: null,
        rule: 'CHAR_DENSITY',
        message: `Visible text is ${chars} chars (limit: ${maxChars}${isCardGrid ? ', card-grid page' : ''}). Reduce content or split into multiple slides.`,
      });
    } else if (chars > T.overflowHintChars) {
      // F19 (2026-06-22): program-only static hint (no browser/AI). Dense-but-under-
      // ceiling pages may still visually overflow at certain canvas widths; flag for
      // the user to eyeball after delivery. content check is ALWAYS_WARNING so this
      // never blocks — it's advisory, per the "观感交用户输出校验" principle.
      findings.push({
        checkId: 'content', file: fileKey, offset: null,
        rule: 'OVERFLOW_HINT',
        message: `Visible text is ${chars} chars (>${T.overflowHintChars}). Dense page — eyeball for overflow after delivery.`,
      });
    }

    // 2. Table row count
    const rows = countElements(html, 'tr');
    if (rows > T.maxTableRows) {
      findings.push({
        checkId: 'content', file: fileKey, offset: null,
        rule: 'TABLE_ROWS',
        message: `Table has ${rows} rows (limit: ${T.maxTableRows}). Remove rows or split into two slides.`,
      });
    }

    // 3. List item count
    const layout = detectLayoutClass(html);
    const liCount = countElements(html, 'li');
    const maxLi = layout === 'todo-checklist' ? T.maxTodoItems : T.maxListItems;
    if (liCount > maxLi) {
      findings.push({
        checkId: 'content', file: fileKey, offset: null,
        rule: 'LIST_ITEMS',
        message: `Slide has ${liCount} list items (limit: ${maxLi}${layout ? ` (${layout})` : ''}). Remove items or split.`,
      });
    }

    // 4. Inline font-size — only check for unreadably tiny text (no ceiling — large decorative fonts are legitimate design)
    const fontSizes = extractInlineFontSizes(html);
    for (const fs of fontSizes) {
      if (fs.pt < T.minFontSizePt) {
        findings.push({
          checkId: 'content', file: fileKey, offset: fs.offset,
          rule: 'FONT_SIZE_TINY',
          message: `font-size ${fs.raw} (~${fs.pt.toFixed(1)}pt) below min ${T.minFontSizePt}pt. Content may be unreadable.`,
        });
      }
    }

    // 5. Heading text length
    const headings = extractHeadings(html);
    for (const h of headings) {
      const limit = T.maxHeadingChars[h.tag] || 80;
      if (h.text.length > limit) {
        findings.push({
          checkId: 'content', file: fileKey, offset: h.offset,
          rule: `HEADING_${h.tag.toUpperCase()}_LONG`,
          message: `<${h.tag}> has ${h.text.length} chars (limit: ${limit}). "${h.text.substring(0, 30)}..." — shorten or reduce font-size.`,
        });
      }
    }
  }

  return findings;
}

// ── Check 8: Emoji detection (P2) ───────────────────────────────
// Flags emoji characters in slide visible content (excl. <aside class="notes">).

const EMOJI_RE = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

// F10 (2026-06-22): emoji inside a `data-replace` slot is a placeholder the
// subagent will overwrite (e.g. course-module's card_N_icon ☕🌸), and emoji
// inside <code>/<pre> is a literal code character (tech-sharing's diff ❌✅).
// Both are legitimate template usage, not visible-content emoji that needs
// replacing. Whitelist them by tracking the open-element stack while walking.
function isInsideExemptContext(stack) {
  for (let i = stack.length - 1; i >= 0; i--) {
    const tag = stack[i];
    if (tag.exempt) return true;       // data-replace slot or code/pre
  }
  return false;
}

function checkEmoji(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');

  for (const file of slides) {
    const html = loadText(join(slidesDir, file));
    const fileKey = 'slides/' + file;

    // Tokenize once and walk with an open-element stack so we know whether each
    // TEXT node is inside an exempt context (data-replace slot / code / pre).
    const tokens = tokenize(html);
    const stack = [];
    const found = new Map();  // emoji -> first offset (per-page dedup)

    for (const token of tokens) {
      if (token.type === 'TAG_OPEN') {
        const tagEnd = html.indexOf('>', token.offset);
        const tagHtml = tagEnd >= 0 ? html.slice(token.offset, tagEnd + 1) : '';
        const isDataReplace = /data-replace\s*=\s*["'][^"']+["']/.test(tagHtml);
        // code/pre = literal code characters (tech-sharing diff ❌✅).
        // SVG <text> = template-designed visual markers (testing-safety-alert risk
        // matrix ⛔⚠) — part of the diagram, not prose emoji to be replaced.
        const isCodeBlock = token.tagName === 'code' || token.tagName === 'pre' || token.tagName === 'text';
        stack.push({ tagName: token.tagName, exempt: isDataReplace || isCodeBlock });
      } else if (token.type === 'TAG_CLOSE') {
        const idx = stack.findLastIndex(s => s.tagName === token.tagName);
        if (idx >= 0) stack.splice(idx, 1);
      } else if (token.type === 'TEXT') {
        if (isInsideExemptContext(stack)) continue;
        let ignored = false;
        for (let i = stack.length - 1; i >= 0; i--) {
          if (IGNORED_TAGS.has(stack[i].tagName) || stack[i].tagName === 'aside') { ignored = true; break; }
        }
        if (ignored) continue;

        for (const m of token.text.matchAll(EMOJI_RE)) {
          if (!found.has(m[0])) {
            found.set(m[0], token.offset + m.index);
          }
        }
      }
    }

    for (const [emoji, offset] of found) {
      findings.push({
        checkId: 'emoji', file: fileKey, offset,
        rule: 'EMOJI_IN_SLIDE',
        message: `Emoji "${emoji}" found in visible slide content. Replace with CSS graphics (circle + text/number) or SVG icon.`,
      });
    }
    if (found.size > 0) {
      findings.push({
        checkId: 'emoji', file: fileKey, offset: null,
        rule: 'EMOJI_SUMMARY',
        message: `${found.size} unique emoji character(s) detected. Remove all emoji from slide visible area.`,
      });
    }
  }

  return findings;
}

// ── Check 9: Visual annotation / image-manifest consistency (P0) ────
// If outline.md has annotations that require AI image generation (per
// visual-content-index.md's generation-required type set), image-manifest.md
// must exist. Pure CSS-component annotations (stat-grid, matrix-2x2, gantt,
// quarterly-review, etc. — layout/role names, not generation scenes) do NOT
// trigger the manifest requirement, aligning validate with SKILL.md:52 which
// scopes image-manifest to "如有；非 SKILL 主流程阶段".
// Catches agents that silently skip Phase 4.1.5 when generation was actually
// declared.

const VISUAL_RE = /\[visual:\s*(\S+)\]/g;
const ELEMENT_RE = /\[(card-bg:\s*\d+|decor:\s*\S+|section-bg)\]/g;

// Page-level [visual:] types that require AI image generation, per
// references/visual-content-index.md §二 (维度 1-3). Any type not in this set
// is treated as a CSS-component / layout annotation and does not require a
// manifest. `none` is explicitly excluded above.
const GENERATION_VISUAL_TYPES = new Set([
  'cover', 'section-divider', 'ending',           // 维度 1 装饰性插画
  'illustration', 'icon',                          // 维度 2 配图与图标
  'flow-infographic', 'arch-infographic', 'comparison', 'data-bg', 'timeline', // 维度 3 内容视觉化
]);

function parseOutlineVisualAnnotations(outlinePath) {
  if (!existsSync(outlinePath)) return [];
  const text = readFileSync(outlinePath, 'utf-8');
  const annotations = [];
  let m;
  // Page-level: [visual: <type>] where type != none
  while ((m = VISUAL_RE.exec(text)) !== null) {
    const type = m[1];
    if (type !== 'none') annotations.push({ type: 'visual', value: type });
  }
  VISUAL_RE.lastIndex = 0;
  // Element-level: [card-bg: N], [decor: position], [section-bg]
  while ((m = ELEMENT_RE.exec(text)) !== null) {
    annotations.push({ type: 'element', value: m[1] });
  }
  ELEMENT_RE.lastIndex = 0;
  return annotations;
}

function parseImageManifest(manifestPath) {
  if (!existsSync(manifestPath)) return null;
  const text = readFileSync(manifestPath, 'utf-8');
  const rows = [];
  const lineRe = /\|.*\|.*\|.*\|.*\|\s*(\w+)\s*\|/g;
  let m;
  while ((m = lineRe.exec(text)) !== null) {
    const status = m[1].trim();
    // Skip header/separator rows
    if (['状态', 'status', '---'].includes(status.toLowerCase())) continue;
    rows.push(status);
  }
  // Sentinel (complexity P2.7): a manifest file that exists but contains zero
  // status rows declares "no AI images" (e.g. a CSS-only deck, or every visual
  // resolved via CSS patterns). Treat as an intentional all-skip, not a failure —
  // return a synthetic SKIPPED row so the downstream boundary check passes.
  if (rows.length === 0) return ['SKIPPED'];
  return rows;
}

function checkVisualAnnotations(deckPath) {
  const findings = [];
  // outline.md and image-manifest.md are two levels up from the live deck dir
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');
  const manifestPath = join(projectDir, 'image-manifest.md');

  const annotations = parseOutlineVisualAnnotations(outlinePath);
  // Only page-level [visual:] annotations whose type requires AI generation
  // (per GENERATION_VISUAL_TYPES, sourced from visual-content-index.md §二)
  // require image-manifest.md. CSS-component / layout annotations
  // (stat-grid, matrix-2x2, gantt, quarterly-review, ...) and element-level
  // annotations are CSS patterns, not generation scenes — they do not trigger
  // the manifest requirement. This keeps validate consistent with SKILL.md:52,
  // which scopes image-manifest to "如有；非 SKILL 主流程阶段".
  const genVisuals = annotations.filter(
    a => a.type === 'visual' && GENERATION_VISUAL_TYPES.has(a.value)
  );
  if (genVisuals.length === 0) return findings;

  const visualTypes = [...new Set(genVisuals.map(a => a.value))];

  const manifest = parseImageManifest(manifestPath);

  if (manifest === null) {
    findings.push({
      checkId: 'visual', file: 'index.html', offset: null,
      rule: 'VISUAL_MANIFEST_MISSING',
      message: `outline.md has ${genVisuals.length} AI-generation visual annotation(s) (${visualTypes.join(', ')}) but image-manifest.md does not exist. If these pages render via CSS components (no AI images), this is fine — otherwise run /html-gen-images to produce the manifest.`,
    });
    return findings;
  }

  const okCount = manifest.filter(s => s === 'OK').length;
  const failedCount = manifest.filter(s => s === 'FAILED').length;
  const skippedCount = manifest.filter(s => s === 'SKIPPED').length;

  // Boundary fix (complexity P2.7 + plan L1.1.3): only flag when there are
  // genuinely FAILED entries — i.e. non-OK, non-SKIPPED rows. A manifest that is
  // entirely SKIPPED (every visual intentionally skipped, or the "no AI images"
  // sentinel) is a PASS. The original `okCount === 0` condition fired even when
  // the whole deck was deliberately image-free, masking nothing real but blocking
  // CSS-only / all-skip decks. Real generation failures (FAILED rows) still trip.
  // `skippedCount < genVisuals.length` is retained as an additional guard so a
  // partial manifest (fewer skips than declared generation visuals, with no OK)
  // still flags.
  const nonSkippedEntries = manifest.length - skippedCount;
  if (okCount === 0 && nonSkippedEntries > 0 && skippedCount < genVisuals.length) {
    findings.push({
      checkId: 'visual', file: 'index.html', offset: null,
      rule: 'VISUAL_ALL_FAILED',
      message: `image-manifest.md has ${manifest.length} entries but 0 OK (${failedCount} FAILED, ${skippedCount} SKIPPED). AI image generation produced no usable images.`,
    });
  }

  return findings;
}

// ── Check 10: Image embedding completeness (P0) ────────────────────────
// Verifies that every image listed in outline.md [img:] annotations is
// actually referenced in the corresponding slide HTML. Catches subagents
// that skip image embedding.

const IMG_ANNOTATION_RE = /\[img:\s*([^\]]+)\]/g;

function parseOutlineImgAnnotations(outlinePath) {
  if (!existsSync(outlinePath)) return [];
  const text = readFileSync(outlinePath, 'utf-8');
  const annotations = [];

  const pageRe = /^###\s+(P(\d+))\b/gm;
  let pageMatch;
  while ((pageMatch = pageRe.exec(text)) !== null) {
    const pageNum = pageMatch[2].padStart(2, '0');
    const lineEnd = text.indexOf('\n', pageMatch.index);
    const line = text.slice(pageMatch.index, lineEnd >= 0 ? lineEnd : text.length);

    const imgMatch = line.match(/\[img:\s*([^\]]+)\]/);
    if (imgMatch) {
      const files = imgMatch[1].split(',').map(f => f.trim()).filter(Boolean);
      for (const file of files) {
        annotations.push({ pageNum, file });
      }
    }
  }
  return annotations;
}

function checkImageEmbedding(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');
  const slidesDir = join(deckPath, 'slides');

  const annotations = parseOutlineImgAnnotations(outlinePath);
  if (annotations.length === 0) return findings;

  const slideFiles = readdirSync(slidesDir).filter(f => f.endsWith('.html'));

  // Build map: pageNum → slide filename
  const slideByPage = new Map();
  for (const file of slideFiles) {
    const m = file.match(/slide-(\d+)-/);
    if (m) slideByPage.set(m[1], file);
  }

  // Collect all image references across all slides (for wrong-page detection)
  const imageInSlides = new Map(); // filename → [pageNum]
  for (const [pageNum, file] of slideByPage) {
    const html = loadText(join(slidesDir, file));
    for (const ann of annotations) {
      const baseName = ann.file.replace(/\.png$/, '');
      if (html.includes(baseName)) {
        if (!imageInSlides.has(ann.file)) imageInSlides.set(ann.file, []);
        imageInSlides.get(ann.file).push(pageNum);
      }
    }
  }

  for (const ann of annotations) {
    const slideFile = slideByPage.get(ann.pageNum);
    const slideKey = slideFile ? `slides/${slideFile}` : 'slides/unknown';

    if (!slideFile) {
      findings.push({
        checkId: 'img-embed', file: slideKey, offset: null,
        rule: 'IMG_EMBED_NO_SLIDE',
        message: `No slide HTML found for page ${ann.pageNum}. Image "${ann.file}" cannot be embedded.`,
      });
      continue;
    }

    const html = loadText(join(slidesDir, slideFile));
    const baseName = ann.file.replace(/\.png$/, '');

    if (!html.includes(baseName)) {
      findings.push({
        checkId: 'img-embed', file: `slides/${slideFile}`, offset: null,
        rule: 'IMG_EMBED_MISSING',
        message: `"${ann.file}" listed in outline.md [img:] for page ${ann.pageNum} but not referenced in ${slideFile}.`,
      });
      continue;
    }

    // Check if image appears in a DIFFERENT page's slide
    const refPages = imageInSlides.get(ann.file) || [];
    const wrongPages = refPages.filter(p => p !== ann.pageNum);
    if (wrongPages.length > 0) {
      findings.push({
        checkId: 'img-embed', file: `slides/${slideFile}`, offset: null,
        rule: 'IMG_EMBED_WRONG_PAGE',
        message: `"${ann.file}" (page ${ann.pageNum}) is referenced in page ${wrongPages.join(', ')} instead. Move to correct slide.`,
      });
    }
  }

  return findings;
}

// ── Check 11 & 12 shared helper ─────────────────────────────────
// Parse [layout: Lxx] annotations from outline.md

const LAYOUT_CATEGORY = {
  'L01': 'structural', 'L02': 'structural', 'L03': 'structural',
  'L04': 'structural', 'L05': 'structural',
  'L06': 'text', 'L07': 'text', 'L08': 'text',
  'L09': 'text', 'L10': 'text',
  'L11': 'data', 'L12': 'data', 'L13': 'data',
  'L14': 'data', 'L15': 'data', 'L16': 'data',
  'L17': 'diagram', 'L18': 'diagram', 'L19': 'diagram',
  'L20': 'diagram', 'L21': 'diagram', 'L22': 'diagram', 'L23': 'diagram',
  'L24': 'compare', 'L25': 'compare', 'L26': 'compare', 'L27': 'compare',
  'L28': 'code', 'L29': 'code', 'L30': 'code',
  'L31': 'tool',
};

const CARD_LAYOUTS = new Set([
  'L02', 'L07', 'L08', 'L11', 'L15', 'L22', 'L24', 'L25', 'L27', 'L29', 'L31',
]);

const VISUAL_LAYOUT_MAP = {
  'cover':            new Set(['L01']),
  'section-divider':  new Set(['L03']),
  'ending':           new Set(['L01', 'L04', 'L09']),
  'illustration':     new Set(['L07', 'L09', 'L10', 'L26']),
  'concept':          new Set(['L07', 'L09', 'L26']),
  'icon':             new Set(['L06', 'L08']),
  'flow-infographic': new Set(['L17', 'L22']),
  'arch-infographic': new Set(['L20', 'L21']),
  'comparison':       new Set(['L24', 'L25']),
  'data-viz':         new Set(['L11', 'L13']),
  'timeline':         new Set(['L18', 'L19']),
};

function parseOutlineLayoutAnnotations(outlinePath) {
  if (!existsSync(outlinePath)) return [];
  const text = readFileSync(outlinePath, 'utf-8');
  const pages = [];
  // Match both "### P01" and "P01 " formats
  const pageRe = /^(?:###\s+)?P(\d+)\s/gm;
  let pageMatch;
  while ((pageMatch = pageRe.exec(text)) !== null) {
    const pageNum = pageMatch[1];
    const lineEnd = text.indexOf('\n', pageMatch.index);
    const line = text.slice(pageMatch.index, lineEnd >= 0 ? lineEnd : text.length);
    const layoutMatch = line.match(/\[layout:\s*(L\d+)\]/);
    const visualMatches = [...line.matchAll(/\[visual:\s*([^\]]+)\]/g)].map(x => x[1]);
    const layout = layoutMatch ? layoutMatch[1] : null;
    pages.push({
      pageNum,
      layout,
      category: layout ? (LAYOUT_CATEGORY[layout] || 'unknown') : null,
      isCard: layout ? CARD_LAYOUTS.has(layout) : false,
      visuals: visualMatches,
    });
  }
  return pages;
}

// ── Check 11: Layout rhythm (P2) ─────────────────────────────────
// Detects consecutive pages using the same layout type (>3 in a row)
// and same layout category (>3 in a row, e.g. all text/card type).

function checkLayoutRhythm(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');
  const slidesDir = join(deckPath, 'slides');

  // T1 template system: rhythm is determined by slide-roles.md design, not layout-catalog IDs
  if (isT1Deck(slidesDir)) return findings;

  const pages = parseOutlineLayoutAnnotations(outlinePath);
  if (pages.length === 0) return findings;

  const maxConsecutive = 3;
  let runStart = 0;

  for (let i = 1; i <= pages.length; i++) {
    const currentLayout = i < pages.length ? pages[i].layout : null;
    const prevLayout = pages[runStart].layout;

    if (currentLayout === null || currentLayout !== prevLayout || i === pages.length) {
      const runLength = i - runStart;
      if (runLength > maxConsecutive && prevLayout !== null) {
        findings.push({
          checkId: 'layout-rhythm', file: 'index.html', offset: null,
          rule: 'LAYOUT_RHYTHM',
          message: `${runLength} consecutive pages use layout ${prevLayout} (P${pages[runStart].pageNum}–P${pages[i - 1].pageNum}, max ${maxConsecutive}). Insert a different layout type as visual rhythm break.`,
        });
      }
      if (prevLayout === null && runLength > maxConsecutive) {
        findings.push({
          checkId: 'layout-rhythm', file: 'index.html', offset: null,
          rule: 'LAYOUT_RHYTHM_UNANNOTATED',
          message: `${runLength} consecutive pages have no [layout: Lxx] annotation (P${pages[runStart].pageNum}–P${pages[i - 1].pageNum}). Annotate each page with [layout: Lxx] in Phase 4.3.`,
        });
      }
      runStart = i;
    }
  }

  // Category-level rhythm: consecutive pages in same layout category
  let catRunStart = 0;
  for (let i = 1; i <= pages.length; i++) {
    const currentCat = i < pages.length ? pages[i].category : null;
    const prevCat = pages[catRunStart].category;
    const isSame = currentCat !== null && prevCat !== null && currentCat === prevCat;

    if (!isSame || i === pages.length) {
      const runLength = i - catRunStart;
      if (runLength > maxConsecutive && prevCat !== null && prevCat !== 'structural') {
        findings.push({
          checkId: 'layout-rhythm', file: 'index.html', offset: null,
          rule: 'LAYOUT_CATEGORY_STREAK',
          message: `${runLength} consecutive pages use "${prevCat}" category (P${pages[catRunStart].pageNum}–P${pages[i - 1].pageNum}, max ${maxConsecutive}). Insert a different layout category (text/diagram/compare/data) as visual rhythm break.`,
        });
      }
      catRunStart = i;
    }
  }

  return findings;
}

// ── Check 12: Layout diversity (P2) ──────────────────────────────
// Ensures sufficient variety of layout types AND categories across the deck.
// Also caps card-driven layouts at 50% of content pages.

function checkLayoutDiversity(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');
  const slidesDir = join(deckPath, 'slides');

  const pages = parseOutlineLayoutAnnotations(outlinePath);
  if (pages.length === 0) return findings;

  // T1 template system: use role-based diversity instead of layout-catalog IDs
  if (isT1Deck(slidesDir)) {
    return checkRoleDiversity(slidesDir, pages.length);
  }

  const totalPages = pages.length;
  const annotated = pages.filter(p => p.layout !== null);
  const layouts = new Set(annotated.map(p => p.layout));
  const categories = new Set(annotated.map(p => p.category).filter(Boolean));
  const uniqueCount = layouts.size;

  // Layout ID diversity
  let minRequired = 0;
  if (totalPages >= 25) minRequired = 8;
  else if (totalPages >= 15) minRequired = 6;
  else if (totalPages >= 8) minRequired = 4;

  if (minRequired > 0 && uniqueCount < minRequired) {
    findings.push({
      checkId: 'layout-diversity', file: 'index.html', offset: null,
      rule: 'LAYOUT_DIVERSITY',
      message: `Only ${uniqueCount} unique layout(s) used across ${totalPages} pages (${[...layouts].join(', ')}). Minimum ${minRequired} required for ${totalPages}-page deck. Consider varying layout types.`,
    });
  }

  // Category diversity
  let minCategories = 0;
  if (totalPages >= 25) minCategories = 5;
  else if (totalPages >= 15) minCategories = 4;
  else if (totalPages >= 8) minCategories = 3;

  if (minCategories > 0 && categories.size < minCategories) {
    findings.push({
      checkId: 'layout-diversity', file: 'index.html', offset: null,
      rule: 'CATEGORY_DIVERSITY_LOW',
      message: `Only ${categories.size} layout categories across ${totalPages} pages (${[...categories].join(', ')}). Minimum ${minCategories} required. Spread across text/diagram/compare/data/structural.`,
    });
  }

  // Card layout ratio cap (50% of content pages, excluding structural)
  const contentPages = pages.filter(p => p.category !== 'structural');
  if (contentPages.length > 0) {
    const cardCount = contentPages.filter(p => p.isCard).length;
    const ratio = cardCount / contentPages.length;
    if (ratio > 0.5) {
      const pct = Math.round(ratio * 100);
      const cardPages = contentPages.filter(p => p.isCard).map(p => `P${p.pageNum}(${p.layout})`);
      findings.push({
        checkId: 'layout-diversity', file: 'index.html', offset: null,
        rule: 'CARD_LAYOUT_RATIO',
        message: `Card-driven layouts: ${cardCount}/${contentPages.length} content pages (${pct}%, max 50%). Affected: ${cardPages.join(', ')}. Replace some with text/diagram/compare layouts.`,
      });
    }
  }

  const unannotated = pages.filter(p => p.layout === null).length;
  if (unannotated > 0) {
    findings.push({
      checkId: 'layout-diversity', file: 'index.html', offset: null,
      rule: 'LAYOUT_DIVERSITY_UNANNOTATED',
      message: `${unannotated} page(s) without [layout: Lxx] annotation. Diversity check may be incomplete.`,
    });
  }

  return findings;
}

// ── Role diversity check (T1 template system) ─────────────────────
// When using T1 templates with slide-roles.md, validate role diversity
// instead of layout-catalog IDs.

function checkRoleDiversity(slidesDir, totalPages) {
  const findings = [];
  const files = slideFiles(slidesDir);
  const roles = new Set();
  const unannotated = [];

  for (const f of files) {
    const html = loadText(join(slidesDir, f));
    // Restrict role tokens to canonical IDs ([A-Za-z0-9_-]+). A looser \S+ captured
    // trailing comment text / stray tokens, inflating "unique roles" and causing
    // spurious ROLE_DIVERSITY_LOW when the same real role parsed as several variants.
    const roleMatch = html.match(/<!--\s*role:\s*([A-Za-z0-9_-]+)/);
    if (roleMatch) {
      roles.add(roleMatch[1]);
    } else {
      unannotated.push(f);
    }
  }

  // Check for unannotated pages
  if (unannotated.length > 0) {
    findings.push({
      checkId: 'layout-diversity', file: 'index.html', offset: null,
      rule: 'ROLE_UNANNOTATED',
      message: `${unannotated.length} page(s) without <!-- role: ... --> annotation: ${unannotated.join(', ')}. Each slide should declare its role from slide-roles.md.`,
    });
  }

  // Role diversity (minimum unique roles based on page count)
  let minRoles = 0;
  if (totalPages >= 25) minRoles = 5;
  else if (totalPages >= 15) minRoles = 4;
  else if (totalPages >= 8) minRoles = 3;

  if (minRoles > 0 && roles.size < minRoles) {
    findings.push({
      checkId: 'layout-diversity', file: 'index.html', offset: null,
      rule: 'ROLE_DIVERSITY_LOW',
      message: `Only ${roles.size} unique role(s) across ${totalPages} pages (${[...roles].join(', ')}). Minimum ${minRoles} required. Add variety via slide-roles.md role assignments.`,
    });
  }

  return findings;
}

// ── Check 13: Accent-text density (P2) ────────────────────────────
// Max 2 .accent-text per page. Summit rule: 配色克制.
// Also checks cross-page accent color consistency (max 2 distinct colors).

function checkAccentDensity(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const maxAccent = 2;

  for (const file of slides) {
    const html = loadText(join(slidesDir, file));
    const fileKey = 'slides/' + file;

    const accentMatches = html.match(/class="[^"]*\baccent-text\b/gi) || [];
    if (accentMatches.length > maxAccent) {
      findings.push({
        checkId: 'accent-density', file: fileKey, offset: null,
        rule: 'ACCENT_OVERUSE',
        message: `${accentMatches.length} .accent-text elements (max ${maxAccent}). Reduce keyword highlighting to core concept terms only.`,
      });
    }
  }

  // Cross-page accent color consistency: collect all .accent-text color definitions
  const accentColors = new Set();
  for (const file of slides) {
    const html = loadText(join(slidesDir, file));
    const styleBlocks = html.match(/<style[^>]*>([\s\S]*?)<\/style>/gi) || [];
    for (const block of styleBlocks) {
      const m = block.match(/\.accent-text\s*\{[^}]*color\s*:\s*([^;]+)/i);
      if (m) accentColors.add(m[1].trim().toLowerCase());
    }
    const inlineColors = html.match(/class="[^"]*\baccent-text\b[^"]*"[^>]*style="[^"]*color\s*:\s*([^;"]+)/gi) || [];
    for (const m of inlineColors) {
      const c = m.match(/color\s*:\s*([^;"]+)/i);
      if (c) accentColors.add(c[1].trim().toLowerCase());
    }
  }
  if (accentColors.size > 2) {
    findings.push({
      checkId: 'accent-density', file: 'index.html', offset: null,
      rule: 'ACCENT_COLOR_INCONSISTENCY',
      message: `${accentColors.size} distinct accent-text colors across deck (max 2): ${[...accentColors].join(', ')}. Use a single global accent color.`,
    });
  }

  return findings;
}

// ── Check 14: Theme annotation compliance (P1) ─────────────────────
// Verifies outline.md [theme: dark/light] annotations are executed in HTML.
// If outline says [theme: dark], body must have class="slide-dark".
// If outline says [theme: light], body must NOT have class="slide-dark".

const THEME_ANNOTATION_RE = /\[theme:\s*(dark|light)\]/g;

function checkThemeCompliance(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');

  if (!existsSync(outlinePath)) return findings;

  const outlineText = readFileSync(outlinePath, 'utf-8');
  const pages = [];

  const pageRe = /^###\s+(P(\d+))\b/gm;
  let pageMatch;
  while ((pageMatch = pageRe.exec(outlineText)) !== null) {
    const pageId = pageMatch[1];
    const pageIdx = parseInt(pageMatch[2], 10);
    const lineEnd = outlineText.indexOf('\n', pageMatch.index);
    const line = outlineText.slice(pageMatch.index, lineEnd >= 0 ? lineEnd : outlineText.length);
    const themeMatch = line.match(/\[theme:\s*(dark|light)\]/);
    pages.push({ pageId, pageIdx, theme: themeMatch ? themeMatch[1] : null });
  }

  if (pages.length === 0) return findings;

  const slidesDir = join(deckPath, 'slides');
  const slideFiles = readdirSync(slidesDir).filter(f => f.endsWith('.html'));

  // Build pageNum → slide file mapping
  const slideByPage = new Map();
  for (const file of slideFiles) {
    const m = file.match(/(\d{2})-/);
    if (m) {
      const num = parseInt(m[1], 10);
      slideByPage.set(num, file);
    }
  }

  for (const page of pages) {
    if (page.theme === null) continue;

    const slideFile = slideByPage.get(page.pageIdx);
    if (!slideFile) continue;

    const html = loadText(join(slidesDir, slideFile));
    const fileKey = `slides/${slideFile}`;
    const hasSlideDark = /class="[^"]*\bslide-dark\b/i.test(html);

    if (page.theme === 'dark' && !hasSlideDark) {
      findings.push({
        checkId: 'theme-compliance', file: fileKey, offset: null,
        rule: 'THEME_DARK_MISSING',
        message: `outline.md [theme: dark] for ${page.pageId} but <body> lacks class="slide-dark". Add slide-dark to body.`,
      });
    }

    if (page.theme === 'light' && hasSlideDark) {
      findings.push({
        checkId: 'theme-compliance', file: fileKey, offset: null,
        rule: 'THEME_LIGHT_HAS_DARK',
        message: `outline.md [theme: light] for ${page.pageId} but <body> has class="slide-dark". Remove slide-dark from body.`,
      });
    }
  }

  return findings;
}

// ── Check 15: Takeaway coverage (P2) ─────────────────────────────
// Advisory: 30-50% of content pages should have .takeaway.
// Only checked when there are enough content pages (≥6) to be meaningful.

function checkTakeawayCoverage(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');
  const slidesDir = join(deckPath, 'slides');
  const slideFiles = readdirSync(slidesDir).filter(f => f.endsWith('.html'));

  if (slideFiles.length < 6) return findings;

  let takeawayCount = 0;
  let contentPages = 0;
  let totalTakeawayUsage = 0; // count across all slides (incl. cover/ending)
  const labelVariants = new Set();

  for (const file of slideFiles) {
    const html = loadText(join(slidesDir, file));
    // Count total .takeaway usage across all slides
    const usages = (html.match(/class="[^"]*\btakeaway\b/gi) || []).length;
    totalTakeawayUsage += usages;

    // Skip cover and ending pages (usually first and last)
    const m = file.match(/(\d{2})-/);
    const pageNum = m ? parseInt(m[1], 10) : 0;
    const isLast = slideFiles.indexOf(file) === slideFiles.length - 1;
    if (pageNum <= 1 || isLast) continue;

    contentPages++;

    if (usages > 0) {
      takeawayCount++;
      // Extract takeaway .label text for consistency check
      const labelMatch = html.match(/class="[^"]*label[^"]*"[^>]*>\s*([^<]+)/i);
      if (labelMatch) {
        const labelText = labelMatch[1].trim().toUpperCase();
        if (labelText) labelVariants.add(labelText);
      }
    }
  }

  if (contentPages === 0) return findings;

  // If no slide uses .takeaway at all, the template system likely doesn't support it — skip
  if (totalTakeawayUsage === 0) return findings;

  const ratio = takeawayCount / contentPages;
  if (ratio < 0.15 && contentPages >= 8) {
    findings.push({
      checkId: 'takeaway-coverage', file: 'index.html', offset: null,
      rule: 'TAKEAWAY_LOW',
      message: `Only ${takeawayCount}/${contentPages} content pages (${(ratio * 100).toFixed(0)}%) have .takeaway. Target: 30-50%. Add takeaway bars to high-density or section-closing pages.`,
    });
  } else if (ratio > 0.55) {
    findings.push({
      checkId: 'takeaway-coverage', file: 'index.html', offset: null,
      rule: 'TAKEAWAY_HIGH',
      message: `${takeawayCount}/${contentPages} content pages (${(ratio * 100).toFixed(0)}%) have .takeaway. Target: 30-50%. Only add takeaway when the page has a genuinely unique concluding insight — not just restating the last point.`,
    });
  }

  // Check label consistency
  if (labelVariants.size > 1) {
    findings.push({
      checkId: 'takeaway-coverage', file: 'index.html', offset: null,
      rule: 'TAKEAWAY_LABEL_INCONSISTENT',
      message: `Takeaway labels are inconsistent: ${[...labelVariants].join(', ')}. Use "TAKEAWAY" uniformly.`,
    });
  }

  return findings;
}
// Warns if outline has [layout:] annotations but zero [theme:] annotations,
// indicating Phase 4.3 did not execute the theme judgment step.

function checkThemeAnnotation(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');

  if (!existsSync(outlinePath)) return findings;

  const outlineText = readFileSync(outlinePath, 'utf-8');
  const tokensPath = join(deckPath, 'shared', 'tokens.css');

  const layoutPages = (outlineText.match(/\[layout:\s*L\d+\]/g) || []).length;
  const themePages = (outlineText.match(/\[theme:\s*(dark|light)\]/g) || []).length;

  // Skip if dark theme (SKILL.md: 深色主题 → 不标 [theme:])
  // Detect by reading --bg from tokens.css — if luminance < 0.15, treat as dark
  let isDarkTheme = false;
  if (existsSync(tokensPath)) {
    const tokensText = readFileSync(tokensPath, 'utf-8');
    const bgMatch = tokensText.match(/--bg\s*:\s*(#[0-9a-fA-F]{3,8})/);
    if (bgMatch) isDarkTheme = luminance(bgMatch[1]) < 0.15;
  }

  if (layoutPages >= 3 && themePages === 0 && !isDarkTheme) {
    findings.push({
      checkId: 'theme-annotation', file: 'outline.md', offset: null,
      rule: 'THEME_ANNOTATION_MISSING',
      message: `outline.md has ${layoutPages} [layout:] annotations but 0 [theme:] annotations. Phase 4.3 must annotate each page with [theme: dark] or [theme: light].`,
    });
  }

  return findings;
}

// Parse hex color to relative luminance (0-1)
function luminance(hex) {
  const h = hex.replace('#', '');
  const rgb = h.length <= 4
    ? [parseInt(h[0]+h[0],16), parseInt(h[1]+h[1],16), parseInt(h[2]+h[2],16)]
    : [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
  const [r, g, b] = rgb.map(c => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

// ── Check 17: Component annotation execution (P1) ──────────────
// Verifies outline.md [comp: point/card/flow/text] and [composite: cards+flow/...]
// annotations are executed in HTML — the annotated component class(es) must appear.
// composite (003 主线三 F): a page whose page-body combines two heterogeneous components
// (e.g. cards + flow). Validated by checking BOTH component classes co-exist in the DOM.

const COMP_ANNOTATION_RE = /\[(?:comp:\s*(point|card|flow|text)|composite:\s*(cards\+flow|list\+flow|kpi\+table))\]/g;

function checkCompAnnotation(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');

  if (!existsSync(outlinePath)) return findings;

  const outlineText = readFileSync(outlinePath, 'utf-8');
  const pages = [];

  // Support both outline formats: "### P01" and "P01"
  const pageRe = /^(?:###\s+)?(P(\d+))\b/gm;
  let pageMatch;
  while ((pageMatch = pageRe.exec(outlineText)) !== null) {
    const pageId = pageMatch[1]; // "P04"
    const pageIdx = parseInt(pageMatch[2], 10); // 4
    const lineEnd = outlineText.indexOf('\n', pageMatch.index);
    const line = outlineText.slice(pageMatch.index, lineEnd >= 0 ? lineEnd : outlineText.length);
    const compMatch = line.match(/\[(?:comp:\s*(point|card|flow|text)|composite:\s*(cards\+flow|list\+flow|kpi\+table))\]/);
    pages.push({
      pageId, pageIdx,
      comp: compMatch && compMatch[1] ? compMatch[1] : null,
      composite: compMatch && compMatch[2] ? compMatch[2] : null,
    });
  }

  if (pages.length === 0) return findings;

  const slidesDir = join(deckPath, 'slides');
  if (!existsSync(slidesDir)) return findings;

  const slideFiles = readdirSync(slidesDir).filter(f => f.endsWith('.html'));

  const slideByPage = new Map();
  for (const file of slideFiles) {
    const m = file.match(/(\d{2})-/);
    if (m) slideByPage.set(parseInt(m[1], 10), file);
  }

  for (const page of pages) {
    if (page.comp === null && page.composite === null) continue;

    const slideFile = slideByPage.get(page.pageIdx);
    if (!slideFile) continue;

    const html = loadText(join(slidesDir, slideFile));
    const fileKey = `slides/${slideFile}`;

    // Extract <style> blocks to detect local redefinitions
    const styleBlocks = [];
    const styleRe = /<style[^>]*>([\s\S]*?)<\/style>/gi;
    let styleMatch;
    while ((styleMatch = styleRe.exec(html)) !== null) {
      styleBlocks.push(styleMatch[1]);
    }
    const allCss = styleBlocks.join('\n');

    // Extract body HTML (outside <style> and <script>)
    const bodyHtml = html
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');

    // DOM direct usage: class="point" or class="... point ..." in HTML body
    const domHasPoint = /\bclass\s*=\s*["'][^"']*\bpoint\b[^"']*["']/.test(bodyHtml);
    const domHasCard = /\bclass\s*=\s*["'][^"']*\bcard\b[^"']*["']/.test(bodyHtml);
    const domHasTakeaway = /\bclass\s*=\s*["'][^"']*\btakeaway\b[^"']*["']/.test(bodyHtml);

    // Local redefinition: .point { ... } or .card { ... } in <style> blocks
    const styleRedefinesPoint = /\.point\s*\{/.test(allCss);
    const styleRedefinesCard = /\.card\s*\{/.test(allCss);
    const styleRedefinesTakeaway = /\.takeaway\s*\{/.test(allCss);

    // COMP_POINT_MISSING: [comp: point] but no .point in DOM
    if (page.comp === 'point' && !domHasPoint) {
      findings.push({
        checkId: 'comp-annotation', file: fileKey, offset: null,
        rule: 'COMP_POINT_MISSING',
        message: `outline.md [comp: point] for ${page.pageId} but HTML body has no class="...point...". Use tokens.css .point (div.point > div.num + div.title + div.desc).`,
      });
    }

    // COMP_POINT_OVERRIDDEN: DOM uses .point but <style> redefines it
    if (page.comp === 'point' && domHasPoint && styleRedefinesPoint) {
      findings.push({
        checkId: 'comp-annotation', file: fileKey, offset: null,
        rule: 'COMP_POINT_OVERRIDDEN',
        message: `outline.md [comp: point] for ${page.pageId} but <style> redefines .point. Standard component must use tokens.css definition only. Remove .point { ... } from <style>.`,
      });
    }

    // COMP_CARD_MISSING: [comp: card] but no .card in DOM
    if (page.comp === 'card' && !domHasCard) {
      findings.push({
        checkId: 'comp-annotation', file: fileKey, offset: null,
        rule: 'COMP_CARD_MISSING',
        message: `outline.md [comp: card] for ${page.pageId} but HTML body has no class="...card...". Use tokens.css .card or extend it with additional classes.`,
      });
    }

    // COMP_CARD_OVERRIDDEN: DOM uses .card but <style> redefines it
    if (page.comp === 'card' && domHasCard && styleRedefinesCard) {
      findings.push({
        checkId: 'comp-annotation', file: fileKey, offset: null,
        rule: 'COMP_CARD_OVERRIDDEN',
        message: `outline.md [comp: card] for ${page.pageId} but <style> redefines .card. Standard component must use tokens.css definition only. Remove .card { ... } from <style>.`,
      });
    }

    // comp: flow — requires either .point or .card in DOM (no redefinition)
    if (page.comp === 'flow' && !domHasPoint && !domHasCard) {
      findings.push({
        checkId: 'comp-annotation', file: fileKey, offset: null,
        rule: 'COMP_FLOW_MISSING',
        message: `outline.md [comp: flow] for ${page.pageId} but HTML body has no .point or .card class. Use .point for list-style flow or .card for block-style flow.`,
      });
    }
    if (page.comp === 'flow') {
      if (domHasPoint && styleRedefinesPoint) {
        findings.push({
          checkId: 'comp-annotation', file: fileKey, offset: null,
          rule: 'COMP_FLOW_OVERRIDDEN',
          message: `outline.md [comp: flow] for ${page.pageId} but <style> redefines .point. Use tokens.css standard .point or .card.`,
        });
      }
      if (domHasCard && styleRedefinesCard) {
        findings.push({
          checkId: 'comp-annotation', file: fileKey, offset: null,
          rule: 'COMP_FLOW_OVERRIDDEN',
          message: `outline.md [comp: flow] for ${page.pageId} but <style> redefines .card. Use tokens.css standard .point or .card.`,
        });
      }
    }

    // comp: text — no specific class required, but takeaway is allowed
    // (no check needed for comp: text)

    // ── composite (003 主线三 F): page combines two heterogeneous components ──
    // Validate BOTH component classes co-exist in the DOM. Uses single-tag class
    // detection (like domHasCard above) — safe: .card and .flow live on different
    // elements, so we check each independently rather than a cross-tag regex.
    if (page.composite) {
      const domHasFlow = /\bclass\s*=\s*["'][^"']*\bflow\b[^"']*["']/.test(bodyHtml) ||
        /\bclass\s*=\s*["'][^"']*\bnode\b[^"']*["']/.test(bodyHtml);
      const domHasKpi = /\bclass\s*=\s*["'][^"']*\bkpi\b[^"']*["']/.test(bodyHtml) ||
        /\bclass\s*=\s*["'][^"']*\bkpi-grid\b[^"']*["']/.test(bodyHtml);
      const domHasTable = /\bclass\s*=\s*["'][^"']*\bcs-table\b[^"']*["']/.test(bodyHtml) ||
        /\bclass\s*=\s*["'][^"']*\btable\b[^"']*["']/.test(bodyHtml) ||
        /\bclass\s*=\s*["'][^"']*\binfo-bar\b[^"']*["']/.test(bodyHtml);

      const compositeNeeds = {
        'cards+flow': { a: domHasCard, b: domHasFlow, aName: '.card', bName: '.flow/.node' },
        'list+flow': { a: domHasPoint, b: domHasFlow, aName: '.point', bName: '.flow/.node' },
        'kpi+table': { a: domHasKpi, b: domHasTable, aName: '.kpi', bName: '.table/.cs-table/.info-bar' },
      };
      const need = compositeNeeds[page.composite];
      if (need) {
        if (!need.a || !need.b) {
          const missing = !need.a && !need.b ? 'both' : (!need.a ? need.aName : need.bName);
          findings.push({
            checkId: 'comp-annotation', file: fileKey, offset: null,
            rule: 'COMP_COMPOSITE_MISSING',
            message: `outline.md [composite: ${page.composite}] for ${page.pageId} but HTML body is missing ${missing} class. Composite page must contain BOTH component classes (${need.aName} + ${need.bName}). See layout-catalog.md §九、复合 page-body 骨架.`,
          });
        }
        // OVERRIDDEN: composite page must not <style>-redefine any component class
        if ((need.aName.includes('card') && styleRedefinesCard) ||
            (need.aName.includes('point') && styleRedefinesPoint) ||
            (need.bName.includes('flow') && /\.flow\s*\{/.test(allCss))) {
          findings.push({
            checkId: 'comp-annotation', file: fileKey, offset: null,
            rule: 'COMP_COMPOSITE_OVERRIDDEN',
            message: `outline.md [composite: ${page.composite}] for ${page.pageId} but <style> redefines a standard component class (${need.aName} or ${need.bName}). Composite page must use tokens.css standard classes only.`,
          });
        }
      }
    }
  }

  return findings;
}

// ── Check 18: Outline rhythm (P2) ─────────────────────────────
// Scans outline.md [weight: light/medium/heavy] annotations for
// rhythm violations: consecutive heavy pages, long stretches without light.

function checkOutlineRhythm(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');

  if (!existsSync(outlinePath)) return findings;

  const text = readFileSync(outlinePath, 'utf-8');
  const pages = [];

  const pageRe = /^P(\d+)\s/gm;
  let pageMatch;
  while ((pageMatch = pageRe.exec(text)) !== null) {
    const pageNum = pageMatch[1];
    const lineEnd = text.indexOf('\n', pageMatch.index);
    const line = text.slice(pageMatch.index, lineEnd >= 0 ? lineEnd : text.length);
    const weightMatch = line.match(/\[weight:\s*(light|medium|heavy)\]/);
    pages.push({ pageNum, weight: weightMatch ? weightMatch[1] : null });
  }

  if (pages.length === 0) return findings;

  // Unannotated pages
  const unannotated = pages.filter(p => p.weight === null);
  if (unannotated.length > 0) {
    findings.push({
      checkId: 'outline-rhythm', file: 'index.html', offset: null,
      rule: 'WEIGHT_UNANNOTATED',
      message: `${unannotated.length} page(s) missing [weight:] in outline.md (${unannotated.map(p => 'P' + p.pageNum).join(', ')}). Phase 2.3 must annotate each page.`,
    });
  }

  // Consecutive heavy pages (≥3)
  let runStart = 0;
  for (let i = 1; i <= pages.length; i++) {
    const cur = i < pages.length ? pages[i].weight : null;
    const prev = pages[runStart].weight;
    if (cur !== prev || i === pages.length) {
      const runLen = i - runStart;
      if (runLen >= 3 && prev === 'heavy') {
        findings.push({
          checkId: 'outline-rhythm', file: 'index.html', offset: null,
          rule: 'RHYTHM_CONSECUTIVE_HEAVY',
          message: `${runLen} consecutive heavy pages in outline.md (P${pages[runStart].pageNum}–P${pages[i - 1].pageNum}, max 2). Insert a light page (section divider / big quote / stat / image hero).`,
        });
      }
      runStart = i;
    }
  }

  // Long stretch without light pages (≥5)
  runStart = 0;
  for (let i = 1; i <= pages.length; i++) {
    const cur = i < pages.length ? pages[i].weight : null;
    if (cur === 'light' || i === pages.length) {
      const runLen = i - runStart;
      if (runLen >= 5 && pages[runStart].weight !== 'light') {
        findings.push({
          checkId: 'outline-rhythm', file: 'index.html', offset: null,
          rule: 'RHYTHM_NO_LIGHT_STRETCH',
          message: `${runLen} pages without a light page in outline.md (P${pages[runStart].pageNum}–P${pages[i - 1].pageNum}, max 4). Insert a breathing page.`,
        });
      }
      runStart = i;
    }
  }

  return findings;
}

// ── Check 19: Slide number consistency (P2) ───────────────────
// Ensures every slide uses the canonical .slide-number pattern:
// <div class="slide-number" data-current="N" data-total="M"></div>
// Violations: child elements, inline style overrides, wrong tag, presence on cover/qa pages.

function checkSlideNumberConsistency(deckPath) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const files = slideFiles(slidesDir);
  const totalSlides = files.length;

  for (const file of files) {
    const html = loadText(join(slidesDir, file));
    const isCover = /^\d{2}-(cover|封面)/.test(file);
    const isQA = /^\d{2}-(qa|thank|end|结尾)/.test(file);
    // F14 (2026-06-22): T1 template decks (weekly-report / keynote-formal /
    // product-launch) deliberately place page numbers on cover/end pages as part
    // of the skeleton design. Suppress SLIDE_NUM_ON_COVER for T1 pages — it's
    // the template's design choice, not a subagent mistake. T2 hand-written pages
    // still get the WARNING (always-advisory, never blocks via ALWAYS_WARNING_RULES).
    const isTemplatePage = isT1Page(html);

    // Find .slide-number elements
    const slideNumRe = /<(\w+)[^>]*class="[^"]*slide-number[^"]*"[^>]*>([\s\S]*?)<\/\1>/g;
    let m;
    while ((m = slideNumRe.exec(html)) !== null) {
      const tag = m[1];
      const innerHTML = m[2].trim();

      // Cover / QA pages should not have .slide-number (WARNING — some templates deliberately put page numbers on covers)
      if ((isCover || isQA) && !isTemplatePage) {
        findings.push({
          checkId: 'slide-number', file: 'slides/' + file, offset: m.index,
          rule: 'SLIDE_NUM_ON_COVER',
          message: `.slide-number found on ${isCover ? 'cover' : 'QA/end'} page — this is a design choice, not a bug. Verify it is intentional.`,
        });
      }

      // Wrong tag (must be div or span)
      if (tag !== 'div' && tag !== 'span') {
        findings.push({
          checkId: 'slide-number', file: 'slides/' + file, offset: m.index,
          rule: 'SLIDE_NUM_WRONG_TAG',
          message: `.slide-number uses <${tag}> instead of <div>`,
        });
      }

      // Child elements inside (should be empty, content rendered by pseudo-elements)
      if (innerHTML.length > 0) {
        findings.push({
          checkId: 'slide-number', file: 'slides/' + file, offset: m.index,
          rule: 'SLIDE_NUM_CHILD_CONTENT',
          message: `.slide-number contains child elements (dual render with ::before/::after)`,
        });
      }
    }

    // Check for inline style overrides on .slide-number
    const inlineStyleRe = /class="[^"]*slide-number[^"]*"[^>]*style="[^"]*"/g;
    while ((m = inlineStyleRe.exec(html)) !== null) {
      findings.push({
        checkId: 'slide-number', file: 'slides/' + file, offset: m.index,
        rule: 'SLIDE_NUM_INLINE_STYLE',
        message: `.slide-number has inline style override — use tokens.css defaults`,
      });
    }

    // Check for <style> redefinition of .slide-number
    const styleBlockRe = /<style[\s>][\s\S]*?<\/style>/gi;
    let sm;
    while ((sm = styleBlockRe.exec(html)) !== null) {
      const cssBlock = sm[0];
      if (/\.slide-number\s*\{/.test(cssBlock)) {
        findings.push({
          checkId: 'slide-number', file: 'slides/' + file, offset: sm.index,
          rule: 'SLIDE_NUM_REDEFINED',
          message: `.slide-number redefined in <style> — use tokens.css defaults`,
        });
      }
    }
  }

  return findings;
}

// ── Gradient-text scope — REMOVED (check 20) ──────────────────
// .gradient-text on content pages is a legitimate design choice.
// PPTX export handles gradient→solid color degradation at the export layer.
// Rationale: see docs/template-architecture-historical.md §8 item 4 (historical RFC, not runtime).

// ── Check 21: Forced line-break abuse (P2) ────────────────────
// Consecutive <br> tags in body text indicate forced line breaks
// that look unnatural in slides. Allow max 1 consecutive <br>.

function checkForcedLineBreak(deckPath) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const files = slideFiles(slidesDir);

  for (const file of files) {
    const html = loadText(join(slidesDir, file));
    // Match 2+ consecutive <br> (with optional whitespace between)
    const brRe = /(<br\s*\/?>\s*){2,}/gi;
    let m;
    while ((m = brRe.exec(html)) !== null) {
      // Skip if inside <pre> or <address> (legitimate line breaks)
      const before = html.slice(Math.max(0, m.index - 100), m.index);
      if (/<(pre|address)\b/i.test(before)) continue;

      findings.push({
        checkId: 'forced-br', file: 'slides/' + file, offset: m.index,
        rule: 'CONSECUTIVE_BR',
        message: `${(m[0].match(/<br/gi) || []).length} consecutive <br> tags — use CSS (margin/padding) or let text wrap naturally`,
      });
    }
  }

  return findings;
}

// ── Check 22: Visual-layout coupling (P2) ────────────────────────
// Pages with [visual: <type>] should use layouts from the recommended
// pairing table (visual-content-guide.md §5.3). Catches e.g. a page
// tagged [visual: cover] but using L12 table.

function checkVisualLayoutCoupling(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');

  const pages = parseOutlineLayoutAnnotations(outlinePath);
  if (pages.length === 0) return findings;

  for (const page of pages) {
    if (!page.layout || page.visuals.length === 0) continue;

    // Only check page-level visuals (skip element-level: card-bg, decor, section-bg)
    const pageVisuals = page.visuals.filter(v => !['card-bg', 'decor', 'section-bg'].includes(v));
    if (pageVisuals.length === 0) continue;

    for (const visual of pageVisuals) {
      const allowed = VISUAL_LAYOUT_MAP[visual];
      if (!allowed) continue;

      if (!allowed.has(page.layout)) {
        findings.push({
          checkId: 'visual-layout', file: 'index.html', offset: null,
          rule: 'VISUAL_LAYOUT_MISMATCH',
          message: `P${page.pageNum} [visual: ${visual}] paired with ${page.layout}. Recommended: ${[...allowed].join(', ')}.`,
        });
      }
    }
  }

  return findings;
}

// ── Check 22: Component class redefinition (P1) ─────────────────
// Detects when a slide's <style> redefines standard component classes
// from tokens.css (.card, .point, .takeaway, .accent-text, .slide-number,
// .num, .title, .desc). This causes cross-page style drift.

const STANDARD_COMPONENT_CLASSES = [
  'card', 'point', 'takeaway', 'accent-text', 'gradient-text',
  'slide-number', 'num', 'desc',
];

function checkComponentRedefinition(deckPath) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const files = slideFiles(slidesDir);

  for (const file of files) {
    const html = loadText(join(slidesDir, file));
    const styleBlocks = html.match(/<style[^>]*>([\s\S]*?)<\/style>/gi) || [];

    for (const block of styleBlocks) {
      for (const cls of STANDARD_COMPONENT_CLASSES) {
        const re = new RegExp(`\\.${cls.replace('-', '\\-')}\\s*\\{`, 'i');
        if (re.test(block)) {
          findings.push({
            checkId: 'comp-redefinition', file: 'slides/' + file, offset: block.indexOf(`.${cls}`),
            rule: 'COMP_REDEFINITION',
            message: `Standard component class .${cls} is redefined in <style>. Remove the redefinition and use tokens.css defaults. If customization is needed, wrap in an outer div with a custom class.`,
          });
        }
      }
    }
  }

  return findings;
}

// ── Check 23: Comp type rhythm (P2) ────────────────────────────
// Detects consecutive pages using the same [comp:] value (4+ in a row).
// This causes visual monotony — same component type = same visual pattern.

function checkCompRhythm(deckPath) {
  const findings = [];
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');

  if (!existsSync(outlinePath)) return findings;

  const text = readFileSync(outlinePath, 'utf-8');
  const pages = [];

  const pageRe = /^(?:###\s+)?(P(\d+))\b/gm;
  let pageMatch;
  while ((pageMatch = pageRe.exec(text)) !== null) {
    const pageNum = pageMatch[2];
    const lineEnd = text.indexOf('\n', pageMatch.index);
    const line = text.slice(pageMatch.index, lineEnd >= 0 ? lineEnd : text.length);
    const compMatch = line.match(/\[comp:\s*(point|card|flow|text)\]/);
    pages.push({ pageNum, comp: compMatch ? compMatch[1] : null });
  }

  if (pages.length === 0) return findings;

  const maxConsecutive = 4;
  let runStart = 0;
  for (let i = 1; i <= pages.length; i++) {
    const cur = i < pages.length ? pages[i].comp : null;
    const prev = pages[runStart].comp;
    if (cur !== prev || i === pages.length) {
      const runLen = i - runStart;
      if (runLen >= maxConsecutive && prev !== null) {
        findings.push({
          checkId: 'comp-rhythm', file: 'index.html', offset: null,
          rule: 'COMP_RHYTHM_STREAK',
          message: `${runLen} consecutive pages use [comp: ${prev}] (P${pages[runStart].pageNum}–P${pages[i - 1].pageNum}, max ${maxConsecutive}). Insert a different comp type (switch to .point/.card/.text) for visual rhythm.`,
        });
      }
      runStart = i;
    }
  }

  return findings;
}

// ── Check 23: T1 unreplaced keys (P0) ────────────────────────────
// Detects data-replace elements whose textContent still matches the template original.
// This means the subagent failed to replace that key.

function checkT1Unreplaced(deckPath) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const files = slideFiles(slidesDir);

  for (const file of files) {
    const html = loadText(join(slidesDir, file));
    const fileKey = 'slides/' + file;

    // Only check T1 pages
    if (!isT1Page(html)) continue;

    // F1 (2026-06-22): replaced the buggy regex
    //   /data-replace\s*=\s*"([^"]+)"[^>]*>([^<]+)</
    // which only captured text up to the first '<', misjudging nested content
    // slots like <div data-replace="x"><span>文本</span></div> as empty (the
    // ([^<]+) matched only "\n    " before <span>). Now use the tokenizer to
    // extract the element's full textContent (all descendant text), so nested
    // slots are correctly seen as non-empty.
    const tokens = tokenize(html);
    for (let i = 0; i < tokens.length; i++) {
      const tok = tokens[i];
      if (tok.type !== 'TAG_OPEN') continue;
      const tagEnd = html.indexOf('>', tok.offset);
      if (tagEnd < 0) continue;
      const tagHtml = html.slice(tok.offset, tagEnd + 1);
      const keyMatch = tagHtml.match(/data-replace\s*=\s*["']([^"']+)["']/);
      if (!keyMatch) continue;
      const key = keyMatch[1];
      if (VOID_ELEMENTS.has(tok.tagName)) continue;

      // Walk forward to the matching close tag, collecting descendant TEXT
      // and noting whether any child element exists.
      let depth = 1;
      let textContent = '';
      let hasChildElement = false;
      for (let j = i + 1; j < tokens.length && depth > 0; j++) {
        const t = tokens[j];
        if (t.type === 'TAG_OPEN' || t.type === 'TAG_SELF_CLOSE') {
          hasChildElement = true;
          if (t.type === 'TAG_OPEN') depth++;
        } else if (t.type === 'TAG_CLOSE') {
          depth--;
          if (depth === 0) break;
        } else if (t.type === 'TEXT') {
          textContent += t.text;
        }
      }
      // Empty only if no text AND no child element. Icon slots legitimately
      // hold an <svg>/<img> with zero text content (e.g. obsidian feat1-icon).
      if (textContent.trim().length === 0 && !hasChildElement) {
        findings.push({
          checkId: 't1-unreplaced', file: fileKey, offset: tok.offset,
          rule: 'T1_KEY_EMPTY',
          message: `data-replace="${key}" has empty content — subagent may have failed to replace it.`,
        });
      }
    }
  }

  return findings;
}

// ── Check 24: T1 structure integrity (P0) ─────────────────────────
// Template slide-roles.md marks certain elements as "不可改动".
// This check verifies those elements still exist in the output.

const T1_IMMUTABLE_SELECTORS = [
  '.section-num', '.num-tag', '.cover-bg', '.cover-blob',
  '.deck-footer', '.slide-number', '.kicker', '.divider-accent',
];

function checkT1Structure(deckPath) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const files = slideFiles(slidesDir);

  for (const file of files) {
    const html = loadText(join(slidesDir, file));
    const fileKey = 'slides/' + file;

    // Only check T1 pages
    if (!isT1Page(html)) continue;

    // Check that key structural elements are not completely absent
    // (a T1 page with section-num in its template should still have it)
    const sectionNumCount = (html.match(/class="[^"]*\bsection-num\b/gi) || []).length;
    const numTagCount = (html.match(/class="[^"]*\bnum-tag\b/gi) || []).length;

    // Only flag if the page has other template markers but lost structural elements
    // (heuristic: if body has tpl-* class, structural elements should be present)
    if (/class="[^"]*\btpl-/.test(html)) {
      // Check for completely empty body (subagent failure)
      const bodyMatch = html.match(/<body[^>]*>([\s\S]*)<\/body>/i);
      if (bodyMatch) {
        const bodyText = bodyMatch[1].replace(/<[^>]+>/g, '').replace(/\s/g, '');
        if (bodyText.length < 10) {
          findings.push({
            checkId: 't1-structure', file: fileKey, offset: null,
            rule: 'T1_BODY_EMPTY',
            message: 'T1 page body is nearly empty — subagent may have failed to copy template HTML.',
          });
        }
      }
    }
  }

  return findings;
}

// ── Check: Content fidelity (003, L4) ─────────────────────────────
// 从 DECK_NOTES 逐字稿提取「数字+强量词」锚点（如「9 阶段」「31 项」「1036 台」），
// 检查 slide 是否保留该「数字+量词」组合。缺失 = 疑似渲染阶段压缩（dialectic L4：
// 模型已读懂 outline，画 HTML 时偷懒合并）。起步 WARNING（ALWAYS_WARNING）避免
// 误报阻塞；session-2 验证命中情况后再定是否升 ERROR。
// 不靠「节点数对比」（dialectic 已证不可靠），靠可 grep 的数字+量词组合。
const CN_DIGITS = { '零': 0, '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9 };
const CN_UNITS = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
const FIDELITY_QUANTIFIER = '个|项|大|阶段|步骤|层|模块|地|台|套|人|核心|流程|类|方面|维度';
// 结构性量词（D9）：这些量词对应「可数视觉节点」——逐字稿说 N 阶段，slide 应有 ≥ N 个
// 对应结构节点。**只收强排期/流程量词**（阶段/步骤/工序/波次/环节）——这些在「实施计划/
// 路线图」类页几乎必然要画 N 个节点，误报率低。不含「模块/层/节点」——它们常作描述性
// 陈述（「覆盖 4 大模块」「四层架构」是系统组成描述，未必每个都画独立节点），加入会过报。
const STRUCTURAL_QUANTIFIER_RE = /^(阶段|步骤|工序|波次|环节)$/;

function cn2num(s) {
  if (/^[0-9]+$/.test(s)) return parseInt(s, 10);
  if (!/^[零一二两三四五六七八九十]+$/.test(s)) return null;
  if (s === '十') return 10;
  if (s[0] === '十') return 10 + (CN_DIGITS[s[1]] ?? 0);
  if (s[s.length - 1] === '十') return (CN_DIGITS[s[0]] ?? 0) * 10;
  const i = s.indexOf('十');
  if (i > 0 && i < s.length - 1) return (CN_DIGITS[s[0]] ?? 0) * 10 + (CN_DIGITS[s[i + 1]] ?? 0);
  return CN_DIGITS[s] ?? null;
}

function num2cn(n) {
  if (n < 0 || n > 99) return null;
  if (n < 10) return CN_UNITS[n];
  if (n === 10) return '十';
  if (n < 20) return '十' + CN_UNITS[n - 10];
  if (n % 10 === 0) return CN_UNITS[n / 10] + '十';
  return CN_UNITS[Math.floor(n / 10)] + '十' + CN_UNITS[n % 10];
}

function extractFidelityAnchors(text) {
  const re = new RegExp('([0-9]+|[零一二两三四五六七八九十]{1,3})[ ]*(' + FIDELITY_QUANTIFIER + ')', 'g');
  const out = [];
  let m;
  while ((m = re.exec(text)) !== null) {
    const num = cn2num(m[1]);
    if (num === null || num < 2) continue;  // 过滤 1 / 单字噪音
    out.push({ num, unit: m[2], raw: m[1] + m[2] });
  }
  // D9 补充：「数字 + 可选连接量词(个/大/张/条/项/类) + 强排期量词(阶段/步骤/工序/波次/环节)」
  // 如「9个阶段」「九大阶段」——上面的贪婪正则会切成 (9,个)/(九,大)，漏掉排期量词。
  // 这里额外产出以排期量词为 unit 的锚点，供 D9 视觉节点数校验用。只收强排期量词（与
  // STRUCTURAL_QUANTIFIER_RE 一致），不含模块/层（避免架构/描述页过报）。
  const structRe = /([0-9]+|[零一二两三四五六七八九十]{1,3})[ ]*(?:个|大|张|条|项|套|类)?[ ]*(阶段|步骤|工序|波次|环节)/g;
  let sm;
  while ((sm = structRe.exec(text)) !== null) {
    const num = cn2num(sm[1]);
    if (num === null || num < 2) continue;
    const unit = sm[2];
    // 去重：若已有同 (num,unit) 锚点则跳过
    if (out.some(a => a.num === num && a.unit === unit)) continue;
    out.push({ num, unit, raw: sm[1] + unit });
  }
  return out;
}

function anchorPresent(slideText, anchor) {
  const variants = [String(anchor.num), num2cn(anchor.num)].filter(Boolean);
  for (const numStr of variants) {
    let from = 0;
    let idx = slideText.indexOf(numStr, from);
    while (idx !== -1) {
      // num 后 6 字内出现 unit（容忍「31 个验证项」「9 个实施阶段」「九大核心流程」）
      const tail = slideText.slice(idx + numStr.length, idx + numStr.length + 6);
      if (tail.includes(anchor.unit)) return true;
      from = idx + numStr.length;
      idx = slideText.indexOf(numStr, from);
    }
  }
  return false;
}

// D9（session-2）：数 slide 内「可数视觉结构节点」的数量。逐字稿说 N 阶段时，slide
// 应有 ≥ N 个对应结构节点（甘特行/时间线项/流程节点/分层/卡片）——抓「文字写 9 阶段、
// 视觉画 3 Wave」这类 dialectic L4 文字-视觉脱钩。
// 安全：只数单标签 class 标记出现次数（不匹配带子标签的元素内容，符合 tokenize 纪律）。
// 取各结构类的最大计数作为该页「节点容量」——不同布局用不同 class，取最大避免低估。
const STRUCTURAL_NODE_PATTERNS = [
  /class\s*=\s*["'][^"']*\bcs-g-rowlabel\b/g,   // cs-gantt 工序行
  /class\s*=\s*["'][^"']*\bgantt-row\b/g,        // 通用甘特行
  /class\s*=\s*["'][^"']*\bcs-milestone\b/g,     // 甘特里程碑
  /class\s*=\s*["'][^"']*\btl-item\b/g,          // 水平时间线项
  /class\s*=\s*["'][^"']*\btimeline-item\b/g,    // 通用时间线项
  /class\s*=\s*["'][^"']*\bphase\b/g,            // 阶段卡
  /class\s*=\s*["'][^"']*\bnode\b/g,             // 流程节点
  /class\s*=\s*["'][^"']*\btier\b/g,             // 分层架构层
  /class\s*=\s*["'][^"']*\bstep\b/g,             // 步骤
  /class\s*=\s*["'][^"']*\bcol\b/g,              // 路线图列
  /<li\b/g,                                       // 列表项
  /class\s*=\s*["'][^"']*\bcard\b/g,             // 卡片（兜底）
];
function countStructuralNodes(slideText) {
  let max = 0;
  for (const re of STRUCTURAL_NODE_PATTERNS) {
    const n = (slideText.match(re) || []).length;
    if (n > max) max = n;
  }
  return max;
}

function checkContentFidelity(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  if (!notes || typeof notes !== 'object') return findings;

  const slidesDir = join(deckPath, 'slides');
  let allSlideText = '';
  const slideTextByFile = {};
  for (const f of slides) {
    try {
      const t = loadText(join(slidesDir, f));
      slideTextByFile[f] = t;
      allSlideText += '\n' + t;
    } catch (e) { /* skip unreadable */ }
  }
  if (!allSlideText.trim()) return findings;

  const reported = new Set();
  const visualReported = new Set();
  for (const [key, text] of Object.entries(notes)) {
    if (typeof text !== 'string' || !text) continue;
    for (const a of extractFidelityAnchors(text)) {
      const dedup = a.num + '|' + a.unit;
      // ── 文字层锚点（数字+量词组合是否出现，全局去重）──
      if (!reported.has(dedup)) {
        reported.add(dedup);
        if (!anchorPresent(allSlideText, a)) {
          findings.push({
            checkId: 'content-fidelity',
            file: 'slides/' + key,
            offset: null,
            rule: 'CONTENT_FIDELITY_MISSING',
            message: `逐字稿提及「${a.raw}」（${a.num} ${a.unit}），但 slides 未见该「数字+量词」组合——疑似渲染压缩。请确认 1:1 保留，或换密集布局承载。`,
          });
        }
      }
      // ── D9 视觉层校验：结构性量词（阶段/步骤/层/模块/工序…）须有 ≥ N 个视觉节点 ──
      // 只对该逐字稿对应的 slide 页查（key = slide 文件名），节点数 < num → 文字-视觉脱钩。
      if (STRUCTURAL_QUANTIFIER_RE.test(a.unit) && a.num >= 4) {
        const vdedup = key + '|' + dedup;
        if (!visualReported.has(vdedup)) {
          visualReported.add(vdedup);
          // DECK_NOTES 的 key 可能带 "slides/" 前缀，slideTextByFile 用裸文件名——两种都试
          const bareKey = key.replace(/^slides\//, '');
          const slideText = slideTextByFile[key] || slideTextByFile[bareKey];
          if (slideText) {
            const nodeCount = countStructuralNodes(slideText);
            if (nodeCount < a.num) {
              findings.push({
                checkId: 'content-fidelity',
                file: 'slides/' + bareKey,
                offset: null,
                rule: 'CONTENT_FIDELITY_VISUAL_GAP',
                message: `逐字稿说「${a.raw}」（${a.num} ${a.unit}），但该页可数视觉结构节点仅 ${nodeCount} 个（< ${a.num}）——文字写 ${a.num} 但视觉只画 ${nodeCount}（dialectic L4 脱钩，如「9 阶段」画成「3 波次」）。用甘特/多阶段时间线/分层布局展开 ${a.num} 个节点，勿压缩。`,
              });
            }
          }
        }
      }
    }
  }
  return findings;
}

// ── Check: Body-tag comment leak (B2, 003 主线五) ────────────────────
// <body ... <!-- role: xxx --> > — body 开标签内含注释 → 注释被当属性，
// 最后的 > 作为 body 文本子节点渲染出来（实战 v32 5/11 页中招，P05 还泄露了
// 整个 style 字符串）。ERROR（结构性 bug 必须治，batch-fix --fix body-tag-comment 可修）。
function checkBodyTagClean(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    const bodyStart = html.search(/<body[\s>]/);
    if (bodyStart === -1) continue;
    // 扫 body 开标签到闭合 >，跳过注释内的 >
    let i = bodyStart + 5;
    let inComment = false;
    let closeIdx = -1;
    while (i < html.length) {
      if (!inComment) {
        if (html.slice(i, i + 4) === '<!--') { inComment = true; i += 4; continue; }
        if (html[i] === '>') { closeIdx = i; break; }
        i++;
      } else {
        if (html.slice(i, i + 3) === '-->') { inComment = false; i += 3; continue; }
        i++;
      }
    }
    if (closeIdx === -1) continue;
    const openTag = html.slice(bodyStart, closeIdx + 1);
    if (/<!--[\s\S]*?-->/.test(openTag)) {
      findings.push({
        checkId: 'body-tag-clean',
        file: 'slides/' + f,
        offset: bodyStart,
        rule: 'BODY_TAG_COMMENT_LEAK',
        message: '<body> 开标签内含 HTML 注释（<!-- -->），会被解析为属性，末尾 > 泄露成文本。把注释移到 <body ...> 闭合之后。可 batch-fix --fix body-tag-comment 修复。',
      });
    }
  }
  return findings;
}

// ── Check: Page number correctness (B1, 003 主线五) ─────────────────
// 每页 .page-num/.slide-number 文本必须等于 manifest 顺序序号。实战 v31 P02 显
// 「04」/ P11 显「15」——subagent 填模板源页码。ERROR（可 batch-fix --fix fix-page-numbers 修）。
function checkPageNumCorrect(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  if (!manifest) return findings;
  const slidesDir = join(deckPath, 'slides');
  for (let idx = 0; idx < slides.length; idx++) {
    const f = slides[idx];
    const expected = String(idx + 1).padStart(2, '0');
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    const re = /<[^>]*class="[^"]*(?:page-num|slide-number)[^"]*"[^>]*>(\s*)([0-9]{1,3})(\s*)<\/[^>]+>/g;
    let m;
    while ((m = re.exec(html)) !== null) {
      const num = m[2];
      if (num !== expected) {
        findings.push({
          checkId: 'page-num-correct',
          file: 'slides/' + f,
          offset: m.index,
          rule: 'PAGE_NUM_MISMATCH',
          message: `页码显示「${num}」，应为「${expected}」（按 slide 文件顺序）。可 batch-fix --fix fix-page-numbers 修复。`,
        });
      }
    }
  }
  return findings;
}

// ── Check: T1 table/grid empty structure (B3, 003 主线五) ───────────
// T1 页核心容器（<tbody> / 主 grid）若声明了 data-replace 但 children 为空 → ERROR。
// 实战 v32 P09：<table><thead></tbody><caption>（thead 未闭就 </tbody>，整组行丢失）。
function checkT1TableRows(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    // 仅 T1 页检查（T2 是主 agent 自建，结构不同）
    if (!/data-skeleton="t1"/.test(html)) continue;
    // 空 <tbody></tbody> 或 <tbody>\s*</tbody>
    const emptyTbody = /<tbody[^>]*>\s*<\/tbody>/.exec(html);
    if (emptyTbody) {
      findings.push({
        checkId: 't1-table-rows',
        file: 'slides/' + f,
        offset: emptyTbody.index,
        rule: 'T1_EMPTY_TBODY',
        message: '<tbody> 为空——T1 替换时丢失了表格行数据。检查 data-replace 替换是否覆盖了所有行。',
      });
    }
    // thead 未闭合就出现 </tbody>（结构性破损）
    if (/<thead[^>]*>(?:(?!<\/thead>)[\s\S])*<\/tbody>/.test(html)) {
      findings.push({
        checkId: 't1-table-rows',
        file: 'slides/' + f,
        offset: 0,
        rule: 'T1_TABLE_BROKEN',
        message: '<thead> 未闭合就出现 </tbody>——表格结构破损，内容渲染会缺失。',
      });
    }
  }
  return findings;
}

// ── Check: Accent class usage minimum (V1, 003 主线五) ─────────────
// 04 引入的强调 class（kpi-emph/data-emph/takeaway-emph/metric-positive/metric-warning
// /emph-border）在实战中 0 使用。WARNING（应用率引导，不阻塞）：deck 内强调 class
// 总使用次数应 ≥ 页数 × 0.5（向下取整，至少 1）。
function checkAccentUsageMinimum(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  const accentRe = /\b(kpi-emph|data-emph|takeaway-emph|metric-positive|metric-warning|emph-border)\b/g;
  let total = 0;
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    const m = html.match(accentRe);
    if (m) total += m.length;
  }
  const min = Math.max(1, Math.floor(slides.length * 0.5));
  if (total < min) {
    findings.push({
      checkId: 'accent-usage-minimum',
      file: 'index.html',
      offset: null,
      rule: 'ACCENT_USAGE_LOW',
      message: `全 deck 强调 class 仅用 ${total} 次（建议 ≥ ${min}）。04 的 kpi-emph/data-emph/takeaway-emph 等白名单 class 在含 KPI/数据/takeaway 的页应至少挂一个，复刻 PPTX 按信息类型常态分色。`,
    });
  }
  return findings;
}

// ── Check: gantt month sequence (G1/G2/G4, 003 主线六) ──────────────
// 甘特图月份头（仅 .cs-g-head，排除里程碑 .cs-ms-date）必须：
//   ① 单调递增（允许跨年 12→1）  ② 无重复月份
//   ③ 列数 = data-gantt-months（若声明）
// 里程碑 .cs-ms-date 独立校验：日期应落在月份头范围内（防 milestone 残留/乱填）。
// 兼容两种写法：`<div class="cs-g-head"><span>7月</span></div>` 与 `<div class="cs-g-head">7月</div>`。
const GANTT_MONTH_RE = /([0-9]{1,2})月/;
function checkGanttMonthSequence(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    if (html.indexOf('cs-gantt') === -1) continue;

    // 提取 cs-g-head 单元的月份（兼容带/不带 <span>）。cs-ms-date 不带 cs-g-head 类，天然排除。
    const headRe = /<div class="cs-g-head[^"]*"[^>]*>\s*(?:<span>\s*)?([0-9]{1,2})月/g;
    const months = [];
    let m;
    while ((m = headRe.exec(html)) !== null) months.push(parseInt(m[1], 10));
    if (months.length === 0) continue;

    // ② 重复检测
    const seen = new Set();
    const dups = [];
    for (const mo of months) { if (seen.has(mo)) dups.push(mo); seen.add(mo); }
    if (dups.length > 0) {
      findings.push({
        checkId: 'gantt-month-sequence', file: 'slides/' + f, offset: null,
        rule: 'GANTT_MONTH_DUP',
        message: `甘特图月份头出现重复月份 ${[...new Set(dups)].map(x => x + '月').join('、')}（序列：${months.map(x => x + '月').join(' ')}）。模板 12 列写死，项目周期短时残留多余列。请用 data-gantt-start/months 声明周期并跑 batch-fix --fix gantt-months。`,
      });
    }

    // ① 单调递增（允许跨年回绕 12→1）
    let disordered = false;
    for (let i = 1; i < months.length; i++) {
      const prev = months[i - 1], cur = months[i];
      const ok = (cur === ((prev % 12) + 1));
      if (!ok) { disordered = true; break; }
    }
    if (disordered) {
      findings.push({
        checkId: 'gantt-month-sequence', file: 'slides/' + f, offset: null,
        rule: 'GANTT_MONTH_DISORDER',
        message: `甘特图月份头非单调递增：${months.map(x => x + '月').join(' ')}。data-replace 替换不完整导致乱序。请跑 batch-fix --fix gantt-months 按 data-gantt-start/months 重建月份头。`,
      });
    }

    // ③ 列数与声明一致
    const decl = /data-gantt-months="(\d{1,2})"/.exec(html);
    if (decl) {
      const want = parseInt(decl[1], 10);
      if (months.length !== want) {
        findings.push({
          checkId: 'gantt-month-sequence', file: 'slides/' + f, offset: null,
          rule: 'GANTT_MONTH_COUNT',
          message: `甘特图声明 data-gantt-months="${want}" 但实际有 ${months.length} 个月份头。请跑 batch-fix --fix gantt-months 同步。`,
        });
      }
    }

    // ④ 里程碑日期（cs-ms-date）独立校验：应落在月份头范围内
    const msRe = /<div class="cs-ms-date[^"]*"[^>]*>\s*(?:<span>\s*)?([0-9]{1,2})月/g;
    const msDates = [];
    let mm;
    while ((mm = msRe.exec(html)) !== null) msDates.push(parseInt(mm[1], 10));
    if (msDates.length > 0) {
      const headSet = new Set(months);
      const outOfRange = msDates.filter(d => !headSet.has(d));
      if (outOfRange.length > 0) {
        findings.push({
          checkId: 'gantt-month-sequence', file: 'slides/' + f, offset: null,
          rule: 'GANTT_MILESTONE_OUT_OF_RANGE',
          message: `里程碑日期 ${[...new Set(outOfRange)].map(x => x + '月').join('、')} 不在甘特月份头范围（${months[0]}月–${months[months.length - 1]}月）内。疑似模板残留或里程碑日期乱填，请核对里程碑月份与项目周期一致。`,
        });
      }
    }
  }
  return findings;
}

// ── Check: gantt skeleton missing (G3, 003 主线六) ──────────────────
// 角色=process-flow 且讲稿含排期关键词，但页面无 cs-gantt 骨架 → 放弃骨架（L4 复发）。
const SCHEDULE_KW_RE = /(甘特|实施计划|实施路线|分阶段|工期|排期|月实施|阶段实施|时间表|里程碑)/;
function checkGanttSkeletonMissing(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    const isProcessFlow = /<!--\s*role:\s*process-flow\s*-->/.test(html);
    if (!isProcessFlow) continue;
    // 讲稿或页面文本含排期关键词
    const noteText = (notes && (notes['slides/' + f] || notes[f])) || '';
    const hasSchedule = SCHEDULE_KW_RE.test(noteText) || SCHEDULE_KW_RE.test(html);
    if (!hasSchedule) continue;
    if (html.indexOf('cs-gantt') === -1 && !/\b(gantt|timeline-item|tl-item)\b/.test(html)) {
      findings.push({
        checkId: 'gantt-skeleton-missing', file: 'slides/' + f, offset: null,
        rule: 'GANTT_SKELETON_MISSING',
        message: `角色 process-flow + 排期内容，但页面未用甘特/时间线骨架（疑似 fallback 到通用 card）。排期类页应用 17-process-flow-gantt 骨架或 timeline 组件，避免 L4 结构降级。`,
      });
    }
  }
  return findings;
}

// ── Check: arch layer unnamed (A1, 003 §12.3 / D15) ─────────────────
// 架构图（.arch 容器或 arch-diagram 角色）每层须有层名（.tname / .layer-name）。
// L21 标准结构：.arch > .tier(.hl) > .tname(层名) + .cells > .cell。
function checkArchLayerNamed(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    const isArch = /\barch\b/.test(html) || /<!--\s*role:\s*arch-diagram\s*-->/.test(html);
    if (!isArch) continue;
    // 层名槽：.tname（L21 标准）/ .arch-layer-name / .layer-name。空槽 = 缺层名。
    // 匹配 <div class="tname...">（带或不带 <span> 子标签，无可见文本）。
    const nameRe = /<div class="[^"]*\b(?:tname|arch-layer-name|layer-name)\b[^"]*"[^>]*>([\s\S]*?)<\/div>/g;
    let mm; let emptyCount = 0;
    while ((mm = nameRe.exec(html)) !== null) {
      const inner = mm[1];
      if (/<(img|svg)\b/i.test(inner)) continue;
      const text = inner.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, '').replace(/\s+/g, '');
      if (text.length === 0) emptyCount++;
    }
    if (emptyCount > 0) {
      findings.push({
        checkId: 'arch-layer-named', file: 'slides/' + f, offset: null,
        rule: 'ARCH_LAYER_UNNAMED',
        message: `架构图存在 ${emptyCount} 个空层名槽（.tname/.layer-name）。每层须填层名（接入层/核心模块/数据底座…），缺名会让架构语义不清。`,
      });
    }
  }
  return findings;
}

// ── Check: table empty column (T1b, 003 §12.5) ──────────────────────
// 表格存在「整列全空」→ 列数与内容列不匹配，残留空列。
function checkTableEmptyColumn(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    if (html.indexOf('<table') === -1) continue;
    const tables = html.match(/<table[\s\S]*?<\/table>/g) || [];
    for (const t of tables) {
      const rows = t.match(/<tr[\s\S]*?<\/tr>/g);
      if (!rows || rows.length < 2) continue;
      const parsed = rows.map(r => (r.match(/<(t[hd])\b[\s\S]*?<\/\1>/g) || []).map(c => isCellEmptyV(c)));
      const colCount = Math.max(...parsed.map(p => p.length));
      if (colCount < 2) continue;
      for (let col = colCount - 1; col >= 1; col--) {
        const allEmpty = parsed.every(p => col >= p.length || p[col]);
        const someExist = parsed.some(p => col < p.length);
        if (allEmpty && someExist) {
          findings.push({
            checkId: 'table-empty-column', file: 'slides/' + f, offset: null,
            rule: 'TABLE_EMPTY_COLUMN',
            message: `表格存在整列全空（第 ${col + 1} 列）。列数与内容列不匹配，请跑 batch-fix --fix table-empty-col 清理。`,
          });
          break;
        } else if (!(allEmpty && someExist)) break;
      }
    }
  }
  return findings;
}
function isCellEmptyV(cellHtml) {
  const inner = cellHtml.replace(/^<t[hd]\b[^>]*>/, '').replace(/<\/t[hd]>$/, '');
  if (/<(img|svg|input|canvas|video)\b/i.test(inner)) return false;
  return inner.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, '').replace(/\s+/g, '').length === 0;
}

// ── Check: inline style semicolon corruption (B2 延伸) ──────────────
// 实战 v37 P05：style="background:var(--accent)padding:14px" — var(--token) 后缺分号，
// 下一条声明被拼进 var() 参数，样式静默损坏（卡片显示不全/挤成一团的隐藏成因之一）。
// 检测 inline style 内 var(--xxx) 紧跟字母（非 ; / 空格 / 引号 / ) 结尾）。
function checkStyleSemicolonCorruption(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  // var(--token) 后紧跟字母 a-z（声明名如 padding/background）= 缺分号
  const corruptRe = /var\(--[a-z0-9-]+\)\s*[a-z]/gi;
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    const m = html.match(corruptRe);
    if (m) {
      findings.push({
        checkId: 'style-semicolon-corruption', file: 'slides/' + f, offset: null,
        rule: 'STYLE_SEMICOLON_MISSING',
        message: `检测到 ${m.length} 处 inline style 中 var(--token) 后缺分号（如 \`var(--accent)padding\`）→ 下条声明被吞，样式静默损坏。请补分号 \`var(--accent);padding\`。`,
      });
    }
  }
  return findings;
}

// ── Check: CTA placeholder leak (B4 回归 + C1, 003 主线零/六) ─────────
// 生成的 deck tokens.css 中 --hi-strong 不应是占位橙 #f97316（CTA 注入失败/未跑 advisor 的信号）。
const PLACEHOLDER_CTA_RE = /--hi-strong\s*:\s*#f97316\b/i;
function checkCTAPlaceholder(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  // 找 deck 的 tokens.css（shared/ 下）+ 单文件 index.html
  const candidates = [join(deckPath, 'shared', 'tokens.css'), join(deckPath, 'index.html')];
  for (const p of candidates) {
    let txt;
    try { txt = loadText(p); } catch (e) { continue; }
    if (PLACEHOLDER_CTA_RE.test(txt)) {
      findings.push({
        checkId: 'cta-placeholder', file: 'index.html', offset: null,
        rule: 'CTA_PLACEHOLDER_LEAK',
        message: `--hi-strong 仍是占位橙 #f97316（CTA 未注入，源：${p.replace(deckPath + '/', '')}）。每 scheme 已预置协调 CTA，请跑 switch-theme --scheme <名> 注入；若已跑，检查 color-schemes.json 该 scheme 的 hi-strong 预设。`,
      });
      break;
    }
  }
  return findings;
}

// ── Check: bare grid without columns (v46 实证，5 页堆叠) ───────────
// display:grid 但无 grid-template-columns → CSS 默认单列 → 子元素垂直堆叠超页。
// v46 P03/P06/P07/P08/P11 全中（subagent 发明 .l06-grid 只写 display:grid）。
// 检测：含 display:grid 的元素 style/class 无 grid-template-columns / .g2-.g5 / .grid-N。
function checkBareGridNoColumns(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    // 找所有 style 含 display:grid 的开标签
    const re = /<(\w+)\s+([^>]*display:\s*grid[^>]*)>/g;
    let m;
    while ((m = re.exec(html)) !== null) {
      const tag = m[1];
      const attrs = m[2];
      // 有没有列定义？inline style 的 grid-template-columns，或 class 是已定义列数的（.g2-.g6）
      const inlineCols = /grid-template-columns/i.test(attrs);
      const definedClassCol = /\bclass="[^"]*\bg[2-6]\b/.test(attrs);
      if (inlineCols || definedClassCol) continue;
      // 确认是 block 容器元素（div/section 等）
      if (!/^(div|section|ul|main)$/.test(tag)) continue;
      findings.push({
        checkId: 'bare-grid-no-columns', file: 'slides/' + f, offset: m.index,
        rule: 'BARE_GRID_NO_COLUMNS',
        message: `display:grid 元素无 grid-template-columns → 子元素单列垂直堆叠（超页/视觉错乱）。v46 实证 5 页中招。请补列数：inline 加 grid-template-columns:repeat(N,1fr)，或用已定义列数的 .g2/.g3/.g4 class。`,
      });
    }
  }
  return findings;
}

// ── Check: process integrity (v50/v52 绕过标准流程，2026-06-26) ──────
// 检测 deck 是否走了标准 gen-slides 流程。v50/v52 实证：会话绕过 switch-theme +
// post-process，自创 tokens.css + 文件结构，产物全面崩坏（200+ DIV_BARE_TEXT、缺 runtime）。
// 指纹：① tokens.css 无 semantic-tokens 层（未跑 switch-theme mergeSemanticTokens）
//      ② 缺 routing.md（未走 4.2 路由）③ tokens.css 过小（<8KB 多半手写非库内方案）
function checkProcessIntegrity(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  // deckPath 可能是 .../export/<name>-live；routing.md 在其上两级（deck 根）或同级
  const tokensPath = join(deckPath, 'shared', 'tokens.css');
  let tokensCss = '';
  try { tokensCss = loadText(tokensPath); } catch (e) { /* 无 tokens.css 别的 check 会报 */ }

  if (tokensCss) {
    // ① 无 semantic-tokens 层 = 未跑 switch-theme
    if (!/semantic-tokens/.test(tokensCss)) {
      findings.push({
        checkId: 'process-integrity', file: 'index.html', offset: null,
        rule: 'PROCESS_SWITCH_THEME_SKIPPED',
        message: `tokens.css 缺 semantic-tokens 层 → switch-theme 未执行（mergeSemanticTokens 未并入）。这通常说明 4.1 Step C 被绕过，颜色系统非标准（如自创 hex 而非库内 scheme）。请跑：node scripts/switch-theme.mjs --deck "${deckPath}" --scheme <方案名>`,
      });
    }
    // ③ tokens.css 过小（标准换色后 ≥18KB；手写自创常 <8KB）
    if (tokensCss.length < 8000) {
      findings.push({
        checkId: 'process-integrity', file: 'index.html', offset: null,
        rule: 'TOKENS_FILE_SUSPICIOUS',
        message: `tokens.css 仅 ${tokensCss.length} 字节（标准换色后通常 ≥18000）。疑似手写自创、未走 switch-theme，而非从模板 cp + 换色。`,
      });
    }
  }

  // ② 缺 routing.md = 未走 4.2（routing.md 在 deck 根，即 export 的上两级）
  const deckRoot = deckPath.replace(/\/export\/[^/]+-live\/?$/, '').replace(/\/export$/, '');
  const routingPath = join(deckRoot, 'routing.md');
  if (!existsSync(routingPath)) {
    findings.push({
      checkId: 'process-integrity', file: 'index.html', offset: null,
      rule: 'PROCESS_ROUTING_MISSING',
      message: `缺 routing.md → 4.2 逐页骨架路由未执行。标准流程必产出 routing.md（T1/T2 分配 + 骨架源）。绕过路由直接手写 HTML 是 v50/v52 崩坏的根因。`,
    });
  }
  return findings;
}

// ── Check: unsized icon img (v63 P11 大 SVG 遮挡根因，2026-06-28) ────
// <img src="...icons/..."> 无 width/height 属性且 class 未定义尺寸 → SVG 以原生 viewBox
// 渲染（circle-checkmark.svg 是 16×16 但部分图标无 viewBox 会撑满）。v63 P11 实证：
// replace-emoji-icons 生成 class="icon-md"，consultant-strategy tokens.css 无 .icon-md → 遮挡。
function checkUnsizedIconImg(deckPath, indexHtml, manifest, notes, slides) {
  const findings = [];
  const slidesDir = join(deckPath, 'slides');
  // deck tokens.css 是否定义了 .icon-md（粗判：读 shared/tokens.css）
  let tokensCss = '';
  try { tokensCss = loadText(join(deckPath, 'shared', 'tokens.css')); } catch (e) { /* */ }
  const hasIconMdDef = /\.icon-md\b/.test(tokensCss);
  for (const f of slides) {
    let html;
    try { html = loadText(join(slidesDir, f)); } catch (e) { continue; }
    // 找引用 assets/icons 的 img
    const re = /<img\s+[^>]*src="[^"]*assets\/icons\/[^"]*"[^>]*>/g;
    let m;
    while ((m = re.exec(html)) !== null) {
      const tag = m[0];
      const hasSizeAttr = /\b(width|height)\s*=\s*["']?\d/i.test(tag);
      const hasIconClass = /\bclass="[^"]*\bicon-(sm|md|lg|xl|2xl)\b/i.test(tag);
      // 有 width/height 属性 → OK；有 icon class 但 deck 未定义该 class → 问题
      if (hasSizeAttr) continue;
      if (hasIconClass && !hasIconMdDef) {
        findings.push({
          checkId: 'unsized-icon-img', file: 'slides/' + f, offset: m.index,
          rule: 'ICON_CLASS_UNDEFINED',
          message: `<img> 引用图标用 class="icon-*" 但 deck tokens.css 未定义该尺寸 class → SVG 可能以原生尺寸渲染撑满页面（v63 P11 遮挡根因）。修法：img 加 width/height 属性，或 deck tokens.css 补 .icon-md 定义。`,
        });
      } else if (!hasIconClass) {
        findings.push({
          checkId: 'unsized-icon-img', file: 'slides/' + f, offset: m.index,
          rule: 'ICON_IMG_UNSIZED',
          message: `<img> 引用图标但无 width/height 属性也无尺寸 class → SVG 可能以原生尺寸渲染。请加 width="24" height="24" 或 class="icon-md"。`,
        });
      }
    }
  }
  return findings;
}

const CHECK_REGISTRY = [
  { id: 'asset',    label: 'Asset path integrity',     fn: checkAssetPaths },
  { id: 'runtime',  label: 'index-runtime.js existence', fn: checkRuntimeJS },
  { id: 'manifest', label: 'DECK_MANIFEST consistency', fn: checkManifest },
  { id: 'notes',    label: 'DECK_NOTES completeness',   fn: checkNotes },
  { id: 'css',      label: 'CSS reference consistency', fn: checkCSSRefs },
  { id: 'html',     label: 'HTML structure basics',     fn: checkHTMLStructure },
  { id: 'pptx',     label: 'PPTX editable pre-check',   fn: checkPPTXPrecheck },
  { id: 'content',  label: 'Content overflow detection', fn: checkContentOverflow },
  { id: 'emoji',    label: 'Emoji detection',              fn: checkEmoji },
  { id: 'visual',   label: 'Visual annotation consistency', fn: checkVisualAnnotations },
  { id: 'img-embed', label: 'Image embedding completeness',    fn: checkImageEmbedding },
  { id: 'layout-rhythm', label: 'Layout rhythm check',            fn: checkLayoutRhythm },
  { id: 'layout-diversity', label: 'Layout diversity check',       fn: checkLayoutDiversity },
  { id: 'accent-density', label: 'Accent-text density check',     fn: checkAccentDensity },
  { id: 'theme-compliance', label: 'Theme annotation compliance',   fn: checkThemeCompliance },
  { id: 'takeaway-coverage', label: 'Takeaway coverage check',      fn: checkTakeawayCoverage },
  { id: 'theme-annotation', label: 'Theme annotation completeness', fn: checkThemeAnnotation },
  { id: 'comp-annotation', label: 'Component annotation execution', fn: checkCompAnnotation },
  { id: 'outline-rhythm', label: 'Outline rhythm check', fn: checkOutlineRhythm },
  { id: 'slide-number', label: 'Slide number consistency', fn: checkSlideNumberConsistency },
  { id: 'forced-br', label: 'Forced line-break abuse', fn: checkForcedLineBreak },
  { id: 'visual-layout', label: 'Visual-layout coupling', fn: checkVisualLayoutCoupling },
  { id: 'comp-redefinition', label: 'Component class redefinition', fn: checkComponentRedefinition },
  { id: 'comp-rhythm', label: 'Comp type rhythm check', fn: checkCompRhythm },
  { id: 't1-unreplaced', label: 'T1 unreplaced keys', fn: checkT1Unreplaced },
  { id: 't1-structure', label: 'T1 structure integrity', fn: checkT1Structure },
  { id: 'content-fidelity', label: 'Content fidelity (outline anchor)', fn: checkContentFidelity },
  { id: 'body-tag-clean', label: 'Body tag comment leak (B2)', fn: checkBodyTagClean },
  { id: 'page-num-correct', label: 'Page number correctness (B1)', fn: checkPageNumCorrect },
  { id: 't1-table-rows', label: 'T1 table/grid structure (B3)', fn: checkT1TableRows },
  { id: 'accent-usage-minimum', label: 'Accent class usage minimum (V1)', fn: checkAccentUsageMinimum },
  { id: 'gantt-month-sequence', label: 'Gantt month sequence (G1/G2)', fn: checkGanttMonthSequence },
  { id: 'gantt-skeleton-missing', label: 'Gantt skeleton missing (G3)', fn: checkGanttSkeletonMissing },
  { id: 'arch-layer-named', label: 'Arch layer named (A1)', fn: checkArchLayerNamed },
  { id: 'table-empty-column', label: 'Table empty column (T1b)', fn: checkTableEmptyColumn },
  { id: 'style-semicolon-corruption', label: 'Style semicolon corruption (B2 ext)', fn: checkStyleSemicolonCorruption },
  { id: 'cta-placeholder', label: 'CTA placeholder leak (B4/C1)', fn: checkCTAPlaceholder },
  { id: 'bare-grid-no-columns', label: 'Bare grid without columns (v46)', fn: checkBareGridNoColumns },
  { id: 'process-integrity', label: 'Process integrity (v50/v52)', fn: checkProcessIntegrity },
  { id: 'unsized-icon-img', label: 'Unsized icon img (v63)', fn: checkUnsizedIconImg },
];

// ── Trap rules (F21, 2026-06-22) ──────────────────────────────────
// Structured metadata for the subagent "已知 validate 陷阱" checklist. Only rules
// a subagent can avoid by writing correct HTML at generation time belong here —
// not asset-path/manifest/runtime checks (those are workflow concerns, not writing
// traps). The brief/rules trap sections are hand-maintained from this TRAP_RULES
// source (the generator scripts are archived under docs/003-ppt-generator-content-richness/).
//
// Schema: { id, title, wrong[], correct[], note? }
//   - wrong/correct are concrete HTML snippets a subagent recognizes.
export const TRAP_RULES = [
  {
    id: 'DIV_BARE_TEXT',
    title: '裸文字 div：包 `<span>`，绝不改成 `<p>` 或 `<h>`',
    wrong: ['<div>裸文字</div>', '<div>裸文字</div> → <p>裸文字</p>（禁止改标签）'],
    correct: ['<div><span>裸文字</span></div>（class/属性原样留外层 div）'],
    note: '模板自带白名单 class（.n .l .tl-title .tl-meta .tl-desc .arch-box .sub .q-label）可保留裸文字。批量兜底：batch-fix.mjs --fix div-bare-text。',
  },
  {
    id: 'NONUNIFORM_BORDER_RADIUS',
    title: '别把单边 border + border-radius 混用',
    wrong: ['<div style="border-left:1px solid red;border-radius:8px">'],
    correct: ['四边 border: 1px solid red + border-radius', '或干脆不加单边 border，用独立装饰元素'],
    note: '单边 border + 圆角在 PPTX 渲染时方角不跟弧。',
  },
  {
    id: 'TEXT_STYLING',
    title: '`<p>/<h>/<li>` 不带 border/background/box-shadow',
    wrong: ['<p style="border-left:1px solid var(--border)">文本</p>', '<p style="background:#f00">文本</p>'],
    correct: ['<div class="insight-line"><p>文本</p></div>（border 移到外层 div）', '装饰线用外层 div 或 padding'],
    note: '为 PPTX 转换高效：hybrid v2 原生重建 <p> 时不处理 border。全插件统一禁 <p> border。',
  },
  {
    id: 'EMOJI_IN_SLIDE',
    title: '可见区不用 emoji',
    wrong: ['<p>© 2024</p>', '<span>★ 推荐</span>', '<div>✓ 已完成</div>'],
    correct: ['用文字 "©" 写成 "Copyright" 或用 SVG 图标', '★/✓ 用 SVG icon 或 CSS 图形'],
    note: 'emoji 仅限：data-replace 占位槽（将被替换）或 <code>/<pre> 代码字面量——这两类自动豁免。xhs-pastel-card 等美学模板的 emoji 占位也属豁免。',
  },
  {
    id: 'SLIDE_NUM_ON_COVER',
    title: '封面/结束页不放 `.slide-number`（T2 手写页）',
    wrong: ['<div class="slide-number">1</div> 放在 01-cover.html'],
    correct: ['内容页才用 .slide-number；封面/结束页用 D 骨架居中排版'],
    note: 'T1 模板自带封面页码是设计选择，已豁免；此条针对 T2 手写页。',
  },
  {
    id: 'CONSECUTIVE_BR',
    title: '标题换行不用连续 `<br>`',
    wrong: ['<h2>第一行<br><br>第二行</h2>（≥2 连续 <br>）'],
    correct: ['CJK 大标题用 CSS keep-all + balance + overflow-wrap 接管换行', '确需断点用 <wbr> 而非 <br>'],
    note: '误判用 <wbr>（零宽换行机会），不触发 CONSECUTIVE_BR。',
  },
  {
    id: 'T1_KEY_EMPTY',
    title: 'T1 模板的 data-replace 槽必须填内容',
    wrong: ['<div data-replace="title"></div>（空）'],
    correct: ['<div data-replace="title">实际标题</div>', 'icon 槽可填 <svg>/<img>（无文字也算非空）'],
    note: 'subagent 复制 T1 模板后必须替换所有 data-replace 区域。',
  },
  {
    id: 'COMP_REDEFINITION',
    title: '不在 slide 的 `<style>` 里重定义标准组件类',
    wrong: ['<style>.card { ... }</style>（重定义 tokens.css 的 .card）'],
    correct: ['标准组件类（.card/.point/.takeaway/.pill 等）只引用不重定义', '自定义样式用独立 class 名'],
  },
  {
    id: 'ROLE_ANNOTATION',
    title: '`<!-- role: xxx -->` 用裸 ID，别带说明文字',
    wrong: ['<!-- role: cover — 开场钩子 -->'],
    correct: ['<!-- role: cover -->（ID 字符仅 [A-Za-z0-9_-]）'],
    note: '多余文字曾导致"唯一角色数"统计虚高 → ROLE_DIVERSITY_LOW 误报。',
  },
  {
    id: 'IMAGE_MANIFEST',
    title: 'image-manifest：CSS-only deck 也要交一份',
    wrong: ['全 CSS deck 不写 image-manifest.md', '写空表留 0 OK'],
    correct: ['每个 [visual: xxx]（非 none）页标 SKIPPED', '真实生图失败的页如实标 FAILED（全 FAILED 会报 VISUAL_ALL_FAILED）'],
    note: '批量兜底：batch-fix.mjs --fix sync-image-manifest（仅 manifest 缺失时生成全 SKIPPED，绝不覆盖已有）。',
  },
];

// ── Main ──────────────────────────────────────────────────────────

function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.deck) {
    console.error('Error: --deck <dir> is required.\n');
    printUsage();
    process.exit(2);
  }

  const deckPath = resolve(args.deck);
  const slidesDir = join(deckPath, 'slides');

  if (!existsSync(deckPath) || !existsSync(slidesDir)) {
    console.error(`Error: deck directory not found or missing slides/: ${deckPath}`);
    process.exit(2);
  }

  if (args.mode !== 'all' && args.mode !== 'strict' && args.mode !== 'editable-strict') {
    console.error(`Error: unknown mode "${args.mode}". Use "all", "strict", or "editable-strict".\n`);
    printUsage();
    process.exit(2);
  }

  if (args.check && !CHECK_IDS.includes(args.check)) {
    console.error(`Error: unknown check "${args.check}". Valid: ${CHECK_IDS.join(', ')}`);
    process.exit(2);
  }

  // Load deck data
  let indexHtml;
  try {
    indexHtml = loadText(join(deckPath, 'index.html'));
  } catch (e) {
    console.error(`Error: cannot read index.html: ${e.message}`);
    process.exit(2);
  }

  // Parse DECK_MANIFEST and DECK_NOTES, capturing syntax errors as findings
  let manifest = null;
  let notes = null;
  let earlyFindings = [];

  try {
    manifest = parseDeckManifest(indexHtml);
  } catch (e) {
    earlyFindings.push({ checkId: 'manifest', file: 'index.html', offset: null, rule: 'MANIFEST_PARSE_ERROR', message: e.message });
  }
  try {
    notes = parseDeckNotes(indexHtml);
  } catch (e) {
    earlyFindings.push({ checkId: 'notes', file: 'index.html', offset: null, rule: 'NOTES_PARSE_ERROR', message: e.message });
  }

  const files = slideFiles(slidesDir);

  if (files.length === 0) {
    console.error('Error: no HTML files found in slides/.');
    process.exit(2);
  }

  // Report early parse errors immediately (these block all other checks)
  if (earlyFindings.length > 0) {
    console.log(`Validating: ${deckPath}`);
    console.log(`  ${files.length} slides, 0 checks (parse errors blocked)\n`);
    for (const f of earlyFindings) {
      console.log(`  index.html  ${RED}ERROR  ${RESET}  ${f.rule}: ${f.message}`);
    }
    console.log(`\n${'─'.repeat(50)}`);
    console.log(`Summary: ${RED}1 ERROR${RESET} — fix index.html and re-run.`);
    process.exit(1);
  }

  const checksToRun = args.check
    ? CHECK_REGISTRY.filter(c => c.id === args.check)
    : CHECK_REGISTRY;

  console.log(`Validating: ${deckPath}`);
  console.log(`  ${files.length} slides, ${checksToRun.length} check${checksToRun.length > 1 ? 's' : ''}, mode=${args.mode}\n`);

  // Pre-load all slide HTML for line number lookup
  const slideHTMLCache = {};
  for (const f of files) {
    slideHTMLCache[f] = loadText(join(slidesDir, f));
  }

  // Run checks
  let allFindings = [];
  for (const check of checksToRun) {
    allFindings.push(...check.fn(deckPath, indexHtml, manifest, notes, files));
  }

  // Report (use cached HTML for line numbers)
  const padLen = String(files.length).length;
  const classified = allFindings.map(f => ({
    ...f,
    effectiveSeverity: getEffectiveSeverity(f.checkId, args.mode, f.rule),
  }));

  let totalErrors = 0;
  let totalWarnings = 0;
  const totalChecks = files.length * checksToRun.length;

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const fileKey = 'slides/' + file;
    const fileFindings = classified.filter(f => f.file === fileKey);
    const errors = fileFindings.filter(f => f.effectiveSeverity === 'ERROR');
    const warnings = fileFindings.filter(f => f.effectiveSeverity === 'WARNING');
    const num = `[${String(i + 1).padStart(padLen)}/${files.length}]`;

    if (errors.length === 0 && warnings.length === 0) {
      if (!args.quiet) console.log(`${num} ${file}  ${GREEN}✓${RESET}`);
      continue;
    }

    const parts = [];
    if (errors.length) parts.push(`${errors.length} error${errors.length > 1 ? 's' : ''}`);
    if (warnings.length) parts.push(`${warnings.length} warning${warnings.length > 1 ? 's' : ''}`);
    console.log(`${num} ${file}  ${RED}✗${RESET} ${parts.join(', ')}`);

    for (const f of fileFindings) {
      if (args.quiet && f.effectiveSeverity === 'WARNING') continue;
      const color = f.effectiveSeverity === 'ERROR' ? RED : YELLOW;
      const tag = f.effectiveSeverity.padEnd(7);
      const loc = f.offset != null ? `L${getLineNumber(slideHTMLCache[file], f.offset)}  ` : '';
      console.log(`  ${loc}${color}${tag}${RESET}  ${f.rule}: ${f.message}`);
    }

    totalErrors += errors.length;
    totalWarnings += warnings.length;
  }

  const indexFindings = classified.filter(f => f.file === 'index.html');
  if (indexFindings.length > 0) {
    console.log('\nindex.html:');
    for (const f of indexFindings) {
      if (args.quiet && f.effectiveSeverity === 'WARNING') continue;
      const color = f.effectiveSeverity === 'ERROR' ? RED : YELLOW;
      const tag = f.effectiveSeverity.padEnd(7);
      console.log(`  ${color}${tag}${RESET}  ${f.rule}: ${f.message}`);
    }
    totalErrors += indexFindings.filter(f => f.effectiveSeverity === 'ERROR').length;
    totalWarnings += indexFindings.filter(f => f.effectiveSeverity === 'WARNING').length;
  }

  const totalPasses = totalChecks - totalErrors - totalWarnings;
  console.log(`\n${'─'.repeat(50)}`);
  console.log(`Summary: ${files.length} slides, ${checksToRun.length} check${checksToRun.length > 1 ? 's' : ''} each (${totalChecks} total)`);
  console.log(`  ${GREEN}PASS${RESET}  ${totalPasses}   ${RED}ERROR${RESET}  ${totalErrors}   ${YELLOW}WARNING${RESET}  ${totalWarnings}`);
  if (args.mode === 'all' && totalWarnings > 0) {
    console.log('  Run with --mode strict to promote warnings to errors.');
  }

  process.exit(totalErrors > 0 ? 1 : 0);
}

// Run main() only when invoked directly as a script, not when imported (any
// consumer importing TRAP_RULES — e.g. the archived generator under
// docs/003-ppt-generator-content-richness/ — must not trigger a validation run). ESM equivalent of require.main === module. Use resolve() to
// normalize relative CLI invocations against import.meta.url (same pattern as
// batch-fix.mjs).
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main();
}
