# 图表组件模板库（30 种）

纯 CSS / 内联 SVG 片段图表组件，复制进 slide `<body>` 即可。所有颜色走 `shared/tokens.css` 的 `var(--token)`，跟随主题/明暗。曲线类（折线/面积/雷达/散点）用内联 SVG，坐标写死、着色 token 化，PPTX 导出友好（无需 Chart.js）。

- **机器选型**：`charts-index.json`（AI / 程序优先读取）
- **人工浏览**：本 README

## 快速选择

> 🤖 AI 选型优先读 `charts-index.json` 的 `quickLookup`；人工浏览用下表。

| 我想展示... | 推荐模板 | 文件 |
|------------|---------|------|
| 时间趋势 | 折线图 / 面积图 | `line-chart.html` / `area-chart.html` |
| 类别数值对比 | 柱状图 | `bar-chart.html` |
| 长标签排名 | 水平条形排名 | `horizontal-bar-chart.html` |
| 多系列对比 | 分组柱状图 | `grouped-bar-chart.html` |
| 构成占比 | 饼图 / 环形图 | `pie-chart.html` / `donut-chart.html` |
| 层级面积占比 | 矩形树图 | `treemap-chart.html` |
| 堆叠构成 | 堆叠柱状图 | `stacked-bar-chart.html` |
| 增减分解 | 瀑布图 | `waterfall-chart.html` |
| 左右双向对比 | 蝴蝶图 | `butterfly-chart.html` |
| 目标 vs 实际 | 子弹图 | `bullet-chart.html` |
| 前后两点对比 | 哑铃图 | `dumbbell-chart.html` |
| 多维评估 | 雷达图 | `radar-chart.html` |
| 相关性/分布 | 散点图 | `scatter-chart.html` |
| 矩阵强度分布 | 热力图 | `heatmap-chart.html` |
| 达成度 | 仪表盘 / 进度条 | `gauge-chart.html` / `progress-bar.html` |
| 关键数字指标 | KPI 卡片 / 大数字 | `kpi-cards.html` / `big-numbers.html` |
| 转化漏斗 | 漏斗图 | `funnel-chart.html` |
| 里程碑 | 时间线 | `timeline.html` |
| 业务流程 | 流程图 | `process-flow.html` |
| 项目排期 | 甘特图 | `gantt-chart.html` |
| 组织架构 | 组织结构图 | `org-chart.html` |
| 四象限分析 | 矩阵图 | `matrix-2x2.html` |
| 战略分析 | SWOT / 波特五力 | `swot-analysis.html` / `porter-five-forces.html` |
| 多维评分 | 评分卡 | `rating-score.html` |
| 方案对比 | 对比表格 | `comparison-table.html` |

## 完整索引（按类别）

### 趋势类（svg-inline）
| 文件 | 用途 | 场景 |
|------|------|------|
| `line-chart.html` | 折线趋势（2 系列） | 时间序列、增长趋势、同比 |
| `area-chart.html` | 面积累积趋势 | 流量趋势、用户增长 |

### 对比类
| 文件 | 用途 | 场景 |
|------|------|------|
| `bar-chart.html` | 垂直柱状对比（3-8 柱） | 销售额对比、区域排名 |
| `horizontal-bar-chart.html` | 水平条形排名（5-12 条，前三高亮） | 品牌排行、满意度评分 |
| `grouped-bar-chart.html` | 多系列分组对比 | 季度产品线对比、同比环比 |
| `stacked-bar-chart.html` | 堆叠构成对比 | 收入构成、市场份额变化 |
| `waterfall-chart.html` | 增减变化分解 | 利润分解、预算变化 |
| `butterfly-chart.html` | 左右双向对比（中轴对称） | 人口金字塔、AB 测试、收支对比 |
| `bullet-chart.html` | 目标 vs 实际（区间+目标线） | KPI 达成、绩效评估 |
| `dumbbell-chart.html` | 两点对比（前后连线） | 竞品前后、实验对比、改造成效 |
| `comparison-table.html` | 2-3 列方案对比 | 方案选型、功能对比 |

### 占比类
| 文件 | 用途 | 场景 |
|------|------|------|
| `pie-chart.html` | 占比（实心，多段 conic） | 市场份额、预算分配 |
| `donut-chart.html` | 占比（带中心数字） | 结构占比、达成率 |
| `treemap-chart.html` | 层级面积占比（flex 分块） | 预算分配、市场份额构成 |

### 指标类
| 文件 | 用途 | 场景 |
|------|------|------|
| `kpi-cards.html` | 关键指标卡片 | 财务总览、数据看板 |
| `big-numbers.html` | 单一大数字冲击 | 核心成果、里程碑 |
| `gauge-chart.html` | 180° 仪表盘达成度 | KPI 完成率、性能监控 |
| `progress-bar.html` | 单/多项进度条 | OKR 进度、项目完成度 |
| `rating-score.html` | 多维评分 | 能力评估、竞品打分 |

### 分析类
| 文件 | 用途 | 场景 |
|------|------|------|
| `radar-chart.html` | 多维评估（5 轴，svg） | 能力评估、竞品对比 |
| `scatter-chart.html` | 相关性/分布（svg） | 投入产出、价格需求 |
| `heatmap-chart.html` | 矩阵强度分布（--i 浓度） | 用户活跃时段、相关性矩阵 |

### 流程/关系类
| 文件 | 用途 | 场景 |
|------|------|------|
| `timeline.html` | 里程碑/历程 | 里程碑、历史演进 |
| `process-flow.html` | 水平业务流程（SVG 图标） | 业务流程、操作指南 |
| `funnel-chart.html` | 转化漏斗 | 销售漏斗、用户转化 |
| `gantt-chart.html` | 项目排期（left%+width%） | 项目管理、产品路线图 |
| `org-chart.html` | 层级树（可嵌套） | 公司架构、汇报关系 |

### 战略框架类
| 文件 | 用途 | 场景 |
|------|------|------|
| `matrix-2x2.html` | 四象限分析 | 波士顿矩阵、优先级 |
| `swot-analysis.html` | SWOT 四象限（四色） | 战略规划、竞品分析 |
| `porter-five-forces.html` | 波特五力（3×3） | 行业分析、市场进入 |

## 使用约定

1. 读取对应 `.html` 模板，复制 `<body>` 片段到 slide
2. 替换 `{{}}` 占位符与示例数值
3. 颜色一律用 `var(--accent)` 等 token；高度/宽度/位置百分比按模板注释公式换算
4. **PPTX 导出**：本库 30 种全部 `render=css` 或 `svg-inline`，导出友好，**无需 Chart.js**（曲线类已用内联 SVG token 版替代）
5. **SVG 图表改数据**：趋势/雷达/散点的坐标在模板注释里给了换算公式（如 `y = 340 - 3.16*值`），改值时重算对应坐标即可

## 完整索引（按类别）

### 对比类
| 文件 | 用途 | 场景 |
|------|------|------|
| `bar-chart.html` | 垂直柱状对比（3-8 柱） | 销售额对比、区域排名 |
| `horizontal-bar-chart.html` | 水平条形排名（5-12 条，前三高亮） | 品牌排行、满意度评分 |
| `grouped-bar-chart.html` | 多系列分组对比 | 季度产品线对比、同比环比 |
| `stacked-bar-chart.html` | 堆叠构成对比 | 收入构成、市场份额变化 |
| `waterfall-chart.html` | 增减变化分解 | 利润分解、预算变化 |
| `butterfly-chart.html` | 左右双向对比（中轴对称） | 人口金字塔、AB 测试、收支对比 |
| `bullet-chart.html` | 目标 vs 实际（区间+目标线） | KPI 达成、绩效评估 |
| `dumbbell-chart.html` | 两点对比（前后连线） | 竞品前后、实验对比、改造成效 |
| `comparison-table.html` | 2-3 列方案对比 | 方案选型、功能对比 |

### 占比类
| 文件 | 用途 | 场景 |
|------|------|------|
| `pie-chart.html` | 占比（实心，多段 conic） | 市场份额、预算分配 |
| `donut-chart.html` | 占比（带中心数字） | 结构占比、达成率 |
| `treemap-chart.html` | 层级面积占比（flex 分块） | 预算分配、市场份额构成 |

### 指标类
| 文件 | 用途 | 场景 |
|------|------|------|
| `kpi-cards.html` | 关键指标卡片 | 财务总览、数据看板 |
| `big-numbers.html` | 单一大数字冲击 | 核心成果、里程碑 |
| `gauge-chart.html` | 180° 仪表盘达成度 | KPI 完成率、性能监控 |
| `progress-bar.html` | 单/多项进度条 | OKR 进度、项目完成度 |
| `rating-score.html` | 多维评分 | 能力评估、竞品打分 |

### 分析类
| 文件 | 用途 | 场景 |
|------|------|------|
| `heatmap-chart.html` | 矩阵强度分布（--i 浓度） | 用户活跃时段、相关性矩阵 |

### 流程/关系类
| 文件 | 用途 | 场景 |
|------|------|------|
| `timeline.html` | 里程碑/历程 | 里程碑、历史演进 |
| `process-flow.html` | 水平业务流程（SVG 图标） | 业务流程、操作指南 |
| `funnel-chart.html` | 转化漏斗 | 销售漏斗、用户转化 |
| `gantt-chart.html` | 项目排期（left%+width%） | 项目管理、产品路线图 |
| `org-chart.html` | 层级树（可嵌套） | 公司架构、汇报关系 |

### 战略框架类
| 文件 | 用途 | 场景 |
|------|------|------|
| `matrix-2x2.html` | 四象限分析 | 波士顿矩阵、优先级 |
| `swot-analysis.html` | SWOT 四象限（四色） | 战略规划、竞品分析 |
| `porter-five-forces.html` | 波特五力（3×3） | 行业分析、市场进入 |

## 使用约定

1. 读取对应 `.html` 模板，复制 `<body>` 片段到 slide
2. 替换 `{{}}` 占位符与示例数值
3. 颜色一律用 `var(--accent)` 等 token；高度/宽度/位置百分比按模板注释公式换算
4. **PPTX 导出**：本库全部 `render=css`，导出友好。折线/雷达等曲线类暂用 Chart.js（导出会 rasterize），第三批将以 `svg-inline` token 版补齐

## 待扩充（见 `charts-index.json` planned）

- **第三批（svg-inline）**：line / area / radar / scatter
