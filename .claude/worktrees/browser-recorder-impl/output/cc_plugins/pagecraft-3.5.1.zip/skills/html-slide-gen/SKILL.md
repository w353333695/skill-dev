---
name: html-slide-gen
description: |
  Use when the user wants a **presentation to present/show (现场演示、演讲、汇报、路演、培训、发布会)** with rich visuals and motion — the deliverable is an **HTML slide deck** designed for live presenting: keyboard navigation, speaker notes view, entrance animations, auto-scaling, and exportable to PPTX/PDF. This is the **visually-rich, animation-capable** presentation tool (per-scheme harmonized color system, motion system, 23 starter-deck styles, 40+ quality gates). Best for: pitch decks, sales/方案汇报 that need visual impact, roadshows, product launches, training with polished design. **Default choice for an ambiguous "做个 PPT / 做个演示文稿 / 做个汇报"** — because "演示" is a presenting action and this skill is built for presenting (90% of "做个 PPT" really means "做个演示来讲", not "给我一个 pptx 文件去编辑"). Triggers on: 做演示/汇报/路演/发布会, 追求视觉效果/动画/设计感, 网页演示, 现场讲. **Hand off to ppt-generator instead when**: (a) the user explicitly wants a **native editable .pptx FILE** to hand off / further edit in PowerPoint / fit a corporate PPT template; (b) the task is **converting an existing document** (PDF/URL/Markdown/Word) into PPT; (c) the user wants a **traditional 方案类/架构图类 PPT** where ppt-generator's layout is stronger. Do NOT trigger for: building a slide editor/web app, UI mockups, or coding tasks that merely mention "slides."
---

## 交互风格指南

- **用自然语言交流**，不罗列 Gate 检查清单。内部检查默默执行，对外只说结论："Phase 1 完成"或"这里还需要补充 XX"
- **写文件时说明缘由**："我把策略规划写入 `slides-output/<name>/strategy.md`，后续阶段从这里恢复进展"
- **关键确认节点用提问**，不要把一堆 ✓✗ 清单丢给用户看
- **过程信息精简**：只说"在做什么"和"为什么"，不逐项展示检查过程
- **文件写入后简要告知**内容范围，不要粘贴完整文件内容给用户看
- **关键产物写完后，以 Markdown 链接格式提供可点击路径**：`[strategy.md](./slides-output/<name>/strategy.md)`。路径相对于用户工作目录，方便用户在 IDE 中直接点击打开。适用于：strategy.md、outline.md、speech.md、brand-spec.md、index.html（单文件）、export PPTX
- **如在 Elevo 环境中**，HTML 产物优先使用 `present_result` 展示预览入口：如果可用工具中存在 `present_result`，对 HTML 结果调用它，输出两个 `file` item：多文件站点入口使用 `display_mode: "preview"` + `presentation_mode: "site"` 走独立站点展示，单文件入口作为 `HTML 文件` 留在文件区里默认渲染页面预览。同时保留原有 Markdown 链接，方便用户复制或在非 Elevo 客户端中查看
- **在其他环境中**，以 Markdown 链接提供可点击路径即可

### 用户确认机制（全局兜底）

所有标记为"确认节点"的位置，在文件写完后**在同一个回复中**调用 `AskUserQuestion` 等待用户选择：

1. Write 写完文件后，在同一个回复中调用 `AskUserQuestion`
2. Question 含简短摘要（如 "strategy.md 已生成，核心信息为「XX」。是否继续？"）
3. Options 至少包含 `["确认继续"]` + `["需要修改"]`
4. **兜底**：如果 `AskUserQuestion` 不可用，输出确认摘要后立即结束当前回复，等用户回复后再决定下一步

核心原则：确认节点的目的是**让用户审阅并决定是否继续**，不是走个过场。

## 校验分层原则 + 能力克制

**主流程视觉验收只走程序静态分析，不调浏览器截图，不调 AI 看图。观感是主观判断，AI 看图不可靠且慢；程序静态分析又快又准，能覆盖客观问题（硬编码色、manifest 不一致、溢出阈值）。主观观感交给看产物的用户，是最可靠的判断来源。**

1. Phase 4 主流程的视觉校验 = `validate.mjs`（程序扫 CSS 规则、token 引用、manifest 一致性、内容溢出阈值）+ `post-process.mjs`（自动修复硬编码色等）。**不**在主流程调 `preview_slides.mjs` 截图、**不**用 AI 图像分析（analyze_image 之类）判断观感。
2. **实际观感（配色协调、留白、层次感、是否挤、是否丑）是用户的事**——用户拿到 `index.html` 自行打开查看，发现问题后反馈，skill 据此优化。skill 不预判主观视觉。
3. 浏览器/AI 视觉工具仅在 **用户主动要求**时作为可选出口（如用户说"看看效果"），**不进任何 Phase 的自动流程**。Phase 4.4 的 S 键演讲者视图也是用户主动触发。
4. CHAR_DENSITY 超 900 字符的页，validate 会输出"⚠️ 内容密集，建议交付后人工确认无溢出"——这是纯文本静态提示，零浏览器依赖，提示用户哪几页值得自己看一眼。

## 产出物

所有文件输出到用户当前工作目录下的 `slides-output/<演讲主题>/` 子目录（子目录名在 Phase 1.4 确定核心信息后创建，支持中英文命名）：

```
slides-output/<name>/
├── index.html                      # 单文件 HTML（默认展示入口，图片/CSS 内联）
├── strategy.md                     # 过程产物：策略与规划（Phase 1 产出，跨会话恢复用）
├── outline.md                      # 过程产物：演讲大纲（Phase 2 产出）
├── speech.md                       # 逐字稿（演讲者模式引用，也可独立阅读）
├── brand-spec.md                   # 设计资产清单
├── visual-config.json               # 视觉参数锁定（palette + typography + chrome 配置）
├── image-manifest.md               # AI 生图清单（由 /html-gen-images 命令产出，如有；非 SKILL 主流程阶段）
├── routing.md                      # Phase 4.2 路由表（全页骨架源/图表/内容映射/节奏摘要，本次生成决策留档）
└── export/                         # 多页版本 + PPTX 导出
    └── <name>-live/                # 多页版本（独立文件夹，可直接下载/迁移）
        ├── index.html              # 入口壳：DECK_MANIFEST + DECK_NOTES 数据
        ├── index-runtime.js        # 运行时：导航、缩放、演讲者模式、Notes、打印
        ├── slides/                 # 每页一个独立 HTML 文件
        │   ├── 01-cover.html
        │   └── ...
        ├── shared/
        │   ├── tokens.css          # 设计 token：色板、字体、间距、动画、通用组件
        │   └── theme.css           # （可选）选中的主题文件
        └── assets/                 # 品牌与产品图片
```

> **技术规格**（画布尺寸、缩放适配、键盘导航、演讲者模式、视频嵌入、字体加载、DECK_NOTES 写法、index/runtime 分离等）统一参考 `references/html-design-system.md`。

### 导出

根目录 `index.html` 是单文件 HTML（Phase 4.4 自动生成），可直接在浏览器打开演示。多页版本在 `export/<name>-live/`，是独立的可移植文件夹。

> **真相来源**：`export/<name>-live/` 是源，根目录 `index.html` 是导出产物。修改请改源文件（slides/*.html、shared/tokens.css），改完重新运行 `export_single.mjs` 更新单文件。

- **单文件 HTML**：Phase 4.4 Gate 通过后自动调用 `scripts/export_single.mjs` 生成到 `slides-output/<name>/index.html`
- **PPTX**：使用 `scripts/export_pptx.mjs`，`--slides` 指向 `export/<name>-live/slides`，详见 `references/html-design-system.md` §5
- **PDF**：使用 `scripts/export_pdf.mjs`，`--slides` 指向 `export/<name>-live/slides`，逐页截图合并为 PDF

> **依赖自动安装**：PPTX/PDF 导出与截图预览依赖 Node 模块（playwright / pptxgenjs / pdf-lib / sharp），而 plugin 分发包**不含 `node_modules`**（被 gitignore、不打进分发包）。**无需手动安装**——首次导出时 `scripts/_resolve.mjs` 会自动：① `npm install` 把 Node 模块装到用户缓存目录（`~/.cache/html-slide-gen`，可被环境变量 `HTML_SLIDE_GEN_NODE_CACHE` 覆盖）；② 下载 Playwright Chromium 浏览器——优先从国内镜像（`cdn.npmmirror.com/binaries/chrome-for-testing`，需 `curl`+`unzip`）手动下载，失败再回退 `playwright install`（官方源）。后续命中缓存秒过。这解决了「skill 目录只读、ESM bare import 不认 NODE_PATH/cwd」的环境问题，机制同姊妹 skill doc-convert。

### 文件写入约定

- **新建产出文件**（slides-output/ 下）统一使用 Bash heredoc。**关键：EOF 必须加引号禁用 shell 展开**——Markdown 中的反引号（`）、`$` 符号、换行等才不会触发 shell 解释或转义错误：

  ```bash
  cat > slides-output/<name>/strategy.md << 'ENDOFFILE'
  ...Markdown content（反引号、$、特殊字符均安全）...
  ENDOFFILE
  ```

- **修改已有文件**使用 Edit 工具
- **模板文件复制**使用 Bash `cp`（如 `cp templates/index-runtime.js slides-output/<name>/export/<name>-live/`）

## 前置动作：扫描上下文

**任何阶段开始前，先主动搜索当前工作目录**，寻找已有素材：

```
find . -type f -regex ".*\.\(md\|txt\|csv\|json\|html\|svg\|png\|jpe?g\|pdf\|docx\|pptx\|ya?ml\|xml\|webp\|hei[cf]\)"
```

### 按能力分类处理

| 能力 | 格式 | 处理方式 |
|------|------|---------|
| **可读取内容** | `.md` `.txt` `.csv` `.json` `.html` | 直接读取 |
| **可查看图片** | `.png` `.jpg` | 用视觉能力查看 |
| **可读取 PDF** | `.pdf` | 读取文本（大文件分页读） |
| **可读 SVG** | `.svg` | 直接读取 |
| **可提取文档内容** | `.pptx` `.docx` | 用 `scripts/import-file.sh` 转换后读取 |

### 扫描目标

- 产品文档、PRD、技术方案
- 已有的演讲稿 / 大纲 / 草稿
- **品牌资产**（logo、配色、字体规范、品牌手册）
- 产品截图、UI 设计稿、产品图片
- 数据文件、图表截图
- 竞品分析、市场报告
- 已有的 Keynote / PPTX 文件（记录路径）

将找到的素材整理成清单。**用户不需要主动提供——你去找。**

### 发现设计资产时：记录路径

扫描到 logo、品牌手册等，**记录资产原始路径**（供 Phase 4.1 复制到 `assets/`）。设计资产的**确认、复制和规范化**留到 Phase 4.1。

> Phase 4.1 会将所有引用的图片资产复制到 `slides-output/<name>/export/<name>-live/assets/`，brand-spec.md 只记录 `assets/` 下的相对路径。

> 如果扫描到已有项目的 `slides-output/` 目录，读取其中已有的 `brand-spec.md` 作为起点。

---

### 快速通道：完整脚本检测

当扫描到完整讲稿时，走快速通道，跳过 Phase 1-3 的逐步交互，合并为单次并行提取。

**触发判断**：
- 扫描到文件含分页标记（宽松格式 `^#{2,4}\s*(PPT|Slide|第|第.部分|页)\s*\d+`，覆盖 `### PPT-1：`、`## Slide 2:`、`## 第3页`、`## 第一部分`、`## 页1` 等变体）且标记数 ≥ 8，或文件总行数 > 50 且含"核心信息""受众""目标"等关键词
- 满足上述**即向用户轻量确认**是否走快速通道（而非 agent 自判边界）：
  > 检测到完整讲稿（N 页分页标记）。跳过规划直接出 slide？[是，直接出 / 否，我要先规划]
- 用户选"是"才走快速通道；选"否"走正常 Phase 1→2→3

**快速通道流程**（单轮完成）：
1. **并行读取**讲稿 + 3 份参考文件（`strategy-guide.md`、`storyline-guide.md`、`speech-writing-rules.md`）
2. **并行写入 `strategy.md` + `outline.md` + `speech.md`**：从讲稿中提取（不重写）——推断文稿类型/目标/受众 → strategy；提取分页大纲 → outline；讲稿全文 → speech
3. **完成后 用户确认**（展示三者的摘要 + Markdown 链接），确认后直接进入 Phase 4

**不触发快速通道**时，正常走 Phase 1→2→3 逐步交互流程。

---

## 确认篇幅

扫描完素材后、进入 Phase 1 前，确定演讲篇幅（默认推断，异议才停）：

| 时长 | 建议页数 | 适用场景 |
|------|---------|---------|
| 10-15 min | 8-12 页 | 快速分享、电梯演讲 |
| 20-30 min | 12-18 页 | 技术分享、产品介绍 |
| 45-60 min | 18-25 页 | 深度培训、方案宣讲 |
| 60-90 min | 20-30 页 | 工作坊、直播演示 |

- **有时长线索**：按时长查表给默认页数，告知用户"默认 N 页（X min），如需改请说明"，异议才停
- **快速通道场景**：用分页标记数直接作为页数，无需再确认
- **无任何时长线索**：默认 20min→15 页，告知用户后异议才停

Phase 2 逐页大纲数量受此约束。

> **画布尺寸**：默认 16:9 HD（1920×1080）。如用户需求指向非默认尺寸（手机竖版故事、朋友圈方形、旧款 4:3 投影等），参考 `references/size-presets.md` 匹配预设并与用户确认——尺寸在此时锁定，后续 Phase 4 的 tokens.css 与 index 壳需与之对齐。

---

## 全局工作规则

### 扫描优先 + 用户确认

后续所有步骤遵循统一模式：

1. **先从前置扫描结果提取**——如果素材已包含足够信息，提取后展示给用户确认（用户确认），确认后直接通过 Gate
2. **信息不足时**——按对应 `references/` 引导文件的方法补充

### 恢复逻辑

每个 Phase 开始前，检查对应产出文件（`slides-output/<name>/strategy.md`、`slides-output/<name>/outline.md`、`slides-output/<name>/speech.md`、`slides-output/<name>/export/<name>-live/slides/`）：

- **已存在且有内容**：读取文件，向用户展示已有结果并确认。从**第一个缺失或待确认的章节**继续
- **不存在**：从该 Phase 第一步开始

---

## Phase 1：策略与规划

> 不要急于产出任何文件。先在对话中帮用户把"为什么要做这份演示"想清楚。

> **Gate 语义说明（Phase 1-3 通用）**：本阶段及 Phase 2/3 的每个 **Gate 都是内部自检**——agent 对照 checklist 判 pass/fail，通过即继续下一步，**不打断用户、不等待用户回复**。对外硬阻塞的用户确认只有 3 处（确认篇幅、Phase 3 讲稿确认、Phase 4.1 设计方向确认），其余均自动推进。

### 1.1 确定文稿类型 / Presentation Type

信息不足时参考 `references/strategy-guide.md` §1.1，用四类文稿对照表 + 追问引导用户。

**Gate**：文稿类型已确定（四选一）+ 叙事模型已匹配 + 判断依据已写出。

### 1.2 明确演讲目标 / Objective

信息不足时参考 `references/strategy-guide.md` §1.2，用一句话目标公式 + From→To 转变模型引导。

**Gate**：一句话目标已套用公式（含明确行动动词）+ 颗粒度测试通过。

### 1.3 分析受众 / Audience Analysis

信息不足时参考 `references/strategy-guide.md` §1.3，用四维剖析 + 受众类型速查引导。

**Gate**：决策者具名/明确角色，3 个具体顾虑 + 利益切入角度（WIIFM）+ 认知水位已评估。

### 1.4 提炼核心信息 / Key Message

信息不足时参考 `references/strategy-guide.md` §1.4，用黄金交点 + 5 种提炼公式 + So What 追问引导。

**Gate**：核心信息 ≤30 字、无行业黑话，且通过出租车自测（能在 30 秒内向非专业人说清）+ 双向校验（核心信息 ↔ 目标/受众一致）。

**通过后创建输出目录并写入 strategy.md**：
1. 用核心信息（或用户确认的短标题）作为子目录名
2. 按 `references/output-conventions.md` 规则规范化目录名（trim、去特殊字符、长度限制、同名冲突递增等）
3. 创建 `slides-output/<name>/` 及子目录 `export/<name>-live/slides/`、`export/<name>-live/shared/`、`export/<name>-live/assets/`
4. 写入 `slides-output/<name>/strategy.md`——此时文件完整（Phase 1 全程只写一次）

> **strategy.md 章节标题必须是中英双语**（无论用户用什么语言提问）：
> `## 文稿类型 / Presentation Type`、`## 演讲目标 / Objective`、`## 受众分析 / Audience Analysis`、`## 核心信息 / Key Message`。
> 产出文件模板参考 `references/strategy-guide.md` 末尾附录。

---

## Phase 2：搭建骨架

### 2.1 素材整理

信息不足时参考 `references/storyline-guide.md` §2.1，用素材分类表引导补充。

**Gate**：素材池已列出（每条标注类别）+ 减法完成。

### 2.2 构建故事线

信息不足时参考 `references/storyline-guide.md` §2.2，用 SCQA 模型 + 文稿类型对应的主体结构引导。

**Gate**：SCQA 开场已明确 + 主体结构已选定并说明理由 + 收尾已规划（回扣核心信息 + 明确 CTA）。

### 2.3 编写演讲大纲

信息不足时参考 `references/storyline-guide.md` §2.3，按标题原则（结论先行、非名词短语）逐页编写。页数受篇幅约束。

**大纲描述密度控制**：每页大纲描述（标题 + 要点摘要）≤ 40 字。大纲阶段是确定信息密度的关键节点——如果大纲就写了 80 字，Phase 3 填充后必然超 200 字。需要拆页的场景在大纲阶段就拆，不要等到 Phase 3 才发现塞不下。

**容量前移（拆页决策在此做，不在 Phase 4.2）**：为每个将使用"固定 slot 布局"的页预估内容项数/行数，对照布局容量上限提前约束。超限的页**就地拆分**（一页拆两页，或降级到更大容量的布局），避免 Phase 4.2 容量预检才暴露、此时 speech 已写、回流成本 ~5-10min。

> **固定 slot 布局上限的权威源**：`scripts/check-spec-capacity.mjs` 的 `LAYOUT_BUDGETS` 常量。大纲阶段对计划用固定 slot 布局（L06/L08/L11/L12/L17/L18/L22/L23/L31）的页，数清 item/row 数与上限比较即可。查看完整上限表运行：`node scripts/check-spec-capacity.mjs --list-budgets`。L07/L13/L15/L21 等无硬 slot 上限的布局不受此约束（但仍受全局"每页 ≤ 40 字描述"密度控制）。L19 路线图按结构约定固定 4 列（脚本无此 budget）。
>
> **自动容量预检（Phase 2.3 跑 `--outline`）**：outline 写完后跑 `node scripts/check-spec-capacity.mjs --outline slides-output/<name>/outline.md`，吃 outline 的 `[visual:]` + `[card-bg:N]` 标签自动对照上限，超限页报 `NEEDS_SPLIT`。⚠️ 脚本只认 `VISUAL_TO_LAYOUT` 的 11 类 visual + 需 `[card-bg:N]` 标签，cover/section-divider/**arch-infographic** 等页型被静默 skip——这些页型在 Phase 4.2 路由表「容量标注」列补一行人工容量标注（详见 `references/phase4-workflow.md` §4.2 容量预检段）。

**视觉标注规则**：每页大纲标题后必须标注视觉需求。**先读轻量索引 `references/visual-content-index.md`（~120 行）决定每页生什么图**，需要完整标注规范再查 `references/visual-content-guide.md` §5.1。格式：

- **页面级标注**（每页一个）：`[visual: <type>]`。如 `[visual: cover]`、`[visual: arch-infographic]`、`[visual: none]`
- **元素级标注**（零或多个）：`[card-bg: N]`、`[decor: position]`、`[section-bg]`
- **节奏标注**：每页 `[weight: light|medium|heavy]`，紧跟 `[visual:]` 之后
- **全局强调色**：outline.md 开头声明 `[accent: <CSS颜色值>]`

标注示例：`P03 消费级设备有三大硬伤 [visual: comparison] [card-bg: 3] [weight: medium]`

**Gate**：大纲精确到每一页标题 + 每页标题是结论句 + 便利贴校验通过 + 每页都能支撑核心信息 + **固定 slot 布局的页内容量未超上限**（L06/L08/L11/L12/L17/L18/L19/L22/L23，见上表）。**通过后写入 `slides-output/<name>/outline.md`**——此时文件完整（Phase 2 全程只写一次）。

> 产出文件模板参考 `references/storyline-guide.md` 末尾附录。

---

## Phase 3：内容填充

### 3.1 逐页填充

信息不足时参考 `references/speech-writing-rules.md` 第一部分（正面质量标准 + 写作手法）。

**内容规范**：
- 每页一个核心观点
- 逐字稿是对着活人说的话，不是产品说明书
- 逐字稿是"提示信号"，不是幻灯片文字的朗读版——包含过渡句、解释、数据口述等幻灯片上不会出现的细节

**逐字稿锚点格式**（必须遵守）：

```markdown
### PPT-1：封面标题
[逐字稿正文]

### PPT-2：章节标题
[逐字稿正文]
```

**逐字稿篇幅参考**：一般参考标准每页 150-300 字。少于 150 字提示不够容易卡壳，多于 300 字来不及扫完。但注意短促有力的开场/收尾页可能约 50 字，复杂的数据解读页约 400 字。

**内容-演讲协调模式**：幻灯片放什么、逐字稿说什么，由每页的角色决定，而非互相约束。以下是常见模式：

| 模式 | 幻灯片 | 逐字稿 | 典型场景 |
|------|--------|--------|---------|
| 图表解读型 | 信息密集（对比矩阵、数据表、流程图） | 简短，引导视线+点睛 | 竞品分析、能力对比、技术架构 |
| 故事驱动型 | 极简（一个词、一张图、一句金句） | 长段，讲故事/描绘场景 | 开场、收尾、转折、情感共鸣 |
| 要点支撑型 | 中等（3-5 个要点标题+简要描述） | 中等，逐条展开补充细节 | 方案介绍、进度汇报 |
| 数据冲击型 | 一个大数字+核心指标 | 中等，解读数字背后的含义 | 核心数据页、增长亮点 |

同一份演示文稿中通常会混用多种模式。判断标准：这一页的核心目的是让观众**自己读**还是**听你说**？

**Gate**：每页逐字稿已填充、符合 `### PPT-N：标题` 锚点格式，且每页单一核心观点（讲稿是提示信号，非照念全文）。

### 3.2 去AI味

参考 `references/speech-writing-rules.md` 第二部分，逐项检查。

**Gate**：逐字稿对照 `references/speech-writing-rules.md` 第二部分通过——无机械衔接词/空话套话/模糊修饰词（"大幅/显著"等已替换为具体数字）/AI 典型模式（过度排比、四字成语堆砌、标志性衔接词）。

### 3.3 质量校验

**骨架回溯**：对每一页执行便利贴校验——不能支撑核心信息的，无论多精彩，删除或移到附录。

**正面校验**：参考 `references/speech-writing-rules.md` 第一部分，检查是否具备 >=4 个质量维度（引用、场景、态度、第一人称、故事、逻辑）。

**清晰度校验**：禁止为了"简洁"而丢失关键信息。

**Gate**：便利贴校验通过（每页支撑核心信息）+ 正面质量 ≥4 维度（引用/场景/态度/第一人称/故事/逻辑）+ 口语化清晰无歧义。**通过后更新 `slides-output/<name>/speech.md`**——此时文件完整。

> 产出文件模板参考 `references/speech-writing-rules.md` 末尾附录。

### 用户确认

speech.md 完成后，**走用户确认流程**（参见"交互风格指南 → 用户确认机制"）：

- 告知用户"讲稿共 N 页 M 字"，以 Markdown 链接提供 [speech.md](./slides-output/<name>/speech.md) 路径
- 在同一个回复中调用 `AskUserQuestion`：
  - Question: "讲稿是否满意？"
  - Options: `["确认，继续下一步"]` + `["需要修改"]`

**用户确认前，禁止推进 Phase 4。**

---

## Phase 4：视觉设计与交付

> ⚠️ **进场必读**：进入 Phase 4 前必须**立即完整 Read** [`references/phase4-workflow.md`](./references/phase4-workflow.md)。本节只保留 Phase 4 的**骨架 + 每步 Gate + 强约束指针**；所有 step 级操作细节（Step A-D、4.2 选型/图表/动画/批量许可、4.3 生成策略、4.3.1-4.3.4 校验流程、4.4 导出）都在该文件。**漏读会丢 Gate、漏一票否决项、产出坏 deck。** Phase 1-3 不需要读该文件。

> **架构原则**：Clone & Adapt + 风格模板与颜色方案分离。T1=复制模板 slide HTML 替换 `data-replace`；T2=layout-catalog 通用骨架 + Style Transfer。标注语法见 `references/annotation-spec.md`，模板约定见 `references/template-tech-facts.md`。

### 4.1 品牌资产与设计方向（合并为一次确认）

- **Step A**：从 strategy.md + outline.md 匹配风格模板（slides-gallery.md 矩阵）+ 颜色方案（color-schemes.json mood）。颜色方案支持两种来源：A) 40 个预置方案按 mood 匹配；B) 参考文件提取（用户提供 .pptx 或截图，调用 `scripts/extract-colors.mjs` 生成自定义色板）。选项 B 的完整操作流程见 `references/phase4-workflow.md` Step A 选项 B 部分（E1–E4）。
- **Step B**：**单次 AskUserQuestion 确认设计方向**（Phase 4 唯一视觉偏好硬阻塞；继承已有 brand-spec.md 时异议才停）。**用户确认前禁止继续。**
- **Step C**：生成 brand-spec.md + tokens.css（cp deck tokens + switch-theme）+ 复制资产 + 加载 slide-roles.md / style-preset
- **Step D**：样张确认（默认可选，已合并进 Step B 视觉门）

> **Gate**：设计方向已确定 + brand-spec.md 已生成 + tokens.css 已生成 + 资产已复制到 `export/<name>-live/assets/` + 路径均为 assets/ 相对 + 无 slide 引用 assets 外部路径。

### 4.2 逐页骨架路由（T1 直生，不写 spec）

- **第零步**：按 slide-roles.md 角色匹配决策树分配 T1/T2（含冲击页识别、图表选型写路由表 `chart` 列），一次性对所有页算完
- **产出物 = 路由表**（`routing.md`，覆盖全部页：骨架源/chart/emph/容量标注 + T2 Style Transfer delta + 内容映射）；T1 不写 spec，仅 T2 派 subagent 时把对应行转成 brief
- **批量产出许可**：路由表是单文件各页无依赖，允许 1-2 turn heredoc 批量写出，节奏检查并入路由表末尾
- **T2 骨架源优先**：有预置锚点（t2-skeletons.md#template-layout）必须用，无预置才回退 layout-catalog Lxx @ offset
- **容量预检已前移 Phase 2.3**（吃 `--outline`，见上）；arch-infographic 等脚本 skip 的页型在路由表「容量标注」列人工补洞

> **Gate**：路由表覆盖全部页 + 每页骨架来源明确 + T2 Style Transfer delta 与 slide-roles.md 逐项对齐 + 节奏检查通过 + 容量预检已在 Phase 2.3 通过（`--outline` 无 NEEDS_SPLIT；skip 页型已人工补注）。

### 4.3 生成 HTML 初稿

- **生成顺序**：先派 T2 subagent（background）→ 主 agent 同时逐页生成 T1 → join T2 产出（总耗时 ≈ max(T1, T2)）
- **T1**：按路由表 cp 模板 → 替换 data-replace textContent（保留 `<span>`/`<b>` 包装，子标签无 class）→ 注入 `<aside class="notes">` → 保留 `data-skeleton="t1"` + `tpl-<deck>` + `.anim-*`
- **T1 残留词检查**：替换 data-replace 后，grep 搜索生成的 HTML 文件中是否残留模板原行业词（如模板是汽车行业，需搜索"NEV"、"乘用车"、"渗透率"等），若发现残留则替换为当前主题对应词汇
- **T2**：调度 subagent，**启动读 `references/subagent-brief.md` 一份**（+ 主 agent 给的路由表行/内容映射），按需局部读骨架一次
- **T1/T2 都不写 CSS、不发明 class、不建自定义组件**
- **`index.html` 必须从 `templates/index-shell.html` 复制；`index-runtime.js` 必须从 `templates/index-runtime.js` 原样复制为独立文件（一票否决）。NEVER 用 starter-deck 自带 index.html。**
- **4.3.1-4.3.4**：步骤 0 验 T2 产出 → 0.5 post-process（含 validate strict）→ 一致性审查 → 4.3.2 仅手动改过才重跑 → 4.3.3 `--check runtime` → 4.3.4 `--check visual` + grep 抽查 → export_single.mjs

> **Gate**：所有 HTML 已生成 + index.html/index-runtime.js 来源正确（runtime 独立文件，一票否决）+ slide 数量在篇幅范围内 + slides 引用 tokens.css + notes 已嵌入 + post-process 0 ERROR + `--check runtime` 通过 + 一致性审查通过 + `--check visual` 通过 + grep 抽查通过。通过后自动生成单文件 HTML。

### 4.4 用户确认与导出

- 输出入口链接（单文件 + Elevo present_result / print_preview_url）→ S 键演讲者视图逐页检查 → 据反馈迭代（改多页后重跑 export_single.mjs）→ 用户确认后导出 PPTX（editable 默认 / image 降级）/ PDF

> **PPTX editable 降级**：editable 失败 → validate-pptx.mjs 查报错 → 修复最多 2 轮 → 仍失败改用 `--mode image`。


## 交付前总检

以下为各 Phase Gate 未覆盖的跨维度最终核对：

- **篇幅校验**：slide 总数是否在"确认篇幅"阶段约定的页数范围内。不足则提示用户补充或合并，超出则精简
- **跨页一致性**：品牌色、字体、间距在所有 slides 中统一
- **视觉质量**：gradient 装饰、L 等级达标。4.3.4 已跑 `--check visual`，此处不再重复调 validate（刚跑过），纯人工按审美判断
- **技术完整性**：`index.html` 必须从 `templates/index-shell.html` 复制（非 starter-deck 自带版本）+ `index-runtime.js` 必须从 `templates/index-runtime.js` 原样复制为独立文件（不可内联到 index.html）+ `DECK_NOTES` 反引号定界 + 键盘导航 + 深链接 + S 键演讲者模式正常。**强制验证**：`validate.mjs --check runtime` 必须通过（4.3.3 已跑；此处可选验证以防被误删）
- **PPTX 导出**：V2 引擎自动适配，无需特殊 HTML 规则。导出前可选运行 `validate-pptx.mjs` 确认无内容溢出

## 参考资料

| 文件 | 内容 |
|------|------|
| `references/phase4-workflow.md` | **Phase 4 完整流程细节**（进场必读）：4.1 Step A-D、4.2 选型/图表/动画/批量许可、4.3 生成策略、4.3.1-4.3.4 校验流程、4.4 导出。SKILL.md 只保留骨架+Gate，细节全在此 |
| `references/annotation-spec.md` | `data-replace` / `data-replace-style` 标注语法 + slide-roles.md 格式（新增/重标模板时读） |
| `references/spec-format.md` | T1/T2 规格文件格式模板（仅复杂 T2 页需独立留档时参考；主流程用路由表，不产 spec） |
| `references/subagent-brief.md` | **Subagent 启动必读（唯一一份）**：合并的 T1/T2 操作步骤 + trap rules + 骨架速查 + 数据页图表要点 + 空间策略速查。手维护产物 |
| `references/template-tech-facts.md` | 模板文件约定：1920×1080 画布、slide HTML 无 `<style>`、body flex 居中、SVG 坐标规则、暗/亮页变体 |
| `references/output-conventions.md` | 产出物目录命名规范 |
| `references/strategy-guide.md` | Phase 1 引导手册 + strategy.md 模板 |
| `references/storyline-guide.md` | Phase 2 引导手册 + outline.md 模板 |
| `references/visual-content-index.md` | Phase 2 视觉标注速查（~120 行，优先加载，决定每页生什么图） |
| `references/visual-content-guide.md` | AI 生图完整指南（构造 Prompt 时局部读，勿整文件加载） |
| `references/speech-writing-rules.md` | 逐字稿编写规范 + 去 AI 味规则 + speech.md 模板 |
| `references/html-design-system.md` | 设计 token、视觉丰富度等级(L1-L3)、CRAP 原则、图表组件、图标、导出方法 |
| `references/motion-system.md` | 动效规范（唯一真相源）：纯 CSS class 驱动、内容语义→动画映射、stagger 配方、4 档模板分级 |
| `references/layout-catalog.md` | 32 种 slide 布局完整 CSS/HTML 骨架（T2 fallback，默认匹配池 12 种优先） |
| `references/layout-catalog-index.md` | 布局索引轻量版 |
| `references/t2-skeletons.md` | T2 预置骨架（已合并 Style Transfer）：有锚点时直接复制，免拼装。当前 6 个：pitch-deck×{L19,L21}、tech-sharing×{L21,L17}、weekly-report×{L11,L18} |
| `references/style-presets.md` | 23 套模板风格预设索引（密度速查表 + 跨页节奏模板）；完整 8 维度按 `## <deck>` 锚点局部读 `style-presets-details.md` |
| `references/editable-pptx.md` | PPTX hybrid v2 导出说明 |
| `references/brand-spec-guide.md` | 品牌资产获取流程 + brand-spec 模板 |
| `references/slides-gallery.md` | 23 个模板索引（匹配表+规则，~280 行）；选定后按 `### <deck>` 锚点局部读 `slides-gallery-details.md` 取详情——含 slide-roles.md 引用 |
| `references/subagent-rules.md` | Subagent 规则的**完整版深度参考**（subagent 启动读 `subagent-brief.md` 速查，需要展开看重点页强调 / 复合骨架 / Anti_Patterns / 空间利用率时按段局部读本文件）：T1/T2 操作规则 + trap rules + 自检清单 |
| `references/style-transfer-guide.md` | Style Transfer 通用指南（6 维度检查清单）——Phase 4.2 T2 页面继承模板视觉语言时先读此文件了解通用流程，再从各模板 `slide-roles.md` 读取模板特定参数 |
| `references/size-presets.md` | 画布尺寸预设库（16:9 / 4:3 / 1:1 / 9:16）——非默认尺寸时按此匹配 |
| `templates/starter-decks/<name>/slide-roles.md` | 每个模板的角色目录——Phase 4.2 骨架首选来源 |
| `templates/charts/` | 30 种图表组件模板（纯 CSS + 内联 SVG，全 token 着色）。机器选型读 `charts-index.json`，人工浏览读 `README.md` |
| `templates/assets/icons/` | 129 个 SVG 图标 |
| `scripts/validate.mjs` | 产物校验 |
| `scripts/validate-pptx.mjs` | PPTX 预检 |
| `scripts/post-process.mjs` | 一站式后处理 |
| `scripts/export_single.mjs` | 单文件 HTML 导出 |
| `scripts/export_pptx.mjs` | PPTX 导出 |
| `scripts/switch-theme.mjs` | 一键换色方案 |
| `scripts/color-schemes.json` | 40 个颜色方案预设 |

## 参考文件依赖关系

> **按 Phase 加载**：Phase 4 才需要的文件在 Phase 1-3 不要预读——避免 token 浪费和缓存压力。

```
SKILL.md（流程编排，始终在上下文）
 ├─ Phase 1 按需：strategy-guide.md, output-conventions.md
 ├─ Phase 2 按需：storyline-guide.md, visual-content-index.md（速查优先）/ visual-content-guide.md（构造 Prompt 时局部读）
 ├─ Phase 3 按需：speech-writing-rules.md
 ├─ 确认篇幅：size-presets.md（非默认尺寸时）
 └─ Phase 4（以下文件仅在此阶段加载）
    ├─ phase4-workflow.md（⚠️ 进场必读：Phase 4 全部 step 级细节都在此文件，SKILL.md 只留骨架+Gate）
    ├─ slides-gallery.md（4.1 读索引+匹配表；选定 deck 后局部读 slides-gallery-details.md#<deck> 取详情）
    ├─ slide-roles.md（4.1 读，角色目录 + Adapt + Style Transfer）
    ├─ style-presets.md（4.1 读密度速查表+节奏模板；选定后局部读 style-presets-details.md#<deck> 取 8 维度）
    ├─ brand-spec-guide.md（4.1 读，品牌资产）
    ├─ color-schemes.json（4.1 读，颜色方案）
    ├─ annotation-spec.md / template-tech-facts.md（4.1/4.2 按需，标注语法 + 模板约定）
    ├─ style-transfer-guide.md（4.2 T2 页 Style Transfer 通用流程）
    ├─ motion-system.md（4.2 动画注入规则 + 模板档位）
    ├─ layout-catalog-index.md（4.2 仅路由表缺 offset 时查 offset 列；正常路由表已带 offset）
    ├─ layout-catalog.md（4.2 T2 回退：按路由表的 offset 局部读对应 Lxx 段）
    ├─ t2-skeletons.md（4.2 T2 首选：有预置锚点时直接复制，免拼装）
    ├─ subagent-brief.md（4.3 subagent 启动读，唯一一份）
    ├─ subagent-rules.md（规则完整版深度参考，brief 按段局部展开）
    └─ html-design-system.md（4.3 技术规格参考 + 导出方法）
```

> 生图命令 `/html-gen-images`（独立 slash command，不在 SKILL.md 主流程）使用内置 `scripts/generate-image.mjs`（pagecraft 可选回退）。图表组件模板在 `templates/charts/`，SVG 图标在 `templates/assets/icons/`——直接复制使用，不需预读。