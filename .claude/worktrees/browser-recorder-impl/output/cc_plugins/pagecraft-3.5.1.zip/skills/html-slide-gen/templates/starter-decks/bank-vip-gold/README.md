# bank-vip-gold · 金融 VIP 财富汇报

16-slide private-wealth advisory deck: cover, agenda, client overview (pyramid), market diagnosis (situation/complication/question), chapter divider, 2×2 asset-allocation matrix, product recommendation, performance deep dive, benchmark table, 3-stage investment plan, quarterly RAG review, risk disclosure, 90-day next steps, thank-you.

Restrained luxury palette — CMB Red (`#c41230`) + Gold accent (`#c9a962`) + Deep Red (`#9a0e26`) on white, fine double-line detailing, concentric rings, dot-grid texture, diamond dividers, corner safe-zone markers, opinion bars, warm-grey/blush cards, generous white space, conclusion-first.

**Use when:** private-bank client reviews, VIP wealth-management reports, family-office asset-allocation proposals, annual wealth briefings, high-net-worth client servicing.
**Feel:** a private-bank annual readout — prestigious, data-driven, every page a takeaway, white-glove restraint.

---

## 配色

默认 `cmb-gold-red`（招行红 + 辅助金）。已接入 `switch-theme.mjs`，可一键切换：

```bash
node scripts/switch-theme.mjs --deck templates/starter-decks/bank-vip-gold --scheme consulting-navy  # 深蓝投行风
node scripts/switch-theme.mjs --deck templates/starter-decks/bank-vip-gold --scheme government-red    # 政务红金
```

配套方案见 `scripts/color-schemes.json`（40 个预设）。

## 结构

16 页叙事弧 = **客户全景 → 资产配置 → 市场展望 → 产品推荐 → 财富规划**：

| 段落 | 页 | 角色 |
|------|-----|------|
| 开篇 | 01-03 | cover（精致轻奢封面）· agenda · executive-summary（客户全景综述） |
| 客户画像 | 04 | situation（**KYC 画像 + 资产配置环形图** · 金融身份证） |
| 市场诊断 | 05-06 | complication（市场挑战）· question（财富主线 MECE 分解） |
| 章节切换 | 07 | chapter-divider（深红全屏） |
| 配置方案 | 08-12 | framework（**核心-卫星配置图**）· recommendation（**产品货架**）· data-deepdive（**净值曲线**）· comparison-table · process-flow（投资路径） |
| 治理 | 13-15 | quarterly-review（RAG 业绩复盘）· risks-mitigation（风险等级×收益矩阵 + 应对）· next-steps（90 天规划） |
| 收束 | 16 | thanks（顾问团队 + 预约 + 合规 · 呼应封面） |

完整角色目录与替换键见 [`slide-roles.md`](slide-roles.md)。

## 差异化（spec `docs/deck-differentiation-spec.md` §6）

本 deck 为**真领域财富管理 deck**，非 consultant 换皮。标志版式（金融身份证）：
- **04 客户画像**：KYC 多维标签 + CSS conic-gradient 资产配置环形图（取代通用 stat 卡）
- **08 资产配置框架**：核心-卫星同心三层圆（取代 2×2 矩阵）
- **09 产品推荐**：分层产品货架 + 主推金标（取代方案 A/B/C 择优卡）
- **10 业绩深潜**：净值/收益曲线 SVG（组合 vs 当前 vs 通胀基准）
- **封面/致谢**：双线·圆环·菱形·顾问卡·尊享标识·私密等级 / 顾问团队卡·预约方式·私行服务·合规提示——元素集与其他 deck 完全不重叠

独有组件 ≥14 个（`bank-kyc`/`bank-alloc`/`bank-coresat`/`bank-nav-curve`/`bank-shelf`/`bank-risk-matrix`/`bank-doubleline`/`bank-rings`/`bank-diamond`/`bank-title-box`/`bank-vip-badge`/`bank-advisor`/`bank-team-card`/`bank-booking`…）。

## 用法

复制本目录到产出目录后修改 `slides/*.html` 中的 `data-replace="key"` 内容。示例填充为「某银行 VIP 客户年度财富管理汇报 / 私人银行资产配置建议书」（通用金融 VIP 场景，不绑定具体客户，替换键示意最清晰）。

```bash
# 预览
open index.html
# 截图所有页
node scripts/preview_slides.mjs --slides slides --out /tmp/preview
# 导出单文件 HTML
node scripts/export_single.mjs --deck . --out ../bank-vip-gold.html
# 导出 PPTX
node scripts/export_pptx.mjs --slides slides --out ../bank-vip-gold.pptx --mode editable
```

## 设计依据

参考 pagecraft-2.0.0 `layouts/招商银行/design_spec.md`（极简轻奢配色、精致双线、多层同心圆、微点阵、菱形分割、四角定位点、观点条等装饰语言）经 HTML 多文件 iframe 架构重做。详见 `docs/starter-decks-expansion-plan.md`。
