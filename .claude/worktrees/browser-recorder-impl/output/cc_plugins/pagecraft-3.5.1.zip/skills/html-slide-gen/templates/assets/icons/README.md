# SVG Icon Library — 129 Icons

精选自 640+ 图标库的 129 个高频 SVG 图标，按分类整理。

## 使用方式

```html
<!-- 方式1: img 引用（推荐） -->
<img src="../assets/icons/chart-bar.svg" class="icon-md" alt="">

<!-- 方式2: 内联 SVG（可 CSS 控制颜色） -->
<svg class="icon-md" viewBox="0 0 24 24" fill="var(--accent)">
  <use href="../assets/icons/chart-bar.svg#icon"/>
</svg>
```

## 图标尺寸工具类

tokens.css 已预置：`.icon-sm`(20) `.icon-md`(32) `.icon-lg`(48) `.icon-xl`(72) `.icon-2xl`(96)

## 图标分类索引

### 数据/图表 (Data & Charts)
| 文件 | 用途 |
|------|------|
| chart-bar.svg | 柱状图、数据对比 |
| chart-line.svg | 折线图、趋势分析 |
| chart-pie.svg | 饼图、占比 |
| arrow-trend-up.svg | 增长趋势 |
| arrow-trend-down.svg | 下降趋势 |
| target.svg / target-arrow.svg | 目标、KPI |
| signal.svg / gauge-high.svg | 指标、仪表 |
| percent.svg | 百分比、折扣 |
| database.svg | 数据库、存储 |
| radar.svg | 雷达图、多维 |

### 用户/组织 (Users & Organization)
| 文件 | 用途 |
|------|------|
| user.svg / users.svg | 用户、团队 |
| building.svg | 公司、建筑 |
| group.svg | 团队、社群 |
| globe.svg | 全球化、国际 |
| crown.svg | 高级、VIP |
| badge.svg / badge-check.svg | 认证、资质 |
| group.svg | 合作、团队、协议 |
| person.svg | 个人、角色 |

### 时间/日程 (Time & Schedule)
| 文件 | 用途 |
|------|------|
| clock.svg | 时间、时效 |
| calendar.svg | 日期、排期 |
| stopwatch.svg | 计时、效率 |
| hourglass-empty.svg | 倒计时、紧迫 |
| alarm-clock.svg | 提醒、DDL |

### 商务/金融 (Business & Finance)
| 文件 | 用途 |
|------|------|
| dollar.svg / yen.svg / euro.svg / british-pound.svg | 货币、金额 |
| wallet.svg | 钱包、支付 |
| shopping-cart.svg | 购物车、电商 |
| receipt.svg | 账单、凭证 |
| credit-card.svg | 信用卡、支付 |
| money.svg / coin.svg | 资金、融资 |
| gem.svg | 价值、精华 |
| tag.svg | 标签、分类 |

### 技术/开发 (Technology & Development)
| 文件 | 用途 |
|------|------|
| code.svg / terminal.svg | 代码、终端 |
| server.svg / cloud.svg | 服务器、云端 |
| database.svg | 数据库 |
| shield-check.svg | 安全、验证 |
| lock-closed.svg / lock-open.svg | 加密、权限 |
| cog.svg | 设置、配置 |
| microchip.svg | 芯片、硬件 |
| bug.svg | 调试、Bug |
| robot.svg | AI、自动化 |
| git-branch.svg / git-commit.svg / git-merge.svg | 版本控制 |
| key.svg | 密钥、关键 |
| keyboard.svg / laptop.svg / desktop.svg / mobile.svg | 设备 |
| wifi.svg / plug.svg | 网络、连接 |

### 文件/文档 (Files & Documents)
| 文件 | 用途 |
|------|------|
| file.svg / files.svg | 文件 |
| folder.svg / folders.svg | 文件夹 |
| clipboard.svg | 剪贴板、清单 |
| copy.svg | 复制、模板 |
| paperclip.svg | 附件 |
| bookmark.svg | 书签、收藏 |
| book.svg / book-open.svg | 书籍、文档 |
| newspaper.svg | 新闻、资讯 |
| sticky-note.svg | 便签、备注 |

### 状态/反馈 (Status & Feedback)
| 文件 | 用途 |
|------|------|
| circle-checkmark.svg | 成功、通过 ✓ |
| circle-x.svg | 错误、失败 ✗ |
| triangle-exclamation.svg | 警告 ⚠ |
| circle-info.svg | 信息 ℹ |
| circle-question.svg | 帮助、疑问 |
| circle-plus.svg / circle-minus.svg | 展开/收起 |
| circle-play.svg / circle-pause.svg / circle-stop.svg | 播放控制 |
| star.svg | 评分、收藏 |
| heart.svg | 喜欢、健康 |
| thumbs-up.svg / thumbs-down.svg | 好评/差评 |
| bell.svg | 通知 |
| badge-check.svg | 认证通过 |

### 通用动作 (General Actions)
| 文件 | 用途 |
|------|------|
| magnifying-glass.svg | 搜索、查找 |
| pencil.svg | 编辑、修改 |
| trash.svg | 删除、清理 |
| plus.svg / minus.svg | 添加/移除 |
| arrow-right.svg / arrow-left.svg / arrow-up.svg / arrow-down.svg | 方向/导航 |
| link.svg | 链接 |
| share-nodes.svg | 分享 |
| rocket.svg | 启动、加速 |
| lightbulb.svg | 想法、洞察 |
| wrench.svg | 工具、修复 |
| sliders.svg | 调整、参数 |
| filter.svg | 筛选 |

### 媒体/通信 (Media & Communication)
| 文件 | 用途 |
|------|------|
| play.svg / pause.svg | 播放/暂停 |
| camera.svg | 拍照、截图 |
| image.svg / images.svg | 图片、相册 |
| envelope.svg | 邮件 |
| phone.svg | 电话 |
| bell.svg | 消息、通知、聊天 |
| video-camera.svg | 视频、录制 |
| headphones.svg | 音频、客服 |
| microphone.svg | 语音、录音 |

### 学术/研究 (Academic & Research)
| 文件 | 用途 |
|------|------|
| mortarboard.svg | 教育、毕业 |
| glasses.svg | 研究、洞察、深入 |
| trophy.svg | 成就、奖项 |
| glasses.svg | 洞察、阅读 |

## 原则

1. **优先使用图标库** — 避免 emoji 作为主要视觉元素
2. **商用/正式场合** — 禁止 emoji 图标，必须使用 SVG 图标
3. **颜色通过 token 控制** — 使用 `fill="var(--accent)"` 而非硬编码颜色
