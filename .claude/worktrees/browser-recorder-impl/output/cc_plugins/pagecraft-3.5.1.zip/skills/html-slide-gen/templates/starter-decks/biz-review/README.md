# biz-review — 季度/年度业务复盘 Deck

> **体裁**：业务复盘（quarterly/annual business review, QBR, 经营汇报）
> **受众**：高管 / 经营委员会
> **调性**：严肃可扫描、商务稳重
> **默认配色**：`ocean-depths`（深海蓝 #0a2540 + 亮蓝 #1d4ed8，白底）
> **页数**：14 页

## 叙事骨架（直线递进，非 SCQA）

周期回顾 → 核心成果 → KPI 总览 → 亮点展开 → 差距分析 → 挑战与风险 → 下阶段计划 → 资源需求

```
01 cover              业务复盘封面（周期+业务线+汇报对象+成绩单）
02 agenda             议程（6 节点直线递进脊柱）
03 period-recap       周期回顾（6 项目标 scorecard）
04 core-results       核心成果（大数字 + 增长结构三信号）
05 kpi-wall           KPI 总览墙（8 KPI · 当期/环比/同比/达标/sparkline）★
06 highlight-expand   亮点展开（1 hero + 支撑 + 归因拆解）★
07 metric-deepdive    数据深潜（月度趋势 SVG + 读图三要点）
08 gap-analysis       差距分析（目标·实际·根因·行动账本）★
09 challenges-risks   挑战与风险（战略挑战 + 风险登记表）
10 next-roadmap       Q3 路线图（4 阶段 · 当前高亮）
11 key-initiatives    重点举措（4 项 · 首项 hero）
12 resource-ask       资源需求（人力/预算/优先级/回报 + ROI）★
13 decisions          决议事项（3 项二选一 · 含推荐）
14 thanks             决议与审批清单（行动决议 + 资源审批 · 非人员卡）★
```
★ = 本 deck 特色页 / 承载 `br-*` 标志组件

## 文件结构（多文件 iframe）

```
biz-review/
├── index.html              入口壳（canonical shell + DECK_MANIFEST 14 项）
├── index-runtime.js        运行时（templates/index-runtime.js AS-IS 复制）
├── README.md               本文件
├── slide-roles.md          角色目录 + 组件层 + 适配规则
├── shared/
│   └── tokens.css          手写设计 token（motion :root + 主 :root ocean-depths + 通用层 + .tpl-biz-review overlay）
└── slides/                 14 页独立 HTML，均 <link> ../shared/tokens.css
```

## 标志组件（`br-*`，区别于现有 deck）

- `.kpi-wall` — KPI 总览墙（8 格 × 五要素：当期值/环比/同比/达标状态/sparkline）
- `.highlight-expand` — 亮点展开（单一 hero + 数据支撑 + 归因拆解条）
- `.gap-analysis` — 差距分析账本（目标·实际·根因·行动 4 列闭环）
- `.resource-ask` — 资源需求表（人力/预算/优先级/预期回报 + 汇总 + ROI）
- `.br-scorecard` — 周期目标达成 scorecard
- `.br-roadmap` — Q3 路线图（layout-catalog L19 无缝网格）
- `.br-decision` / `.br-approval` — 决议事项 + 审批清单（致谢页主体）
- `.br-spark` / `.br-trend` — token 着色 inline SVG（sparkline + 月度趋势）

## 差异化（vs 现有 deck）

| | weekly-report | consultant-strategy | **biz-review** |
|---|---|---|---|
| 叙事 | 团队周同步 | SCQA 诊断+方案择优 | **直线递进 回顾→规划** |
| 容量 | 7 页细粒度 | 16 页咨询 | **14 页高管级** |
| 状态语言 | ▲▼ delta chip | RAG 点 | **达标/未达标/超额 badge** |
| 数据强调 | 左 4.5px 色条 | amber | **亮蓝 + sparkline** |
| 致谢页 | 周报收尾 | 4 联系人卡 | **决议+资源审批清单** |
| 配色 | (各 scheme) | mckinsey 蓝绿 | **ocean-depths 深海蓝** |

## switch-theme

已接入。改 `shared/tokens.css` 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 即换肤：

```bash
node scripts/switch-theme.mjs --deck biz-review --scheme consulting-navy
```

## 样例场景

某 SaaS 协同办公产品线 Q2 复盘 + Q3 规划：ARR 超额、中型客群突破，但 NRR 与 KA 新签未达标——复盘回顾成果、定位差距、提出增购攻坚与产能扩张、向管理层申请资源与决议。
