# 模板标注规格 — `data-replace` 语法与 slide-roles 格式

> 本文档定义 T1（Clone & Adapt）模板的可替换内容标注语法。仅当**新增/重新标注模板**时需要读；日常生成（subagent 按 spec 替换占位符）由 `subagent-rules.md` + 各模板 `slide-roles.md` 覆盖，无需读本文件。

## 一、`data-replace` 标注语法

在模板 slide HTML 源文件中，用 `data-replace` 属性标记每个可替换的内容区域。

### 标注规则

| 规则 | 说明 |
|------|------|
| **标注粒度** | 标注到最小的可替换单元。标题、正文各自独立 key，不要整张卡片笼统标一个 key |
| **保留原件内容** | data-replace 标注后原件文字**不删除**——它作为 AI 的内容密度参考和视觉预览 |
| **不标注结构性元素** | `<div class="card">` 本身、`.grid` 容器、`.section-num` 的 span 标签等结构元素**不标**——它们是 composition 的一部分 |
| **属性放在文字元素上** | data-replace 放在包含文字的元素上（`<h2>` `<p>` `<span>`），不是父容器 |
| **嵌套规则** | 卡片内 h4 和 p 各自可替换则各自标 key；标题+正文整体替换（如引用块）则标在父元素 |
| **key 命名** | `snake_case` 语义化（如 `card_1_title`、`hero_headline`、`bar_3_label`），同角色内唯一 |
| **不影响渲染** | data-replace 是纯标注属性，不影响浏览器渲染，模板仍可直接预览 |

### 示例

```html
<!-- 标注后 -->
<span class="section-num" data-replace="section_num">01</span>
<h2 class="h2" data-replace="section_title">Solo founders duct-tape<br>7+ tools to stay alive.</h2>
<div class="card">
  <h4 data-replace="card_1_title">Fragmentation</h4>
  <p class="dim" data-replace="card_1_body">Stripe, QuickBooks... Nothing talks.</p>
</div>
```

### 特殊场景

**A. 内容有多行 `<br>` 拆行**：标在整体 `<h2>` 上，AI 负责判断是否保留 `<br>`。

**B. 列表项**：每个 `<li>` 独立标注（`list_item_1` / `list_item_2`…），保留 `<ul>` 结构不动。

**C. 图表数据**：标签和数值各自独立标注，高度等动态计算的 CSS 用 `data-replace-style`：

```html
<div class="bar" style="height:18%" data-replace-style="bar_1_height">
  <em data-replace="bar_1_value">$6k</em>
  <span data-replace="bar_1_label">Oct</span>
</div>
```

> `data-replace-style` 用于标注需动态计算的 CSS 属性（柱状图高度、进度条宽度），AI 按内容数据计算后替换。

**永不标注**：SVG 坐标属性（`x` `y` `width` `d`…）、装饰层（`.cover-blob` `.ambient-glow`）、`body` class。

## 二、slide-roles.md 格式（速查）

文件位置：`templates/starter-decks/<name>/slide-roles.md`，Phase 4.1 加载。每个模板都有一份实例，新模板照此结构写。必需小节：模板气质 / 默认 color-scheme / 适用文稿类型 / 叙事结构 / 角色索引表 / 角色详情 / 角色匹配决策树 / Style Transfer 规则。

### 角色 ID 命名规范

```
cover                        — 封面
toc                          — 目录/议程
content-section-{N}card      — 章节分隔 + N 卡片（N=2,3,4）
content-section-chart         — 章节分隔 + 图表
content-section-timeline      — 章节分隔 + 时间线
content-section-metrics       — 章节分隔 + KPI 指标
content-bigquote              — 大引用/金句
content-code                  — 代码展示
content-comparison            — 对比（双列/表格）
thanks                        — 感谢/结束
cta                           — 行动号召/Ask
qna                           — Q&A
content-custom-<desc>         — 逃生舱（无匹配角色时）
```

### 关键设计原则

1. **slide-roles.md 不重复 HTML**。HTML 骨架唯一来源是模板 slide 文件本身（带 data-replace）；slide-roles.md 只做索引和适配规则。
2. **可替换键 vs 不可改动**：明确区分内容（可改）与 composition（不可改），防止破坏模板视觉 DNA。
3. **正文容量指导值**：基于模板原件实际内容密度给出，帮助判断是否拆行。
4. **卡片扩展/收缩规则**：约定用户卡片数 ≠ 模板卡片数时如何处理。

---

## 三、`[composite:]` 复合骨架标注（outline 标注）

> 单页 page-body 由**两类异类组件组合**承载时（如「能力卡矩阵 + 闭环流程图」「KPI 条 + 明细表」），用 `[composite:]` 标注，驱动主 agent 选用「复合 page-body」骨架（见 `layout-catalog.md` §九、复合 page-body 骨架）。

### 语法

| 标注 | 组合 | page-body 内必须含的 class |
|------|------|------|
| `[composite: cards+flow]` | 上半卡片网格 + 下半流程管道 | `.card`（或 `.point`）**且** `.flow`（`.node`） |
| `[composite: list+flow]` | 左栏要点列表 + 右栏流程图 | `.point` **且** `.flow` |
| `[composite: kpi+table]` | 顶部 KPI 条 + 底部明细表 | `.kpi`（`.kpi-grid`）**且** `.table` / `.cs-table` / `.info-bar` |

### 标注规则

1. **位置**：写 outline.md 页头行（与 `[comp:]` 同位置），如 `### P05 [composite: cards+flow]`。
2. **一页一个**：`[composite:]` 不叠加——一页最多一个 composite 标注，不 `cards+flow+kpi` 三类混用（容量爆炸 + 视觉混乱）。
3. **与 `[comp:]` 互斥**：一页要么 `[comp: x]`（单类组件），要么 `[composite: x+y]`（组合骨架），不并存。
4. **DOM 校验语义**：校验器（`validate.mjs` comp-annotation）检测同 page-body 内是否同时含两类组件对应 class——缺任一报 `COMP_COMPOSITE_MISSING`。

### 示例

```markdown
### P05 [composite: cards+flow]
上半：三大监控能力卡（统一监控 / 拓扑大屏 / 告警智能处理）
下半：闭环流程图（监控发现 → 告警分级 → 自动处理 → ITSM 管控 → 自动化执行）
```

### 复合骨架组合白名单（subagent 执行）

`[composite:]` 标注由主 agent 在路由表写，subagent 见到即按白名单组合执行——**组合内 class 全部来自 tokens.css 已有 class，不发明新 class**（与「禁发明 class」规则一致）。3 种合法组合见 `layout-catalog.md` §九。
