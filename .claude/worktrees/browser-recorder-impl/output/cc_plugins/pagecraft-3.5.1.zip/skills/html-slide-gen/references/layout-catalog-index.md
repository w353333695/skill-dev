# 布局索引 — 32 种 Slide 布局速查

> 轻量版，供 subagent 快速匹配布局编号。完整 CSS/HTML 骨架见 `references/layout-catalog.md`。

> **局部读取规则（H1 减负）**：表中 `offset` 列是 `layout-catalog.md` 里该布局 `### Lxx` 详情块的起始行号——32 个布局**全部**有独立 `### Lxx` 块，故 32 个 offset 全有值。命中布局后**按 offset 局部读取**（如 `Read layout-catalog.md offset=410 limit=44` 读 L21），**严禁整文件加载 741 行**。limit 按需估（多数布局块 20-50 行，到下一个 `###` 为止）。

## 一、结构型页面（5 个）

| 编号 | 名称 | 视觉等级 | 容量（结构约束） | 一句话描述 | offset |
|------|------|---------|------|-----------|--------|
| L01 | 封面 (cover) | L3 | 居中列 | 垂直居中列，全屏封面 | 50 |
| L02 | 目录 (toc) | L1 | `.grid.g2` 双列 | 双列卡片网格，最后一项可全宽 | 68 |
| L03 | 章节分隔 (section-divider) | L2 | 限宽 780px | 居中列，限宽 780px | 86 |
| L04 | 结束页 (thanks) | L3 | 居中列 | `.center.tc` 居中列 | 102 |
| L05 | 行动号召 (cta) | L2 | 限宽 900px | 居中列 + 双按钮，限宽 900px | 117 |

## 二、文本型页面（5 个）

| 编号 | 名称 | 视觉等级 | 容量（结构约束） | 一句话描述 | offset |
|------|------|---------|------|-----------|--------|
| L06 | 要点列表 (bullets) | L1 | 垂直堆叠 | 垂直 `.card.card-accent` 堆叠 | 140 |
| L07 | 双栏 (two-column) | L1 | `.grid.g2` 双列 | 双卡片并排 | 161 |
| L08 | 三栏 (three-column) | L1 | `.grid.g3` 三列（不可变） | 三卡片并排，不可加第 4 卡 | 177 |
| L09 | 大引用 (big-quote) | L1 | 限宽 1040px | 居中 serif 大引文 | 195 |
| L10 | 数据亮点 (stat-highlight) | L2 | 居中 1 数字 | 居中超大数字冲击，渐变背景 | 210 |

## 三、数据型页面（6 个）

| 编号 | 名称 | 视觉等级 | 容量（结构约束） | 一句话描述 | offset |
|------|------|---------|------|-----------|--------|
| L11 | KPI 网格 (kpi-grid) | L1 | `.grid.g4` 四列（不可变） | 四列指标卡，推荐用 `templates/charts/kpi-cards.html` | 229 |
| L12 | 表格 (table) | L1 | 全宽表格 | 卡片内全宽表格，数值列右对齐 | 253 |
| L13 | 柱状图 (chart-bar) | L1 | 4-6 柱 | Chart.js / 推荐用 `templates/charts/bar-chart.html` | 272 |
| L14 | 折线图 (chart-line) | L1 | 2-3 线 | 推荐用 `templates/charts/line-chart.html`（svg-inline）/ Chart.js | 290 |
| L15 | 饼图 (chart-pie) | L1 | 5 段 | 左环形图+右洞察 / 推荐用 `templates/charts/donut-chart.html` | 299 |
| L16 | 雷达图 (chart-radar) | L1 | 2-3 组 | 推荐用 `templates/charts/radar-chart.html`（svg-inline）/ Chart.js | 315 |

## 四、图表型页面（7 个）

| 编号 | 名称 | 视觉等级 | 容量（结构约束） | 一句话描述 | offset |
|------|------|---------|------|-----------|--------|
| L17 | 流程图 (flow-diagram) | L1 | 水平 flex 管线 | 水平 flex 管线 / 推荐用 `templates/charts/process-flow.html` | 326 |
| L18 | 时间线 (timeline) | L1 | 水平 5 列 | 5 列水平时间线 / 推荐用 `templates/charts/timeline.html` | 350 |
| L19 | 路线图 (roadmap) | L1 | 4 列 grid（不可变） | 4 列无缝网格，当前阶段高亮 | 371 |
| L20 | 思维导图 (mindmap) | L1 | 绝对定位 | 绝对定位节点 + SVG 连接线 | 392 |
| L21 | 架构图 (arch-diagram) | L1 | 多行分层网格 | 多行分层网格 | 410 |
| L22 | 步骤图 (process-steps) | L1 | 4 列 grid（不可变） | 4 列步骤卡，圆形数字徽章 | 454 |
| L23 | 甘特图 (gantt) | L1 | 13 列 grid | 13 列网格 + 绝对定位条形 | 474 |

## 五、对比与媒体型（4 个）

| 编号 | 名称 | 视觉等级 | 容量（结构约束） | 一句话描述 | offset |
|------|------|---------|------|-----------|--------|
| L24 | 对比 (comparison) | L1 | 2-3 列 grid | 3 列网格 / 推荐用 `templates/charts/comparison-table.html` | 495 |
| L25 | 优劣势 (pros-cons) | L1 | `.grid.g2` 双列 | 双列绿/红色编码 / 推荐用 `templates/charts/matrix-2x2.html` | 513 |
| L26 | 大图展示 (image-hero) | L2 | 1 图 | 全幅卡片内分层渐变 + Ken Burns | 534 |
| L27 | 图片网格 (image-grid) | L1 | Bento 网格 | Bento 网格 4 列 × 180px 行 | 555 |

## 六、代码/开发型（3 个）

| 编号 | 名称 | 视觉等级 | 容量（结构约束） | 一句话描述 | offset |
|------|------|---------|------|-----------|--------|
| L28 | 代码 (code) | L1 | 1 文件 | highlight.js 语法高亮代码块 | 575 |
| L29 | Diff | L1 | 1 diff | Git 风格 diff 显示（绿增/红删） | 596 |
| L30 | 终端 (terminal) | L1 | 1 终端 | 终端模拟器美学，薄荷绿光标 | 623 |

## 七、工具型（2 个）

| 编号 | 名称 | 视觉等级 | 容量（结构约束） | 一句话描述 | offset |
|------|------|---------|------|-----------|--------|
| L31 | 待办清单 (todo-checklist) | L1 | 垂直清单 | 垂直清单，自定义复选框 | 653 |
| L32 | 次级信息条 (secondary-info-bar) | L1 | 底部横排 | 底部横排信息条（团队/工具链等） | 681 |

## 八、复合 page-body（3 个 · 003 主线三 F）

> 单页承载两类异类组件（卡+流程 / 列表+流程 / KPI+明细）。outline 标 `[composite: x+y]` 驱动，offset 指向 `layout-catalog.md` §九。复合骨架 = 现有 class 组合，不发明新 class。一页一个 composite，不叠加。

| 编号 | 名称 | 视觉等级 | 容量（结构约束） | 一句话描述 | offset |
|------|------|---------|------|-----------|--------|
| composite-cards-flow | 卡片+流程 | L2 | 3 卡 + 3-5 节点 | 上半卡片网格 + 下半流程管道 | 723 |
| composite-list-flow | 列表+流程 | L2 | 3-5 point + 3-5 节点 | 左栏要点列表 + 右栏流程图 | 743 |
| composite-kpi-table | KPI+明细 | L2 | 4 KPI + 4-6 行表 | 顶部 KPI 条 + 底部明细表 | 763 |

## 布局选择速查

| 内容类型 | 推荐布局 |
|---------|---------|
| 核心结论/数字 | L10 stat-highlight 或 L09 big-quote |
| 并列要点 | L06 bullets 或 L08 three-column |
| 数据对比 | L12 table、L13 chart-bar、L24 comparison |
| 流程/步骤 | L17 flow-diagram、L22 process-steps、L18 timeline |
| 系统架构 | L21 arch-diagram、L20 mindmap |
| 规划/排期 | L19 roadmap、L23 gantt |
| 产品截图 | L26 image-hero、L27 image-grid |
| 代码展示 | L28 code、L29 diff、L30 terminal |
| 优劣势分析 | L25 pros-cons |
| 检查清单 | L31 todo-checklist |
| 仪表盘指标 | L11 kpi-grid |
| 占比分布 | L15 chart-pie |
| 趋势变化 | L14 chart-line |
| 团队/工具补充 | L32 secondary-info-bar |

---

## 数据可视化决策 / Data-to-Chart Mapping

> **原则：有结构化数据（数字、类别、时间、占比）→ 图表优先，表格兜底。**

| 数据类型 | 首选图表/布局 | 备选 | 判断信号 |
|---------|-------------|------|---------|
| 3-4 个关键指标 | L11 KPI 网格 | L10 数据亮点 | 有 "%"、"万"、"增长率"、"同比" |
| 类别对比（≤6 项） | L13 柱状图 | L12 表格 | 有 "A vs B vs C"、并列对比 |
| 占比构成（≤5 段） | L15 环形图 | L12 表格 | 有 "占比"、"构成"、"XX% 来自" |
| 时间趋势（≥4 点） | L14 折线图 | L13 柱状图 | 有 "Q1-Q4"、"逐年"、"趋势" |
| 流程步骤（≤5 节点） | L17 流程图 | L22 步骤图 | 有 "流程"、"步骤"、"先后" |
| 里程碑时间线（≤5 点） | L18 时间线 | L12 表格 | 有 "里程碑"、"历程"、"时间节点" |
| 计划排期（≤8 任务） | L23 甘特图 | L19 路线图 | 有 "排期"、"甘特"、"月份" |
| 优劣势对比 | L25 优劣势 | L24 对比 | 有 "优势"、"劣势"、"利/弊" |
| 架构/层级结构 | L21 架构图 | 文本列表 | 有 "层"、"模块"、"架构" |
| 转化漏斗 | 漏斗图组件 | L12 表格 | 有 "转化"、"逐级"、"漏斗" |
| 多维评分 | 评分卡组件 | L12 表格 | 有 "评分"、"维度"、"权重" |
| 2×2 矩阵定位 | 矩阵组件 | L12 表格 | 有 "象限"、"矩阵"、"X/Y 轴" |

### 反模式速查

| 反模式 | 应改为 |
|--------|-------|
| ≥3 个数值用列表或文字描述 | KPI 网格（L11）或大数字（L10） |
| "A 占 30%, B 占 45%, C 占 25%" 用纯文字 | 饼图 / 环形图（L15） |
| 长标签排名（品牌/区域 5-12 项） | 水平条形排名图（`horizontal-bar-chart.html`） |
| 多系列同比/环比对比 | 分组柱状图（`grouped-bar-chart.html`） |
| 收入/份额逐年构成 | 堆叠柱状图（`stacked-bar-chart.html`） |
| 利润/预算增减分解 | 瀑布图（`waterfall-chart.html`） |
| KPI 完成率单值达成 | 仪表盘（`gauge-chart.html`） |
| 战略优劣机威分析 | SWOT（`swot-analysis.html`） |
| 行业竞争结构分析 | 波特五力（`porter-five-forces.html`） |
| 6 个月实施计划用 9 行表格 | 甘特图（L23） |
| 5 个流程步骤用卡片列表 | 流程图（L17）或步骤图（L22） |
| 环境数据（服务器/虚拟机/设备数）用表格 | KPI 网格（L11） |
| 能力卡 + 闭环流程硬塞进单卡网格 | 复合骨架 composite-cards-flow |
| 复合骨架三类混用（cards+flow+kpi） | 一页一个 composite，不叠加（容量爆炸+视觉混乱） |

> 所有图表组件的 CSS 类已在 `templates/shared/tokens.css` 预置，HTML 模板在 `templates/charts/` 目录。
> **机器选型**优先读 `templates/charts/charts-index.json`（含 `render`/`pptxFriendly`/`keywords`），人工浏览读 `templates/charts/README.md`。
> 本决策表在 Phase 4.2 规划布局时使用，subagent 生成时应遵守"图表优先"原则。

---

> **完整 CSS/HTML 骨架**见 `references/layout-catalog.md`。
> **图表组件**优先使用 `templates/charts/` 预置模板，而非从零构建。
> **容量标注"（不可变）"** = grid 列数/槽位数是 HTML 布局结构的物理限制，不可增减。其他布局的容量由实际内容量动态决定——用 `scripts/check-spec-capacity.mjs` 的 `LAYOUT_BUDGETS` 做容量预检判断填充率，而非硬编码项数上限。
> **容量预检**：Phase 4.2 规格生成后用 `scripts/check-spec-capacity.mjs` 运行自动化检查。
