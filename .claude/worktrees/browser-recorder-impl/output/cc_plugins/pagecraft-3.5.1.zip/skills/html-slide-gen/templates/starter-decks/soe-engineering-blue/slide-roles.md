# soe-engineering-blue — Slide Role Catalog

> **模板气质**：央企国企工程汇报风（中国电建_现代调性）—— 深蓝科技渐变底 + 精密经纬网格 + 金色高光、科技卡片（微弱发光边框）、四角瞄准框、stroke-only 巨型轮廓字章节号。深底白字、数据驱动、稳重克制、突出大国重器与技术创新。
> **默认 color-scheme**：`powerchina-modern`（电建蓝 `#00418d` + 光辉金 `#ffd700`，深海蓝底 `#001f45`，中国红 `#C41E3A` 点睛）。**这是深色 deck**。
> **switch-theme**：已接入。`shared/tokens.css` §2 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 为换肤入口；所有 `soe-*` 组件与语义 token 均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 一键切换。适合切换为 `government-blue`（政务蓝）、`consulting-navy`（深蓝投行风）等。
> **适用文稿类型**：汇报 / 总结（央企国企重大工程项目建设汇报、央企年度工作汇报、科技创新成果汇报、重大基础设施可研与进展汇报）。
> **叙事结构（16 页，按出现顺序）**：cover → toc → executive-summary → situation → complication → question → chapter-divider → framework → recommendation → data-deepdive → comparison-table → process-flow → quarterly-review → risks-mitigation → next-steps → thanks。
>
> 01–03 为「开篇」（封面·基石概念 + 目录·里程碑 + 项目综述/金字塔顶）；04–06 为「概况与挑战」（项目概况+参数表 + 建设挑战 + 技术主线 MECE 分解）；07 为「章节切换」（stroke-only 巨型轮廓字）；08–12 为「技术方案与进度」（技术路线图 + 关键技术科技卡片 + 数据深潜 + 工程对标 + **甘特图**）；13–15 为「管控治理」（**四控制仪表盘** + 风险管控 + 下一步部署）；16 为「收束」（致谢建设者 + 工程全景图 + 参建联合署名）。
>
> **特色角色页**：01（基石概念·居中封面）/ 07（stroke-only 巨型轮廓字）/ 08（技术路线图，取代 2×2 矩阵）/ 09（科技卡片 glowing）/ 12（**甘特图**，取代通用时间轴）/ 13（**四控制仪表盘**，取代 RAG 季度卡）/ 16（**工程成果全景**，取代人员卡片网格）。
>
> **叙事骨架**（工程项目汇报体裁，非 SCQA，spec §5.1）：项目概况 → 技术方案 → 建设进度 → 质量安全 → 效益分析。**差异化**（docs/deck-differentiation-spec.md）：深色 deck + 甘特图/四控制/技术路线图/科技卡片四大标志版式，去掉 consultant 的 2×2 矩阵/通用时间轴/RAG 季度卡；封面（基石概念·居中）与致谢（工程全景图+参建联合署名，spec §3.5.2 反套路）元素集与政府/金融/学术完全不重叠。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 封面（基石概念·居中）：经纬网格底 + 居中项目全称 + 工程剪影 SVG（塔吊/大坝/桥梁）+ 参数角标 + 参建单位三联 + 开工日期 | `.bar-top`, `.soe-corner-mark`(×4), `.h1`(含 `.gradient-text`), 工程剪影 SVG, 参数角标条, `.soe-cover-meta` 参建三联 |
| 02 | `toc` | 目录：工程里程碑横向时间轴（5 节点）+ 6 章节双栏列表 | `.soe-pagehead`, `.soe-milestone-rail`(`.soe-ms-dot`), `.h3.mono`(编号), `.h4`, `border-bottom` 分隔 |
| 03 | `executive-summary` | 项目综述（金字塔顶）：一句话核心结论 + 3 工程亮点卡 | `.card.card-gold`(结论条), `.grid.g3`, `.card-accent`, `.pill-accent`, `.h3.mono`(指标) |
| 04 | `situation` | 项目概况：4 列工程数据卡（投资/工期/装机/发电量） + 工程参数表 + 工程定位条 | `.grid.g4`, `.soe-fact`, `.soe-param-table`(8 格工程技术参数), `.card-soft`(定位) |
| 05 | `complication` | 建设挑战：3 难点卡（地质/技术/工期）+ 中国红强调影响 | `.grid.g3`, `.card-gold`, `.pill-red`, `.h2.mono`(影响, 红色) |
| 06 | `question` | 技术主线：MECE 树状分解（1 root → 3 leaf） | `.soe-tree-node.root`/`.leaf`, inline SVG 三叉连接线 |
| 07 | `chapter-divider` | 章节切换（特色页）：深蓝渐变 + 右侧 stroke-only 巨型轮廓字章节号 | `.soe-chapter-stroke`(420px stroke-only), `.h1`(96px 白) |
| 08 | `framework` | 技术路线图（5 阶段流程，取代 2×2 矩阵） + 关键产出三块 | `.soe-roadmap`(`.soe-rm-node.done/cur`), `.soe-rm-stage` 圆形阶段节点, `.soe-glass` 产出卡 |
| 09 | `recommendation` | 关键技术：4 科技卡片（深底 glowing，金核心/蓝领先/红攻关） + 创新价值条 | `.grid.g2`, `.soe-tech-card.hero/.attack`(发光边框), `.soe-tc-icon` SVG, `.soe-tc-metric-row`, `.card-soft`(价值) |
| 10 | `data-deepdive` | 工程数据深潜：左大数字 + 同类工程对比 bar + 右 3 主要部位拆解卡 | `.card-accent`, `.h1.mono`(大数字), 内联 bar, `.card-gold`(拆解) |
| 11 | `comparison-table` | 工程对标表：6 维度硬边表，本项目列金色高亮 | `.soe-table`(硬边, 表头蓝底白字, `.col-hero` 金色列), `caption` |
| 12 | `process-flow` | 施工进度甘特图（标志版式，取代通用时间轴） + 关键里程碑 | `.soe-gantt`(CSS grid, 行=工序, 列=月份, `.soe-g-bar.plan/.actual/.lag` 双色条), `.soe-gantt-legend`, `.soe-milestone.done/.cur/.plan` |
| 13 | `quarterly-review` | 四控制仪表盘（特色页，取代 RAG 季度卡）：安全/质量/进度/投资 四宫格 + 状态灯 + KPI + 仪表条 + 关注项 | `.soe-fourcontrol`, `.soe-fc-light`(good/warn/bad 发光状态灯), `.soe-fc-icon` SVG, `.soe-fc-kpi`, `.soe-fc-gauge`, `.card-soft`(关注项) |
| 14 | `risks-mitigation` | 风险管控：3 风险卡（安全/质量/进度），每卡风险/应对双栏对照 | `.card`(风险行), `.soe-risk`(`.soe-risk-risk`/`.soe-risk-mit`), 风险等级 pill(红/金) |
| 15 | `next-steps` | 下一步部署：4-step pipeline（投产/验收/移交/运维） + 决议清单 | `.soe-pipeline`, `.soe-step.hero`, `.soe-step-num`/`.title`/`.body`/`.owner`, `.pill-gold`(决议) |
| 16 | `thanks` | 致谢（工程成果收束·spec §3.5.2）：深蓝底「致谢全体建设者」+ 项目全景图（大坝/水库/厂房/输电线+形象进度）+ 参建方联合署名横条（建设/设计/监理/施工）+ 角落项目编号 | `.soe-corner-mark`(×4), `.h1`(80px), `.soe-glass`(全景图框), 项目全景 SVG(1040×300), 参建署名横条, 项目编号 |

---

## 角色详情

### 01 — `cover`（基石概念·居中，spec §3.5.1）
- **源文件**：`slides/01-cover.html`
- **可替换键**：`project_code`, `client_label`, `headline`, `headline_accent`, `subtitle`, `kpi_1~3_value/label`, `owner_build`, `owner_design`, `owner_supervise`, `owner_startdate`, `footer_source`
- **不可改动**：`.bar-top` 8px 深蓝渐变条、`.soe-corner-mark` 四角瞄准框、**居中布局**（justify-content:center）、`.h1` 字号/字重、工程剪影 SVG 几何（塔吊+拱坝+桥梁）、参数角标三联结构、参建单位三联（建设/设计/监理 + 开工日期）
- **内容适配规则**：
  - 元素集与政府/金融/学术封面完全不重叠：经纬网格底 · 工程剪影 · 参建三联 · 参数角标
  - `headline` 居中含一个 `<span class="gradient-text">` accent 词，替换时保留 span
  - 参建单位固定 4 项（建设/设计/监理 + 开工日期），增减时同步调整 `border-right` 分隔

### 02 — `toc`
- **可替换键**：`kicker`, `title`, `ms_1~5`(里程碑标签), `item_1~6_num/title/desc`, `footer_source`
- **不可改动**：`.soe-milestone-rail` 横向时间轴（5 个 `.soe-ms-dot`，第 3 个 `.gold` 高亮）、`.grid.g2` 双栏、每项 `border-bottom` 分隔线、编号用 `.h3.mono`
- **内容适配规则**：章节项 4~6 个，增删 `.row` 元素，标题控制在 12 字内；里程碑节点位置随章节数调整 `left:%`

### 03 — `executive-summary`（金字塔顶）
- **可替换键**：`kicker`, `title`, `core_conclusion`(含 5 个内嵌 `<b>`/`<span>` 高亮), `pillars_label`, `pillar_1~3_tag/metric/title/body`, `footer_source`
- **不可改动**：`.card.card-gold` 结论条字号(30px)、3 亮点卡等宽(`.grid.g3`)、指标用 `.h3.mono` 金色
- **内容适配规则**：
  - `core_conclusion` 是整 deck 的"金字塔顶"，必须一句话含核心定位 + 量化目标
  - 内嵌高亮词用 `<span style="color:var(--accent-3)">` 或 `<b>`，替换时保留标记
  - 亮点固定 3 个（对应后续 04-06 概况挑战 + 08-12 技术方案）

### 04 — `situation`
- **可替换键**：`kicker`, `title`, `subtitle`, `stat_1~4_value/label/delta`, `pt_1~8_k/v/u`(工程参数 8 格), `insight_tag`, `insight_body`, `footer_source`
- **不可改动**：4 列等宽(`.grid.g4`)、`.soe-num` 88px Bold、delta 用 `.soe-delta.up`(绿)、`.soe-param-table` 8 格参数表（工程身份证）
- **内容适配规则**：4 个数据卡 + 8 格工程技术参数表（坝高/库容/水头/隧洞长/混凝土/开挖量/服务年限），`stat_*_value` 控制在 6 字内，delta 含方向箭头

### 05 — `complication`
- **可替换键**：`kicker`, `title`, `prob_1~3_tag/impact/title/body/evidence`, `footer_source`
- **不可改动**：3 列 `.card-gold`、影响数字用 `.h2.mono` 中国红(`var(--bad)`)、tag 用 `.pill-red`
- **内容适配规则**：3 个难点卡（地质/技术/工期），`prob_*_impact` 是量化影响（红），`evidence` 是脚注证据

### 06 — `question`（MECE 分解）
- **可替换键**：`kicker`, `title`, `subtitle`, `root_question`, `leaf_1~3_tag/title/body`, `footer_source`
- **不可改动**：`.soe-tree-node.root` 电建蓝底白字、inline SVG 三叉连接线坐标、3 leaf 等宽
- **内容适配规则**：1 root + 3 leaf（MECE 互斥穷尽），leaf 的 body 用"→ 技术"格式回链方向

### 07 — `chapter-divider`（特色页 · stroke-only 轮廓字）
- **可替换键**：`chapter_num`, `chapter_bignum`, `chapter_title`, `chapter_sub`, `footer_source`
- **不可改动**：全屏深蓝渐变背景、`.soe-chapter-stroke` 420px stroke-only 巨型轮廓字（右侧绝对定位 right:40px）、`.h1` 96px 白字、金色分隔条
- **内容适配规则**：用于切换到"技术方案"大章节，`chapter_bignum` 是巨型轮廓字内容（如"03"），`chapter_title` **不写 `<br>`**（CJK 换行交 CSS）

### 08 — `framework`（技术路线图，取代 2×2 矩阵，spec §5.1）
- **可替换键**：`kicker`, `title`, `subtitle`, `rm_1~5_name/desc/meta`(5 阶段), `out_1~3_tag/title/body`(关键产出), `footer_source`
- **不可改动**：`.soe-roadmap` 5 列横向流程（`.soe-rm-stage` 圆形阶段节点 + `::after` 连接线）、节点状态 done/cur/默认、`.soe-glass` 产出卡左色边（绿/金/红）
- **内容适配规则**：5 阶段串行攻关（勘测→设计→主体→机组→调试），done=已完成(绿)、cur=进行中(金实心)、默认=计划(金描边)；右下三块关键产出按已完成/攻关中/卡脖子着色

### 09 — `recommendation`（关键技术·科技卡片，spec §5.2）
- **可替换键**：`kicker`, `title`, `tech_1~4_tag/title/body/k1~3/k1~3_label`, `reason_tag`, `reason_body`, `footer_source`
- **不可改动**：核心突破卡用 `.soe-tech-card.hero`（金发光 + 金描边图标）；攻关方向卡用 `.soe-tech-card.attack`（红发光）；其余 `.soe-tech-card`（蓝发光）；每卡 `.soe-tc-icon` SVG + 3 项 `.soe-tc-metric`
- **内容适配规则**：
  - 4 技术：1 核心突破(hero 金) + 2 行业领先(蓝) + 1 攻关方向(attack 红)
  - 若核心突破项变更，需把 `.hero` class 迁移到对应卡
  - `.soe-tc-metric .v.good` 强制绿色用于正向指标

### 10 — `data-deepdive`
- **可替换键**：`kicker`, `title`, `big_label`, `big_value`, `big_unit`, `bar_now/goal/top_label` + 对应值, `break_1~3_tag/impact/title/body`, `footer_source`
- **不可改动**：左 `.card-accent` 大数字(120px 金色) + 内联 3 行 bar、右 3 `.card-gold` 部位卡
- **内容适配规则**：bar 宽度需手动按值调整 `width:%`（当前 95/65/100 对应 38/26/40 万 m³/月）

### 11 — `comparison-table`
- **可替换键**：`kicker`, `title`, `col_dim/now/plan/top/gap`(5 列头), `row_1~6_dim/now/plan/top/gap`(6 行 ×5), `caption`, `footer_source`
- **不可改动**：`.soe-table` 硬边、表头蓝底白字、`.col-hero` 列金色高亮、gap 列绿/金着色
- **内容适配规则**：6 维度行，`col-hero` 默认指第 3 列（本项目），如改对比列需迁移 class

### 12 — `process-flow`（施工进度甘特图，标志版式，spec §5.2，取代通用时间轴）
- **可替换键**：`kicker`, `title`, `subtitle`, `g_head`, `g_m1~12`(12 月份头), `g_r1~6`(6 工序名) + `g_r*_plan/actual`(计划/实际条), `lg_plan/actual/lag`(图例), `ms_label`, `ms_1~3_date/name/prog/pct`(里程碑), `footer_source`
- **不可改动**：`.soe-gantt` CSS grid（190px 工序列 + 12 月份列）、`.soe-g-track` 每行双色条（`.soe-g-bar.plan` 蓝 + `.soe-g-bar.actual` 金；`.lag` 红滞后）、`left:%`/`width:%` 定位、`.soe-milestone.done/.cur/.plan` 左色边
- **内容适配规则**：
  - 甘特图条位置 = 工序起止月份占比（12 列，每列 ~8.33%）
  - `g_r*_actual` 条宽 = 实际形象进度%，与 `plan` 比对
  - 里程碑 `.soe-ms-pct` 与 done/cur 状态色同步（绿/金）

### 13 — `quarterly-review`（四控制仪表盘，特色页，spec §5.2，取代 RAG 季度卡）
- **可替换键**：`kicker`, `title`, `subtitle`, `fc1~4_name/tag/kpi/unit/status`(4 控制项 ×5), `action_tag`, `action_body`, `footer_source`
- **不可改动**：`.soe-fourcontrol` 2×2 玻璃宫格、`.soe-fc-light`(good/warn/bad 发光状态灯)、`.soe-fc-icon` SVG 图标、`.soe-fc-kpi`(大 KPI)、`.soe-fc-gauge`+`<i>` 仪表条颜色随状态(good/warn/bad)
- **内容适配规则**：
  - 四宫格固定：安全/质量/进度/投资（工程"四控制"标准）
  - `fc*_kpi` class 与 `.soe-fc-light` class + `.soe-fc-gauge>i` class 必须三者同状态（good/warn/bad）
  - `.soe-fc-gauge>i` width:% = 仪表填充比例

### 14 — `risks-mitigation`
- **可替换键**：`kicker`, `title`, `risk_1~3_level/title/prob/risk_head/risk_body/mit_head/mit_body`, `footer_source`（3 风险 ×7）
- **不可改动**：`.soe-risk` 双栏（左红 `.soe-risk-risk` / 右绿 `.soe-risk-mit`）、风险等级 pill 颜色(高=红/中=金)
- **内容适配规则**：3 风险卡（安全/质量/进度），每卡"风险描述 + 应对措施"对照，`prob` 格式"概率 X% · 影响 Y"

### 15 — `next-steps`
- **可替换键**：`kicker`, `title`, `subtitle`, `step_1~4_num/title/body/owner/due`, `decision_tag`, `decision_body`, `footer_source`（4 步 ×5）
- **不可改动**：`.soe-pipeline` 4 步等宽、`.soe-step.hero`（首步金顶边 + 金发光）、owner 用 `.soe-step-owner` 加粗
- **内容适配规则**：4 步部署（投产/验收/移交/运维），每步 owner(部门) + due(年月) + 可验证交付

### 16 — `thanks`（致谢·工程成果收束，spec §3.5.2 反套路）
- **可替换键**：`kicker`, `headline`, `subtitle`, `panorama_label`, `party_1~4_role/name`(参建署名横条), `contact_label`, `footer_code`, `contact_url`, `footer_confidential`, `footer_org`
- **不可改动**：**主体=项目全景图 SVG（1040×300，大坝/水库/厂房/输电线 + 形象进度条 56%）**（非人员卡片网格）、`.h1` 80px「致谢全体建设者」、参建方联合署名横条（建设/设计/监理/施工，横向一条 4 等分，非 4 卡网格）、角落项目编号（right:60px;bottom:74px）、`.soe-corner-mark` 四角瞄准框、深蓝经纬网格底
- **内容适配规则**：
  - 反套路：尾页主体是「工程成果/全景」，不是「人员名片网格」
  - 全景图 SVG 形象进度条位置/百分比（当前 56%）需与 12 甘特图、13 仪表盘数据一致
  - 参建方固定 4 个（建设/设计/监理/施工），横向署名，增删同步调整 `border-right` 分隔

---

## 组件层（`shared/tokens.css` `.tpl-soe-engineering-blue` overlay）

**基础组件**（页头/数据卡/管道/表/树/封面元数据）：

| class | 作用 |
|------|------|
| `.soe-pagehead` | 页头：kicker + h2.title |
| `.soe-corner-mark` (`.tl/.tr/.bl/.br`) | 四角瞄准框（spec §5.2，工程精密感，深色 deck 特色） |
| `.soe-fact` / `.soe-num` / `.soe-label` / `.soe-delta` | 大数字卡（值/标签/增减） |
| `.soe-pipeline` / `.soe-step` / `.soe-step.hero` | 4-step 部署管道 |
| `.soe-table` / `.col-hero` | 硬边对标表（本项目列高亮） |
| `.soe-risk` / `.soe-risk-risk` / `.soe-risk-mit` | 风险/应对双栏 |
| `.soe-tree-node.root` / `.leaf` | MECE 树节点 |
| `.soe-cover-meta` | 封面项目元数据 |
| `.bar-top` / `.bar-left` / `.card-gold` / `.card-accent` / `.pill-gold` / `.pill-red` | 装饰条 + 强调卡/pill |

**工程特色组件**（spec §5.2 独有，真领域版式，非 consultant 换皮）：

| class | 作用 | 用于页 |
|------|------|------|
| `.soe-grid-bg` | 可复用经纬网格背景块（opacity .07） | 装饰底纹 |
| `.soe-glass` | 深底玻璃面（rgba(255,255,255,.05) + blur） | 08/16 等 |
| `.soe-tech-card` / `.hero` / `.attack` | 科技卡片（深底 glowing 边框 + SVG 图标 + 指标行） | 09 关键技术 |
| `.soe-gantt` / `.soe-g-bar.plan/.actual/.lag` | 施工进度甘特图（CSS grid 行=工序/列=月份/双色条） | 12（标志版式） |
| `.soe-milestone` / `.done` / `.cur` / `.plan` | 里程碑节点（日期+形象进度+状态+百分比） | 12 |
| `.soe-fourcontrol` / `.soe-fc-light` / `.soe-fc-gauge` | 四控制仪表盘（安全/质量/进度/投资 四宫格+状态灯+KPI+仪表条） | 13（标志版式） |
| `.soe-param-table` | 工程技术参数表（8 格） | 04 项目概况 |
| `.soe-roadmap` / `.soe-rm-node` / `.soe-rm-stage` | 技术路线流程图（5 阶段，取代 2×2 矩阵） | 08 |
| `.soe-chapter-stroke` | 章节页 stroke-only 巨型轮廓字 | 07（特色） |
| `.soe-milestone-rail` / `.soe-ms-dot` | 目录页工程里程碑时间轴 | 02 |

> 所有 `soe-*` 组件颜色均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 切换时自动联动。深色 deck 适配：卡片用 `rgba(255,255,255,.04-.06)` 玻璃感 + 发光边框，文字白/浅灰，不硬套浅灰卡。推荐配套方案：`powerchina-modern`（默认）、`government-blue`（政务蓝）、`consulting-navy`（深蓝投行）、`ocean-depths`（深海蓝）。

> **差异化**（docs/deck-differentiation-spec.md §5）：本 deck 是深色 deck，标志性版式 = **甘特图（12）+ 四控制仪表盘（13）+ 技术路线图（08）+ 科技卡片（09）**，去掉了 consultant 的 2×2 矩阵/通用时间轴/RAG 季度卡。封面（基石概念·居中）与致谢（参建联系人+全景图+二维码）元素集与政府/金融/学术完全不重叠。
