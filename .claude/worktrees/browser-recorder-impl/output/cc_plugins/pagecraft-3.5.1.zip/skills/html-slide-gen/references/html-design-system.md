# HTML 演示文稿设计系统

## 目录

- [架构概述：多文件 iframe](#架构概述多文件-iframe) — index.html / slides/*.html / shared/tokens.css / assets
- [1. 设计 Token](#1-设计-token) — 基础 Token · 逐字稿隐藏 · 颜色管理 · 视觉丰富度等级(L1-L3) · CRAP 原则 · 版面利用率 · 禁止模式 · 图表组件(11) · 图标(129) · 多画布
- [2. 内容篇幅参考](#2-内容篇幅参考) — 布局内容参考 · 文本截断 · 字号合规 · 2.1 布局目录 · 2.2 轻量组件(.point/.takeaway/.accent-text/slide-dark) · 2.3 Chrome 装饰层
- [3. 动画规范](#3-动画规范) — 入场动画(data-anim) · 列表逐条揭示 · 使用原则
- [4. 换肤机制（双轨）](#4-换肤机制双轨) — 颜色方案注入(推荐) · 完整主题 CSS(备选) · 场景推荐
- [5. PPTX 导出](#5-pptx-导出) — editable(V2 hybrid) · image(降级)
- [6. 运行时规格](#6-运行时规格) — 画布适配 · 键盘导航 · 视频嵌入 · 字体 · DECK_NOTES · index/runtime 分离

> **快速路径**：写 token → 看 §1；选布局/组件 → 看 §2；导出 → 看 §5。

## 架构概述：多文件 iframe

本设计系统基于**多文件 iframe 架构**，不是单文件 HTML：

- `index.html` — 入口壳，管理导航、缩放、深链接
- `slides/*.html` — 每页一个独立 HTML，通过 `<iframe>` 加载，CSS 天然隔离
- `shared/tokens.css` — 唯一设计真相来源，所有 slides 引用同一份 token
- `assets/` — 品牌图片，slides 通过 `../assets/` 引用

**关键约束：**
- 每个 slide 是**独立的完整 HTML 文件**，包含自己的 `<html>`、`<head>`、`<body>`
- 所有 slides 通过 `<link rel="stylesheet" href="../shared/tokens.css">` 共享设计 token
- 每个 slide 使用固定画布 `1920px × 1080px`（由 `tokens.css` 的 `var(--deck-width)` / `var(--deck-height)` 定义），`index.html` 通过 `transform: scale()` 适配任意屏幕
- `index.html` 通过 `<iframe>` 加载 slides，实现导航和演示

---

## 1. 设计 Token

所有颜色、字体、间距通过 CSS 变量管理。主题切换 = 替换一个 CSS 文件。

### 基础 Token（tokens.css 定义，主题可覆盖）

```css
:root {
  /* 颜色 */
  --bg: #ffffff;           /* 页面背景 */
  --bg-soft: #f7f7f8;      /* 柔和背景 */
  --surface: #ffffff;      /* 卡片/容器背景 */
  --surface-2: #f2f2f4;    /* 次级表面 */
  --border: rgba(0,0,0,.08);
  --border-strong: rgba(0,0,0,.16);
  --text-1: #111216;       /* 主文字 */
  --text-2: #55596a;       /* 次文字 */
  --text-3: #8a8f9e;       /* 辅助文字 */
  --accent: #3b6cff;       /* 主强调色 */
  --accent-2: #7a5cff;     /* 辅助强调色 */
  --accent-3: #ff5c8a;     /* 第三强调色 */
  --good: #1aaf6c;         /* 成功/正面 */
  --warn: #f5a524;         /* 警告/中性 */
  --bad: #e0445a;          /* 错误/负面 */
  --grad: linear-gradient(135deg,#3b6cff,#7a5cff 55%,#ff5c8a);

  /* 圆角 */
  --radius: 18px;
  --radius-sm: 12px;
  --radius-lg: 26px;

  /* 阴影 */
  --shadow: 0 10px 30px rgba(18,24,40,.08), 0 2px 6px rgba(18,24,40,.04);
  --shadow-lg: 0 24px 60px rgba(18,24,40,.14), 0 6px 16px rgba(18,24,40,.06);

  /* 字体 */
  --font-sans: 'Inter','Noto Sans SC',-apple-system,BlinkMacSystemFont,Helvetica,Arial,sans-serif;
  --font-serif: 'Playfair Display','Noto Serif SC',Georgia,serif;
  --font-mono: 'JetBrains Mono','IBM Plex Mono',SFMono-Regular,Menlo,monospace;
  --font-display: var(--font-sans);

  /* 字间距 */
  --letter-tight: -.03em;
  --letter-normal: -.01em;

  /* 缓动 */
  --ease: cubic-bezier(.4,0,.2,1);
}
```

> **slide 作者只需用语义 token**（`var(--accent)` / `var(--text-1)` / `var(--grad)` 等），无需关心 brand 层。语义色在每个 deck 的 tokens.css 主 `:root` 内由 `--brand-*` 派生（`--accent: var(--brand-primary)` 等），switch-theme 换 `--brand-*` 时自动联动。详见 §4 换肤机制。

### 逐字稿隐藏规则（必须保留）

tokens.css **必须包含**以下规则，否则 `<aside class="notes">` 中的逐字稿会直接渲染到幻灯片画面上：

```css
.notes, aside.notes { display: none !important; }
```

此规则已内置在 `templates/shared/tokens.css` 中。生成或修改 tokens.css 时**禁止删除此行**。

### 颜色管理原则

- 同一页不超过 **3 种颜色**（中性色不算）
- 主色调 1 个：用于标题、关键数据、按钮
- 辅助色 1-2 个：用于图表区分、次要信息
- 强调色 1 个：用于需要特别突出的内容（通常与主色调形成对比）
- NEVER 使用 `color: #xxx` 硬编码，ALWAYS 使用 `var(--xxx)`

### 视觉丰富度等级（Visual Richness Levels）

所有 slides 必须满足对应等级的最低视觉质量标准。共三级：

| 等级 | CSS 要求 | 适用页面 | 检查方式 |
|------|----------|----------|----------|
| **L1** | 至少 1 个 gradient（渐变顶条 `.slide-top-bar` 或背景渐变） | 所有内容页**底线** | `grep -c 'linear-gradient\|radial-gradient'` |
| **L2** | L1 + card shadow + 角落 ambient glow `.ambient-glow-*` 或装饰几何 `.deco-circle` | 章节分隔页 | L1 检查 + `grep -c 'box-shadow'` |
| **L3** | L2 + 多层装饰 + `.icon-halo` 背景光晕 + `.divider-gradient` 渐变分隔线 | 封面、结束页 | L2 检查 + 视觉审查 |

**预置工具类**（`templates/shared/tokens.css` 中定义，所有 slide 自动可用）：

- **L1**: `.slide-top-bar`（渐变顶条）、`.slide-bottom-bar`（渐变底条）、`.slide-side-bar`（侧边渐变条）
- **L2**: `.ambient-glow-tr` / `.ambient-glow-bl` / `.ambient-glow-tl`（角落环境光晕）、`.card-elevated`（精致阴影卡片）、`.deco-circle`（装饰圆形）
- **L3**: `.icon-halo`（图标光晕）、`.divider-gradient`（渐变分隔线）、`.dot-cluster`（装饰圆点簇）、`.grid-texture`（网格纹理背景）

**L1 底线示例**——任何内容页至少包含一个渐变顶条：

```html
<body>
  <div class="slide-top-bar"></div>
  <!-- 页面内容 -->
</body>
```

**L3 封面示例**——组合使用多种装饰：

```html
<body>
  <div class="slide-top-bar"></div>
  <div class="ambient-glow-tr"></div>
  <div class="ambient-glow-bl"></div>
  <div class="deco-circle" style="width:300px;height:300px;top:-80px;right:-60px;"></div>
  <div class="dot-cluster" style="top:120px;right:200px;"></div>
  <div class="dot-cluster sm accent2" style="top:140px;right:220px;"></div>
  <!-- 封面内容 -->
</body>
```

**布局等级要求**——各布局的最低视觉等级要求见 `references/layout-catalog.md` 每个布局的标注。

### CRAP 设计原则

生成所有 slides 后必须逐页自检以下四项：

#### 对齐 (Alignment)

- 同类元素的左/右/中边距统一（偏差 ≤ 4px）
- 标题、正文、注释的起始 x 位置保持一致
- 卡片内 padding 值统一（使用 `var(--space-*)` 而非硬编码）

#### 对比 (Contrast)

- 标题字号 ≥ 正文 1.5x（h1: 72px, h3: 32px, p: 18-20px）
- 主文字 `--text-1` vs 辅助文字 `--text-3` 对比度 ≥ 4.5:1
- 强调色仅用于 < 10% 的页面元素

#### 重复 (Repetition)

- 所有卡片统一 `border-radius: var(--radius)`（不要混用 px 值）
- 同级标题使用相同的 `font-size` 和 `font-weight`
- 页脚/页码在所有页面中位置和样式一致

#### 亲密性 (Proximity / 聚拢)

- 标题与其内容间距 < 标题与上一板块间距
- 图表与图例紧邻
- KPI 数字与标签紧邻（不拆到不同卡片）

**CRAP 自检清单**（Phase 4.4 生成后逐页检查）：

```
□ 所有文本左/中/右边距是否统一？
□ 标题 vs 正文字号比例是否 ≥ 1.5x？
□ 同类卡片是否使用相同圆角、阴影、padding？
□ 相关元素是否在空间上靠近，无关元素是否分离？
```

### 版面利用率参考

以下为各页面类型的**参考区间**（非硬性约束）。实际内容量由 Phase 2 故事线决定——利用率不在参考区间不代表错误，但应检查是否合理。

| 页面类型 | 推荐利用率 | 说明 |
|---------|-----------|------|
| 架构图/流程图 | 70-85% | 信息密集，充分利用空间 |
| 卡片网格 | 60-75% | 卡片间留白是视觉呼吸 |
| 要点列表 | 50-70% | 留白帮助聚焦 |
| 封面/结尾 | 30-50% | 大量留白，视觉冲击 |
| 数据图表 | 65-80% | 图表占主导，留白用于标签和图例 |

**利用率估算**：内容自然高度（子元素高度 + gap 之和）/ 可用画布高度。`< 40%` 检查是否太松，`> 95%` 检查是否可能溢出（触发压缩策略：缩小 gap、减小字号、或拆页）。

### 禁止模式清单

以下 CSS 组合必然导致布局 bug，**任何 slide 中不得出现**：

| 禁止模式 | 后果 | 替代方案 |
|---------|------|---------|
| `margin-top: auto` 与 `position: absolute`（如 `.tech-footer`）共存 | 内容区末元素与 footer 必然重叠 | 用固定 `margin-top: 28px`，靠 `padding-bottom` 控制 footer 间距 |
| `flex: 1` 容器缺 `overflow: hidden` | 子元素穿透容器，与 footer 或其他区域重叠 | 所有 `flex: 1` 容器必须加 `overflow: hidden; min-height: 0`（已内置在 `.page-body` 和 `.fill` 中） |
| 在 `.tech-footer` 区域内放置内容元素 | footer 文字被遮挡 | `.tech-footer` 只放 `<span>` 项目名和页码 |
| 挂 `.anim-fade`/`.anim-fade-up-soft` 的 SVG 元素用元素级 `opacity="..."` 做淡色 | 动画末态 `opacity:1`（CSS 优先级高于属性）覆盖淡色 → 色块变实心、同色标签隐形 | 静态淡色一律 `fill-opacity=".10"`（填充层，不被 opacity 动画影响）；详见 `references/motion-system.md §9.1` |
| SVG 圆点 `r` / 描边 `stroke-width` / 轴标贴 `viewBox` 边界 | 末端点、粗描边、曲线收尾被默认 `overflow:hidden` 静默裁切 | 几何离边 ≥ `r + stroke-width/2`，或给 viewBox 加负原点 padding（`viewBox="-P -P (W+2P) (H+2P)"`，坐标不动）；deck tokens 的 `svg{overflow:visible}` 兜底；详见 `motion-system.md §9.2` |

### 图表组件模板库

`templates/charts/` 目录提供 **30 种**图表组件的 HTML/CSS 模板（曲线类用内联 SVG + token 着色），避免 AI 每次从零构建。完整机器索引见 `templates/charts/charts-index.json`（含 `render`/`pptxFriendly`/`tokens`/`keywords` 字段，AI 选型优先读取），人工浏览见 `templates/charts/README.md`。

| 组件 | 文件 | CSS 类 | 使用场景 |
|------|------|--------|---------|
| 折线图 | `line-chart.html` | `.svg-chart` `.line` `.ser-a`（svg-inline） | 时间趋势 |
| 面积图 | `area-chart.html` | `.svg-chart` `.area-a`（svg-inline） | 累积趋势 |
| KPI 卡片 | `kpi-cards.html` | `.kpi-grid` `.kpi-card` `.kpi-accent-bar` | 关键指标展示 |
| 大数字 | `big-numbers.html` | `.kpi-card` `.kpi-value` | 数据冲击 |
| 柱状图 | `bar-chart.html` | `.chart-bars` `.chart-bar` `.chart-bar-item` | 类别对比 |
| 水平条形排名 | `horizontal-bar-chart.html` | `.hbars` `.hbar-row` `.hbar-rank` `.hbar-fill` | 长标签排名（前三高亮） |
| 分组柱状图 | `grouped-bar-chart.html` | `.grouped-bars` `.gb-bar` `.gb-legend` | 多系列对比 |
| 堆叠柱状图 | `stacked-bar-chart.html` | `.stacked-bars` `.sb-col` `.sb-seg` | 构成对比 |
| 瀑布图 | `waterfall-chart.html` | `.waterfall` `.wf-bar` `.wf-conn` | 增减分解 |
| 蝴蝶图 | `butterfly-chart.html` | `.butterfly` `.bf-row` `.bf-bar` | 左右双向对比 |
| 子弹图 | `bullet-chart.html` | `.bullets` `.bullet-track` `.bullet-target` | 目标 vs 实际 |
| 哑铃图 | `dumbbell-chart.html` | `.dumbbells` `.db-track` `.db-dot` | 前后两点对比 |
| 饼图 | `pie-chart.html` | `.pie`（conic-gradient 多段） | 占比构成 |
| 环形图 | `donut-chart.html` | `.donut` `.donut-sm` `.donut-lg` | 占比构成（中心数字） |
| 矩形树图 | `treemap-chart.html` | `.treemap` `.tm-tile` | 层级面积占比 |
| 热力图 | `heatmap-chart.html` | `.heatmap` `.hm-cell`（`--i` 浓度） | 矩阵强度分布 |
| 雷达图 | `radar-chart.html` | `.svg-chart` `.radar-poly-a`（svg-inline） | 多维评估 |
| 散点图 | `scatter-chart.html` | `.svg-chart` `.scatter-a`（svg-inline） | 相关性/分布 |
| 仪表盘 | `gauge-chart.html` | `.gauge` `.gauge-needle`（180° 半圆） | 达成度 |
| 进度条 | `progress-bar.html` | `.progress-bar-track` `.progress-bar-fill` | 完成率/对比 |
| 评分卡 | `rating-score.html` | 复用 `.progress-bar-*` + `.donut` | 多维度评分 |
| 时间线 | `timeline.html` | `.timeline` `.timeline-item` | 里程碑/历程 |
| 流程图 | `process-flow.html` | `.process-flow` `.pf-node` | 业务流程 |
| 漏斗图 | `funnel-chart.html` | `.funnel` `.funnel-stage` | 转化流程 |
| 甘特图 | `gantt-chart.html` | `.gantt` `.gantt-lane` `.gantt-bar` | 项目排期 |
| 组织结构图 | `org-chart.html` | `.orgchart` `.org-node` `.org-children` | 组织架构 |
| 四象限矩阵 | `matrix-2x2.html` | `.matrix-2x2` `.quadrant` | 战略定位 |
| SWOT 分析 | `swot-analysis.html` | `.swot` `.swot-cell`（S/W/O/T 四色） | 战略规划 |
| 波特五力 | `porter-five-forces.html` | `.porter` `.porter-center`（3×3） | 行业分析 |
| 对比表格 | `comparison-table.html` | `.grid` `.card` | 方案对比 |

**使用方式**：读取模板文件的 HTML 片段，复制到 slide 的 `<body>` 内，替换 `{{}}` 占位符即可。所有 CSS 类已在 `tokens.css` 中预置，无需页面内重复定义。颜色一律用 `var(--accent)` 等 token，跟随 deck 主题/明暗。

**与 Chart.js 的关系**：本库 30 种全部 `render=css` 或 `svg-inline`，PPTX 导出友好。**曲线类（折线/面积/雷达/散点）已用内联 SVG + token 着色替代 Chart.js**，导出不再 rasterize 失真。仅当需交互或超复杂数据时才考虑 Chart.js。

**图表选择决策**：什么数据用什么图表，见 `references/layout-catalog-index.md` 的「数据可视化决策速查」章节。

### 图标使用

`templates/assets/icons/` 提供 129 个常用 SVG 图标，分类索引见 `templates/assets/icons/README.md`。

**使用方式**：

```html
<!-- 方式1: img 引用（推荐，简单可靠） -->
<img src="../assets/icons/chart-bar.svg" class="icon-md" alt="">

<!-- 方式2: 内联 SVG（可 CSS 控制颜色，通过 var(--xxx)） -->
<svg class="icon-md" viewBox="0 0 24 24" fill="var(--accent)">
  <use href="../assets/icons/sprite.svg#chart-bar"/>
</svg>
```

**图标尺寸工具类**（tokens.css 已预置）：
- `.icon-sm` — 20×20px（卡片内小图标）
- `.icon-md` — 32×32px（默认尺寸）
- `.icon-lg` — 48×48px（章节图标）
- `.icon-xl` — 72×72px（封面/重点图标）
- `.icon-2xl` — 96×96px（封面主图标）

**原则**：
- 优先使用图标库，避免 emoji 作为主要视觉元素
- 商用/正式场合禁止 emoji 图标，使用 SVG 图标替代
- 图标颜色通过 `var(--accent)` / `var(--accent-2)` 等 token 控制，不硬编码

### 多画布格式

默认画布为 16:9 (1920×1080px)。在 `<body>` 上添加 class 切换画布：

| 格式 | CSS Class | 尺寸 | 适用场景 |
|------|-----------|------|---------|
| 16:9 | `.deck-169`（或默认） | 1920×1080 | 标准演示、投影仪 |
| 4:3 | `.deck-43` | 1024×768 | 旧投影仪、兼容性 |
| 9:16 | `.deck-916` | 1080×1920 | 手机竖屏、短视频 |
| 1:1 | `.deck-11` | 1080×1080 | 社交媒体、朋友圈 |

**切换方式**：
1. 在 `index.html` 的 `<body>` 上添加对应 class（如 `<body class="deck-916">`）
2. 设置 `DECK_WIDTH` / `DECK_HEIGHT` 变量匹配
3. tokens.css 的 `:root.deck-*` 规则自动覆盖 `--deck-width`、`--deck-height`、`--margin`
4. 所有 slide HTML 无需修改，自动适配

**注意**：切换画布后，slide 内容区域会等比例变化。竖版布局（9:16）需要调整排版节奏——减少单页内容量，增大字号和间距。

---

## 2. 内容篇幅参考

内容量由策略规划和故事线阶段决定，不设硬性字符上限。不同文稿类型、不同布局对内容量的承载力不同——一张能力对比表格天然比一句话金句承载更多信息，这完全合理。

以下仅为 **参考基准**（validate.mjs 的 `content` 检查会按 200 字符发出 WARNING 提醒，但不阻断导出）：

| 文稿类型 | 参考范围 | 典型场景 |
|---------|---------|---------|
| 说服/促动 | 一句话、一个数字、一个关键词 | 核心观点冲击 |
| 信息同步 | 3–5 个要点 + 简短描述 | 汇报、同步 |
| 传授/赋能 | 可有更多正文，注意留白 | 培训、分享 |
| 启发/共鸣 | 一句金句或一个画面 | 开场、收尾 |

**实际内容量的判断标准：**
- 故事线阶段（Phase 2）已为每页规划了核心信息和支撑要点——按规划执行即可
- 能力对比、竞品分析、数据表格等结构化内容——信息密度天然高，应保证完整性
- 真正需要警惕的是：大段无结构的纯文本堆砌，而非字符数本身

**溢出是排版问题，不是内容量问题：** 如果内容超出画布，应通过调整字号、间距、布局来适配，而非删减内容。validate.mjs 的 `content` 检查在任何模式下均为 WARNING 提醒，不阻断导出。

### 每种布局的内容参考

布局的物理空间自然约束了内容量。**不再使用硬编码项数上限**——实际容量由内容深度动态决定（3 张薄卡 ≠ 3 张厚卡）。用 `scripts/check-spec-capacity.mjs` 的 `LAYOUT_BUDGETS` 做容量预检判断填充率。

以下为**结构约束**（不可变的 grid 列数/固定槽位），其余由动态估算决定：

| 布局 | 结构约束 | 说明 |
|------|------|------|
| L08 three-column | `.grid.g3` 三列，不可加第 4 卡 | 超出 3 卡拆页或换布局 |
| L11 kpi-grid | `.grid.g4` 四列，不可加第 5 卡 | 超出 4 卡拆页或换布局 |
| L19 roadmap | 4 列 grid，不可加列 | 超出拆为两行或两页 |
| L22 process-steps | 4 列 grid，不可加第 5 步 | 超出拆为"总览 + 详情"两页 |

> "不可加"是 HTML 布局结构的物理限制（grid 列数/固定槽位）。其余布局无结构硬约束——内容量由高度估算公式决定是否拆页。

### 文本截断工具类

当容器空间有限时，使用 `line-clamp` 工具类防止文字撑破容器：

```css
.clamp-1  /* 限制 1 行，超出截断 */
.clamp-2  /* 限制 2 行 */
.clamp-3  /* 限制 3 行 */
```

典型用法：
- 卡片标题加 `.clamp-2`（最多显示 2 行）
- 列表描述加 `.clamp-3`
- 永远不要用 `.nowrap` 包裹可能超长的文本

### 字体大小合规

- 必须使用 `tokens.css` 定义的设计 token：`--fs-hero`(38pt) → `--fs-micro`(9pt)
- NEVER 在 inline style 中使用 `font-size` 超出 9pt–72pt 范围
- validate.mjs `content` 检查会拦截超出范围的 inline font-size

---

## 2.1 布局目录

32 种 slide 布局的完整参考（CSS 模式、HTML 骨架、布局选择速查）见 `references/layout-catalog.md`。

快速分类：结构型 5（L01-L05）| 文本型 5（L06-L10）| 数据型 6（L11-L16）| 图表型 7（L17-L23）| 对比与媒体型 4（L24-L27）| 代码/开发型 3（L28-L30）| 工具型 2（L31-L32）。

布局选择速查：核心数字→L10/L09 | 并列要点→L06/L08 | 数据对比→L12/L13/L24 | 流程步骤→L17/L22/L18 | 架构→L21/L20 | 规划排期→L19/L23 | 产品图→L26/L27 | 代码→L28/L29/L30

---

## 2.2 轻量内容组件

演讲场景优先使用以下轻量组件，减少 `.card` 堆叠造成的视觉疲劳。

### `.point` — 三行列表项

编号 + 标题 + 说明的三行结构，无背景、无边框、无阴影。演讲场景**默认首选**。

```html
<div class="point">
  <span class="num">01</span>
  <div>
    <div class="title">Context Engineering</div>
    <div class="desc">让 AI 理解你的代码库和业务上下文。</div>
  </div>
</div>
```

多个 `.point` 用 `.stack` 包裹形成列表：

```html
<div class="stack">
  <div class="point">...</div>
  <div class="point">...</div>
  <div class="point">...</div>
</div>
```

**何时用**：要点列表、目录页、功能特性介绍、时间线节点、对比分析内容。

**何时不用**：需要卡片边界的独立容器（如 Before/After 对比卡片）——用 `.card` + 内部 `.point`。

### `.takeaway` — 页面底部结论行

固定在内容区底部的结论/要点行。用 `margin-top: auto` 推到 `.slide-body` 底部。

```html
<div class="slide-body">
  <!-- 页面正文 -->
  ...
  <div class="takeaway">
    <span class="label">KEY TAKEAWAY</span>
    Context Engineering 是 Claude Code 区别于其他 AI 编码工具的核心竞争力。
  </div>
</div>
```

**何时用**：有明确结论/核心观点的内容页。不是每页都需要——适合"这页想让人记住一句话"的场景。

**何时不用**：目录页、纯数据页、封面/结尾页。

### `.accent-text` — 单色关键词高亮

纯色高亮，PPTX 导出兼容。适用于内容页标题或正文中的 1-2 个关键词。

```html
<h2>The <span class="accent-text">context engineering</span> difference</h2>
```

**与 `.gradient-text` 的区别**：

| | `.accent-text` | `.gradient-text` |
|---|---|---|
| 效果 | 纯色（`var(--accent)`） | 渐变色（`var(--grad)`） |
| 适用 | 内容页关键词 | 封面大标题 |
| 克制度 | 低（1-2 个词） | 高（整行渐变） |
| PPTX | 兼容 | 不兼容 |

### `body.slide-dark` — 深色模式

在 `<body>` 上加 `class="slide-dark"`，CSS 变量自动切换为深色（`--dark-bg`、`--dark-text` 等）。品牌色（`--accent`、`--grad`）不受影响。

```html
<body class="slide-dark">
  <div class="slide-body">
    <h2 class="h2">Deep page content</h2>
  </div>
</body>
```

**深色模式变量**（定义在 tokens.css `:root` 中，可在 deck 级别覆写）：

```css
--dark-bg: #0A1628;
--dark-surface: #111D35;
--dark-text: #F8FAFC;
--dark-text-dim: #94A3B8;
--dark-text-faint: #475569;
--dark-border: rgba(255,255,255,.08);
```

**适用场景**：章节过渡页、全屏声明/金句页、要点总结页。关键是章节边界处有节奏变化，不需要每页交替。

---

## 2.3 Chrome 装饰层

Chrome 装饰层是在内容之下、背景之上叠加的视觉装饰（网格纹理、角落光晕、边框线、几何节点），为深色主题幻灯片增加精致感和科技感。所有 Chrome 类在 tokens.css 中定义为工具类，可直接组合使用。

### 工作流：封面先行建立 Chrome → 后续页面复用

1. **Wave 1（封面）** subagent 确定该 deck 的 Chrome 规格（选哪些层、用哪些颜色）
2. **输出 `chrome-spec.md`**：记录该 deck 选定的 Chrome 类组合（CSS 代码片段）
3. **Wave 2/3** subagent 读 `chrome-spec.md`，复制相同 Chrome 层到自己的页面

### 可用 Chrome 工具类

| 类名 | 视觉效果 | z-index |
|------|---------|---------|
| `.chrome-layer` | 全屏容器（absolute inset:0, pointer-events:none） | z:1 |
| `.chrome-grid` | 60×60 极淡网格纹理（accent 色 3% 不透明度） | z:auto |
| `.chrome-glow-tl` | 左上角光晕（accent-2 色 10% 不透明度） | z:auto |
| `.chrome-glow-br` | 右下角光晕（accent 色 7% 不透明度） | z:auto |
| `.chrome-line-top` | 顶部渐变细线（两端淡出） | z:auto |
| `.chrome-line-bottom` | 底部渐变细线（accent+accent-2 混合） | z:auto |
| `.chrome-line-left` | 左侧竖线（两端淡出） | z:auto |
| `.chrome-line-right` | 右侧竖线（两端淡出） | z:auto |
| `.chrome-geo-tl/tr/bl/br` | 四角菱形几何节点（accent-2 色 + 光晕） | z:auto |

### 使用示例

```html
<body class="tpl-tech-sharing slide-dark">
  <!-- Chrome 装饰层（z-index: 1，内容层 z-index: 2） -->
  <div class="chrome-layer">
    <div class="chrome-grid"></div>
    <div class="chrome-glow-tl"></div>
    <div class="chrome-glow-br"></div>
    <div class="chrome-line-top"></div>
    <div class="chrome-line-bottom"></div>
    <div class="chrome-line-left"></div>
    <div class="chrome-line-right"></div>
    <div class="chrome-geo-node chrome-geo-tl"></div>
    <div class="chrome-geo-node chrome-geo-tr"></div>
    <div class="chrome-geo-node chrome-geo-bl"></div>
    <div class="chrome-geo-node chrome-geo-br"></div>
  </div>
  <!-- 内容层 -->
  <div class="slide-body" style="z-index: 2;">
    ...
  </div>
</body>
```

### 精简配置

不是所有页面都需要完整 Chrome。常见配置：

| 场景 | 推荐配置 |
|------|---------|
| 封面 | 全部（grid + glow×2 + lines×4 + geo×4） |
| 章节分隔 | grid + glow×2 + lines×2（无 geo-nodes） |
| 内容页 | grid + glow×1（可选 lines） |
| 结尾 | 与封面对称 |

### 前置条件

Chrome 层使用 `rgba(var(--accent-rgb), ...)` 语法，需要 `--accent-rgb` 和 `--accent-2-rgb` 变量。Phase 4.1 brand-spec 注入时必须设置这些变量。brand-spec.md 中主色 hex 值会被转换为 RGB 通道值。

---

## 3. 动画规范

> 动效规范见 **`references/motion-system.md`**（动效唯一真相源）。

核心要点：

- **纯 CSS class 驱动**，挂 `.anim-*` class（如 `.anim-fade-up`、`.anim-rise-in`、`.anim-zoom-pop`）+ `.anim-dN` delay 类。**`data-anim` 属性已弃用**（无 JS 消费，死代码），生成 slide 时删除。
- 动效强度按模板分 4 档（强/中/轻/零），详见 motion-system.md §6。opt-out 模板（dir-key-nav-minimal、knowledge-arch-blueprint）严禁任何 `anim-*` class。
- 内容语义角色 → 动画映射、8 种 slide 类型的 stagger 时序配方见 motion-system.md §4-§5。

列表逐条揭示仍用 `.anim-stagger-list` 容器类：

```html
<ul class="anim-stagger-list">
  <li>第一点</li>
  <li>第二点</li>
  <li>第三点</li>
</ul>
```

### 动画使用原则

- 克制使用，每页最多 2-3 个动画元素
- 数据图表的柱状图可以逐个出现（引导视线）
- NEVER 在所有页面上都加动画——只有需要引导注意力时才用
- NEVER 使用旋转、弹跳、闪烁等分散注意力的动画

---

## 4. 换肤机制（双轨）

本设计系统提供两种换肤方式，推荐使用方式一：

### 方式一：颜色方案注入（推荐）

通过 `scripts/color-schemes.json`（40 个预设）选择颜色方案，由 `scripts/switch-theme.mjs` 正则替换**每个 deck 的** `shared/tokens.css` 主 `:root` 里的 brand 键——14 个 `--brand-*` + `--border-strong` + `--grad-soft` 字面色，外加 7 个 `--brand-*-rgb` 通道（primary/secondary/accent/good/warn/bad/text，供 overlay 内 `rgba(var(--brand-*-rgb),α)` 使用）。语义 token（`--accent`、`--bg` 等）与 deck-private vars（`--kb-rust` 等）都 `var(--brand-*)` 链接，自动跟随。这是 SKILL.md Phase 4.1 的默认方式，23 个 starter-deck 全部已接入。

```bash
# 查看所有可用颜色方案
node scripts/switch-theme.mjs --list
# 一键切换（写到 <deck-dir>/shared/tokens.css）
node scripts/switch-theme.mjs --deck <deck-dir> --scheme <name>
```

### 按场景推荐

| 文稿类型 | 推荐颜色方案（40 个预设，按 mood 标签匹配） |
|---------|----------------------------------------|
| 说服/促动 | ocean-depths, midnight-ink |
| 传授/赋能 | forest-canopy, tokyo-night |
| 信息同步 | cerulean, slate-grey |
| 启发/共鸣 | sakura-blossom, rose-pine |
| 高端咨询/投行 | **mckinsey-blue**, **consulting-navy** |
| 政企/政务汇报 | **government-red**, **government-blue** |
| 央企/国企工程 | **powerchina-modern**, ocean-depths |
| 金融/VIP 财富 | **cmb-gold-red**, ocean-depths |
| 学位答辩/学术 | **academic-green**, **cqu-mountain** |
| 医疗/健康研究 | **medical-cyan**, ocean-depths |
| 极客/复古/游戏 | **pixel-neon**, dracula |

> 加粗项为 2026-06-18 新增的 10 个配色方案，源自 pagecraft `layouts/*/design_spec.md`，覆盖咨询/政企/央企/金融/学术/医疗/极客 7 个高端 B 端赛道。完整颜色方案列表（含 mood 标签）见 `scripts/color-schemes.json`。

---

## 5. PPTX 导出

> **V2 引擎下 HTML 生成阶段零约束**——TreeWalker 全覆盖文本提取、渐变/SVG/背景图自动截图保留。详见 `references/editable-pptx.md`。

```bash
# PPTX 可编辑模式（推荐，V2 hybrid）
node scripts/export_pptx.mjs --slides slides-output/<name>/export/<name>-live/slides --out slides-output/<name>/export/<标题>.pptx --mode editable

# PPTX 图片模式（editable 报错时降级）
node scripts/export_pptx.mjs --slides slides-output/<name>/export/<name>-live/slides --out slides-output/<name>/export/<标题>.pptx --mode image
```

---

## 6. 运行时规格

### 画布与屏幕适配

画布默认 1920px × 1080px（由 `tokens.css` 的 `var(--deck-width)` / `var(--deck-height)` 定义），通过 `index.html` 的 `transform: scale()` 适配任意屏幕。

| 屏幕尺寸 | scale | 说明 |
|---------|-------|------|
| 1920px | 1.0 | 与画布等大 |
| 1440px | ≈0.75 | 常见笔记本屏幕 |
| 2560px | ≈1.33 | 2K 显示器 |
| 更小屏幕 | < 0.75 | 自动适配 |

每页 slide HTML 的 `body` 使用 `var(--deck-width)` 和 `var(--deck-height)` 确保与画布一致。内容区用 `max-width` 约束，居中显示。禁止在 slide 内部使用 `zoom` 或逐个 `font-size !important` 覆盖。

### 键盘导航与交互

`index-runtime.js` 必须支持以下交互：

- **键盘导航**：`←` `→` `空格` `PgUp/PgDn` `Home/End`
- **演讲者模式**（S 键）：弹出窗口，含当前页预览、下一页预览、逐字稿、计时器，双向同步翻页（BroadcastChannel）
- **逐字稿快览**（N 键）：底部抽屉展示当前页逐字稿
- **URL 深链接**：`#/N`

### 视频嵌入

- 必须转 `.mp4`（H.264 + AAC），`.mov` 浏览器兼容性差
- ffmpeg 转换必须加 `-movflags +faststart`（moov atom 前置，边下载边播放）
- `<video>` 必须加 `controls` + `playsinline` + `preload="metadata"`
- 视频页背景用纯黑 `#0a0a0a`

### 字体

- <= 2 种字体家族（标题 + 正文）
- 全部使用系统字体栈，零网络请求：
  - Sans: `-apple-system, BlinkMacSystemFont, 'PingFang SC', 'Microsoft YaHei', 'Helvetica Neue', Arial, sans-serif`
  - Serif: `'PingFang SC', 'Noto Serif SC', Georgia, 'Songti SC', serif`
  - Mono: `'SF Mono', 'Cascadia Code', 'Consolas', 'Liberation Mono', Menlo, monospace`

> **字体栈说明**：§1 token 表中的 `--font-sans`/`--font-serif`（含 `'Inter'`、`'Noto Sans SC'`、`'Playfair Display'` 等）是设计理想态——**仅当运行环境能联网加载 Web 字体时生效**。运行时（§6）为兼容离线 / `file://` 打开、避免外网请求和 FOUT，回退为上述纯系统字体栈。两套不冲突：token 定义「想要什么」，runtime 保证「离线也能正常渲染」。最终 slide HTML 的 `body` 字体以 tokens.css 中实际注入的栈为准。

### DECK_NOTES 写入规则

1. 从 `speech.md` 提取每页逐字稿，以 `<p>` 标签包裹后写入 `window.DECK_NOTES` 对象
2. **必须使用反引号（模板字面量）**作为字符串定界符——逐字稿中的中文引号 `""` 会被浏览器误判为 JS 字符串终止符，导致 SyntaxError
3. key 格式为 `"slides/XX-xxx.html"`，value 为 HTML 字符串
4. 这是演讲者模式的数据源——`file://` 协议下 `fetch()` 被 CORS 拦截，不能依赖运行时请求 slide 文件

### index.html 与 index-runtime.js 分离

- **必须从模板复制，禁止从头写**：
  1. 复制 `templates/index-shell.html` → `slides-output/<name>/export/<name>-live/index.html`
  2. 复制 `templates/index-runtime.js` → `slides-output/<name>/export/<name>-live/index-runtime.js`（原样复制，不做任何修改）
  3. 只修改 `slides-output/<name>/export/<name>-live/index.html` 中的 `<title>`、`DECK_MANIFEST`、`DECK_NOTES`、`DECK_WIDTH`、`DECK_HEIGHT`
- `index.html` 只包含 HTML 结构、CSS 样式、`DECK_MANIFEST` 数据、`DECK_NOTES` 数据，通过 `<script src="index-runtime.js"></script>` 引入运行时
- `index-runtime.js` 包含全部运行时 JS 逻辑（导航、缩放、演讲者模式、Notes overlay、打印等）
- **绝对禁止**把运行时 JS 内嵌在 index.html 的 `<script>` 标签里——避免中文内容与 HTML 属性引号冲突
- Gate 检查：`slides-output/<name>/export/<name>-live/index-runtime.js` 文件必须存在，且 index.html 中必须包含 `<script src="index-runtime.js">`
