# graphify-dark-graph — Slide Role Catalog

> **模板气质**：deep-night gradient, SVG force graph, glass-morphism cards, animated orbs, neon-influenced code glow
> **默认 color-scheme**：dark-graph（body class `tpl-graphify-dark-graph` 注入全套 `--gd-*` CSS 变量）
> **适用文稿类型**：技术分享、开源项目宣讲、工具 demo、架构介绍
> **叙事结构**：Cover → Section Divider → Agenda → Feature Cards → Code Showcase → Comparison Chart → Pipeline Steps → Stat Hero → Quote → Timeline → CTA → Thanks（共 12 个角色版式，按需选用、任意排序；演示默认顺序 = 文件名顺序 01~12）

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面 | .gd-ambient, SVG force-graph, .gd-rainbow, .gd-eyebrow, .gd-h1, .gd-lede |
| 02 | `section_divider` | 章节分隔页 | .gd-ambient, .gd-orb, .gd-eyebrow, .gd-h1(.gd-grad), .gd-lede |
| 03 | `agenda` | 目录/议程页（编号玻璃行） | .gd-glass 横向 flex 行, mono 大号编号, .gd-grad |
| 04 | `feature_cards` | 四卡片特性展示 + 底部总结 | .gd-grid-4, .gd-glass(.gd-glass-warm/.gd-glass-blue/.gd-glass-green), .gd-grad, .gd-ico 内联 SVG 图标 |
| 05 | `code_showcase` | 命令行 + 代码块展示 | .gd-cmd (neon glow), .gd-codebox (syntax-highlighted pre) |
| 06 | `comparison_chart` | 双栏 ✗/✓ 痛点 vs 收益对比 + 三大指标卡片 | .gd-grid-2, .gd-glass, .gd-ico(circle-x/circle-checkmark), .gd-big.gd-grad |
| 07 | `pipeline_steps` | 四步流程（箭头串联玻璃卡片） | .gd-glass (horizontal flex), → arrows, .gd-text3 dividers, .gd-ico 内联 SVG |
| 08 | `stat_hero` | 大数字 + 力导向插图（左右分栏） | .gd-big.gd-grad, SVG force-graph 插图, .gd-lede |
| 09 | `quote` | 引用/金句页（大引言 + 出处） | 排版引号「"」, .gd-grad 关键词, .gd-eyebrow 出处 |
| 10 | `timeline` | 时间轴/路线图（渐变基线 + 4 节点） | 渐变基线, 节点圆, .gd-glass 小卡, .gd-grad |
| 11 | `cta` | 行动号召 | .gd-cmd (dual neon commands), .gd-tag pills, .gd-grad |
| 12 | `thanks` | 感谢/结束（末页） | .gd-big.gd-rainbow, .gd-lede |

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **页面类型**：封面
- **可替换键**：`slide_number`, `kicker`, `title`, `subtitle`, `caption`
- **不可改动**：`.gd-ambient` + `.gd-orb` 装饰层（保留 dom 结构和动画）、SVG `<svg>` 力导向图（全部 line/circle 坐标和样式）、`.gd-rainbow` span 结构（保留 class 以实现动画渐变色）、body class `tpl-graphify-dark-graph`、h1 `font-size: 118px` 和 `line-height:1.08`
- **内容适配规则**：
  - `title` 使用 `<span class="gd-rainbow">` 包裹全部标题文字（key 在父级 h1 上），替换时保留 span 结构
  - 标题总字数控制在 20 字以内，用 `<br>` 拆行（保持原模板 2 行结构）
  - `subtitle` 中 `<span class="gd-accent">` 包裹最高亮短语，替换时保留 span
  - `caption` 保持一行陈述句，控制在 30 字以内
- **卡片扩展/收缩**：不适用

### `section_divider`
- **源文件**：`slides/02-section-divider.html`
- **页面类型**：章节分隔页（全屏居中大字）
- **可替换键**：`slide_number`, `section_label`, `section_title`, `section_subtitle`
- **不可改动**：`.gd-ambient` + 2 个 `.gd-orb` 位置/动画、h1 `font-size: 160px`/`line-height:1.08`/`font-weight:800`、`.gd-grad` span 结构、垂直居中的 `margin:auto 0` 容器
- **内容适配规则**：
  - `section_title` 中 `<span class="gd-grad">` 包裹 1~3 个关键词做渐变强调，替换时保留 span
  - 标题总字数控制在 8 字以内（大字排版）
  - `section_label` 格式 `"Part XX"` 或中文 "第X部分"，控制在 12 字以内
  - `section_subtitle` 一行副标题，控制在 20 字以内
- **卡片扩展/收缩**：不适用

### `agenda`
- **源文件**：`slides/03-agenda.html`
- **页面类型**：目录/议程页（单列编号玻璃行）
- **可替换键**：`slide_number`, `kicker`, `section_title`, `item_num_1`~`item_num_5`, `item_title_1`~`item_title_5`, `item_desc_1`~`item_desc_5`
- **不可改动**：每行 `.gd-glass` 横向 flex 结构（编号 + 标题/说明两段）、mono 大号编号列（`font-family:SF Mono`/`font-size:30px`/`width:64px`）、编号颜色与卡片色变体配对（warm/blue/green/warm/purple）、行间 `margin-bottom:15px`
- **内容适配规则**：
  - `item_num_N` 为 2 位编号（01~09），mono 字体
  - `item_title_N` 控制在 8 字以内
  - `item_desc_N` 控制在 20 字以内（单行）
  - `section_title` 中 `<span class="gd-grad">` 包裹关键词
- **卡片扩展/收缩**：增删整行 `.gd-glass`（默认 5 条，建议 4~6 条）；调整 `width:64px` 编号列宽适配更大数字

### `feature_cards`
- **源文件**：`slides/04-content.html`
- **页面类型**：内容页（四卡片 1x4 grid + 底部玻璃总结条）
- **可替换键**：`slide_number`, `kicker`, `section_title`, `feature_name_1`, `feature_desc_1`, `feature_name_2`, `feature_desc_2`, `feature_name_3`, `feature_desc_3`, `feature_name_4`, `feature_desc_4`, `summary`
- **不可改动**：`.gd-grid-4` 结构（4 列 grid）、`.gd-glass` 样式（圆角 27px/padding 29px 39px/backdrop-filter/box-shadow/::before inset highlight）、卡片颜色变体（`.gd-glass-warm`/.`.gd-glass-blue`/.`.gd-glass-green` 的分布模式）、卡片顶部内联 SVG 图标（`<svg class="gd-ico gd-ico-40">`，viewBox/fill/path 结构保留，fill 按卡片色变体：warm/blue/green/purple）
- **内容适配规则**：
  - `feature_name_N` 控制在 6 字以内
  - `feature_desc_N` 控制在 25 字以内（单行或紧凑两行）
  - 四张卡片内容量应均匀（最长与最短描述差异不超过 50%）
  - `section_title` 中 `<span class="gd-grad">` 包裹关键词，替换时保留 span
  - `summary` 中 `<span class="gd-accent">` 包裹核心观点，替换时保留 span
- **卡片扩展/收缩**：
  - 收缩为 3 卡：`.gd-grid-4` → `.gd-grid-3`，删除第 4 张卡片
  - 收缩为 2 卡：`.gd-grid-4` → 2 列 grid（`grid-template-columns: repeat(2,1fr)`），调大 gap
  - 扩展为 5 卡：`.gd-grid-4` → `.gd-grid-3`（第一行 3 卡，第二行 2 卡需额外 CSS grid-column 调整）或保持 4 列改为 2 行（需添加 `grid-template-rows`）

### `code_showcase`
- **源文件**：`slides/05-code.html`
- **页面类型**：内容页（命令行展示 + 语法高亮代码块）
- **可替换键**：`slide_number`, `kicker`, `section_title`, `cli_command`, `code_block`
- **不可改动**：`.gd-cmd` 样式（JetBrains Mono/43px/neon glow text-shadow）、`.gd-codebox` 样式（rgba(0,0,0,.55) 深色底/圆角 19px/padding 29px 39px/等宽字体 19px）、`<span class="cm">`/`<span class="kw">`/`<span class="st">`/`<span class="fn">` 语法高亮 span 结构（保留 class，替换内文）pre 内部缩进和空行结构
- **内容适配规则**：
  - `cli_command` 保留 `$` 前缀和 mono 字体风格
  - `code_block` 整体替换为新的语法高亮代码，保留 span class 语义（`.cm`=注释, `.kw`=关键字, `.st`=字符串, `.fn`=函数/布尔）
  - 代码块控制在 12 行以内（超出用 `...` 省略并加注释）
  - `section_title` 中 `<span class="gd-grad">` 包裹关键词
- **卡片扩展/收缩**：不适用（单代码块页面，无卡片网格）

### `comparison_chart`
- **源文件**：`slides/06-chart.html`
- **页面类型**：内容页（双栏 ✗/✓ 痛点 vs 收益对比 + 三大指标玻璃卡片）
- **可替换键**：`slide_number`, `kicker`, `section_title`, `comparison_label_a`, `comparison_sub_a`, `comparison_label_b`, `comparison_sub_b`, `pain_1`, `pain_2`, `pain_3`, `gain_1`, `gain_2`, `gain_3`, `stat_value_1`, `stat_label_1`, `stat_value_2`, `stat_label_2`, `stat_value_3`, `stat_label_3`
- **不可改动**：`.gd-grid-2`（1fr | auto | 1fr）三列结构（左痛点卡 / 中间→ / 右收益卡）、左卡 danger 色调（`rgba(224,112,112,.06)` 底 + `.22` 边，内联）与右卡 `.gd-glass-green` 的语义对照、每行行首内联 SVG 图标（左 `circle-x` fill `--gd-danger` / 右 `circle-checkmark` fill `--gd-green`，`gd-ico-28`）、`.gd-grid-3` 指标卡结构、`.gd-big.gd-grad` 数字样式（`font-size: 160px`/`font-weight: 900`/`letter-spacing:-.04em`）
- **内容适配规则**：
  - `comparison_label_a` / `_b`（「没有知识库」/「有知识库」）控制在 6 字以内
  - `comparison_sub_a` / `_b` 为一句副标语（如「每次都从零开始」），控制在 12 字以内
  - `pain_N` / `gain_N` 控制在 16 字以内（单行），左右各 3 条、一一对应语义
  - `stat_value_N` 保留数值+单位紧凑格式（如 "5×" "-80%" "∞"），使用 `.gd-grad` 渐变样式
  - `stat_label_N` 控制在 8 字以内
  - 左右两栏条数必须相等（默认 3 vs 3）
- **卡片扩展/收缩**：
  - 痛点/收益行数增减：在 `.gd-glass` 内复制/删除整行（图标+文案 div），左右对称
  - 统计卡片缩为 2：`.gd-grid-3` → `grid-template-columns: repeat(2,1fr)`
  - 统计卡片扩为 4：`.gd-grid-3` → `.gd-grid-4`

### `pipeline_steps`
- **源文件**：`slides/07-pipeline.html`
- **页面类型**：内容页（横向四步流程 + 底部说明玻璃条）
- **可替换键**：`slide_number`, `kicker`, `section_title`, `step_name_1`, `step_desc_1`, `step_name_2`, `step_desc_2`, `step_name_3`, `step_desc_3`, `step_name_4`, `step_desc_4`, `pipeline_note`
- **不可改动**：横向 flex 容器（`display:flex;align-items:center;justify-content:center;gap:11px`）、→ 箭头分隔符（`<div style="color:var(--gd-text3);font-size:32px">→</div>` 保留结构和样式）、`.gd-glass` 四张卡片样式、卡片颜色变体分布（default/blue/green/warm）、每步顶部内联 SVG 图标（`<svg class="gd-ico gd-ico-45" style="margin:0 auto">`，fill 按色变体：purple/blue/green/warm）
- **内容适配规则**：
  - `step_name_N` 控制在 5 字以内（英文单单词）
  - `step_desc_N` 控制在 8 字以内（紧凑单行）
  - `section_title` 中 `<span class="gd-grad">` 包裹关键词
  - `pipeline_note` 控制在 40 字以内（一行半以内）
  - 步骤图标为内联 SVG（结构保留，非 data-replace 文案）
- **卡片扩展/收缩**：
  - 收缩为 3 步：删除第 4 张卡片和它前面的 → 箭头
  - 收缩为 2 步：保留首尾两张卡片和中间一个 → 箭头
  - 扩展为 5 步：在箭头链末尾再复制一对 → + .gd-glass 卡片

### `quote`
- **源文件**：`slides/09-quote.html`
- **页面类型**：引用/金句页（全屏居中大引言 + 出处）
- **可替换键**：`slide_number`, `quote_text`, `attribution`
- **不可改动**：装饰排版引号「"」（Georgia serif / `font-size:240px` / `opacity:.32` / `color:--gd-purple`）、`margin:auto 0` 垂直居中容器、`max-width:1410px` 限宽、引号与正文 `margin-bottom:-30px` 叠压关系、出处线（54px warm 横线 + eyebrow）
- **内容适配规则**：
  - `quote_text` 一句金句，控制在 40 字以内；用 `<span class="gd-grad">` 包裹 1 个关键词做渐变强调（保留 span）
  - `attribution` 格式「人物 · 头衔」或「— 来源」，控制在 25 字以内
  - 引言过长（>40 字）时下调 `font-size:52px`（保持 `line-height:1.32`）
- **卡片扩展/收缩**：不适用

### `stat_hero`
- **源文件**：`slides/08-stat-hero.html`
- **页面类型**：内容页（左大数字 + 右力导向插图，左右分栏）
- **可替换键**：`slide_number`, `kicker`, `stat_value`, `stat_headline`, `stat_desc`, `graph_caption`
- **不可改动**：左右分栏 flex 结构（左 `flex:1.05` / 右 `flex:1`，`gap:64px`）、`.gd-big.gd-grad` 数字样式（`font-size:188px`）、右侧 SVG 力导向图（`viewBox 0 0 720 720`/全部 line/circle 坐标和 fill 配色/`opacity:.82`）、`stat_desc` 的 `max-width:560px` 限宽、插图 `width:600px`
- **内容适配规则**：
  - `stat_value` 紧凑数字+单位（如 "10,000+" "300×" "∞"），使用 `.gd-grad` 渐变
  - `stat_headline` 一句话副标，控制在 25 字以内；用 `<span class="gd-accent">` 包裹高亮短语
  - `stat_desc` 补充说明，控制在 50 字以内（`max-width:560px` 内两~三行）
  - `graph_caption` 一行图注，控制在 15 字以内
- **卡片扩展/收缩**：不适用（单插图页）；如不需要插图可删除右栏并将左栏 `flex` 改为默认（撑满），下移数字

### `timeline`
- **源文件**：`slides/10-timeline.html`
- **页面类型**：内容页（水平时间轴：日期行 / 渐变基线+节点行 / 卡片行，三行 grid）
- **可替换键**：`slide_number`, `kicker`, `section_title`, `ms_date_1`~`ms_date_4`, `ms_title_1`~`ms_title_4`, `ms_desc_1`~`ms_desc_4`
- **不可改动**：三行 grid 结构（日期行 / 节点行 / 卡片行，均 `repeat(4,1fr)`）、节点行绝对定位渐变基线（`left:12.5%;right:12.5%` + `linear-gradient(90deg,warm,blue,green,purple)`）、节点圆样式（22px 圆 + `box-shadow:0 0 0 7px rgba(.16)` 光晕）、日期 mono 字体、卡片颜色变体分布（warm/blue/green/purple）
- **内容适配规则**：
  - `ms_date_N` 版本/日期（如 "v1.0 · 2026-01"），控制在 15 字以内
  - `ms_title_N` 控制在 6 字以内
  - `ms_desc_N` 控制在 14 字以内（单行）
  - 节点数默认 4 个，扩展/收缩时必须同步改 3 行 grid 的 `repeat()` 列数与基线 `left/right` 百分比
- **卡片扩展/收缩**：
  - 收缩为 3 节点：三行 grid 均 `repeat(3,1fr)`，基线改 `left:16.6%;right:16.6%`，删第 4 列
  - 扩展为 5 节点：三行 grid 均 `repeat(5,1fr)`，基线改 `left:10%;right:10%`，末列新增

### `cta`
- **源文件**：`slides/11-cta.html`
- **页面类型**：行动号召
- **可替换键**：`slide_number`, `kicker`, `title`, `install_command`, `run_command`, `tags`
- **不可改动**：`.gd-cmd` 样式（neon glow text-shadow 分别用 green 和 warm 色）、`.gd-tag` pill 样式（`border-radius:1330px`/半透明底/玻璃边框）、`.gd-grad` span 结构、h1 `font-size: 106px`
- **内容适配规则**：
  - `title` 中 `<span class="gd-grad">` 包裹 1~3 词做渐变强调
  - `install_command` 和 `run_command` 保留 `$` 前缀和完整 CLI 命令格式
  - 两条命令呈现 "安装 → 使用" 的递进关系
  - `tags` 整个容器替换为新的 `.gd-tag` 列表，标签数量 3~6 个，每个前面保留 `#`
- **卡片扩展/收缩**：tags 容器内 `.gd-tag` 按需增删，3~6 个标签

### `thanks`
- **源文件**：`slides/12-thanks.html`
- **页面类型**：结束页（末页）
- **可替换键**：`slide_number`, `thanks_message`, `thanks_detail`
- **不可改动**：`.gd-big.gd-rainbow` 大字样式（`font-size:239px`/`font-weight:900`/`letter-spacing:-.04em` rainbow 动画）、居中容器 `text-align:center` + `margin:auto 0` 垂直居中
- **内容适配规则**：
  - `thanks_message` 保持单英文单词风格（如 "Thanks." "Thank You."），使用 `.gd-rainbow` 动画渐变
  - `thanks_detail` 包含项目链接 / 联系方式，控制在 50 字以内（单行）
- **卡片扩展/收缩**：不适用

---

## 角色匹配决策树

```
用户文稿类型是什么？
├── 技术分享 / 工具宣讲 / 开源项目介绍
│   ├── 需要封面 → `cover`（01）
│   ├── 开场给目录 → `agenda`（03）
│   ├── 需要章节过渡 → `section_divider`（02）
│   ├── 展示多个并列特性（4个）→ `feature_cards`（04）
│   ├── 展示终端命令 + 配置文件 → `code_showcase`（05）
│   ├── 对比（有无/前后/新旧）→ `comparison_chart`（06）
│   ├── 展示流程/步骤（3~5步）→ `pipeline_steps`（07）
│   ├── 单个核心数据 + 视觉焦点 → `stat_hero`（08）
│   ├── 放一句金句/权威引用 → `quote`（09）
│   ├── 演进/版本/路线图 → `timeline`（10）
│   ├── 结尾行动号召 → `cta`（11）
│   └── 结尾感谢（末页）→ `thanks`（12）
└── 其他文稿类型 → 不推荐此模板（建议换用 pitch-deck / course-module 等）
```

---

## Style Transfer — T2 页面继承规则

当在 `graphify-dark-graph` 模板骨架内创作新页面（或从其他模板迁入页面）时，必须遵守以下继承规则以确保视觉一致性：

### 空间密度对齐
- **页面 padding**：`padding: 85px 130px`（body 级，所有页面统一）
- **卡片内 padding**：`.gd-glass` 统一 `padding: 29px 39px`
- **卡片圆角**：`.gd-glass` 统一 `border-radius: 27px`，`.gd-codebox` 统一 `border-radius: 19px`
- **网格间距**：`.gd-grid-3` gap 21px，`.gd-grid-4` gap 19px

### 装饰模式继承
- **环境氛围层**：所有页面必须保留 `.gd-ambient` + `.gd-orb` 结构（至少 1 个 orb），orb 数量 1~3 按视觉密度需求选择
- **SVG 力导向图**：仅在 `cover` 页面使用，其他页面不得引入 SVG 力导向图
- **玻璃卡片**：`.gd-glass` 为通用容器，颜色变体（`-warm` / `-blue` / `-green`）用于区分信息层级，不得混用超过 3 种变体在同一网格中
- **渐变文字**：`.gd-grad`（静态渐变）用于章节标题关键词，`.gd-rainbow`（动画彩虹）仅用于封面和结束页的大字

### 组件类名统一
- 页面级标题：`h1.gd-h1`（封面/分隔/CTA）或 `h2.gd-h2`（内容页）
- 副标题/引言：`p.gd-lede`
- 小标签/眉题：`p.gd-eyebrow` 或 `div.gd-eyebrow`
- 调暗正文：`p.gd-dim` 或 `div.gd-dim`
- 强调关键词：`span.gd-accent`
- 命令行：`p.gd-cmd`
- 代码块：`pre.gd-codebox` + 语法高亮 span class（`.cm` `.kw` `.st` `.fn`）
- 标签：`span.gd-tag`
- 大数字：`div.gd-big` + `.gd-grad`
- 页码：`div.gd-snum`
- 内联 SVG 图标：`<svg class="gd-ico gd-ico-28|-40|-45|-64">`，`fill` 内联指向 `--gd-*` 色变量（替代 emoji，暗底玻璃卡上可见）
- 双栏对比网格：`.gd-grid-2`（`1fr | auto | 1fr`，中间列放→/分隔）

### 排版层级对齐
- h1 封面标题：98~160px / 800~900wt / line-height 1.05~1.08 / `letter-spacing:-.02em`
- h2 内容标题：69~72px / 700wt / line-height 1.1~1.12
- h4 卡片标题：29px / 600wt / line-height 1.3（inline style `margin: 13px 0 6.5px`）
- lede 引言：29px / 300wt / line-height 1.55~1.65 / `color:var(--gd-text2)`
- 代码/命令：JetBrains Mono / 19px(codebox) 或 43px(cmd)
- eyebrow：18px / 500wt / `letter-spacing:.2em` / uppercase / `color:var(--gd-text3)`

### 禁止引入的视觉元素
- **白色/浅色背景**：不兼容暗色渐变底，禁止使用白色卡片（`.card` / `.surface`）或亮色背景区域
- **硬阴影**：禁止使用 `box-shadow` 替代 `.gd-glass` 的 glass-morphism 阴影（包含 `inset` 高光）
- **标准系统字体栈**：必须使用 `Inter` + `Noto Sans SC`（由 tokens.css 全局注入），禁止覆盖 font-family
- **实色背景卡片**：禁止使用 `background: #fff` 或 `background: var(--surface)` 的卡片替代玻璃卡片
- **细线分隔线**：禁止使用 `border-bottom: 1px solid` 作为内容分隔，应使用玻璃卡片间自然间隙
