# presenter-mode-reveal — Slide Role Catalog

> **模板气质**：演讲者模式/技术分享风，深色 Tokyo Night 主题，等宽字体 kicker，代码块演示，大字号逐字稿驱动，S 键演讲者视图，T 键主题切换
> **默认 color-scheme**：tokyo-night（深色蓝紫基调，`--bg: #1a1b26`）
> **适用文稿类型**：传授/赋能（tech talk / 产品主讲 / 课程讲授）
> **叙事结构**：Cover → Agenda → 〔Part01 章节 → Problem(3card) → Stat(数字)〕→ 〔Part02 章节 → Diagram(SVG四象限) → Features(2×2)〕→ 〔Part03 章节 → Rules(3铁律) → Quote(引用) → Timeline(流程)〕→ 〔Part04 章节 → Demo(代码)〕→ Thanks/Q&A

## 角色索引（15 页）

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面(speaker+gradient title+instructions) | .kicker, .h1(anim-rise-in+gradient span), .lede, .speaker(.av+b+span), .deck-footer |
| 02 | `agenda` | 议程列表(5 行编号+标题+时长) | .kicker, .h2, .agenda-row(.num+.t+.d), .anim-stagger-list |
| 03 | `section` | 章节过渡页 Part 01(大号编号+标题) | .pm-center, .pm-section-num, .kicker, .h1(gradient span), .lede |
| 04 | `comparison` | 三卡片对比(做得好/讲得好/差别) | .kicker, .h2(.accent), .card.card-accent(h4含 inline SVG icon+p.dim) |
| 05 | `stat` | 数据高亮(3 大数字横排) | .kicker, .h2(.accent), .grid.g3, .pm-stat(.num+.unit+.label) |
| 06 | `section` | 章节过渡页 Part 02 | .pm-center, .pm-section-num, .kicker, .h1(gradient span), .lede |
| 07 | `diagram` | **SVG 插图**(演讲者视图四象限) | .kicker, .h2(.accent), .pm-figure>.pm-figure-media>svg.anim-path-draw(.pm-box/.pm-box-key/.pm-lbl/.pm-sub/.pm-edg), .pm-figure-caption |
| 08 | `features` | 四特征网格(2×2, 彩色编号) | .kicker, .h2(.accent), .grid.g2, .feature-row(.num.blue/.green/.orange/.purple+b+p.dim) |
| 09 | `section` | 章节过渡页 Part 03 | .pm-center, .pm-section-num, .kicker, .h1(gradient span), .lede |
| 10 | `rules` | 三条规则/铁律(编号+标题+说明) | .kicker, .h2(.accent), .rule-row(.num.red+b(.accent)+p.dim), .anim-stagger-list |
| 11 | `quote` | 引用页(serif 大字+装饰引号+cite) | .kicker, .pm-quote(::before引号+blockquote(.accent)+cite), |
| 12 | `timeline` | 横向流程时间线(4 节点) | .kicker, .h2(.accent), .pm-timeline>.pm-tl-node(.dot+.pm-tl-when/name/note) |
| 13 | `section` | 章节过渡页 Part 04 | .pm-center, .pm-section-num, .kicker, .h1(gradient span), .lede |
| 14 | `demo` | 代码演示(code block + takeaway lede) | .kicker, .h2(.accent), .code-block(.comment+.cmd+.flag), .lede.tc, .deck-footer |
| 15 | `thanks` | 致谢/Q&A 收尾(居中渐变 Thanks.) | .pm-thanks, .kicker, .h1(gradient span), .lede, .deck-footer |

> `section` 角色复用 4 次（Part 01–04），结构相同、内容不同；`comparison`/`features`/`rules`/`demo` 为既有页（仅重命名+页码同步）。

## 特殊机制：aside.notes 逐字稿 + 演讲者模式

### 逐字稿（`<aside class="notes">`）

每页 `<aside class="notes">` 写 150–300 字口语化逐字稿。三条铁律：
1. **不是讲稿，是提示信号** — 核心点加粗，过渡句成段，数据列清楚
2. **150–300 字/页** — 按 2–3 分钟/页的节奏控制
3. **用口语写** — "因此" → "所以"；"该方案" → "这个方案"

支持的 inline 标签：`<strong>`(高亮)、`<em>`(斜体强调)、`<code>`(等宽)、`<p>`(分段)。

CSS 默认 `.notes, aside.notes { display:none!important }`，观众永远看不到。演讲者模式（S 键）从 iframe DOM 中提取 `.notes` 内容并显示在大字号区域。

### 演讲者模式功能（不在 slides 中）

以下功能在 `index.html`（手写 iframe 列表 + 内联 runtime）中实现，不在 slide HTML 文件中：

- **S 键** — 打开演讲者窗口（弹出新窗口，原页面保持观众视图）
- **T 键** — 循环切换 5 种预设主题（tokyo-night, dracula, catppuccin-mocha, nord, corporate-clean）
- **N 键** — 底部 notes 浮层（观众端预览逐字稿）
- **F 键** — 全屏；**← → / Space** — 翻页；**Esc** — 退出

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **页面类型**：封面 · **视觉等级**：L3
- **可替换键**：`kicker`, `headline`, `headline_accent`, `instructions`, `speaker_name`, `speaker_meta`, `footer_tags`
- **不可改动**：body class(`tpl-presenter-mode-reveal`)、.h1 的 anim-rise-in 动画、.speaker .av 装饰圆形渐变、.deck-footer 位置、gradient span 的 inline style（保留 `background:var(--grad); -webkit-background-clip:text; background-clip:text; color:transparent`）
- **内容适配规则**：`headline` 含一个 `<span style="background:var(--grad);...">` 包裹的 accent 词；标题总字数 ≤20 字（超出用 `<br>` 拆行）；`instructions` 保留 `.mono` 快捷键；`speaker_name` 格式 `"@username"`；`footer_tags` 3~5 个 hashtag

### `agenda`
- **源文件**：`slides/02-agenda.html`
- **页面类型**：内容页（议程列表）· **视觉等级**：L1
- **可替换键**：`kicker`, `section_title`, `item_1..5_num`, `item_1..5_title`, `item_1..5_duration`
- **不可改动**：.agenda-row 的 grid 布局（`grid-template-columns: 65px 1fr auto`）、.stack 结构、.num/.d 等宽字体
- **卡片扩展/收缩**：议程项数 3~8，增删 `.agenda-row`，保持 grid 列结构

### `section`（章节过渡页，复用 4 次：03/06/09/13）
- **源文件**：`slides/03-section-problem.html`（及 06/09/13，同结构换内容）
- **页面类型**：章节过渡 · **视觉等级**：L2
- **可替换键**：`section_num`(01-04), `kicker`, `section_title`, `section_title_accent`, `section_lede`, `footer_tags`
- **不可改动**：`.pm-center` 居中包裹、`.pm-section-num` 大号 mono 编号样式、.h1 的 anim-rise-in、gradient span 的 inline style
- **内容适配规则**：`section_num` 两位数（01-04）；`section_title` 用 `<br>` 拆两行，含一个 gradient span accent 词；`section_lede` ≤40 字一句话章节摘要
- **机制**：section 角色对应议程的一个"part"，在内容页之间制造节奏。四张同结构不同内容，是 PPT 模板的章节过渡板式

### `comparison`
- **源文件**：`slides/04-problem.html`
- **页面类型**：内容页（三卡片对比）· **视觉等级**：L1
- **可替换键**：`kicker`, `section_title`, `section_title_accent`, `card_1..3_title`(含 inline SVG icon), `card_1..3_body`
- **不可改动**：.grid.g3 三列结构、.card.card-accent 样式（顶部 3px accent 色条）、h4(25px)、.dim(19px)
- **卡片图标**：卡片标题用 **inline `<svg>`**（check/x/lightbulb glyph，stroke 跟随 `var(--brand-*)` 主题色）。**不要换回 `<img src="../assets/icons/...">`**——该路径在本 deck 是 404 坏链，inline SVG 才正确
- **卡片扩展/收缩**：4 卡→`.grid.g4`，2 卡→`.grid.g2`，不可收缩为 1 卡

### `stat`
- **源文件**：`slides/05-stat.html`
- **页面类型**：内容页（数据高亮）· **视觉等级**：L1
- **可替换键**：`kicker`, `section_title`, `section_title_accent`, `stat_1..3_value`(可含 `.unit` 子 span), `stat_1..3_label`
- **不可改动**：`.grid.g3` 三列、`.pm-stat` 顶部 2px accent 实线、`.pm-stat .num`(mono clamp 80-124px accent 色)、`.pm-stat .label`(22px text-2)
- **内容适配规则**：`stat_N_value` 大数字（可带 `<span class="unit">%</span>`/`字`/`min` 单位）；`stat_N_label` ≤30 字说明
- **卡片扩展/收缩**：2 数字→`.grid.g2`，4 数字→`.grid.g4`；单数字 hero 可去掉 grid，直接一个居中 `.pm-stat`

### `diagram`（核心 SVG 插图）
- **源文件**：`slides/07-diagram.html`
- **页面类型**：内容页（SVG 插图）· **视觉等级**：L2
- **可替换键**：`kicker`, `section_title`, `section_title_accent`, `figure_media`(整个 `<svg>`)、`figure_caption`
- **不可改动**：`.pm-figure`/`.pm-figure-media` 容器、`<svg>` 的 `class="anim-path-draw"`（路径绘制入场动效）、`role="img"`+`aria-label` 无障碍属性、SVG 内部类名（`.pm-box`/`.pm-box-key`/`.pm-lbl`/`.pm-lbl-key`/`.pm-sub`/`.pm-edg`，由 tokens.css 主题色驱动）
- **关键约定**：
  - **一律 inline `<svg>`**，不要用 `<img src="...svg">`（本 deck 的 `<img>` 图标路径是 404 坏链，已废弃）
  - SVG 内部样式由 tokens.css 的 `.tpl-presenter-mode-reveal .pm-figure-media svg .pm-*` 作用域定义，用 `var(--accent)`/`var(--brand-*-rgb)`/`var(--text-*)`，**T 键换肤时插图自动跟随**
  - viewBox 按内容算尺寸（本页 `0 0 920 460`），CSS `width:100%; height:auto; max-height:560px` 自适应
  - `.pm-box-key`（accent 边 + 半透明 accent 填充）用于强调重点象限；`.pm-edg` 虚线做分隔/连接
- **替换 SVG 内容**：改 `<svg>...</svg>` 内的 `<rect>`/`<text>`/`<path>` 即可换插图；保留类名以维持主题色

### `features`
- **源文件**：`slides/08-features.html`
- **页面类型**：内容页（四特征网格 2×2）· **视觉等级**：L1
- **可替换键**：`kicker`, `section_title`, `section_title_accent`, `feature_1..4_title`, `feature_1..4_desc`
- **不可改动**：.grid.g2 两列、.feature-row 的 flex 布局和底部边框分隔线、.num 颜色类名(.blue/.green/.orange/.purple)
- **卡片扩展/收缩**：6 特征→每列 3 个；2 特征→每列 1 个

### `rules`
- **源文件**：`slides/10-rules.html`
- **页面类型**：内容页（三条规则/铁律）· **视觉等级**：L1
- **可替换键**：`kicker`, `section_title`, `section_title_accent`, `rule_1..3_title`(含 accent span), `rule_1..3_desc`
- **不可改动**：.stack 结构、.rule-row 的 grid 布局（`75px 1fr`）、.num(.red) 字号(38px)字重(800)
- **卡片扩展/收缩**：规则数 2~5，增删 `.rule-row`
- **复用提示**：竖向步骤流可直接复用 `.rule-row`（同结构），不必新建类

### `quote`
- **源文件**：`slides/11-quote.html`
- **页面类型**：内容页（引用）· **视觉等级**：L2
- **可替换键**：`kicker`, `quote_text`(blockquote，含 `.accent` 关键词), `quote_cite`(含 `<b>` 出处), `footer_tags`
- **不可改动**：`.pm-quote` 的 `::before` 装饰大引号（`\201C`、`--font-serif`、`--accent` opacity .38）、blockquote 的 serif 字体 + clamp(40-62px)、cite 的 mono 字体
- **内容适配规则**：`quote_text` ≤50 字，关键词用 `<span class="accent">`；`quote_cite` 格式 `"— <b>人名/出处</b> · 补充说明"`

### `timeline`
- **源文件**：`slides/12-timeline.html`
- **页面类型**：内容页（横向流程时间线）· **视觉等级**：L1
- **可替换键**：`kicker`, `section_title`, `section_title_accent`, `step_1..4_when`, `step_1..4_name`, `step_1..4_note`
- **不可改动**：`.pm-timeline` 的 `grid-template-columns: repeat(4,1fr)`、`::before` 横线（穿过 dot 中心，对齐公式 padding-top 50 + dot 半径 11 = 61px）、`.pm-tl-node .dot` 圆点、`.done` 状态色（`--brand-good`）
- **内容适配规则**：`step_N_when` 格式 `"step 0X · 阶段名"`（mono uppercase）；`step_N_name` ≤10 字；`step_N_note` ≤40 字
- **状态**：已完成节点加 `.done`（dot 变绿），当前/未来节点不加（dot 为 accent 色）
- **卡片扩展/收缩**：3 节点→`grid-template-columns: repeat(3,1fr)`；5 节点→`repeat(5,1fr)`，横线对齐公式不变

### `demo`
- **源文件**：`slides/14-demo.html`
- **页面类型**：内容页（代码演示 + takeaway）· **视觉等级**：L2
- **可替换键**：`kicker`, `section_title`, `section_title_accent`, `code_block`(容器), `code_comment_*`/`code_cmd_*`/`code_flag_*`, `closing_lede`, `footer_tags`
- **不可改动**：.code-block 样式（深色底 `var(--brand-bg)`、圆角 16px、等宽 20px、行高 1.8）、.comment/.cmd/.flag 颜色类名、.lede.tc 居中样式
- **内容适配规则**：代码块用 `.comment`(灰)/`.cmd`(绿)/`.flag`(橙) 三种 span 保持语法高亮，5~15 行；`closing_lede` ≤50 字含 `<strong>`
- **与 thanks 的分工**：demo 页的 footer 用 `#demo` 类标签；Q&A/致谢收尾交给独立的 `thanks` 页（15）

### `thanks`
- **源文件**：`slides/15-thanks.html`
- **页面类型**：致谢/Q&A 收尾 · **视觉等级**：L2
- **可替换键**：`kicker`(`// end · Q&A`), `thanks_message`/`thanks_accent`(gradient span), `thanks_detail`, `footer_tags`(`#thanks · Q&A`)
- **不可改动**：`.pm-thanks` 居中包裹、.h1 的 anim-rise-in、gradient span 的 inline style、.deck-footer 位置
- **机制**：与 cover 呼应——同样的 `.h1` + inline gradient span 结构，作为全 deck 的收尾闭环

---

## 角色匹配决策树

1. 用户 slide 是封面 → `cover`
2. 用户 slide 是议程/目录列表 → `agenda`
3. 用户 slide 是章节过渡/大编号分节 → `section`（复用结构，换 section_num + 内容）
4. 用户 slide 有三张对比卡片（优劣/前后/方案对比） → `comparison`
5. 用户 slide 是大数字/数据强调（1~4 个 KPI） → `stat`
6. 用户 slide 是**示意图/架构图/流程图/插图**（SVG 画） → `diagram`
7. 用户 slide 有四特征/要点网格（2×2 矩阵式） → `features`
8. 用户 slide 有三条规则/原则/铁律（或竖向步骤流） → `rules`
9. 用户 slide 是金句/引用/名言 → `quote`
10. 用户 slide 是横向流程/时间线/路线图 → `timeline`
11. 用户 slide 是代码演示/live demo → `demo`
12. 用户 slide 是致谢/结束/Q&A → `thanks`
13. 以上都不匹配 → 降级到 T2 layout-catalog 通用骨架（应用下方 Style Transfer 规则）

---

## Style Transfer — T2 页面继承规则

当 deck 中存在 T2 页面（从 layout-catalog 生成的非模板页面）时，以下规则确保它们与 presenter-mode-reveal 模板页面的视觉语言一致。

### 空间密度对齐
- 内容区 body padding：对齐 `96px 142px`
- 卡片间距：对齐 `.grid` gap 值 = 27px
- 标题与内容间距：.mt-s = 13px, .mt-m = 27px, .mt-l = 43px

### 装饰模式继承
- **Kicker 标签**：T2 内容页顶部用 `<p class="kicker">`（等宽字体、18px、--text-3 色、0.14em 字距、uppercase）
- **标题 accent 词**：用 `<span class="accent">` 包裹关键词（颜色 var(--accent)、字重 700），不使用 `.gradient-text`
- **代码块**：用 `.code-block`（深色底 + 三种语法高亮 span），不使用 `.terminal`
- **SVG 插图**：一律 **inline `<svg>`**（不要 `<img src="../assets/...">`，该路径在本 deck 是 404 坏链）；容器用 `.pm-figure`/`.pm-figure-media`；内部样式用 `.pm-*` 类（由 tokens.css 主题色驱动）
- **底部 footer**：用 `.deck-footer`（绝对定位 bottom:32px, left:59px, right:59px），含 `.mono` 标签和 `.slide-number`

### 组件类名统一
- 卡片用 `.card.card-accent`（深色 surface 底 + 顶部 3px accent 色条）
- 列表行用 `.rule-row` 或 `.agenda-row`（grid 布局 + border + border-radius + surface 背景）
- 特征项用 `.feature-row`（flex 布局 + 底部 border 分隔线）
- 数据高亮用 `.pm-stat`（顶部 2px accent 实线 + mono 大数字）
- 引用用 `.pm-quote`（::before 装饰引号 + serif blockquote + mono cite）
- 时间线用 `.pm-timeline`（横向 grid + 穿 dot 中心横线）
- 章节过渡用 `.pm-center` + `.pm-section-num` + `.h1`(inline gradient span)

### 排版层级对齐
- Kicker：等宽字体、18px、--text-3、0.14em 字距、uppercase
- 章节大编号（`.pm-section-num`）：等宽、clamp(120-200px)、--text-3 opacity .5
- 内容页标题：h2, `clamp(43px, 3.6vw, 65px)`, weight 700, letter-spacing -0.01em
- 正文色：--text-2，用 class `.dim`
- 辅助文字：--text-3，用 class `.dim2`
- 强调色：--accent，用 class `.accent`
- 等宽文字：用 class `.mono`（0.9em 字号、8px 圆角背景、accent 色）

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| `<img src="../assets/icons/...">` | 本 deck 无 assets/ 目录，该相对路径 404。图标/SVG 一律 inline `<svg>` |
| .section-num / .num-tag | presenter-mode-reveal 用 `.kicker` + `.pm-section-num` 做章节标识 |
| .gradient-text | presenter-mode-reveal 用 inline style gradient + `.accent` class |
| .terminal | presenter-mode-reveal 用 `.code-block`（无 macOS chrome 的纯代码块） |
| .pill / .pill-accent | presenter-mode-reveal 无 pill 标签组件 |
| .glass / 玻璃拟态卡片 | presenter-mode-reveal 无此视觉语言 |
| .cover-bg / .cover-blob | 封面装饰仅限 cover 页的 gradient title span |
| .icon-halo / .dot-cluster | 装饰极简，不引入额外视觉噪音 |
