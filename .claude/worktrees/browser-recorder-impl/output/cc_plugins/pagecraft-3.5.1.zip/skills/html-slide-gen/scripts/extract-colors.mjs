#!/usr/bin/env node
/**
 * extract-colors.mjs — 从参考文件提取配色，生成与 color-schemes.json 兼容的自定义色板
 *
 * 用法：
 *   # PPTX 输入（调用 pptx_to_template.py --style-only）
 *   node extract-colors.mjs --input reference.pptx --output custom-scheme.json
 *
 *   # 直接传入色值（AI 视觉分析图片后使用）
 *   node extract-colors.mjs \
 *     --colors '{"primary":"#1A3A5C","secondary":"#E8F0F8","accent":"#F5A623"}' \
 *     --output custom-scheme.json
 *
 *   # 保存到 color-schemes.json 的 custom 分组
 *   node extract-colors.mjs --input ref.pptx --output custom-scheme.json \
 *     --save --name "企业品牌蓝-2026"
 */

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import { spawnSync } from 'child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── CLI arg parsing ──────────────────────────────────────────────────────────

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (!next || next.startsWith('--')) {
        args[key] = true;
      } else {
        args[key] = next;
        i++;
      }
    }
  }
  return args;
}

const args = parseArgs(process.argv.slice(2));

if (!args.output) {
  console.error('错误: 缺少 --output 参数');
  console.error('用法: node extract-colors.mjs --input ref.pptx --output custom-scheme.json');
  process.exit(1);
}

if (!args.input && !args.colors) {
  console.error('错误: 需要 --input（PPTX 文件路径）或 --colors（JSON 色值字符串）之一');
  process.exit(1);
}

// ── Color math helpers ───────────────────────────────────────────────────────

function hexToRgb(hex) {
  const h = hex.replace('#', '');
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ];
}

function rgbToHex(r, g, b) {
  return '#' + [r, g, b].map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
}

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;
  if (max === min) {
    h = s = 0;
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  return [h * 360, s * 100, l * 100];
}

function hslToRgb(h, s, l) {
  h /= 360; s /= 100; l /= 100;
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}

/** 生成 hi-strong：accent 降低亮度 15%（hover/pressed 状态） */
function deriveHiStrong(accentHex) {
  const [r, g, b] = hexToRgb(accentHex);
  const [h, s, l] = rgbToHsl(r, g, b);
  const newL = Math.max(0, l - 15);
  return rgbToHex(...hslToRgb(h, s, newL));
}

/**
 * 生成 data-1..6：以 primary 为锚，色相环均匀分布 6 色
 * 保持接近 primary 的饱和度和亮度，确保视觉协调
 */
function deriveDataColors(primaryHex) {
  const [r, g, b] = hexToRgb(primaryHex);
  const [h, s, l] = rgbToHsl(r, g, b);
  // 目标饱和度/亮度：适合图表的中等对比（不要太浅也不要太深）
  const targetS = Math.max(40, Math.min(70, s));
  const targetL = Math.max(35, Math.min(55, l));
  // 6 色均匀分布，第一色与 primary 同色相
  return Array.from({ length: 6 }, (_, i) => {
    const hue = (h + i * 60) % 360;
    return rgbToHex(...hslToRgb(hue, targetS, targetL));
  });
}

/** 计算 rgb 字符串 "r,g,b" */
function toRgbStr(hex) {
  return hexToRgb(hex).join(',');
}

// ── Step 1: 获取原始色值 ─────────────────────────────────────────────────────

let rawColors;

if (args.colors) {
  // 直接传入色值（AI 视觉分析图片后使用）
  try {
    rawColors = JSON.parse(args.colors);
  } catch (e) {
    console.error('错误: --colors 参数不是合法 JSON');
    process.exit(1);
  }
  if (!rawColors.primary) {
    console.error('错误: --colors JSON 必须包含 primary 字段');
    process.exit(1);
  }
  console.log('✓ 使用传入色值（AI 视觉分析）');
} else {
  // PPTX 输入：调用 pptx_to_template.py --style-only
  const inputPath = path.resolve(args.input);
  if (!fs.existsSync(inputPath)) {
    console.error(`错误: 找不到输入文件: ${inputPath}`);
    process.exit(1);
  }

  // 找 pptx_to_template.py
  const scriptPath = path.resolve(__dirname, '../../ppt-generator/scripts/pptx_to_template.py');
  if (!fs.existsSync(scriptPath)) {
    console.error(`错误: 找不到 pptx_to_template.py: ${scriptPath}`);
    console.error('请确认 ppt-generator skill 已正确安装');
    process.exit(1);
  }

  const tmpDir = path.join(path.dirname(args.output), '.extract-colors-tmp');
  fs.mkdirSync(tmpDir, { recursive: true });

  console.log(`正在提取配色: ${path.basename(inputPath)} …`);
  const result = spawnSync('python3', [scriptPath, inputPath, '-o', tmpDir, '--style-only'], {
    encoding: 'utf-8',
    stdio: 'pipe',
  });

  if (result.status !== 0) {
    console.error('错误: pptx_to_template.py 执行失败');
    console.error(result.stderr);
    process.exit(1);
  }

  // 读取 style/template_data.json
  const tdPath = path.join(tmpDir, 'style', 'template_data.json');
  if (!fs.existsSync(tdPath)) {
    console.error(`错误: 未找到提取结果: ${tdPath}`);
    process.exit(1);
  }
  const td = JSON.parse(fs.readFileSync(tdPath, 'utf-8'));
  rawColors = {
    primary: td.colors.primary,
    secondary: td.colors.secondary,
    accent: td.colors.accent,
    background: td.colors.background,
  };

  // 质量评估
  const qa = td.input_assessment;
  if (qa.quality === 'poor') {
    console.error(`\n⚠️  质量评估: poor — ${qa.note}`);
    console.error('建议改用预置颜色方案，或提供配色更丰富的参考文件。');
    console.error('如需强制继续，在脚本调用时加 --force 参数。');
    if (!args.force) {
      fs.rmSync(tmpDir, { recursive: true, force: true });
      process.exit(1);
    }
    console.warn('--force 已指定，强制继续（结果可能不准确）');
  } else if (qa.quality === 'limited') {
    console.warn(`⚠️  质量评估: limited — ${qa.note}`);
    console.warn('   提取结果可能不够准确，建议用户确认后再继续。');
  }

  // 打印提取结果
  const stdout = result.stdout.trim();
  if (stdout) console.log(stdout);

  // 清理临时目录
  fs.rmSync(tmpDir, { recursive: true, force: true });
}

// ── Step 2: 映射为完整 color-scheme tokens ───────────────────────────────────

const primary   = rawColors.primary   || '#1A3A5C';
const secondary = rawColors.secondary || '#E8F0F8';
const accent    = rawColors.accent    || '#F5A623';
const bg        = rawColors.background || '#FFFFFF';

const hiStrong = deriveHiStrong(accent);
const dataColors = deriveDataColors(primary);

// 从 primary 推导文字色
const [pr, pg, pb] = hexToRgb(primary);
const [, , pl] = rgbToHsl(pr, pg, pb);
const brandText = pl < 50 ? primary : '#1a1a1a';  // 深色主色可直接作为文字色
const brandTextDim = '#425466';
const brandTextFaint = '#8898aa';

// 从 secondary 推导 surface/border
const brandSurface = secondary;
const [sr, sg, sb] = hexToRgb(secondary);
const borderOpacity = 0.18;

const scheme = {
  name: args.name || 'custom-from-reference',
  label: args.label || '参考文件提取配色',
  mood: ['自定义'],
  bestFor: ['参考文件提取'],
  source: 'extracted',
  isDark: pl < 40,
  tokens: {
    'brand-primary':       primary,
    'brand-secondary':     secondary,
    'brand-accent':        accent,
    'brand-bg':            bg,
    'brand-surface':       brandSurface,
    'brand-text':          brandText,
    'brand-text-dim':      brandTextDim,
    'brand-text-faint':    brandTextFaint,
    'brand-border':        `rgba(${toRgbStr(primary)},${borderOpacity})`,
    'border-strong':       `rgba(${toRgbStr(primary)},0.30)`,
    'brand-good':          '#0e9f6e',
    'brand-warn':          '#d97706',
    'brand-bad':           '#dc2626',
    'brand-gradient':      `linear-gradient(135deg,${primary},${secondary})`,
    'grad-soft':           `linear-gradient(135deg,${bg},${secondary})`,
    'brand-primary-rgb':   toRgbStr(primary),
    'brand-secondary-rgb': toRgbStr(secondary),
    'brand-accent-rgb':    toRgbStr(accent),
    'brand-good-rgb':      '14,159,110',
    'brand-warn-rgb':      '217,119,6',
    'brand-bad-rgb':       '220,38,38',
    'brand-text-rgb':      toRgbStr(brandText),
    'hi-strong':           hiStrong,
    'hi-strong-rgb':       toRgbStr(hiStrong),
    'data-1':              dataColors[0],
    'data-2':              dataColors[1],
    'data-3':              dataColors[2],
    'data-4':              dataColors[3],
    'data-5':              dataColors[4],
    'data-6':              dataColors[5],
    'hi-positive':         '#2d962c',
    'hi-positive-rgb':     '45,150,44',
    'hi-warning':          '#962c2f',
    'hi-warning-rgb':      '150,44,47',
  },
};

// ── Step 3: 写入 output JSON ──────────────────────────────────────────────────

const outputPath = path.resolve(args.output);
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(scheme, null, 2), 'utf-8');
console.log(`✓ 自定义色板已生成: ${outputPath}`);
console.log(`  主色: ${primary}  辅色: ${secondary}  强调色: ${accent}`);
console.log(`  hi-strong: ${hiStrong}  data-1..6: ${dataColors.join(' ')}`);

// ── Step 4: 可选 —— 保存到 color-schemes.json 的 custom 分组 ─────────────────

if (args.save) {
  const schemesPath = path.join(__dirname, 'color-schemes.json');
  if (!fs.existsSync(schemesPath)) {
    console.error(`错误: 找不到 color-schemes.json: ${schemesPath}`);
    process.exit(1);
  }
  const all = JSON.parse(fs.readFileSync(schemesPath, 'utf-8'));
  if (!all.custom) all.custom = [];

  // 去重：相同 name 则更新
  const existingIdx = all.custom.findIndex(s => s.name === scheme.name);
  // --id override, or slugify name; fall back to timestamp when name has no ASCII letters (e.g. Chinese)
  const rawSlug = scheme.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  const schemeId = args.id || (rawSlug.length >= 2 ? rawSlug : `custom-${Date.now()}`);
  const entry = { id: schemeId, ...scheme };
  if (existingIdx >= 0) {
    all.custom[existingIdx] = entry;
    console.log(`✓ 已更新 color-schemes.json 中的 custom 条目: ${scheme.name}`);
  } else {
    all.custom.push(entry);
    console.log(`✓ 已追加到 color-schemes.json custom 分组: ${scheme.name}`);
  }
  fs.writeFileSync(schemesPath, JSON.stringify(all, null, 2), 'utf-8');
}
