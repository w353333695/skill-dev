# consultant-strategy — Slide Role Catalog

> **模板气质**：高端咨询风（麦肯锡/BCG 调性）—— 白底 + 品牌蓝 + amber 数据强调、硬边卡片、无阴影、紧凑排版、结论先行（Pyramid Principle）、MECE 结构化。
> **默认 color-scheme**：`mckinsey-blue`（McKinsey Blue `#005587` + Amber `#f5a623`，白底）。
> **switch-theme**：已接入。`shared/tokens.css` §2 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 为换肤入口；所有 `cs-*` 组件与语义 token 均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 一键切换。适合切换为 `consulting-navy`（深蓝投行风）等。
> **适用文稿类型**：说服 / 决策（strategy advisory, board presentation, investment analysis, quarterly review）。
> **叙事结构（16 页，按出现顺序）**：cover → toc → executive-summary → situation → complication → question → chapter-divider → framework → recommendation → data-deepdive → comparison-table → process-flow → quarterly-review → risks-mitigation → next-steps → thanks。
>
> 01–03 为「开篇」（封面 + 议程 + 执行摘要/金字塔顶）；04–06 为「诊断」（SCQA 现状/痛点/问题）；07 为「章节切换」；08–12 为「方案」（框架矩阵 + 方案择优 + 数据深潜 + 对标 + 路线图）；13–15 为「治理」（季度复盘 + 风险缓释 + 90 天行动）；16 为「收束」。其中 **07（chapter-divider）/ 13（quarterly-review）为本 deck 特色角色页**（pagecraft 参考源经 HTML 重做）。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 封面：项目代码 + 渐变标题 + 副标题 + 底部项目元数据 + 机密标识 | `.bar-left`, `.kicker`, `.h1`(含 `.gradient-text` accent 词), `.lede`, `.cs-cover-meta`, `.confidential` |
| 02 | `toc` | 议程：6 章节双栏列表 + 编号 + 时长 | `.cs-pagehead`, `.h3.mono`(编号), `.h4`(章节标题), `border-bottom` 分隔 |
| 03 | `executive-summary` | 执行摘要（金字塔顶）：一句话核心结论 + 3 战略支柱卡 | `.card.card-amber`(结论条), `.grid.g3`, `.card.card-accent`, `.pill-accent`, `.h3.mono`(指标) |
| 04 | `situation` | 现状（S）：4 列数据卡（大数字 + delta） + 洞察条 | `.grid.g4`, `.cs-fact`(`.cs-num`/`.cs-label`/`.cs-delta`), `.card-soft`(洞察) |
| 05 | `complication` | 痛点（C）：3 列问题卡 + amber 影响数字 + 证据脚注 | `.grid.g3`, `.card-amber`, `.pill-amber`, `.h2.mono`(影响) |
| 06 | `question` | 关键问题（Q）：MECE 树状分解（1 root → 3 leaf） | `.cs-tree-node.root`/`.leaf`, inline SVG 连接线 |
| 07 | `chapter-divider` | 章节切换：蓝色全屏 + 居中大字章节号/标题 | `background:var(--accent)`, `.h1`(110px 白), amber 分隔条 |
| 08 | `framework` | 战略框架：2×2 矩阵（4 象限） + 右侧优先级图例 | `.cs-matrix`(`.cs-cell.hero`), `.cs-axis-x`/`.cs-axis-y`, `.cs-quadrant-*`, `.card-soft`(图例) |
| 09 | `recommendation` | 方案择优：3 方案对比卡 + 推荐项 amber 高亮 + 选择理由 | `.grid.g3`, `.card-amber`(推荐), `.pill-amber`(★标), `.card-soft`(理由) |
| 10 | `data-deepdive` | 数据深潜：左大数字 + mini 柱图 + 右 3 杠杆拆解卡 | `.card-accent`, `.h1.mono`(大数字), 内联 bar, `.card-amber`(杠杆) |
| 11 | `comparison-table` | 对标表：6 维度硬边表，推荐列 amber 高亮 | `.cs-table`(硬边, 表头蓝底白字, `.col-hero` amber 列), `caption` |
| 12 | `process-flow` | 实施路径：3 波次时间轴 + 里程碑 + 图例 | 时间轴(绝对定位线 + 圆点节点), `.card`/`.card-amber`(波次卡), `.eyebrow`(波次标签) |
| 13 | `quarterly-review` | 季度复盘（特色页）：4 季度卡 + RAG 状态点 + 完成率进度条 + 关注项 | `.cs-quarter`, `.cs-rag-dot`(G/A), `.cs-q-progress`/`.cs-q-bar`, `.cs-q-pct`, `.card-soft`(关注项) |
| 14 | `risks-mitigation` | 风险与缓释：3 风险卡，每卡风险/缓释双栏对照 | `.card`(风险行), `.cs-risk`(`.cs-risk-risk`/`.cs-risk-mit`), 风险等级 pill |
| 15 | `next-steps` | 90 天行动：4-step pipeline（首步 hero） + 决议清单 | `.cs-pipeline`, `.cs-step.hero`, `.cs-step-num`/`.title`/`.body`/`.owner`, `.pill-accent`(决议) |
| 16 | `thanks` | 致谢：大字 + 副标题 + 4 联系人卡 + 机密标识 | `.bar-left`, `.h1`(130px), `.card-soft`×4(联系人), `.confidential` |
| 17 | `process-flow-gantt` | **甘特变体**（与 12 时间轴互补）：N 月（由 `data-gantt-months` 驱动）× N 工序 plan/actual 双色条 + 里程碑 + 图例 | `.cs-gantt`(CSS grid 行=工序列=月份), `.cs-g-bar.plan/.actual/.lag`(双色条), `.cs-milestone.done/.cur/.plan`, `.cs-gantt-legend` |

> **角色 17 与 12 的关系**：两者同属 `process-flow` 叙事位（实施路径/路线图）。**排期/甘特/多阶段类页（含月份、阶段起止时间、≥3 工序）优先用 17 甘特**；纯波次推进（3 阶段无细粒度排期）用 12 时间轴。17 是 consultant 对 `.soe-gantt`（soe-engineering-blue）甘特范式的移植，换肤浅色硬边。

---

## 角色详情

### 01 — `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`project_code`, `client_label`, `headline`, `headline_accent`, `subtitle`, `meta_code`, `meta_date`, `meta_partner`, `meta_confidential`, `footer_source`
- **不可改动**：`.bar-left` 左侧 8px 蓝竖条、`.h1` 字号(78px)/字重(800)、`.cs-cover-meta` 底部绝对定位(left:90px;bottom:80px)
- **内容适配规则**：
  - `headline` 含一个 `<span class="gradient-text">` 渐变 accent 词(key: `headline_accent`)，替换时保留 span
  - `meta_*` 四项为"标签+加粗值"结构，增减时同步调整 `.cs-cover-meta` gap
  - `meta_confidential` 用 `.confidential` 红色大写

### 02 — `toc`
- **可替换键**：`kicker`, `title`, `item_1~6_num/title/desc`, `footer_source`（6 组 ×3 字段 + 2）
- **不可改动**：`.grid.g2` 双栏、每项 `border-bottom` 分隔线、编号用 `.h3.mono` 蓝色
- **内容适配规则**：议程项 4~6 个，增删 `.row` 元素，标题控制在 12 字内

### 03 — `executive-summary`（金字塔顶）
- **可替换键**：`kicker`, `title`, `core_conclusion`(含 5 个内嵌 `<b>`/`<span>` 高亮), `pillars_label`, `pillar_1~3_tag/metric/title/body`, `footer_source`
- **不可改动**：`.card.card-amber` 结论条字号(32px)、3 支柱卡等宽(`.grid.g3`)、指标用 `.h3.mono` amber
- **内容适配规则**：
  - `core_conclusion` 是整 deck 的"金字塔顶"，必须一句话含核心动作 + 量化目标
  - 内嵌高亮词用 `<span style="color:var(--accent-3)">` 或 `<b>`，替换时保留标记
  - 支柱固定 3 个（对应后续 04-06 诊断 + 08-12 方案）

### 04 — `situation`
- **可替换键**：`kicker`, `title`, `subtitle`, `stat_1~4_value/label/delta`, `insight_tag`, `insight_body`, `footer_source`
- **不可改动**：4 列等宽(`.grid.g4`)、`.cs-num` 88px Bold、delta 用 `.cs-delta.down`/`.up` 红/绿
- **内容适配规则**：4 个数据卡，`stat_*_value` 控制在 6 字内（如"¥93亿"），delta 含方向箭头

### 05 — `complication`
- **可替换键**：`kicker`, `title`, `prob_1~3_tag/impact/title/body/evidence`, `footer_source`
- **不可改动**：3 列 `.card-amber`、影响数字用 `.h2.mono` 红色(`var(--bad)`)
- **内容适配规则**：3 个问题卡，`prob_*_impact` 是量化损失（红），`evidence` 是脚注证据

### 06 — `question`（MECE 分解）
- **可替换键**：`kicker`, `title`, `subtitle`, `root_question`, `leaf_1~3_tag/title/body`, `footer_source`
- **不可改动**：`.cs-tree-node.root` 蓝底白字、inline SVG 三叉连接线坐标、3 leaf 等宽
- **内容适配规则**：1 root + 3 leaf（MECE 互斥穷尽），leaf 的 body 用"→ 指标"格式回链目标

### 07 — `chapter-divider`（特色页）
- **可替换键**：`chapter_num`, `chapter_title`, `chapter_sub`, `footer_source`
- **不可改动**：全屏 `background:var(--accent)`、`.h1` 110px 白字、amber 分隔条
- **内容适配规则**：用于切换到"方案建议"大章节，`chapter_title` 可含 `<br>` 换行

### 08 — `framework`（2×2 矩阵）
- **可替换键**：`kicker`, `title`, `axis_x`, `axis_y`, `q1~4_label/title/desc`, `legend_title`, `legend_1~4_tag/body`, `legend_note`, `footer_source`
- **不可改动**：`.cs-matrix` 2×2 grid、`.cs-cell.hero`（Q1 高亮象限用 `rgba(brand-primary,.06)`）、`.cs-axis-y` 竖排文字
- **内容适配规则**：4 象限按"高价值高成熟(Q1,hero)→高价值低成熟(Q2)→低价值高成熟(Q3)→低价值低成熟(Q4)"填充，右侧图例 P0-P3 对应优先级

### 09 — `recommendation`
- **可替换键**：`kicker`, `title`, `opt_a~c_tag/risk/title/body/invest_label/invest/gmv_label/gmv/irr_label/irr`, `opt_b_tag/subtype/horizon`, `reason_tag`, `reason_body`, `footer_source`（3 方案 × ~9 字段）
- **不可改动**：推荐方案(默认 B)用 `.card-amber` + 顶部居中 amber pill、IRR 红绿着色
- **内容适配规则**：
  - 3 方案：A 保守 / B 推荐 / C 激进，`opt_b_*` 整组高亮
  - 若推荐项变更（如改推 C），需把 `.card-amber` class 迁移到对应卡

### 10 — `data-deepdive`
- **可替换键**：`kicker`, `title`, `big_label`, `big_value`, `big_unit`, `bar_now/goal/top_label` + `_value`, `break_1~3_tag/impact/title/body`, `footer_source`
- **不可改动**：左 `.card-accent` 大数字(120px) + 内联 3 行 bar、右 3 `.card-amber` 杠杆卡
- **内容适配规则**：bar 宽度需手动按值调整 `width:%`（当前 36/64/70 对应 1.8/3.2/3.5）

### 11 — `comparison-table`
- **可替换键**：`kicker`, `title`, `col_dim/now/plan/top/gap`（5 列头）, `row_1~6_dim/now/plan/top/gap`（6 行 ×5）, `caption`, `footer_source`
- **不可改动**：`.cs-table` 硬边、表头蓝底白字、`.col-hero` 列 amber 高亮、gap 列绿色
- **内容适配规则**：6 维度行，`col-hero` 默认指第 3 列（方案 B 目标），如改对比列需迁移 class

### 12 — `process-flow`
- **可替换键**：`kicker`, `title`, `wave_1~3_tag/title/body/ms`, `legend_done/cur/plan`, `footer_source`
- **不可改动**：时间轴主线(绝对定位, 实线=已完成 var(--accent) / 虚线背景=计划)、3 波次等宽、圆点节点颜色对应状态
- **内容适配规则**：3 波次，每波 `wave_*_ms` 是可验证里程碑

### 13 — `quarterly-review`（特色页 · 新增）
- **可替换键**：`kicker`, `title`, `subtitle`, `q1~4_label/rag/title/pct/status/event`, `action_tag`, `action_body`, `footer_source`（4 季度 ×5）
- **不可改动**：`.cs-quarter` 4 卡等宽、`.cs-rag-dot` G/A/R 状态点、`.cs-q-progress`/`.cs-q-bar` 进度条颜色随 RAG(good/warn/bad)
- **内容适配规则**：
  - `q*_rag` 值为 "G"/"A"/"R"，需与 `.cs-rag-dot` class(good/warn/bad) + `.cs-q-bar` class 同步
  - `q*_pct` 数字 + `.cs-q-bar` width:% 需一致
  - `subtitle` 含内嵌 RAG 图例 dot，保留 `<span class="cs-rag-dot good">`

### 14 — `risks-mitigation`
- **可替换键**：`kicker`, `title`, `risk_1~3_level/title/prob/risk_head/risk_body/mit_head/mit_body`, `footer_source`（3 风险 ×7）
- **不可改动**：`.cs-risk` 双栏（左红 `.cs-risk-risk` / 右绿 `.cs-risk-mit`）、风险等级 pill 颜色(高=红/中=amber)
- **内容适配规则**：3 风险卡，每卡"风险描述 + 缓释措施"对照，`prob` 格式"概率 X% · 影响 ¥Y"

### 15 — `next-steps`
- **可替换键**：`kicker`, `title`, `subtitle`, `step_1~4_num/title/body/owner/due`, `decision_tag`, `decision_body`, `footer_source`（4 步 ×5）
- **不可改动**：`.cs-pipeline` 4 步等宽、`.cs-step.hero`（首步 amber 顶边 + 浅底）、owner 用 `.cs-step-owner` 加粗
- **内容适配规则**：4 步 90 天行动，每步 owner(角色) + due(T+Nd) + 可验证交付

### 16 — `thanks`
- **可替换键**：`kicker`, `headline`, `subtitle`, `contact_1~4_role/name/email`, `footer_confidential`, `footer_code`
- **不可改动**：`.h1` 130px、4 联系人 `.card-soft` 等宽、`.bar-left` 蓝竖条
- **内容适配规则**：联系人 2~4 个，email 用 `.mono`

### 17 — `process-flow-gantt`（甘特变体 · 新增）
- **源文件**：`slides/17-process-flow-gantt.html`
- **周期适配（关键，治 G1/G2/G4）**：甘特列数/月份头/bar 百分比**由 `data-gantt-start`+`data-gantt-months` 驱动，post-process `fixGanttMonths` 自动生成**，subagent **禁止手填月份表头、手算 left/width**。
- **可替换键**：`kicker`, `title`, `subtitle`, `g_head`(角标), `g_r1~6`(工序名)，每条 bar 设 `data-mstart`(第几月开始,1-based) + `data-mspan`(跨几月) 声明（**不是** inline style）,`lg_plan`/`lg_actual`/`lg_lag`(图例)，`ms_label`, `ms_1~3_date/name/prog/pct`(里程碑，日期须落在 start..start+months-1 范围)，`footer_source`
- **周期声明**：在 `.cs-gantt` 元素上设 `data-gantt-start="起始月"` + `data-gantt-months="月数"`（如 6 月项目 7 月起：`start="7" months="6"`，跨年自动回绕）
- **不可改动**：`.cs-gantt` CSS grid（`190px repeat(var(--gantt-cols,12),1fr)`，列数随周期）、表头蓝底白字 `background:var(--accent)`、`.cs-g-bar.plan`(浅蓝半透)/`.actual`(amber 实心)/`.lag`(红) 配色、**硬边 2px var(--border-strong) 无 box-shadow**
- **内容适配规则**：
  - 工序 4-6 行（每行 min-height 50px 容纳 plan/actual 双条）；多于 6 → 拆页或合并近义工序
  - 里程碑 3-4 个，状态分布建议 1 done / 1 cur / 1~2 plan，`.cs-ms-pct` 与 done/cur 状态色同步（绿/amber）
  - **不要**手填月份表头或手算百分比——交给 post-process；改周期只需改 `data-gantt-start`/`data-gantt-months` + 各 bar 的 `data-mstart`/`data-mspan`

---

## 组件层（`shared/tokens.css` `.tpl-consultant-strategy` overlay）

| class | 作用 |
|------|------|
| `.cs-pagehead` | 页头：kicker + h2.title |
| `.cs-fact` / `.cs-num` / `.cs-label` / `.cs-delta` | 大数字卡（值/标签/增减） |
| `.cs-matrix` / `.cs-cell.hero` / `.cs-quadrant-*` / `.cs-axis-x` / `.cs-axis-y` | 2×2 战略矩阵 |
| `.cs-pipeline` / `.cs-step` / `.cs-step.hero` | 4-step 行动管道 |
| `.cs-table` / `.col-hero` | 硬边对比表（推荐列高亮） |
| `.cs-quarter` / `.cs-rag-dot` / `.cs-q-progress` / `.cs-q-bar` / `.cs-q-pct` | 季度复盘卡（RAG + 进度） |
| `.cs-risk` / `.cs-risk-risk` / `.cs-risk-mit` | 风险/缓释双栏 |
| `.cs-tree-node.root` / `.leaf` | MECE 树节点 |
| `.cs-gantt` / `.cs-g-bar.plan/.actual/.lag` / `.cs-g-track` / `.cs-gantt-legend` | 实施计划甘特图（CSS grid 行=工序/列=月份/双色条）· 角色 17 |
| `.cs-milestone.done/.cur/.plan` / `.cs-ms-*` | 甘特图里程碑卡（硬边 + 左色条）· 角色 17 |
| `.cs-cover-meta` | 封面项目元数据 |
| `.bar-top` / `.bar-left` / `.card-amber` / `.card-accent` | 装饰条 + 强调卡（通用层定义） |

> 所有 `cs-*` 组件颜色均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 切换时自动联动。推荐配套方案：`mckinsey-blue`（默认）、`consulting-navy`（深蓝投行）、`ocean-depths`（深海蓝）。

---

## Style Transfer — T2 页面继承规则

> consultant-strategy 的 T2 页面（无角色匹配、回退 layout-catalog 通用骨架的页）应用下列 Style Transfer delta，确保与 T1 页面视觉一致。主 agent 在 4.2 spec 里列 delta 时**直接从本段复制**，不凭记忆。

### 空间密度对齐

| 字段 | 值 | 出处 |
|------|-----|------|
| 内容区 body padding | `80px 110px` | 紧凑咨询风（tokens.css `--deck-padding` 默认） |
| 卡片间距（grid gap） | `28px` | `.grid{gap:28px}` 通用层 |
| 内容页标题 h2 | `54px`，weight `700`，letter-spacing `-0.02em` | `.h2` 通用层 |
| 章节标识 | `.bar-top`（5px 品牌蓝顶条）+ `.cs-pagehead` kicker | 咨询风章节标识（无 `.section-num` 水印） |
| 卡片圆角 | `var(--radius)` = `4px` | 硬边小圆角，克制 |
| 卡片边框 | `1.5px solid var(--border)`，**`box-shadow:none`** | `.card` 通用层（靠边框分层，禁阴影） |
| 分隔线 | `.divider`（`1px solid var(--border)`） | 通用层 |

### 装饰模式继承

- 强调靠 **硬边色条**（`.card-amber` 左 5px amber / `.card-accent` 顶蓝边），不靠阴影/光晕
- 数据强调用 **amber 实色**（`var(--accent-3)`）+ **mono 字体**（`var(--font-mono)`）
- 表头统一 **蓝底白字**（`background:var(--accent);color:#fff`，仿 `.cs-table` thead）

### 禁止引入的视觉元素（consultant-strategy T2 页面不得出现）

| 禁止 | 原因 |
|------|------|
| `box-shadow` / 阴影 | 咨询风靠边框分层，`--shadow:none` |
| 大圆角（`border-radius` > 8px） | `--radius:4px`，克制硬边 |
| `.ambient-glow` / 光晕 / `.deco-circle` 光球 | 咨询风无此视觉语言 |
| `.cover-blob` / blob 渐变球 | 装饰靠 `.bar-top`/`.bar-left` 色条 |
| glass / 玻璃拟态（`backdrop-filter:blur` / `rgba(255,255,255,.xx)` 半透底） | 浅色硬边 deck，禁玻璃感 |
| 渐变条背景（`linear-gradient` 填充数据条） | 数据条用实色 `var(--accent-3)`/`var(--bad)`，非渐变 |
| 自定义 class（`.arch-*` 等非 `cs-*`/通用层 class） | 只用 tokens.css 已定义的 class |
