# product-launch — Slide Role Catalog

> **模板气质**：Apple-event 风、全暗 deck（暗藏青 #0a0a12 底 + 暖橙→蜜桃渐变 accent）、feature-card 图标圆、testimonial 衬线引文、渐变 CTA 按钮、SVG 产品插图 + 编号标注
> **默认 color-scheme**：aurora-glow（暖橙 #ff5a36 / #ff8c5a / #ffb36b，暗底 #0a0a12）
> **适用文稿类型**：说服/促动（产品发布、v2 揭晓、all-hands reveal、press kit）
> **叙事结构**：Cover(dark) → Introducing(center) → **Product Hero(SVG+callout)** → Sound(3card) → Fit(dark,3card) → Intelligence(2card) → **Specs(KPI网格)** → **Comparison(vs竞品表)** → HowItWorks(3steps) → **UseCases(2×2场景)** → Pricing(3tier) → Ship(dark, testimonial+CTA)
> **暗/亮说明**：所有页底色都是暗藏青 `#0a0a12`（暖橙渐变是 dark-native）。`.dark` 类不换底色，只切换卡片质感——`.dark` 页用半透玻璃卡 `rgba(255,255,255,.06)`，普通页用实色卡 `--surface #1a1a28`；正文 `.lede/.dim` 在 `.dark` 页更亮一档（`rgba(245,245,247,.72)`），普通页用 `--brand-text-dim #9a9aa6`。两者均过 WCAG AA。

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面(dark) | .hero-shot, .brand, h1(gradient accent) |
| 02 | `content-big-statement` | 产品名大字(center) | .center.tc, 186px h1 |
| 03 | `content-product-hero` | 产品英雄页(SVG 插图+标注) | .product-hero(文字/插图两栏), .hero-figure(inline SVG), .spec-pill, 编号 callout pin |
| 04 | `content-feature-3card` | 特性三卡片(亮质感) | .feature-card(.icon+h4+p) |
| 05 | `content-feature-3card-dark` | 特性三卡片(暗玻璃) | .dark, .card |
| 06 | `content-feature-2card` | 特性两卡片 | .feature-card, .grid.g2 |
| 07 | `content-specs` | 规格大数字(KPI 网格) | .spec-grid(g4), .spec(.num[渐变clip]+.unit+.label) |
| 08 | `content-comparison` | 竞品对比表 | .compare-table, .col-best(Halo 列高亮), .check/.cross |
| 09 | `content-steps` | 三步流程 | .step(.n+h4+p) |
| 10 | `content-use-cases` | 使用场景(2×2 bento) | .scenario-grid(g2), .scenario-card(.ico[小 SVG]+h4+p) |
| 11 | `content-pricing` | 三档定价 | .price-card(.pro=推荐档), .amount, ul |
| 12 | `cta` | 引文+预购(dark) | .testimonial, .cta-btn, 128px 价格 |

> **板式库说明**：03 / 07 / 08 / 10 是为补全"真实发布模板"新增的板式——产品 SVG 插图页、规格 KPI 网格、竞品对比表、场景 bento。agent 生成时按内容需要选用，位置可在叙事线上前后挪动（例如把对比表提前到特性段后、或把场景页放到 how-it-works 前）。挪动时记得同步文件名序号 + `data-current` + `index.html` iframe 顺序 + 本表行号。

## Style Transfer — T2 页面继承规则

### 空间密度对齐
- body padding: `106px 165px`
- 暗底 `#0a0a12`（全 deck 统一）

### 装饰模式继承
- 特性卡片用 `.feature-card`（图标圆+标题+正文）
- 暗页节奏：用 `.dark` 切玻璃卡质感，不换底色（见上"暗/亮说明"）
- 大数字/价格/accent 文字用 inline `background:var(--grad); -webkit-background-clip:text` 渐变（spec-card `.num` 已封装为 class）

### 组件类名统一
- 特性卡片：`.feature-card`（不用裸 .card）
- 定价：`.price-card` + `.price-card.pro`（推荐档高亮）
- 步骤：`.step`
- CTA 按钮：`.cta-btn`
- 产品插图：`.product-hero` + `.hero-figure`（inline SVG，callout pin 画在 SVG 内）
- 规格指标：`.spec-grid` + `.spec`（渐变大数字）
- 对比表：`.compare-table` + `.col-best`（高亮列）
- 场景卡：`.scenario-grid` + `.scenario-card`（小 inline SVG 图标，stroke=`--accent`）

### 灰色文字可读性（必读）
- 全 deck 暗底，正文灰用 `--brand-text-dim #9a9aa6`（7.09:1）、footer/eyebrow 用 `--brand-text-faint #8a8a94`（4.9:1）。**不要**把任何 `.dim`/`.lede`/列表项改回 `#3a3a44`——那是亮底灰，暗底上仅 1.75:1 不可读。
- 新增含正文/说明文字的页，沿用 `.dim`/`.lede` class，勿硬编码灰色 hex。

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| .section-num 水印 | product-launch 用 kicker 编号 |
| .card-accent | 用 .feature-card 替代 |
| .gradient-text class | 用 inline style 渐变 或 .spec .num |
| .terminal / 代码块 | 非技术模板 |
| 亮色页面底 | 全 deck dark-native，"亮页"靠卡片质感区分而非底色 |
