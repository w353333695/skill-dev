#!/usr/bin/env node
// preview_slides.mjs — 用 Playwright 对每页 slide 截图
// 视觉验收用：AI 查看截图判断视觉质量
// 依赖: playwright (npm install playwright) —— plugin 分发包不含 node_modules，缺失时见下方报错

'use strict';

import { readdirSync, existsSync, mkdirSync, statSync } from 'fs';
import { join, resolve, basename } from 'path';
import { dep } from './_resolve.mjs';

const DECK_WIDTH = 1920;
const DECK_HEIGHT = 1080;

function parseArgs(argv) {
  const args = { slides: null, out: null, format: 'png' };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--slides' && argv[i + 1]) { args.slides = argv[++i]; continue; }
    if (a === '--out' && argv[i + 1]) { args.out = argv[++i]; continue; }
    if (a === '--format' && argv[i + 1]) { args.format = argv[++i]; continue; }
    if (a === '--width' && argv[i + 1]) { args.width = parseInt(argv[++i]); continue; }
    if (a === '--height' && argv[i + 1]) { args.height = parseInt(argv[++i]); continue; }
    if (a === '--help' || a === '-h') { printUsage(); process.exit(0); }
  }
  return args;
}

function printUsage() {
  console.log('Usage: node preview_slides.mjs --slides <dir> --out <dir> [--format png|jpeg]');
  console.log('');
  console.log('  --slides <dir>     Directory containing slide HTML files');
  console.log('  --out <dir>        Output directory for screenshots');
  console.log('  --format png|jpeg  Screenshot format (default: png)');
  console.log('  --width <px>       Deck width (default: 1920)');
  console.log('  --height <px>      Deck height (default: 1080)');
}

function slideFiles(slidesDir) {
  return readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();
}

async function screenshotSlide(context, filePath, outPath, format) {
  const page = await context.newPage();
  try {
    await page.goto('file://' + filePath, { waitUntil: 'networkidle', timeout: 15000 });

    // Wait for any animations to settle
    await page.evaluate(() => new Promise(r => setTimeout(r, 500)));

    await page.screenshot({
      path: outPath,
      type: format === 'jpeg' ? 'jpeg' : 'png',
      quality: format === 'jpeg' ? 90 : undefined,
      fullPage: false,
    });

    console.log(`  ✓ ${basename(outPath)}`);
  } catch (err) {
    console.error(`  ✗ ${basename(filePath)}: ${err.message}`);
  } finally {
    await page.close();
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.slides || !args.out) {
    console.error('Error: --slides and --out are required.\n');
    printUsage();
    process.exit(2);
  }

  const slidesDir = resolve(args.slides);
  const outDir = resolve(args.out);

  if (!existsSync(slidesDir)) {
    console.error(`Error: slides directory not found: ${slidesDir}`);
    process.exit(2);
  }

  if (!existsSync(outDir)) {
    mkdirSync(outDir, { recursive: true });
  }

  const files = slideFiles(slidesDir);
  if (files.length === 0) {
    console.error('Error: no HTML files found in slides directory.');
    process.exit(2);
  }

  console.log(`Previewing ${files.length} slides → ${outDir}/`);
  console.log(`  Format: ${args.format}, Viewport: ${args.width || DECK_WIDTH}×${args.height || DECK_HEIGHT} @2x\n`);

  const chromium = dep('playwright').chromium;
  const browser = await chromium.launch({
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  // deviceScaleFactor 与 viewport 在 Playwright 中需通过 context 设置（puppeteer 的 page.setViewport 不存在）
  const context = await browser.newContext({
    deviceScaleFactor: 2,
    viewport: { width: args.width || DECK_WIDTH, height: args.height || DECK_HEIGHT },
  });

  try {
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const filePath = join(slidesDir, file);
      const outName = file.replace(/\.html$/, `.${args.format}`);
      const outPath = join(outDir, outName);

      const num = `[${String(i + 1).padStart(String(files.length).length)}/${files.length}]`;
      process.stdout.write(`${num} ${file} `);
      await screenshotSlide(context, filePath, outPath, args.format);
    }
  } finally {
    await browser.close();
  }

  console.log(`\nDone: ${files.length} screenshots saved to ${outDir}/`);
  console.log('Visual review checklist:');
  console.log('  □ 整体观感是否有层次（不是"白蒙蒙"或"黑糊糊"）');
  console.log('  □ 卡片是否有深度感（shadow）');
  console.log('  □ 渐变装饰是否存在');
  console.log('  □ 文字是否清晰可辨');
  console.log('  □ 跨页风格是否一致');
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
