# xhs-pastel-card — Slide Role Catalog

> **模板气质**：小红书温柔生活美学、柔光 blob 装饰层、马卡龙色系卡片(peach/mint/sky/lilac/lemon)、Playfair Display 斜体强调(`<em>`)、donut SVG 环形图 + 柔光马卡龙 SVG 插图
> **默认 color-scheme**：pastel-macaron（出厂默认；AI 在 Phase 4.1 独立替换颜色方案）
> **适用文稿类型**：生活美学/品牌叙事/感性说服/个人博客式分享/小红书收藏向清单
> **叙事结构**（14 页）：Cover → Agenda → Section → Timeline → Content(2x2 cards) → Compare(before/after) → Illustration(SVG) → Quote → Code/Prompt → Image-Text → Checklist → Chart(donut) → CTA(3card) → Thanks
> **装饰系统**：`.xp-blob` 柔光色块（b1/b2/b3 三层叠加 soft blob 背景，注意 b1 `right:-6%` / b2 `bottom:-10%` 会故意溢出视口，靠 body `overflow:hidden` 裁切——属设计，非 bug）、`.xp-topbar` 顶部导航条（chip 标签 + page 页码）、`.xp-divider` 分隔线、`.xp-footer` 底部信息栏
> **卡片色板**：peach / mint / sky / lilac / lemon / rose（马卡龙配色，每张卡片独立色调，通过 `.xp-card.peach` 等类名绑定）；deck-private 深档色 `--xp-*-dd`（peach-dd #f48b5c / mint-dd #2e9d70 / sky-dd #4e7ed6 / lilac-dd #7b5dc4 / lemon-dd #e0a93b / rose-dd #e8709a）供时间线节点、✓/✗、勾选圈、SVG 描边使用
> **专属动效**（overlay 段 keyframes，不进 §2.5）：`.anim-bloom`（SVG 花朵绽放）、`.anim-check`（勾选圈 pop）、`.anim-tl-draw`（时间线轨道 stroke 绘制，配合 `.xp-tl-track` 自动触发）
> **CJK 标题**：`.xp-h2` 已接管换行（`word-break:keep-all; overflow-wrap:break-word; text-wrap:balance`，规则⑩）——新页标题**不写 `<br>`**

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面 | .xp-blob(b1+b2+b3), .xp-topbar, .xp-chip, .xp-kicker, h1.xp-h1(em+span.rose), .xp-divider, .xp-sub |
| 02 | `agenda` | 目录/大纲页 | .xp-blob(b1+b3), .xp-topbar, .xp-chip, .xp-kicker, h2.xp-h2(em), .xp-toc(.xp-toc-row ×6) |
| 03 | `section` | 章节分隔页 | .xp-blob(b2+b3), .xp-topbar, .xp-chip.mint, .xp-kicker, h1.xp-h1(160px+span.mint), .xp-sub |
| 04 | `timeline` | 横向时间线/流程页 | .xp-blob(b2), .xp-topbar, .xp-chip.sky, h2.xp-h2(em), .xp-timeline(.xp-tl-rail+track+node ×4 / .xp-tl-cards .xp-card ×4) |
| 05 | `content-2x2-cards` | 内容页：四卡片 2x2 grid | .xp-blob(b1), .xp-topbar, .xp-chip.rose, h2.xp-h2(em), .xp-grid-2, .xp-card ×4(.xp-num+h4+p) |
| 06 | `compare` | 对比页：before/after 双栏 | .xp-blob(b1+b2), .xp-topbar, .xp-chip.rose, h2.xp-h2(em), .xp-cmp(.xp-cmp-side.before/after + .xp-cmp-list) |
| 07 | `illustration` | SVG 插图页（柔光马卡龙） | .xp-blob(b3), .xp-topbar, .xp-chip.mint, h2.xp-h2(em), .xp-illo(inline SVG: 柔光日历圆+花朵), .xp-illo-cap |
| 08 | `quote` | 引用/金句页 | .xp-blob(b3+b2), .xp-topbar, .xp-chip.lilac, .xp-hero-card, .xp-quote(em×2), .xp-divider, .xp-sub |
| 09 | `code-prompt` | 代码/Prompt 展示页 | .xp-blob(b1), .xp-topbar, .xp-chip, h2.xp-h2(em+span.rose), pre.xp-codebox |
| 10 | `image-text` | 图文混排（左文右图） | .xp-blob(b1), .xp-topbar, .xp-chip, .xp-grid-2(align-items:center), .xp-kicker, h2.xp-h2(em), .xp-sub, .xp-it-tags(.xp-chip), .xp-it-visual(svg) |
| 11 | `checklist` | 清单/收藏向页 | .xp-blob(b3), .xp-topbar, .xp-chip.rose, h2.xp-h2(em), .xp-checklist(.xp-check-item ×5, .xp-check-box) |
| 12 | `chart-donut` | Donut 环形图数据页 | .xp-blob(b2), .xp-topbar, .xp-chip.mint, h2.xp-h2(span.mint), SVG donut(circle×5+text×2), .xp-card legend×4 |
| 13 | `cta-3card` | 行动号召：三卡片 1x3 grid | .xp-blob(b1+b3), .xp-topbar, .xp-chip.rose, h2.xp-h2(em), .xp-grid-3, .xp-card ×3(.xp-num emoji+h4+p) |
| 14 | `thanks` | 感谢/结束页 | .xp-blob(b2), .xp-kicker 居中, h1.xp-h1(213px+em"·"), .xp-divider 居中, .xp-sub 居中 |

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **页面类型**：封面
- **视觉等级**：L3
- **可替换键**：`chip`, `page_num`, `kicker`, `headline`, `headline_em`, `headline_accent`, `subtitle`, `footer_author`, `footer_label`
- **不可改动**：.xp-blob 三层柔光装饰（b1/b2/b3 保留位置/颜色/模糊度）、.xp-topbar 结构、.xp-divider 分隔线、.xp-footer 容器、h1 字号/字重、body class
- **内容适配规则**：
  - `headline` 含一个用 `<em>` 包裹的英文/关键词（key: `headline_em`）和一个用 `<span class="rose">` 包裹的 accent 词（key: `headline_accent`），替换时保留 em 和 span 结构
  - 标题总字数控制在 20 字以内
  - `kicker` 控制在 25 字符以内，格式 `"主题 · 年份"`
  - `subtitle` 控制在 50 字以内
  - `footer_author` 格式 `"by 作者 · 版本名"`
- **卡片扩展/收缩**：不适用

### `agenda`
- **源文件**：`slides/02-agenda.html`
- **页面类型**：目录/大纲页
- **视觉等级**：L2
- **可替换键**：`chip`, `page_num`, `kicker`, `headline`, `headline_em`, `item_N_num`(N=1..6), `item_N_title`, `item_N_desc`, `footer_left`, `footer_right`
- **不可改动**：.xp-toc 两列 grid 结构、.xp-toc-row 的 flex 布局（序号 + fill）、`border-bottom` 分隔、.xp-num 字号、.xp-blob 装饰
- **内容适配规则**：
  - `headline` 含一个 `<em>` 强调词（key: `headline_em`）
  - 标题控制在 14 字以内（CJK 由 `.xp-h2` 的 keep-all+balance 自动换行，不写 `<br>`）
  - 章节行数建议 4~6 行（`.xp-toc` 是 2 列 grid，奇数行会留半行空白——优先用偶数 4/6 行）
  - `item_N_num` 保持 `"01"~"06"` 两位序号
  - `item_N_title` 控制在 8 字以内
  - `item_N_desc` 控制在 18 字以内（一句话钩子）
- **卡片扩展/收缩**：
  - 扩展章节行：直接增删 `.xp-toc-row`，建议保持偶数行（2 列对齐）
  - 单列目录：`.xp-toc` 改 `grid-template-columns:1fr`

### `section`
- **源文件**：`slides/03-section.html`
- **页面类型**：章节分隔页
- **视觉等级**：L2
- **可替换键**：`chip`, `page_num`, `kicker`, `headline`, `headline_accent`, `subtitle`, `footer_left`, `footer_right`
- **不可改动**：.xp-blob 装饰（b2/b3）、h1 字号(160px)/字重、居中 layout 容器(`style="margin:auto 0"`)、color class（`.mint`）绑定到 accent span
- **内容适配规则**：
  - `headline` 含一个用 `<span class="mint">` 包裹的 accent 词（key: `headline_accent`），替换时保留 span.mint 结构
  - 标题控制在 15 字以内
  - `kicker` 控制在 10 字以内（章节引导短句）
  - `subtitle` 控制在 30 字以内（金句式副标题）
  - `chip` 控制在 15 字符以内，格式 `"Chapter N"` 或 `"章节名"`
- **卡片扩展/收缩**：不适用

### `timeline`
- **源文件**：`slides/04-timeline.html`
- **页面类型**：横向时间线/流程页
- **视觉等级**：L1
- **可替换键**：`chip`, `page_num`, `headline`, `headline_em`, `tN_eyebrow`(N=1..4), `tN_time`, `tN_title`, `tN_body`, `footer_left`, `footer_right`
- **不可改动**：.xp-tl-rail 的 4 列 grid 结构、.xp-tl-track 轨道线（abs 定位 + 自动绘制动效）、.xp-tl-node 圆点色板（peach/mint/sky/lilac 深档 `--xp-*-dd`）、节点列的 color class（`.mint`/`.sky`/`.lilac`）必须与下方 `.xp-card` 色板对应、.xp-tl-cards 的 4 列 grid
- **内容适配规则**：
  - `headline` 含一个 `<em>` 强调词（key: `headline_em`）
  - 标题控制在 14 字以内
  - 时段节点数固定 4 个（`t1_eyebrow`~`t4_eyebrow`），格式 `"Morning · 09:00"`（时段 · 时间）
  - `tN_time` 控制在 12 字以内，格式 `"HH:MM — 动作"`
  - `tN_title` 控制在 10 字以内
  - `tN_body` 控制在 25 字以内
  - **节点列 color class 与卡片色板一一对应**：列 1 默认 peach，列 2 `.mint`，列 3 `.sky`，列 4 `.lilac`
- **卡片扩展/收缩**：
  - 扩展为 3 节点：`.xp-tl-rail`/`.xp-tl-cards` grid 改 `repeat(3,1fr)`，删一个 col + card
  - 扩展为 5 节点：`repeat(5,1fr)`，卡片字号需下调避免拥挤
  - **不建议超过 5 节点**（横向空间紧张）

### `content-2x2-cards`
- **源文件**：`slides/05-content-2x2-pastel-cards.html`
- **页面类型**：内容页（四卡片 2x2 grid）
- **视觉等级**：L1
- **可替换键**：`chip`, `page_num`, `headline`, `headline_em`, `card_1_num`, `card_1_title`, `card_1_body`, `card_2_num`, `card_2_title`, `card_2_body`, `card_3_num`, `card_3_title`, `card_3_body`, `card_4_num`, `card_4_title`, `card_4_body`, `footer_left`, `footer_right`
- **不可改动**：.xp-grid-2 grid 结构、.xp-card 卡片样式（padding/圆角/阴影）、卡片色板类名（peach/mint/sky/lilac 顺序）、.xp-num 字号和位置、h4/p 字号
- **内容适配规则**：
  - `headline` 含一个用 `<em>` 包裹的强调词（key: `headline_em`），替换时保留 em 结构
  - 标题控制在 12 字以内
  - 卡片序号（card_N_num）保持数字格式 "01"~"04"
  - 卡片标题（card_N_title）控制在 12 字以内
  - 卡片正文（card_N_body）控制在 35 字以内
  - 四张卡片内容量应均匀（最长与最短差异不超过 50%）
  - 每张卡片保留原始色板类名（peach/mint/sky/lilac）
- **卡片扩展/收缩**：
  - 扩展为 6 卡：`.xp-grid-2` → `.xp-grid-3`（3 列 × 2 行），新增卡片复用 peach/mint/sky/lilac/lemon 色板
  - 收缩为 2 卡：`.xp-grid-2` 不变（2 列各 1 卡即可）
  - **不可收缩为 1 卡**（1 卡改用 `quote` 角色或 T2 fallback）

### `compare`
- **源文件**：`slides/06-compare.html`
- **页面类型**：对比页（before/after 双栏）
- **视觉等级**：L1
- **可替换键**：`chip`, `page_num`, `headline`, `headline_em`, `before_tag`, `after_tag`, `b1`~`b5`(before 列表，每项含 `<strong>` 关键词), `a1`~`a5`(after 列表), `footer_left`, `footer_right`
- **不可改动**：.xp-cmp 两栏 grid 结构、`.xp-cmp-side.before`（虚线灰底）与 `.after`（白底阴影）的视觉差异、✗/✓ 圆标（`.xp-cmp-list li b`）、列表项的 strong 关键词加粗
- **内容适配规则**：
  - `headline` 含一个 `<em>` 强调词（key: `headline_em`）
  - 标题控制在 16 字以内
  - `before_tag`/`after_tag` 控制在 8 字以内（如 `"✗ 之前"` / `"✓ 之后"`）
  - before/after 两栏列表项数**必须相等**（默认各 5 项 `b1`~`b5` / `a1`~`a5`）
  - 每项 `<strong>` 关键词控制在 8 字以内，剩余说明 ≤15 字
  - 两栏内容应**一一对照**（before 第 N 项对应 after 第 N 项的改进）
- **卡片扩展/收缩**：
  - 列表项数 3~6：增删 `<li>`，两栏同步
  - 项数 >6 时字号自动偏小，建议 ≤5 项

### `illustration`
- **源文件**：`slides/07-illustration.html`
- **页面类型**：SVG 插图页（柔光马卡龙填色）
- **视觉等级**：L3
- **可替换键**：`chip`, `page_num`, `headline`, `headline_em`, `illo_caption`(SVG 内 caption text), `illo_note`(.xp-illo-cap 注解), `footer_left`, `footer_right`
- **不可改动**：`.xp-illo` 居中容器、SVG `<defs>` 内的 6 个 `<radialGradient>`（g-peach/g-mint/g-sky/g-lilac/g-lemon/g-rose，马卡龙柔光色块）、SVG scoped class（`.day`/`.day-busy`/`.lbl`/`.stem`/`.leaf`/`.bloom`/`.petal`/`.cap`）、花朵的 `.anim-bloom` 绽放动效绑定、`viewBox="0 0 800 460"`
- **内容适配规则**：
  - `headline` 含一个 `<em>` 强调词（key: `headline_em`）
  - 标题控制在 14 字以内
  - `illo_caption`（SVG 内顶部斜体标题）控制在 14 字以内
  - `illo_note`（图下注解）控制在 40 字以内
  - **SVG 结构性数据驱动**：若改"忙碌天数/留白天数"比例，需同步调整 `<circle>` 的 fill（busy 用 `day-busy` 白实心 / free 用柔光 `fill-opacity:.5`）和花朵 `<g class="bloom">` 的位置（花朵从留白圆上方长出）
  - SVG 描边/填色用 deck-private token（`#2a2340` 系 + `--xp-*-dd` 深档），不用 `--xp-*` 浅 brand 色（会与白底对比不足）
- **卡片扩展/收缩**：不适用
- **替换插画的两种方式**：
  1. **改配色不改结构**：只换 `<radialGradient>` 的 stop-color（保持 6 个 gradient id）+ 花朵 `<ellipse>`/`<circle>` 的 fill
  2. **整体换插画**：保留 `<svg viewBox="0 0 800 460" role="img" aria-label>` 外壳 + `<defs><style>` 里的 scoped class 命名约定，重画 `<g>` 内容；花朵类继续用 `.bloom .anim-bloom` 绑定绽放

### `quote`
- **源文件**：`slides/08-quote.html`
- **页面类型**：引用/金句页
- **视觉等级**：L2
- **可替换键**：`chip`, `page_num`, `quote_text`, `quote_em_1`, `quote_em_2`, `subtitle`, `footer_left`, `footer_right`
- **不可改动**：.xp-hero-card 卡片容器（居中大白卡+阴影）、.xp-quote 字号(54px)/字距(-0.025em)/行高、.xp-divider 分隔线、.xp-sub 辅助文字样式
- **内容适配规则**：
  - `quote_text` 含两处 `<em>` 包裹的强调词（key: `quote_em_1`, `quote_em_2`），替换时保留 em 结构
  - 引文控制在 30 字以内
  - `subtitle` 控制在 50 字以内（说明/解读引文）
  - em 强调词各控制在 6 字以内
- **卡片扩展/收缩**：不适用（引用页无卡片）

### `code-prompt`
- **源文件**：`slides/09-code-prompt.html`
- **页面类型**：代码/Prompt 展示页
- **视觉等级**：L1
- **可替换键**：`chip`, `page_num`, `headline`, `headline_em`, `headline_accent`, `code_text`, `footer_left`, `footer_right`
- **不可改动**：pre.xp-codebox 代码框样式（暗色背景/等宽字体/圆角/内边距）、代码高亮 class（.cm .kw .st .hl）保留为样式标记
- **内容适配规则**：
  - `headline` 含一个用 `<em>` 包裹的关键词（key: `headline_em`）和一个用 `<span class="rose">` 包裹的 accent 词（key: `headline_accent`），替换时保留 em 和 span 结构
  - 标题控制在 18 字以内
  - `code_text` 为 pre 的 innerHTML，包含语法高亮 span（.cm 注释 / .kw 关键词 / .st 字符串 / .hl 高亮），替换时保留 span 标签和 class
  - 代码内容控制在 12 行以内
  - 保持原代码缩进和空行格式
- **卡片扩展/收缩**：不适用（代码页无卡片）

### `image-text`
- **源文件**：`slides/10-image-text.html`
- **页面类型**：图文混排（左文右图）
- **视觉等级**：L2
- **可替换键**：`chip`, `page_num`, `kicker`, `headline`, `headline_em`, `body`, `tag_1`/`tag_2`/`tag_3`, `footer_left`, `footer_right`
- **不可改动**：`.xp-grid-2` 的 `align-items:center`（左右垂直居中对齐）、左栏 `.xp-kicker`+`.xp-h2`+`.xp-sub`+`.xp-it-tags` 结构、右栏 `.xp-it-visual` 内 inline SVG（viewBox `0 0 420 380`，柔光底 `radialGradient it-g` + 对话气泡 + 便当盒 scoped class）
- **内容适配规则**：
  - `headline` 含一个 `<em>` 强调词（key: `headline_em`）
  - 标题控制在 16 字以内
  - `kicker` 控制在 15 字以内（案例标签，格式 `"case · 主题"`）
  - `body` 控制在 80 字以内（案例叙述）
  - `tag_N` 控制在 10 字以内（数据 chip，建议 2~3 个，色板复用 `.xp-chip` + `.mint`/`.rose`/默认）
  - 右栏 SVG 可整体替换（保留外壳 `<svg viewBox role img aria-label>` + scoped class 约定），但宽度由 `.xp-it-visual svg{max-width:420px}` 约束
- **卡片扩展/收缩**：
  - 标签数 2~4：增删 `.xp-it-tags` 内的 `.xp-chip`
  - 图文左右互换：`.xp-grid-2` 内两栏 DOM 顺序对调即可

### `checklist`
- **源文件**：`slides/11-checklist.html`
- **页面类型**：清单/收藏向页
- **视觉等级**：L1
- **可替换键**：`chip`, `page_num`, `headline`, `headline_em`, `cN_title`(N=1..5), `cN_body`, `footer_left`, `footer_right`
- **不可改动**：.xp-checklist 单列布局、.xp-check-item 的 flex 结构（勾选圈 + fill）、.xp-check-box 圆圈深档色板（peach/mint/sky/lilac/lemon 的 `--xp-*-dd`）、`.anim-check` 勾选 pop 动效绑定、item 上的色板 class
- **内容适配规则**：
  - `headline` 含一个 `<em>` 强调词（key: `headline_em`）
  - 标题控制在 14 字以内
  - 清单项数 4~5（默认 5 项 `c1`~`c5`），每项色板按序 peach/mint/sky/lilac/lemon
  - `cN_title` 控制在 12 字以内（步骤动作）
  - `cN_body` 控制在 35 字以内（步骤说明）
  - 清单应有**递进感**（步骤 1→N，或时间顺序）
  - `.xp-check-box` 内容默认是序号 `"01"~"05"`，可换成 emoji（如 ✓ ☕ 🌸）控制在 2 字符以内
- **卡片扩展/收缩**：
  - 项数 3~6：增删 `.xp-check-item`（每项绑定一个色板 class，色板循环复用）
  - 项数 >5 时单页偏挤，建议拆成两页或改用 `agenda` 两列

### `chart-donut`
- **源文件**：`slides/12-chart.html`
- **页面类型**：Donut 环形图数据页
- **视觉等级**：L1
- **可替换键**：`chip`, `page_num`, `headline`, `headline_accent`, `donut_center_value`, `donut_center_label`, `legend_1_label`, `legend_2_label`, `legend_3_label`, `legend_4_label`, `footer_left`, `footer_right`
- **不可改动**：SVG 结构整体保留（viewBox 0 0 260 260）、所有 `<circle>` 元素（轨道环 + 4 段数据弧的 stroke/stroke-width/stroke-dasharray/stroke-dashoffset/transform 属性不标注 data-replace）、SVG text 的字体/字号/位置属性、legend 色点 div（背景色 var(--xp-*-d)）
- **内容适配规则**：
  - `headline` 含一个用 `<span class="mint">` 包裹的 accent 词（key: `headline_accent`），替换时保留 span.mint
  - 标题控制在 15 字以内
  - `donut_center_value` 控制在 4 字符以内（如 "4h"、"8h"、"30%"），保留数值+单位格式
  - `donut_center_label` 控制在 15 字符以内（环形图中心副标签）
  - legend label 格式 `"XX min · 类别名"`（时间+分类），控制在 20 字符以内
  - **重要**：SVG circle 的 stroke-dasharray 和 stroke-dashoffset 由数据比例决定，AI 替换数据时需同步调整这些 SVG 属性值，但不在 slide HTML 中用 data-replace 标注（属于结构性数据驱动渲染）
- **卡片扩展/收缩**：
  - legend 数量 2~6：增删 `.xp-card` legend 行
  - 每增减一个 legend，需在 SVG 中增减对应的数据弧 `<circle>` + 更新剩余的 stroke-dashoffset 偏移量

### `cta-3card`
- **源文件**：`slides/13-cta.html`
- **页面类型**：行动号召（三卡片 1x3 grid）
- **视觉等级**：L2
- **可替换键**：`chip`, `page_num`, `headline`, `headline_em`, `card_1_icon`, `card_1_title`, `card_1_body`, `card_2_icon`, `card_2_title`, `card_2_body`, `card_3_icon`, `card_3_title`, `card_3_body`, `footer_left`, `footer_right`
- **不可改动**：.xp-grid-3 grid 结构、卡片色板（lemon/peach/sky 左到右顺序）、.xp-num emoji icon 字号、卡片 h4/p 样式
- **内容适配规则**：
  - `headline` 含一个用 `<em>` 包裹的强调词（key: `headline_em`），替换时保留 em 结构
  - 标题控制在 15 字以内
  - `card_N_icon` 为单个 emoji 字符（如 ☕🌸🌙），控制在 2 字符以内
  - `card_N_title` 控制在 20 字符以内（时间段描述）
  - `card_N_body` 控制在 35 字以内（行动步骤描述）
  - 三张卡片保留原始色板类名（lemon/peach/sky）
  - 卡片内容应有时间递进感（morning → afternoon → night / step 1 → 2 → 3）
- **卡片扩展/收缩**：
  - 扩展为 4 卡：`.xp-grid-3` → `.xp-grid-4`，新增卡片用 lilac 色板
  - 收缩为 2 卡：`.xp-grid-3` → `.xp-grid-2`
  - **不可收缩为 1 卡**（1 卡改用 `quote` 或 T2 fallback）

### `thanks`
- **源文件**：`slides/14-thanks.html`
- **页面类型**：感谢/结束页
- **视觉等级**：L3
- **可替换键**：`kicker`, `headline`, `headline_em`, `subtitle`, `footer_left`, `footer_right`
- **不可改动**：居中对齐 container(`text-align:center` + `margin:auto 0`)、h1 字号(213px)/字重(900)、.xp-divider 居中样式(`margin: 32px auto`)、.xp-sub 居中样式(`margin:0 auto`)
- **内容适配规则**：
  - `headline` 含一个用 `<em>` 包裹的装饰分隔符（key: `headline_em`，原为 `·`），替换时保留 em 结构
  - 标题控制在 15 字符以内，格式 `"中文 · English"` 双语道谢
  - `kicker` 控制在 15 字符以内（如 "thanks for reading"）
  - `subtitle` 控制在 50 字以内（互动引导/社交传播文案）
- **卡片扩展/收缩**：不适用

---

## 角色匹配决策树

1. 用户 slide 是封面 → `cover`
2. 用户 slide 是目录/大纲/章节预览（序号 + 标题 + 一句话）→ `agenda`
3. 用户 slide 是章节分隔/大标题过渡 → `section`
4. 用户 slide 是横向时间线/流程/多时段节点（带轨道线）→ `timeline`
5. 用户 slide 是 before/after 对比（两栏 ✗/✓ 列表）→ `compare`
6. 用户 slide 是概念性 SVG 插图/视觉隐喻页（无数据）→ `illustration`
7. 用户 slide 是图文混排（左文右插画/图）→ `image-text`
8. 用户 slide 是可勾选清单/收藏向步骤 → `checklist`
9. 用户 slide 是感谢/结束 → `thanks`
10. 用户 slide 是引用/金句（一条主引文 + 辅助说明）→ `quote`
11. 用户 slide 是代码/Prompt/技术指令展示 → `code-prompt`
12. 用户 slide 有环形图/比例数据 + 图例 → `chart-donut`
13. 用户 slide 有 4 张卡片（2×2 grid）→ `content-2x2-cards`
14. 用户 slide 是行动号召/步骤引导（3 张卡片 1×3）→ `cta-3card`
15. 以上都不匹配 → 降级到 T2 layout-catalog 通用骨架（应用下方 Style Transfer 规则）

---

## Style Transfer — T2 页面继承规则

当 deck 中存在 T2 页面（从 layout-catalog 生成的非模板页面）时，以下规则确保它们与 xhs-pastel-card 模板页面的视觉语言一致。

### 空间密度对齐
- 内容区 body padding：对齐 84px 100px（topbar 下方安全区）
- 卡片间距：对齐 `.xp-grid-2` gap = 22px, `.xp-grid-3` gap = 20px
- 标题与内容间距：h2 下 margin 天然间距，正文段落用 xp-sub 样式

### 装饰模式继承
- **blob 背景**：所有 T2 页面必须添加至少一个 `.xp-blob` 装饰层（推荐 b1 或 b2），与其他页面视觉连贯。注意 blob 会故意溢出视口（b1 `right:-6%`/b2 `bottom:-10%`），靠 body `overflow:hidden` 裁切
- **topbar**：T2 内容页必须添加 `.xp-topbar`（含 `.xp-chip` + `.xp-page`），chip 色板从 peach/mint/sky/lilac/rose 中选择一个与页面色调匹配的
- **footer**：T2 页面必须添加 `.xp-footer`
- **分隔线**：标题与正文之间用 `.xp-divider`

### 组件类名统一
- 卡片用 `.xp-card`（白底 + 阴影 + 31px 圆角）+ 色板 class（`.peach` / `.mint` / `.sky` / `.lilac` / `.lemon` / `.rose`）
- 标题用 `h2.xp-h2`（67px, weight 800, Playfair Display `<em>` 斜体强调，CJK 自动 keep-all+balance 换行）
- 正文用 `<p>` 自然样式（--text-2, 22px）
- 序号用 `.xp-num`（75px, weight 900, Playfair Display italic, opacity 0.85）
- 深档强调色（节点/✓✗/勾选圈/SVG 描边）用 deck-private `--xp-*-dd`（peach-dd #f48b5c 等），不用 `--xp-*` 浅 brand 色
- T2 新增布局类若需要，写在 `.tpl-xhs-pastel-card` overlay 段，命名带 `xp-` 前缀（如 `.xp-<feature>`）

### 排版层级对齐
- 封面/章节/感谢标题：h1.xp-h1（106~213px, weight 900, letter-spacing -2px）
- 内容页标题：h2.xp-h2（67px, weight 800, letter-spacing -1px）
- 正文色：--text-2（#5b5470 左右，随 tokens.css 具体值）
- 辅助文字：--text-3（#9089a8，用于 footer）
- 字体：'Noto Serif SC' (标题/序号/斜体强调) + -apple-system/'PingFang SC' (正文/chip)

### SVG 插画规范（T2 若需画 SVG）
- inline SVG，`viewBox` 定尺寸（无 width/height attr），外层容器控宽
- 柔光色块用 `<defs><radialGradient>`（马卡龙色 stop → transparent）
- 实色填用 deck-private 深档 `--xp-*-dd` 或字面量（PPTX 友好，避免依赖 runtime CSS 变量在 SVG attribute 上）
- `<defs><style>` 内用 scoped class 命名，避免污染全局
- 根 `<svg>` 加 `role="img" aria-label="描述"`
- 绽放/绘制类动效可绑 `.anim-bloom` / `.anim-tl-draw`（overlay 段已有 keyframes）

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| .xp-cover-bg / .cover-blob | xhs-pastel-card 无封面专用背景层，统一用 .xp-blob b1/b2/b3 |
| .section-num 水印（293px 超大序号） | xhs-pastel-card 无此元素，章节标识靠色板 chip |
| .card-accent / .card-hover | xhs-pastel-card 卡片无高亮档或 hover 态变体 |
| .gradient-text / 渐变文字 | xhs-pastel-card 强调色用 .rose/.mint class 纯色，不用渐变 |
| .btn-gradient / .ask-box | xhs-pastel-card CTA 用卡片 grid，无独立按钮或渐变框 |
| .glass / 玻璃拟态 | xhs-pastel-card 无此视觉语言 |
| .pill / .pill-accent | xhs-pastel-card 标签用 .xp-chip，不用 pill 组件 |
| 粗重数据大数字（78px+ metric .n） | xhs-pastel-card 数据用 donut SVG 表达，不用独立超大数字 |
| CJK 标题内 `<br>` | 标题换行由 `.xp-h2` 的 keep-all+balance+overflow-wrap 接管（规则⑩），内容里写 `<br>` 会断在词中间 |
