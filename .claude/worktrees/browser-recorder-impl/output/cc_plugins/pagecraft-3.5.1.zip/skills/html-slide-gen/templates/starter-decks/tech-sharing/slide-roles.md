# tech-sharing — Slide Role Catalog

> **模板气质**：GitHub 暗黑工程师风、macOS 终端代码块、语法高亮、mono 字体标识
> **默认 color-scheme**：tokyo-night（暗底 #0d1117，绿 #7ee787 / 蓝 #79c0ff / 红 #ff7b72）
> **适用文稿类型**：传授/赋能（45min 技术分享标准节奏）
> **叙事结构**：SCQA + 三幕剧
> ```
> Act 1 · Why            Act 2 · How             Act 3 · So what
> 01 cover               07 § 02 INTERNALS       12 § 03 PRACTICE
> 02 agenda              08 architecture         13 code (mini-runtime)
> 03 § 01 BACKGROUND     09 deep-dive 1          14 benchmark
> 04 stats-hero          10 deep-dive 2          15 pitfall
> 05 context (3card)     11 code-diff            16 takeaways
> 06 timeline                                    17 resources
>                                                18 qna
> ```

## 角色索引（14 个角色 / 18 张页）

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面 | .speaker, .h1(渐变 accent 词), .mono hashtags |
| 02 | `toc` | 议程 | .agenda-row(.num+.t+.d), .stack |
| 03/07/12 | `section-divider` | 章节分隔（× 3 实例） | .ts-divider · .ts-snum · .ts-stitle · .ts-srule |
| 04 | `stats-hero` | 巨号指标 ring（SVG） | .ts-stats · .ts-ring · .ts-ring-bad/warn |
| 05 | `content-section-3card` | 对比三卡片 | .card-accent · .tag · .grid.g3 |
| 06 | `timeline` | 横向时间线（SVG） | .ts-timeline · .ts-tl-track · .ts-tl-node |
| 08 | `architecture` | 系统架构图（盒子+连线） | .ts-arch · .ts-arch-box · .ts-ab-accent/secondary/dashed |
| 09 | `content-text-code` | 左文右代码 | .terminal · .grid.g2 · 语法高亮 |
| 10 | `content-text-card` | 左文右步骤卡片 | .grid.g2 · .card · 步骤序号 |
| 11 | `code-diff` | Before/After 代码对比 | .ts-diff · .ts-diff-pane.before/after · .ts-diff-add/del |
| 13 | `content-code` | 纯代码展示 | .terminal · 语法高亮 |
| 14 | `benchmark` | 横向基准条形图 | .ts-bench · .ts-bench-row · .ts-bench-fill |
| 15 | `pitfall` | 反例陷阱卡 | .ts-pitfall · .ts-pf-icon(SVG ✕) · .ts-pf-snippet · .ts-pf-fix |
| 16 | `content-takeaways` | 三要点+延伸阅读 | .card-accent × 3 · .lede |
| 17 | `resources` | 三列分类延伸阅读 | .ts-res · .ts-res-col · .ts-res-cat(SVG icon) |
| 18 | `qna` | Q&A | .center.tc · 160px "?" · .tag |

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`event_label`, `headline`, `headline_accent`, `subtitle`, `speaker_name`, `speaker_info`, `hashtags`
- **不可改动**：.speaker 组件结构、.deck-footer 位置、h1 字号(105px)/字重(800)
- **内容适配规则**：
  - `headline` 含一个 `<span style="background:var(--grad);...">` 渐变 accent 词(key: `headline_accent`)，替换时保留 span+style
  - `speaker_info` 格式 `"团队 · 时长 + Q&A"`
  - `hashtags` 用 `.mono` 包裹，格式 `#tag1 #tag2 #tag3`

### `toc`
- **源文件**：`slides/02-agenda.html`
- **可替换键**：`toc_label`, `toc_title`, `item_1_num`~`item_5_num`, `item_1_title`~`item_5_title`, `item_1_dur`~`item_5_dur`
- **不可改动**：.agenda-row 结构(.num+.t+.d)、.stack 垂直排列、.kicker mono 风格
- **内容适配规则**：议程项数 3~6，每项标题 ≤ 25 字，`_dur` 格式 `"~Nmin"`

### `section-divider`（× 3）
- **源文件**：`slides/03-section-1.html` · `slides/07-section-2.html` · `slides/12-section-3.html`
- **可替换键**：`section_num`, `section_title`, `section_title_accent`, `section_summary`
- **不可改动**：.ts-divider 容器、.ts-stitle 字号(168px)/字重(800)、.ts-srule 4px accent 横线、.ts-sdots `· · ·` 收尾
- **内容适配规则**：
  - `section_num` 格式 `"§ 01 · UPPERCASE"`，mono 字体，accent 色
  - `section_title` 1-3 个英文词或 4-8 个 CJK 字，巨字号；含一个 `<span data-replace="section_title_accent">` 渐变 accent 词（同 cover）
  - `section_summary` 30-60 字一句话摘要
  - footer 显示进度 `01 / 03` `02 / 03` `03 / 03`
- **新增章节**：复制任意一张 divider，改 `section_num` / `section_title` / `section_summary`，新增的 iframe 插到目标位置即可

### `stats-hero`
- **源文件**：`slides/04-stats.html`
- **可替换键**：`section_label`, `section_title`, `stat_1_num`~`stat_3_num`, `stat_1_unit`~`stat_3_unit`, `stat_1_label`~`stat_3_label`, `stat_1_desc`~`stat_3_desc`
- **不可改动**：.ts-stats grid 3 列、.ts-ring SVG 结构（圆周 ≈ 276，r=44）、.ts-ring-num 字号(56px)
- **内容适配规则**：
  - 每个 ring 用 `stroke-dasharray="<filled> <gap>"` 指定填充比例，`<filled>+<gap>=276`（如 92% → `254 22`）
  - 颜色按情绪：accent = 正向（节省/提升）、warn = 中性警告、bad = 负向痛点（在 .ts-ring 上加 `.ts-ring-warn` / `.ts-ring-bad`）
  - `stat_*_num` 大数字+小单位：`<span style="font-size:.5em;color:var(--text-2)">单位</span>`
  - `stat_*_label` ≤ 14 字，`stat_*_desc` ≤ 40 字
- **指标数量调整**：3 个为标准；2 个把 grid-template-columns 改为 `repeat(2, 1fr)`，4 个改 `repeat(4, 1fr)` 并缩小 ring（180px）

### `content-section-3card`
- **源文件**：`slides/05-context.html`
- **可替换键**：`section_label`, `section_title`, `card_1_title`~`card_3_title`, `card_1_body`~`card_3_body`, `card_1_tag`~`card_3_tag`
- **不可改动**：.card-accent（顶部 5px accent 色条）、.tag 样式、.grid.g3
- **内容适配规则**：每个卡片含标题+正文+tag 标签，tag ≤ 10 字；.kicker 用 mono 风格标签（如 `// context`）
- **卡片扩展/收缩**：3 张为标准。2 张改 .grid.g2，4 张改 .grid.g4 并缩字号

### `timeline`
- **源文件**：`slides/06-timeline.html`
- **可替换键**：`section_label`, `section_title`, `t1_year`~`t5_year`, `t1_title`~`t5_title`, `t1_desc`~`t5_desc`
- **不可改动**：.ts-tl-track 横线渐变、.ts-tl-node::before 圆点装饰、最后一个节点加 `.ts-tl-now` class（实心点）
- **内容适配规则**：
  - 节点数由 `style="--ts-tl-n: N"` 控制（默认 5；范围 3~6）
  - `t*_year` ≤ 6 字符（年份/版本号/`now`）
  - `t*_title` ≤ 14 字，`t*_desc` ≤ 28 字（mono 字体）
- **节点增减**：删 .ts-tl-node 同时改 `--ts-tl-n` 数字

### `architecture`
- **源文件**：`slides/08-architecture.html`
- **可替换键**：`section_label`, `section_title`, `L1_label`/`L1_name`/`L1_meta`, `L1b_*`, `L2_*`/`L2b_*`/`L2c_*`, `L3_*`/`L3b_*`
- **不可改动**：.ts-arch 三列 grid、.ts-arch-box 三种变体（裸 / .ts-ab-accent / .ts-ab-secondary / .ts-ab-dashed）、左 3px 色条
- **内容适配规则**：
  - 列数 2~4，每列 1~3 个盒子（用 .ts-arch-stack 包裹同列盒子）
  - 用 `.ts-ab-accent`（绿）= 核心组件，`.ts-ab-secondary`（蓝）= 入口/出口，`.ts-ab-dashed` = 协议/契约
  - `L*_label` ≤ 14 字符（uppercase mono）、`L*_name` ≤ 18 字、`L*_meta` ≤ 50 字
- **连线**（可选）：在 .ts-arch 内加 `<svg class="ts-arch-svg">...<path d="..."/></svg>` 画连接线，stroke 走 var(--accent)；不加连线也能用，盒子的 border-left 已是结构提示

### `content-text-code`
- **源文件**：`slides/09-deep-dive-1.html`
- **可替换键**：`section_label`, `section_title`, `lede_text`, `tag_1`~`tag_3`, `code_title`, `code_block`
- **不可改动**：.terminal（macOS chrome .bar + .dot×3）、.grid.g2 左右分栏、语法高亮 class(.kw/.fn/.str/.cmt/.num)
- **内容适配规则**：`code_block` 保留语法高亮 span 结构，`lede_text` ≤ 80 字

### `content-text-card`
- **源文件**：`slides/10-deep-dive-2.html`
- **可替换键**：`section_label`, `section_title`, `lede_text`, `feature_1`~`feature_4`, `card_title`, `step_1`~`step_5`
- **不可改动**：.grid.g2 左右分栏、.card padding(43px)、步骤序号(1.-5.)色
- **内容适配规则**：feature 项数 3~5，步骤项数 3~6

### `code-diff`
- **源文件**：`slides/11-code-diff.html`
- **可替换键**：`section_label`, `section_title`, `before_title`, `before_code`, `after_title`, `after_code`
- **不可改动**：.ts-diff 双栏 grid、.ts-diff-pane.before/.after 红绿 tag、.ts-diff-add / .ts-diff-del / .ts-diff-ctx 行级 class、行前 +/− 装饰
- **内容适配规则**：
  - 每行用 `<span class="ts-diff-line ts-diff-add">...</span>` 包裹（add = 绿、del = 红、ctx = 中性）
  - before 段全部用 .ts-diff-del + .ts-diff-ctx；after 段全部用 .ts-diff-add + .ts-diff-ctx
  - 两段行数尽量对齐（用空 `.ts-diff-line.ts-diff-ctx` 占位），保持视觉对称
  - 单段 ≤ 14 行（max-height: 560px 限）

### `content-code`
- **源文件**：`slides/13-code.html`
- **可替换键**：`section_label`, `section_title`, `code_title`, `code_block`
- **不可改动**：.terminal 结构、语法高亮 class
- **内容适配规则**：代码 ≤ 25 行

### `benchmark`
- **源文件**：`slides/14-benchmark.html`
- **可替换键**：`section_label`, `section_title`, `b1_label`~`b5_label`, `b1_value`~`b5_value`, `bench_note`
- **不可改动**：.ts-bench grid（280px label / 1fr track / 140px value）、.ts-bench-fill 渐变、.ts-bench-row.ts-bench-bad/warn 变体
- **内容适配规则**：
  - 每行用 `style="--ts-bench-w: NN%"` 控制条形长度（最大值 100%，其他按比例）
  - 颜色按情绪：默认 accent gradient = 正向/最强者；`.ts-bench-warn` = 中性、`.ts-bench-bad` = 垫底/失败
  - `b*_label` ≤ 22 字符（mono），`b*_value` 大数字 + 单位
  - 行数 3~6（多了挤）
  - `bench_note` 用 lede + mono 标注测试条件（机器型号、参数、时间）
- **改造为正向比较**：把 `.ts-bench-bad` 全去掉，改成纯 accent 渐变阶梯即可

### `pitfall`
- **源文件**：`slides/15-pitfall.html`
- **可替换键**：`section_label`, `section_title`, `pitfall_title`, `pitfall_body`, `pitfall_snippet`, `pitfall_fix`
- **不可改动**：.ts-pitfall 红色边框 + 左 4px bad 色条、.ts-pf-icon SVG ✕、.ts-pf-snippet mono 代码块、.ts-pf-fix `→` 前缀
- **内容适配规则**：
  - `pitfall_title` ≤ 24 字，单句结论
  - `pitfall_body` ≤ 100 字，描述"为什么这样会出事"
  - `pitfall_snippet` 反例代码片段 ≤ 8 行
  - `pitfall_fix` ≤ 50 字，描述修复方向
- **多个陷阱同页**：复制 .ts-pitfall 块；建议每页 1-2 个，>2 改成 .grid.g2 并简化 snippet

### `content-takeaways`
- **源文件**：`slides/16-takeaways.html`
- **可替换键**：`section_label`, `section_title`, `takeaway_1_title`~`takeaway_3_title`, `takeaway_1_body`~`takeaway_3_body`, `further_reading`
- **不可改动**：.card-accent × 3、.lede 延伸阅读行
- **内容适配规则**：每项标题 ≤ 15 字，正文 ≤ 30 字

### `resources`
- **源文件**：`slides/17-resources.html`
- **可替换键**：`section_label`, `section_title`, `cat_1`~`cat_3`, `r1_name`~`r9_note`（每列 3 项 × 3 列）
- **不可改动**：.ts-res grid 3 列、.ts-res-cat dashed 下边框 + SVG icon、.ts-res-item 卡片样式
- **内容适配规则**：
  - 列分类：默认 Books/Specs · Blogs/Talks · Repos/Code，可改成 Docs/Code/Community 等组合
  - `r*_name` ≤ 32 字符（mono，URL 或仓库名），`r*_note` ≤ 40 字
  - 每列 2-4 项；要更多用 .ts-res-list 内增加 .ts-res-item

### `qna`
- **源文件**：`slides/18-q-and-a.html`
- **可替换键**：`qna_title`, `contact_info`, `link_1`, `link_2`
- **不可改动**：.center.tc 居中、160px "?" 装饰、.tag 样式

---

## 角色匹配决策树

```
1. 封面 → cover                                   议程 → toc                Q&A → qna
2. 章节切换/三幕剧节奏 → section-divider（每个 act 起点放一张）
3. 痛点数字/3 个量化指标对照 → stats-hero
4. 历史演进/版本时间线/阶段进展 → timeline
5. 系统组件 + 关系/数据流 → architecture
6. 同样逻辑的两种写法对比 → code-diff
7. 多方案吞吐/性能/成本横评 → benchmark
8. 反例 + 解释 + 修复方向 → pitfall
9. 分类延伸阅读（书/博客/repo） → resources
10. 三卡片对比/并列概念 → content-section-3card
11. 文字 + 代码并列 → content-text-code
12. 文字 + 步骤卡片并列 → content-text-card
13. 纯代码展示（>15 行） → content-code
14. 三要点 + 总结 → content-takeaways
15. 不匹配 → T2 fallback
```

---

## Style Transfer — T2 页面继承规则

### 空间密度对齐
- body padding: `96px 142px`
- grid gap: 32px, stack gap: 19px
- 章节 divider 标题字号：168px（其余巨号场景对齐）

### 装饰模式继承
- 内容页顶部用 `.kicker`（mono 风格标签，自带 `> ` 前缀，如 `// section-name`）
- 卡片统一用 `.card-accent`（顶部 5px accent 色条）
- 代码块统一用 `.terminal`（macOS chrome + 语法高亮 .kw/.fn/.str/.cmt/.num）
- 章节切换页统一用 `.ts-divider`（巨号 § + 4px accent rule）
- 数字/指标统一用 `.ts-ring`（SVG 进度环）
- 横评/性能比较统一用 `.ts-bench`（横向条形图）
- 反例/警告统一用 `.ts-pitfall`（红边 + ✕ icon）

### 组件类名统一
- 卡片：`.card-accent`（不用裸 `.card`）
- 标签：`.tag`（不用 `.pill`）
- 代码：`.terminal > .bar + pre`（不用裸 `<pre>`）
- 等宽文字：`.mono`
- deck 私有组件：`.ts-*` 前缀（防污染）

### SVG 插图规则
- 全部内联到 slide HTML（不外置文件）
- 颜色用 `currentColor` 或 `var(--accent)` / `var(--bad)` / `var(--good)` / `var(--brand-warn)`，**不写字面 hex 色**——保证 switch-theme 联动换肤
- `stroke` 而非 `fill` 优先（线性插图气质 > 实心块）
- 指标 ring 用 `<circle r="44">`（圆周 ≈ 276，方便算 dasharray）
- icon 字号 20-48px，统一 `stroke-width: 2`

### 排版层级对齐
- 内容页标题：h2, 72px, weight 700, letter-spacing -0.025em，色 `#fff`
- 章节 divider 标题：168px, weight 800, letter-spacing -0.04em
- kicker: 18px, weight 600, color: var(--accent)，自带 `> ` mono 前缀
- 正文字色：var(--text-2)（dim）/ #fff（强调），用 class `.dim` / 直接 inline

### 颜色情绪映射（新页延用）
| 情绪 | token | 用法 |
|------|-------|------|
| 正向/主线 | `var(--accent)` (绿 #7ee787) | 主调，最常用 |
| 入口/桥接 | `var(--accent-2)` (蓝 #79c0ff) | 次调，对比 |
| 痛点/警告 | `var(--bad)` (红 #f85149) | pitfall 边框、bench 垫底、ring-bad |
| 中性提示 | `var(--brand-warn)` (黄) | bench-warn、中等指标 |
| 成功/修复 | `var(--good)` (绿) | diff-add、pf-fix `→` 前缀 |

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| .pill / .pill-accent | tech-sharing 用 .tag 和 .card-accent，无 pill 系统 |
| .gradient-text class | tech-sharing 用 inline style `background:var(--grad);-webkit-background-clip:text;...` 实现渐变（仅出现在 cover/divider 的强调词） |
| .slide-top-bar / .ambient-glow | tech-sharing 暗底已有 radial-gradient 光晕，无需额外装饰层 |
| .section-num 水印 | tech-sharing 用 `.ts-divider` 整页 + `.kicker` 做章节标识，无序号水印 |
| .cover-bg / .cover-blob | tech-sharing 封面背景已是 deck 全局 radial-gradient |
| 写死字面色（如 `#7ee787` `#ff7b72`） | 必须走 `var(--accent)` / `var(--bad)` 等语义 token，否则 switch-theme 不联动 |
| 字面 rgba（如 `rgba(126,231,135,.12)`） | 必须用 `rgba(var(--brand-primary-rgb), .12)` 通道形式 |
| `<br>` 在巨号标题里手工换行 | 用 CSS `word-break:keep-all; overflow-wrap:break-word; text-wrap:balance` 三件套；偶发误判用 `<wbr>` 修，不写 `<br>` |
