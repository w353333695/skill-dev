# 品牌设计资产管理指南

## 核心原则

品牌资产是演示文稿视觉一致性的根基。所有设计决策必须追溯到 `slides-output/<name>/brand-spec.md`——它是**唯一设计真相来源（Single Source of Truth）**。

---

## 与项目文件结构的关系

```
slides-output/<name>/
├── brand-spec.md           # 本文件：资产清单 + 设计规范
└── export/<name>-live/
    ├── shared/tokens.css   # 运行时：从 brand-spec 提取的 CSS 变量 + 通用组件 + 动画
    ├── assets/             # 图片资产：logo、产品图等（slides 通过 ../assets/ 引用）
    └── slides/             # 每页 HTML 通过 ../shared/tokens.css 使用 token
```

brand-spec.md 是"设计合同"——人类可读、AI 可追溯。`shared/tokens.css` 是"运行时实现"——从 brand-spec 中的色板、字体、间距生成 CSS 变量，供所有 slides 使用。

---

## brand-spec.md 完整模板

```markdown
# <Brand> · Brand Spec
> 采集日期：YYYY-MM-DD
> 资产来源：<列出下载来源 / "用户已有资产（已复制到 assets/）">
> 资产完整度：<完整 / 部分 / 推断>
> 模板: <模板名>（如 pitch-deck / corporate-clean）
> 主题: <主题名>（如使用主题而非模板）
> 文稿类型: <说服/促动 | 信息同步 | 传授/赋能 | 启发/共鸣>
> 场景关键词: <逗号分隔，如"技术分享, 架构, 工程师团队">
> 上次选择: <模板名 或 主题名>（供后续会话偏好记忆，格式同 模板:/主题: 字段）

## 核心资产（一等公民）

### Logo
- 主版本：`assets/logo.svg`
- 浅底反色版：`assets/logo-white.svg`
- 深底版（如有）：`assets/logo-dark.svg`
- 使用场景：<片头 / 片尾 / 角落水印 / 全局>
- 禁用变形：<不能拉伸 / 改色 / 加描边 / 旋转>

### 产品图（实体产品必填）
- 主视角：`assets/product-hero.png`（建议 2000×1500）
- 细节图：`assets/product-detail-1.png` / `product-detail-2.png`
- 场景图：`assets/product-scene.png`
- 使用场景：<特写 / 旋转 / 对比>

### UI 截图（数字产品必填）
- 主页：`assets/ui-home.png`
- 核心功能：`assets/ui-feature-<name>.png`
- Dashboard：`assets/ui-dashboard.png`
- 使用场景：<产品展示 / 渐现 / 对比演示>

## 辅助资产

### 色板
- Primary: #XXXXXX  <来源标注>
- Secondary: #XXXXXX
- Background: #XXXXXX
- Surface: #XXXXXX
- Ink / Text: #XXXXXX
- Accent: #XXXXXX
- Good / 成功: #XXXXXX
- Warn / 警告: #XXXXXX
- Bad / 错误: #XXXXXX
- 禁用色：<品牌明确不用的色系>

### 字型
- Display（标题）: <font stack>
- Body（正文）: <font stack>
- Mono（代码 / 数据 HUD）: <font stack>

### 签名细节
- <哪些细节是"120% 做到"的——比如圆角大小、阴影风格、线条粗细>

### 禁区
- <明确不能做的：比如不用蓝色、不用渐变、不用低饱和暖色>

### 气质关键词
- <3-5 个形容词，指导整体视觉调性>
```

---

## 资产获取流程

### Step 1：问用户

> "你们有品牌规范吗？有 logo 源文件和标准色板吗？"

如果用户提供了品牌手册或设计文件路径，**必须将所有引用的图片资产复制到 `slides-output/<name>/export/<name>-live/assets/`**，brand-spec.md 只记录本地相对路径。

### Step 2：搜索官方渠道（用户无资产时）

- `<brand>.com/brand` 或 `/press` 或 `/media-kit`
- 搜索 `<brand> brand guidelines pdf`
- GitHub 组织页的 `.github/` 目录
- 社交媒体头像（作为 logo 的最低保底）

### Step 3：下载与提取（3 条 fallback 路径）

**Logo 获取优先级：**
1. SVG 矢量文件（最佳）
2. 从品牌官网 HTML 中提取内联 SVG
3. 高清 PNG 社交头像（最低保底）

**色板提取方法：**
1. 品牌手册中明确标注的颜色
2. 从 SVG logo 中 grep 提取 `#xxxxxx` 颜色值
3. 从官网截图用取色器提取

### Step 4：验证

- 确认 logo 在深色背景和浅色背景上均可识别
- 确认色板中的颜色对比度足够（WCAG AA 标准）
- 确认字体在浏览器中可正常渲染

### Step 5：固化为 brand-spec.md

写入模板，后续所有 HTML 引用此文件。

---

## 写入后的硬要求（执行纪律）

1. 所有图片资产**必须复制到 `slides-output/<name>/export/<name>-live/assets/`**，brand-spec.md 只记录 `assets/` 下的相对路径
2. 所有 HTML **禁止引用 `assets/` 目录之外的图片路径**——这会导致打包迁移断链
3. Logo 作为 `<img>` 引用真实文件，NEVER 用 CSS 剪影或 SVG 手画代替
4. 产品图作为 `<img>` 引用真实文件，NEVER 用 CSS 占位符代替
5. `shared/tokens.css` 从 brand-spec 注入 CSS 变量：`:root { --brand-primary: ...; }`
6. 所有 slides 通过 `<link>` 引用 `../shared/tokens.css`，NEVER 内联重复样式
7. 想临时加色或改设计参数，**先改 `brand-spec.md`**，再更新 `shared/tokens.css`

这让品牌一致性从"靠自觉"变成"靠结构"。

---

## 过程中新产生的资产

在设计过程中可能会产生新的设计素材，也纳入 `slides-output/<name>/export/<name>-live/assets/` 管理：

```
slides-output/<name>/export/<name>-live/assets/
├── logo.svg            # logo 相关
├── logo-white.svg
├── icon-*.svg          # 过程中产生的图标
├── bg-*.png            # 背景图、装饰图
└── ...                 # 其他设计素材
```

**规则：**
- 每产生一个新资产，立即在 `brand-spec.md` 中登记路径
- 图片类资产建议提供 2x 分辨率（Retina 适配）
- SVG 优先于 PNG（矢量无损、文件更小）
- 资产命名规范：`<用途>-<描述>.<格式>`，如 `bg-gradient-dark.svg`、`icon-check.svg`

---

## 全流程失败的兜底

如果经过上述流程仍然无法获得任何品牌资产（用户没有、官网找不到、搜索无结果）：

1. 使用 `scripts/color-schemes.json`（40 个颜色方案）选择配色，注入 `templates/shared/tokens.css`
2. 使用 `references/slides-gallery.md` 匹配场景合适的 starter-deck 模板作为风格基础
3. 在 `brand-spec.md` 中标注"资产完整度：推断"，说明使用的颜色方案和模板
4. 继续推进——不要因为没有品牌资产而阻塞整个流程

**底线原则：没有品牌资产 ≠ 没有设计。** 用 40 个颜色方案 + 23 个 starter-deck 模板兜底，保证视觉下限在 70 分以上。
