#!/usr/bin/env node

import path from 'node:path';

function parseArgs(argv) {
  const options = {
    format: 'url',
    label: 'Elevo Preview',
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--file') {
      options.file = argv[i + 1];
      i += 1;
      continue;
    }
    if (arg === '--base-url') {
      options.baseUrl = argv[i + 1];
      i += 1;
      continue;
    }
    if (arg === '--workspace-id') {
      options.workspaceId = argv[i + 1];
      i += 1;
      continue;
    }
    if (arg === '--format') {
      options.format = argv[i + 1];
      i += 1;
      continue;
    }
    if (arg === '--label') {
      options.label = argv[i + 1];
      i += 1;
      continue;
    }
  }

  return options;
}

function normalizeWorkspaceFilePath(filePath) {
  const absoluteOrRelative = path.isAbsolute(filePath)
    ? path.relative(process.cwd(), filePath)
    : filePath;

  return absoluteOrRelative.replace(/\\/g, '/').replace(/^\.\//, '');
}

function buildPreviewUrl({ baseUrl, workspaceId, filePath }) {
  const url = new URL(`/workspaces/${workspaceId}`, baseUrl);
  url.searchParams.set('view', 'files');
  url.searchParams.set('file', filePath);
  return url.toString();
}

const args = parseArgs(process.argv.slice(2));
const baseUrl = args.baseUrl || process.env.AGENT_FRONTEND_BASE_URL || 'http://localhost:3000';
const workspaceId = args.workspaceId || process.env.AGENT_WORKSPACE_ID || process.env.ELEVO_WORKSPACE_ID;

if (!args.file) {
  console.error('Missing required --file argument');
  process.exit(1);
}

if (!workspaceId) {
  console.error('Missing workspace id. Pass --workspace-id or run inside Elevo with AGENT_WORKSPACE_ID.');
  process.exit(1);
}

const filePath = normalizeWorkspaceFilePath(args.file);
const url = buildPreviewUrl({ baseUrl, workspaceId, filePath });

if (args.format === 'markdown') {
  console.log(`[${args.label}](${url})`);
  process.exit(0);
}

console.log(url);
