# biz-review — Slide Role Catalog

> **模板气质**：业务复盘风（高管级）—— 白底 + 深海蓝 + 亮蓝数据强调、中等圆角、克制微阴影、表格化数字纪律（tabular-nums）、直线递进叙事（回顾→规划）、面向高管而非团队同步。
> **默认 color-scheme**：`ocean-depths`（深海蓝 `#0a2540` + 亮蓝 `#1d4ed8`，白底）。有意区别于 consultant-strategy 的 mckinsey 蓝绿与 weekly-report 的轻扁平。
> **switch-theme**：已接入。`shared/tokens.css` §2 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 为换肤入口；所有 `br-*` 组件与语义 token 均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 一键切换。适合切换为 `mckinsey-blue`（麦肯锡蓝）、`consulting-navy`（深蓝投行）、`midnight-ink`（午夜墨蓝）等。
> **适用文稿类型**：信息同步 + 说服（quarterly/annual business review, QBR, operating review, 绩效复盘, 季度经营汇报）。
> **动效强度**：强档（参 motion-system.md）。挂载契约 `class="语义class anim-class delay-class"`，iframe 重载即重播。语义映射：
> - KPI/大数字 → `.anim-scale-pop`（数字独立砸）；进度/归因条 → `.anim-bar-grow`（从左生长）
> - 封面/致谢 hero、收束金句 → `.anim-blur-in`；决议推荐项/当前阶段 → `.anim-slide-r`（方向强调）
> - 卡片/列表/表格 → `.anim-fade-up` + `.anim-d1..d14` stagger（90ms 节拍）；环境元素（kicker/footer/chart axis）→ 仅 `.anim-fade`
> - reduced-motion + print 兜底见 `shared/tokens.css`（动画终态直接显示，导出不空白）
> **叙事结构（14 页，直线递进，非 SCQA）**：cover → agenda → period-recap → core-results → kpi-wall → highlight-expand → metric-deepdive → gap-analysis → challenges-risks → next-roadmap → key-initiatives → resource-ask → decisions → thanks。
>
> 01–02 为「开篇」（封面 + 议程）；03–04 为「回顾」（周期 scorecard + 核心成果）；05–07 为「数据」（KPI 墙 + 亮点展开 + 月度趋势）；08–09 为「差距与风险」（差距分析账本 + 风险登记）；10–11 为「计划」（Q3 路线图 + 重点举措）；12–13 为「资源与决议」（资源申请 + 待批决议）；14 为「收束」（决议与审批清单）。
> 其中 **05（kpi-wall）/ 06（highlight-expand）/ 08（gap-analysis）/ 12（resource-ask）/ 14（审批清单）为本 deck 特色角色页**，承载 `br-*` 标志组件。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 业务复盘封面：周期带 + 标题 + 副标题 + 右侧本期成绩单 + 底部元信息（周期/业务线/汇报对象/编制） | `.bar-top`, `.br-cover-band`, `.eyebrow`, `.h1`, `.lede`, `.card-accent/.card-warn`, `.br-status`, `.br-cover-meta` |
| 02 | `agenda` | 议程：6 节点横向「直线递进」脊柱 + 三焦点卡 | `.br-masthead`, `.br-period-chip`, `.grid.g6`(编号圆节点 + 连接线), `.card-accent/.card-warn/.card-outline`, `.br-status` |
| 03 | `period-recap` | 周期回顾：6 项目标达成 scorecard（目标 vs 实际 + 达成率 + 状态） | `.br-masthead`, `.br-scorecard`(`.br-goal` + `.br-goal-vals` + `.br-progress`/`.br-progress-fill`/`.br-progress-mark`), `.br-status` |
| 04 | `core-results` | 核心成果：大数字 hero（L10 stat-highlight）+ 三项增长结构支撑 + 小结横条 | `.br-masthead`, `.card-accent`(`.h1.mono` 124px 大数字), `.card-good`×3, `.br-callout`, `.br-status` |
| 05 | `kpi-wall` | KPI 总览墙：8 KPI 网格（当期值/环比/同比/达标状态/mini sparkline） | `.br-masthead`, `.kpi-wall`, `.kpi-tile`(`.good/.warn/.bad`), `.kpi-value`, `.kpi-deltas`, `.br-spark`, `.br-status` |
| 06 | `highlight-expand` | 亮点展开：1 大亮点 hero + 数据支撑 + 归因拆解条 + 启示 | `.br-masthead`, `.highlight-expand`(`.he-hero` + `.he-side`), `.he-support`, `.br-attrib`(`.br-attrib-bar`/`.br-attrib-seg`/`.br-attrib-legend`), `.br-callout` |
| 07 | `metric-deepdive` | 数据深潜：月度新签 ARR inline SVG 趋势图 + 三读图要点 | `.br-mastcard`(`.br-chart-card` + `.br-trend` SVG), `.card-good/.card-warn/.card-accent`, `.br-chart-legend` |
| 08 | `gap-analysis` | 差距分析：目标·实际·根因·行动 4 列账本（3 项未达标）+ 闭环横条 | `.br-masthead`, `.gap-analysis`(`.col-target/.col-actual/.col-cause/.col-action`, `.ga-target/.ga-actual/.ga-gap/.ga-cause/.ga-action`), `.br-callout.warn` |
| 09 | `challenges-risks` | 挑战与风险：3 战略挑战卡 + 风险登记表（概率×影响） | `.grid.g3`(`.card-warn`), `.gap-analysis`(风险表), `.pill-good/.pill-warn/.pill-bad`(概率/影响) |
| 10 | `next-roadmap` | Q3 路线图：4 阶段无缝网格（当前阶段高亮）+ 3 项目标 | `.br-masthead`, `.br-roadmap`(`.br-rm-col.now` + `.br-rm-phase/.br-rm-title/.br-rm-body/.br-rm-owner`), `.card-accent`×3 |
| 11 | `key-initiatives` | 重点举措：4 项举措卡（首项 hero）+ 优先级小结 | `.br-masthead`, `.br-init-grid`, `.br-init.hero`, `.br-init-num/.br-init-title/.br-init-body/.br-init-kpi`, `.br-callout` |
| 12 | `resource-ask` | 资源需求：人力/预算/优先级/回报表 + 汇总行 + ROI 三卡 | `.br-masthead`, `.resource-ask`(`.ra-item/.ra-headcount/.ra-budget/.ra-return` + `tfoot`), `.card-accent/.card-good/.card-warn`, `.pill` |
| 13 | `decisions` | 决议事项：3 项待批决议（议题 + 选项 A/B + 推荐 + 决议人 + 截止） | `.br-masthead`, `.br-decision`(`.br-dc-issue/.br-opt.rec/.br-dc-approver`, `.br-opt-rec`), `.br-period-chip` |
| 14 | `thanks` | 决议与审批清单（致谢页）：行动决议清单 + 资源审批清单 + 会签路由（**非人员卡**） | `.bar-top`, `.br-approval`(`.br-approval-col` + `.br-approval-item` + `.br-ap-check.pending`), `.br-period-chip` |

---

## 角色详情

### 01 — `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`period_text`, `business_line`, `headline`, `subtitle`, `sc_1/2/3`(_val), `cm_period`, `cm_line`, `cm_audience`, `cm_date`, `footer_source`
- **不可改动**：`body` `justify-content:space-between`（顶带/中部/底元三段）、`.bar-top` 顶部 5px 亮蓝条、`.br-cover-meta` 4 等分边框单元格、右侧成绩单 3 卡顺序（超额/未达/超额）
- **内容适配规则**：
  - 业务复盘式封面：必须含「周期 + 业务线 + 汇报对象 + 编制日期」四元信息（区别于咨询项目元数据 / 周报 week-chip）
  - 右侧「本期成绩单」3 卡 = 1 超额 + 1 未达 + 1 超额，体现复盘的「成绩与差距并存」基调；替换时保留好坏混合
  - `headline` 为「QX 业务复盘与 QX+1 规划」式，CJK 换行交由 CSS（不写 `<br>`）

### 02 — `agenda`
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `p1~6_title/desc`, `focus_label`, `f1~3_tag/title/body/status`
- **不可改动**：6 编号圆节点等宽(`.grid.g6`)、连接主线(absolute, 亮蓝→深海蓝渐变)、三焦点卡状态色(成绩=exceeded/差距=missed/决议=ongoing)
- **内容适配规则**：
  - 直线递进骨架 = 6 阶段（周期回顾→核心成果→KPI→差距→计划→资源），节点编号 01–06 顺序不可调
  - 三焦点卡 = 1 成绩 + 1 差距 + 1 待决议，对应 deck 三个核心信息

### 03 — `period-recap`
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `subtitle`, `g1~6_name/sub/actual/target/status/pct/note`, `footer_source`
- **不可改动**：`.br-scorecard` 2 列、6 `.br-goal` 卡、`.br-progress-fill` width:% 必须与达成率一致、`.br-progress-mark`（100% 标尺）位置 = 目标占比、状态 badge 颜色(met/good, missed/bad, 近达标/warn)
- **内容适配规则**：
  - 6 项目标应混合「达标/超额/未达标」，体现真实复盘（不要全绿）
  - `g*_actual` 达标用 `var(--accent)`、未达标 inline 改 `color:var(--bad)`、近达标 `var(--warn)`

### 04 — `core-results`
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `hero_label/value/delta/vs/note`, `support_label`, `s1~3_val/title/body`, `co_tag/co_body`, `footer_source`
- **不可改动**：左 hero `.h1.mono` 124px、3 支撑卡 `.card-good` 等宽 + 左大数字(`.h3.mono` 130px 定宽对齐)、小结横条 `.br-callout`
- **内容适配规则**：hero 大数字 = 当期最核心成果（如 ARR）；3 支撑 = 增长结构证据（客单价/续费/增购），三向同向改善才成立

### 05 — `kpi-wall`（特色页）
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `k1~8_name/value/qoq/yoy/status`, `footer_source`
- **不可改动**：`.kpi-wall` 4 列网格(8 格)、每格 `.kpi-tile` 左 4px 色条(`.good/.warn/.bad`)、`.kpi-deltas` 双列(环比/同比)、`.br-spark` mini 折线、`.br-status` 达标 badge
- **内容适配规则**：
  - 8 KPI 必须含「当期值 + 环比 QoQ + 同比 YoY + 达标状态 + 趋势」五要素——这是区别于 weekly `.kpi`（仅 value+▲▼delta）的核心
  - `.kpi-tile` 状态 class（good/warn/bad/无）需与 `.br-status` 达标判定一致
  - `.br-spark` 折线方向应与趋势一致（上升用递增点序、下降用递减）

### 06 — `highlight-expand`（特色页）
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `he_eyebrow/he_num/he_unit/he_title/he_lede`, `sup1~3_num/lbl`, `attr_title/attr_sum`, `seg1~4`(宽度%), `lg1~4_name/pct`, `co_tag/co_body`, `footer_source`
- **不可改动**：`.highlight-expand` 2 列(hero 左 / 支撑+归因 右)、`.he-hero` 渐变浅底 + `.he-num` 96px、`.br-attrib-bar` 各段宽度% 之和必须 = 100%
- **内容适配规则**：
  - 聚焦**单一**大亮点（非三卡）——hero 一个核心数字 + 一句话业务含义
  - `.br-attrib` 归因段宽度 = 各因子贡献%，4 段之和必须 = 100%；段内文字 = 百分比

### 07 — `metric-deepdive`
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `chart_title/sub`, `lg_main/lg_target`, SVG 数据点(inline), `pt1~3_tag/val/title/body`, `footer_source`
- **不可改动**：`.br-chart-card` 左 / 三要点右、`.br-trend` SVG viewBox `0 0 900 320`、目标参考线(amber 虚线)、主线(亮蓝)+面积+末点高亮
- **内容适配规则**：SVG 数据点坐标需与实际月度值一致（y 越小值越大）；右栏 3 要点 = 加速 / 放缓 / 趋势，体现客观读图（不只讲好）

### 08 — `gap-analysis`（特色页）
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `h_metric/target/actual/cause/action`, `r1~3_metric/target/actual/gap/cause/action`, `co_tag/co_body`, `footer_source`
- **不可改动**：`.gap-analysis` 5 列(指标/目标/实际/根因/行动)、表头四色(目标-深海、实际-亮蓝、根因-amber、行动-绿)、`.ga-actual` 未达标红 / 近达标 amber + `.ga-gap` 缺口
- **内容适配规则**：
  - 每行 = 一个未达标项，闭环到「根因 + Q3 行动」（行动含 `<b>` 加粗的关键举措）
  - 行动必须可在后续 page（11 举措 / 12 资源）追溯，形成闭环

### 09 — `challenges-risks`
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `ch1~3_tag/title/body/status`, `risk_label`, `rh_risk/prob/imp/owner/action`, `r1~4_risk/prob/imp/owner/action`, `footer_source`
- **不可改动**：上 3 挑战卡(`.card-warn` 等宽) + 下风险登记表(`.gap-analysis` 表)、概率/影响 pill 颜色(低=good/中=warn/高=bad)
- **内容适配规则**：挑战卡与风险表内容不重复——挑战 = 战略级进行中问题，风险登记 = 概率×影响矩阵（含低概率高影响项）

### 10 — `next-roadmap`
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `subtitle`, `p1~4_phase/title/body/owner`, `t1~3_lbl/val/note`, `footer_source`
- **不可改动**：`.br-roadmap` 4 列无缝(gap:0)、当前阶段 `.now`(浅蓝渐变 + 右上「当前阶段」标签)、每列 phase/title/body/owner 结构
- **内容适配规则**：4 阶段按月推进（7月/8月/8-9月/Q3末），当前阶段固定 1 列；底部 3 目标卡呼应 scorecard 差距（NRR/KA/ARR）

### 11 — `key-initiatives`
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `i1~4_num/title/body/kpi/kpi_lbl`, `co_tag/co_body`, `footer_source`
- **不可改动**：`.br-init-grid` 4 列、首项 `.br-init.hero`(amber 顶边 + 浅底)、每卡 num/title/body/kpi 结构、kpi 底部分隔
- **内容适配规则**：4 举措与 page 08 差距 + page 10 路线图一一对应；P0/P1/P2 优先级标注在 num 行

### 12 — `resource-ask`（特色页）
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `h_item/hc/budget/prio/return`, `r1~4_item/sub/hc/budget/prio/return`, `ft_label/hc/budget/prio/return`, `roi1~3_lbl/val/note`, `footer_source`
- **不可改动**：`.resource-ask` 5 列(申请项/人力/预算/优先级/回报)、数字列 `.num`(右对齐 tabular-nums)、`tfoot` 汇总行(深海蓝底白字)、优先级 pill(P0=bad/P1=warn/P2=accent)
- **内容适配规则**：
  - 复盘向高管要资源的标准结构：每项 = 申请 + 人力 + 预算 + 优先级 + **预期回报**
  - `tfoot` 汇总 = 合计人力 + 合计预算 + ROI；ROI 三卡给出「全额 / 回报倍数 / 若仅批 P0」三档决策视角

### 13 — `decisions`
- **可替换键**：`kicker`, `title`, `period_chip`, `reportline`, `d1~3_tag/title/bg`, `optA/optB`(各决议两选项), `d1~3_by/due`, `footer_source`
- **不可改动**：`.br-decision` 4 列(议题/选项A/选项B/决议人)、推荐项 `.br-opt.rec`(浅绿底 + 「推荐」标)、决议人列 `.br-dc-approver`(灰底 + 截止红字)
- **内容适配规则**：每项决议 = 二选一（A/B），推荐项 class `.rec` 可在两选项间迁移；决议人与截止对应 page 14 会签顺序

### 14 — `thanks`（致谢页 · 特色）
- **可替换键**：`kicker`, `headline`, `subtitle`, `col1_title/count`, `c1~3_title/by/due`, `col2_title/count`, `r1~4_title/amt`, `routing`, `deadline_chip`, `footer_source`
- **不可改动**：`.br-approval` 2 列(决议 / 资源)、左列顶边亮蓝 / 右列顶边 amber、每项 `.br-ap-check.pending`(待批空心)、底部会签路由 + 截止 chip
- **内容适配规则**：
  - **禁止**改成「4 联系人卡片网格」——本页主体是**决议与资源审批清单**（该体裁收束页的真实内容）
  - 决议 3 项 ↔ page 13，资源 4 项 ↔ page 12，逐项可追溯；批复后 `.br-ap-check` 由 `.pending` 改 `.open`(实心对勾)

---

## 组件层（`shared/tokens.css` `.tpl-biz-review` overlay）

| class | 作用 |
|------|------|
| `.br-masthead` / `.br-period-chip` / `.br-reportline` | 报告式页头（章节 + 标题 / 右侧周期 chip + 报告线） |
| `.br-status.met/.missed/.exceeded/.ongoing` | 达标状态 badge（✓ 达标 / ✗ 未达标 / ▲ 超额 / · 进行中）——区别于 RAG 点与 ▲▼ chip |
| `.br-progress` / `.br-progress-fill(.good/.warn/.bad)` / `.br-progress-mark` | 达成率进度条 + 100% 标尺 |
| `.kpi-wall` / `.kpi-tile(.good/.warn/.bad)` / `.kpi-value` / `.kpi-deltas` | **KPI 总览墙**（8 格，五要素） |
| `.br-spark` | KPI 内 mini SVG sparkline（vector-effect 锐利描边） |
| `.highlight-expand` / `.he-hero` / `.he-side` / `.he-support` | **亮点展开**（单一 hero + 支撑） |
| `.br-attrib` / `.br-attrib-bar` / `.br-attrib-seg` / `.br-attrib-legend` | **归因拆解条**（100% 贡献堆叠） |
| `.gap-analysis` / `.ga-target/.ga-actual/.ga-gap/.ga-cause/.ga-action` | **差距分析账本**（目标·实际·根因·行动） |
| `.br-scorecard` / `.br-goal` / `.br-goal-vals` | 周期 scorecard（目标 vs 实际 + 达成率） |
| `.resource-ask` / `.ra-item/.ra-headcount/.ra-budget/.ra-return` | **资源需求表**（含汇总行） |
| `.br-roadmap` / `.br-rm-col.now` | Q3 路线图（基于 layout-catalog L19，4 阶段无缝网格） |
| `.br-init-grid` / `.br-init.hero` | 重点举措 pipeline |
| `.br-decision` / `.br-opt.rec` / `.br-dc-approver` | 决议事项（议题 + 选项 + 推荐 + 决议人） |
| `.br-approval` / `.br-approval-col(.fund)` / `.br-approval-item` / `.br-ap-check(.open/.pending)` | **决议与审批清单**（致谢页主体，非人员卡） |
| `.br-chart-card` / `.br-trend` / `.br-chart-legend` | 数据深潜趋势图容器（inline SVG） |
| `.br-callout(.warn/.good)` | 页内强调横条（小结/启示/闭环） |
| `.br-cover-band` / `.br-cover-meta` | 封面周期带 + 元信息四格 |

> 所有 `br-*` 组件颜色均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 切换时自动联动。推荐配套方案：`ocean-depths`（默认）、`mckinsey-blue`、`consulting-navy`、`midnight-ink`。
