# pitch-deck — Slide Role Catalog

> **模板气质**：自信数据驱动、超大序号水印(293px)、渐变大数字冲击、灰度卡片对比
> **默认 color-scheme**：ocean-depths（出厂默认；AI 在 Phase 4.1 独立替换颜色方案）
> **适用文稿类型**：说服/促动
> **叙事结构**：Cover → Problem(3card) → Solution(pills) → Product(4card) → Market(3metric) → Business Model(3pricing) → Traction(chart) → Team(3avatar) → Ask(gradient box) → Thanks

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面 | .cover-bg, .cover-blob, .brand-dot, .brand, .mega |
| 02 | `content-section-3card` | 章节分隔+三卡片 | .section-num, .num-tag, .card |
| 03 | `content-section-pills` | 章节分隔+解决方案 pills | .section-num, .num-tag, .pill.pill-accent, .gradient-text |
| 04 | `content-section-4card` | 章节分隔+四卡片(2×2 grid) | .section-num, .num-tag, .card.card-hover |
| 05 | `content-section-metrics` | 章节分隔+三大数字指标 | .section-num, .num-tag, .metric, .n (gradient-text 大数字) |
| 06 | `content-section-pricing` | 章节分隔+三档定价卡片 | .section-num, .num-tag, .card, .card-accent, .metric .n |
| 07 | `content-section-chart` | 章节分隔+柱状图 | .section-num, .num-tag, .traction-bar, .bar |
| 08 | `content-section-team` | 章节分隔+三成员团队 | .section-num, .num-tag, .card.team-card, .avatar |
| 09 | `cta` | 行动号召 (The Ask) | .num-tag, .ask-box, 三大数字 |
| 10 | `thanks` | 感谢/结束 | .cover-bg, .mega, .pill |

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **页面类型**：封面
- **视觉等级**：L3
- **可替换键**：`brand_name`, `round_tagline`, `headline`, `headline_accent`, `subtitle`, `presenter_info`
- **不可改动**：.cover-bg 和 .cover-blob 装饰层（保留位置/大小/模糊度）、.brand-dot 样式、.deck-footer 位置、h1 字号(96px)/字距(-0.03em)/字重(900)
- **内容适配规则**：
  - `headline` 含一个用 `<span class="gradient-text">` 包裹的 accent 词（key: `headline_accent`），替换时保留 span 结构
  - **中文标题**：控制在 16 字以内（96px 字号下，中文单字宽 ≈140px，16 字 ≈2240px 可拆 2 行）。单行超过 8 字用 `<br>` 拆行
  - **英文标题**：控制在 55 字符以内
  - `brand_name` 控制在 5 字以内（绝对定位在左上角，过长会与标题重叠）
  - `presenter_info` 格式 `"姓名 · 职位"`
- **卡片扩展/收缩**：不适用

### `content-section-3card`
- **源文件**：`slides/02-problem.html`
- **页面类型**：内容页（章节分隔 + 三卡片）
- **视觉等级**：L1
- **可替换键**：`section_num`, `section_tag`, `section_title`, `card_1_title`, `card_1_body`, `card_2_title`, `card_2_body`, `card_3_title`, `card_3_body`
- **不可改动**：.section-num 字号(293px)/字距(-0.05em)/颜色(var(--surface-2))/左边距(-120px)、.num-tag 位置/样式、.grid.g3 结构、卡片样式(.card)
- **内容适配规则**：
  - `section_title` 控制在 12 字以内，超过用 `<br>` 拆行
  - 卡片标题控制在 5 字以内，正文控制在 35 字以内
  - 三张卡片内容量应均匀（最长与最短差异不超过 50%）
- **卡片扩展/收缩**：
  - 扩展为 4 卡：`.grid.g3` → `.grid.g4`，卡片样式不变
  - 收缩为 2 卡：`.grid.g3` → `.grid.g2`，卡片宽度增大但保持相同 padding/圆角/阴影
  - **不可收缩为 1 卡**（1 卡改用 `content-bigquote` 角色或 T2 fallback）

### `content-section-pills`
- **源文件**：`slides/03-solution.html`
- **页面类型**：内容页（章节分隔 + 方案描述 + pill 标签组）
- **视觉等级**：L1
- **可替换键**：`section_num`, `section_tag`, `section_title`, `section_title_accent`, `lede_text`, `pill_1`, `pill_2`, `pill_3`, `pill_4`, `pill_5`
- **不可改动**：.section-num 水印、.num-tag 样式、.pill.pill-accent 样式、.lede 宽度(max-width:62ch)
- **内容适配规则**：
  - `section_title` 含一个用 `<span class="gradient-text">` 包裹的 accent 词（key: `section_title_accent`），替换时保留 span 结构
  - `lede_text` 控制在 60 字以内，保留原文的 → 箭头连接风格
  - pills 数量 3~6 个，3-4 个一行，5-6 个用 `.row.wrap`
- **卡片扩展/收缩**：pills 数量 3~6，按需增删 `<span class="pill pill-accent">` 元素

### `content-section-4card`
- **源文件**：`slides/04-product.html`
- **页面类型**：内容页（章节分隔 + 四卡片 2×2 grid）
- **视觉等级**：L1
- **可替换键**：`section_num`, `section_tag`, `section_title`, `card_1_title`, `card_1_body`, `card_2_title`, `card_2_body`, `card_3_title`, `card_3_body`, `card_4_title`, `card_4_body`
- **不可改动**：.section-num 水印、.num-tag、.grid.g2 结构、.card.card-hover 样式
- **内容适配规则**：
  - 卡片标题控制在 5 字以内，正文控制在 40 字以内
  - 每张卡片内容量均匀（最长与最短差异不超过 50%）
- **卡片扩展/收缩**：
  - 收缩为 2 卡：`.grid.g2` 不变（2 列各 1 卡即可），或切换为 `.grid.g3` + 居中
  - 扩展为 6 卡：`.grid.g2` → `.grid.g3`（3 列 × 2 行）

### `content-section-metrics`
- **源文件**：`slides/05-market.html`
- **页面类型**：内容页（章节分隔 + 三大数字指标 + 脚注）
- **视觉等级**：L1
- **可替换键**：`section_num`, `section_tag`, `section_title`, `metric_1_value`, `metric_1_label`, `metric_2_value`, `metric_2_label`, `metric_3_value`, `metric_3_label`, `footnote`
- **不可改动**：.section-num 水印、.num-tag、.metric .n（渐变文字大数字，96px 900wt）、.metric .l（标签，21px）、.grid.g3 结构
- **内容适配规则**：
  - `metric_N_value` 保留数值+单位格式（如 "73M" "$186B" "9.4%"），数字与单位紧贴
  - `metric_N_label` 控制在 15 字以内
  - `footnote` 控制在 60 字以内
- **卡片扩展/收缩**：
  - 扩展为 4 指标：`.grid.g3` → `.grid.g4`
  - 收缩为 2 指标：`.grid.g3` → `.grid.g2`

### `content-section-pricing`
- **源文件**：`slides/06-business-model.html`
- **页面类型**：内容页（章节分隔 + 三档定价/方案卡片）
- **视觉等级**：L1
- **可替换键**：`section_num`, `section_tag`, `section_title`, `plan_1_name`, `plan_1_price`, `plan_1_desc`, `plan_2_name`, `plan_2_price`, `plan_2_desc`, `plan_3_name`, `plan_3_price`, `plan_3_desc`, `footnote`
- **不可改动**：.section-num 水印、.num-tag、.grid.g3 结构、.card-accent（中间推荐档高亮）、.metric .n 价格数字(75px 900wt)
- **内容适配规则**：
  - `plan_N_price` 保留货币符号/百分比格式
  - `plan_N_desc` 控制在 20 字以内
  - 中间卡片（plan_2）始终用 `.card-accent` 作为推荐档
  - `footnote` 控制在 50 字以内
- **卡片扩展/收缩**：
  - 收缩为 2 档：`.grid.g3` → `.grid.g2`，去掉中间档或合并低/高档
  - 扩展为 4 档：`.grid.g3` → `.grid.g4`

### `content-section-chart`
- **源文件**：`slides/07-traction.html`
- **页面类型**：内容页（章节分隔 + 柱状图）
- **视觉等级**：L1
- **可替换键**：`section_num`, `section_tag`, `section_title`, `bar_1_label`, `bar_1_value`, `bar_2_label`, `bar_2_value`...（×6 组）, `footnote`
- **不可改动**：.section-num 水印、.num-tag、.traction-bar 高度(319px)/gap(19px)、.bar 最小高度(27px)/圆角(11px 11px 0 0)、.bar em 数值标签位置(top: -38px)
- **内容适配规则**：
  - 柱子数量 4~8，通过调整 bar 的 `style.height` 控制（data-replace-style）
  - 每根 bar 高度 = `(该值 / 最大值) * 100%`，最小 5%
  - `bar_N_value` 保留数值+单位格式（如 "$6k"）
  - `bar_N_label` 控制在 5 字以内
  - `footnote` 控制在 40 字以内
- **卡片扩展/收缩**：柱子数 4~8，增删 `.bar` 元素

### `content-section-team`
- **源文件**：`slides/08-team.html`
- **页面类型**：内容页（章节分隔 + 三成员团队）
- **视觉等级**：L1
- **可替换键**：`section_num`, `section_tag`, `section_title`, `person_1_initials`, `person_1_name`, `person_1_bio`, `person_2_initials`, `person_2_name`, `person_2_bio`, `person_3_initials`, `person_3_name`, `person_3_bio`
- **不可改动**：.section-num 水印、.num-tag、.grid.g3 结构、.card.team-card 居中样式、.avatar 圆形渐变(142×128px, 43px 字号)
- **内容适配规则**：
  - `person_N_initials` 控制在 2-3 字符（首字母缩写）
  - `person_N_name` 控制在 20 字以内
  - `person_N_bio` 控制在 40 字以内，格式 `"职位 · 经历。亮点。"`
- **卡片扩展/收缩**：
  - 扩展为 4 人：`.grid.g3` → `.grid.g4`
  - 收缩为 2 人：`.grid.g3` → `.grid.g2`

### `cta`
- **源文件**：`slides/09-the-ask.html`
- **页面类型**：行动号召（The Ask）
- **视觉等级**：L2
- **可替换键**：`section_tag`, `ask_headline`, `ask_body`, `ask_metric_1_value`, `ask_metric_1_label`, `ask_metric_2_value`, `ask_metric_2_label`, `ask_metric_3_value`, `ask_metric_3_label`
- **不可改动**：.num-tag 样式、.ask-box（渐变背景+白色文字+圆角 38px+阴影）、三大数字字号(78px 900wt)
- **内容适配规则**：
  - `ask_headline` 控制在 12 字以内
  - `ask_body` 控制在 80 字以内
  - `ask_metric_N_value` 保留数值+单位格式
  - `ask_metric_N_label` 控制在 15 字以内
  - 此页无 .section-num 水印（Ask 页是独立视觉节奏点）
- **卡片扩展/收缩**：指标数固定 3 个

### `thanks`
- **源文件**：`slides/10-thanks.html`
- **页面类型**：感谢/结束
- **视觉等级**：L3
- **可替换键**：`thanks_word`, `contact_info`, `cta_text`, `version_info`
- **不可改动**：.cover-bg（复用封面柔光背景）、.mega 字号(239px)/字距(-0.05em)/渐变文字效果、.pill 样式、.center.tc 居中布局
- **内容适配规则**：
  - `thanks_word` 控制在 5 字以内（"Thanks." "谢谢。" "Thank you." 等）
  - `contact_info` 控制在 50 字以内
  - `cta_text` 控制在 10 字以内（行动号召 pill）
  - `version_info` 控制在 30 字以内（版本/日期信息 pill）

---

## 角色匹配决策树

1. 用户 slide 是封面 → `cover`
2. 用户 slide 是结束/感谢 → `thanks`
3. 用户 slide 是行动号召/融资 Ask → `cta`
4. 用户 slide 有章节分隔需求 + 3 张卡片 → `content-section-3card`
5. 用户 slide 有章节分隔需求 + 4 张卡片 → `content-section-4card`
6. 用户 slide 有章节分隔需求 + pills/标签列表 → `content-section-pills`
7. 用户 slide 有章节分隔需求 + KPI/大数字指标 → `content-section-metrics`
8. 用户 slide 有章节分隔需求 + 定价/方案对比 → `content-section-pricing`
9. 用户 slide 有章节分隔需求 + 柱状图/趋势 → `content-section-chart`
10. 用户 slide 有章节分隔需求 + 团队/人物 → `content-section-team`
11. 以上都不匹配 → 降级到 T2 layout-catalog 通用骨架（应用下方 Style Transfer 规则）

---

## Style Transfer — T2 页面继承规则

当 deck 中存在 T2 页面（从 layout-catalog 生成的非模板页面）时，以下规则确保它们与 pitch-deck 模板页面的视觉语言一致。

### 空间密度对齐
- 内容区 body padding：对齐 `118px 165px`
- 卡片间距：对齐 `.grid` gap 值 = 32px
- 标题与内容间距：.mt-s = 11px, .mt-m = 25px, .mt-l = 43px

### 装饰模式继承
- **章节标识**：T2 内容页必须在顶部添加 `.section-num`（293px 水印字号）+ `.num-tag`（章节标签），与 T1 页面一致
- **分隔线**：标题下方用 `.divider-accent`（4px 高，106px 宽，var(--accent) 色）
- **不使用封面装饰**：.cover-bg / .cover-blob 仅限于 `cover` 和 `thanks` 角色

### 组件类名统一
- 卡片用 `.card`（白底 + 标准阴影 + var(--radius)=27px 圆角）
- 推荐/高亮档用 `.card-accent`（顶部 3px var(--accent) 色条）
- 强调色用 `.gradient-text`（渐变文字）用于关键数字，不要引入 .accent-text

### 排版层级对齐
- 内容页标题：h2, 82px, weight 800, letter-spacing -0.03em
- 正文色：--text-2 (#4a5070)，用 class `.dim`
- 辅助文字：--text-3 (#8a90ad)，用 class `.dim2`
- 字体：'Inter', 'Noto Sans SC', sans-serif

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| .pill 标签 | pitch-deck 仅在 solution 页(.pill-accent)和 thanks 页使用 pill，T2 页面不引入 |
| .glass / 玻璃拟态卡片 | pitch-deck 无此视觉语言 |
| .icon-halo / .dot-cluster | pitch-deck 装饰靠 .cover-blob 和 .section-num 水印 |
| .slide-top-bar / .slide-bottom-bar | pitch-deck 无渐变顶条/底条装饰 |
| .btn-gradient | pitch-deck 用 .ask-box 渐变卡片作 CTA，无独立按钮 |
| 自定义 class（.arch-* 等） | 只使用 tokens.css 中已定义的 class；模板已有的 .card .metric .grid .pill 等足够覆盖所有 T2 场景 |

### T2 页面特殊处理

**架构图/流程图（T2）**：
- 使用 layout-catalog L21 骨架，body 顶对齐 `style="justify-content:flex-start;padding:80px 150px 60px"`
- 标题区保持紧凑（h2 + lede 一行概括），把垂直空间留给架构图
- L21 现已适配 slide 级比例——cell 字号 21px/16px、padding 28px、gap 32px，无需担心"太小"
- 3 层以内架构图天然撑满画布，不要额外加 section-num 水印
- 只使用 tokens.css 和 L21 已定义的 class，不要自创 class

**时间线/路线图（T2）**：
- `.timeline` 最多容纳 5 个条目——≥6 个条目时改用 layout-catalog L19（roadmap 四列 grid）或 L23（规划排期）
- 时间线条目超过 5 个且每个含描述文字时，必须用 roadmap/甘特图样式，不要堆叠成列表
- 不要同时放时间线 + 侧边卡片——信息过载，二选一 |
