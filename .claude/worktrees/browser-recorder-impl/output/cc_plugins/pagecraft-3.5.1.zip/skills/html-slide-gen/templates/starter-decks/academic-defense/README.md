# academic-defense · 学位论文答辩

16-slide thesis-defense deck: cover, contents, research summary (core contribution), background & significance, research gap, research question (MECE), chapter divider, 2×2 research framework, methodology, experiments (with formula block), method comparison table, technical roadmap, phased results (RAG), limitations & future work, future research plan, acknowledgements.

Restrained academic palette — Deep Blue (`#003366`) header band + Red (`#cc0000`) left-bar/accent on white, light-blue-grey (`#e8f4fc`) cards with 8px radius and colored left-bars, insight bars, rigorous and research-grade, conclusion-first and MECE-structured.

**Use when:** master's/doctoral thesis defense, mid-term research review, research achievement report, proposal defense.
**Feel:** a rigorous graduate defense readout — data-driven, structured, every page is a takeaway.

---

## 配色

默认 `academic-green`（深蓝 #003366 + 红 #cc0000 + 浅蓝灰 #e8f4fc，白底）。
⚠️ scheme 名「学术墨绿」为历史遗留，实际 token 为深蓝+红，与 pagecraft `academic_defense/design_spec` 实际配色一致；如需改名单独立项，不改 JSON。

已接入 `switch-theme.mjs`，可一键切换：

```bash
node scripts/switch-theme.mjs --deck templates/starter-decks/academic-defense --scheme government-blue  # 同系深蓝
node scripts/switch-theme.mjs --deck templates/starter-decks/academic-defense --scheme consulting-navy   # 深蓝投行
```

配套方案见 `scripts/color-schemes.json`（40 个预设）。

## 结构

16 页叙事弧 = **学位论文答辩体裁（选题背景 → 文献综述 → 研究方法 → 实验结果 → 结论贡献）**，非咨询 SCQA 套用：

| 段落 | 页 | 角色 |
|------|-----|------|
| 开篇 | 01-03 | cover（答辩封面·页眉条+答辩信息块）· contents · research-summary（核心贡献） |
| 背景与综述 | 04-06 | background · **lit-review（文献综述编号卡）** · research-question（MECE 分解） |
| 章节切换 | 07 | chapter-divider |
| 方法与实验 | 08-12 | **tech-roadmap（技术路线图）** · methodology · **experiments（公式块+baseline 对比）** · **method-comparison（SOTA 对比表）** · technical-roadmap |
| 结论与展望 | 13-15 | phased-results（RAG）· limitations · future-research |
| 收束 | 16 | acknowledgements（致谢·基金号+DOI/代码+Q&A） |

**学术身份证**（区别于 consultant/政府/央企/金融 4 个 deck 的标志版式）：文献综述编号卡 `.aca-litcard`、编号公式块 `.aca-formula`、baseline 对比 `.aca-baseline`、研究技术路线图 `.aca-roadmap`、文中上标引用 `.aca-cite`、答辩封面/致谢的页眉条 `.aca-header` + 信息块 `.aca-info`。详见 [`slide-roles.md`](slide-roles.md)。

完整角色目录与替换键见 [`slide-roles.md`](slide-roles.md)。

## 用法

复制本目录到产出目录后修改 `slides/*.html` 中的 `data-replace="key"` 内容。示例填充为「基于深度学习的医学图像病灶分割方法研究」（典型硕士学位论文答辩，自然有数据/方法/实验/对比/局限，映射全部 16 角色）。

```bash
# 预览
open index.html
# 截图所有页
node scripts/preview_slides.mjs --slides slides --out /tmp/preview
# 导出单文件 HTML
node scripts/export_single.mjs --deck . --out ../academic-defense.html
# 导出 PPTX
node scripts/export_pptx.mjs --slides slides --out ../academic-defense.pptx --mode editable
```

## 设计依据

参考 pagecraft-2.0.0 `layouts/academic_defense/design_spec.md`（页眉带 70px 深蓝 + 红色左竖条、观点条浅蓝灰 + 蓝竖条、装饰分割线 + 圆点、卡片浅蓝灰圆角 8px 左彩色竖条、严谨克制科研感）经 HTML 多文件 iframe 架构重做。详见 `docs/starter-decks-expansion-plan.md`。

⚠️ 公式/引用暂用 SVG inline + `.aca-formula`/`.mono` 占位，katex 渲染后续单独立项。
