# government-formal-red · 政务工作汇报

16-slide 政务汇报 deck：封面（红头文件版心）、目录、工作综述、政策背景、存在问题、工作主线、章节切换（深蓝全屏）、总体思路（2×2 矩阵）、重点举措、数据深潜、对标先进、实施路径（时间轴）、阶段成效（RAG）、风险防控、下一步举措、结束页。

政务庄重配色 —— 政府红 `#8B0000` + 政府蓝 `#003366` + 金色 `#DAA520` 点缀，白底，红蓝双色顶饰、深蓝章节全屏、红色序号块、印章徽标，庄重克制、结论先行。

**Use when:** 政务汇报、工作总结、政策宣讲、项目推介、招商引资（营商环境、专项工作、年度总结、改革推进）。
**Feel:** 红头文件 meets 现代政务汇报 —— 庄重权威、数据驱动、结构清晰、每页一个结论。

---

## 配色

默认 `government-red`（政府红 + 政府蓝 + 金）。已接入 `switch-theme.mjs`，可一键切换：

```bash
node scripts/switch-theme.mjs --deck templates/starter-decks/government-formal-red --scheme government-blue  # 政府蓝
node scripts/switch-theme.mjs --deck templates/starter-decks/government-formal-red --scheme consulting-navy  # 深蓝
```

配套方案见 `scripts/color-schemes.json`（40 个预设）。

## 结构

16 页叙事弧 = **政策背景 → 工作部署 → 落实成效 → 下一步举措**：

| 段落 | 页 | 角色 |
|------|-----|------|
| 开篇 | 01-03 | cover（红头文件版心）· toc · executive-summary（工作综述） |
| 背景与问题 | 04-06 | situation（政策背景）· complication（存在问题）· question（工作主线 MECE） |
| 章节切换 | 07 | chapter-divider（深蓝全屏） |
| 部署 | 08-12 | framework（2×2 矩阵）· recommendation（重点举措）· data-deepdive · comparison-table（对标）· process-flow |
| 治理 | 13-15 | quarterly-review（阶段成效 RAG）· risks-mitigation · next-steps |
| 收束 | 16 | thanks |

完整角色目录与替换键见 [`slide-roles.md`](slide-roles.md)。

## 用法

复制本目录到产出目录后修改 `slides/*.html` 中的 `data-replace="key"` 内容。示例填充为「某市营商环境优化工作汇报」（典型政务工作汇报场景，替换键示意最清晰）。

```bash
# 预览
open index.html
# 截图所有页
node scripts/preview_slides.mjs --slides slides --out /tmp/preview
# 导出单文件 HTML
node scripts/export_single.mjs --deck . --out ../government-formal-red.html
# 导出 PPTX
node scripts/export_pptx.mjs --slides slides --out ../government-formal-red.pptx --mode editable
```

## 设计依据

参考 pagecraft-2.0.0 `layouts/government_red/design_spec.md`（红蓝双色顶饰、深蓝章节全屏、金色点缀、红色序号块、印章）经 HTML 多文件 iframe 架构重做。详见 `docs/starter-decks-expansion-plan.md`。
