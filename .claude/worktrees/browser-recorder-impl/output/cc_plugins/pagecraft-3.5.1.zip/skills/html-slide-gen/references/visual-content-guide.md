# Visual Content Guide — AI 生图场景与提示词知识库

> 本文档分为两层：**通用层**（§一-§四，任务二可直接复用）和 **Slides 应用层**（§五，仅任务一）。
> 通用层不依赖任何特定产品概念，slides 应用层标注 `[SLIDES]`。

## 目录

**通用层**
- [一、总览](#一总览) — 1.1 为什么需要视觉化 · 1.2 决策框架 · 1.3 视觉化光谱 · 1.4 人工覆盖 · 1.5 风格一致性锚点
- [二、场景分类与 Prompt 模板](#二场景分类与-prompt-模板) — 维度 1 装饰性插画 · 维度 2 配图与图标 · 维度 3 内容视觉化 · 维度 4 局部装饰
- [三、Prompt 工程速查](#三prompt-工程速查) — 3.1 四步法 · 3.2 两套格式 · 3.3 风格关键词表 · 3.4 尺寸选择 · 3.5 语言策略
- [四、质量标准与限制](#四质量标准与限制) — 4.1 能力边界 · 4.2 中文渲染 · 4.3 品牌一致性 · 4.4 失败降级 · 4.5 成本意识

**Slides 应用层 [SLIDES]**
- [五、Slides 应用层](#五slides-应用层-slides) — 5.1 大纲标注规范 · 5.2 各场景触发条件 · 5.3 图片与布局搭配 · 5.4 generate.py 调用规范 · 5.5 画布尺寸与清晰度

> **快速路径**：只关心"这页该生什么图"→ 直接看 §5.2 触发条件表 + §二对应维度的 Prompt 模板。需要完整 Prompt 写法参考 → §三。

---

## 一、总览

### 1.1 为什么需要视觉化

纯文字的信息堆叠难以快速传达核心信息。视觉化的价值在于三层递进：

| 层级 | 效果 | 举例 |
|------|------|------|
| **氛围感** | 让作品看起来专业、有品质 | 封面有一张主题插画 vs 纯文字标题 |
| **精致度** | 统一的视觉风格提升整体协调性 | 每个模块有主题化图标 vs 通用数字编号 |
| **信息传达** | 复杂信息一目了然 | 架构图/流程图/对比图 vs 文字段落描述 |

三个视觉维度按此递进关系设计：
- **维度 1（装饰性插画）** → 让作品有氛围感
- **维度 2（配图与图标）** → 让作品更精致统一
- **维度 3（内容视觉化）** → 让信息传达更有效

### 1.2 视觉化决策框架

在决定"某个内容区域是否需要 AI 生图"之前，先通过以下流程判断：

**前置判断：CSS 能解决的不走 AI 生图**

CSS 图形（圆形背景 + 数字/字母、渐变背景、边框卡片等）能覆盖以下场景，不应调用 AI 生图：
- 通用编号图标（①②③、01/02/03）
- 简单装饰元素（分割线、色块、渐变背景）
- 已有品牌 SVG 图标

**判断流程**：

```
这个内容区域需要视觉增强吗？
├── 否 → 保持纯文字/CSS 图形
└── 是 → 问题 A：信息之间有关系结构吗？
              或是抽象概念需要隐喻？
              或受众需要快速抓全局？
    ├── 否 → 问题 B：CSS 图形够用吗？
    │         ├── 是 → 使用 CSS 图形
    │         └── 否 → 维度 2（配图/图标）
    └── 是 → 问题 B：AI 生图能做到吗？
              （概念隐喻✅ 流程架构⚠️ 数据图表❌ 大量文字❌）
        ├── 是 → 维度 3（内容视觉化）
        └── 否 → 退回维度 1（装饰性插画）或 CSS
```

### 1.3 视觉化光谱

每个内容块在"纯文字"到"全视觉"之间有一个档位：

| 档位 | 形式 | 示例 | 适用场景 |
|------|------|------|---------|
| 0 | 纯文字排版 | 要点列表、段落文字 | 数据密集页、案例页 |
| 1 | 文字 + CSS 图标 | 数字/字母圆形图标 | 一般要点、列表项 |
| 2 | 文字 + 装饰性插画 | 页面一侧放氛围图 | 章节/段落过渡 |
| 3 | 文字 + 视觉图解 | AI 图表达概念或关系 | 架构图、流程图、对比图 |
| 4 | 视觉为主 + 少量标签 | 整块区域是 AI 图 | 概念展示页、视觉冲击页 |

维度 1 覆盖档位 2，维度 2 覆盖档位 1-2（CSS 做不到的部分），维度 3 覆盖档位 3-4。

### 1.4 人工覆盖机制

AI 自动判断不完美，提供两个干预节点：

**节点 1：大纲阶段（页面级粗标记）**
在规划内容结构时，用户可以标记某页的视觉需求：
- "这页整体偏视觉化" → AI 生成时倾向维度 3
- "这页用插画氛围" → AI 生成时倾向维度 1
- "这页不需要图" → 跳过 AI 生图

**节点 2：内容块级细调整**
在具体生成时，用户可以对单个内容区域微调：
- "这个区域不要图，换个 CSS 图标就行"
- "这个流程图需要更详细的视觉化"

### 1.5 风格一致性锚点

一份作品中如果需要多张 AI 生成的图片，**必须使用同一风格基调**，否则会出现一张扁平插画、一张 3D 渲染、一张照片的割裂感。

**规则**：在第一张图生成前确定**整份作品的视觉风格**（如"扁平商务插画"），后续所有 prompt 继承这个风格前缀，不再独立选择风格。

#### 风格维度锁

风格基调不止是一句话描述——必须在三个物理维度上锁定，生成时每个 prompt 都要携带这三个维度的约束：

| 维度 | 锁定策略 | 示例 |
|------|---------|------|
| **透视** | 锁定单一透视模式（推荐 2.5D 等距视角） | "2.5D 等距视角，无透视变形" |
| **质感** | 锁定材质/渲染风格（推荐磨砂玻璃 + 微渐变） | "磨砂玻璃质感，柔和微渐变，无硬边缘" |
| **光影** | 锁定光照风格（推荐柔光漫射，禁止强阴影） | "均匀柔光，无硬阴影，无高对比明暗" |

**执行方式**：Step 5 确定风格锚点时，输出一个三行锁定声明（示例）：

```
透视：2.5D 等距视角
质感：磨砂玻璃 + 微渐变
光影：均匀柔光，无硬阴影
```

后续所有 prompt（A/B/C 三类）都必须在风格前缀中包含这三个维度的关键词。**禁止任何一张图偏离锁定值**——例如锁了 2.5D 就不能出现 3D 透视的图。

风格锚点示例：
- "2.5D 等距视角，磨砂玻璃质感，均匀柔光，微渐变色调，暖色灯光" ← 所有图共享
- "扁平化设计，矢量感，简洁色块，无阴影，品牌蓝色系" ← 所有图共享

---

## 二、场景分类与 Prompt 模板

### 维度 1：装饰性插画

#### 2.1 封面/主视觉氛围图

**触发条件**：
- 作品需要一个视觉化的"第一印象"
- 主题抽象或概念性强，纯文字封面不够吸引人
- 作品面向外部受众（路演、发布、展示）

**不适用**：
- 内部汇报（纯信息传递，不需要视觉冲击）
- 已有高质量品牌封面图/产品图
- 极度正式的场合（如法律文书、财务报表）

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 科技/产品发布 | 等距微缩城市、3D 渲染 | isometric, clay material, volumetric lighting |
| 企业路演/战略 | 扁平商务插画 | flat illustration, clean shapes, vector style |
| 教育/培训 | 友好插画、吉卜力风 | Studio Ghibli, warm, hand-drawn |
| 年度回顾/激励 | 电影级摄影、大场面 | cinematic, wide angle, golden hour |
| 学术/技术分享 | 极简几何、玻璃态 | minimalist, geometric, glassmorphism |

**Prompt 模板（结构化 6 段式）**：

```
1. 画面场景：
   [作品主题的抽象/隐喻场景]。[场景环境描述，如室内/室外/抽象空间]。

2. 主体描述：
   [核心视觉元素]，[材质/质感]，[颜色/色调]。
   [细节：纹理、光效、粒子等微观特征]。

3. 构图与视角：
   [相机角度：俯瞰/平视/仰视/特写/全景]。
   [深度关系：浅景深/全景深/分层]。
   [画面布局：主体居中/偏左/偏右/留白放标题]。

4. 光线与色彩：
   [光源方向和色温]。
   [高光/阴影处理]。
   [整体色调：冷暖、饱和度、对比度]。

5. 材质与细节：
   [表面纹理]。
   [微观细节：反光、磨损、光泽等]。

6. 排除项：
   不含文字, 无水印, 无边框, 无 logo[其他排除项]。
```

**完整示例 1：科技产品路演封面**

> **Prompt**:
> 等距微缩城市风格的科技产品架构图。俯瞰 45 度视角，画面呈现一座微型城市模型，黏土材质质感，柔和的暖色调灯光。城市分为三层：底层是深灰色混凝土基座，上面矗立着几座低矮的方形建筑，代表基础设施能力；中层是由透明玻璃连桥连接的多栋高楼，每栋楼体用不同颜色的半透明面板标识不同的核心能力；顶层是开阔的天台花园，散布着代表不同应用场景的小型装置。整体光线：城市底部散发冷蓝色环境光，中层有暖白色工作灯光，顶层沐浴在金色的晨曦光线中。右下角留出空间用于放置标题。不含文字, 无水印, 无边框。
>
> **尺寸**: 1792×1024
> **适用场景**: 科技公司产品发布路演、技术架构展示

**完整示例 2：企业年度战略封面**

> **Prompt**:
> 扁平化设计风格的商业战略愿景图。全景构图，画面从左到右呈现一条从山脚蜿蜒而上的道路，道路两侧散布着简洁的几何建筑——左侧是低矮的工厂（代表过去），中间是层叠的办公楼（代表现在），右侧是通透的玻璃塔楼（代表未来）。建筑使用品牌蓝色和白色为主色调，点缀少量琥珀色和翡翠绿。浅景深，背景是柔和的渐变色天空（从左下方的暖橙色到右上方的冷蓝色）。风格简洁现代，无多余装饰，画面干净留白充足，右下方预留标题区域。不含文字, 无水印。
>
> **尺寸**: 1792×1024
> **适用场景**: 企业年度战略发布、团建激励、愿景展望

---

#### 2.2 章节/段落过渡图

**触发条件**：
- 作品有明显的章节/段落划分
- 章节之间需要视觉"呼吸"——让读者意识到进入新话题
- 章节主题可以用一个简单的视觉隐喻表达

**不适用**：
- 章节数量 ≤ 2（不需要过渡）
- 过渡页已有足够的设计元素（品牌色块、大号章节编号等）

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 科技/产品 | 抽象几何、渐变 | abstract geometry, gradient, clean |
| 企业/战略 | 极简线条、留白 | minimalist lines, negative space |
| 教育/培训 | 友好插画 | warm illustration, soft colors |
| 创意/品牌 | 水彩、手绘 | watercolor, hand-drawn texture |

**完整示例**：

> **Prompt**:
> 极简风格的章节过渡装饰图。画面中央是一个抽象的几何图形——由三条柔和的渐变色带（品牌蓝色、白色、淡紫色）交织而成的螺旋形图案。背景是纯净的白色，图案边缘有细腻的渐隐效果。整体感觉轻盈、现代、不抢内容焦点。画面纵向构图，适合放在页面一侧作为装饰。不含文字, 无水印。
>
> **尺寸**: 1024×1792（纵向）
> **适用场景**: 章节分隔页的一侧装饰

---

#### 2.3 结尾/收尾愿景图

**触发条件**：
- 作品需要一个有感染力的收尾画面
- 愿景/目标可以用一个视觉场景表达（如山顶、地平线、日出）
- 需要给受众留下情感印象

**不适用**：
- 纯信息传递型作品（结尾只需总结要点）
- 已有品牌规定的结尾页模板

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 通用/激励 | 电影级风景、暖色调 | cinematic landscape, golden hour, warm tones |
| 科技/产品 | 未来主义城市、科幻 | futuristic cityscape, sci-fi, dawn light |
| 教育/培训 | 温暖插画、人物剪影 | warm illustration, silhouette, sunrise |

**完整示例**：

> **Prompt**:
> 一条蜿蜒的山路通向远处的金色地平线，道路两侧是柔和的绿色丘陵。画面正中偏下是一个剪影人物站在山顶，面朝远方的日出。天空是渐变的橙红色到金色，几朵薄云点缀其中。整体氛围温暖、充满希望和前瞻感。浅景深，远处的山脉微微模糊。画面干净简洁，下方预留空间放联系方式。不含文字, 无水印。
>
> **尺寸**: 1792×1024
> **适用场景**: 演讲结尾页、愿景展望、激励型收尾

**风格呼应规则**：结尾页的视觉风格**必须与封面保持一致**（同一风格维度锁，§1.5）。如果封面是 2.5D 等距城市，结尾页不应突然切换到写实摄影——应延续同视角、同质感，可调整色调（封面暖色 → 结尾页金色渐变）来制造首尾呼应的叙事感。

---

### 维度 2：配图与图标

#### 2.4 概念配图

**触发条件**：
- 内容包含抽象概念需要视觉化解释（如"数字化转型"、"数据驱动"）
- 文字描述冗长，一张图胜过一段话
- 内容区域有足够空间放置配图（通常搭配双栏布局：左文右图或左图右文）

**不适用**：
- 概念很简单，一句话就能说清楚
- 已有产品截图/真实照片可用
- 内容区域空间不足（纯文字列表页）

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 科技/企业 | 等距插画、扁平 | isometric illustration, flat design |
| 通用/商务 | 简约线条、极简 | minimalist line art, clean |
| 创意/品牌 | 水彩、手绘 | watercolor, hand-drawn, organic |

**完整示例**：

> **Prompt**:
> 等距风格的"数据驱动决策"概念插画。画面呈现一个透明的玻璃漏斗，数据流（蓝色和白色的小方块）从上方涌入，经过漏斗中间的分析层（齿轮和图表图标），最终从下方流出为三个整齐排列的金色立方体（代表决策产出）。整体使用品牌蓝色系，浅灰色背景，黏土材质质感，柔和的顶部光照。不含文字, 无水印。
>
> **尺寸**: 1024×1024
> **适用场景**: 双栏布局页面中的概念解释配图

---

#### 2.5 主题化图标

**触发条件**：
- 需要视觉叙事能力的定制图标（如太空主题需要星球/火箭图标，自然主题需要叶子/水滴图标）
- 通用 CSS 图标（数字、字母、简单几何形状）无法传达主题含义

**与 CSS 图形的选择边界**：

| 场景 | 用 CSS | 用 AI |
|------|--------|-------|
| 编号/顺序（①②③、01/02/03） | ✅ CSS 圆形 + 数字 | ❌ |
| 简单符号（箭头、加号、对勾） | ✅ CSS 图形 | ❌ |
| 品牌已有 SVG 图标 | ✅ 直接使用 | ❌ |
| 主题化图标（星球、齿轮、叶子） | ❌ 不够表达 | ✅ AI 生图 |
| 情感化图标（表情、手势） | ❌ 不够表达 | ✅ AI 生图 |

**完整示例（四步法行内格式，适用于简单场景）**：

> **Prompt**: 一个微缩的地球仪图标，放置在简约的蓝色圆形底座上，等距风格，黏土材质，柔和光线从左上方照射，白色背景。不含文字, 无水印。
>
> **尺寸**: 1024×1024
> **适用场景**: 全球化/国际化相关页面的主题化图标

---

### 维度 3：内容视觉化

> 维度 3 是重点。当信息之间有明确的关系结构（流程、层级、对比、因果）时，AI 生图可以将"文字堆叠"变为"视觉化信息图"，大幅提升信息传达效率。

#### 2.6 流程/步骤可视化

**触发条件**：
- 内容描述了一个多步骤的过程或工作流
- 步骤之间有先后/递进/循环关系
- 纯文字列表无法有效传达流程的方向性和连贯性

**不适用**：
- 步骤数 ≤ 2（太简单，文字足够）
- 步骤间关系纯线性且无分支（CSS 时间线够用）

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 科技/企业 | 等距管道、3D | isometric pipeline, 3D render |
| 通用/教育 | 扁平插画 | flat illustration, infographic style |
| 创意/品牌 | 手绘流程图 | hand-drawn flowchart, organic lines |

**Prompt 模板（结构化 6 段式）**：

```
1. 画面场景：
   [流程发生的场景/环境]。[整体布局：水平/垂直/环形]。

2. 主体描述：
   [步骤数量] 个步骤，从 [起点] 到 [终点]。
   每个步骤：[具体物化场景描述]。
   步骤间的连接：[具象化连接元素]。

3. 构图与视角：
   [视角]。[是否需要留白放标题/说明]。

4. 光线与色彩：
   [整体色调]。[是否需要步骤间色彩渐变表示进展]。

5. 材质与细节：
   [质感风格]。

6. 排除项：
   不含文字, 无水印[其他排除项]。
```

**物化指令（必须遵守）**：
- 禁止使用纯几何形状（彩色圆形内嵌图标符号）作为步骤视觉表现
- 每个步骤的视觉表现必须是一个**具体物体或场景隐喻**：
  - "需求分析" → 人物拿着放大镜检查文档
  - "架构设计" → 建筑师在蓝图前工作
  - "编码实现" → 工匠在工台上组装零件
  - "测试验证" → 质检员用仪器检测产品
  - "部署上线" → 火箭发射台上的火箭
- 连接元素用具体物体：管道、传送带、河流、桥梁等，不用抽象箭头

**完整示例**：

> **Prompt**:
> 扁平化信息图风格的软件开发流程图。水平布局，从左到右呈现 5 个步骤：需求分析（一位分析师手持放大镜仔细检查桌上铺开的文档）→ 架构设计（建筑师在半透明蓝图前用笔规划楼层结构）→ 编码实现（工匠在明亮工台上组装精密零件）→ 测试验证（质检员用仪器检测传送带上的产品）→ 部署上线（发射台上蓄势待发的火箭）。步骤之间用发光的数据流管道连接，管道颜色从蓝色渐变到红色。每个场景周围有柔和的光晕。白色背景，画面干净简洁，上下留白充足。不含文字, 无水印, 无边框。
>
> **尺寸**: 1792×1024
> **适用场景**: 工作流程/开发流程/业务流程的视觉化呈现

---

#### 2.7 架构/系统/关系可视化

**触发条件**：
- 内容描述了多层级的系统架构、模块关系、或概念之间的因果/依赖/包含关系
- 关系结构复杂，文字列表无法清晰表达层级和连接

**不适用**：
- 层级 ≤ 2 层（简单列表够用）
- 已有标准化的架构图模板（如 AWS/Azure 架构图）

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 科技/企业 | 等距微缩城市、分层建筑 | isometric city, layered architecture |
| 通用/教育 | 简约分层图、树状图 | layered diagram, tree structure |
| 概念解释 | 隐喻场景（如大脑=神经网络） | metaphor scene |

**物化指令（必须遵守）**：
- 禁止使用纯几何分层图（矩形方块堆叠、网格矩阵）
- 架构层次用**现实场景隐喻**表现：
  - "基础服务层" → 地下管道系统 / 建筑地基 / 树根系统
  - "业务服务层" → 工厂车间 / 办公楼层 / 树枝分叉
  - "API 网关层" → 城门 / 交通枢纽 / 树冠
- 层间连接用具体物体：管道、桥梁、电梯、阶梯，不用抽象线条

**完整示例**：

> **Prompt**:
> 等距微缩城市风格的微服务架构图。俯瞰 45 度视角。画面分为三层平台，每层由透明玻璃材质的桥板连接。底层平台：3 座深灰色方形建筑（代表基础服务——数据库、消息队列、认证），上面有蓝色 LED 灯带。中层平台：4 座较高的半透明建筑（代表业务服务——用户、订单、支付、通知），分别用蓝色、绿色、琥珀色、紫色标识。顶层平台：2 座通透的玻璃塔楼（代表 API 网关和负载均衡），楼内可以看到数据流动的光粒子效果。层与层之间有发光的数据流管道连接。背景是深色渐变。不含文字, 无水印。
>
> **尺寸**: 1792×1024
> **适用场景**: 系统架构、微服务架构、技术栈展示

---

#### 2.8 对比/优劣势可视化

**触发条件**：
- 内容需要对比两个或多个方案/方案/选项
- 对比维度明确（如"优势 vs 劣势"、"方案 A vs 方案 B"、"之前 vs 之后"）

**不适用**：
- 简单的二元对比（一个对比表格就够）
- 对比项 ≤ 3（CSS 卡片布局够用）

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 通用 | 分屏对比、左右对称 | split screen, symmetric comparison |
| 科技 | 天平、赛道路 | balance scale, racing track |
| 叙事 | 之前/之后、日出/日落 | before/after, sunrise/sunset metaphor |

**物化指令（必须遵守）**：
- 禁止左右两栏纯色块+抽象图形对比
- 对比双方用**有现实意义的场景**表达差异：
  - "传统方案" → 破旧/混乱/低效的具体场景（生锈机器、堆满文件的桌子、拥堵马路）
  - "新方案" → 现代/整洁/高效的具体场景（崭新设备、数字化工作台、畅通高速）
- 中间分隔用具象物体（天平中轴、赛道中线、河流分岔），不用虚线

**完整示例**：

> **Prompt**:
> 扁平化信息图风格的技术选型对比图。画面分为左右两个区域，中间由一条虚线分隔。左侧（过去/传统方案）：灰色调，一座堆满积木的摇摇欲坠的高塔，积木上散落着警告标识。右侧（现在/新方案）：明亮色调，一座稳固的金字塔结构，每一层都整齐排列着相同规格的方块，顶部有一面小旗帜。两侧的底部各有一个简洁的标签区域（留白不放文字）。背景是纯净的浅灰色。整体风格简洁现代。不含文字, 无水印。
>
> **尺寸**: 1792×1024
> **适用场景**: 方案对比、技术选型、前后对比、优劣分析

---

#### 2.9 数据/指标可视化

**⚠️ AI 生图不擅长精确数据图表**

AI 生成的数据图表（柱状图、饼图、折线图）存在以下问题：
- 数据不准确（AI 无法精确计算比例）
- 标签/数字可能渲染错误或位置偏移
- 缺乏交互性（无法悬停查看详细数据）

**推荐替代方案**：
- 数据图表 → 使用 Chart.js / ECharts 等工具生成精确图表
- 数据背景氛围图 → AI 生图可以为数据页面提供装饰性背景（但数据本身用图表工具）

**适用场景**（仅限氛围背景）：

> **Prompt**:
> 抽象的数据流动背景装饰图。画面呈现多条流动的光带（品牌蓝色和白色），在深色背景上从左向右流动，光带上偶尔有发光的数据节点。整体效果抽象、科技感、不抢内容焦点。低对比度，适合作为背景图使用。不含文字, 无水印。
>
> **尺寸**: 1792×1024
> **适用场景**: 数据页面的装饰性背景（数据图表本身用 Chart.js 等工具）

---

#### 2.10 时间线/路线图可视化

**触发条件**：
- 内容描述了时间线上的里程碑、发展阶段或演进路径
- 时间跨度明确（如"2024-2026 三年规划"）
- 纯文字列表无法传达时间的连续性和阶段感

**不适用**：
- 里程碑 ≤ 3 个（简单列表够用）
- 时间线是纯线性的且无分支（CSS 时间线够用）

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 科技/企业 | 赛道、等距路径 | isometric roadmap, tech track |
| 通用/教育 | 山路、阶梯 | mountain path, staircase metaphor |
| 创意/品牌 | 地图航线 | vintage map, flight route |

**物化指令（必须遵守）**：
- 禁止抽象圆点+直线的纯几何时间线
- 用**现实隐喻**表达路径和节点：
  - 里程碑站点用具体建筑/地标（灯塔、车站、城堡、山峰）
  - 路径用具体道路类型（山路、公路、河流、赛道）
  - 阶段区分用环境变化（季节更替、昼夜交替、天气变化）

**完整示例**：

> **Prompt**:
> 等距风格的三年战略路线图。水平布局，从左到右呈现一条蜿蜒向上的赛道，赛道分为三段，分别用蓝色（第一年：基础建设）、绿色（第二年：能力提升）、金色（第三年：规模扩张）标识。每段赛道上有 2-3 个简洁的站点标记（发光的圆点）。赛道周围有微型的等距建筑代表不同阶段的目标成就。背景是柔和的渐变色（从左下方的浅蓝到右上方的暖金色）。画面干净简洁，预留标题区域。不含文字, 无水印。
>
> **尺寸**: 1792×1024
> **适用场景**: 年度战略、产品路线图、发展历程

---

### 维度 4：局部装饰（小图多产）

> Samuel 反馈："是不是可以多点插画，又或者是背景，又或者是卡片的背景，又或者是卡片的装饰元素，等等这一些方向"。核心思路：**大图少（封面/结尾），小图多（卡片背景/装饰元素）**——小图生成难度低、容错率高，能快速提升整份作品的视觉丰富度。

#### 2.11 卡片背景装饰

**触发条件**：
- 页面有多个卡片（L08 three-column、L06 bullets 等）
- 卡片用纯 CSS 背景过于单调，需要增加视觉层次
- 适合"精选卡片"场景——不是所有卡片都需要 AI 背景

**不适用**：
- 卡片内已有复杂图表或图片（AI 背景会干扰内容）
- 卡片数量 > 6（背景图太多反而杂乱）
- 数据密集型卡片（数值为主，背景抢焦点）

**标注方式**：`[card-bg: N]`，N 为需要 AI 背景的卡片数量（1-3）。相邻卡片建议交替使用 AI 背景 vs CSS 纯色，避免视觉疲劳。

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 科技/产品 | 抽象几何渐变 | abstract gradient, geometric, tech |
| 企业/战略 | 简约纹理 | subtle texture, minimal, clean |
| 创意/品牌 | 水彩泼墨 | watercolor splash, artistic, organic |
| 教育/培训 | 手绘插画背景 | hand-drawn illustration, warm |

**Prompt 模板（简化 3 段式）**：

```
1. 风格与色调：
   [继承风格锚点]，[品牌色描述]。
   适合作为卡片背景：明暗适中，边缘渐隐。

2. 主体：
   [抽象/几何/纹理背景描述]。
   适合叠加白色或浅色文字。

3. 排除项：
   不含文字, 无水印, 不含人物, 不含具体物体。
```

**完整示例**：

> **Prompt**:
> 扁平商务插画风格，品牌蓝色系（cobalt blue + 琥珀色点缀）。抽象的几何渐变背景——从左下方的深蓝色渐变到右上方的淡琥珀色，中间交织着几条半透明的白色几何线条和圆形光点。整体效果简洁现代，边缘渐隐到透明，适合叠加浅色文字。不含文字, 无水印, 不含人物, 不含具体物体。
>
> **尺寸**: 1024×1024
> **适用场景**: 能力介绍页的精选卡片背景（搭配双栏或三栏布局）

**批量变体**：当 `[card-bg: 3]` 时，3 张卡片背景应共享风格但细节不同（角度、色相微偏、纹理变化），通过 prompt 尾部添加差异化描述实现。

---

#### 2.12 页面装饰元素

**触发条件**：
- 页面边缘/角落适合放小型装饰插画，增加精致感
- 页面主要内容居中，四周有留白空间
- 不影响内容可读性，纯氛围增强

**不适用**：
- 内容已填满整个页面（无多余空间）
- 信息密度高的页面（数据页、表格页）
- 封面/结尾页已有全幅主图（不需要额外装饰）

**标注方式**：`[decor: position]`，position 可选值：
- `corner-bl` — 左下角（最常用，自然阅读动线的终点）
- `corner-tr` — 右上角
- `corner-br` — 右下角
- `corner-tl` — 左上角
- `side-left` — 左侧纵向装饰条
- `side-right` — 右侧纵向装饰条

**风格推荐**：

| 场景类型 | 推荐风格 | 关键词 |
|---------|---------|--------|
| 科技/产品 | 抽象几何碎片、光线 | abstract geometry, light particles |
| 企业/战略 | 极简线条、渐变色块 | minimal lines, gradient blocks |
| 自然/环保 | 植物剪影、水彩 | plant silhouette, watercolor |
| 创意/品牌 | 手绘涂鸦、品牌色形状 | hand-drawn doodle, brand shapes |

**Prompt 模板（简化 3 段式）**：

```
1. 风格与色调：
   [继承风格锚点]，[品牌色描述]，半透明/淡雅处理。

2. 主体：
   [小型装饰元素描述]，[位置暗示]。
   尺寸感：小巧精致，不遮挡内容。

3. 排除项：
   不含文字, 无水印, 不含人物。
```

**完整示例**：

> **Prompt**:
> 扁平商务插画风格，品牌蓝色（cobalt blue）半透明处理。一组抽象的几何碎片和光粒子，从画面右上角向左下方散射。碎片大小不一，最大碎片约占画面 1/4，其余零星分布。整体透明度 30-50%，白色背景，适合叠加在页面右上方作为装饰。不含文字, 无水印, 不含人物。
>
> **尺寸**: 1024×1024
> **适用场景**: 内容页右上角装饰，增加视觉精致度

---

#### 2.13 区块背景装饰

**触发条件**：
- 页面有明确的内容区块划分（如上区标题+下区要点）
- 某个区块需要"背景氛围"但不需要完整的信息图
- 适合数据页、案例页、CTA 页等

**不适用**：
- 全页已有主图（封面、结尾）
- 内容区叠加文字较多（背景太花影响阅读）

**标注方式**：`[section-bg]`，表示页面主内容区需要 AI 生成的背景氛围图。通常与 CSS `background-image` + `background-size: cover` + 半透明叠加层配合使用。

**Prompt 模板（简化 3 段式）**：

```
1. 风格与色调：
   [继承风格锚点]，[品牌色描述]，低对比度，适合内容叠加。

2. 主体：
   [抽象场景/氛围背景]，大面积色块或渐变，留出中央文字区域。

3. 排除项：
   不含文字, 无水印, 不含人物, 画面简洁不抢焦点。
```

**完整示例**：

> **Prompt**:
> 扁平商务插画风格，品牌蓝色系。大面积的抽象渐变背景——从左到右由深蓝色过渡到品牌蓝色，中间有几条极细的白色流动线条，右下角有一组模糊的几何形状。整体效果沉稳、科技感、不抢内容焦点，适合作为全页背景图叠加半透明色层后放文字。不含文字, 无水印, 不含人物。
>
> **尺寸**: 1792×1024
> **适用场景**: 数据页/CTA 页的全页背景氛围

---

## 三、Prompt 工程速查

### 3.1 四步法

来源：pagecraft `references/prompt-guide.md`（完整文档参考原文）。

1. **提取核心意图**：从内容中提取主体、风格、构图、光线、氛围、用途
2. **补全缺失要素**：用户通常只描述主体，其他要素需 AI 根据上下文推断
   - 用户没说风格 → 优先：扁平插画、简约商务、写实摄影
   - 用户没说光线 → 主动设计（光线是影响质量最大的要素）
3. **组装 Prompt**：按优先级排列，前 50 词权重最高
   - 复杂场景用结构化 6 段式（§2.x 的 Prompt 模板）
   - 简单场景用行内格式（见 3.2）
4. **控制长度**：简单 50-100 词，一般 200-500 词，复杂 500-1000 词

### 3.2 两套 Prompt 格式

**结构化 6 段式**（复杂场景：封面、内容视觉化）：
```
1. 画面场景：[环境/天气/背景]
2. 主体描述：[核心对象/材质/颜色/细节]
3. 构图与视角：[相机角度/景深/布局]
4. 光线与色彩：[光源/色温/色调]
5. 材质与细节：[表面纹理/微观特征]
6. 排除项：[不需要的元素]
```

**四步法行内格式**（简单场景：图标、小装饰）：
```
[主体 + 动作/姿态], [风格], [光线], [构图/视角], [氛围/色调], [排除项]
```

### 3.3 风格关键词表

| 风格 | 中文关键词 | 英文关键词 |
|------|-----------|-----------|
| 写实摄影 | 真实照片质感, 自然光线, 8K高清 | photorealistic, 8K, natural lighting, sharp focus |
| 赛博朋克 | 赛博朋克, 霓虹灯, 暗夜都市 | cyberpunk, neon lights, futuristic city |
| 日式动漫 | 动漫风格, 赛璐璐上色, 明亮色彩 | anime, cel shading, vibrant colors |
| 吉卜力 | 宫崎骏风格, 温暖治愈, 手绘质感 | Studio Ghibli, warm, hand-drawn |
| 扁平插画 | 扁平化设计, 简洁色块, 矢量感 | flat illustration, clean shapes, vector style |
| 极简主义 | 极简, 大量留白, 几何形状 | minimalist, white space, geometric |
| 3D 渲染 | 3D渲染, 体积光, 材质质感 | 3D render, volumetric lighting |
| 玻璃态 | 玻璃态, 透明磨砂材质, 光泽折射 | glassmorphism, frosted glass |
| 水彩画 | 水彩, 柔和边缘, 色彩晕染 | watercolor, soft edges, paper texture |
| 国潮新中式 | 新中式, 水墨+现代, 传统纹样 | neo-Chinese, ink + modern |
| 像素风 | 像素画, 8-bit, 复古游戏 | pixel art, 8-bit, retro game |
| 手绘素描 | 手绘, 铅笔素描, 纸张纹理 | hand-drawn, pencil sketch, organic lines |
| 波普艺术 | 波普艺术, 高饱和色块, 漫画风格 | pop art, bold colors, comic style |
| 等距微缩 | 等距视角, 微缩城市, 黏土材质 | isometric, miniature city, clay material |

### 3.4 尺寸选择指南

| 用途 | 推荐尺寸 | 说明 |
|------|---------|------|
| 通用/图标 | 1024×1024 | 正方形，默认尺寸 |
| 封面/全幅图 | 1792×1024 | 横向宽幅（待确认 API 是否支持） |
| 纵向装饰 | 1024×1792 | 纵向 |

> **注意**：pagecraft prompt-guide.md 列出了 1792×1024，但需确认 gpt-image-2 实际支持的尺寸。如果 1792×1024 不可用，使用 1024×1024 或 1536×1024 替代。

### 3.5 Prompt 语言策略

- **需要渲染文字的图片**（如封面标题、标签）：prompt 必须中文，GPT-Image-2 中文渲染准确率 ~99%
- **不需要文字的图片**（氛围图、抽象插画）：默认中文，英文也可以，效果差异不大
- **混合语言可用**：中文描述主体 + 英文风格关键词（如 "一座现代建筑, minimalist, clean lines"）

---

## 四、质量标准与限制

### 4.1 AI 生图能力边界

| 能力 | 评级 | 说明 |
|------|------|------|
| 概念隐喻/场景插画 | ✅ 强 | 封面氛围、过渡图、愿景图 |
| 流程/架构视觉化 | ⚠️ 中等 | 结构正确但细节可能不准确 |
| 数据图表 | ❌ 弱 | 比例/数字不准确，推荐用 Chart.js |
| 大量文字渲染 | ❌ 弱 | 短标题可用，长段落不可靠 |
| 精确的空间布局 | ⚠️ 中等 | 基本构图可以，精确像素级对齐不可靠 |

### 4.2 中文文字渲染

- GPT-Image-2 中文渲染准确率约 99%
- **短文字可用**（1-10 个字的标题/标签）
- **长文字不推荐**（完整句子可能出错或字体不协调）
- 如需渲染文字，prompt 中直接包含文字内容

### 4.3 品牌一致性

**风格锚点机制**（§1.5 已详述）：选定风格后所有 prompt 继承。

**品牌色注入方法**：

AI 模型理解的是颜色名称（如 "cobalt blue"），不是 hex 值。转换方法：

| 品牌色（hex） | 最接近的 CSS 色名 | Prompt 色彩描述 |
|-------------|-----------------|----------------|
| `#3b6cff` | `DodgerBlue` | "道奇蓝" / "cobalt blue" |
| `#7a5cff` | `SlateBlue` | "石板蓝" / "slate blue" |
| `#ff5c8a` | `RosePink` | "玫瑰粉" / "rose pink" |
| `#1aaf6c` | `EmeraldGreen` | "翡翠绿" / "emerald green" |
| `#f5a524` | `Amber` | "琥珀色" / "amber" |
| `#e0445a` | `Crimson` | "绯红" / "crimson" |

> 运行时从 brand-spec.md 读取品牌色，转换为 prompt 色彩描述后注入模板。

### 4.4 失败降级策略

API 调用失败时（超时、网络错误、返回异常），按视觉类型降级为 CSS 方案。以下模板可直接复制使用，所有类和变量均来自 `tokens.css`。

| 维度 | 降级方案 | 效果 |
|------|---------|------|
| 维度 1（装饰性插画） | CSS 渐变背景 + 装饰元素 | 仍有视觉氛围，只是不如 AI 图有表现力 |
| 维度 1（结尾愿景图） | CSS 渐变氛围 + 居中大字金句 | 仍有收尾仪式感 |
| 维度 2（配图/图标） | CSS 圆形图标 | 数字/字母图标仍然实用 |
| 维度 3（流程/架构可视化） | 自包含 HTML/CSS 图表 | 保留布局结构，信息传达不受损 |
| 维度 3（对比可视化） | CSS 双栏对比卡片 | 正/负面分栏，顶部色带区分 |
| 维度 3（时间线可视化） | CSS 纵向时间线 | 首节点实心，节点+标签+文字 |

#### 4.4.1 封面/章节过渡装饰图 FAILED → CSS 渐变+装饰元素

```html
<!-- <style> 块 -->
<style>
.cover-bg {
  position: absolute; inset: 0; z-index: -1;
  background: radial-gradient(ellipse at 30% 50%, var(--accent, #3b6cff) 0%, transparent 70%);
}
.cover-blob {
  position: absolute; left: -60px; top: 50%; transform: translateY(-50%);
  width: 200px; height: 200px; border-radius: 50%;
  background: var(--accent, #3b6cff); opacity: .08; filter: blur(4px);
}
</style>

<!-- 封面/章节页 body 内 -->
<div class="cover-bg"></div>
<div class="cover-blob"></div>
<div style="position:absolute;right:-80px;top:-80px;width:350px;height:350px;border-radius:50%;background:var(--accent-2,#7a5cff);filter:blur(6px);opacity:.15;z-index:0;"></div>
```

> `.cover-bg` 提供径向渐变氛围，`.cover-blob` 是左侧装饰圆。额外在右上角添加一个模糊光斑增加层次。`var(--accent)` 带 fallback 值确保无主题变量时也能工作。

#### 4.4.2 概念配图 FAILED → CSS 占位框+中心图标

```html
<div class="card" style="padding:var(--space-lg);text-align:center;max-width:360px;">
  <div style="width:96px;height:96px;border-radius:50%;background:rgba(59,108,255,.08);display:flex;align-items:center;justify-content:center;margin:0 auto var(--space-md);">
    <p class="mono" style="font-size:36px;font-weight:700;color:var(--accent);">D</p>
  </div>
  <p class="dim" style="font-size:var(--fs-caption);">[概念名称] 概念示意</p>
</div>
```

> 圆形字母图标复用 `.logo-mark` 模式。字母替换为概念首字母（如 D=Data、A=AI、S=Security）。

#### 4.4.3 主题化图标 FAILED → CSS 圆形图标

```html
<div style="width:48px;height:48px;border-radius:50%;background:rgba(59,108,255,.08);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
  <p style="font-size:18px;font-weight:700;color:var(--accent);">1</p>
</div>
```

> 与 L08 三栏布局的图标模式一致。可替换为字母或短文字（≤2 字）。

#### 4.4.4 流程/架构可视化 FAILED → 简化 HTML/CSS 图表

**流程图（自包含）**：

```html
<style>
.flow { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.node {
  padding:10px 20px; border-radius:8px;
  background:var(--surface,#fff); border:1px solid var(--border,rgba(0,0,0,.08));
  font-size:var(--fs-body,14px); color:var(--text,#333);
}
.node.hl { background:var(--accent,#3b6cff); color:#fff; border-color:var(--accent,#3b6cff); }
.arr { font-size:20px; color:var(--muted,#999); }
</style>
<div class="flow">
  <div class="node">需求分析</div>
  <div class="arr">&rsaquo;</div>
  <div class="node hl">架构设计</div>
  <div class="arr">&rsaquo;</div>
  <div class="node">编码实现</div>
</div>
```

**架构图（自包含）**：

```html
<style>
.arch { display:flex; flex-direction:column; gap:12px; width:100%; }
.tier {
  display:flex; align-items:center; gap:12px;
  padding:12px 16px; border-radius:8px;
  background:var(--surface,#fff); border:1px solid var(--border,rgba(0,0,0,.08));
}
.tier-name {
  font-size:12px; font-weight:600; color:var(--accent,#3b6cff);
  min-width:60px; text-align:right;
}
.cells { display:flex; gap:8px; flex-wrap:wrap; }
.cell {
  padding:6px 14px; border-radius:6px;
  background:var(--surface-2,#f5f7fa); font-size:var(--fs-caption,12px); color:var(--text,#333);
}
</style>
<div class="arch">
  <div class="tier"><span class="tier-name">接入层</span>
    <div class="cells"><div class="cell">API 网关</div><div class="cell">负载均衡</div></div>
  </div>
  <div class="tier"><span class="tier-name">业务层</span>
    <div class="cells"><div class="cell">用户服务</div><div class="cell">订单服务</div></div>
  </div>
</div>
```

> 所有 CSS 变量带 fallback 值，无主题变量时也能正常渲染。layout-catalog.md 的 L17/L21 有更丰富的变体，优先使用。

#### 4.4.5 对比/优劣势可视化 FAILED → CSS 双栏对比卡片

```html
<style>
.compare-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; width:100%; }
.compare-col {
  padding:20px; border-radius:10px;
  background:var(--surface,#fff); border:1px solid var(--border,rgba(0,0,0,.08));
}
.compare-col.pro { border-top:3px solid var(--accent,#3b6cff); }
.compare-col.con { border-top:3px solid var(--muted,#999); }
.compare-col h4 { font-size:var(--fs-h4,16px); margin-bottom:12px; }
.compare-col li {
  font-size:var(--fs-body,14px); color:var(--text,#333);
  padding:4px 0; list-style:none;
}
.compare-col li::before { content:"· "; color:var(--accent,#3b6cff); font-weight:700; }
</style>
<div class="compare-grid">
  <div class="compare-col pro">
    <h4>优势</h4>
    <ul><li>自动化部署</li><li>实时监控</li><li>弹性扩缩容</li></ul>
  </div>
  <div class="compare-col con">
    <h4>挑战</h4>
    <ul><li>学习曲线</li><li>初期成本</li><li>依赖云服务</li></ul>
  </div>
</div>
```

> 双栏布局，顶部色带区分正/负面。`var()` 带 fallback，无主题变量也能工作。适合 `[visual: comparison]` 失败时降级。

#### 4.4.6 时间线/路线图可视化 FAILED → CSS 纵向时间线

```html
<style>
.timeline { display:flex; flex-direction:column; gap:0; position:relative; padding-left:28px; }
.timeline::before {
  content:""; position:absolute; left:9px; top:0; bottom:0; width:2px;
  background:var(--border,rgba(0,0,0,.1));
}
.tl-item { display:flex; gap:16px; padding:12px 0; position:relative; }
.tl-dot {
  position:absolute; left:-28px; top:16px;
  width:20px; height:20px; border-radius:50%;
  background:var(--surface,#fff); border:2px solid var(--accent,#3b6cff);
}
.tl-item:first-child .tl-dot { background:var(--accent,#3b6cff); }
.tl-label { font-size:var(--fs-caption,12px); color:var(--muted,#666); margin-bottom:2px; }
.tl-text { font-size:var(--fs-body,14px); color:var(--text,#333); }
</style>
<div class="timeline">
  <div class="tl-item">
    <div class="tl-dot"></div>
    <div><div class="tl-label">Q1 2026</div><div class="tl-text">完成基础架构搭建</div></div>
  </div>
  <div class="tl-item">
    <div class="tl-dot"></div>
    <div><div class="tl-label">Q2 2026</div><div class="tl-text">核心功能上线</div></div>
  </div>
  <div class="tl-item">
    <div class="tl-dot"></div>
    <div><div class="tl-label">Q3 2026</div><div class="tl-text">全面推广运营</div></div>
  </div>
</div>
```

> 纵向时间线，首节点实心、其余空心。`var()` 带 fallback。适合 `[visual: timeline]` 失败时降级。

#### 4.4.7 结尾愿景图 FAILED → CSS 渐变氛围+大字金句

```html
<style>
.ending-bg {
  position:absolute; inset:0; z-index:-1;
  background:linear-gradient(135deg, var(--accent,#3b6cff) 0%, var(--accent-2,#7a5cff) 100%);
  opacity:.06;
}
.ending-text {
  font-size:var(--fs-h1,40px); font-weight:800;
  color:var(--text,#333); text-align:center;
  max-width:600px; margin:0 auto; line-height:1.4;
}
</style>
<div class="ending-bg"></div>
<div class="ending-text">未来已来，<br>让我们一起定义下一个十年</div>
```

> 渐变氛围 + 居中大字金句，无图也能有收尾仪式感。适合 `[visual: ending]` 失败时降级。

#### 4.4.8 卡片背景装饰 FAILED → CSS 微渐变背景

```html
<div class="card" style="background:linear-gradient(135deg, color-mix(in srgb, var(--accent,#3b6cff) 6%, transparent), color-mix(in srgb, var(--accent-2,#7a5cff) 6%, transparent));border:none;">
  <h4>标题</h4>
  <p>内容</p>
</div>
```

> 或者更简单的方案：直接使用 `var(--brand-gradient-soft, linear-gradient(...))`。

#### 4.4.9 页面装饰元素 FAILED → CSS 几何装饰

```html
<!-- 右下角装饰 -->
<div style="position:absolute;bottom:40px;right:40px;width:72px;height:72px;border-radius:50%;background:var(--grad,var(--accent,#3b6cff));opacity:.12;"></div>
<div style="position:absolute;bottom:60px;right:88px;width:32px;height:32px;border-radius:50%;border:2px solid var(--accent,#3b6cff);opacity:.18;"></div>
```

> 复用 `.brand-dot` 模式。两个大小不同的圆叠加，营造层次感。根据 `[decor: position]` 调整定位。

### 4.5 生成成本意识

| 项目 | 说明 |
|------|------|
| 单次 API 调用耗时 | 30 秒 - 2 分钟 |
| 一份完整作品（5-10 张图） | 5 - 20 分钟 |
| 判断是否值得 | 高价值页面（封面、关键数据、重要流程）优先，纯装饰页面最后考虑 |

---

## 五、Slides 应用层 [SLIDES]

> 以下内容仅适用于 html-slide-gen 任务一。任务二（通用 image2 skill）不使用本章。

### 5.1 大纲标注规范 [SLIDES]

在 Phase 2（大纲阶段），Claude 为每页大纲标注视觉需求。标注分两级：**页面级**（主视觉）和**元素级**（局部装饰）。

#### 页面级标注（每页一个）

标注放在大纲每页标题后面：`### PPT-X：页面标题 [visual: flow-infographic] [layout: L17]`

> `[layout: Lxx]` 在 Phase 4.3（布局阶段）追加，不在 Phase 2（大纲阶段）填写。

| 标注 | 含义 | 对应维度 | 尺寸 | Prompt 复杂度 |
|------|------|---------|------|-------------|
| `[visual: cover]` | 封面氛围图 | 维度 1 (2.1) | 1792×1024 | A（6 段式） |
| `[visual: section-divider]` | 章节过渡装饰图 | 维度 1 (2.2) | 1024×1792 | A（6 段式） |
| `[visual: ending]` | 结尾愿景图 | 维度 1 (2.3) | 1792×1024 | A（6 段式） |
| `[visual: illustration]` | 概念配图 | 维度 2 (2.4) | 1024×1024 | A（6 段式） |
| `[visual: icon]` | 主题化图标 | 维度 2 (2.5) | 1024×1024 | C（行内式） |
| `[visual: flow-infographic]` | 流程可视化 | 维度 3 (2.6) | 1792×1024 | A（6 段式） |
| `[visual: arch-infographic]` | 架构可视化 | 维度 3 (2.7) | 1792×1024 | A（6 段式） |
| `[visual: comparison]` | 对比可视化 | 维度 3 (2.8) | 1792×1024 | A（6 段式） |
| `[visual: data-bg]` | 数据页氛围背景 | 维度 3 (2.9) | 1792×1024 | A（6 段式） |
| `[visual: timeline]` | 时间线可视化 | 维度 3 (2.10) | 1792×1024 | A（6 段式） |
| `[visual: none]` | 不需要页面级 AI 生图 | — | — | — |

#### 元素级标注（每页零或多个，紧跟页面级标注）

| 标注 | 含义 | 对应维度 | 尺寸 | Prompt 复杂度 |
|------|------|---------|------|-------------|
| `[card-bg: N]` | 为 N 个卡片生成背景图 | 维度 4 (2.11) | 1024×1024 | B（3 段式） |
| `[decor: position]` | 页面装饰元素 | 维度 4 (2.12) | 1024×1024 | B（3 段式） |
| `[section-bg]` | 区块背景氛围图 | 维度 4 (2.13) | 1792×1024 | B（3 段式） |

position 可选值：`corner-bl`、`corner-tr`、`corner-br`、`corner-tl`、`side-left`、`side-right`

#### 标注示例

```
P01  专业航拍，让项目高出一个身位 [visual: cover] [layout: L01]

P03  消费级设备有三大硬伤 [visual: comparison] [card-bg: 3] [layout: L24]

P05  我们用航空级设备+专业飞手 [visual: arch-infographic] [decor: corner-bl] [layout: L21]

P07  已交付地产、文旅、基建超过200个项目 [visual: data-bg] [card-bg: 2] [layout: L11]

P09  不是让你多花一笔钱 [visual: ending] [layout: L04]

P10  预约免费试拍 [visual: none] [section-bg] [decor: corner-tr] [layout: L05]
```

#### Prompt 复杂度分层

| 层级 | 适用 | 模板 | 说明 |
|------|------|------|------|
| A（6 段式） | 封面、结尾、信息图 | §2.x 完整模板 | 场景+主体+构图+光线+材质+排除 |
| B（3 段式） | 卡片背景、装饰元素、区块背景 | 简化模板 | 风格色调+主体+排除 |
| C（行内式） | 图标 | §2.5 四步法 | 主体+风格+光线+排除 |

**设计原则**：
- **大图少**：A 类图片每页最多 1 张（封面/结尾/信息图）
- **小图多**：B 类图片可多张（每页 1-5 张），生成快、容错率高
- **总量控制**：一份 10 页演示文稿，建议 AI 生图总量 8-15 张（A 类 3-5 + B 类 5-10）

### 5.2 各场景的 Slides 触发条件 [SLIDES]

#### 页面级标注

| Slides 页面类型 | 推荐标注 | 优先级 |
|---------------|---------|--------|
| 封面 (L01) | `[visual: cover]` | 高 |
| 章节分隔 (L03) | `[visual: section-divider]` | 中 |
| 技术架构/系统分层 | `[visual: arch-infographic]` | 高 |
| 流程/步骤 | `[visual: flow-infographic]` | 高 |
| 对比/优劣势 | `[visual: comparison]` | 中 |
| 时间线/路线图 | `[visual: timeline]` | 中 |
| 数据/指标页 | `[visual: data-bg]`（仅氛围背景） | 低 |
| 概念介绍页 | `[visual: illustration]` | 中 |
| 能力/特性页 | `[visual: icon]` | 低（CSS 图标够用时不标注） |
| 结束页 (L04/L05) | `[visual: ending]` | 中 |
| 要点列表 (L06) | 不标注 | — |
| 表格 (L12) | 不标注 | — |
| 案例/故事页 | 不标注 | — |

#### 元素级标注

| Slides 页面类型 | 推荐元素标注 | 说明 |
|---------------|-----------|------|
| 能力/特性卡片页 | `[card-bg: 1-3]` | 精选 1-3 张卡片用 AI 背景，其余 CSS 纯色 |
| 痛点/挑战页 | `[card-bg: 3]` | 三个痛点卡片各用不同背景 |
| 案例展示页 | `[card-bg: 2]` + `[decor: corner-tr]` | 精选 2 个案例卡片背景 + 角落装饰 |
| CTA/收尾页 | `[section-bg]` + `[decor: corner-bl]` | 区块氛围 + 装饰元素 |
| 流程/步骤页 | `[decor: corner-br]` | 主图已有，加角落装饰增加精致感 |
| 数据/指标页 | `[decor: side-left]` | 主图已有，侧面装饰增加层次 |

**使用原则**：
- 元素级标注不与页面级标注冲突，可同时存在
- `[visual: none]` 的页面**仍然可以**有元素级标注（如 `[visual: none] [section-bg] [decor: corner-tr]`）
- 元素级标注总数建议 3-8 个/份（太多会增加生成时间和成本）

### 5.3 图片与布局的搭配关系 [SLIDES]

#### 页面级图片

| 场景 | 推荐搭配布局（layout-catalog.md） | 图片位置 | 图占比建议 |
|------|-------------------------------|---------|-----------|
| 封面氛围图 | L01 cover | 全屏背景 | > 80% |
| 章节过渡图 | L03 section-divider | 页面一侧装饰 | > 40% |
| 概念配图 | L07 two-column | 左文右图 / 左图右文 | > 40% |
| 主题化图标 | L08 three-column / L06 bullets | 卡片顶部图标 | > 20%（图标体） |
| 流程可视化 | L17 flow-diagram / L22 process-steps | 替代纯文字流程 | > 50% |
| 架构可视化 | L21 arch-diagram / L20 mindmap | 替代纯文字层级 | > 50% |
| 对比可视化 | L24 comparison / L25 pros-cons | 替代纯文字对比 | > 40% |
| 时间线可视化 | L18 timeline / L19 roadmap | 替代纯文字列表 | > 40% |

**图占比规则**：AI 生图不应仅作为页面装饰——图占页面面积的比例（"图占比"）应达到推荐值。低于推荐值时，考虑：①改用 CSS 图形替代（不需要 AI 生图）；②扩大图片区域（选图片占大比例的布局）；③取消该页的 AI 生图标注改为 `[visual: none]`。

#### 元素级图片

| 场景 | CSS 用法 | 说明 |
|------|---------|------|
| 卡片背景 `[card-bg]` | `background-image: url(...); background-size: cover;` | 叠加半透明层后放文字 |
| 角落装饰 `[decor: corner-*]` | `position: absolute; opacity: 0.3;` | 指定角落定位，低透明度 |
| 侧面装饰 `[decor: side-*]` | `position: absolute; width: 20%;` | 纵向裁剪，侧面放置 |
| 区块背景 `[section-bg]` | `background-image: url(...); background-size: cover;` | 全页/区块背景 + 半透明叠加层 |

**相邻卡片交替规则**：当 `[card-bg: 3]` 时，3 张卡片不应使用完全相同的背景处理方式。建议：
- 第 1 张：AI 生成背景
- 第 2 张：CSS 纯色/渐变（视觉呼吸）
- 第 3 张：AI 生成背景（与第 1 张细节不同）

具体交替方式在 prompt 构造阶段实现。

#### 图片嵌入强制规则（内容页）

AI 生图在内容页中必须满足以下全部条件，否则视为 CSS 降级候选：

| 规则 | 要求 | 原因 |
|------|------|------|
| `opacity` | 必须 ≥ 0.7（禁止低于 0.5） | 低于 0.5 的"装饰图"实际不可见，浪费生图预算 |
| 图片面积 | 占内容区 ≥ 40% | 图不是装饰，是内容的一部分 |
| `object-fit` | 使用 `cover` 完整展示，不裁切不拉伸 | 保持 AI 生图构图完整性 |
| 底部过渡 | 卡片/面板内图片底部加 `::after` 渐变（transparent → bg-color） | 柔和连接文字区，避免生硬割裂 |
| 透明度降级 | 禁止用低透明度模拟"融入背景"效果 | 如需融入，换 CSS 背景色而非降透明度 |

**反面示例（错误）**：
```css
background-image: url(...); opacity: 0.15; /* 看不见的"装饰" */
background-size: 100% 100%; /* 拉伸变形 */
```

**正面示例（正确）**：
```css
.card-image { width: 100%; height: 55%; object-fit: cover; }
.card-image::after {
  content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 40%;
  background: linear-gradient(transparent, var(--surface));
}
```

### 5.4 生图脚本调用规范 [SLIDES]

> **独立性**：本插件**自带**生图脚本 `${CLAUDE_SKILL_DIR}/scripts/generate-image.mjs`（Node 18+ 内置 fetch，零外部依赖），**优先用内置**。仅当未设置 `ANTHROPIC_AUTH_TOKEN`/`ANTHROPIC_BASE_URL` 且机器上有兄弟插件 pagecraft 时，才回退到 pagecraft 的 generate.py。两者 CLI 接口完全兼容（prompt 位置参数 + `-o`/`-m`/`-s`/`-n`/`--timeout`，退出码 0/1/2）。命令 `/html-gen-images` 会自动探测并设 `$GEN_CMD`。

**内置（推荐）**：
```bash
node "${CLAUDE_SKILL_DIR}/scripts/generate-image.mjs" \
  "prompt 内容" \
  -o <deck-path>/export/<name>-live/assets/<filename>.png \
  -s 1024x1024 \
  -m gpt-image-2
```

**pagecraft 回退**（`$GEN_CMD` 由 `/html-gen-images` 解析自 `~/.ppt-generator.json` 的 `pagecraft_path` 或 `PAGECRAFT_PATH` 环境变量）：
```bash
$GEN_CMD \
  "prompt 内容" \
  -o <deck-path>/export/<name>-live/assets/<filename>.png \
  -s 1024x1024 \
  -m gpt-image-2
```

**参数**：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `prompt` | 图片生成 prompt（位置参数） | 必填 |
| `-o` | 输出路径 | `/workspace/tmp/` |
| `-s` | 尺寸 | `1024x1024` |
| `-m` | 模型名 | `gpt-image-2` |
| `-n` | 生成数量 | `1` |
| `--timeout` | 超时秒数 | `1800` |

**环境变量**（必须已配置）：
- `ANTHROPIC_AUTH_TOKEN`
- `ANTHROPIC_BASE_URL`

**命名规范**：`<用途>-<序号>.png`（如 `cover-01.png`、`flow-02.png`）

**目录规则**：所有生成的图片保存到 `export/<name>-live/assets/` 目录，HTML 通过 `../assets/<filename>.png` 相对路径引用。

### 5.5 PPT 画布尺寸与图片清晰度 [SLIDES]

- HTML 画布默认：1440×900px（tokens.css 中 `--deck-width` / `--deck-height`）
- **1024px 图片放满宽会被拉伸 ~1.4 倍**，可能模糊
- **封面/全幅图**：优先使用较大尺寸（1792×1024 或 1536×1024）
- **内容区配图**：1024px 通常够用（实际显示尺寸小于全宽）
- **图标**：1024×1024 完全够用（显示尺寸 48-64px）
