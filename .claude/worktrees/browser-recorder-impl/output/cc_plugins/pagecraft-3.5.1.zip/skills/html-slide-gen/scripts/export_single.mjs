#!/usr/bin/env node
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { extractDeckManifest, extractDeckNotes } from './_deck-manifest.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function parseArgs() {
  const args = {};
  const a = process.argv.slice(2);
  for (let i = 0; i < a.length; i += 2) {
    const k = a[i].replace(/^--/, '');
    args[k] = a[i + 1];
  }
  if (!args.deck) { console.error('Usage: export_single.mjs --deck <deck_dir> --out <output.html>'); process.exit(1); }
  if (!args.out) { console.error('Usage: export_single.mjs --deck <deck_dir> --out <output.html>'); process.exit(1); }
  return args;
}

function safeEval(expr) { return new Function('return (' + expr + ')')(); }

function extractDataScripts(html) {
  // DECK_MANIFEST / DECK_NOTES extracted via shared robust helper (bracket-depth scan),
  // not the fragile flat `\[[\s\S]*?\]` regex — see scripts/_deck-manifest.mjs (audit L2).
  let manifest = extractDeckManifest(html) || [];
  // Fallback: 多文件 iframe 架构的 index.html 没有 window.DECK_MANIFEST，
  // 而是用 <iframe data-src="slides/xx.html" data-title="...">。解析这些生成 manifest，
  // 否则所有 starter-deck 都会导出 0 slides。
  if (!manifest.length) {
    const iframeRe = /<iframe[^>]+data-src=["'](slides\/[^"']+)["'](?:[^>]*data-title=["']([^"']*)["'])?/gi;
    let m;
    while ((m = iframeRe.exec(html)) !== null) {
      manifest.push({ file: m[1], label: m[2] || '' });
    }
  }
  const notes = extractDeckNotes(html) || {};
  const width = parseInt(html.match(/window\.DECK_WIDTH\s*=\s*(\d+)/)?.[1]) || 1920;
  const height = parseInt(html.match(/window\.DECK_HEIGHT\s*=\s*(\d+)/)?.[1]) || 1080;
  return { manifest, notes, width, height };
}

async function extractRuntimeJs(indexHtml, deckPath) {
  const srcMatch = indexHtml.match(/<script\s+src=["']index-runtime\.js["'][^>]*><\/script>/);
  if (srcMatch) {
    return await fs.readFile(path.join(deckPath, 'index-runtime.js'), 'utf8');
  }
  const blocks = [...indexHtml.matchAll(/<script>([\s\S]*?)<\/script>/g)];
  for (const m of blocks) {
    if (m[1].includes('function show(') || m[1].includes('function fit(')) return m[1];
  }
  throw new Error('Could not find runtime JS in index.html');
}

function getShellPrefix(html) {
  const idx = html.indexOf('<script');
  if (idx === -1) throw new Error('No <script> found in index.html');
  return html.substring(0, idx);
}

const MIME_MAP = {
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.avif': 'image/avif',
};

async function processSlide(html, tokensCss, deckPath) {
  if (html.includes('</script>')) {
    throw new Error('Slide contains </script> which breaks single-file embedding');
  }
  html = html.replace(
    /<link[^>]+href=["']\.\.\/shared\/tokens\.css["'][^>]*\/?>/gi,
    '<style>' + tokensCss + '</style>'
  );
  const imgRegex = /src=(["'])(\.\.\/assets\/[^"']+)\1/gi;
  let match;
  while ((match = imgRegex.exec(html)) !== null) {
    const quote = match[1];
    const relPath = match[2];
    const absPath = path.resolve(deckPath, 'slides', relPath);
    try {
      const buf = await fs.readFile(absPath);
      const ext = path.extname(relPath).toLowerCase();
      const mime = MIME_MAP[ext] || 'application/octet-stream';
      const dataUri = 'data:' + mime + ';base64,' + buf.toString('base64');
      html = html.replace(match[0], 'src=' + quote + dataUri + quote);
    } catch (e) {
      console.warn('  Warning: could not read image ' + absPath + ': ' + e.message);
    }
  }
  return html;
}

async function main() {
  const { deck: deckArg, out: outArg } = parseArgs();
  const deckPath = path.resolve(deckArg);
  const outPath = path.resolve(outArg);

  await fs.access(path.join(deckPath, 'index.html'));
  await fs.access(path.join(deckPath, 'slides'));

  console.log('Reading index.html...');
  const indexHtml = await fs.readFile(path.join(deckPath, 'index.html'), 'utf8');
  const { manifest, notes, width, height } = extractDataScripts(indexHtml);
  console.log('  ' + manifest.length + ' slides, ' + width + 'x' + height);

  console.log('Reading runtime JS...');
  const runtimeJs = await extractRuntimeJs(indexHtml, deckPath);
  console.log('  ' + runtimeJs.length + ' bytes');

  console.log('Reading tokens.css...');
  const tokensCss = await fs.readFile(path.join(deckPath, 'shared', 'tokens.css'), 'utf8');

  // ── CTA 占位橙硬阻断门（B4/C1，2026-06-26）──
  // 实战 v42：switch-theme 漏跑 → tokens.css 残留占位橙 #f97316 仍被导出。
  // post-process 的 strict validate 本应拦（CTA_PLACEHOLDER_LEAK 是 ERROR），
  // 但生成会话可能无视 exit code 继续 export。本门在导出最后一道防线硬拒。
  if (/--hi-strong\s*:\s*#f97316\b/i.test(tokensCss)) {
    console.error('\n❌ 导出中止：tokens.css 的 --hi-strong 仍是占位橙 #f97316（CTA 未注入）。');
    console.error('   这通常说明 4.1 Step C 的 switch-theme 漏跑。请先执行：');
    console.error(`   node scripts/switch-theme.mjs --deck "${deckPath}" --scheme <方案名> [--palette palette.json]`);
    console.error('   每个 scheme 已预置协调 CTA，换色后占位橙会被替换。');
    console.error('   （可用 node scripts/validate.mjs --deck "' + deckPath + '" --check cta-placeholder 复核）');
    process.exit(1);
  }

  // ── 流程完整性硬阻断门（v50/v52，2026-06-26）──
  // 实战 v50/v52：生成会话绕过 switch-theme + post-process，自创 tokens.css/HTML 结构，
  // 产物全面崩坏（200+ DIV_BARE_TEXT、emoji、缺 runtime）。这类 deck 即使导出也是废品。
  // 指纹：tokens.css 无 semantic-tokens 层（未跑 switch-theme）或过小（手写自创）。
  if (!/semantic-tokens/.test(tokensCss)) {
    console.error('\n❌ 导出中止：tokens.css 缺 semantic-tokens 层（switch-theme 未执行）。');
    console.error('   这说明颜色系统是手写自创而非标准库内 scheme，产物会全面崩坏（v50/v52 实证）。');
    console.error('   标准流程：cp 模板 tokens.css → switch-theme 换色。请执行：');
    console.error(`   node scripts/switch-theme.mjs --deck "${deckPath}" --scheme <方案名>`);
    console.error('   （可用 node scripts/validate.mjs --deck "' + deckPath + '" --check process-integrity 复核）');
    process.exit(1);
  }
  if (tokensCss.length < 8000) {
    console.error(`\n❌ 导出中止：tokens.css 仅 ${tokensCss.length} 字节（标准换色后 ≥18000）。`);
    console.error('   疑似手写自创、未从模板 cp + 换色。请走标准 4.1 流程。');
    process.exit(1);
  }

  const slideHtmls = [];
  for (let i = 0; i < manifest.length; i++) {
    const item = manifest[i];
    const slidePath = path.join(deckPath, item.file);
    console.log('Processing slide ' + (i + 1) + '/' + manifest.length + ': ' + item.file);
    let slideHtml = await fs.readFile(slidePath, 'utf8');
    slideHtml = await processSlide(slideHtml, tokensCss, deckPath);
    slideHtmls.push(slideHtml);
  }

  const shellPrefix = getShellPrefix(indexHtml);
  const labels = manifest.map(m => m.label || '');
  const origFiles = manifest.map(m => m.file);

  const slideDataTags = slideHtmls.map((html, i) =>
    '<script type="text/html" id="sd-' + i + '">' + html + '</script>'
  ).join('\n');

  const bootstrap = `<script>
(function(){
  var els=document.querySelectorAll('script[type="text/html"][id^="sd-"]');
  var htmls=[];els.forEach(function(el){htmls.push(el.textContent)});
  var urls=htmls.map(function(h){return URL.createObjectURL(new Blob([h],{type:'text/html'}))});
  var labels=${JSON.stringify(labels)};
  var origFiles=${JSON.stringify(origFiles)};
  var notes=${JSON.stringify(notes)};
  window.DECK_MANIFEST=urls.map(function(u,i){return{file:u,label:labels[i]}});
  window.DECK_NOTES={};
  Object.keys(notes).forEach(function(k){var idx=origFiles.indexOf(k);if(idx>=0)window.DECK_NOTES[urls[idx]]=notes[k]});
  window.DECK_WIDTH=${width};
  window.DECK_HEIGHT=${height};
  // Replace iframe data-src with blob URLs so they load from inlined content
  var iframes=document.querySelectorAll('#stage iframe');
  iframes.forEach(function(f,i){if(urls[i]){f.dataset.src=urls[i];f.removeAttribute('src')}});
  els.forEach(function(el){el.remove()});
})();
</script>`;

  const singleHtml = shellPrefix + slideDataTags + '\n' + bootstrap + '\n<script>' + runtimeJs + '</script>\n</body></html>';

  await fs.mkdir(path.dirname(outPath), { recursive: true });
  await fs.writeFile(outPath, singleHtml, 'utf8');
  const stats = await fs.stat(outPath);
  console.log('Exported: ' + outPath + ' (' + (stats.size / 1024).toFixed(1) + ' KB, ' + slideHtmls.length + ' slides)');
}

main().catch(e => { console.error(e); process.exit(1); });
