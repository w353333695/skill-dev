# keynote-formal — Slide Role Catalog

> **模板气质**：庄重主题演讲（年度大会 / CEO keynote 调性）——近黑底 `#171717` + 庄重金 `#d4af37` 单色强调（不堆多彩），极大字 serif（Noto Serif SC）叙事、大留白克制；装饰语言 = 金线 `.gold-rule`、章节序号 `.kf-mark`、叙事弧节点 `.arc-step`。
> **默认 color-scheme**：`炭黑金`（庄重金 #d4af37 / #e5c687，近黑底 #171717）
> **适用文稿类型**：启发/共鸣（叙事）｜受众=全员/大会｜内容形态=大字+故事+情感｜调性=庄重有分量、叙事感染力。公司年度大会 CEO 主题演讲、全员 keynote、十周年/司庆叙事演讲、品牌信念发布、毕业/开学典礼致辞。
> **叙事结构**：Cover(信念预告) → **Belief(信念宣言·Why)** → **NarrativeBeat(挣扎)** → **PullQuote(情感高潮)** → **NarrativeBeat(转折)** → ImageHero(新的理解) → **NarrativeBeat(成长)** → Milestone(十年·一数字) → **CallToAction(行动号召)** → Thanks(金句回响)
> **叙事骨架**：黄金圈/英雄之旅（信念 Why → 挣扎故事 → 转折点 → 新的理解 → 行动号召），**非 SCQA、非 dir-key 逐点递进**——有情感曲线。
> **明/暗说明**：全 deck 暗底 `#171717`（庄重金是 dark-native）。正文 `.lede/.dim/.beat-body` 用 `--brand-text-dim #a3a3a3`（5.94:1）、页脚/eyebrow 用 `--brand-text-faint #737373`（3.95:1），均过 WCAG AA。标题与金句用近白 `--text-1 #f5f5f5`，金色 `.kf-accent` 仅用于强调句（不滥用）。

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 | 替换键 |
|------|---------|------|---------|--------|
| 01 | `cover` | 主题演讲式封面（主题+演讲人+大会名+日期） | `.kf-cover`（金线封顶版心）, `.convocation`, h1, `.lede`, speaker block | `convocation`, `headline`, `headline_accent`, `subtitle`, `speaker_block`, `footer_text` |
| 02 | `belief_statement` | 信念宣言（黄金圈 · Why · 极大字+极简） | **`.belief-statement`**（eyebrow+极大字 belief-text+金线）, `.arc-row` 叙事弧节点 | `belief_text`, `footer_text` |
| 03 | `narrative_beat` | 叙事节拍 · 挣扎（大字金句+留白+山峰攀登者意象） | **`.narrative-beat`**（左列文本+右列剪影 SVG）, `.beat-headline`, `.gold-rule` | `beat_label`, `beat_headline`, `beat_body`, `footer_text` |
| 04 | `pull_quote` | 情感高潮大引语（居中超大字+巨型开引号） | **`.pull-quote`**（quote-mark+blockquote+金线+attr） | `quote_text`, `quote_attr`, `footer_text` |
| 05 | `narrative_beat` | 叙事节拍 · 转折（一扇打开的门意象） | **`.narrative-beat`**, `.beat-headline` | `beat_label`, `beat_headline`, `beat_body`, `footer_text` |
| 06 | `image_hero` | 新的理解 · 章节式全幅金光（L26） | `.kf-hero`（金光地平线+上升光柱+底部叠层）, hero headline（渐变金句） | `hero_label`, `hero_headline`, `footer_text` |
| 07 | `narrative_beat` | 叙事节拍 · 成长（年轮同心圆意象） | **`.narrative-beat`**, `.beat-headline` | `beat_label`, `beat_headline`, `beat_body`, `footer_text` |
| 08 | `milestone` | 十年 · 一个数字叙事（非 KPI 墙） | `.milestone`（大数字+金线+一句话）, 成长弧条（10 年金色条） | `ms_label`, `ms_num`, `ms_body`, `growth_bars`, `growth_caption`, `footer_text` |
| 09 | `call_to_action` | 行动号召（号召+演讲式签名，非通用 CTA 卡） | **`.call-to-action`**（kicker+金线+headline+sub+签名） | `cta_kicker`, `cta_headline`, `cta_sub`, `cta_sign`, `cta_sign_meta`, `footer_text` |
| 10 | `thanks` | 金句回响 + 大会署名（非人员卡） | 金句 headline（渐变金）+ 金线 + 大会署名带 | `thanks_headline`, `thanks_body`, `thanks_convocation`, `thanks_date`, `footer_text` |

> **板式库说明**：02 / 03-05-07 / 04 / 09 是叙事演讲的身份证组件（belief-statement / narrative-beat / pull-quote / call-to-action）。06 用 L26 image-hero、08 用 milestone 单数字叙事。叙事演讲**不需要** KPI 墙/对比表/甘特图等咨询/复盘/工程版式——若内容确实需要数据，用单数字 `.milestone`（一数字讲一故事），不要堆指标。`narrative_beat` 角色在 03/05/07 三页复用（同一组件不同意象 + 不同章节序号 i./ii./iii./iv.），是英雄之旅多节拍的载体。

## data-replace 替换键总表

| 键 | 出现页 | 含义 | 示例值 |
|----|--------|------|--------|
| `convocation` | 01, 10 | 大会名 / 场合名 | 2026 拓见科技 · 年度大会 |
| `headline` / `headline_accent` | 01 | 封面主标题 / 金色强调句 | 我们的十年，/ 始于一个信念 |
| `subtitle` | 01 | 演讲副题/主题说明 | 一场关于坚守、挣扎与重新出发的回顾 |
| `speaker_block` | 01 | 主讲人 + 时间地点（结构化） | 林望舒 · 创始人/CEO / 2026.06.18 · 上海 |
| `belief_text` | 02 | 一句话信念（Why） | 技术**应当让人更自由**，而非更繁忙。 |
| `beat_label` | 03,05,07 | 章节序号 + 节拍名 | 第一章 · 最初的挣扎 |
| `beat_headline` | 03,05,07 | 节拍大字金句 | 前三年，我们差点**活不下来**。 |
| `beat_body` | 03,05,07 | 节拍故事正文（叙事性，非要点） | 2016 年，三个人挤在民治的合租房里写代码…… |
| `quote_text` | 04 | 情感高潮引言 | 真正让我们活下来的，是第一个**愿意付费的用户**。 |
| `quote_attr` | 04 | 引言出处/情境标注 | —— 2017 · 第一笔 380 元的订单 |
| `hero_label` / `hero_headline` | 06 | 章节式页标签 / 新理解的标题 | 第三章 · 新的理解 / 我们做的不是工具，是把"准备"还给认真的人。 |
| `ms_label` / `ms_num` / `ms_body` | 08 | 十年指标标签 / 大数字 / 一句话 | 十年·一个数字 / 1,200,000 位 / 认真准备过一次会议的人。 |
| `growth_bars` / `growth_caption` | 08 | 年度成长条（10 条）/ 弧线说明 | （10 根逐年高度条）/ 慢，但每年都在长。 |
| `cta_kicker` / `cta_headline` / `cta_sub` | 09 | 号召 kicker / 号召金句 / 号召补充 | The Call·下一个十年 / 下一个十年，**和我们**，把认真做成一种**本能**。/ 这件事没有终点，只有同行的人。 |
| `cta_sign` / `cta_sign_meta` | 09 | 演讲式签名 / 签名职衔 | —— 林望舒 / 拓见科技 · 创始人/CEO |
| `thanks_headline` / `thanks_body` | 10 | 收束金句 / 收束补充 | **谢谢，**还在路上的**我们**。/ 下一个十年，由今天在场的每一位写下。 |
| `thanks_convocation` / `thanks_date` | 10 | 致谢大会署名 / 日期地点 | 2026 拓见科技 · 年度大会 / 2026.06.18 · Shanghai |
| `footer_text` | 全页 | 页脚品牌/篇名 | 拓见科技 · TÜOJIΛN |

## Style Transfer — T2 页面继承规则

### 空间密度对齐
- body padding: `120px 165px`（大留白是庄重感的来源，**不要**收紧到咨询式的 80px）
- 暗底 `#171717`（全 deck 统一）

### 装饰模式继承
- **金线** `.gold-rule`（双线印刷感，宽度 120px）是全 deck 的统一装饰——封面/信念/引语/号召/致谢都用它做分割，**不要**换成 `.divider-accent`（那是咨询的强调条）
- **章节序号** `.kf-mark`（serif 斜体 i./ii./iii./iv.）做叙事节拍的章节符
- **叙事弧节点** `.arc-row` + `.arc-step`（信念→挣扎→转折→理解→号召 5 节点）可放信念页/数据页底部标"我们走到哪里"
- 标题金色强调一律用 `.kf-accent`（serif 斜体金色），**不要**用 inline `background:var(--grad);-webkit-background-clip:text` 满屏渐变（那是 product-launch 的戏剧感，庄重演讲只在 hero/thanks 用渐变金句）

### 组件类名统一
- 信念宣言：`.belief-statement`（不用裸 `.center`）
- 叙事节拍：`.narrative-beat`（左列 `.tpl-keynote-beat-text` + 右列 `.tpl-keynote-beat-figure`）
- 情感引语：`.pull-quote`（不用 `.blockquote`）
- 行动号召：`.call-to-action`（不用 `.cta-btn` / 通用 CTA 卡）
- 十年数据：`.milestone`（单数字叙事，**不用** `.kpi-card` / `.grid.g4` KPI 墙）
- 全幅章节页：`.kf-hero`（L26 image-hero）

### 灰色文字可读性（必读）
- 全 deck 暗底，正文灰用 `--brand-text-dim #a3a3a3`（5.94:1）、footer/eyebrow 用 `--brand-text-faint #737373`（3.95:1）。**不要**硬编码浅灰 hex。
- 新增含正文/说明文字的页，沿用 `.lede`/`.dim`/`.beat-body` class。

### 节拍意象（inline SVG）规则
- 节拍页右侧意象均为**金色描边 + 金色淡填**的 inline SVG（山峰/门/年轮），无外部图依赖，适配 PPTX 导出。
- 新增节拍意象时：保持 `viewBox="0 0 400 400"`、`stroke="var(--accent)"`、`fill="rgba(212,175,55,.0X)"`、底部金线基座 + 右下章节符（serif 斜体拉丁词）的统一语言。
- SVG 内可加 `<animate>` 做极克制的心跳/呼吸（庄重感，非花哨）。
- ⚠️ SVG 末尾 `svg{overflow:visible}` 已在 tokens.css 兜底，避免描边/光晕被 viewBox 裁切（motion-system §9）。

### 动效表达（庄重叙事 · 情感差异化）
本 deck 在 tokens.css `.tpl-keynote-formal` overlay 段内置了 **deck-private 庄重动效库 `anim-kf-*`**（9 种），按庄重演讲的情感曲线为不同节点配差异化动效，避免 10 页雷同的 fade/rise。全部庄重克制（慢 0.85-1.3s、缓、不弹跳），用 `ease-prod/expr/entry`。命名带 `anim-` 前缀 → **自动落入全局 `[class*="anim-"]` 的 reduced-motion / print 兜底**（§2.5），无需单独写 fallback。与 `.anim-dN` 阶梯延迟组合：`class="anim-kf-focus-in anim-d3"`。

| 动效类 | 情感 / 用于 | 渲染 |
|--------|------------|------|
| `.anim-kf-curtain` | 揭幕 · 封面 h1 / 致谢 | clip-path 自上而下揭开 |
| `.anim-kf-rise-emphasis` | 缓重上浮 · 信念/节拍/hero 金句 | 大幅 translateY(64px) + 极轻 scale + 慢 |
| `.anim-kf-glow-pulse` | 信念金光呼吸 · belief 强调句（无限循环） | text-shadow 金色脉动 4.5s |
| `.anim-kf-focus-in` | 聚焦显形 · pull-quote 情感高潮 | blur(22px)→0 + opacity |
| `.anim-kf-light-beam` | 光柱点亮 · hero 光柱 / 节拍意象 | clip-path 自下而上揭开 |
| `.anim-kf-counter-emphasis` | 数字加重 · milestone 大数字 | scale(.88)→回弹→1，分量感 |
| `.anim-kf-ascend` | 升腾 · call-to-action 标题 | translateY(48px) 上浮渐显 |
| `.anim-kf-soft-bloom` | 柔和绽放 · 致谢金句余韵 | scale(.96)+blur(10px) 现形 |
| `.anim-kf-rule-grow` | 金线生长 · gold-rule 装饰 | scaleX 从中心向两端（设 origin:center） |

**各页动效映射**：01 curtain+rule-grow｜02 rise-emphasis+glow-pulse+rule-grow｜03/05/07 rise-emphasis(标题)+light-beam(意象)｜04 focus-in｜06 light-beam(光柱)+rise-emphasis(标题)｜08 counter-emphasis+stagger(成长条)｜09 ascend+rise-emphasis+rule-grow｜10 soft-bloom+rule-grow。

> **新增/换内容时的动效选用**：节拍页标题一律 `rise-emphasis`、意象 `light-beam`；情感性金句（引语/信念）用 `focus-in`/`glow-pulse`；号召性标题用 `ascend`；收束金句用 `soft-bloom`；金线一律 `rule-grow`。**不要**引入 product-launch 的 glitch/confetti/neon/3D 翻转等戏剧动效——破坏庄重基调。

### 禁止引入的视觉元素（反换皮）
| 禁止 | 原因 |
|------|------|
| KPI 网格 / `.grid.g4` 指标墙 | 叙事演讲不堆指标；用单数字 `.milestone` |
| 2×2 矩阵 / MECE 树 | 咨询框架，破坏叙事弧 |
| 甘特图 / 对比表 / RAG 卡 | 工程/复盘/咨询版式，非演讲体裁 |
| 多彩强调（绿/橙/紫混用） | 庄重感靠单色（金）+ 留白，多彩破坏庄重 |
| dir-key 逐点列表 + 键盘提示 | 那是极简逐点递进；keynote 是叙事弧 |
| presenter 工具壳（S 键磁吸卡/逐字稿） | 那是演讲者工具；keynote 是视觉叙事模板 |
| 通用 `.cta-btn` 按钮 / 4 联系小卡片网格尾页 | 用 `.call-to-action`（号召+签名）+ 致谢金句回响 |
| product-launch 渐变满铺 / glitch / confetti | 那是产品发布戏剧感；keynote 是主题演讲叙事感 |

## Adapt 规则（改内容时的边界）

| 想改 | 怎么改 | 不要碰 |
|------|--------|--------|
| 换演讲主题/故事 | 改 `slides/*.html` 的 `data-replace` 内容；节拍意象 SVG 可按新故事换（山峰→航船→灯塔…保持金描边语言） | 不要改 `.tpl-keynote-formal` overlay 的版式结构 |
| 加/减节拍页 | 复制 `narrative_beat` 页，换 `.beat-no`（i./ii./…）、意象 SVG、章节序号；同步 `index.html` iframe 列表 + 全页 `data-total` + `slide-number` data-current | 不要超过 ~12 页（叙事演讲宜精不宜多） |
| 换配色 | `node scripts/switch-theme.mjs --deck templates/starter-decks/keynote-formal --scheme <单色庄重 scheme>` | 不要切到高饱和多彩 scheme（破坏庄重质感） |
| 换成真实摄影意象 | 把 `.tpl-keynote-beat-figure` 内 `<svg>` 换成 `<img>`（遵守 editable-pptx 约束，配 `../assets/` 相对路径） | 不要破坏 `.tpl-keynote-beat-figure` 容器尺寸 |
| 缩短叙事弧（如 7 页 keynote） | 保留 cover + belief + 1-2 个 beat + pull-quote + cta + thanks 的骨架；删 milestone/mid-beat | 不要删 belief（Why）和 cta（号召）——这是黄金圈首尾 |

## 一致性自检（改完必过）

- [ ] `:root` 顶层 = 2（motion + 主），`--brand-primary:` 恰好 1 处
- [ ] 全页暗底 `#171717`，正文灰过 WCAG AA
- [ ] CJK 大标题换行靠 CSS（keep-all+balance+overflow-wrap），**无 `<br>`**
- [ ] CJK 标题 `max-width` 用 **em 不用 ch**（ch 是拉丁"0"宽≈0.5em，Nch 只够 N/2 个 CJK 字，会让标题拆成过多行/溢出）
- [ ] 金色 `.kf-accent` 仅用于强调句，未滥用为正文色
- [ ] 10 页 `data-current`/`data-total` 与 `index.html` iframe 顺序一致
- [ ] 每页内容不溢出安全区（垂直 120~960，水平 165~1755），不与 `.deck-footer`（bottom:34px）重叠
- [ ] 每页至少 1 个 `anim-kf-*` 庄重动效（差异化，非全 deck 雷同 fade）；reduced-motion 下 `anim-kf-*` 自动降级为无动效且可见
- [ ] SVG 末尾 `svg{overflow:visible}` 兜底在；节拍意象无 viewBox 裁切
- [ ] `switch-theme` 切 scheme 后 bg/accent 真联动（`--brand-*` 链路未断）
