# government-formal-red — Slide Role Catalog

> **模板气质**：政务汇报风（政府红 + 政府蓝 + 金色点缀）—— 白底 + 红蓝双色顶饰、深蓝章节全屏、红色序号块、印章徽标、庄重克制、结论先行。
> **默认 color-scheme**：`government-red`（政府红 `#8B0000` + 政府蓝 `#003366` + 金 `#DAA520`，白底）。
> **设计依据**：pagecraft `government_red/design_spec.md`（红蓝双色顶饰、深蓝章节全屏、金色点缀、红色序号块、印章）。
> **switch-theme**：已接入。`shared/tokens.css` §2 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 为换肤入口；所有 `gov-*` 组件与语义 token 均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 一键切换。推荐配套：`government-red`（默认）、`government-blue`（政府蓝）、`consulting-navy`。
> **适用文稿类型**：政务汇报 / 工作总结 / 政策宣讲 / 项目推介 / 招商引资（典型：营商环境、专项工作、年度总结、改革推进）。
> **叙事结构（16 页，按出现顺序）**：cover → toc → executive-summary(工作综述) → situation(政策背景) → complication(存在问题) → question(工作主线) → chapter-divider(工作部署) → framework(总体思路) → recommendation(重点举措) → data-deepdive(数据深潜) → comparison-table(对标先进) → process-flow(实施路径) → quarterly-review(阶段成效) → risks-mitigation(风险防控) → next-steps(下一步举措) → thanks(结束)。
>
> 结构四段：01–03「开篇」（封面 + 目录 + 工作综述）；04–06「政策背景与问题」（背景 + 短板 + 工作主线）；07「章节切换」；08–12「部署」（总体思路 + 重点举措 + 数据深潜 + 对标 + 实施路径）；13–15「治理」（阶段成效 + 风险防控 + 下一步）；16「收束」。**特色角色页**：01（红头文件版心封面）、07（深蓝章节全屏）、13（RAG 阶段成效）。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 封面：单位全称 + 红头文件式标题 + 副标题 + 印章 + 汇报信息 | `.gov-redbar`, `.gov-doc-title`(含 `.gradient-text` accent), `.gov-goldline`, `.gov-seal`, `.gov-cover-meta` |
| 02 | `toc` | 目录：6 章双栏列表 + 红色序号块 | `.gov-redbar`, `.gov-pagehead`, `.gov-chapnum`(序号块), `border-bottom` 分隔 |
| 03 | `executive-summary` | 工作综述：一句话核心结论 + 3 工作重点 | `.card.card-amber`(结论条), `.grid.g3`, `.card.card-accent`, `.pill-accent`, `.h3.mono`(指标) |
| 04 | `situation` | 政策依据与基本盘：**政策依据引用块**（带文号）+ 4 基本盘数据卡 + 形势判断 | `.gov-policy-cite`(文号+引文+要求), `.grid.g4`, `.gov-fact`, `.card-soft`(判断) |
| 05 | `executive-achievements` | **主要成效**（成效先行，政务惯例）：标志性成效大数字（排名跃升 20→8）+ 4 成效亮点卡 | `.card-accent`(排名from→to), `.gov-rank-trend`, `.card-soft`×4(亮点) |
| 06 | `problems-checklist` | **存在问题（三清单式）**：问题清单/影响清单/整改清单 三栏 | `.gov-checklist`(三栏 .warn/.good), `.gov-cl-num`, `.card-soft`(攻坚方向) |
| 07 | `chapter-divider` | 章节切换：深蓝渐变全屏 + 半透明大号章节号 + 白字标题 | `.gov-chapter-bg`(data-bignum), `.h1`(108px 白), 金线分隔 |
| 08 | `framework` | **总体要求与目标**：三化工作原则（市场化/法治化/国际化）+ 主要目标指标条（约束性/预期性）| `.gov-principle`(三原则卡), `.gov-goal-bar`(约束性+预期性指标) |
| 09 | `recommendation` | **重点任务分解**：4 任务卡（牵头单位/目标值/完成节点）+ 部署原则 | `.grid.g4`, `.card-accent`, `.card-amber`(攻坚), `.pill-accent` |
| 10 | `data-deepdive` | 数据深潜：左大数字 + mini 柱图（改革前/当前/全国） + 右 3 举措拆解卡 | `.card-accent`, `.h1.mono`(大数字), 内联 bar, `.card-amber`(举措) |
| 11 | `comparison-table` | 对标表：6 维度硬边表，年底目标列金色高亮 | `.gov-table`(硬边, 表头红底白字, `.col-hero` 金列), `caption` |
| 12 | `process-flow` | 实施路径：3 阶段时间轴 + 里程碑 + 图例 | 时间轴(绝对定位线 + 圆点节点), `.card`/`.card-amber`(阶段卡), `.eyebrow`(阶段标签) |
| 13 | `quarterly-review` | 阶段成效（特色页）：4 季度卡 + RAG 状态点 + 完成率进度条 + 需协调事项 | `.gov-quarter`, `.gov-rag-dot`(达标/关注), `.gov-q-progress`/`.gov-q-bar`, `.gov-q-pct`, `.card-soft`(协调) |
| 14 | `risks-mitigation` | 风险防控：3 风险卡，每卡风险/应对双栏对照 | `.card`(风险行), `.gov-risk`(`.gov-risk-risk`/`.gov-risk-mit`), 风险等级 pill |
| 15 | `next-steps` | **责任分工与保障**：责任分工矩阵表（任务/牵头/配合/时限/考核 5列）+ 组织保障四宫格 + 审议清单 | `.gov-resp-table`(5列分工表), `.gov-safeguard`(四保障宫格), `.pill-accent`(审议) |
| 16 | `thanks` | 结束：大字 + 金线 + 副标题 + 4 联系/信息卡 | `.gov-redbar`/`.gov-redbar-bottom`, `.h1`(128px), `.gov-goldline`, `.card-soft`×4 |

---

## 角色详情

### 01 — `cover`（红头文件版心）
- **源文件**：`slides/01-cover.html`
- **可替换键**：`doc_code`, `classification`, `unit`, `headline`(含 `.gradient-text` accent 词 `headline_accent`), `subtitle`, `kpi_1~3_value/label`, `meta_unit`, `meta_date`, `seal`, `footer_source`
- **不可改动**：`.gov-redbar` 顶饰、`.gov-doc-title` 居中粗体、`.gov-seal` 印章圆形描边、body `justify-content:flex-start`
- **内容适配规则**：
  - `headline` 含 `<span class="gradient-text">` 渐变 accent 词，替换时保留 span
  - 顶部 `doc_code`（文件编号）+ `classification`（密级/保管说明）
  - `unit` 单位全称 + `headline` 主标题 + `subtitle` 副标题（汇报事项）
  - `seal` 印章内含换行文字（机构简称）

### 02 — `toc`
- **可替换键**：`chap_num`, `kicker`, `title`, `item_1~6_num/title/desc`, `footer_source`（6 组 ×3 + 3）
- **不可改动**：`.gov-chapnum` 红色序号块、`.grid.g2` 双栏、每项 `border-bottom` 分隔
- **内容适配规则**：议程项 4~6 个，标题控制在 12 字内；章节序号用 `.gov-chapnum`

### 03 — `executive-summary`（工作综述）
- **可替换键**：`kicker`, `title`, `core_conclusion`(含 4 个内嵌 `<b>`/`<span>` 高亮), `pillars_label`, `pillar_1~3_tag/metric/title/body`, `footer_source`
- **不可改动**：`.card.card-amber` 结论条字号(30px)、3 重点卡等宽(`.grid.g3`)、指标用 `.h3.mono`
- **内容适配规则**：
  - `core_conclusion` 是工作综述的核心，一句话含总体进展 + 量化成效
  - 内嵌高亮词用 `<span style="color:var(--accent-3)">` 或 `<b>`，替换时保留标记
  - 3 个工作重点（政务服务/企业减负/市场活力，对应后续措施）

### 04 — `situation`（政策背景）
- **可替换键**：`kicker`, `title`, `subtitle`, `stat_1~4_value/label/delta`, `insight_tag`, `insight_body`, `footer_source`
- **不可改动**：4 列等宽(`.grid.g4`)、`.gov-num` 84px Bold、delta 用 `.gov-delta.up` 绿
- **内容适配规则**：4 个基本盘数据卡，`stat_*_value` 控制在 6 字内，delta 含方向箭头（政务指标多为上升用绿）

### 05 — `complication`（存在问题）
- **可替换键**：`kicker`, `title`, `prob_1~3_tag/impact/title/body/evidence`, `footer_source`
- **不可改动**：3 列 `.card-amber`、影响数字用 `.h2.mono` 红色(`var(--bad)`)
- **内容适配规则**：3 个短板卡，`prob_*_impact` 是量化影响（红），`evidence` 是来源脚注

### 06 — `question`（工作主线 / MECE）
- **可替换键**：`kicker`, `title`, `subtitle`, `root_question`, `leaf_1~3_tag/title/body`, `footer_source`
- **不可改动**：`.gov-tree-node.root` 红底白字、inline SVG 三叉连接线坐标、3 leaf 等宽
- **内容适配规则**：1 root + 3 leaf（市场化/法治化/国际化"三化"，MECE 互斥穷尽），leaf 的 body 用"→ 举措"回链

### 07 — `chapter-divider`（深蓝章节全屏 · 特色页）
- **可替换键**：`chapter_num`, `chapter_title`, `chapter_sub`, `footer_source`
- **不可改动**：`.gov-chapter-bg` 深蓝渐变全屏 + `data-bignum` 半透明大号章节号、`.h1` 108px 白字、金线分隔
- **内容适配规则**：用于切换到"工作部署"大章节，`chapter_title` 用 `<wbr>` 折行（不写 `<br>`）

### 08 — `framework`（总体思路 / 2×2 矩阵）
- **可替换键**：`kicker`, `title`, `axis_x`, `axis_y`, `q1~4_label/title/desc`, `legend_title`, `legend_1~4_tag/body`, `legend_note`, `footer_source`
- **不可改动**：`.gov-matrix` 2×2 grid、`.gov-cell.hero`（Q1 高亮用 `rgba(brand-primary,.06)`）、`.gov-axis-y` 竖排
- **内容适配规则**：4 象限按"高获得感高力度(Q1,hero)→高获得感待发力(Q2)→低获得感高力度(Q3)→低获得感待发力(Q4)"，右侧图例（保/攻/提/试）

### 09 — `recommendation`（重点举措）
- **可替换键**：`kicker`, `title`, `opt_a~d_tag/lead/title/body/k1_label/k1/k2_label/k2`, `opt_b_tag/subtype`, `reason_tag`, `reason_body`, `footer_source`（4 举措 ×8）
- **不可改动**：重点举措(默认二)用 `.card-amber` + 顶部居中 amber pill(★)、K2 完成时点红绿着色
- **内容适配规则**：
  - 4 项举措等宽，`opt_b_*` 整组 amber 高亮为重点
  - 每项含 lead(牵头单位) + title + body + 2 个 KPI(目标值 + 完成时点)
  - 若重点项变更，需把 `.card-amber` 迁移到对应卡

### 10 — `data-deepdive`
- **可替换键**：`kicker`, `title`, `big_label`, `big_value`, `big_unit`, `bar_now/goal/top_label` + `_value`, `break_1~3_tag/impact/title/body`, `footer_source`
- **不可改动**：左 `.card-accent` 大数字(120px) + 内联 3 行 bar、右 3 `.card-amber` 举措拆解卡
- **内容适配规则**：bar 宽度需手动按值调整 `width:%`（当前 100/17/40 对应改革前/当前/全国平均）

### 11 — `comparison-table`（对标先进）
- **可替换键**：`kicker`, `title`, `col_dim/now/plan/top/gap`（5 列头）, `row_1~6_dim/now/plan/top/gap`（6 行 ×5）, `caption`, `footer_source`
- **不可改动**：`.gov-table` 硬边、表头红底白字、`.col-hero` 列金色高亮、gap 列绿色
- **内容适配规则**：6 维度行，`col-hero` 默认指第 3 列（年底目标），如改对比列需迁移 class

### 12 — `process-flow`（实施路径）
- **可替换键**：`kicker`, `title`, `wave_1~3_tag/title/body/ms`, `legend_done/cur/plan`, `footer_source`
- **不可改动**：时间轴主线(绝对定位, 实线=已完成 `var(--accent)` / 虚线背景=计划)、3 阶段等宽、圆点节点颜色对应状态
- **内容适配规则**：3 阶段（动员部署→集中攻坚→验收提升），每阶段 `wave_*_ms` 是可验证里程碑

### 13 — `quarterly-review`（阶段成效 · 特色页）
- **可替换键**：`kicker`, `title`, `subtitle`, `q1~4_label/rag/title/pct/status/event`, `action_tag`, `action_body`, `footer_source`（4 季度 ×5）
- **不可改动**：`.gov-quarter` 4 卡等宽、`.gov-rag-dot` 状态点、`.gov-q-progress`/`.gov-q-bar` 进度条颜色随 RAG(good/warn/bad)
- **内容适配规则**：
  - `q*_rag` 值为"达标/关注/预警"，需与 `.gov-rag-dot` class(good/warn/bad) + `.gov-q-bar` class 同步
  - `q*_pct` 数字 + `.gov-q-bar` width:% 需一致
  - `subtitle` 含内嵌 RAG 图例 dot，保留 `<span class="gov-rag-dot good">`

### 14 — `risks-mitigation`（风险防控）
- **可替换键**：`kicker`, `title`, `risk_1~3_level/title/prob/risk_head/risk_body/mit_head/mit_body`, `footer_source`（3 风险 ×7）
- **不可改动**：`.gov-risk` 双栏（左红 `.gov-risk-risk` / 右绿 `.gov-risk-mit`）、风险等级 pill 颜色(高=红/中=金)
- **内容适配规则**：3 风险卡，每卡"风险描述 + 应对措施"对照，`prob` 格式"概率 X% · 影响 Y"

### 15 — `next-steps`（下一步举措）
- **可替换键**：`kicker`, `title`, `subtitle`, `step_1~4_num/title/body/owner/due`, `decision_tag`, `decision_body`, `footer_source`（4 步 ×5）
- **不可改动**：`.gov-pipeline` 4 步等宽、`.gov-step.hero`（首步金顶边 + 浅底）、owner 用 `.gov-step-owner` 加粗
- **内容适配规则**：4 步行动，每步 owner(牵头单位) + due(完成时点) + 可考核成果

### 16 — `thanks`（结束）
- **可替换键**：`kicker`, `headline`, `subtitle`, `contact_1~4_role/name/email`, `footer_unit`, `footer_date`
- **不可改动**：`.h1` 128px、`.gov-goldline` 金线、4 信息 `.card-soft` 等宽、`.gov-redbar`/`.gov-redbar-bottom` 顶底饰条
- **内容适配规则**：4 个联系/信息卡（牵头单位/政务服务/企业诉求/信息查询）

---

## 组件层（`shared/tokens.css` `.tpl-government-formal-red` overlay）

| class | 作用 |
|------|------|
| `.gov-redbar` | 红蓝双色顶饰条（6px 渐变，贯穿整页） |
| `.gov-redbar-bottom` | 底部政府红装饰线（4px） |
| `.gov-chapnum` | 红色正方形章节序号块（54×54 白字） |
| `.gov-goldline` | 金色装饰细线 |
| `.gov-doc-title` | 红头文件式标题（居中粗体 + 下方红线） |
| `.gov-seal` | 印章感圆形徽标（描边 + 内文） |
| `.gov-chapter-bg` | 章节全屏深蓝渐变背景 + `data-bignum` 半透明大号章号 |
| `.gov-pagehead` | 页头：kicker + h2.title |
| `.gov-fact` / `.gov-num` / `.gov-label` / `.gov-delta` | 大数字卡（值/标签/增减） |
| `.gov-matrix` / `.gov-cell.hero` / `.gov-quadrant-*` / `.gov-axis-x` / `.gov-axis-y` | 2×2 工作矩阵 |
| `.gov-pipeline` / `.gov-step` / `.gov-step.hero` | 4-step 行动管道 |
| `.gov-table` / `.col-hero` | 硬边对比表（目标列金色高亮） |
| `.gov-quarter` / `.gov-rag-dot` / `.gov-q-progress` / `.gov-q-bar` / `.gov-q-pct` | 阶段成效卡（RAG + 进度） |
| `.gov-risk` / `.gov-risk-risk` / `.gov-risk-mit` | 风险/应对双栏 |
| `.gov-tree-node.root` / `.leaf` | MECE 工作主线树节点 |
| `.gov-cover-meta` | 封面单位元数据 |
| `.card-amber` / `.card-accent` / `.card-soft` | 强调卡（通用层定义） |

> 所有 `gov-*` 组件颜色均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 切换时自动联动。推荐配套方案：`government-red`（默认）、`government-blue`（政府蓝）、`consulting-navy`（深蓝）。
