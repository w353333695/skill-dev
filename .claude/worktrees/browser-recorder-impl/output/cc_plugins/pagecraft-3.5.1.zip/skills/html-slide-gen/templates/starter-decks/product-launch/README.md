# product-launch

12-slide consumer product announcement deck: hero cover, "introducing" moment, an SVG product-hero page with annotated callouts, three feature slides, a specs KPI grid, a competitor comparison table, how-it-works, a 2×2 use-case bento, pricing tiers, and a closing testimonial + pre-order CTA.

A fully dark deck (deep navy `#0a0a12` + warm orange→peach gradient accent) — the orange gradient is dark-native, so every page shares the dark background. The light/dark rhythm lives in **card texture**, not background: `.dark` pages use translucent glass cards (`rgba(255,255,255,.06)` + backdrop blur), regular pages use solid surface cards (`#1a1a28`). Body text is tuned for the dark canvas (`--brand-text-dim #9a9aa6`, 7.1:1 contrast).

**Use when:** launching a product, announcing a v2, internal all-hands reveals, press kit decks.
**Feel:** Apple-event-on-a-budget — confident, tactile, uncluttered.

## Layout library

| # | Slide | Layout pattern |
|---|-------|----------------|
| 01 | Cover | hero-shot + gradient headline |
| 02 | Introducing | centered big-statement (186px) |
| 03 | Product Hero | SVG device illustration + numbered callout pins |
| 04 | Sound | 3 feature cards |
| 05 | Fit | 3 cards, dark glass |
| 06 | Intelligence | 2 feature cards |
| 07 | Specs | 4-cell KPI grid, gradient big-numbers |
| 08 | Comparison | vs-competitor table, Halo column highlighted |
| 09 | How it works | 3 numbered steps |
| 10 | Use Cases | 2×2 bento, inline SVG icons |
| 11 | Pricing | 3 tiers, `.pro` highlighted |
| 12 | Ship | testimonial + gradient CTA |
