# testing-safety-alert — Slide Role Catalog

> **模板气质**：红/琥珀高警示风、白底高对比、45° 红黑对角警告条纹、L1/L2/L3 严重度色卡、删除线 / 高亮 / 警示框 / policy-YAML 代码块 / 风险矩阵 / 防护管线 / 事故时间线
> **默认 color-scheme**：red-alert（红 #e0314a / 琥珀 #d97706 / 绿 #067647）
> **switch-theme**：通过主 `:root` 的 `--brand-*` 字面色 + RGB 通道联动换肤；本 deck 颜色当前以 `--ts-*` 链路 `var(--brand-*)` 维护
> **适用文稿类型**：安全警示、风险通报、合规宣导、事故复盘、红队测试、AI 上线前评估、policy-as-code
> **叙事结构（16 页 · 双章节）**：cover → agenda → hero-quote → **§1 风险分级**(section → risk-levels → risk-matrix → hero-stat) → **§2 防护架构**(section → policy-code → process-flow → incident-chart → timeline → compare) → checklist → cta → thanks

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 警示封面 | .ts-stripe, .ts-chrome(.ts-alert-tag), .ts-kicker, .ts-h1(.strike + .red), .ts-sub, .ts-alert-box |
| 02 | `agenda` | 目录 / 议程 | .ts-agenda > .ts-agenda-item > .num(mono 红) + .ttl + .desc，分隔线 |
| 03 | `hero-quote` | 核心论点金句 | .ts-quote(.q 巨字号 keep-all+balance + ::before 红色 “), .attr |
| 04 | `section-divider` | §1 章节分隔页 | .ts-stripe, .ts-chrome(.ts-alert-tag.amber), .ts-h1(173px .red), .ts-sub(38px) |
| 05 | `risk-level-cards` | 三级风险卡片 | .ts-h2, .ts-grid-3 > .ts-card(border-top: L1 绿 / L2 琥珀 / L3 红), .ts-alert-box.amber |
| 06 | `risk-matrix` | 风险矩阵 2×2 | inline SVG(4 着色象限 + 轴标 + 事故圆点), .ts-matrix |
| 07 | `hero-stat` | 大数字冲击页 | .ts-stat(.ts-stat-num 240px + .ts-stat-unit + .ts-stat-body), 配 SVG sparkline |
| 08 | `section-divider` | §2 章节分隔页 | 同 04 角色，内容为「用代码管规则」 |
| 09 | `policy-code` | Policy-as-Code YAML | .ts-kicker, .ts-h2(.ts-highlight-red), pre.ts-codebox(暗底: .cm/.kw/.st/.bad) |
| 10 | `process-flow` | 防护管线 | inline SVG(agent → policy runtime → block/action → audit log 5 节点), .ts-flow |
| 11 | `incident-chart` | 事故趋势图 | inline SVG 堆叠柱状图(绿/琥珀/红), legend |
| 12 | `timeline` | 事故时间线 | inline SVG(主轴 + T0…T+90s 刻度 + 上下事件卡), .ts-timeline |
| 13 | `compare-table` | do/don't 对比表 | table.ts-compare(th.bad/th.good + td.bad/td.good, ✕/✓ glyph) |
| 14 | `checklist` | 上线前检查清单 | .ts-checklist > .ts-check(.ok) > .box(✓/!) + .txt |
| 15 | `cta` | 行动号召 | .ts-grid-3 > .ts-card(.lbl 1·2·3 + h4 + p), .ts-alert-box.green |
| 16 | `thanks` | 结束致谢 | .ts-h1(186px .red 分隔点), .ts-sub(32px), .ts-alert-tag.amber |

> **SVG 插图页**（5 个）：`risk-matrix` / `hero-stat`(sparkline) / `process-flow` / `incident-chart` / `timeline`。均为手写 inline `<svg>`，颜色用 deck 警报色硬编码 hex（`#e0314a / #d97706 / #067647 / #14141a / #4a4955 / #8a8892`），与 `incident-chart` 现有惯例一致。

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`kicker`, `heading`, `subtitle`, `alert-heading`, `alert-body`, `footer-left`
- **不可改动**：.ts-stripe / .ts-stripe-b 警示条纹结构、.ts-chrome(.ts-alert-tag) 顶部条、.ts-h1 内 .strike(删除线) 和 .red span 包装、.ts-alert-box 警示框结构
- **内容适配规则**：
  - `heading` 应含 `<span class="strike">` 删除线 + `<span class="red">` 红色强调，形成对比句式
  - `subtitle` 为一段式说明，40-80 字
  - `alert-box` 为红色警示框，含标题 + 正文
  - `footer-left` 格式 `"AI SAFETY BRIEF · AUTHOR · YYYY.MM"`

### `agenda`
- **源文件**：`slides/02-agenda.html`
- **可替换键**：`heading`, `subtitle`, `agenda-1-title` ~ `agenda-5-title`, `agenda-1-desc` ~ `agenda-5-desc`, `footer-left`
- **不可改动**：.ts-agenda 列表结构、.ts-agenda-item 的 .num(mono 红编号，固定 `01`~`05`)/.ttl/.desc 三段、项间分隔线（border-top/bottom）
- **内容适配规则**：
  - 5 项为宜（与 `01`~`05` 编号强绑定）；如需增减，同步改 .num 文本
  - `.ttl` 可含 `<span class="red">` 关键词高亮；`.desc` 右对齐一句话补充
  - 每项 title ≤ 12 字，desc ≤ 24 字

### `hero-quote`
- **源文件**：`slides/03-hero-quote.html`
- **可替换键**：`kicker`, `quote`, `attribution`, `footer-left`
- **不可改动**：.ts-quote 结构、::before 巨型红色引号 “(CSS 伪元素)、.q 的 word-break:keep-all + overflow-wrap:break-word + text-wrap:balance（换行交给 CSS，**不写 `<br>`**）、.attr 结构
- **内容适配规则**：
  - `quote` 是核心论点，可含 `.red`/`.strike` span；**禁止在内容里写 `<br>`**（CSS 已接管换行）
  - `attribution` 含 `.who`(粗体署名) + 一句论证
  - 整页只用一个 hero 元素，留白要足

### `section-divider`（04 / 08 复用）
- **源文件**：`slides/04-section-risk.html`、`slides/08-section-guards.html`
- **可替换键**：`kicker`, `heading`, `subtitle`, `footer-left`
- **不可改动**：.ts-stripe / .ts-stripe-b 警示条纹、.ts-h1 font-size:173px 和 inline style、.ts-sub font-size:38px、.ts-alert-tag.amber 章节标签、`margin:auto 0` 垂直居中包裹
- **内容适配规则**：
  - `kicker` 为章节编号，格式 `"Chapter One"` / `"Chapter Two"`
  - `heading` 含 `<span class="red">` 红色关键词
  - `subtitle` 为两行说明
  - 两页用同一角色、不同内容，分别开启「风险分级」与「防护架构」两章

### `risk-level-cards`
- **源文件**：`slides/05-risk-levels.html`
- **可替换键**：`heading`, `card1-title`, `card1-body`, `card2-title`, `card2-body`, `card3-title`, `card3-body`, `alert-heading`, `alert-body`, `footer-left`
- **不可改动**：.ts-grid-3 三列网格、.ts-card border-top 颜色(L1=绿 / L2=琥珀 / L3=红)、.lbl 标签文本(L1·绿色 / L2·琥珀 / L3·红色 与颜色强绑定)、.ts-alert-box.amber
- **内容适配规则**：
  - 三张卡片保持 L1→L2→L3 从左到右，严重度递增
  - 每张卡 `cardN-body` 含示例 + `<b style="color:var(--ts-{color})">策略：XXX</b>`
  - .lbl 不可改：与卡片 border-top 颜色强绑定

### `risk-matrix`
- **源文件**：`slides/06-risk-matrix.html`
- **可替换键**：`heading`, `subtitle`, `footer-left`（SVG 内象限文字/事故圆点为演示数据，可改但不改结构）
- **不可改动**：inline SVG 整体结构（4 象限矩形 + 坐标轴 + 十字虚线 + 圆点）、象限配色（左下绿 / 右下琥珀 / 左上琥珀 / 右上红）、右上红色 callout pill
- **内容适配规则**：
  - 横轴=发生概率、纵轴=严重度，**不可换轴**
  - 圆点颜色对应事故等级（红=L3 / 琥珀=L2 / 绿=L1），圆内数字=该等级数量
  - 改数据时同步改圆点 cx/cy（落点要符合该等级所在象限）和圆内数字
  - 右上红象限 = 高严重×高概率 = 硬卡区，必须保留 callout

### `hero-stat`
- **源文件**：`slides/07-hero-stat.html`
- **可替换键**：`kicker`, `stat-num`, `stat-unit`, `stat-label`, `stat-title`, `stat-desc`, `footer-left`
- **不可改动**：.ts-stat 横向布局、.ts-stat-num(mono 240px 红)、SVG sparkline 结构（上升曲线 + 末端点 + 轴刻度）
- **内容适配规则**：
  - `stat-num` 为单个冲击数字（可含 `$` / `%`），`stat-unit` 为单位（如 `/ 90s`）
  - `stat-title` 含 `.red` 关键词，`stat-desc` 一段论证
  - **这是「冲击数字页」不是 KPI 卡**——只放一个数字，不放多指标网格（本 deck 禁止 .kpi/.metric/.delta）
  - sparkline 末端点必须在曲线终点，颜色用 `#e0314a`

### `policy-code`
- **源文件**：`slides/09-policy-code.html`
- **可替换键**：`kicker`, `heading`, `footer-left`
- **不可改动**：pre.ts-codebox 整个代码块(暗底 #141418、左边框红色 6px、语法着色 span: .cm/.kw/.st/.bad)、.ts-highlight-red pill
- **内容适配规则**：
  - `heading` 含 `<span class="ts-highlight-red">` 红色高亮关键词
  - **代码块为模板结构性组件**：policy-yaml 语法着色 span 保持原样；高危操作用 `<span class="bad">` 标注

### `process-flow`
- **源文件**：`slides/10-process-flow.html`
- **可替换键**：`heading`, `subtitle`, `footer-left`（SVG 内节点文字为演示内容，可改但不改结构）
- **不可改动**：inline SVG 管线结构（5 节点 + 箭头 + marker defs）、节点 ② policy runtime 的红框强调 + L1/L2/L3 三色 chip、节点 ③ HARD BLOCK 红虚线框、底部红强调线
- **内容适配规则**：
  - 节点顺序固定：agent → policy runtime → block → action → audit log（**不可调序**）
  - 三色 chip（绿 L1 放 / 琥珀 L2 复 / 红 L3 卡）颜色不可改
  - 强调「policy runtime 是所有请求必经、不可绕过」——这是本页论点

### `incident-chart`
- **源文件**：`slides/11-incident-chart.html`
- **可替换键**：`heading`, `subtitle`, `footer-left`
- **不可改动**：SVG 整个图表(堆叠柱状图 bars + legend 文字)、.ts-alert-tag.amber 事故标签
- **内容适配规则**：
  - `heading` 含 `<span class="red">` 红色事故数量
  - **SVG 图表为结构性组件**：柱状图数据、legend 分类(L1可恢复 / L2需复核 / L3不可撤销)为演示数据

### `timeline`
- **源文件**：`slides/12-timeline.html`
- **可替换键**：`heading`, `subtitle`, `footer-left`（SVG 内事件卡文字/时间为演示内容，可改但不改结构）
- **不可改动**：inline SVG 时间线结构（主轴 + 5 个 T 刻度 + 上下事件卡 + 虚线连接）、T+90s 的红色 KILL SWITCH 卡（必须红底白字收尾）、底部教训脚注
- **内容适配规则**：
  - 5 个时间刻度固定（T0 / T+22s / T+45s / T+68s / T+90s），可改秒数但保持递增
  - 事件卡颜色对应等级（红=告警/kill / 琥珀=人工介入 / 黑=起点）
  - **必须以 kill switch（红卡）收尾**——这是「为什么要有 kill switch」的视觉论点
  - 改事件时同步改卡内编号/! 标记和虚线 x 坐标（要对齐对应刻度）

### `compare-table`
- **源文件**：`slides/13-compare.html`
- **可替换键**：`heading`, `subtitle`, `row1-bad` ~ `row4-bad`, `row1-good` ~ `row4-good`, `footer-left`
- **不可改动**：table.ts-compare 结构、表头 th.bad(红 ✕ 别这么做) / th.good(绿 ✓ 该这么做) 与配色、td 左边框颜色（红/绿）、✕/✓ glyph
- **内容适配规则**：
  - 左列=反例、右列=正例，**逐行一一对应**同一主题
  - 行数 3-4 为宜；每格一句话，关键操作用 `<b>` 加粗
  - 红绿两列对比要形成「希望它小心」vs「保证它做不到」的张力

### `checklist`
- **源文件**：`slides/14-checklist.html`
- **可替换键**：`heading`, `check-item-1` ~ `check-item-7`, `footer-left`
- **不可改动**：.ts-checklist 列表结构、.ts-check 每项的 .box(✓ 或 !) 和 class(.ok=绿勾 / 无.ok=红叹号)、.ts-alert-tag.green
- **内容适配规则**：
  - `heading` 含 `<span class="red">` 红色数字
  - 每项 check-item 为一段式检查项，25-50 字
  - 勾选项与待办项比例约 4:3

### `cta`
- **源文件**：`slides/15-cta.html`
- **可替换键**：`heading`, `card1-title`, `card1-body`, `card2-title`, `card2-body`, `card3-title`, `card3-body`, `alert-heading`, `alert-body`, `footer-left`
- **不可改动**：.ts-grid-3 三列网格、.lbl 编号(1·/2·/3·)与步骤强绑定、.ts-alert-box.green、.ts-highlight-red
- **内容适配规则**：
  - 三张卡片为行动步骤，.lbl(1·/2·/3·) 不可改
  - `alert-heading` 为核心理念句，`alert-body` 为论证

### `thanks`
- **源文件**：`slides/16-thanks.html`
- **可替换键**：`kicker`, `heading`, `subtitle`, `footer-left`
- **不可改动**：.ts-stripe / .ts-stripe-b 警示条纹、.ts-h1 font-size:186px 和 inline style、.ts-sub font-size:32px、.ts-alert-tag.amber、.red 分隔点
- **内容适配规则**：
  - `kicker` 格式 `"end of brief"`
  - `heading` 含 `<span class="red">·</span>` 红色分隔点
  - `subtitle` 为 CTA 或资源引导句

---

## 匹配决策树

```
用户需求
├─ 需要封面/标题页？
│   └─ cover (01)
├─ 需要目录/议程？
│   └─ agenda (02) — 编号列表 + 分隔线
├─ 需要一句核心论点/金句？
│   └─ hero-quote (03) — 巨字号 pull-quote + 红色 “
├─ 需要章节分隔/过渡页？
│   └─ section-divider (04 / 08) — 173px 标题 + 红色关键词
├─ 需要分级/分类展示多个维度？
│   ├─ 3 个等级，颜色编码，严重度递增？
│   │   └─ risk-level-cards (05) — L1 绿 / L2 琥珀 / L3 红 border-top 卡片
│   ├─ 两个维度交叉定位（严重度×概率 / 影响×成本）？
│   │   └─ risk-matrix (06) — SVG 2×2 矩阵 + 事故圆点
│   └─ 其他数量/无颜色编码 → 不要用这些角色
├─ 需要一个冲击性大数字？
│   └─ hero-stat (07) — 单个 240px 数字 + sparkline（非 KPI 多指标）
├─ 需要展示代码/配置？
│   └─ policy-code (09) — 暗底语法着色 YAML + 红色左边框
├─ 需要展示流程/管线/架构？
│   └─ process-flow (10) — SVG 防护管线（agent→policy→block→action→audit）
├─ 需要展示数据图表/趋势？
│   └─ incident-chart (11) — SVG 堆叠柱状图(绿/琥珀/红三色)
├─ 需要时间线/事件回放？
│   └─ timeline (12) — SVG 主轴 + T 刻度 + 事件卡（以 kill switch 收尾）
├─ 需要正反对比（do/don't / before-after）？
│   └─ compare-table (13) — 红 ✕ / 绿 ✓ 两列表
├─ 需要清单/检查项？
│   └─ checklist (14) — ✓/! 勾选标记 + 7 项检查
├─ 需要行动号召？
│   └─ cta (15) — .lbl 1·2·3 编号卡片 + 绿色警示框
├─ 需要结束页/致谢？
│   └─ thanks (16) — 186px 标题 + 红色分隔点
└─ 以上都不匹配 → 这不是 testing-safety-alert 模板的适用场景
```

---

## Style Transfer — T2 页面继承规则

### 空间密度对齐
- body padding: 对齐 `85px 124px`
- .ts-grid-3 gap: 21px；.ts-checklist gap: 16px；.ts-card padding: 29px 35px；.ts-agenda-item padding: 22px 8px
- 新卡片用 .ts-card（border:1px solid var(--ts-line), border-radius:21px, background:#fff）

### 装饰模式继承
- **全局警示条纹**：所有页面必须保留 .ts-stripe(顶部 45° 红黑对角 19px) 和 .ts-stripe-b(底部 45° 红黑对角 8px, opacity:.6)
- **顶部条**：所有页面必须使用 .ts-chrome > .ts-alert-tag + .ts-page
- **警示标签**：.ts-alert-tag 按严重度选色（默认红色 / .amber / .green），配 ⚠ 或 ✓ 伪元素图标
- **红色高亮**：.ts-h1/.ts-h2 内关键词用 `<span class="red">`；pill 式用 `<span class="ts-highlight-red">`
- **删除线**：对比句式用 `<span class="strike">`，CSS 伪元素生成红色斜线
- **页码**：所有页面统一 `NN / 16`（顶部 .ts-page + 底部 .ts-footer）

### 组件类名统一
- 卡片：`.ts-card`（不可用 .card / .card-accent）
- 三列网格：`.ts-grid-3`
- 警示框：`.ts-alert-box`（+ .amber / .green 变体）
- 红色高亮：`.red`（文字级）/ `.ts-highlight-red`（pill 级）
- 删除线：`.strike`
- 检查清单：`.ts-checklist > .ts-check(.ok) > .box + .txt`
- 代码块：`pre.ts-codebox` + span(.cm / .kw / .st / .bad)
- 目录：`.ts-agenda > .ts-agenda-item > .num + .ttl + .desc`
- 金句：`.ts-quote > .q + .attr`
- 大数字：`.ts-stat > .ts-stat-num + .ts-stat-unit + .ts-stat-body`
- 对比表：`table.ts-compare > th(.bad/.good) + td(.bad/.good)`
- SVG 插图容器：`.ts-matrix` / `.ts-flow` / `.ts-timeline`（仅尺寸居中，图形在 inline SVG 内）
- 页脚：`.ts-footer`

### SVG 插图页规则（risk-matrix / hero-stat / process-flow / incident-chart / timeline）
- **手写 inline `<svg viewBox=... style="width:100%;max-width:Npx">` 直接放 slide `<body>`**，不嵌套 iframe（全 deck 零 iframe 引用 charts/）
- 颜色用硬编码 hex：`#e0314a`(红) / `#d97706`(琥珀) / `#067647`(绿) / `#14141a`(墨) / `#4a4955`(次墨) / `#8a8892`(淡) / `#eaecf3`(网格线)——**禁止引入蓝/紫/青**
- 入场动效用 deck 现有 `.anim-fade` / `.anim-fade-up-soft` / `.anim-bar-grow` + `.anim-dN` 错峰，给 SVG `<g>`/`<rect>`/`<circle>` 加 class
- viewBox 横向构图为主（matrix 1100×560 / flow 1640×470 / timeline 1640×520 / chart 1040×360 / sparkline 含 padding），max-width 1180~1560px
- **【根治规则 A · 静态色块禁用元素级 `opacity`】**：SVG 元素要半透明色块时一律用 `fill-opacity=".10"`，**绝不用元素级 `opacity="..."`**。原因：`.anim-fade` 动画 `opacity` 0→1 且 `fill-mode:both` 会把 `to{opacity:1}` 钉住，覆盖元素级 `opacity` 属性 → 动画结束后色块变全不透明，同色文字（如矩阵象限标签）变不可见。`fill-opacity` 是填充层，不被 `opacity` 动画影响，两者解耦。（静态装饰线/非动画文字 alpha 可用 `opacity`，不受此限。）
- **【根治规则 B · viewBox 内必须留 padding】**：几何（圆点 r、描边 stroke-width、轴标文字）不得贴 viewBox 边界，否则被默认 `overflow:hidden` 裁切（如折线末端圆点/曲线被切）。要么几何内缩留 ≥ `r + stroke-width/2` 的边距，要么给 viewBox 加负原点 padding（例：`viewBox="-16 -16 352 232"` 给原 320×200 各边留 16 单位）。全 deck SVG 另有 `.tpl-testing-safety-alert svg{overflow:visible}` 兜底，避免任何越界被静默裁切。

### 警报色系统
| 严重度 | 主色 CSS 变量 | hex | 使用场景 |
|--------|-------------|-----|---------|
| 红(L3) | `--ts-red` | #e0314a | 不可撤销、硬卡、封面/条纹/警示框(默认)、SVG 高危点 |
| 琥珀(L2) | `--ts-amber` | #d97706 | 半可撤销、需复核、章节标签、SVG 中危点 |
| 绿(L1) | `--ts-green` | #067647 | 可撤销、已通过、行动号召、SVG 低危点 |

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| .card / .card-accent / .card-soft | 用 .ts-card 替代 |
| .gradient-text | 无渐变文字，红色用 .red / .ts-highlight-red |
| .pill / .pill-accent | 用 .ts-highlight-red / .ts-highlight-amber / .ts-highlight-green |
| .section-num 水印 | 用 .ts-kicker 做章节标识 |
| .terminal / 终端风格代码块 | 用 pre.ts-codebox（暗底 + 红色左边框 + 语法着色） |
| .kpi / .metric / .delta | 本 deck 无 KPI 系统；冲击数字用 hero-stat（单数字 + sparkline），趋势用 SVG 图表 |
| 非警报色系 | 只用红/琥珀/绿三色，不引入蓝/紫/青等 accent 色（SVG 内同样） |
