# Style Transfer 通用指南

> T2 页面（从 layout-catalog 通用骨架生成）与 T1 页面（从模板 slide 生成）在同一份 deck 中混用时，必须应用 Style Transfer——从模板 slide 继承 composition 特征。本文档提供通用检查清单，各模板的 `slide-roles.md` 中有模板特定的 Style Transfer 规则。

## 何时应用

当 Phase 4.2 中某页的骨架来源为 T2 时，生成规格文件前必须执行 Style Transfer 检查。

## 通用检查清单（6 维度）

### 1. 空间密度对齐

```
□ body padding 是否对齐模板内容页？（读取 slide-roles.md 的 Style Transfer → 空间密度对齐）
□ grid/stack gap 是否对齐模板？
□ 标题与内容间距(.mt-s/.mt-m/.mt-l)是否对齐模板？
```

### 2. 装饰模式继承

```
□ 模板内容页有章节标识（.section-num / .num-tag / .kicker）？
  → T2 页面也加同样的章节标识结构
□ 模板内容页有分隔线（.divider-accent / .divider）？
  → T2 页面在标题下方加同样的分隔线
□ 模板封面/结束页装饰（.cover-bg / .cover-blob / .hero-shot）？
  → 仅对应类型页（封面/结束）继承，普通内容页不加
```

### 3. 组件类名统一

```
□ 模板用 .card 还是 .card-accent？→ T2 页面对齐选择
□ 模板用 .h2 还是 .title？→ T2 页面对齐
□ 模板用 .pill 还是 .tag？→ T2 页面对齐（如模板两者皆无，T2 也不用）
□ 模板的 .kicker 颜色/字距？→ T2 页面保持一致
```

### 4. 排版层级对齐

```
□ 标题字号/字重/字距是否对齐模板的 .tpl-xxx 覆盖值？
□ 正文颜色是否用模板的 --text-2 / --text-3 映射？
□ 强调色使用方式：渐变文字(.gradient-text) vs 纯色强调(.accent-text) vs pill 标签？
```

### 5. 禁止引入模板不存在的视觉元素

```
□ 检查 T2 页面 HTML 骨架中是否使用了模板禁止的 class：
  - 模板没有 .pill → T2 页面不用 .pill
  - 模板没有 .glass / 玻璃拟态 → T2 页面不用
  - 模板没有 .icon-halo / .dot-cluster → T2 页面不用
  - 模板没有 .slide-top-bar → T2 页面不用
  - 模板没有 .btn-gradient → T2 页面不用
```

**核心原则**：T2 页面可以"少一点模板的味道"，但绝不能"多出模板没有的味道"。

### 6. 暗色/亮色页节奏

```
□ 模板有暗/亮交替节奏（如 product-launch）？
  → T2 页面也遵循交替节奏，body 添加对应 class
□ 模板全局暗色（如 tech-sharing）？
  → T2 页面保持暗色，不出现亮色页
```

## 在 spec 中的体现

T2 规格文件的 `## Style Transfer 注入检查` 段应列出以上检查项的实际结果：

```markdown
## Style Transfer 注入检查
- [x] 空间密度对齐：body padding 118px 165px（对齐 pitch-deck）
- [x] 装饰模式继承：添加 .section-num + .num-tag + .divider-accent
- [x] 组件类名统一：.card（非 .card-accent）
- [x] 排版层级对齐：h2 82px/800wt/-0.03em
- [x] 无模板禁止元素：已确认无 .pill .glass .icon-halo .slide-top-bar
```

## 与 slide-roles.md 的关系

- **本文档**：通用原则和检查清单（适用于所有模板的 T2 页面）
- **slide-roles.md**：模板特定的 Style Transfer 规则（具体的间距值、装饰模式、禁止元素列表）
- **Phase 4.2 执行时**：先读本文档了解通用流程，再从 slide-roles.md 读取模板特定参数
