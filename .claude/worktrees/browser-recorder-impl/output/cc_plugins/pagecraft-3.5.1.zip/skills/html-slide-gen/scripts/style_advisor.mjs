#!/usr/bin/env node
/**
 * style_advisor.mjs — 行业/关键词 → 六色板（含 CTA）+ 视觉推理约束 检索
 *
 * 移植自 SVG 版 style_advisor.py 的 BM25（k1=1.5/b=0.75，纯标准库）。
 * 简化为两域：colors（六色板）+ ui-reasoning（Anti_Patterns / Decision_Rules）。
 *   - Style_Priority 仅作为「建议文本」返回，不自动落地（HTML 模板画不出
 *     Glassmorphism / Liquid Glass 等 SVG 专属风格，渲染 gap）。
 *
 * BM25 对中文查询无效（whitespace 分词切不开中文），故在 BM25 之前加一层
 * 精简的中文行业关键词桥（IT服务→B2B Service 等）——这是 SVG 版没有的增强，
 * 否则中文讲稿（主用例）恒走 fallback。
 *
 * 数据系列 --data-1..6 用 Okabe-Ito 色盲安全 6 色（与 brand 解耦，正是
 * 「不再全 brand 单色循环」的本意）；CTA 来自 colors.csv 的 BM25/关键词匹配。
 *
 * Usage:
 *   node style_advisor.mjs "企业IT服务 方案汇报" --json          # 输出 palette JSON（switch-theme --palette 消费）
 *   node style_advisor.mjs "金融科技 支付" --design-system        # 人类可读（含推理约束）
 *   node style_advisor.mjs "SaaS dashboard" --domain color        # 单域 BM25
 *
 * 输出 JSON 结构（--json，供 switch-theme --palette <file>）:
 *   {
 *     query, industry, industryNotes,
 *     colors: { primary, secondary, cta, ctaRgb, background, text, border },
 *     palette: { "hi-strong", "hi-strong-rgb", "data-1".."data-6" },
 *     reasoning: { stylePriority[], colorMood, decisionRules, antiPatterns }
 *   }
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, 'advisor');
const MAX_RESULTS = 3;

// Okabe-Ito 色盲安全 8 色取 6（数据可视化金标准，刻意与 brand 解耦）
const DATA_SERIES = ['#0072B2', '#E69F00', '#009E73', '#CC79A7', '#56B4E9', '#D55E00'];

// 中文行业关键词 → colors.csv "Product Type" 桥（BM25 看不见中文，这层让主用例可用）
const INDUSTRY_KEYWORDS = [
  [/IT服务|IT管理|运维|系统建设|方案汇报|企业服务|信息化|数字化(?!营销)/, 'B2B Service'],
  [/银行|金融(?!科技)|招行|招商|理财|财富管理/, 'Banking/Traditional Finance'],
  [/金融科技| fintech|支付|加密|区块链|数字货币/, 'Fintech/Crypto'],
  [/电商|商城|零售|购物|旗舰店/, 'E-commerce'],
  [/医疗|健康|医院|诊所|医药|患者/, 'Healthcare App'],
  [/教育|课程|培训|在线学习|网课|教学/, 'Online Course/E-learning'],
  [/政府|公共|政务|机关|事业单位/, 'Government/Public Service'],
  [/物流|配送|快递|仓储|供应链/, 'Logistics/Delivery'],
  [/制造|工业|工厂|产线/, 'Construction/Architecture'],
  [/建筑|地产|房产|楼盘|物业/, 'Real Estate/Property'],
  [/餐饮|食品|餐厅|外卖|美食/, 'Restaurant/Food Service'],
  [/旅游|旅行|酒店|民宿|出行/, 'Travel/Tourism Agency'],
  [/咨询|顾问|企业管理咨询/, 'Consulting Firm'],
  [/数据|分析|看板|dashboard|报表|bi/, 'Analytics Dashboard'],
  [/(?:^|\W)saas|软件|工具|平台化/, 'SaaS (General)'],
  [/\bai\b|智能|大模型|聊天机器人|chatbot|gpt/, 'AI/Chatbot Platform'],
  [/安全|网安|信息安全|攻防|渗透/, 'Cybersecurity Platform'],
  [/游戏|gaming|电竞/, 'Gaming'],
  [/媒体|新闻|资讯|门户/, 'News/Media Platform'],
  [/航空|航空|航班|机票/, 'Airline'],
  [/保险|投保|理赔/, 'Insurance Platform'],
  [/能源|电力|新能源|光伏|储能|esg|可持续/, 'Sustainability/ESG Platform'],
];

// ============ BM25（移植自 style_advisor.py，k1=1.5/b=0.75）============
class BM25 {
  constructor(k1 = 1.5, b = 0.75) {
    this.k1 = k1;
    this.b = b;
    this.corpus = [];
    this.docLengths = [];
    this.avgdl = 0;
    this.idf = {};
    this.docFreqs = {};
    this.N = 0;
  }

  tokenize(text) {
    const cleaned = String(text).toLowerCase().replace(/[^\w\s]/g, ' ');
    return cleaned.split(/\s+/).filter(w => w.length > 2);
  }

  fit(documents) {
    this.corpus = documents.map(d => this.tokenize(d));
    this.N = this.corpus.length;
    if (this.N === 0) return;
    this.docLengths = this.corpus.map(d => d.length);
    this.avgdl = this.docLengths.reduce((a, b) => a + b, 0) / this.N;
    this.docFreqs = {};
    for (const doc of this.corpus) {
      const seen = new Set(doc);
      for (const word of seen) {
        this.docFreqs[word] = (this.docFreqs[word] || 0) + 1;
      }
    }
    for (const [word, freq] of Object.entries(this.docFreqs)) {
      this.idf[word] = Math.log((this.N - freq + 0.5) / (freq + 0.5) + 1);
    }
  }

  score(query) {
    const queryTokens = this.tokenize(query);
    const scores = [];
    for (let idx = 0; idx < this.corpus.length; idx++) {
      let score = 0;
      const doc = this.corpus[idx];
      const docLen = this.docLengths[idx];
      const termFreqs = {};
      for (const word of doc) termFreqs[word] = (termFreqs[word] || 0) + 1;
      for (const token of queryTokens) {
        if (token in this.idf) {
          const tf = termFreqs[token] || 0;
          const idf = this.idf[token];
          const numerator = tf * (this.k1 + 1);
          const denominator = tf + this.k1 * (1 - this.b + this.b * docLen / this.avgdl);
          score += idf * numerator / denominator;
        }
      }
      scores.push([idx, score]);
    }
    return scores.sort((a, b) => b[1] - a[1]);
  }
}

// ============ CSV ============
function loadCsv(filename) {
  const filepath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filepath)) return [];
  const text = fs.readFileSync(filepath, 'utf-8').replace(/^﻿/, '');
  const [headerLine, ...lines] = text.split(/\r?\n/).filter(l => l.length > 0);
  const headers = parseCsvRow(headerLine);
  return lines.map(line => {
    const cols = parseCsvRow(line);
    const row = {};
    headers.forEach((h, i) => { row[h] = cols[i] ?? ''; });
    return row;
  });
}

// 最小 CSV 解析（处理引号内逗号 + 双引号转义），零依赖
function parseCsvRow(line) {
  const out = [];
  let cur = '';
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (inQ) {
      if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (c === '"') { inQ = false; }
      else { cur += c; }
    } else {
      if (c === ',') { out.push(cur); cur = ''; }
      else if (c === '"') { inQ = true; }
      else { cur += c; }
    }
  }
  out.push(cur);
  return out;
}

// ============ colors 域检索 ============
function searchColors(query, maxResults = MAX_RESULTS) {
  const data = loadCsv('colors.csv');
  if (data.length === 0) return [];
  const documents = data.map(r => `${r['Product Type']} ${r['Notes']}`);
  const bm25 = new BM25();
  bm25.fit(documents);
  const ranked = bm25.score(query);

  // 中文关键词桥：BM25 看不见中文，先于 BM25 用关键词命中 Product Type
  const keywordMatch = matchIndustryKeyword(query);
  const results = [];
  if (keywordMatch) {
    const idx = data.findIndex(r => r['Product Type'] === keywordMatch);
    if (idx >= 0) results.push({ row: data[idx], score: 1, via: 'keyword' });
  }
  for (const [idx, score] of ranked) {
    if (results.length >= maxResults) break;
    if (score > 0 && !results.find(r => r.row === data[idx])) {
      results.push({ row: data[idx], score, via: 'bm25' });
    }
  }
  // 兜底：BM25 与关键词都空 → 第一行（SaaS General）
  if (results.length === 0 && data[0]) {
    results.push({ row: data[0], score: 0, via: 'fallback' });
  }
  return results;
}

function matchIndustryKeyword(query) {
  for (const [re, productType] of INDUSTRY_KEYWORDS) {
    if (re.test(query)) return productType;
  }
  return null;
}

// ============ ui-reasoning 域（Anti_Patterns / Decision_Rules）============
function findReasoning(productType) {
  const data = loadCsv('ui-reasoning.csv');
  if (data.length === 0 || !productType) return null;
  const pt = productType.toLowerCase();
  // 精确匹配 UI_Category
  let rule = data.find(r => (r['UI_Category'] || '').toLowerCase() === pt);
  // 包含匹配
  if (!rule) rule = data.find(r => {
    const c = (r['UI_Category'] || '').toLowerCase();
    return c && (c.includes(pt) || pt.includes(c));
  });
  if (!rule) return null;
  const stylePriority = (rule['Style_Priority'] || '').split('+').map(s => s.trim()).filter(Boolean);
  return {
    stylePriority,                                   // 仅建议文本，不自动落地（渲染 gap）
    colorMood: rule['Color_Mood'] || '',
    typographyMood: rule['Typography_Mood'] || '',
    keyEffects: rule['Key_Effects'] || '',
    decisionRules: rule['Decision_Rules'] || '',
    antiPatterns: rule['Anti_Patterns'] || '',        // → brief 约束（重点：禁 AI purple/pink gradients）
    severity: rule['Severity'] || '',
  };
}

// ============ hex → "r,g,b" ============
function hexToRgb(hex) {
  const h = String(hex).replace('#', '').trim();
  const v = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
  if (!/^[0-9a-fA-F]{6}$/.test(v)) return '0,0,0';
  const n = parseInt(v, 16);
  return `${(n >> 16) & 255},${(n >> 8) & 255},${n & 255}`;
}

// ============ 合成 palette（switch-theme --palette 消费）============
function generatePalette(query) {
  const colorResults = searchColors(query, 1);
  const best = colorResults[0];
  const row = best?.row || {};
  const productType = row['Product Type'] || 'SaaS (General)';
  const cta = row['CTA (Hex)'] || '#F97316';

  const reasoning = findReasoning(productType);

  return {
    query,
    industry: productType,
    industryNotes: row['Notes'] || '',
    via: best?.via || 'fallback',
    colors: {
      primary: row['Primary (Hex)'] || '#2563EB',
      secondary: row['Secondary (Hex)'] || '#3B82F6',
      cta,
      ctaRgb: hexToRgb(cta),
      background: row['Background (Hex)'] || '#F8FAFC',
      text: row['Text (Hex)'] || '#1E293B',
      border: row['Border (Hex)'] || '#E2E8F0',
    },
    palette: {
      'hi-strong': cta,
      'hi-strong-rgb': hexToRgb(cta),
      'data-1': DATA_SERIES[0],
      'data-2': DATA_SERIES[1],
      'data-3': DATA_SERIES[2],
      'data-4': DATA_SERIES[3],
      'data-5': DATA_SERIES[4],
      'data-6': DATA_SERIES[5],
    },
    reasoning: reasoning || {
      stylePriority: ['Minimalism', 'Flat Design'],
      colorMood: '', typographyMood: '', keyEffects: '',
      decisionRules: '', antiPatterns: '', severity: '',
    },
  };
}

// ============ CLI ============
function parseArgs(argv) {
  const args = { format: 'ascii' };
  const a = argv.slice(2);
  args.query = [];
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '--json') { args.format = 'json'; continue; }
    if (a[i] === '--design-system') { args.designSystem = true; continue; }
    if (a[i] === '--domain') { args.domain = a[++i]; continue; }
    if (a[i] === '--format') { args.format = a[++i]; continue; }
    if (a[i] === '--max-results' || a[i] === '-n') { args.maxResults = parseInt(a[++i], 10); continue; }
    if (a[i] === '--help' || a[i] === '-h') { args.help = true; continue; }
    if (!a[i].startsWith('--')) args.query.push(a[i]);
  }
  args.query = args.query.join(' ');
  return args;
}

function formatAscii(ds) {
  const W = 78;
  const line = (s) => ('|  ' + s).padEnd(W + 1) + '|';
  const out = ['+' + '-'.repeat(W) + '+'];
  out.push(line(`PALETTE: ${ds.industry}  (via ${ds.via})`));
  if (ds.industryNotes) out.push(line(`  ${ds.industryNotes}`));
  out.push('+' + '-'.repeat(W) + '+');
  out.push(line(`CTA / hi-strong:  ${ds.colors.cta}  (rgb ${ds.colors.ctaRgb})`));
  out.push(line(`Primary:    ${ds.colors.primary}`));
  out.push(line(`Secondary:  ${ds.colors.secondary}`));
  out.push(line(`Background: ${ds.colors.background}   Text: ${ds.colors.text}`));
  out.push(line(`Data series (Okabe-Ito, 色盲安全, 与 brand 解耦):`));
  ds.palette['data-1'] && DATA_SERIES.forEach((c, i) => out.push(line(`  data-${i + 1}: ${c}`)));
  out.push('+' + '-'.repeat(W) + '+');
  const r = ds.reasoning;
  if (r.antiPatterns) {
    out.push(line('AVOID (约束, 进 brief):'));
    out.push(line(`  ${r.antiPatterns.slice(0, 72)}`));
  }
  if (r.decisionRules) out.push(line(`Decision_Rules: ${r.decisionRules.slice(0, 72)}`));
  if (r.stylePriority?.length) out.push(line(`Style_Priority (仅建议, 不自动落地): ${r.stylePriority.join(' + ')}`));
  out.push('+' + '-'.repeat(W) + '+');
  return out.join('\n');
}

function main() {
  const args = parseArgs(process.argv);
  if (args.help || !args.query) {
    console.log(`用法: node style_advisor.mjs "<行业/关键词>" [--json|--design-system] [--domain color] [-n N]
  --json           输出 palette JSON（switch-theme --palette <file> 消费）
  --design-system  人类可读（含推理约束）
  --domain color   单域 BM25（不合成 palette）`);
    process.exit(args.help ? 0 : 1);
  }

  if (args.domain === 'color' && !args.designSystem && args.format === 'ascii') {
    // 单域：返回 colors.csv BM25 top-N
    const results = searchColors(args.query, args.maxResults || 3);
    if (args.format === 'json') {
      console.log(JSON.stringify({ query: args.query, count: results.length, results }, null, 2));
    } else {
      results.forEach((r, i) => {
        console.log(`--- Result ${i + 1} (via ${r.via}, score ${r.score.toFixed(3)}) ---`);
        console.log(`  Product Type: ${r.row['Product Type']}`);
        console.log(`  Primary/Secondary/CTA: ${r.row['Primary (Hex)']} / ${r.row['Secondary (Hex)']} / ${r.row['CTA (Hex)']}`);
        console.log(`  Notes: ${r.row['Notes']}`);
        console.log('');
      });
    }
    return;
  }

  const ds = generatePalette(args.query);
  if (args.format === 'json') {
    console.log(JSON.stringify(ds, null, 2));
  } else {
    console.log(formatAscii(ds));
  }
}

main();
