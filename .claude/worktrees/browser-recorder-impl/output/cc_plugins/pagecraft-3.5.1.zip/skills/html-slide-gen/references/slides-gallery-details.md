# Deck Gallery Details — 23 个模板详情

> 本文件是 `slides-gallery.md` 的详情拆分（H1 减负）。选定模板后**按 `### <deck-name>` 锚点局部读取**（如 `Read slides-gallery-details.md` 后定位 `### pitch-deck`），勿整文件加载。每个 deck 的完整色板/组件模式/适用场景在此。

## 模板详情

### pitch-deck

**路径**: `templates/starter-decks/pitch-deck/` · **角色目录**: `slide-roles.md`
**语言**: en · **页数**: 10
**演示类型**: 说服/促动 · **叙事模型**: What-Why-How

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）:
- Primary: `#3b5bff` · Secondary: `#7a46ff` · Accent: `#d94cff`
- Text: `#0d1130` / `#4a5070` / `#8a90ad`
- Gradient: `135deg #3b5bff → #7a46ff 55% → #d94cff`

**幻灯片结构**:
Cover → Problem(3-card) → Solution(pills) → Product(4-card) → Market(3-metric) → Business Model(3-pricing) → Traction(bar chart) → Team(3-avatar) → Ask(gradient box) → Thanks

**关键组件**: `.cover-bg`(soft gradient bg) · `.cover-blob`(模糊光球) · `.section-num`(220px 超大序号) · `.num-tag`(章节标签) · `.metric`(大数字+标签) · `.traction-bar`(柱状图) · `.ask-box`(渐变 CTA 卡) · `.team-card`(居中头像卡) · `.avatar`(渐变圆形首字母)

**匹配条件**: 融资路演、office hours、state of the company、需要 metric+traction+ask 结构的任何说服场景。

---

### weekly-report

**路径**: `templates/starter-decks/weekly-report/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 14 
**演示类型**: 信息同步 · **叙事模型**: 直线递进（开篇→成果→活动→深潜→健康→向前→收束）

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）:
- Primary: `#2e63eb` · Secondary: `#0ea5b5` · Accent: `#f59e0b`
- Good: `#10b981` · Warn: `#f59e0b` · Bad: `#ef4444`
- Gradient: `120deg #2e63eb → #0ea5b5`

**幻灯片结构**:
Cover(logo+week chip) → Agenda(双栏编号目录) → KPIs(8-grid, color-coded) → Wins(SVG 趋势插图 + 高光大数字) → Shipped(6 items, FEAT/FIX/EXP/INFRA tags) → Velocity(SVG 折线 计划 vs 实际) → Funnel(CSS 渐窄漏斗 5 级) → Metrics(bar chart 深潜) → OKR(进度条 + SVG gauge) → Blockers(3 items, severity) → Decisions(待决策 + 推荐项) → Next Week(5 rows) → Team(roster + 产能条) → Thanks

**关键组件**: `.cover-head`(logo + week chip) · `.kpi`(左侧彩色条, value+delta) · `.kpi.good/.bad/.warn`(状态色) · `.ship-item`(tag + 标题 + 描述 + owner) · `.tag.feat/.fix/.exp/.infra`(分类标签) · `.chart-bars`(柱状图) · `.blocker`(红色左边框) · `.next-row`(grid 双列 owner+task) · `.wr-panel/.wr-tile`(扁平容器) · `.wr-win`(高光大数字) · `.wr-hero-art`(SVG 插图) · `.wr-chart`(SVG 折线) · `.wr-funnel/.wr-stage`(转化漏斗) · `.wr-progress/.wr-gauge`(OKR 进度+仪表) · `.wr-decision`(待决策) · `.wr-team-row/.wr-capacity`(团队产能)

**匹配条件**: 团队周报、squad review、skip-level update、跨团队 shipped this week、任何需要 KPI+shipped+blockers 结构的定期汇报。

---

### tech-sharing

**路径**: `templates/starter-decks/tech-sharing/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 18 
**演示类型**: 传授/赋能 · **叙事模型**: 金字塔（论点 → 论据 → 结论）

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）:
- Primary: `#7ee787`(绿) · Secondary: `#79c0ff`(蓝) · Accent: `#ff7b72`(红)
- Background: `#0d1117` · Surface: `#161b22` · Code bg: `#010409`
- Gradient: `120deg #7ee787 → #79c0ff 60% → #d2a8ff`

**幻灯片结构**:
Cover(speaker info) → Agenda(5 rows with time) → Context(3-card comparison) → Deep Dive 1(text+terminal) → Deep Dive 2(text+card) → Code Example(full terminal) → Takeaways(3-card) → Q&A

**关键组件**: `.terminal`(macOS chrome 代码块, syntax-highlighted) · `.kw/.fn/.str/.cmt/.num`(语法颜色类) · `.agenda-row`(编号+标题+时间) · `.speaker`(头像+姓名+时长) · `.card-accent`(顶部绿色条) · 背景双层 radial gradient ambient

**匹配条件**: 技术分享会、brown-bag talk、conference submission、任何需要 code block + 代码高亮的深度技术演讲。

---

### product-launch

**路径**: `templates/starter-decks/product-launch/` · **角色目录**: `slide-roles.md`
**语言**: en · **页数**: 12 
**演示类型**: 说服/促动 · **叙事模型**: BAB（Before→After→Bridge）

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）:
- Primary: `#ff5a36` · Secondary: `#ff8c5a` · Accent: `#ffb36b`
- Dark slides: `#0a0a12`
- Gradient: `120deg #ff5a36 → #ff8c5a 60% → #ffb36b`

**幻灯片结构**:
Cover(dark, hero-shot blob) → Introducing(center, 大字) → Feature 1(3-card) → Feature 2(dark, 3-card) → Feature 3(2-card) → How it Works(3-step) → Pricing(3-tier) → Testimonial+CTA(dark, serif quote + pre-order)

**关键组件**: `.hero-shot`(圆形渐变+内嵌文字) · `.slide.dark`(暗色变体, backdrop-filter glass) · `.feature-card`(icon 渐变圆+标题+描述) · `.step`(序号圆+内容) · `.price-card`/`.price-card.pro`(暗色放大推荐档) · `.cta-btn`(渐变圆角按钮) · `.testimonial`(Playfair serif 大引文)

**匹配条件**: 产品发布、v2 发布会、all-hands reveal、press kit、任何需要 dark/light 交替营造戏剧感的产品展示。

---


### course-module

**路径**: `templates/starter-decks/course-module/` · **角色目录**: `slide-roles.md`
**语言**: en · **页数**: 11 
**演示类型**: 传授/赋能 · **叙事模型**: 金字塔

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: Off-white paper · Playfair Display · Green `#3a7d44` + Terracotta `#c4735b` accent pair

**匹配条件**: 在线课程模块、讲座讲义、onboarding 培训、workshop 单元。左侧 sidebar 列出学习目标并随进度勾选。

---

### dir-key-nav-minimal

**路径**: `templates/starter-decks/dir-key-nav-minimal/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 13 
**演示类型**: 启发/共鸣 · **叙事模型**: 逐点递进

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: 8 张独立背景(indigo / cream / crimson / emerald / slate / violet / white / charcoal)，每张有自己的 `.dk-accent`

**关键组件**: 160px 超大标题 · 4px 短粗 accent line divider · arrow-prefixed mono list · JetBrains Mono 数字/代码 · 左下键盘提示 · 右下 page label

**匹配条件**: 有话要说、没太多图、用排版节奏推进注意力；keynote 式极简讲稿；公开分享 / 每张只讲一件事。

---

### graphify-dark-graph

**路径**: `templates/starter-decks/graphify-dark-graph/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 12 
**演示类型**: 信息同步 · **叙事模型**: What-Why-How

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: Deep-night 渐变 · 三颗 400-520px blur orb 慢飘动 · 琥珀 `#e8a87c` / 薄荷 `#7ed3a4` / 雾蓝 `#7eb8da` / 丁香 `#b8a4d6` 四色 accent · rainbow shift 渐变标题

**关键组件**: 力导向 SVG 知识图谱背景 · glass 拟态卡片(5 变体) · JetBrains Mono `.cmd-glow` 命令行 · warm/blue/green/purple 四色系统

**匹配条件**: 开发者工具介绍、命令行产品、知识图谱/数据可视化项目、需要"AI native + 科技感 + 温度"气质。

---

### hermes-cyber-terminal

**路径**: `templates/starter-decks/hermes-cyber-terminal/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 14 
**演示类型**: 信息同步 · **叙事模型**: 对比评测

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: `#0a0c10` · 56px cyber 网格 · CRT vignette · scanlines 叠层 · 薄荷绿 glow `#7ed3a4` · JetBrains Mono 全文 · 琥珀/绿/红分级标签

**关键组件**: 56px cyber 网格背景 · CRT vignette + scanlines · 窗口 traffic-light chrome · `$ prompt` 命令行标题 · text-shadow glow · stroke-only 虚拟 bar chart · blinking cursor

**匹配条件**: 评测开发者工具/CLI/agent、展示跑分数据/trace/diff、长 trace/long code 场景、需要"honest cyber review"气质。

---

### knowledge-arch-blueprint

**路径**: `templates/starter-decks/knowledge-arch-blueprint/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 16 
**演示类型**: 传授/赋能 · **叙事模型**: What-Why-How

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: 暖米色纸底 · 微弱 48px 蓝图网格 · 锈红 `#B5392A` 单一 accent · 硬黑 2px 边框卡片 · Playfair Display 大字衬线

**关键组件**: 48px 蓝图网格 · pipeline step-box 一字排开 · hero box 凸起 · 右上 insight 红色 callout · SVG 反馈回路虚线+箭头 · 无渐变无阴影极度克制

**匹配条件**: 系统架构、数据流向、流程拆解、技术白皮书、需要严肃感/印刷感/可截图塞 README。

---

### consultant-strategy

**路径**: `templates/starter-decks/consultant-strategy/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 16
**演示类型**: 说服/决策 · **叙事模型**: SCQA + 金字塔原则

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: 白底 · McKinsey Blue `#005587` 主色 · Amber `#f5a623` 数据强调 · 硬边卡片无阴影 · Arial/Helvetica 字体栈 · 结论先行（Pyramid Principle）

**幻灯片结构**:
Cover → Agenda → Executive Summary(金字塔顶) → Situation(4 数据卡) → Complication(3 痛点卡) → Question(MECE 树) → Chapter Divider(蓝屏) → Framework(2×2 矩阵) → Recommendation(3 方案对比) → Data Deep Dive(大数字+拆解) → Comparison Table(6 维度对标) → Process Flow(3 波次路线图) → Quarterly Review(RAG 季度卡) → Risks & Mitigation(3 风险双栏) → Next Steps(90 天 4-step) → Thanks

**关键组件**: `.cs-fact`(大数字卡, `.cs-num`/`.cs-label`/`.cs-delta`) · `.cs-matrix` + `.cs-cell.hero`(2×2 战略矩阵) · `.cs-pipeline` + `.cs-step.hero`(4-step 管道) · `.cs-table` + `.col-hero`(硬边对比表, 推荐列 amber 高亮) · `.cs-quarter` + `.cs-rag-dot` + `.cs-q-progress`(季度 RAG 复盘) · `.cs-risk`(风险/缓释双栏) · `.cs-tree-node`(MECE 分解) · `.card-amber`/`.bar-top`/`.bar-left`(咨询装饰)

**匹配条件**: 战略咨询、董事会汇报、投资分析、季度业务复盘、商业提案、M&A、任何需要"结论先行 + 数据驱动 + MECE 结构"的高端 B 端决策场景。模板气质克制专业，与 pitch-deck 区别在于：pitch-deck 面向投资人讲故事（Problem→Ask），consultant-strategy 面向董事会做决策（SCQA 诊断 → 方案择优 → 90 天行动）。

**配套颜色方案**: 默认 `mckinsey-blue`；可切 `consulting-navy`（深蓝投行）、`ocean-depths`（深海蓝）、`cmb-gold-red`（金融红金）。

---

### government-formal-red

**路径**: `templates/starter-decks/government-formal-red/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 16
**演示类型**: 政务汇报 · **叙事模型**: 工作回顾→成效→问题→部署→保障（政务工作报告体裁，非 SCQA）

**默认色板**（可替换——颜色由 color-schemes.json 独立注入）: 白底 · 政府红 `#8B0000` + 政府蓝 `#003366` + 金 `#DAA520` · 红蓝双色顶饰 · 红头文件版心 · 雅黑字体栈

**幻灯片结构**:
Cover(红头文件版心+文号+印章) → 目录(红色序号块) → 工作综述 → 政策依据与基本盘(政策引用块+4数据卡) → 主要成效(排名跃升+亮点) → 存在问题(三清单) → 章节切换(深蓝全屏) → 总体要求与目标(三化原则+目标指标条) → 重点任务分解 → 数据深潜 → 对标先进 → 实施路径(时间轴) → 阶段成效(RAG) → 风险防控 → 责任分工与组织保障(责任分工表+四保障) → 结束(居中表态+署名带+渠道条)

**关键组件**: `.gov-redbar`(红蓝双色顶饰) · `.gov-doc-title`/`.gov-seal`(红头版心+印章) · `.gov-chapter-bg`(深蓝章节全屏) · `.gov-policy-cite`(政策依据引用块·带文号) · `.gov-checklist`(三清单·问题/影响/整改) · `.gov-principle`(三化工作原则) · `.gov-goal-bar`(约束性+预期性目标指标) · `.gov-resp-table`(责任分工矩阵表·5列) · `.gov-safeguard`(组织保障四宫格) · `.gov-signband`/`.gov-channelbar`(署名带+服务渠道条)

**匹配条件**: 政务工作汇报、专项工作总结、政策宣讲、营商环境/改革推进、招商引资、年度工作报告。与 consultant-strategy 区别：consultant 是咨询诊断（SCQA→方案择优），government-formal-red 是政务汇报（政策依据→成效→问题→责任分工部署），用红头文件/责任分工表/三清单等政务专属版式，绝非咨询换皮。

**配套颜色方案**: 默认 `government-red`；可切 `government-blue`（政府蓝）、`consulting-navy`（深蓝）。

---

### soe-engineering-blue

**路径**: `templates/starter-decks/soe-engineering-blue/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 16
**演示类型**: 工程项目汇报 · **叙事模型**: 项目概况→技术方案→建设进度→质量安全→效益分析

**默认色板**（可替换）: **深色 deck** · 深海蓝底 `#001F45` + 电建蓝 `#00418D`/科技蓝 `#0066CC` + 光辉金 `#FFD700` + 中国红点睛 · 经纬网格纹理 · 白字 · 雅黑栈

**幻灯片结构**:
Cover(基石概念·深蓝网格+工程剪影) → 目录(工程里程碑) → 项目综述 → 项目概况(投资/工期/规模参数角标) → 建设挑战 → 技术主线 → 章节切换(stroke-only轮廓字) → 技术方案路线图 → 关键技术(科技卡) → 工程数据深潜 → 对标同类工程 → 施工进度甘特图 → 四控制阶段进展 → 风险管控 → 下一步(投产/验收/移交) → 结束(工程全景+致谢建设者)

**关键组件**: `.soe-grid-bg`(经纬网格底) · `.soe-corner-mark`(四角瞄准框) · `.soe-gantt`(甘特图·工序×月份) · `.soe-fourcontrol`(安全/质量/进度/投资四控制仪表盘) · `.soe-tech-card`(科技卡片·glowing) · `.soe-param-table`(工程技术参数表) · `.soe-milestone`(里程碑形象进度)

**匹配条件**: 央企/国企重大工程项目汇报、基建/水电/桥梁/能源项目、国际业务展示、科技成果发布。**深色科技风**与其它白底 deck 视觉差异最大；甘特图+四控制是工程汇报的身份证。与 consultant 区别：用工程专属版式（甘特图/四控制/参数表），绝非咨询换皮。

**配套颜色方案**: 默认 `powerchina-modern`；深色底适配深色系 scheme。

---

### bank-vip-gold

**路径**: `templates/starter-decks/bank-vip-gold/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 16
**演示类型**: 财富管理汇报 · **叙事模型**: 客户全景→资产配置→市场展望→产品推荐→财富规划

**默认色板**（可替换）: 白底 · 招行红 `#C41230` + 辅助金 `#C9A962` + 深红 `#9A0E26` · 精致双线 + 多层圆环 + 菱形分割 · 雅黑栈

**幻灯片结构**:
Cover(精致轻奢·红条金双线+多层圆环+菱形) → 目录(清单式金下划线) → 客户全景综述 → 客户画像与资产现状(KYC+配置环形图) → 市场挑战 → 配置主线 → 章节切换(全屏深红+金阶梯) → 资产配置框架(核心-卫星) → 产品推荐货架 → 业绩深潜(净值曲线) → 产品对比表 → 投资路径/定投 → 季度业绩复盘 → 风险提示/合规 → 财富规划下一步 → 结束(专属预约大卡+私行承诺+风险提示+圆环呼应)

**关键组件**: `.bank-doubleline`(精致双线) · `.bank-rings`(多层同心圆·向日葵) · `.bank-diamond`(菱形分割) · `.bank-kyc`(客户画像多维标签) · `.bank-alloc`(资产配置环形图·conic-gradient) · `.bank-nav-curve`(净值曲线) · `.bank-shelf`(产品货架) · `.bank-risk-matrix`(风险评级矩阵)

**匹配条件**: 银行/金融机构 VIP 客户汇报、私人银行资产配置建议、年度财富管理报告、高端理财产品推介。极简轻奢质感；资产配置环形图+产品货架是财富管理身份证。与 consultant 区别：用金融专属版式（配置饼图/净值曲线/产品货架/KYC），绝非咨询换皮。

**配套颜色方案**: 默认 `cmb-gold-red`；可切其它红金/深红系。

---

### academic-defense

**路径**: `templates/starter-decks/academic-defense/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 16
**演示类型**: 学位论文答辩 · **叙事模型**: 选题背景→文献综述→研究方法→实验结果→结论贡献

**默认色板**（可替换）: 白底 · 主导深蓝 `#003366` + 辅助蓝 `#0066CC` + 强调红 `#CC0000` · 深蓝页眉条 + 红竖条 · 雅黑栈（注：scheme 名"academic-green 墨绿"，实际配色为深蓝+红，按设计规范用）

**幻灯片结构**:
Cover(答辩严谨·深蓝页眉条+红竖条+答辩人/导师/学号/校徽) → 目录(卡片双列) → 研究综述(核心贡献+创新点) → 选题背景与意义 → 文献综述(编号引用卡) → 研究问题 → 章节切换(深蓝全屏+几何装饰) → 研究技术路线图 → 研究方法 → 实验结果(公式块+baseline对比) → 方法对比表(baseline vs ours) → 研究路线 → 研究进度 → 局限与未来工作 → 后续研究计划 → 结束(致谢正文·导师/课题组/基金号+论文链接+Q&A)

**关键组件**: `.aca-header`(深蓝页眉条+红竖条) · `.aca-info`(答辩人信息块·姓名/学号/导师/机构/日期) · `.aca-litcard`(文献综述编号卡·[1]+作者年+观点) · `.aca-cite`(上标引用标记) · `.aca-formula`(公式块·居中mono+编号) · `.aca-baseline`(baseline vs ours对比) · `.aca-roadmap`(研究路线图)

**匹配条件**: 硕博学位论文答辩、学术汇报、研究进展报告、课题中期检查、开题答辩。严谨科研感；文献综述卡+公式块+baseline对比是学术答辩身份证。公式暂用 `.mono` 占位，KaTeX 渲染后续单独立项。与 consultant 区别：用学术专属版式（文献卡/公式/baseline对比），绝非咨询换皮。

**配套颜色方案**: 默认 `academic-green`（实为深蓝+红）；可切 `consulting-navy`。

---

### insight-report

**路径**: `templates/starter-decks/insight-report/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 14
**演示类型**: 研究报告/观点输出 · **叙事模型**: BLUF 结论先行（执行摘要→背景→方法论→发现→数据→对比→影响→建议→附录）

**默认色板**（可替换）: 白底 · 克制深墨蓝 `#0A2540` 主色 + 高对比 · 可打印（避免深色满铺，省墨）

**幻灯片结构**:
Cover(报告标题+机构+报告编号) → 执行摘要(BLUF: 一句话结论+支撑要点) → 背景 → 方法论(研究方法网格) → 发现×3(编号发现卡) → 数据深潜 → 对比 → 影响 → 建议 → 下一步 → 附录(方法论细节/数据来源/术语表)

**关键组件**: `.exec-summary`(BLUF 执行摘要框) · `.finding-card`(编号发现卡) · `.ir-method-grid`/`.ir-method-item`(方法论网格) · `.appendix-block`(附录·可打印) · `.research-chart`(图表容器带来源标注) · `.ir-keynums`(关键数字) · `.ir-colophon`(报告版权页)

**匹配条件**: 行业研究报告、市场洞察、数据调研、白皮书、年度趋势报告、给决策者的观点输出。与 consultant-strategy 区别：consultant 是咨询诊断(SCQA→方案择优)，insight-report 是研究报告(BLUF+方法论+发现+附录)，有方法论页和可打印附录。

**配套颜色方案**: 默认深墨蓝（ink/`#0A2540`）；可切 `consulting-navy`、`ocean-depths`。

---

### biz-review

**路径**: `templates/starter-decks/biz-review/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 14
**演示类型**: 业务复盘/述职 · **叙事模型**: 直线递进（周期回顾→核心成果→KPI总览→亮点展开→挑战风险→下阶段计划→资源需求）

**默认色板**（可替换）: 白底 · 商务深蓝 · 专业稳重

**幻灯片结构**:
Cover(周期+业务线+汇报对象) → 周期回顾 → 核心成果 → KPI 总览墙 → 亮点展开 → 差距分析(目标vs实际vs根因vs行动) → 挑战与风险 → 下阶段计划 → 资源审批块 → 结束(行动决议)

**关键组件**: `.br-attrib`/`.br-attrib-bar`/`.br-attrib-seg`(KPI 归因条) · `.br-chart-card`(图表卡) · `.br-callout`(成果高亮) · `.br-approval`/`.br-approval-col`/`.br-approval-item`(资源审批块) · `.kpi-wall`(KPI 总览墙)

**匹配条件**: 季度/年度业务复盘、述职报告、产品线回顾、部门汇报、给高管的"成果+规划+要资源"。与 weekly-report 区别：weekly 是 14 页团队细粒度同步，biz-review 是高管级业务复盘（KPI 墙+归因+资源审批），容量和受众层级更高。

**配套颜色方案**: 商务深蓝；可切 `consulting-navy`、`mckinsey-blue`。

---

### compare-eval

**路径**: `templates/starter-decks/compare-eval/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 10
**演示类型**: 对比评测/选型 · **叙事模型**: 对比评测（评测维度→参评方→对比矩阵→深挖→裁决→推荐）

**默认色板**（可替换）: 白底 · 中性墨蓝 `#1E3A5F` · 客观克制不偏袒

**幻灯片结构**:
Cover(评测对象+评测方+日期) → 评测维度说明 → 参评方档案×N → 对比矩阵(评分+勾叉+权重) → 维度深挖 → 优劣对照 → 综合裁决 → 推荐结论 → 附录(测试方法)

**关键组件**: `.ce-cand-grid`/`.ce-cand-col`/`.ce-cand-head`/`.ce-cand-list`/`.ce-cand-logo`(参评方档案) · `.ce-cand-fit`/`.ce-cand-tagrow`(适配度/标签行) · `.ce-dd-bar-row`/`.ce-dd-bar-fill`(维度深挖进度条) · 评测矩阵(评分单元格)

**匹配条件**: 技术选型、产品横评、方案对比、vendor 评估、招标评比、给决策者/选型委员会的客观评测。与 hermes-cyber-terminal 区别：hermes 是 CLI/agent 评测（CRT 扫描线+终端主题绑死），compare-eval 是泛化的对比评测骨架（任意选型，评分矩阵+权重+裁决）。与 consultant comparison-table 区别：那是方案对比推荐列高亮，compare-eval 是多维评分矩阵。

**配套颜色方案**: 中性墨蓝；可切 `slate-grey`、`consulting-navy`。

---

### keynote-formal

**路径**: `templates/starter-decks/keynote-formal/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 10
**演示类型**: 主题演讲/大会致辞 · **叙事模型**: 黄金圈/英雄之旅（信念Why→挣扎故事→转折点→新的理解→行动号召）

**默认色板**（可替换）: 庄重金 `#D4AF37` + 黑 · 正式有分量

**幻灯片结构**:
Cover(主题+演讲人+大会名+日期) → 信念宣言(Why) → 挣扎故事 → 转折点 → 新的理解 → 大引语(情感高潮) → 叙事节拍×N → 行动号召 → 结束(金句回响)

**关键组件**: `.slide-body`(叙事节拍页容器) · `.accent-text`(金句强调) · `.counter`/`.slide-number`(节拍编号) · `.notes`(逐字稿，观众不可见) · `.tpl-keynote-beat-text`/`.tpl-keynote-beat-figure`(节拍图文) · `.tpl-keystone-grid`(拱心石布局)

**匹配条件**: 公司年会 CEO 致辞、主题大会演讲、开学/毕业典礼、品牌发布会主题演讲、任何需要"信念→故事→号召"叙事弧的庄重演讲。与 dir-key-nav-minimal 区别：那是极简逐点递进，keynote-formal 是有情感曲线的叙事弧。与 presenter-mode-reveal 区别：那是演讲者工具(S键+逐字稿)，keynote-formal 是视觉叙事模板本身。

**配套颜色方案**: 庄重金黑；可切单色系（`ink-slate` 等）。

---

### obsidian-claude-gradient

**路径**: `templates/starter-decks/obsidian-claude-gradient/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 14 
**演示类型**: 传授/赋能 · **叙事模型**: What-Why-How

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: `#0d1117` · 紫色 ambient radial `#7c3aed` · 60px 遮罩网格 · 紫→蓝→绿渐变文字 `#a855f7→#60a5fa→#34d399`

**关键组件**: 居中对齐 · 紫色 pill tag · linear 三停渐变字 · GitHub-ish 代码色(暗底+紫/蓝/橙/绿 token) · 紫色左边框 highlight 块 · 简洁 step 列表

**匹配条件**: 开发者友好工作流、MCP/Agent/Dev tool 教程、气质接近 GitHub Blog/Linear Changelog、内容以配置文件+步骤为主。

---

### presenter-mode-reveal

**路径**: `templates/starter-decks/presenter-mode-reveal/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 15 
**演示类型**: 传授/赋能 · **叙事模型**: 灵活

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: 5 预设主题(tokyo-night, dracula, catppuccin-mocha, nord, corporate-clean)

**关键组件**: **S 键演讲者窗口** — 4 个可拖拽/缩放的磁吸卡片(CURRENT iframe + NEXT iframe + SPEAKER SCRIPT + TIMER)，BroadcastChannel 双向同步翻页 · `<aside class="notes">` 逐字稿(观众不可见) · 5 主题热切换(T 键)

**匹配条件**: 技术分享(30-60min)、产品发布会主讲、课程讲授、任何需要照着讲但不能念稿的正式演讲。

---

### testing-safety-alert

**路径**: `templates/starter-decks/testing-safety-alert/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 16 
**演示类型**: 说服/促动 · **叙事模型**: 问题→后果→行动

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: 白底 · 红琥珀警示色 · 顶部 45° 红黑斜条纹警示带 · L1/L2/L3 三档色卡(绿/琥珀/红) · 圆形 alert-box · red strike-through

**关键组件**: 45° 红黑斜条纹警示带(顶+底) · `strike-through` 否定大字 · L1/L2/L3 三档色卡 · 圆形前置指示灯 alert-box · policy-yaml 深色代码块(红色左边框) · 红绿复选框 checklist · Q1 事故柱状图

**匹配条件**: 安全/风控/事故复盘/红队测试/AI 上线前评估/policy as code、需要让观众立刻感到"这事严肃"。

---

### xhs-pastel-card

**路径**: `templates/starter-decks/xhs-pastel-card/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 14 
**演示类型**: 启发/共鸣 · **叙事模型**: SCQA

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: 暖奶油底 · 三颗柔光 blob · Playfair italic 衬线 accent · 整色马卡龙卡片(桃/薄荷/天/丁香/柠檬/玫瑰 `#f8c8d8`/`#c8e6d0`/`#c8ddf0`/`#d8c8e8`/`#f0e0a8`/`#f0c8d0`)

**关键组件**: 柔光 blob 背景 · 顶部 chip+page 组合 · Playfair italic accent 词 · 整色 28px 圆角大卡片 · italic Playfair 序号 01-04 · donut SVG 图 · 衬线标题/sans 正文混排

**匹配条件**: 生活方式/个人成长/轻内容/情感向、需要"不那么科技感、偏杂志偏手作"的气质、讲"慢""休息""温柔"主题。

---

### xhs-white-editorial

**路径**: `templates/starter-decks/xhs-white-editorial/` · **角色目录**: `slide-roles.md`
**语言**: zh-CN · **页数**: 16 
**演示类型**: 信息同步+说服 · **叙事模型**: What-Why-How

**默认色板**（可替换——颜色由 color-schemes.json 独立注入，以下仅为模板出厂默认值）: 纯白底 · 顶部 10 色彩虹条 · 渐变 brand 文字(紫→蓝→绿→橙→粉) · macaron 软色卡(soft-purple/pink/blue/green/orange)

**关键组件**: 顶部 10 色彩虹条 · 80-110px 超大标题(负字距) · 渐变 brand 文字 · macaron 软色卡分组 · 胶囊 tag + dot · 黑底 `.focus` 强调框 · hero quote box(淡阴影)

**匹配条件**: 小红书图文、也能当横屏 deck、文字多/重点密集/需要一眼抓住关键词、面向中文读者为主。

---
