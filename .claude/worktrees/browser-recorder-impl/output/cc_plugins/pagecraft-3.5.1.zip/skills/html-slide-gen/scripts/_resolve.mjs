// _resolve.mjs — html-slide-gen 导出脚本的依赖解析 + 自举安装
//
// 背景：plugin 分发包（git archive）不含 node_modules，且在 AI 平台上 skill
// 目录（本 .mjs 所在）往往是只读挂载，无法就地 npm install。ESM 的 bare import
// 又只从「脚本文件所在目录链」向上回溯找 node_modules，既不看 cwd 也不看
// NODE_PATH——所以只读目录下的 .mjs 根本解析不到任何依赖。
//
// 解法（复刻姊妹 skill doc-convert/lib/_resolve.mjs 的 createRequire 思路，
// 并把 doc-convert 放在 shell bootstrap 里的「安装」步骤内置进来——因为
// html-slide-gen 没有 shell 入口，导出都是 `node xxx.mjs` 裸调）：
//   1. 把 plugin 根 package.json 复制到用户家目录缓存
//      （${HTML_SLIDE_GEN_NODE_CACHE:-~/.cache/html-slide-gen}，家目录永远可写）
//   2. 在缓存目录 npm install（stamp 变化才重装，命中则秒过）
//   3. 首次还需 `playwright install chromium`（playwright npm 包不含浏览器二进制）
//   4. 用 createRequire() 造一个 require，解析起点锚定到缓存目录（与 .mjs 物理
//      位置无关），从而在只读目录里也能 require 到缓存中的依赖。
//
// 相比 doc-convert 多两步：① 安装用 O_EXCL 锁防并发损坏 node_modules；
// ② playwright 浏览器二进制安装（doc-convert 用 puppeteer 会自动下 Chrome）。
//
// 用法（各 .mjs 顶部 main() 内）：
//   import { dep } from './_resolve.mjs';
//   const chromium = dep('playwright').chromium;   // 缺失→自动安装→重试；再缺失 exit(2)
//   const pptxgen  = dep('pptxgenjs').default;

import { createRequire } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { execSync } from 'node:child_process';
import crypto from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs';

/** 依赖缓存目录。可被环境变量 HTML_SLIDE_GEN_NODE_CACHE 覆盖。 */
export const CACHE_DIR = process.env.HTML_SLIDE_GEN_NODE_CACHE
  || path.join(os.homedir(), '.cache', 'html-slide-gen');

// 从本 .mjs 所在位置向上找 plugin 根（含 package.json 的目录，即 plugins/pagecraft）。
// 不硬编码路径，便于 skill 目录整体搬迁。
function _findPluginDir() {
  let dir = path.dirname(fileURLToPath(import.meta.url));
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, 'package.json'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return path.dirname(path.dirname(fileURLToPath(import.meta.url))); // 兜底
}
export const PLUGIN_DIR = _findPluginDir();

// createRequire 传入的 filename 仅用于确定「解析起点目录」，文件不必真实存在——
// 只要 dirname 指向缓存目录，require 就会从 <CACHE_DIR>/node_modules 解析。
const cacheRequire = createRequire(pathToFileURL(path.join(CACHE_DIR, 'package.json')).href);

const _memo = new Map();

function _printMissingHint(pkg) {
  console.error(`\n✗ 缺少依赖 "${pkg}"`);
  console.error('  依赖应位于缓存目录（默认 ~/.cache/html-slide-gen/node_modules）。');
  console.error('  正常情况下导出脚本会自动安装；若自举失败，请手动安装到缓存：');
  console.error(`    npm install --prefix "${CACHE_DIR}" ${pkg}`);
  console.error('  playwright 首次还需下载浏览器：');
  console.error(`    "${path.join(CACHE_DIR, 'node_modules', '.bin', 'playwright')}" install chromium`);
}

// ── stamp：plugin 的 package.json + package-lock.json + node 大版本 ──────────
// 任一变化（依赖升级、换 Node 大版本）都触发重装。
function _computeStamp() {
  const pkgPath = path.join(PLUGIN_DIR, 'package.json');
  const lockPath = path.join(PLUGIN_DIR, 'package-lock.json');
  const pkgJson = fs.existsSync(pkgPath) ? fs.readFileSync(pkgPath, 'utf8') : '';
  const lockJson = fs.existsSync(lockPath) ? fs.readFileSync(lockPath, 'utf8') : '';
  return crypto.createHash('sha256')
    .update(`${pkgJson}\n${lockJson}\n${process.version}`)
    .digest('hex');
}

// ── 锁：O_EXCL 互斥锁，防并发安装损坏 node_modules ─────────────────────────
// 持锁者安装；等锁者阻塞重试，拿到锁后重判 stamp（多半已被装好，直接秒过）。
// 附 mtime-TTL（5min）陈旧锁回收，防进程被 SIGKILL 后残留死锁。
const LOCK_PATH = path.join(CACHE_DIR, '.install.lock');
const LOCK_TTL_MS = 5 * 60 * 1000;

// 同步等待（Node 无内置 sync sleep；execSync('sleep') 仅在等锁的百毫秒级使用）。
function _sleepSync(ms) {
  try { execSync(`sleep ${ms / 1000}`, { stdio: 'ignore' }); } catch {}
}

function _acquireLock() {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
  for (;;) {
    try {
      // 'wx' = O_EXCL：文件已存在则抛 EEXIST。返回 fd，调用方负责 close + unlink。
      const fd = fs.openSync(LOCK_PATH, 'wx');
      // 持锁成功：注册退出清理。process.exit / 未捕获异常 / 常见信号都会触发 'exit'
      // 事件从而释放锁，避免等锁者死等——因为 _ensureInstalled / _installChromium 失败时
      // 直接 process.exit(2)，不展开调用栈，dep 的 finally 不会执行（实测会死锁）。
      // SIGKILL 无法捕获，由上方陈旧锁 TTL（5min）回收兜底。幂等：锁已删时 unlink 抛
      // ENOENT 被 catch 吞掉，多次注册亦只多几次无害 unlink 尝试。
      process.on('exit', () => { try { fs.unlinkSync(LOCK_PATH); } catch {} });
      return fd;
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
      // 锁存在；判断是否陈旧（持有者已死）。
      try {
        const st = fs.statSync(LOCK_PATH);
        if (Date.now() - st.mtimeMs > LOCK_TTL_MS) {
          try { fs.unlinkSync(LOCK_PATH); } catch {} // 回收后重试；竞态下 unlink 失败则循环兜底
          continue;
        }
      } catch {}
      _sleepSync(500); // 锁仍有效：短暂等待后重试。
    }
  }
}

// ── 自举：把依赖装进缓存（持锁后调用） ─────────────────────────────────────
function _ensureInstalled() {
  fs.mkdirSync(CACHE_DIR, { recursive: true });

  // stamp 命中（等锁者多半走这里）→ 跳过安装。
  const want = _computeStamp();
  const stampFile = path.join(CACHE_DIR, '.stamp');
  if (fs.existsSync(stampFile) && fs.readFileSync(stampFile, 'utf8') === want) return;

  if (!_commandExists('npm')) {
    console.error('\n✗ npm 未安装（html-slide-gen 的 Node 依赖需要它）');
    console.error('  安装指引: apt-get install nodejs npm 或访问 https://nodejs.org/');
    process.exit(2);
  }

  // 复制 plugin 清单到缓存（缓存是「安装根」，npm 在此读 package.json）。
  const pkgSrc = path.join(PLUGIN_DIR, 'package.json');
  if (fs.existsSync(pkgSrc)) fs.copyFileSync(pkgSrc, path.join(CACHE_DIR, 'package.json'));
  const lockSrc = path.join(PLUGIN_DIR, 'package-lock.json');
  if (fs.existsSync(lockSrc)) fs.copyFileSync(lockSrc, path.join(CACHE_DIR, 'package-lock.json'));

  console.log(`[INFO] 准备 Node 依赖到缓存目录: ${CACHE_DIR}`);
  console.log('[INFO] npm install（首次较慢，约数十秒；后续命中缓存秒过）...');

  // 两段式：npmmirror 镜像失败回退默认源。
  const installOk = _runNpmInstall('https://registry.npmmirror.com') || _runNpmInstall(null);
  if (!installOk) {
    console.error('\n✗ Node 依赖安装失败。');
    console.error(`  可手动安装: npm install --prefix "${CACHE_DIR}"`);
    process.exit(2);
  }

  // 哨兵：核心依赖装好后必须能找到 playwright。
  if (!fs.existsSync(path.join(CACHE_DIR, 'node_modules', 'playwright'))) {
    console.error(`\n✗ 依赖安装后仍找不到核心包 playwright（缓存: ${CACHE_DIR}）`);
    process.exit(2);
  }

  // playwright 浏览器二进制（npm 包不含，必须单独下载）。无条件幂等执行：
  // 不自行 readdir 检测目录名——playwright 浏览器目录命名随版本变
  // （chromium- / chromium_headless_shell- / chromium_tip_of_tree-），检测易假阳性
  // 导致「以为已装实则版本不匹配」。交给 `playwright install chromium` 自判，已装且
  // 版本匹配则秒过；playwright 包升级时 stamp 变化会触发重跑，自动下载对应版本。
  _installChromium();
  // 注：浏览器缺失也可能在「npm 包已就绪、stamp 命中」时发生（包在但浏览器被删/版本漂移），
  // 那条路径不经过本函数，改由 dep('playwright') 末尾的 _ensureChromiumReady() 兜底。

  fs.writeFileSync(stampFile, want);   // npm 包 + Chromium 都就绪才写 stamp
  console.log('[INFO] 依赖就绪（Node 模块 + Chromium，缓存已就绪，后续导出将复用）');
}

// 下载 Chromium 浏览器。国内环境 cdn.playwright.dev 常不可达，且 npmmirror 的 playwright
// 镜像未跟进 cft（Chrome for Testing）构建（PLAYWRIGHT_DOWNLOAD_HOST 设了也 404），故优先
// 【手动】从 npmmirror 的 chrome-for-testing 镜像下载解压到 playwright 期望目录；失败再
// 回退 `playwright install chromium`（官方源，国内可能慢/不通）。两条路都失败才报错。
function _installChromium() {
  if (_installChromiumManual()) return true;
  console.log('[WARN] 国内镜像手动下载失败，回退 playwright install（官方源）...');
  return _installChromiumViaPlaywright();
}

// 回退路径：直接交给 playwright install（官方源 cdn.playwright.dev）。
function _installChromiumViaPlaywright() {
  const pwBin = path.join(CACHE_DIR, 'node_modules', '.bin', 'playwright');
  try {
    execSync(`"${pwBin}" install chromium`, { stdio: 'inherit' });
    return true;
  } catch {
    console.error('\n✗ Playwright Chromium 下载失败（官方源）。');
    console.error(`  可手动: "${pwBin}" install chromium`);
    return false;
  }
}

// playwright 平台字符串（与 playwright-core 内部一致，多年稳定）。
function _pwPlatform() {
  const p = process.platform, a = process.arch;
  if (p === 'darwin') return a === 'arm64' ? 'mac-arm64' : 'mac-x64';
  if (p === 'linux') return a === 'arm64' ? 'linux-arm64' : 'linux-x64';
  if (p === 'win32') return 'win64';
  throw new Error(`不支持的平台: ${p}/${a}`);
}

// 从 playwright-core/browsers.json 读 chromium 的 revision + browserVersion。
function _readChromiumRevision() {
  const bjPath = path.join(CACHE_DIR, 'node_modules', 'playwright-core', 'browsers.json');
  const bj = JSON.parse(fs.readFileSync(bjPath, 'utf8'));
  const cr = (bj.browsers || []).find(b => b.name === 'chromium');
  if (!cr) throw new Error('browsers.json 未找到 chromium 条目');
  return { revision: cr.revision, browserVersion: cr.browserVersion };
}

// 手动从国内镜像下载并解压 Chromium（完整 + headless shell）。
// 镜像布局：https://cdn.npmmirror.com/binaries/chrome-for-testing/<browserVersion>/<plat>/<file>
// playwright 期望：ms-playwright/chromium-<rev>/chrome-<plat>/（完整）
//                  ms-playwright/chromium_headless_shell-<rev>/chrome-headless-shell-<plat>/（hss）
function _installChromiumManual() {
  // 需要系统 curl + unzip（精简容器可能缺失，此时回退 playwright install）。
  if (!_commandExists('curl') || !_commandExists('unzip')) {
    console.error('[WARN] 缺少 curl 或 unzip，无法走国内镜像手动下载；回退 playwright install。');
    return false;
  }
  const MIRROR = 'https://cdn.npmmirror.com/binaries/chrome-for-testing';
  let rev, browserVer, plat;
  try {
    ({ revision: rev, browserVersion: browserVer } = _readChromiumRevision());
    plat = _pwPlatform();
  } catch (e) {
    console.error(`[WARN] 无法读取 chromium 版本信息：${e.message}`);
    return false;
  }

  const browsersDir = process.env.PLAYWRIGHT_BROWSERS_PATH
    || (process.platform === 'darwin'
        ? path.join(os.homedir(), 'Library', 'Caches', 'ms-playwright')
        : path.join(os.homedir(), '.cache', 'ms-playwright'));

  const builds = [
    {
      name: 'chromium',
      dirName: `chromium-${rev}`,
      archiveName: `chrome-${plat}`,
      url: `${MIRROR}/${browserVer}/${plat}/chrome-${plat}.zip`,
    },
    {
      name: 'chromium-headless-shell',
      dirName: `chromium_headless_shell-${rev}`,
      archiveName: `chrome-headless-shell-${plat}`,
      url: `${MIRROR}/${browserVer}/${plat}/chrome-headless-shell-${plat}.zip`,
    },
  ];

  for (const b of builds) {
    const destDir = path.join(browsersDir, b.dirName);
    const unpackSubdir = path.join(destDir, b.archiveName);
    // 幂等：解压目标已存在则跳过该构建。
    if (fs.existsSync(unpackSubdir)) continue;
    console.log(`[INFO] 下载 ${b.name}（国内镜像）...`);
    const tmpZip = path.join(os.tmpdir(), `pw-${b.name}-${rev}.zip`);
    try {
      execSync(`curl -fL --connect-timeout 15 --max-time 300 -o "${tmpZip}" "${b.url}"`, { stdio: 'inherit' });
      fs.mkdirSync(destDir, { recursive: true });
      // zip 顶层目录即 b.archiveName，解压到 destDir 即得 destDir/chrome-<plat>/。
      execSync(`unzip -q -o "${tmpZip}" -d "${destDir}"`, { stdio: 'inherit' });
    } catch (e) {
      console.error(`[WARN] ${b.name} 镜像下载/解压失败：${e.message}`);
      try { fs.rmSync(destDir, { recursive: true, force: true }); } catch {}
      try { fs.rmSync(tmpZip, { force: true }); } catch {}
      return false;
    }
    try { fs.rmSync(tmpZip, { force: true }); } catch {}
    if (!fs.existsSync(unpackSubdir)) {
      console.error(`[WARN] ${b.name} 解压后未找到 ${b.archiveName}/`);
      return false;
    }
  }
  console.log('[INFO] Chromium 就绪（国内镜像下载完成）');
  return true;
}

// 校验 Chromium 二进制是否真的可启动（playwright 的 executablePath() 在浏览器缺失时
// 不抛错、只返回不存在的路径，故用 existsSync 判断）。供 dep('playwright') 兜底：
// 覆盖「npm 包已就绪、stamp 命中，但浏览器二进制缺失」的场景。
function _chromiumReady(pwModule) {
  try {
    const exe = pwModule.chromium.executablePath();
    return !!exe && fs.existsSync(exe);
  } catch { return false; }
}

function _runNpmInstall(registry) {
  const args = ['install', '--omit=optional', '--no-audit', '--no-fund'];
  if (registry) args.push(`--registry=${registry}`);
  try {
    execSync(`npm ${args.join(' ')}`, { stdio: 'inherit', cwd: CACHE_DIR });
    return true;
  } catch { return false; }
}

function _commandExists(cmd) {
  try { execSync(`command -v ${cmd}`, { stdio: 'ignore' }); return true; } catch { return false; }
}

/**
 * 同步加载一个 npm 依赖（从缓存目录解析）。缺失则自举安装后重试；再缺失打印指引并 exit(2)。
 * 所有依赖均有 CJS 构建，故同步 require 即可，调用处无需 async/await。
 * @param {string} name 依赖名，如 'playwright' / 'pptxgenjs' / 'pdf-lib'
 * @returns {*} module.exports
 */
export function dep(name) {
  if (_memo.has(name)) return _memo.get(name);
  let mod;
  try {
    mod = cacheRequire(name);
  } catch {
    // npm 包缺失 → 持锁自举安装 → 重试。
    let fd;
    try {
      fd = _acquireLock();
      _ensureInstalled();            // 内部会重判 stamp，等锁者通常直接秒过
      mod = cacheRequire(name);
    } catch {
      _printMissingHint(name);
      process.exit(2);
    } finally {
      if (fd !== undefined) {
        try { fs.closeSync(fd); } catch {}
        try { fs.unlinkSync(LOCK_PATH); } catch {}
      }
    }
  }
  // playwright 专属兜底：npm 包就绪 ≠ 浏览器二进制就绪。包在但浏览器缺失/版本漂移时
  // （如 stamp 命中路径），补装 chromium。轻量校验（existsSync），缺失才走重安装。
  if (name === 'playwright' && !_chromiumReady(mod)) {
    let fd;
    try {
      fd = _acquireLock();
      // 持锁后再判一次：等锁期间另一进程可能已装好。
      if (!_chromiumReady(mod) && !_installChromium()) {
        console.error('\n✗ Playwright Chromium 不可用，导出/截图将失败。');
        process.exit(2);
      }
    } finally {
      if (fd !== undefined) {
        try { fs.closeSync(fd); } catch {}
        try { fs.unlinkSync(LOCK_PATH); } catch {}
      }
    }
  }
  _memo.set(name, mod);
  return mod;
}

/**
 * 同步加载可选依赖。缺失或加载失败返回 null，不退出、不安装。
 * @param {string} name
 * @returns {*} module.exports 或 null
 */
export function depOptional(name) {
  if (_memo.has(name)) return _memo.get(name);
  try {
    const mod = cacheRequire(name);
    _memo.set(name, mod);
    return mod;
  } catch {
    _memo.set(name, null);
    return null;
  }
}
