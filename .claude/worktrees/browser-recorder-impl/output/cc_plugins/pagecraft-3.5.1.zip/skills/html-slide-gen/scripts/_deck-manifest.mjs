// _deck-manifest.mjs — shared DECK_MANIFEST / DECK_NOTES extractor.
//
// Why this exists (audit L2): the manifest/notes extraction regex was duplicated
// across validate.mjs (robust, uses bracket-depth scan) and export_single.mjs /
// batch-fix.mjs (flat `\[[\s\S]*?\]` regex). The flat variant breaks first when a
// manifest string contains a literal `}` (e.g. a JSON value with a closing brace),
// because `*?` is non-greedy and stops at the first `];`-ish boundary. Unify on
// the robust bracket-depth approach so all three scripts agree.
//
// Exports:
//   - extractDeckManifest(html): array | null  (bracket-depth scan over the [...] payload)
//   - extractDeckNotes(html):   object | null  (brace-depth scan over the {...} payload)
//   - MANIFEST_RE / NOTES_START_RE: the anchor regexes (for callers that need the match index)

// Anchor: locates `window.DECK_MANIFEST = [`. The payload is the balanced [...] that follows.
const MANIFEST_RE = /window\.DECK_MANIFEST\s*=\s*/;
// Anchor: locates `window.DECK_NOTES = {`.
const NOTES_START_RE = /window\.DECK_NOTES\s*=\s*/;

function safeEval(expr) {
  return new Function('return (' + expr + ')')();
}

// Scan a balanced bracket region starting at `start` (index of the opening bracket).
// openChar/closeChar are '[' / ']' or '{' / '}'. Returns the index AFTER the matching
// close bracket, or -1 if unbalanced. String literals ("..." and '...') are skipped so a
// literal close-bracket inside a JSON string value (e.g. {"label":"a]b"}) does not break the
// depth count — this is the one real improvement over pagecraft's validator, which scanned
// blind and would mis-count on such values.
function scanBalanced(html, start, openChar, closeChar) {
  let depth = 0;
  let inStr = null; // current string quote char, or null if not in a string
  for (let i = start; i < html.length; i++) {
    const ch = html[i];
    if (inStr) {
      if (ch === '\\') { i++; continue; } // skip escaped char
      if (ch === inStr) inStr = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inStr = ch; continue; }
    if (ch === openChar) depth++;
    else if (ch === closeChar) {
      depth--;
      if (depth === 0) return i + 1;
    }
  }
  return -1;
}

function extractPayload(html, anchorRe, openChar, closeChar) {
  const m = anchorRe.exec(html);
  if (!m) return null;
  const open = html.indexOf(openChar, m.index);
  if (open === -1) return null;
  const end = scanBalanced(html, open, openChar, closeChar);
  if (end === -1) return null;
  return { raw: html.slice(open, end), index: m.index };
}

export function extractDeckManifest(html) {
  const payload = extractPayload(html, MANIFEST_RE, '[', ']');
  if (!payload) return null;
  try {
    return safeEval(payload.raw);
  } catch (e) {
    throw new Error(`DECK_MANIFEST parse error: ${e.message}`);
  }
}

export function extractDeckNotes(html) {
  const payload = extractPayload(html, NOTES_START_RE, '{', '}');
  if (!payload) return null;
  try {
    return safeEval(payload.raw);
  } catch (e) {
    throw new Error(`DECK_NOTES parse error: ${e.message}`);
  }
}

export { MANIFEST_RE, NOTES_START_RE };
