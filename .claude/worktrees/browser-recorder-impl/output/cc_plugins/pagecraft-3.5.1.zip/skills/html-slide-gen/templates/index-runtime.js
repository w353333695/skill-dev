/**
 * index-runtime.js — Deck Presenter Runtime
 *
 * COPY THIS FILE to slides-output/<name>/index-runtime.js AS-IS.
 * Do NOT regenerate or inline into index.html.
 *
 * Dependencies:
 *   - window.DECK_MANIFEST  (array of {file, label})
 *   - window.DECK_NOTES     (object keyed by slide file path)
 *   - window.DECK_WIDTH     (default 1920)
 *   - window.DECK_HEIGHT    (default 1080)
 *   - DOM: #stage, #frame, #counter, #printStack, #notesOverlay, #notesContent, #navL, #navR
 */
(function () {
  'use strict';

  const W = window.DECK_WIDTH || 1920;
  const H = window.DECK_HEIGHT || 1080;
  const deck = window.DECK_MANIFEST || [];
  const preNotes = window.DECK_NOTES || {};
  const stage = document.getElementById('stage');
  const frame = document.getElementById('frame');
  const counter = document.getElementById('counter');
  const printStack = document.getElementById('printStack');
  const notesOverlay = document.getElementById('notesOverlay');
  const notesContent = document.getElementById('notesContent');
  const storageKey = 'deck-pos-' + location.pathname;
  const CHANNEL_NAME = 'deck-presenter-' + location.pathname;
  const LAYOUT_STORAGE_KEY = 'deck-presenter-layout:' + location.pathname;

  let current = 0;
  let presenterWin = null;
  let bc;

  // BroadcastChannel
  try { bc = new BroadcastChannel(CHANNEL_NAME); } catch (e) { bc = null; }

  if (!deck.length) {
    counter.textContent = 'No slides';
    return;
  }

  stage.style.width  = W + 'px';
  stage.style.height = H + 'px';

  /* ========== Build slideMeta from DECK_MANIFEST + DECK_NOTES ========== */
  const slideMeta = deck.map(item => ({
    file: item.file,
    label: item.label || '',
    title: item.label || item.file,
    notes: preNotes[item.file] || ''
  }));

  /* ========== Helper: extract notes from iframe contentDocument (fallback) ========== */
  function extractNotesFromFrame() {
    try {
      const doc = frame.contentDocument || frame.contentWindow.document;
      const noteEl = doc.querySelector('aside.notes, .notes, .speaker-notes');
      const titleEl = doc.querySelector('h1, h2, h3');
      if (titleEl) slideMeta[current].title = titleEl.textContent.trim();
      if (noteEl) slideMeta[current].notes = noteEl.innerHTML;
    } catch (_) { /* cross-origin or not ready */ }
  }

  /* ========== Fit stage to viewport ========== */
  function fit() {
    const s = Math.min(window.innerWidth / W, window.innerHeight / H);
    const x = (window.innerWidth  - W * s) / 2;
    const y = (window.innerHeight - H * s) / 2;
    stage.style.transform = `translate(${x}px, ${y}px) scale(${s})`;
    stage.style.top = '0';
    stage.style.left = '0';
  }

  /* ========== Navigate to slide ========== */
  function show(idx, fromRemote) {
    if (idx < 0 || idx >= deck.length) return;
    current = idx;
    frame.src = deck[idx].file;
    counter.innerHTML = `${idx + 1} / ${deck.length}<span class="label">${deck[idx].label || ''}</span>`;
    try { localStorage.setItem(storageKey, String(idx)); } catch (_) {}
    if (location.hash !== '#' + (idx + 1)) {
      history.replaceState(null, '', '#' + (idx + 1));
    }
    // Update notes overlay if open
    updateNotesContent(idx);
    // Sync to presenter window via postMessage (works under file://)
    if (!fromRemote && presenterWin && !presenterWin.closed) {
      try { presenterWin.postMessage({ type: 'deck-go', idx: idx }, '*'); } catch (_) {}
    }
    // Also try BroadcastChannel (works under http/https)
    if (!fromRemote && bc) {
      bc.postMessage({ type: 'go', idx: idx });
    }
  }

  function next() { show(current + 1); }
  function prev() { show(current - 1); }

  /* ========== Notes overlay (N key) ========== */
  function updateNotesContent(idx) {
    if (slideMeta[idx] && slideMeta[idx].notes) {
      notesContent.innerHTML = slideMeta[idx].notes;
    } else {
      notesContent.innerHTML = '<span class="notes-empty">(No speaker notes for this slide)</span>';
    }
  }

  function toggleNotes(force) {
    const isOpen = force !== undefined ? force : !notesOverlay.classList.contains('open');
    notesOverlay.classList.toggle('open', isOpen);
    if (isOpen) {
      updateNotesContent(current);
    }
  }

  /* ========== Cross-window sync (presenter <-> main) ========== */
  // Receive from presenter window via postMessage
  window.addEventListener('message', function (e) {
    if (!e.data || e.data.type !== 'deck-go') return;
    if (typeof e.data.idx === 'number') {
      show(e.data.idx, true);
    }
  });
  // Also try BroadcastChannel (works under http/https)
  if (bc) {
    bc.onmessage = function (e) {
      if (!e.data) return;
      if (e.data.type === 'go' && typeof e.data.idx === 'number') {
        show(e.data.idx, true);
      }
    };
  }

  /* ========== PRESENTER MODE ========== */
  function openPresenterWindow() {
    if (presenterWin && !presenterWin.closed) {
      presenterWin.focus();
      return;
    }

    // Extract notes from current frame as fallback
    extractNotesFromFrame();

    const presenterHTML = buildPresenterHTML(
      W, H, slideMeta, deck.length, current, CHANNEL_NAME, LAYOUT_STORAGE_KEY
    );

    presenterWin = window.open('', 'deck-presenter', 'width=1280,height=820,menubar=no,toolbar=no');
    if (!presenterWin) {
      alert('Please allow pop-up windows to use Presenter View.\n\n请允许弹出窗口以使用演讲者视图。');
      return;
    }
    presenterWin.document.open();
    presenterWin.document.write(presenterHTML);
    presenterWin.document.close();
  }

  function buildPresenterHTML(deckW, deckH, meta, total, startIdx, channelName, layoutKey) {
    const metaJSON = JSON.stringify(meta);
    const deckWJSON = JSON.stringify(deckW);
    const deckHJSON = JSON.stringify(deckH);
    const channelJSON = JSON.stringify(channelName);
    const layoutKeyJSON = JSON.stringify(layoutKey);

    return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>Presenter View</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body {
    width: 100%; height: 100%; overflow: hidden;
    background: #1a1d24;
    background-image:
      radial-gradient(circle at 20% 30%, rgba(88,166,255,.04), transparent 50%),
      radial-gradient(circle at 80% 70%, rgba(188,140,255,.04), transparent 50%);
    color: #e6edf3;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans SC", "PingFang SC", sans-serif;
  }
  #stage { position: absolute; inset: 0; overflow: hidden; }

  /* Magnetic card */
  .pcard {
    position: absolute;
    background: #0d1117;
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,.45), 0 0 0 1px rgba(255,255,255,.02);
    display: flex; flex-direction: column;
    overflow: hidden;
    min-width: 180px; min-height: 100px;
    transition: box-shadow .2s, border-color .2s;
  }
  .pcard.dragging {
    box-shadow: 0 16px 48px rgba(0,0,0,.6), 0 0 0 2px rgba(88,166,255,.5);
    border-color: #58a6ff; transition: none; z-index: 9999;
  }
  .pcard.resizing {
    box-shadow: 0 16px 48px rgba(0,0,0,.6), 0 0 0 2px rgba(63,185,80,.5);
    border-color: #3fb950; transition: none; z-index: 9999;
  }
  .pcard:hover { border-color: rgba(88,166,255,.3); }

  /* Card header (drag handle) */
  .pcard-head {
    display: flex; align-items: center; gap: 10px;
    padding: 8px 12px;
    background: rgba(255,255,255,.04);
    border-bottom: 1px solid rgba(255,255,255,.06);
    cursor: move; user-select: none; flex-shrink: 0;
  }
  .pcard-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--dot-color, #58a6ff); flex-shrink: 0; }
  .pcard-title {
    font-size: 11px; letter-spacing: .15em; text-transform: uppercase;
    font-weight: 700; color: #8b949e; flex: 1;
  }
  .pcard-meta { font-size: 11px; color: #6e7681; font-variant-numeric: tabular-nums; }

  /* Card body */
  .pcard-body { flex: 1; position: relative; overflow: hidden; min-height: 0; }

  /* Preview cards (CURRENT / NEXT) -- iframe at native resolution, CSS scale */
  .pcard-preview .pcard-body { background: #000; }
  .pcard-preview iframe {
    position: absolute; top: 0; left: 0;
    border: none;
    transform-origin: top left;
    pointer-events: none;
    background: transparent;
  }
  .pcard-preview .preview-end {
    position: absolute; inset: 0;
    display: flex; align-items: center; justify-content: center;
    color: #484f58; font-size: 14px; letter-spacing: .12em;
  }

  /* Notes card */
  .pcard-notes .pcard-body {
    padding: 14px 18px; overflow-y: auto;
    font-size: 18px; line-height: 1.75;
    color: #d0d7de;
    font-family: "Noto Sans SC", "PingFang SC", -apple-system, sans-serif;
  }
  .pcard-notes .pcard-body p { margin: 0 0 .7em 0; }
  .pcard-notes .pcard-body strong { color: #f0883e; }
  .pcard-notes .pcard-body em { color: #58a6ff; font-style: normal; }
  .pcard-notes .pcard-body code {
    font-family: "SF Mono", "SF Mono", "Cascadia Code", monospace; font-size: .9em;
    background: rgba(255,255,255,.08); padding: 1px 6px; border-radius: 4px;
  }
  .pcard-notes .pcard-body .empty { color: #484f58; font-style: italic; }

  /* Timer card */
  .pcard-timer .pcard-body {
    display: flex; flex-direction: column; gap: 14px;
    padding: 18px 20px; justify-content: center;
  }
  .timer-display {
    font-family: "SF Mono", "SF Mono", "Cascadia Code", monospace;
    font-size: 42px; font-weight: 700;
    color: #3fb950; letter-spacing: .04em; line-height: 1;
  }
  .timer-row {
    display: flex; align-items: center; gap: 12px;
    font-size: 14px; color: #8b949e;
  }
  .timer-row .label { font-size: 10px; letter-spacing: .15em; text-transform: uppercase; color: #6e7681; }
  .timer-row .val { color: #e6edf3; font-weight: 600; font-family: "SF Mono", "SF Mono", "Cascadia Code", monospace; }
  .timer-controls { display: flex; gap: 8px; flex-wrap: wrap; }
  .timer-btn {
    background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.1);
    color: #e6edf3; padding: 6px 12px; border-radius: 6px;
    font-size: 12px; cursor: pointer; font-family: inherit;
  }
  .timer-btn:hover { background: rgba(88,166,255,.15); border-color: #58a6ff; }
  .timer-btn:active { transform: translateY(1px); }

  /* Resize handle */
  .pcard-resize {
    position: absolute; right: 0; bottom: 0;
    width: 18px; height: 18px; cursor: nwse-resize;
    background: linear-gradient(135deg, transparent 50%, rgba(255,255,255,.25) 50%, rgba(255,255,255,.25) 60%, transparent 60%, transparent 70%, rgba(255,255,255,.25) 70%, rgba(255,255,255,.25) 80%, transparent 80%);
    z-index: 5;
  }
  .pcard-resize:hover {
    background: linear-gradient(135deg, transparent 50%, #58a6ff 50%, #58a6ff 60%, transparent 60%, transparent 70%, #58a6ff 70%, #58a6ff 80%, transparent 80%);
  }

  /* Bottom hint bar */
  .hint-bar {
    position: fixed; bottom: 0; left: 0; right: 0;
    background: rgba(0,0,0,.6);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border-top: 1px solid rgba(255,255,255,.08);
    padding: 6px 16px;
    font-size: 11px; color: #8b949e;
    display: flex; gap: 18px; align-items: center;
    z-index: 1000;
  }
  .hint-bar kbd {
    background: rgba(255,255,255,.08);
    padding: 1px 6px; border-radius: 3px;
    font-family: "SF Mono", "SF Mono", "Cascadia Code", monospace;
    font-size: 10px;
    border: 1px solid rgba(255,255,255,.1);
    color: #e6edf3;
  }
  .hint-bar .reset-layout {
    margin-left: auto;
    background: transparent; border: 1px solid rgba(255,255,255,.15);
    color: #8b949e; padding: 3px 10px; border-radius: 4px;
    font-size: 11px; cursor: pointer; font-family: inherit;
  }
  .hint-bar .reset-layout:hover { background: rgba(248,81,73,.15); border-color: #f85149; color: #f85149; }

  body.is-dragging-card * { user-select: none !important; }
  body.is-dragging-card iframe { pointer-events: none !important; }
</style>
</head>
<body>

<div id="stage">
  <div class="pcard pcard-preview" id="card-cur" style="--dot-color:#58a6ff">
    <div class="pcard-head" data-drag>
      <span class="pcard-dot"></span>
      <span class="pcard-title">CURRENT</span>
      <span class="pcard-meta" id="cur-meta">—</span>
    </div>
    <div class="pcard-body"><iframe id="iframe-cur"></iframe></div>
    <div class="pcard-resize" data-resize></div>
  </div>

  <div class="pcard pcard-preview" id="card-nxt" style="--dot-color:#bc8cff">
    <div class="pcard-head" data-drag>
      <span class="pcard-dot"></span>
      <span class="pcard-title">NEXT</span>
      <span class="pcard-meta" id="nxt-meta">—</span>
    </div>
    <div class="pcard-body"><iframe id="iframe-nxt"></iframe></div>
    <div class="pcard-resize" data-resize></div>
  </div>

  <div class="pcard pcard-notes" id="card-notes" style="--dot-color:#f0883e">
    <div class="pcard-head" data-drag>
      <span class="pcard-dot"></span>
      <span class="pcard-title">SPEAKER SCRIPT · 逐字稿</span>
    </div>
    <div class="pcard-body" id="notes-body"></div>
    <div class="pcard-resize" data-resize></div>
  </div>

  <div class="pcard pcard-timer" id="card-timer" style="--dot-color:#3fb950">
    <div class="pcard-head" data-drag>
      <span class="pcard-dot"></span>
      <span class="pcard-title">TIMER</span>
    </div>
    <div class="pcard-body">
      <div class="timer-display" id="timer-display">00:00</div>
      <div class="timer-row">
        <span class="label">Slide</span>
        <span class="val" id="timer-count">1 / \${total}</span>
      </div>
      <div class="timer-controls">
        <button class="timer-btn" id="btn-prev">← Prev</button>
        <button class="timer-btn" id="btn-next">Next →</button>
        <button class="timer-btn" id="btn-reset">⏱ Reset</button>
      </div>
    </div>
    <div class="pcard-resize" data-resize></div>
  </div>
</div>

<div class="hint-bar">
  <span><kbd>← →</kbd> 翻页</span>
  <span><kbd>R</kbd> 重置计时</span>
  <span><kbd>Esc</kbd> 关闭</span>
  <span style="color:#6e7681">拖动卡片头部移动 · 拖动右下角调整大小</span>
  <button class="reset-layout" id="reset-layout">重置布局</button>
</div>

<script>
(function(){
  var slideMeta = ${metaJSON};
  var total = ${total};
  var idx = ${startIdx};
  var DECK_W = ${deckWJSON};
  var DECK_H = ${deckHJSON};
  var STORAGE_KEY = ${layoutKeyJSON};
  var bc;
  try { bc = new BroadcastChannel(${channelJSON}); } catch(e) {}

  var iframeCur = document.getElementById('iframe-cur');
  var iframeNxt = document.getElementById('iframe-nxt');
  var notesBody = document.getElementById('notes-body');
  var curMeta = document.getElementById('cur-meta');
  var nxtMeta = document.getElementById('nxt-meta');
  var timerDisplay = document.getElementById('timer-display');
  var timerCount = document.getElementById('timer-count');

  /* ===== Default card layout ===== */
  function defaultLayout() {
    var w = window.innerWidth;
    var h = window.innerHeight - 36;
    return {
      'card-cur':   { x: 16,        y: 16,            w: Math.round(w*0.55) - 24, h: Math.round(h*0.62) - 16 },
      'card-nxt':   { x: Math.round(w*0.55) + 8, y: 16, w: w - Math.round(w*0.55) - 24, h: Math.round(h*0.42) - 16 },
      'card-notes': { x: Math.round(w*0.55) + 8, y: Math.round(h*0.42) + 8, w: w - Math.round(w*0.55) - 24, h: h - Math.round(h*0.42) - 16 },
      'card-timer': { x: 16,        y: Math.round(h*0.62) + 8, w: Math.round(w*0.55) - 24, h: h - Math.round(h*0.62) - 16 }
    };
  }

  /* ===== Apply / save / restore layout ===== */
  function applyLayout(layout) {
    Object.keys(layout).forEach(function(id){
      var el = document.getElementById(id);
      var l = layout[id];
      if (el && l) {
        el.style.left = l.x + 'px';
        el.style.top = l.y + 'px';
        el.style.width = l.w + 'px';
        el.style.height = l.h + 'px';
      }
    });
    rescaleAll();
  }
  function readLayout() {
    try {
      var saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch(e) {}
    return defaultLayout();
  }
  function saveLayout() {
    var layout = {};
    ['card-cur','card-nxt','card-notes','card-timer'].forEach(function(id){
      var el = document.getElementById(id);
      if (el) {
        layout[id] = {
          x: parseInt(el.style.left, 10) || 0,
          y: parseInt(el.style.top, 10) || 0,
          w: parseInt(el.style.width, 10) || 300,
          h: parseInt(el.style.height, 10) || 200
        };
      }
    });
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(layout)); } catch(e) {}
  }

  /* ===== iframe rescale to fit card body ===== */
  function rescaleIframe(iframe) {
    if (!iframe || iframe.style.display === 'none') return;
    var body = iframe.parentElement;
    var cw = body.clientWidth, ch = body.clientHeight;
    if (!cw || !ch) return;
    iframe.style.width = DECK_W + 'px';
    iframe.style.height = DECK_H + 'px';
    var s = Math.min(cw / DECK_W, ch / DECK_H);
    iframe.style.transform = 'scale(' + s + ')';
    var sw = DECK_W * s, sh = DECK_H * s;
    iframe.style.left = Math.max(0, (cw - sw) / 2) + 'px';
    iframe.style.top = Math.max(0, (ch - sh) / 2) + 'px';
  }
  function rescaleAll() {
    rescaleIframe(iframeCur);
    rescaleIframe(iframeNxt);
  }
  window.addEventListener('resize', rescaleAll);

  /* ===== Drag (move card by header) ===== */
  document.querySelectorAll('[data-drag]').forEach(function(handle){
    handle.addEventListener('mousedown', function(e){
      if (e.button !== 0) return;
      var card = handle.closest('.pcard');
      if (!card) return;
      e.preventDefault();
      card.classList.add('dragging');
      document.body.classList.add('is-dragging-card');
      var startX = e.clientX, startY = e.clientY;
      var startL = parseInt(card.style.left, 10) || 0;
      var startT = parseInt(card.style.top, 10) || 0;
      function onMove(ev){
        var nx = Math.max(0, Math.min(window.innerWidth - 100, startL + ev.clientX - startX));
        var ny = Math.max(0, Math.min(window.innerHeight - 50, startT + ev.clientY - startY));
        card.style.left = nx + 'px';
        card.style.top = ny + 'px';
      }
      function onUp(){
        card.classList.remove('dragging');
        document.body.classList.remove('is-dragging-card');
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        saveLayout();
      }
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  });

  /* ===== Resize (drag bottom-right corner) ===== */
  document.querySelectorAll('[data-resize]').forEach(function(handle){
    handle.addEventListener('mousedown', function(e){
      if (e.button !== 0) return;
      var card = handle.closest('.pcard');
      if (!card) return;
      e.preventDefault(); e.stopPropagation();
      card.classList.add('resizing');
      document.body.classList.add('is-dragging-card');
      var startX = e.clientX, startY = e.clientY;
      var startW = parseInt(card.style.width, 10) || card.offsetWidth;
      var startH = parseInt(card.style.height, 10) || card.offsetHeight;
      function onMove(ev){
        var nw = Math.max(180, startW + ev.clientX - startX);
        var nh = Math.max(100, startH + ev.clientY - startY);
        card.style.width = nw + 'px';
        card.style.height = nh + 'px';
        if (card.querySelector('iframe')) rescaleIframe(card.querySelector('iframe'));
      }
      function onUp(){
        card.classList.remove('resizing');
        document.body.classList.remove('is-dragging-card');
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        rescaleAll();
        saveLayout();
      }
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  });

  /* ===== Update content ===== */
  function update(n) {
    n = Math.max(0, Math.min(total - 1, n));
    idx = n;

    /* Current preview */
    if (slideMeta[n]) {
      iframeCur.src = slideMeta[n].file;
    }
    curMeta.textContent = (n + 1) + ' / ' + total;

    /* Next preview */
    if (n + 1 < total) {
      iframeNxt.style.display = '';
      var endEl = document.querySelector('#card-nxt .preview-end');
      if (endEl) endEl.remove();
      if (slideMeta[n + 1]) {
        iframeNxt.src = slideMeta[n + 1].file;
      }
      nxtMeta.textContent = (n + 2) + ' / ' + total;
    } else {
      iframeNxt.style.display = 'none';
      var body = document.querySelector('#card-nxt .pcard-body');
      if (body && !body.querySelector('.preview-end')) {
        var end = document.createElement('div');
        end.className = 'preview-end';
        end.textContent = '— END OF DECK —';
        body.appendChild(end);
      }
      nxtMeta.textContent = 'END';
    }

    /* Notes */
    var note = slideMeta[n] && slideMeta[n].notes;
    notesBody.innerHTML = note || '<span class="empty">（这一页还没有逐字稿）</span>';

    /* Timer count */
    timerCount.textContent = (n + 1) + ' / ' + total;
  }

  /* ===== Timer ===== */
  var tStart = Date.now();
  var timerInterval = setInterval(function(){
    var s = Math.floor((Date.now() - tStart) / 1000);
    var mm = String(Math.floor(s / 60)).padStart(2, '0');
    var ss = String(s % 60).padStart(2, '0');
    timerDisplay.textContent = mm + ':' + ss;
  }, 1000);
  function resetTimer() {
    tStart = Date.now();
    timerDisplay.textContent = '00:00';
  }

  /* ===== Sync to main window ===== */
  function go(n) {
    n = Math.max(0, Math.min(total - 1, n));
    update(n);
    // postMessage to opener (works under file://)
    try { window.opener.postMessage({ type: 'deck-go', idx: n }, '*'); } catch(e) {}
    // Also try BroadcastChannel (works under http/https)
    if (bc) bc.postMessage({ type: 'go', idx: n });
  }
  /* ===== Receive from main window ===== */
  window.addEventListener('message', function(e) {
    if (!e.data || e.data.type !== 'deck-go') return;
    if (typeof e.data.idx === 'number') update(e.data.idx);
  });
  if (bc) {
    bc.onmessage = function(e){
      if (!e.data) return;
      if (e.data.type === 'go') {
        update(e.data.idx);
      }
    };
  }

  /* ===== Buttons ===== */
  document.getElementById('btn-prev').addEventListener('click', function(){ go(idx - 1); });
  document.getElementById('btn-next').addEventListener('click', function(){ go(idx + 1); });
  document.getElementById('btn-reset').addEventListener('click', resetTimer);
  document.getElementById('reset-layout').addEventListener('click', function(){
    if (confirm('恢复默认卡片布局？')) {
      try { localStorage.removeItem(STORAGE_KEY); } catch(e){}
      applyLayout(defaultLayout());
    }
  });

  /* ===== Keyboard ===== */
  document.addEventListener('keydown', function(e){
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    switch(e.key) {
      case 'ArrowRight': case ' ': case 'PageDown': go(idx + 1); e.preventDefault(); break;
      case 'ArrowLeft':  case 'PageUp':   go(idx - 1); e.preventDefault(); break;
      case 'Home': go(0); break;
      case 'End':  go(total - 1); break;
      case 'r': case 'R': resetTimer(); break;
      case 'Escape': window.close(); break;
    }
  });

  /* ===== Iframe load -> rescale ===== */
  iframeCur.addEventListener('load', function(){ rescaleIframe(iframeCur); });
  iframeNxt.addEventListener('load', function(){ rescaleIframe(iframeNxt); });

  /* ===== Init ===== */
  applyLayout(readLayout());
  update(idx);
})();
</` + `script>
</body></html>`;
  }

  /* ========== Keyboard handler ========== */
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    switch (e.key) {
      case 'ArrowRight': case ' ': case 'PageDown': e.preventDefault(); next(); break;
      case 'ArrowLeft':  case 'PageUp':              e.preventDefault(); prev(); break;
      case 'Home':                                    e.preventDefault(); show(0); break;
      case 'End':                                     e.preventDefault(); show(deck.length - 1); break;
      case 's': case 'S':                             openPresenterWindow(); break;
      case 'n': case 'N':                             toggleNotes(); break;
      case 'Escape':                                  toggleNotes(false); break;
      default:
        if (e.key >= '1' && e.key <= '9') {
          const i = parseInt(e.key, 10) - 1;
          if (i < deck.length) { e.preventDefault(); show(i); }
        }
    }
  });

  /* ========== Click zones ========== */
  document.getElementById('navL').addEventListener('click', prev);
  document.getElementById('navR').addEventListener('click', next);
  window.addEventListener('resize', fit);

  /* ========== Hash deep-linking ========== */
  window.addEventListener('hashchange', () => {
    const m = location.hash.match(/^#(\d+)$/);
    if (m) show(parseInt(m[1], 10) - 1, true);
  });

  // Restore position from hash or localStorage
  const hashMatch = location.hash.match(/^#(\d+)$/);
  if (hashMatch) {
    current = Math.min(parseInt(hashMatch[1], 10) - 1, deck.length - 1);
  } else {
    try {
      const v = parseInt(localStorage.getItem(storageKey), 10);
      if (!isNaN(v) && v >= 0 && v < deck.length) current = v;
    } catch (_) {}
  }

  fit();
  show(current);

  /* ========== Extract notes from loaded slides (frame load) ========== */
  frame.addEventListener('load', () => {
    extractNotesFromFrame();
  });

  /* ========== Print support ========== */
  window.addEventListener('beforeprint', () => {
    printStack.innerHTML = '';
    deck.forEach(item => {
      const f = document.createElement('iframe');
      f.src = item.file;
      printStack.appendChild(f);
    });
    printStack.style.display = 'block';
    document.getElementById('stage').style.display = 'none';
  });
  window.addEventListener('afterprint', () => {
    printStack.innerHTML = '';
    printStack.style.display = 'none';
    document.getElementById('stage').style.display = '';
  });
})();
