# dir-key-nav-minimal — Slide Role Catalog

> **模板气质**：极简暗色基调，8 种单页独立背景色（indigo / cream / crimson / emerald / slate / violet / white / charcoal），超大号无衬线标题排版，mono 字体功能文字，水平分隔线装饰，单一关键词高亮色强调。方向键驱动叙事，一页一背景、一页一焦点。
> **默认 color-scheme**：8-color rotation（no single default；cover 起手 t-indigo，依次切换至 t-charcoal 收尾）
> **适用文稿类型**：技术演讲、产品发布、极简故事线叙事、conference talk、内部提案
> **叙事结构**：Cover → Agenda → Section → List → Compare → Diagram → Steps → Code → Stats → Chart → Quote → CTA → Thanks

## 角色索引
| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 封面页，大标题 + 副标题 + 引导语 | eyebrow, dk-h0, dk-line, dk-lede |
| 02 | `agenda` | 目录/议程页，标题 + 双列编号清单 | eyebrow, dk-h1, dk-toc(5 item) |
| 03 | `section_divider` | 章节分隔页，章节编号 + 核心论点 | eyebrow, dk-h0, dk-line, dk-lede |
| 04 | `content_list` | 内容列表页，标题 + 4 条箭头列表 | eyebrow, dk-h1, dk-list(4 li) |
| 05 | `content_compare` | 内容对比页，标题 + 导语 + 2 列对比 | eyebrow, dk-h1, dk-lede, dk-grid-2(2 dk-col) |
| 06 | `content_diagram` | 概念示意图页，标题 + 内联单色 SVG + 说明 | eyebrow, dk-h2, dk-diagram(svg), dk-lede |
| 07 | `content_steps` | 步骤/时间线页，标题 + 3 步带连接竖线 | eyebrow, dk-h1, dk-steps(3 li) |
| 08 | `content_code` | 代码展示页，标题 + 代码块 + 说明 | eyebrow, dk-h2, dk-code, dk-lede |
| 09 | `content_stats` | 多数据 KPI 页，标题 + 2×2 大字数字 | eyebrow, dk-h2, dk-stats(4 dk-stat) |
| 10 | `content_chart` | 数据图表页，大字数字 + 水平条形图 + 说明 | eyebrow, dk-big, dk-lede, SVG bar |
| 11 | `content_quote` | 大字引用页，serif 引语 + 归属 | dk-quote(blockquote + .attr) |
| 12 | `content_cta` | 行动号召页，标题 + 导语 + 终端命令代码块 | eyebrow, dk-h1, dk-line, dk-lede, dk-code |
| 13 | `thanks` | 结束致谢页，大字致谢 + 补充信息 | eyebrow, dk-h0, dk-line, dk-lede |

## 角色详情
### `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`eyebrow`, `cover_title`, `cover_lede`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-indigo`）、`dk-snum`（页码）、`dk-line`（装饰线）、`dk-keyhint`（进度标签 `opening · 00 / 04`）、`dk-page`（页脚标签）、`<span class="dk-accent">` 的模式保留（作为设计语言的一环，替换文本时需重现该结构）
- **标题规则（重要）**：`cover_title` **不写 `<br>`**，纯文本 + 一个 `<span class="dk-accent">` 高亮词。`.dk-h0` 的 `max-width:1050px` + `text-wrap:balance` 会自动把 6–10 字标题平衡成两行（如「笔记治不了 / LLM」）。标题控制在 6–10 字即可稳定两行；勿手填 `<br>`。
- **内容适配规则**：标题使用 `<span class="dk-accent">` 包裹 1 个关键词进行高亮；`cover_lede` 约 2-3 行中文（不再含「按 → 继续」之类的键盘引导，键盘提示统一由 `index.html` 底部 hint-bar 承载）；`eyebrow` 为全大写简短标签（英文 2-4 词）
- **卡片扩展/收缩**：不适用

### `agenda`
- **源文件**：`slides/02-agenda.html`
- **可替换键**：`eyebrow`, `section_heading`, `toc_num_1..5`, `toc_title_1..5`, `toc_desc_1..5`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-white`）、`dk-snum`、`<div class="dk-toc">`（双列网格容器）、`dk-keyhint`、`dk-page`、条目数固定为 5
- **内容适配规则**：`section_heading` 用 `<span class="dk-accent">` 高亮关键词，自然换行不写 `<br>`；每条 `toc_num` 为 mono 编号（01-05），`toc_title` 为 4-8 字章节名，`toc_desc` 为一句（≤15 字）补充
- **卡片扩展/收缩**：条目数固定为 5，不可增减

### `section_divider`
- **源文件**：`slides/03-section.html`
- **可替换键**：`section_eyebrow`, `section_title`, `section_lede`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-cream`）、`dk-snum`、`dk-line`、`dk-keyhint`、`dk-page`
- **内容适配规则**：`section_eyebrow` 为章节编号（如 "Chapter 01"）或阶段标签；`section_title` 为章节核心论点，使用 `<span class="dk-accent">` 高亮关键词，自然换行；`section_lede` 为 1-2 句补充说明。t-cream 背景为浅色，文字为深色，accent 自动变为 #B5392A
- **卡片扩展/收缩**：不适用

### `content_list`
- **源文件**：`slides/04-content.html`
- **可替换键**：`eyebrow`, `section_heading`, `list_item_1`, `list_item_2`, `list_item_3`, `list_item_4`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-crimson`）、`dk-snum`、`<ul class="dk-list">`（列表容器）、`dk-keyhint`、`dk-page`、列表项数量固定为 4
- **内容适配规则**：`section_heading` 为 1-2 行中文标题，使用 `<span class="dk-accent">` 高亮关键词，**不写 `<br>`**（`.dk-h1` 的 max-width:850px + balance 自动平衡成两行）；每个 `list_item` 为一条中文陈述句，长度控制在 20-30 字。箭头符号（→）由 CSS `::before` 伪元素生成，不可替换
- **卡片扩展/收缩**：列表项数目固定为 4，不可增减

### `content_compare`
- **源文件**：`slides/05-content.html`
- **可替换键**：`eyebrow`, `section_heading`, `lede`, `col_1_heading`, `col_1_body`, `col_2_heading`, `col_2_body`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-emerald`）、`dk-snum`、`dk-grid-2`（2 列网格容器）、`dk-col`（列容器 div）、`dk-keyhint`、`dk-page`
- **内容适配规则**：`col_1_heading` 为否定/旧方案（带 × 前缀），`col_2_heading` 为肯定/新方案（带 ✓ 前缀）；每列 body 为 1-2 句说明；`lede` 为导入语，约 2 行中文；`section_heading` 使用 `<span class="dk-accent">` 高亮关键词
- **卡片扩展/收缩**：列数固定为 2，不可增减

### `content_diagram`
- **源文件**：`slides/06-diagram.html`
- **可替换键**：`eyebrow`, `section_heading`, `diagram_svg`, `lede`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-slate`）、`dk-snum`、`<div class="dk-diagram">` 容器、`dk-keyhint`、`dk-page`
- **SVG 规则（重要）**：`diagram_svg` 为**内联单色 SVG**，全部图形用 CSS class 着色——连线用 `.stroke` / `.stroke-dash`（`stroke=currentColor`，虚线用于弱关系），节点用 `.node` / `.node-accent`（描边、近透明填充），文字用 `.lbl` / `.lbl-accent`。**禁止 `<img>`、禁止位图、禁止内联 `fill="#hex"` 写死颜色**（颜色必须经 class + currentColor/`--dk-accent-current` 跟随主题）。默认是 hub-spoke 4 叶节点示意，可按内容改成分层、流程、关系图，但保持线稿单色风。
- **内容适配规则**：`section_heading` 用 `<span class="dk-accent">` 高亮关键词；`lede` 为 1-2 句解读
- **卡片扩展/收缩**：SVG 节点数建议 3-6 个，过多则拥挤

### `content_steps`
- **源文件**：`slides/07-steps.html`
- **可替换键**：`eyebrow`, `section_heading`, `step_num_1..3`, `step_title_1..3`, `step_desc_1..3`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-violet`）、`dk-snum`、`<ol class="dk-steps">`（步骤容器，左侧连接竖线由 `::before` 生成）、`dk-keyhint`、`dk-page`、步骤数固定为 3
- **内容适配规则**：`section_heading` 用 `<span class="dk-accent">` 高亮关键词，自然换行；每步 `step_num` 为 mono 编号（01-03），`step_title` 为 4-8 字，`step_desc` 为一句（≤25 字）说明。连接竖线随主题色，编号背景用 `--dk-bg` 自动遮断
- **卡片扩展/收缩**：步骤数固定为 3，不可增减

### `content_code`
- **源文件**：`slides/08-code.html`
- **可替换键**：`eyebrow`, `section_heading`, `code_block`, `lede`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-slate`）、`dk-snum`、`<pre class="dk-code">`（代码块容器，保留 class）、`dk-keyhint`、`dk-page`
- **内容适配规则**：`code_block` 为 YAML / 配置 / 代码片段，保留原始缩进格式，建议 4-6 行；`section_heading` 使用 `<span class="dk-accent">` 高亮关键词；`lede` 为 1-2 句补充说明
- **卡片扩展/收缩**：代码块高度随内容自动扩展，建议不超过 8 行以保持视觉平衡

### `content_stats`
- **源文件**：`slides/09-stats.html`
- **可替换键**：`eyebrow`, `section_heading`, `stat_num_1..4`, `stat_label_1..4`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-emerald`）、`dk-snum`、`<div class="dk-stats">`（2×2 网格）、`dk-stat`（单格容器）、`dk-keyhint`、`dk-page`、格子数固定为 4
- **内容适配规则**：`section_heading` 用 `<span class="dk-accent">` 高亮关键词；每格 `stat_num` 为大字数字（mono，跟随 accent 色），可用 `<span style="font-size:.5em">` 做单位（如 `min`、`%`）；`stat_label` 为一句（≤15 字）说明
- **卡片扩展/收缩**：格子数固定为 4，不可增减

### `content_chart`
- **源文件**：`slides/10-chart.html`
- **可替换键**：`eyebrow`, `big_number`, `lede`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-violet`）、`dk-snum`、`<svg>` 条形图元素（含 `rect` 和 `text`，仅可调整 `width` 数值和 `text` 内容）、`dk-keyhint`、`dk-page`
- **内容适配规则**：`big_number` 为百分比或大数字（如 "87%"）；`lede` 为 2 行数据解读说明；SVG 条形图中 `rect` 的 `width` 和对应的 `<text>` 内容需与 `big_number` 保持一致
- **卡片扩展/收缩**：SVG 条形图宽度需与 big_number 数值匹配
- **与 stats 的区别**：本页强调**单一**核心数字 + 进度条；多数字并列用 `content_stats`

### `content_quote`
- **源文件**：`slides/11-quote.html`
- **可替换键**：`quote_text`（含可选 `<span class="dk-accent">` 高亮 + 可选 `<span class="attr">` 归属）
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-charcoal`）、`dk-snum`、`<blockquote class="dk-quote">`（引用容器，serif 字体 + 左侧 accent 竖线）、`dk-keyhint`、`dk-page`
- **内容适配规则**：`quote_text` 为一句金句/引语（serif 大字，建议 1-2 行，10-30 字），用 `<span class="dk-accent">` 高亮半句；归属用 `<span class="attr">— 来源</span>` 放在引语末尾（mono 小字）。本页无 eyebrow/h1，纯引语居中，制造「停顿」节奏
- **卡片扩展/收缩**：不适用

### `content_cta`
- **源文件**：`slides/12-cta.html`
- **可替换键**：`eyebrow`, `section_heading`, `lede`, `code_block`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-white`）、`dk-snum`、`dk-line`、`<pre class="dk-code">`（代码块容器）、`dk-keyhint`、`dk-page`
- **内容适配规则**：`code_block` 为终端命令（shell 代码块），建议 3-5 行，保留 `$` 前缀；`section_heading` 使用 `<span class="dk-accent">` 高亮关键词；`lede` 为 1-2 句中文号召语
- **卡片扩展/收缩**：代码块建议不超过 5 行

### `thanks`
- **源文件**：`slides/13-thanks.html`
- **可替换键**：`eyebrow`, `thanks_title`, `thanks_lede`
- **不可改动**：`body` 元素（`tpl-dir-key-nav-minimal t-charcoal`）、`dk-snum`、`dk-line`、`dk-keyhint`（进度标签 `closing · 04 / 04`）、`dk-page`
- **内容适配规则**：`thanks_title` 为致谢语（如 "谢谢"、"Thank You"），使用 `<span class="dk-accent">` 高亮关键词；`eyebrow` 为结束标签；`thanks_lede` 为 1-2 句补充信息，可含链接或联系信息（不再含键盘引导）
- **卡片扩展/收缩**：不适用

## 角色匹配决策树
1. **需要一个强有力的开场** → 使用 `cover`（封面大标题 + 引导语）
2. **需要在开场后给出全篇路线图** → 使用 `agenda`（双列编号目录）
3. **需要划分章节/引出新话题** → 使用 `section_divider`（章节分隔 + 核心论点）
4. **需要列出多个要点（4 条）** → 使用 `content_list`（标题 + 箭头列表）
5. **需要对比两个方案/观点** → 使用 `content_compare`（2 列正反对比）
6. **需要展示概念关系/结构示意** → 使用 `content_diagram`（内联单色 SVG 示意图）
7. **需要展示顺序步骤/流程/时间线** → 使用 `content_steps`（编号步骤 + 连接竖线）
8. **需要展示配置 / 代码 / 命令** → 使用 `content_code` 或 `content_cta`（代码块 + 说明）
9. **需要并列展示多个数据指标** → 使用 `content_stats`（2×2 大字 KPI）
10. **需要强调单一核心数据 + 进度** → 使用 `content_chart`（大字数字 + 条形图）
11. **需要一句金句/引语做停顿** → 使用 `content_quote`（serif 大字引用）
12. **需要收尾致谢** → 使用 `thanks`（大字致谢 + 补充信息）
13. **CTA 带终端命令** → 使用 `content_cta`（t-white 背景更醒目的命令展示）

## Style Transfer — T2 页面继承规则
### 空间密度对齐
- 所有页面统一使用 `padding: 106px 154px`，上下留白充裕
- 内容区 `.dk-snum` 固定右上角，`.dk-keyhint` 固定左下角，`.dk-page` 固定右下角
- 正文区域通过 `margin:auto 0` 垂直居中（`content_quote` 例外：引语本身 `margin:auto 0`）

### 标题与断行规则（全局）—— 换行由 CSS 接管，不写 `<br>`
- **核心原则：换行是版式决策，不是内容决策。** 生成标题时**只产出纯文本**（含一个 `<span class="dk-accent">` 高亮词），**绝不写 `<br>`**。断行由 CSS 三层组合拳自动决定，落点尽量在 CJK 词边界：
  1. `word-break: keep-all` — 用浏览器 CJK 分词(UAX#29)只在**词边界**允许断，而非任意两字之间
  2. `text-wrap: balance` — 在所有允许的断点里挑**最平衡**的位置
  3. `overflow-wrap: break-word` — **兜底**：keep-all 分词失败/词太长时强制断，绝不溢出
- 各标题类的「目标行数 + max-width + 字数预算」：

  | 类 | 字号 | max-width | 目标行数 | 字数预算（中文计） |
  |----|------|-----------|----------|--------------------|
  | `dk-h0` | 213px | 1050px | 2 行（短句如「謝謝。」1 行） | 6–10 字 |
  | `dk-h1` | 133px | 850px | 2 行 | 9–14 字 |
  | `dk-h2` | 96px | 1100px | 1 行（仅超长才折） | 6–12 字 |

- **字数预算是第二道闸**：把标题长度压在预算内，让 `keep-all + balance` 的断点稳定落在语义处（如「笔记治不了 / LLM」「接下来要讲的 / 五件事」「答案不是更大 / 的窗口」）。
- **`<wbr>` 是精修逃生口（重要）**：浏览器 CJK 分词对新词/复合词可能误判（例：把「三步把它装上背」的"装上背"当一个词 → 断成"三步把它装上 / 背"，把高亮词"背"孤立到行尾）。**遇到此类 keep-all 误判，在该断的字之间插一个 `<wbr>`（折行机会标记）即可**——它只在需要时才断，比 `<br>`（强制断）安全得多。例：`三步把它<wbr>装上 <span class="dk-accent">背</span>` → 「三步把它 / 装上背」。`<wbr>` 是人工精修手段，**只修标题，不进 body 内容**；仍**不写 `<br>`**。
- 关键词高亮统一用 `<span class="dk-accent">`，accent 色随背景自动切换。

### 装饰模式继承
- `dk-line` 装饰横线（宽 133px，高 6px）用于 cover / section_divider / content_cta / thanks 页面
- `dk-accent` 关键词高亮色随背景色自动切换（由 tokens.css 中的 per-theme accent 规则控制）
- `dk-eyebrow` 右侧有 `::after` 伪元素装饰线（max-width 177px）

### 组件类名统一
- 所有样式类名前缀统一为 `dk-`（dir-key 缩写）
- 排版类名：`dk-eyebrow`, `dk-h0`, `dk-h1`, `dk-h2`, `dk-lede`, `dk-big`, `dk-quote`(serif)
- 布局类名：`dk-grid-2`, `dk-col`, `dk-list`, `dk-toc`, `dk-steps`, `dk-stats`, `dk-diagram`
- 代码类名：`dk-code`
- 装饰类名：`dk-line`, `dk-accent`, `dk-snum`, `dk-keyhint`, `dk-page`
- per-theme 变量：`--dk-accent-current`（accent 色）、`--dk-bg`（背景色，用于 steps 编号遮断连接线）

### 排版层级对齐
- `dk-h0`：213px / 900 weight / -5px letter-spacing / max-width 1050px / 目标 2 行（封面和章节分隔专用）
- `dk-h1`：133px / 900 weight / -3px letter-spacing / max-width 850px / 目标 2 行（内容页主标题）
- `dk-h2`：96px / 800 weight / -2px letter-spacing / max-width 1100px / 目标 1 行（diagram / code / stats / chart 页标题）
- `dk-lede`：35px / 300 weight / 0.72 opacity（导语/说明）
- `dk-eyebrow`：16px / 700 weight / 3.5px letter-spacing / 0.55 opacity（标签行）
- `dk-big`：319px / 800 weight / mono font（大字数字，仅 chart 页）
- `dk-quote`：85px / 600 weight / serif font（引用页专用编辑式衬线）

### 导航提示规则
- **页内不再出现键盘符号**（`←` `→` `space` `F` 等 `<kbd>` 元素）
- `dk-keyhint` 现统一为角色/进度标签：`opening · 00/04`（cover）、`agenda · 5 items`、`content · list/compare/diagram/steps/code`、`content · stats`、`chart · big-num`、`content · quote`、`cta · three-commands`、`closing · 04/04`（thanks）
- 键盘快捷键由 `index.html` 底部 hint-bar 统一承载（← → / F / N / Esc）

### 禁止引入的视觉元素
- **禁止位图 / 外部图片 / `<img>`**；**唯一允许的「插图」是 `content_diagram` 角色里的内联单色 SVG 线条示意图**（`stroke=currentColor`/`--dk-accent-current`，无填充位图，贴合极简 DNA）
- SVG 示意图**仅限** `content_diagram` 角色，其它角色不得引入 SVG 图形
- 禁止使用卡片组件（`.card`, `.card-soft` 等，此模板无卡片概念）
- 禁止使用网格布局超过 2 列（`dk-grid-2` / `dk-toc` / `dk-stats` 均为 2 列上限）
- 禁止添加 `<style>` 块（所有样式由 `shared/tokens.css` 统一管理）
- 禁止修改 `dk-keyhint` 和 `dk-page` 的固定位置布局
- 动效：中档强度（kicker fade / 标题 fade-up-soft / 列表 stagger），仅用 .anim-fade / .anim-fade-up-soft / .anim-dN，不用 rise/zoom/blur（保持极简调性）
- 禁止在非 design token 指定的元素上使用内联颜色值（SVG 颜色经 class + currentColor，不写死 hex）
