#!/usr/bin/env node
// check-spec-capacity.mjs — Pre-generation capacity checker
// Reads specs/*.md files and estimates content height vs available height.
// Catch overflow risks before subagents generate HTML.
// --style <name> enables space strategy suggestions for sparse pages.
//
// --outline <outline.md> (Phase 2.3): check capacity directly from an outline's
// `[visual: <type>]` + `[card-bg: N]` tags, before specs/ exist. Lets the main
// agent run a half-automated capacity check during storyline planning instead
// of eyeballing LAYOUT_BUDGETS by hand.

'use strict';

import { readdirSync, readFileSync, writeFileSync, existsSync } from 'fs';
import { join, resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Space strategies by style preset (lightweight inline version;
// full definitions in references/style-presets.md)
const SPACE_STRATEGIES = {
  'visual-amplify': {
    name: '视觉放大',
    applies: ['pitch-deck', 'product-launch', 'dir-key-nav-minimal', 'graphify-dark-graph'],
    actions: [
      '.card padding: 26→48px',
      'h2.title: fs-h2→fs-h1',
      'page-body gap: 20→40px',
      'grid gap: 24→40px',
      '装饰升级：.card→.card-elevated',
      '加 .ambient-glow-tr + .ambient-glow-bl',
    ],
  },
  'content-enrich': {
    name: '内容丰富',
    applies: ['weekly-report', 'course-module', 'tech-sharing', 'testing-safety-alert',
              'knowledge-arch-blueprint', 'hermes-cyber-terminal', 'obsidian-claude-gradient'],
    actions: [
      '为每个要点补充子信息（负责人、日期、关联指标）',
      '考虑布局降格（3列→2列，每列更宽）',
      '底部加 .kpi-grid 汇总行或辅助信息条',
    ],
  },
  'whitespace-keep': {
    name: '留白保留',
    applies: ['xhs-pastel-card', 'xhs-white-editorial'],
    actions: [
      '不做填充——留白是设计意图',
      '可选：字号微调 fs-h2→fs-h1',
    ],
  },
  'medium-default': {
    name: '中等密度默认',
    applies: ['presenter-mode-reveal'],
    actions: [
      '间距微调：gap: 20→28px',
      '可选：字号微调一档',
    ],
  },
};

function getStrategyForStyle(style) {
  for (const [key, strategy] of Object.entries(SPACE_STRATEGIES)) {
    if (strategy.applies.includes(style)) return { key, ...strategy };
  }
  return SPACE_STRATEGIES['content-enrich']; // default fallback
}

// Heights for layout types referenced in spec files (approximate, including padding)
const LAYOUT_BUDGETS = {
  'L06': { itemsPerUnit: 70, name: '要点列表', maxItems: 5 },
  'L07': { itemsPerUnit: 400, name: '双栏' },
  'L08': { itemsPerUnit: 300, name: '三栏', maxItems: 3 },
  'L11': { itemsPerUnit: 150, name: 'KPI网格', maxItems: 4 },
  'L12': { rowsPerUnit: 42, name: '表格', maxRows: 7 },
  'L13': { itemsPerUnit: 320, name: '柱状图' },
  'L15': { itemsPerUnit: 200, name: '环形图' },
  'L17': { itemsPerUnit: 140, name: '流程图', maxItems: 5 },
  'L18': { itemsPerUnit: 80, name: '时间线', maxItems: 5 },
  'L21': { itemsPerUnit: 300, name: '架构图' },
  'L22': { itemsPerUnit: 200, name: '步骤图', maxItems: 4 },
  'L23': { itemsPerUnit: 80, name: '甘特图', maxItems: 8 },
  'L31': { itemsPerUnit: 60, name: '待办清单', maxItems: 8 },
};

// Visual type → fixed-slot layout code (for --outline mode).
// Only common Phase 2.3 visual tags that map cleanly to a layout with
// maxItems/maxRows are listed. Unmapped visual types fall through to a
// "skip with hint" line rather than erroring — the main agent still has
// to judge those manually.
// Sources: layout-catalog-index.md + storyline-guide.md visual tags.
const VISUAL_TO_LAYOUT = {
  'stat-grid':        'L11', // KPI 网格 maxItems 4
  'feature-cards':    'L06', // 要点列表 maxItems 5
  'problem-cards':    'L06', // 要点列表 maxItems 5
  'recommendation':   'L06', // 要点列表 maxItems 5
  'comparison':       'L08', // 三栏 maxItems 3
  'process-flow':     'L17', // 流程图 maxItems 5
  'flow-infographic': 'L17', // 流程图 maxItems 5
  'loop-infographic': 'L17', // 流程图（闭环）maxItems 5
  'timeline':         'L18', // 时间线 maxItems 5
  'next-steps':       'L22', // 步骤图 maxItems 4
  'gantt':            'L23', // 甘特图 maxItems 8
};

const HEADER_HEIGHT = 100;
const FOOTER_HEIGHT = 84;
const DEFAULT_GAP = 20;
const AVAILABLE_HEIGHT = 1080 - HEADER_HEIGHT - FOOTER_HEIGHT;

function parseSpec(content) {
  const layoutMatch = content.match(/- 布局：\s*(L\d+)/);
  const skeletonMatch = content.match(/骨架：\s*\[([A-D])\]/);
  const itemsMatch = content.match(/当前内容[量]*[：:]\s*(\d+)\s*项/);
  const rowsMatch = content.match(/当前内容[量]*[：:]\s*(\d+)\s*行/);
  const cardsMatch = content.match(/当前内容[量]*[：:]\s*(\d+)\s*卡/);
  const compactMatch = content.match(/需\s*compact[-_]?header/);
  const splitMatch = content.match(/需\s*拆分/);
  const fillRateMatch = content.match(/填充率[：:]\s*(\d+)%/);
  const needCompactNew = content.match(/🔴\s*需\s*compact/);
  const needSplitNew = content.match(/❌\s*需\s*拆分/);

  return {
    layout: layoutMatch ? layoutMatch[1] : null,
    skeleton: skeletonMatch ? skeletonMatch[1] : 'A',
    items: itemsMatch ? parseInt(itemsMatch[1]) : null,
    rows: rowsMatch ? parseInt(rowsMatch[1]) : null,
    cards: cardsMatch ? parseInt(cardsMatch[1]) : null,
    needsCompact: !!compactMatch || !!needCompactNew,
    needsSplit: !!splitMatch || !!needSplitNew,
    fillRate: fillRateMatch ? parseInt(fillRateMatch[1]) : null,
  };
}

function estimateSpecHeight(layout, spec) {
  const budget = LAYOUT_BUDGETS[layout];
  if (!budget) return null;

  let height = 0;
  let count = 0;

  if (budget.itemsPerUnit) {
    count = spec.items || spec.cards || 1;
    height = count * budget.itemsPerUnit;
  }
  if (budget.rowsPerUnit) {
    count = spec.rows || 1;
    height = count * budget.rowsPerUnit;
  }

  if (count > 1) height += (count - 1) * DEFAULT_GAP;

  if (spec.needsCompact || spec.skeleton === 'B') {
    height -= 25;
  }

  return { height, count };
}

function injectSpaceStrategy(content, fillRate, strategy) {
  // Check if space strategy section already exists
  if (content.includes('## 空间策略')) return content;

  const actions = strategy.actions.map(a => `  - ${a}`).join('\n');

  const strategyBlock = `
## 空间策略（填充率 ${fillRate}% < 60%，触发「${strategy.name}」策略）
- 触发策略：${strategy.name}（来自风格预设: ${strategy.key}）
- 具体动作：
${actions}
`;

  // Insert after the capacity check section
  const capacityEnd = content.indexOf('建议CSS：');
  if (capacityEnd > 0) {
    const insertAt = content.indexOf('\n', capacityEnd) + 1;
    // Find end of capacity section
    let endOfCapacity = insertAt;
    const nextLine = content.indexOf('\n```', insertAt);
    if (nextLine > 0) {
      endOfCapacity = content.indexOf('\n', nextLine + 1) + 1;
    }
    return content.slice(0, endOfCapacity) + '\n' + strategyBlock + content.slice(endOfCapacity);
  }

  // Fallback: append to end
  return content + '\n' + strategyBlock;
}

// Parse an outline.md into a list of per-page tag entries.
// Recognizes both Phase 2.3 outline formats:
//   - v4 style plain line: `P02 标题 [visual: stat-grid] [card-bg: 4] [weight: medium]`
//   - v3 style heading:    `### PPT-2：标题 [visual: stat-grid] [weight: medium]`
// Scan strategy: pick any line that carries a `[visual: ...]` and/or `[card-bg: N]`
// tag. These tags only appear on page-entry lines, so this is robust even if the
// section heading varies ("## 逐页大纲" vs "## 大纲" vs custom).
// Returns: [{ page, visual, cardBg, line }]
function parseOutline(content) {
  const pages = [];
  const lines = content.split('\n');
  // Page prefix: matches both "P02 ..." and "### PPT-1：..." / "PPT_2:" / "PPT2 ".
  // Anchored at line start (after optional leading "### " heading marker) so we
  // never grab a page number that appears mid-description.
  const pageRe = /^\s*(?:#{1,6}\s+)?(?:PPT[-_\s]?|P)(\d+)/;

  for (const rawLine of lines) {
    const visualMatch = rawLine.match(/\[visual:\s*([^\]]+)\]/);
    const cardBgMatch = rawLine.match(/\[card-bg:\s*(\d+)\]/);
    if (!visualMatch && !cardBgMatch) continue;

    const pageMatch = rawLine.match(pageRe);
    const page = pageMatch
      ? `P${pageMatch[1].padStart(2, '0')}`
      : '?';

    pages.push({
      page,
      visual: visualMatch ? visualMatch[1].trim() : null,
      cardBg: cardBgMatch ? parseInt(cardBgMatch[1], 10) : null,
      line: rawLine.trim(),
    });
  }
  return pages;
}

// Check capacity for an outline.md (Phase 2.3 mode).
// Returns exit code: 0 if all checked pages pass, 1 if any page NEEDS_SPLIT.
// Pages without a usable `[card-bg: N]` or with an unmapped visual type are
// reported as skipped (·) — never as errors.
function checkOutline(outlinePath) {
  const content = readFileSync(outlinePath, 'utf-8');
  const pages = parseOutline(content);

  console.log(`Checking ${pages.length} outline page(s) in ${outlinePath}\n`);

  let warnings = 0;
  let skipped = 0;
  let checked = 0;

  for (const p of pages) {
    // 没有 card-bg 标签的页：无法对照上限，跳过提示
    if (p.cardBg == null) {
      console.log(`  · ${p.page}: no [card-bg: N] tag — skip (capacity check needs card count)`);
      skipped++;
      continue;
    }

    // 未在 VISUAL_TO_LAYOUT 里的 visual type：可能是非固定 slot 布局
    if (!p.visual || !VISUAL_TO_LAYOUT[p.visual]) {
      const hint = p.visual ? `visual "${p.visual}" → no fixed-slot mapping` : 'no [visual: ...] tag';
      console.log(`  · ${p.page}: card-bg ${p.cardBg}, but ${hint} — skip`);
      skipped++;
      continue;
    }

    const layoutCode = VISUAL_TO_LAYOUT[p.visual];
    const budget = LAYOUT_BUDGETS[layoutCode];
    // 映射表已限定到 maxItems 布局；防御性兜底
    if (!budget || budget.maxItems == null) {
      console.log(`  · ${p.page}: ${p.visual}→${layoutCode} has no maxItems — skip`);
      skipped++;
      continue;
    }

    checked++;
    const over = p.cardBg > budget.maxItems;
    if (over) {
      warnings++;
      console.log(
        `  ❌ ${p.page}: ${p.visual}→${layoutCode} (${budget.name}) | card-bg ${p.cardBg} > maxItems ${budget.maxItems} [NEEDS_SPLIT]`,
      );
    } else {
      const headroom = budget.maxItems - p.cardBg;
      console.log(
        `  ✅ ${p.page}: ${p.visual}→${layoutCode} (${budget.name}) | card-bg ${p.cardBg} ≤ maxItems ${budget.maxItems} (headroom ${headroom}) [OK]`,
      );
    }
  }

  console.log(
    `\nSummary: ${pages.length} page(s) total | ${checked} checked | ${skipped} skipped | ${warnings} need attention`,
  );
  if (warnings > 0) {
    console.log(`❌ ${warnings} page(s) exceed fixed-slot capacity — consider splitting.`);
  }
  return warnings > 0 ? 1 : 0;
}

function main() {
  const args = process.argv.slice(2);

  // --list-budgets: print the fixed-slot layout capacity table and exit.
  // Single source of truth for SKILL.md §2.3 容量前移 + storyline-guide.md
  // (P2.1, 2026-06-22) — docs引用此命令而非手抄副本，永不错版。
  if (args.includes('--list-budgets')) {
    console.log('固定 slot 布局容量上限（LAYOUT_BUDGETS 权威源）：\n');
    console.log('  布局    名称         上限');
    console.log('  ──────  ───────────  ─────────────');
    for (const [code, b] of Object.entries(LAYOUT_BUDGETS)) {
      const limit = b.maxItems != null ? `maxItems ${b.maxItems}` : b.maxRows != null ? `maxRows ${b.maxRows}` : '无硬上限';
      console.log(`  ${code.padEnd(6)}  ${b.name.padEnd(11)}  ${limit}`);
    }
    console.log('\n注：L07/L13/L15/L21 等无 maxItems/maxRows 的布局不受固定 slot 约束，');
    console.log('但仍受全局"每页 ≤ 40 字大纲描述"密度控制约束。');
    process.exit(0);
  }

  const specDirIdx = args.indexOf('--specs');
  const outlineIdx = args.indexOf('--outline');
  const styleIdx = args.indexOf('--style');
  const dryRun = args.includes('--dry-run');

  // --specs 与 --outline 互斥（防止误用）
  if (specDirIdx >= 0 && outlineIdx >= 0) {
    console.error('Error: --specs 与 --outline 互斥，请二选一。');
    console.error('  --specs <dir>      Phase 4.2 已生成 specs/ 时使用');
    console.error('  --outline <file>   Phase 2.3 大纲阶段，specs 尚未生成时使用');
    process.exit(2);
  }

  // --outline 模式：从 outline.md 的 [visual: <type>] + [card-bg: N] 标签
  // 推断内容项数，对照 LAYOUT_BUDGETS 上限报状态。详见文件头注释。
  if (outlineIdx >= 0) {
    if (!args[outlineIdx + 1]) {
      console.error('Error: --outline 需要一个 outline.md 路径参数');
      process.exit(2);
    }
    const outlinePath = resolve(args[outlineIdx + 1]);
    if (!existsSync(outlinePath)) {
      console.error(`Error: outline file not found: ${outlinePath}`);
      process.exit(2);
    }
    process.exit(checkOutline(outlinePath));
  }

  if (specDirIdx < 0 || !args[specDirIdx + 1]) {
    console.error('Usage: node check-spec-capacity.mjs --specs <specs-dir> [--style <name>] [--dry-run] [--list-budgets]');
    console.error('       node check-spec-capacity.mjs --outline <outline.md>');
    console.error('');
    console.error('  --specs <dir>        Path to specs/ directory containing PPT-NN.md files');
    console.error('  --outline <file>     Check capacity from outline.md (Phase 2.3, before specs exist)');
    console.error('  --style <name>       Template style name (enables space strategy injection, --specs only)');
    console.error('  --dry-run            Report only, do not modify spec files (--specs only)');
    console.error('  --list-budgets       Print fixed-slot layout capacity table and exit');
    process.exit(2);
  }

  const specDir = resolve(args[specDirIdx + 1]);
  const style = styleIdx >= 0 ? args[styleIdx + 1] : null;

  if (!existsSync(specDir)) {
    console.error(`Error: specs directory not found: ${specDir}`);
    process.exit(2);
  }

  const strategy = style ? getStrategyForStyle(style) : null;
  if (style) {
    console.log(`Style: ${style} → 稀疏空间策略: ${strategy.name}`);
    console.log();
  }

  const specFiles = readdirSync(specDir).filter(f => f.endsWith('.md') && !f.startsWith('_')).sort();
  let warnings = 0;
  let strategyInjected = 0;

  console.log(`Checking ${specFiles.length} spec files in ${specDir}\n`);

  for (const file of specFiles) {
    const filePath = join(specDir, file);
    let content = readFileSync(filePath, 'utf-8');
    const spec = parseSpec(content);

    if (!spec.layout) {
      console.log(`  ? ${file}: no layout detected (non-slide spec?)`);
      continue;
    }

    const budget = LAYOUT_BUDGETS[spec.layout];
    const budgetName = budget ? budget.name : 'unknown';

    let limitViolation = null;
    if (budget) {
      if (budget.maxItems && spec.items && spec.items > budget.maxItems) {
        limitViolation = `EXCEEDS_ITEMS: ${spec.items} items > ${budget.maxItems} max`;
      }
      if (budget.maxRows && spec.rows && spec.rows > budget.maxRows) {
        limitViolation = `EXCEEDS_ROWS: ${spec.rows} rows > ${budget.maxRows} max`;
      }
    }

    const result = estimateSpecHeight(spec.layout, spec);
    const fillRate = result
      ? Math.round((result.height / AVAILABLE_HEIGHT) * 100)
      : (spec.fillRate || null);

    let status = 'OK';
    let statusIcon = '✅';
    let isSparse = false;

    if (spec.needsSplit || limitViolation?.startsWith('EXCEEDS')) {
      status = 'NEEDS_SPLIT';
      statusIcon = '❌';
      warnings++;
    } else if (fillRate !== null && fillRate > 100) {
      status = 'NEEDS_COMPACT_OR_SPLIT';
      statusIcon = '🔴';
      warnings++;
    } else if (fillRate !== null && fillRate > 95) {
      status = 'TIGHT';
      statusIcon = '⚡';
      warnings++;
    } else if (fillRate !== null && fillRate < 60 && spec.layout !== 'L01' && spec.layout !== 'L03' && spec.layout !== 'L04') {
      status = 'LOOSE';
      statusIcon = '⚠️';
      isSparse = true;
      warnings++;
    }

    const countStr = result ? `${result.count} items` : '?';
    const heightStr = result ? `${result.height}px` : '?';
    const fillStr = fillRate !== null ? `${fillRate}%` : '?';
    const budgetStr = `${spec.layout} (${budgetName})`;

    console.log(`  ${statusIcon} ${file}: ${budgetStr} | ${countStr} | est. ${heightStr} / ~${AVAILABLE_HEIGHT}px = ${fillStr} [${status}]`);

    if (limitViolation) {
      console.log(`      ↳ ${limitViolation}`);
    }

    // Inject space strategy for sparse pages
    if (isSparse && strategy && !dryRun) {
      content = injectSpaceStrategy(content, fillRate, strategy);
      writeFileSync(filePath, content, 'utf-8');
      console.log(`      ↳ 注入空间策略: ${strategy.name}`);
      strategyInjected++;
    } else if (isSparse && strategy && dryRun) {
      console.log(`      ↳ [dry-run] 将注入空间策略: ${strategy.name}`);
    } else if (isSparse && !strategy) {
      console.log(`      ↳ 提示: 使用 --style <name> 自动注入空间策略建议`);
    }
  }

  console.log(`\n${warnings > 0 ? '❌' : '✅'} ${warnings} spec(s) need attention.`);
  if (strategyInjected > 0) {
    console.log(`📝 ${strategyInjected} spec(s) received space strategy injection.`);
  }
  process.exit(warnings > 0 ? 1 : 0);
}

main();
