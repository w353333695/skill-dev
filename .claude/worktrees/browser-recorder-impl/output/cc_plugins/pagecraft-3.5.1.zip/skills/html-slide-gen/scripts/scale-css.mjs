#!/usr/bin/env node
/**
 * Scale CSS pixel values proportionally for html-ppt templates → 1920x1080 canvas.
 *
 * Scale factor: 1.33x uniform (both height and width properties)
 *
 * Usage: node scale-css.mjs [--dry-run] <file1> <file2> ...
 */

import { readFileSync, writeFileSync } from 'fs';

const DRY_RUN = process.argv.includes('--dry-run');
const files = process.argv.filter(a => a.endsWith('.css'));

if (files.length === 0) {
  console.error('Usage: node scale-css.mjs [--dry-run] <css-file...>');
  process.exit(1);
}

// ─── Scaling Configuration ──────────────────────────────────────────

// Properties whose ENTIRE value should scale uniformly (1.33x)
const HEIGHT_SCALE_PROPS = new Set([
  'font-size',
  'line-height',      // unitless values skipped, px values scaled
  'margin-top',
  'margin-bottom',
  'padding-top',
  'padding-bottom',
  'top',
  'bottom',
  'height',
  'min-height',
  'max-height',
  'border-radius',
  'border-top-left-radius',
  'border-top-right-radius',
  'border-bottom-left-radius',
  'border-bottom-right-radius',
  'gap',
  'row-gap',
  'column-gap',
  'grid-gap',
]);

// Properties whose ENTIRE value should scale uniformly (1.33x)
const WIDTH_SCALE_PROPS = new Set([
  'margin-left',
  'margin-right',
  'padding-left',
  'padding-right',
  'left',
  'right',
  'width',
  'min-width',
  'max-width',
]);

// Shorthand properties with directional px values
// These get their individual components scaled differently
const SHORTHAND_PROPS = {
  'margin':       ['top', 'right', 'bottom', 'left'],
  'padding':      ['top', 'right', 'bottom', 'left'],
  'border-radius': ['tl', 'tr', 'br', 'bl'],  // all height-scaled
};

// Properties where all numeric values scale by height (like box-shadow offsets)
const ALL_HEIGHT_SCALE = new Set([
  'box-shadow',
  'text-shadow',
  'outline-offset',
]);

// Properties to NEVER scale (only used for filtering)
const SKIP_PROPS = new Set([
  'opacity',
  'z-index',
  'font-weight',
  'letter-spacing',   // em-based, don't scale
  'transform',
  'animation-duration',
  'animation-delay',
  'transition-duration',
  'transition-delay',
  'stroke-width',
  'filter',           // blur() etc are intentional
]);

// ─── Value Parsing & Scaling ────────────────────────────────────────

function scaleNumber(val, factor) {
  const num = parseFloat(val);
  if (isNaN(num) || num === 0) return val;
  const scaled = Math.round(num * factor);
  // For very small values (< 10px), keep more precision by rounding to nearest 0.5
  if (num < 10) return String(Math.round(num * factor * 2) / 2);
  return String(scaled);
}

function scalePxValue(val, factor) {
  return val.replace(/(\d+(?:\.\d+)?)(px|pt)/g, (_, num, unit) => {
    const n = parseFloat(num);
    if (n === 0) return `0${unit}`;
    const scaled = n < 10 ? Math.round(n * factor * 2) / 2 : Math.round(n * factor);
    return scaled + unit;
  });
}

/**
 * Scale a shorthand value like "10px 20px 30px 40px" or "10px 20px" or "10px".
 * Each component gets its own factor from `factors` array.
 */
function scaleShorthand(val, factors) {
  const parts = val.trim().split(/\s+/);
  // Skip if empty or 0
  if (parts.length === 0 || val === '0') return val;

  const scaled = parts.map((part, i) => {
    // Use the factor for this position (cycling if fewer factors than parts)
    const factor = factors[i] || factors[factors.length - 1];
    return scalePxValue(part, factor);
  });
  return scaled.join(' ');
}

/**
 * Scale box-shadow: "offsetX offsetY blur spread color [inset]"
 * Offsets scale by 1.2, blur/spread by 1.2, colors/inset left alone
 */
function scaleBoxShadow(val) {
  // Split by commas for multi-shadow
  return val.split(',').map(shadow => {
    return shadow.replace(
      /(-?\d+(?:\.\d+)?)(px|pt)\s+(-?\d+(?:\.\d+)?)(px|pt)(\s+(\d+(?:\.\d+)?)(px|pt))?(\s+(\d+(?:\.\d+)?)(px|pt))?/g,
      (match, x, xu, y, yu, _b1, b, bu, _s1, s, su) => {
        const scaleX = Math.round(parseFloat(x) * 1.33);
        const scaleY = Math.round(parseFloat(y) * 1.33);
        let result = `${scaleX}${xu} ${scaleY}${yu}`;
        if (b) result += ` ${Math.round(parseFloat(b) * 1.33)}${bu}`;
        if (s) result += ` ${Math.round(parseFloat(s) * 1.33)}${su}`;
        return result;
      }
    );
  }).join(',');
}

/**
 * Scale a single CSS declaration value based on property name.
 */
function scaleDeclarationValue(prop, value) {
// CSS custom properties that define CANVAS DIMENSIONS (not component sizing).
// These should NOT be scaled — they are the target dimensions, not source.
const CANVAS_DEFINITION_PROPS = new Set([
  '--deck-width',
  '--deck-height',
  '--margin',
]);

// ... later in scaleDeclarationValue:

  // Skip non-pixel values and CSS variable references
  if (!/px|pt/.test(value)) return value;
  if (/var\(/.test(value)) return value;
  // Skip canvas definition tokens (--deck-width, --deck-height, --margin)
  if (CANVAS_DEFINITION_PROPS.has(prop)) return value;
  // Other CSS custom properties (--radius, --shadow, --xp-*, --gd-* etc.) ARE scaled

  // Skip if property should not be scaled
  if (SKIP_PROPS.has(prop)) return value;

  // Box-shadow special handling
  if (ALL_HEIGHT_SCALE.has(prop)) {
    return scaleBoxShadow(value);
  }

  // Shorthand properties
  if (SHORTHAND_PROPS[prop]) {
    const factors = SHORTHAND_PROPS[prop].map(dir => {
      if (dir === 'left' || dir === 'right') return 1.33;
      return 1.33;
    });
    return scaleShorthand(value, factors);
  }

  // Height-scaled properties
  if (HEIGHT_SCALE_PROPS.has(prop)) {
    return scalePxValue(value, 1.33);
  }

  // Width-scaled properties
  if (WIDTH_SCALE_PROPS.has(prop)) {
    return scalePxValue(value, 1.33);
  }

  // For unrecognized properties with px values, apply conservative height scaling
  if (/px|pt/.test(value)) {
    return scalePxValue(value, 1.33);
  }

  return value;
}

/**
 * Process a full CSS line. May contain selectors + multiple declarations.
 * Finds ALL `property: value;` or `property: value}` patterns and scales values.
 */
function processLine(line) {
  // Skip comments
  if (/^\s*\/\*/.test(line) || /^\s*\/\//.test(line)) return line;

  // Find all property:value pairs (with ; or } terminator)
  return line.replace(/([\w-]+)\s*:\s*([^;{}]+?)([;}])/g, (match, prop, value, term) => {
    const newValue = scaleDeclarationValue(prop, value.trim());
    if (newValue === value.trim()) return match;
    return `${prop}: ${newValue}${term}`;
  });
}

/**
 * Process a full CSS file content.
 */
function processCSS(content, filePath) {
  const lines = content.split('\n');
  let changed = 0;

  const result = lines.map((line, idx) => {
    const processed = processLine(line);
    if (processed !== line) {
      changed++;
      if (DRY_RUN) {
        console.log(`  [${basename(filePath)}:${idx + 1}] CHANGED`);
      }
    }
    return processed;
  });

  return { content: result.join('\n'), changed };
}

// ─── Main ────────────────────────────────────────────────────────────

import { basename } from 'path';
const path = await import('path');

let totalChanged = 0;

for (const file of files) {
  const original = readFileSync(file, 'utf-8');
  const { content, changed } = processCSS(original, file);

  if (!DRY_RUN) {
    writeFileSync(file, content, 'utf-8');
  }

  const label = DRY_RUN ? ' [DRY RUN]' : '';
  console.log(`${changed} values scaled in ${basename(file)}${label}`);
  totalChanged += changed;
}

console.log(`\nTotal: ${totalChanged} values scaled across ${files.length} files${DRY_RUN ? ' (DRY RUN)' : ''}`);
