#!/usr/bin/env node
// validate-templates.mjs — Starter-deck template source self-check (F18/F19 defense, 2026-06-22)
//
// Runs validate.mjs against every starter-deck template and applies a noise
// whitelist, so "template source introduced a real violation" (like the F18
// TEXT_STYLING <p> border bug) is caught at template-edit time instead of
// surfacing on every deck generated from that template.
//
// Whitelist policy: only rules that legitimately fire on a BARE template
// skeleton (no generated speech/notes/runtime yet) are whitelisted universally.
// Template-specific design exceptions (decorative empty slots, theme emoji) are
// listed per-template. Any OTHER error fails the check — that's the signal a
// template edit introduced a real defect.
//
// Usage: node validate-templates.mjs [--quiet]
// Exit: 0 = all templates clean (post-whitelist), 1 = at least one has real errors.

'use strict';

import { readdirSync, existsSync } from 'fs';
import { join, dirname, resolve } from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SCRIPTS = __dirname;
const TEMPLATES = resolve(__dirname, '..', 'templates', 'starter-decks');
const VALIDATE = join(SCRIPTS, 'validate.mjs');

// Rules that legitimately fire on every bare template skeleton — the template
// ships without generated DECK_NOTES / DECK_MANIFEST / index-runtime.js (those
// are filled/copied at deck-generation time). Not template defects.
const UNIVERSAL_WHITELIST = new Set([
  'MANIFEST_MISSING',
  'NOTES_MISSING',
  'RUNTIME_FILE_MISSING',
]);

// Template-specific design exceptions. Each entry: { rule, reason }.
// These are LEGITIMATE template-source choices, not defects — but they'd
// otherwise fail the self-check. Keep the reason current; if a template is
// reworked to remove the exception, delete the entry.
const TEMPLATE_WHITELIST = {
  // biz-review ships a populated DECK_MANIFEST (14 slides) but an empty
  // DECK_NOTES={} in its index.html. The manifest/notes mismatch fires
  // NOTES_MISSING_FOR_SLIDE per slide. TODO: either clear DECK_MANIFEST too
  // (match other templates) or populate notes — tracked separately.
  'biz-review': [
    { rule: 'NOTES_MISSING_FOR_SLIDE', reason: 'index.html has DECK_MANIFEST but DECK_NOTES={} — template source mismatch (track separately)' },
    { rule: 'T1_KEY_EMPTY', reason: 'spine slot is a decorative 3px gradient divider div, not a content slot' },
  ],
  // product-launch uses ♪ as the icon glyph for audio-product feature cards —
  // thematic iconography, part of the template's visual language.
  'product-launch': [
    { rule: 'EMOJI_IN_SLIDE', reason: '♪ is the thematic icon for audio-product feature cards' },
    { rule: 'EMOJI_SUMMARY', reason: 'consequence of the ♪ icon above' },
    { rule: 'T1_KEY_EMPTY', reason: 'col_dim is an empty <th> dimension-column placeholder, not a content slot' },
  ],
};

function listTemplates() {
  return readdirSync(TEMPLATES)
    .filter(f => {
      const p = join(TEMPLATES, f);
      return existsSync(p) && existsSync(join(p, 'slides')) && existsSync(join(p, 'index.html'));
    })
    .sort();
}

// Parse validate.mjs --quiet output into [{rule, file, message}] (ERRORs only).
// Quiet mode still prints ERROR lines; format: "  L<n>  ERROR  <RULE>: <msg>"
// or (index.html) "  ERROR  <RULE>: <msg>".
function parseErrors(output) {
  const errors = [];
  const lines = output.split('\n');
  const re = /\bERROR\s+([A-Z_]+):\s*(.*)$/;
  for (const line of lines) {
    const m = line.match(re);
    if (m) errors.push({ rule: m[1], message: m[2].trim() });
  }
  return errors;
}

function isWhitelisted(template, err) {
  if (UNIVERSAL_WHITELIST.has(err.rule)) return true;
  const list = TEMPLATE_WHITELIST[template] || [];
  return list.some(e => e.rule === err.rule);
}

function checkTemplate(template) {
  const deckPath = join(TEMPLATES, template);
  let output;
  try {
    output = execSync(
      `node "${VALIDATE}" --deck "${deckPath}" --mode strict --quiet`,
      { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }
    );
  } catch (e) {
    // validate exits 1 when it finds errors — that's expected, the stdout is
    // still on e.stdout. Only treat missing-deck / parse failures as fatal.
    output = (e.stdout || '') + (e.stderr || '');
    if (!/Validating:/.test(output)) {
      return { template, fatal: true, raw: output, errors: [], real: [] };
    }
  }

  const errors = parseErrors(output);
  const real = errors.filter(e => !isWhitelisted(template, e));
  const whitelisted = errors.filter(e => isWhitelisted(template, e));
  return { template, fatal: false, errors, real, whitelisted };
}

function main() {
  const quiet = process.argv.includes('--quiet');
  const templates = listTemplates();

  if (templates.length === 0) {
    console.error(`No starter-deck templates found under ${TEMPLATES}`);
    process.exit(2);
  }

  console.log(`Template self-check: ${templates.length} starter-decks\n`);

  let failCount = 0;
  for (const t of templates) {
    const r = checkTemplate(t);
    if (r.fatal) {
      console.log(`  ${t.padEnd(28)} 💥 FATAL — validate.mjs could not run`);
      console.log(`     ${r.raw.split('\n')[0]}`);
      failCount++;
      continue;
    }
    if (r.real.length === 0) {
      const wl = r.whitelisted.length;
      console.log(`  ${t.padEnd(28)} ✓ clean${wl ? `  (${wl} whitelisted noise)` : ''}`);
    } else {
      console.log(`  ${t.padEnd(28)} ✗ ${r.real.length} real error(s)`);
      for (const e of r.real) {
        console.log(`     ${e.rule}: ${e.message}`);
      }
      failCount++;
    }
  }

  console.log(`\n${'─'.repeat(50)}`);
  if (failCount === 0) {
    console.log(`All ${templates.length} templates clean (post-whitelist).`);
    process.exit(0);
  } else {
    console.log(`${failCount}/${templates.length} templates have real errors — fix template source.`);
    process.exit(1);
  }
}

main();
