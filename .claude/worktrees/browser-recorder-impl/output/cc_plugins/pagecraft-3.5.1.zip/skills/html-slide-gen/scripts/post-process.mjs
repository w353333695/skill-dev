#!/usr/bin/env node
// post-process.mjs — One-stop post-processing after all subagents finish
// Runs batch-fix + component-usage + style-violation + validate in a single command.
// Usage: node scripts/post-process.mjs --deck <path> [--style <name>] [--skip visual,usage,style]

'use strict';

import { execSync } from 'child_process';
import { resolve, dirname, join } from 'path';
import { existsSync, readdirSync, readFileSync, writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { FIXES, syncManifest, syncNotes, syncImageManifest } from './batch-fix.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Component classes from tokens.css (manually maintained — keep in sync with
// templates/shared/tokens.css + each deck's .tpl-* overlay component layer)
const COMPONENT_CLASSES = [
  'card', 'card-accent', 'card-elevated', 'card-soft', 'card-outline',
  'kpi-grid', 'kpi-card', 'kpi-value', 'kpi-delta',
  'chart-bars', 'donut', 'timeline', 'comparison-table',
  'matrix-2x2', 'funnel', 'progress-bar-track',
  'process-flow', 'pf-node',
  'page-header', 'page-body', 'tech-footer',
  'kicker', 'lede', 'eyebrow', 'section-tag', 'gradient-text',
  'ambient-glow', 'icon-halo', 'grid-texture', 'dot-cluster', 'cover-content',
  'slide-top-bar', 'slide-bottom-bar', 'slide-side-bar',
  'deck-footer', 'ship-item', 'tag', 'blocker',
];

// Style violation rules: { class: [forbidden_styles] }
const STYLE_VIOLATIONS = {
  'ambient-glow-tr': ['weekly-report', 'course-module', 'tech-sharing', 'testing-safety-alert',
                      'knowledge-arch-blueprint', 'presenter-mode-reveal'],
  'ambient-glow-bl': ['weekly-report', 'course-module', 'tech-sharing', 'testing-safety-alert',
                      'knowledge-arch-blueprint', 'presenter-mode-reveal'],
  'ambient-glow-tl': ['weekly-report', 'course-module', 'tech-sharing', 'testing-safety-alert',
                      'knowledge-arch-blueprint', 'presenter-mode-reveal'],
  'card-elevated': ['weekly-report', 'course-module', 'testing-safety-alert'],
  'cover-content': ['weekly-report', 'tech-sharing', 'testing-safety-alert'],
  'grid-texture': ['pitch-deck', 'weekly-report', 'product-launch', 'course-module',
                   'xhs-pastel-card', 'xhs-white-editorial',
                   'hermes-cyber-terminal', 'presenter-mode-reveal', 'testing-safety-alert'],
  'dot-cluster': ['weekly-report', 'course-module', 'tech-sharing', 'testing-safety-alert',
                  'hermes-cyber-terminal', 'presenter-mode-reveal'],
  'icon-halo': ['weekly-report', 'tech-sharing', 'course-module',
                'hermes-cyber-terminal', 'testing-safety-alert'],
  'gradient-text': ['weekly-report', 'course-module', 'testing-safety-alert',
                    'knowledge-arch-blueprint'],
  'divider-gradient': ['weekly-report', 'tech-sharing', 'course-module', 'testing-safety-alert',
                       'hermes-cyber-terminal'],
  'tech-footer': ['xhs-pastel-card', 'xhs-white-editorial'],
  'slide-top-bar': ['xhs-pastel-card'],
  'compact-header': ['pitch-deck', 'product-launch', 'xhs-pastel-card',
                     'xhs-white-editorial', 'dir-key-nav-minimal'],
  'deco-circle': ['weekly-report', 'tech-sharing', 'course-module', 'testing-safety-alert'],
};

function parseArgs(argv) {
  const args = { deck: null, style: null, skip: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--deck' && argv[i + 1]) { args.deck = argv[++i]; continue; }
    if (a === '--style' && argv[i + 1]) { args.style = argv[++i]; continue; }
    if (a === '--skip' && argv[i + 1]) { args.skip = argv[++i].split(','); continue; }
    if (a === '--help' || a === '-h') { printUsage(); process.exit(0); }
  }
  return args;
}

function printUsage() {
  console.log('Usage: node post-process.mjs --deck <dir> [--style <name>] [--skip visual,usage,style]');
  console.log('');
  console.log('One-stop post-processing after all subagents finish:');
  console.log('  1. batch-fix --fix inject-data-skeleton  (add data-skeleton=t1 to tpl bodies)');
  console.log('  2. batch-fix --fix div-bare-text          (wrap bare div text in <span>)');
  console.log('  3. batch-fix --fix footer-padding');
  console.log('  4. batch-fix --fix compact-header');
  console.log('  5. batch-fix --fix hardcoded-colors');
  console.log('  6. batch-fix --fix add-slide-top-bar');
  console.log('  7. batch-fix --fix sync-manifest');
  console.log('  8. batch-fix --fix sync-notes');
  console.log('  9. batch-fix --fix sync-image-manifest    (materialize all-SKIPPED manifest if missing)');
  console.log(' 10. check-component-usage');
  console.log(' 11. check-style-violations');
  console.log(' 12. node scripts/validate.mjs --mode strict');
  console.log('');
  console.log('  --deck <dir>    Deck root directory (parent of slides/)');
  console.log('  --style <name>  Template style name for style violation checks');
  console.log('  --skip <list>   Comma-separated steps to skip (also: skeleton,baretext,imagemanifest)');
}

function run(cmd, label) {
  process.stdout.write(`  ${label}... `);
  try {
    const output = execSync(cmd, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] });
    // Extract summary line
    const lines = output.trim().split('\n');
    const lastLine = lines[lines.length - 1] || '';
    if (lastLine.includes('Done') || lastLine.includes('files modified') || lastLine.includes('entries written') || lastLine.includes('extracted')) {
      console.log('✅');
    } else {
      console.log('✅ (see output below)');
    }
    if (output.trim()) {
      // Print key lines only
      const keyLines = lines.filter(l => l.includes('FIXED') || l.includes('✅') || l.includes('PASS') || l.includes('ERROR') || l.includes('WARNING') || l.includes('Summary') || l.includes('Done'));
      if (keyLines.length > 0) {
        keyLines.forEach(l => console.log(`    ${l.trim()}`));
      }
    }
    return { ok: true, output };
  } catch (e) {
    const stderr = e.stderr || '';
    const stdout = e.stdout || '';
    const msg = (stdout + stderr).trim();
    // Validate exits non-zero when there are errors — check if they're ERROR or just WARNING
    if (msg.includes('ERROR')) {
      console.log('❌');
      // Print error summary
      const errorLines = msg.split('\n').filter(l => l.includes('ERROR') || l.includes('Summary'));
      errorLines.forEach(l => console.log(`    ${l.trim()}`));
      return { ok: false, output: msg };
    } else {
      console.log('⚠️ (warnings only)');
      return { ok: true, output: msg };
    }
  }
}

// Capture console.log/error output during fn(), return captured lines.
// Lets runStep format in-process fix output the same way run() formats
// subprocess output (✅/❌ + indented key lines).
function captureOutput(fn) {
  const lines = [];
  const origLog = console.log;
  const origErr = console.error;
  console.log = (...args) => lines.push(args.map(String).join(' '));
  console.error = (...args) => lines.push(args.map(String).join(' '));
  try {
    fn();
  } finally {
    console.log = origLog;
    console.error = origErr;
  }
  return lines;
}

// In-process equivalent of run() for batch-fix functions. Same ✅/❌/⚠️ output
// format, but no subprocess — reads/writes happen in this process.
function runStep(name, fn) {
  process.stdout.write(`  ${name}... `);
  let lines;
  try {
    lines = captureOutput(fn);
  } catch (e) {
    console.log('❌');
    console.log(`    ${e.message}`);
    return { ok: false, output: e.message };
  }
  const output = lines.join('\n');
  const lastLine = lines[lines.length - 1] || '';

  if (output.includes('ERROR')) {
    console.log('❌');
    const errorLines = lines.filter(l => l.includes('ERROR') || l.includes('Summary'));
    errorLines.forEach(l => console.log(`    ${l.trim()}`));
    return { ok: false, output };
  }

  if (lastLine.includes('Done') || lastLine.includes('files modified') ||
      lastLine.includes('entries written') || lastLine.includes('extracted')) {
    console.log('✅');
  } else {
    console.log('✅ (see output below)');
  }

  if (output.trim()) {
    const keyLines = lines.filter(l => l.includes('FIXED') || l.includes('✅') || l.includes('PASS') || l.includes('ERROR') || l.includes('WARNING') || l.includes('Summary') || l.includes('Done'));
    if (keyLines.length > 0) {
      keyLines.forEach(l => console.log(`    ${l.trim()}`));
    }
  }
  return { ok: true, output };
}

// Apply a slide-level fix (from batch-fix.mjs FIXES map) to all slides in-place.
// Outer loop = fix, inner loop = slide — one pass over all slides per fix, no
// subprocess cold start. Prints FIXED/Done lines that runStep captures.
function applySlideFix(slidesDir, fixName, style) {
  const fixFn = FIXES[fixName];
  const slideFiles = readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();
  let totalChanged = 0;
  for (const file of slideFiles) {
    const filePath = join(slidesDir, file);
    const html = readFileSync(filePath, 'utf8');
    const { html: newHtml, changed } = fixName === 'compact-header'
      ? fixFn(html, style)
      : fixFn(html);
    if (changed) {
      writeFileSync(filePath, newHtml, 'utf8');
      totalChanged++;
      console.log(`  FIXED: slides/${file} (1 fixes applied)`);
    }
  }
  console.log(`Done. ${totalChanged}/${slideFiles.length} files modified.`);
}

function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.deck) {
    console.error('Error: --deck <dir> is required.\n');
    printUsage();
    process.exit(2);
  }

  const deckPath = resolve(args.deck);
  const slidesDir = `${deckPath}/slides`;

  if (!existsSync(slidesDir)) {
    console.error(`Error: slides/ directory not found at ${slidesDir}`);
    process.exit(2);
  }

  const validate = `node ${resolve(__dirname, 'validate.mjs')}`;

  console.log(`\nPost-process: ${deckPath}`);
  if (args.style) console.log(`Style: ${args.style}\n`);
  else console.log();

  let hasErrors = false;

  // Step 1-4: Slide-level fixes (in-process — no subprocess cold start)
  const skip = args.skip || [];

  // Inject data-skeleton="t1" FIRST so every downstream T1-aware fix (compact-header,
  // div-bare-text) and validator exemption (SVG whitelist, DIV_BARE_TEXT skip) takes
  // effect on the same run. Without it, template pages leak a flood of false positives.
  if (!skip.includes('skeleton')) {
    runStep('inject-data-skeleton', () => applySlideFix(slidesDir, 'inject-data-skeleton'));
  }
  if (!skip.includes('baretext')) {
    runStep('div-bare-text', () => applySlideFix(slidesDir, 'div-bare-text'));
  }
  if (!skip.includes('footer')) {
    runStep('footer-padding', () => applySlideFix(slidesDir, 'footer-padding'));
  }
  if (!skip.includes('compact')) {
    const COMPACT_HEADER_BLACKLIST = STYLE_VIOLATIONS['compact-header'] || [];
    if (args.style && COMPACT_HEADER_BLACKLIST.includes(args.style)) {
      console.log(`  compact-header... ⏭️  (disabled for style "${args.style}")`);
    } else {
      runStep('compact-header', () => applySlideFix(slidesDir, 'compact-header', args.style || ''));
    }
  }
  if (!skip.includes('colors')) {
    runStep('hardcoded-colors', () => applySlideFix(slidesDir, 'hardcoded-colors'));
  }
  if (!skip.includes('topbar')) {
    runStep('add-slide-top-bar', () => applySlideFix(slidesDir, 'add-slide-top-bar'));
  }
  // 003 主线六 (G1/G2/G4): gantt 月份表头 + bar 百分比由 data-gantt-start/months 重建
  if (!skip.includes('gantt')) {
    runStep('gantt-months', () => applySlideFix(slidesDir, 'gantt-months'));
  }
  // 003 §12.5 (T1b): 表格末尾整列空 → 删列
  if (!skip.includes('tablecol')) {
    runStep('table-empty-col', () => applySlideFix(slidesDir, 'table-empty-col'));
  }
  // 003 A1 配套 (B2 延伸): var(--token) 后缺分号 → 补分号
  if (!skip.includes('stylesemi')) {
    runStep('style-semicolon', () => applySlideFix(slidesDir, 'style-semicolon'));
  }
  // 003 V2 延伸 (FONT_SIZE_TINY): inline font-size 过小 → 提升到可读下限
  if (!skip.includes('fontsize')) {
    runStep('font-size-floor', () => applySlideFix(slidesDir, 'font-size-floor'));
  }
  // 003 C (EMOJI_IN_SLIDE, v41 实证 43 处): 可见区 emoji → SVG 图标
  if (!skip.includes('emoji')) {
    runStep('replace-emoji-icons', () => applySlideFix(slidesDir, 'replace-emoji-icons'));
  }
  // 003 v46 实证 (BARE_GRID_NO_COLUMNS): display:grid 无列数 → 按子元素数补列
  if (!skip.includes('baregrid')) {
    runStep('bare-grid-columns', () => applySlideFix(slidesDir, 'bare-grid-columns'));
  }

  // Step 5-6: Deck-level fixes (in-process)
  if (!skip.includes('manifest')) {
    runStep('sync-manifest', () => syncManifest(deckPath));
  }
  if (!skip.includes('notes')) {
    runStep('sync-notes', () => syncNotes(deckPath));
  }
  // Step 5.5: Truncate any content after </html> (safety check for batch-fix append bug)
  if (!skip.includes('truncate')) {
    runStep('truncate-after-html', () => {
      const slides = readdirSync(slidesDir).filter(f => f.endsWith('.html'));
      let truncated = 0;
      for (const slide of slides) {
        const filePath = join(slidesDir, slide);
        let content = readFileSync(filePath, 'utf8');
        const htmlEndIndex = content.indexOf('</html>');
        if (htmlEndIndex !== -1) {
          const afterHtml = content.substring(htmlEndIndex + 7).trim();
          if (afterHtml.length > 0) {
            content = content.substring(0, htmlEndIndex + 7) + '\n';
            writeFileSync(filePath, content, 'utf8');
            truncated++;
          }
        }
      }
      if (truncated > 0) {
        console.log(`    FIXED: Truncated ${truncated} file(s) with content after </html>`);
      } else {
        console.log(`    Done. No files needed truncation.`);
      }
    });
  }
  // Materialize an all-SKIPPED image-manifest.md from outline.md when one is missing
  // (decks that render all page-level visuals via template/CSS). Runs BEFORE validate
  // so the visual check passes for CSS-only decks.
  if (!skip.includes('imagemanifest')) {
    runStep('sync-image-manifest', () => syncImageManifest(deckPath));
  }

  // Step 7: Check component usage
  if (!skip.includes('usage')) {
    console.log('');
    const usageResult = checkComponentUsage(slidesDir);
    if (!usageResult.ok) hasErrors = true;
  }

  // Step 8: Check style violations
  if (!skip.includes('style') && args.style) {
    console.log('');
    const styleResult = checkStyleViolations(slidesDir, args.style);
    if (!styleResult.ok) hasErrors = true;
  } else if (!args.style && !skip.includes('style')) {
    console.log('\n  ℹ️  Use --style <name> to enable style violation checks');
  }

  // Step 9: Validate
  if (!skip.includes('validate')) {
    console.log('');
    const result = run(`${validate} --deck "${deckPath}" --mode strict`, 'validate');
    if (!result.ok) hasErrors = true;
  }

  console.log('');
  if (hasErrors) {
    console.log('⚠️  Post-process complete with ERRORS. Review above and fix remaining issues.');
    process.exit(1);
  } else {
    console.log('✅ Post-process complete. No errors remaining.');
    process.exit(0);
  }
}

function checkComponentUsage(slidesDir) {
  const slideFiles = readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();
  let warnings = 0;
  const LOW_THRESHOLD = 5; // fewer than 5 component classes = warning

  console.log('  checking component usage...');

  for (const file of slideFiles) {
    const content = readFileSync(`${slidesDir}/${file}`, 'utf-8');
    let usedCount = 0;
    const used = [];

    for (const cls of COMPONENT_CLASSES) {
      const regex = new RegExp(`class=["'][^"']*\\b${cls}\\b[^"']*["']`, 'g');
      if (regex.test(content)) {
        usedCount++;
        used.push(cls);
      }
    }

    if (usedCount < LOW_THRESHOLD) {
      console.log(`  ⚠️  ${file}: only ${usedCount}/${COMPONENT_CLASSES.length} component classes used (${used.join(', ')})`);
      console.log(`      ↳ Consider using more tokens.css classes instead of custom divs`);
      warnings++;
    }
  }

  const ok = warnings === 0;
  if (ok) {
    console.log(`  ✅ All ${slideFiles.length} slides have sufficient component usage`);
  } else {
    console.log(`  ⚠️  ${warnings} slide(s) have low component usage`);
  }
  return { ok };
}

function checkStyleViolations(slidesDir, style) {
  const slideFiles = readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();
  let violations = 0;

  console.log(`  checking style violations for "${style}"...`);

  for (const file of slideFiles) {
    const content = readFileSync(`${slidesDir}/${file}`, 'utf-8');

    for (const [cls, forbiddenStyles] of Object.entries(STYLE_VIOLATIONS)) {
      if (forbiddenStyles.includes(style)) {
        const regex = new RegExp(`\\b${cls}\\b`);
        if (regex.test(content)) {
          console.log(`  ❌ ${file}: .${cls} is forbidden in "${style}" style`);
          violations++;
        }
      }
    }
  }

  const ok = violations === 0;
  if (ok) {
    console.log(`  ✅ All ${slideFiles.length} slides comply with "${style}" style rules`);
  } else {
    console.log(`  ❌ ${violations} style violation(s) found`);
  }
  return { ok };
}

main();
