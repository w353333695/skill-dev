#!/usr/bin/env node
// generate-image.mjs — 内置 AI 生图脚本（零依赖，Node 18+ 内置 fetch）。
//
// 为什么本脚本存在（独立性）：历史上本插件的 AI 生图硬依赖兄弟插件 pagecraft
// （commands/html-gen-images.md、visual-content-guide.md §5.4 全部调用
// `python3 $PAGECRAFT_PATH/skills/image-gen/scripts/generate.py`）。`/plugin install` 到没有
// pagecraft 的环境后生图直接失效。本脚本把同样的能力内化进本插件，pagecraft 降级为可选。
//
// 与 pagecraft generate.py 功能对等：
//   - 读 ANTHROPIC_AUTH_TOKEN / ANTHROPIC_BASE_URL 环境变量
//   - POST {BASE_URL}/v1/images/generations（兼容 BASE_URL 自身已含 /v1）
//   - 处理 b64_json 或 url 两种返回，存 PNG
//   - 相同的 CLI 接口（prompt 位置参数 + -o/-m/-s/-n/--timeout）
//   - 退出码语义一致：0 成功（stdout 打印保存路径）、1 生成/保存失败、2 参数/环境错误
//
// 用法（与 generate.py 完全兼容，可无缝替换）：
//   node scripts/generate-image.mjs "prompt 内容" -o assets/cover-01.png -s 1024x1024 -m gpt-image-2
//   node scripts/generate-image.mjs --help

import { writeFileSync, mkdirSync } from 'fs';
import { dirname, basename, resolve, extname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

const ENV_TOKEN = 'ANTHROPIC_AUTH_TOKEN';
const ENV_BASE_URL = 'ANTHROPIC_BASE_URL';
const API_PATH = '/v1/images/generations';
const MIN_TIMEOUT = 1800;
const DEFAULT_TIMEOUT = 1800;
const DEFAULT_MODEL = 'gpt-image-2';
const DEFAULT_SIZE = '1024x1024';

function parseArgs(argv) {
  const args = { model: DEFAULT_MODEL, size: DEFAULT_SIZE, count: 1, timeout: DEFAULT_TIMEOUT };
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') { args.help = true; continue; }
    if (a === '-o' || a === '--output') { args.output = argv[++i]; continue; }
    if (a === '-m' || a === '--model') { args.model = argv[++i]; continue; }
    if (a === '-s' || a === '--size') { args.size = argv[++i]; continue; }
    if (a === '-n' || a === '--count') { args.count = parseInt(argv[++i], 10); continue; }
    if (a === '--timeout') { args.timeout = parseInt(argv[++i], 10); continue; }
    if (a.startsWith('--')) { args[a.replace(/^--/, '')] = argv[++i]; continue; }
    positional.push(a);
  }
  args.prompt = positional.join(' ').trim();
  return args;
}

function usage() {
  return `Generate images via image-gen API and save locally.

Usage:
  generate-image.mjs "<prompt>" [-o PATH] [-m MODEL] [-s SIZE] [-n COUNT] [--timeout SEC]

Options:
  prompt              Image generation prompt (required, positional)
  -o, --output PATH   Output file or directory. Default: ./tmp with auto-named file
  -m, --model NAME    Model name (default: ${DEFAULT_MODEL})
  -s, --size SIZE     Image size (default: ${DEFAULT_SIZE})
  -n, --count N       Number of images (default: 1)
  --timeout SEC       Request timeout seconds (default: ${DEFAULT_TIMEOUT}, min ${MIN_TIMEOUT})

Environment:
  ${ENV_TOKEN}       Required. Bearer token for the image-gen API.
  ${ENV_BASE_URL}    Required. API base URL; /v1/images/generations is appended
                      (if BASE_URL already ends with /v1, only /images/generations is added).

Exit codes: 0 = success (saved paths printed to stdout), 1 = generation/save failed, 2 = bad args/env.`;
}

function resolveApiUrl() {
  const base = (process.env[ENV_BASE_URL] || '').trim().replace(/\/+$/, '');
  if (!base) throw new Error(`environment variable ${ENV_BASE_URL} is not set`);
  return base.endsWith('/v1') ? `${base}/images/generations` : `${base}${API_PATH}`;
}

function slugify(s) {
  return (s.slice(0, 30).replace(/[^a-zA-Z0-9]/g, '_').replace(/^_+|_+$/g, '')) || 'image';
}

function timestamp() {
  // Stable formatting without locale deps; mirrors pagecraft's %Y%m%d-%H%M%S.
  const d = new Date();
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function resolveOutputPaths(output, count, prompt) {
  const ts = timestamp();
  const slug = slugify(prompt);
  if (!output) {
    const dir = resolve(process.cwd(), 'tmp');
    mkdirSync(dir, { recursive: true });
    return count === 1
      ? [resolve(dir, `${ts}_${slug}.png`)]
      : Array.from({ length: count }, (_, i) => resolve(dir, `${ts}_${slug}_${i + 1}.png`));
  }
  // Treat as directory if it ends with a separator or already is a directory.
  const looksLikeDir = /[\\/]$/.test(output);
  if (looksLikeDir) {
    mkdirSync(output, { recursive: true });
    return count === 1
      ? [resolve(output, `${ts}_${slug}.png`)]
      : Array.from({ length: count }, (_, i) => resolve(output, `${ts}_${slug}_${i + 1}.png`));
  }
  const outPath = resolve(output);
  mkdirSync(dirname(outPath), { recursive: true });
  if (count === 1) return [outPath];
  const ext = extname(outPath) || '.png';
  const stem = basename(outPath, extname(outPath));
  return Array.from({ length: count }, (_, i) => resolve(dirname(outPath), `${stem}_${i + 1}${ext}`));
}

async function callApi(token, payload, timeoutMs) {
  const url = resolveApiUrl();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    let resp;
    try {
      resp = await fetch(url, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
    } catch (e) {
      throw new Error(`Network error: ${e.message}`);
    }
    if (!resp.ok) {
      const text = await resp.text().catch(() => '');
      throw new Error(`HTTP ${resp.status} error: ${text.slice(0, 500)}`);
    }
    let json;
    try { json = await resp.json(); }
    catch (e) { throw new Error(`Invalid JSON response: ${(await resp.text().catch(() => '')).slice(0, 500)}`); }
    return json;
  } finally {
    clearTimeout(timer);
  }
}

async function downloadImage(url, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    let resp;
    try { resp = await fetch(url, { signal: controller.signal }); }
    catch (e) { throw new Error(`Download network error: ${e.message}`); }
    if (!resp.ok) {
      const text = await resp.text().catch(() => '');
      throw new Error(`Download HTTP ${resp.status} error: ${text.slice(0, 500)}`);
    }
    return Buffer.from(await resp.arrayBuffer());
  } finally {
    clearTimeout(timer);
  }
}

async function saveItem(item, outPath, timeoutMs) {
  if (item.b64_json) {
    writeFileSync(outPath, Buffer.from(item.b64_json, 'base64'));
    return;
  }
  if (item.url) {
    writeFileSync(outPath, await downloadImage(item.url, timeoutMs));
    return;
  }
  throw new Error('item missing both b64_json and url');
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { process.stdout.write(usage() + '\n'); return 0; }

  const token = process.env[ENV_TOKEN];
  if (!token) {
    process.stderr.write(`Error: environment variable ${ENV_TOKEN} is not set.\n`);
    return 2;
  }
  if (!args.prompt) {
    process.stderr.write(`Error: prompt is required.\n\n${usage()}\n`);
    return 2;
  }
  if (!(args.count >= 1)) {
    process.stderr.write('Error: --count must be >= 1\n');
    return 2;
  }
  if (args.timeout < MIN_TIMEOUT) {
    process.stderr.write(`Warning: timeout ${args.timeout}s too low, clamped to ${MIN_TIMEOUT}s\n`);
    args.timeout = MIN_TIMEOUT;
  }

  const payload = { model: args.model, prompt: args.prompt, n: args.count, size: args.size };
  let data;
  try {
    data = await callApi(token, payload, args.timeout * 1000);
  } catch (e) {
    process.stderr.write(`Error: ${e.message}\n`);
    return 1;
  }

  const items = data.data || [];
  if (!items.length) {
    process.stderr.write(`Error: no images returned. Raw response: ${JSON.stringify(data).slice(0, 500)}\n`);
    return 1;
  }

  const paths = resolveOutputPaths(args.output, items.length, args.prompt);
  const saved = [];
  for (let i = 0; i < items.length; i++) {
    try {
      await saveItem(items[i], paths[i], args.timeout * 1000);
      saved.push(paths[i]);
    } catch (e) {
      process.stderr.write(`Warning: failed to save image: ${e.message}\n`);
    }
  }
  if (!saved.length) return 1;
  for (const p of saved) process.stdout.write(p + '\n');
  return 0;
}

main().then((code) => process.exit(code)).catch((e) => {
  process.stderr.write(`Fatal: ${e.message}\n`);
  process.exit(1);
});
