# 风格预设 — 23 套模板的设计语言定义

> 本文档为 Phase 4.1 模板匹配后的风格注入提供结构化参数（**索引版**）。
> 每个模板定义 8 个维度：空间密度、装饰等级分布、组件偏好、排版基调、页面节奏、专属组件、禁用模式、稀疏空间策略。
> 风格预设与颜色方案正交——前者控制"怎么排版"，后者控制"什么颜色"。
>
> **H1 减负**：本文件只保留密度速查表 + 跨页节奏模板。选定模板后**按 `## <deck-name>` 锚点局部读取** [`style-presets-details.md`](./style-presets-details.md)（298 行）取该 deck 完整 8 维度，勿整文件加载。

## 密度速查表

> 仅用于初筛/二次匹配。最终选定 deck 的 8 维度参数从 `style-presets-details.md#<deck-name>` 局部读取。

| 模板 | 空间密度 |
|------|---------|
| pitch-deck | 低密度 |
| weekly-report | 高密度 |
| tech-sharing | 中低密度 |
| product-launch | 低密度 |
| course-module | 中密度 |
| xhs-pastel-card | 极低密度 |
| xhs-white-editorial | 中低密度 |
| knowledge-arch-blueprint | 中密度 |
| consultant-strategy | 中高密度 |
| government-formal-red | 中高密度 |
| soe-engineering-blue | 中密度宽间距 |
| bank-vip-gold | 中低密度留白 |
| academic-defense | 中密度 |
| insight-report | 中高密度 |
| biz-review | 中高密度 |
| compare-eval | 中密度 |
| keynote-formal | 低密度大留白 |
| dir-key-nav-minimal | 中密度 |
| graphify-dark-graph | 中低密度 |
| hermes-cyber-terminal | 中密度 |
| obsidian-claude-gradient | 中密度 |
| presenter-mode-reveal | 中密度 |
| testing-safety-alert | 中密度 |

---

## 视觉节奏模板（对抗 AI 味道）

> Phase 4.2 跨页节奏检查时使用。对任意 N 页的 deck，从对应的风格分组中选择视觉角色分布。

### 商务演示型（pitch-deck / product-launch / weekly-report / presenter-mode-reveal / consultant-strategy / government-formal-red / bank-vip-gold / insight-report / biz-review / compare-eval）

| 页数 | 冲击页(数据/引用/大图) | 呼吸页(分隔/留白/引用) | 非对称页 | 标准网格页 |
|------|:---:|:---:|:---:|:---:|
| 8-10 页 | ≥ 1 | ≥ 1 | ≥ 1 | 其余 |
| 11-15 页 | ≥ 2 | ≥ 2 | ≥ 1 | 其余 |
| 16+ 页 | ≥ 3 | ≥ 2 | ≥ 2 | 其余 |

冲击页候选：L10 stat-highlight（单个大数字+结论）、L09 big-quote（大引用）、L26 image-hero（全幅大图+分层渐变）
呼吸页候选：L03 section-divider（章节分隔）、L09 big-quote（极简引用页）
非对称候选：L26 image-hero、L20 mindmap、L05 cta（居中行动号召）、L27 image-grid（bento 网格）

### 技术型（tech-sharing / knowledge-arch-blueprint / graphify-dark-graph / hermes-cyber-terminal / obsidian-claude-gradient / soe-engineering-blue）

| 页数 | 冲击页 | 呼吸页 | 非对称页 | 标准页 |
|------|:---:|:---:|:---:|:---:|
| 8-10 页 | ≥ 1 | ≥ 1 | ≥ 1 | 其余 |
| 11+ 页 | ≥ 2 | ≥ 2 | ≥ 1 | 其余 |

冲击页候选：L10 stat-highlight、L28 code（全屏代码展示）、L30 terminal
呼吸页候选：L03 section-divider、L09 big-quote

### 小红书/图文型（xhs-pastel-card / xhs-white-editorial）

> 此类风格本身就是"每页独立成图"的节奏，不需要主动插入冲击页/呼吸页。唯一规则：连续 2 页同布局类型时，第 3 页必须切换卡片颜色或排版模式。

### 教学型（course-module）

> 此风格本身就是"每页独立成图"的节奏，不需要主动插入冲击页/呼吸页。唯一规则：连续 2 页同布局类型时，第 3 页必须切换卡片颜色或排版模式。

### 学术/答辩型（academic-defense）

> 沿用商务演示型节奏规则（16 页：≥3 冲击 + ≥2 呼吸 + ≥2 非对称）。冲击页候选：实验结果大数字/公式块、文献综述引用；呼吸页候选：章节分隔（深蓝全屏）。

| 页数 | 冲击页 | 呼吸页 | 非对称页 | 标准页 |
|------|:---:|:---:|:---:|:---:|
| 8-10 页 | ≥ 1 | ≥ 1 | ≥ 1 | 其余 |

冲击页候选：L09 big-quote（核心概念引用）、L26 image-hero（图示）
呼吸页候选：L03 section-divider（模块分隔）

### 告警/安全型（testing-safety-alert）

> 此风格"每页都是冲击页"，红色警示美学贯穿全 deck。不需要额外冲击页。唯一规则：连续 3 页卡片网格时，插入 L09 引用页或 L03 分隔页呼吸。

### 启发/叙事型（keynote-formal / dir-key-nav-minimal / xhs-pastel-card）

> 每页切换背景色的设计本身就是视觉节奏。不应用网格页限制。唯一规则：连续 3 页同类型内容时，插入一页纯文字引用或超大字数字页。

## 重点页强调（受控逃生舱——全局，所有模板适用）

> 解决 HTML「重点不突出、强调色与主色同色系」问题。不放开自由 CSS，强调走**预置 class + token**；强调**决策集中在主 agent 路由表**，subagent 只执行。完整规则与 class 表见 [`subagent-rules.md` §重点页强调](./subagent-rules.md)。

**重点页强调建议**（主 agent 据内容判定，写 `[emph:]` 进 spec）：
- **KPI / 核心数据页** → `[emph: kpi-strong]`（`.kpi-emph`，CTA 色 `--hi-strong` 放大数字）
- **核心结论 / 金句页** → `[emph: takeaway]`（`.takeaway-emph`，CTA 渐变底）
- **增长/达成指标** → `[emph: positive]`（`.metric-positive`，稳定绿 `--hi-positive`）
- **风险/下降指标** → `[emph: warning]`（`.metric-warning`，稳定红 `--hi-warning`）
- **多系列图表** → 用 `var(--data-1..6)` 分色（不再 `--accent` 单色循环）

**Anti_Patterns 守则（全局硬约束，subagent 必须遵守）**：
- **禁 AI purple/pink gradients**——ui-reasoning 多行业 Anti_Patterns 共识，防 AI 退化默认审美。渐变只用 `--grad-soft`/`--grad-emph` 官方 token。
- 行业特定 Anti_Patterns 由 advisor 检索结果（`style_advisor.mjs --json` 的 `reasoning.antiPatterns`）写入 brand-spec/brief，4.1 一次确定。
- Style_Priority 的 Glassmorphism / Liquid Glass / Claymorphism 等 SVG 专属风格**不自动落地**（HTML 渲染 gap），仅作建议文本。

---

## 封面装饰等级 V6（L3 定义 + 3 套装饰包）

> 解决封面氛围克制问题（SVG P01 大色块/渐变/几何装饰/氛围图 vs HTML 装饰克制）。封面允许更高装饰等级 **L3**，预置 3 套装饰包，主 agent 按 deck 类型选。**仍走预置 class + token，不自由 CSS**——装饰包是现有/新增 class 的命名组合，subagent 只挂 class。

### L3 封面装饰等级定义

L3 = **渐变背景层**（`.cover-bg` 或 deck 专属底纹）+ **几何装饰层**（硬边线条/瞄准框/网格，**非光球**——除科技感包外）+ **产品氛围图位**（`.hero-shot` 或 mockup 位，可选）+ **logo 位**（右上或左下）+ **渐变标题 accent 词**（`.gradient-text`，已有）。

### 3 套封面装饰包（按 deck 类型选）

| 装饰包 | 适用 deck 类型 | 预置 class 组合 | 示范 deck |
|--------|--------------|----------------|----------|
| **科技感** | 暗底科技 deck（soe/hermes/graphify/obsidian） | `.soe-grid-bg`(经纬网格) + `.ambient-glow`(蓝 radial) + `.soe-corner-mark`×4(四角瞄准框) + `.gradient-text` | soe-engineering-blue |
| **商务感** | 浅色硬边商务 deck（consultant/bank/insight/biz-review） | `.bar-top`(5px 蓝) + `.cs-corner-deco.tl/.tr/.bl/.br`(4 角硬边 L 型直角线) + `.cs-cover-logo`(右上 logo 位) + `.gradient-text` | consultant-strategy |
| **数据感** | 数据/报表 deck（weekly-report/biz-review） | `.bar-top` + `.cover-grid-bg`(48px 浅网格) + `.kpi-mini-strip`/`.kpi-mini`(封面底部 mini KPI 预览) + `.gradient-text` | weekly-report |

**执行纪律**：
- 主 agent 在 4.1/4.2 据 deck 类型（density 速查表分组）选装饰包，路由表 cover 页 `骨架源` 标注用哪套。
- subagent 按包装饰 class 挂到 `01-cover.html`——**不写 CSS、不发明 class**（新增 class 全在 tokens.css overlay 注册，颜色走 `var(--brand-*)`）。
- 装饰包是「叠加层」：在现有 cover 结构基础上追加装饰 div，**不改现有 data-replace 结构**。
- 其余 deck（非示范 3 类）套用指引见 `style-presets-details.md` 各 deck「装饰等级分布」段。
