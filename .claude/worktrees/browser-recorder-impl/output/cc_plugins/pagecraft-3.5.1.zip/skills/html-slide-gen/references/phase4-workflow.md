# Phase 4 视觉设计与交付 — 完整流程细节

> **加载纪律**：本文件是 SKILL.md Phase 4 的细节下沉产物。**进入 Phase 4 时必须立即完整 Read 本文件**——SKILL.md 只保留 Phase 4 的骨架、每步 Gate 和强约束指针，所有 step 级操作细节都在本文件。漏读会丢 Gate、漏一票否决项、产出坏 deck。
>
> Phase 1-3 阶段**不需要**读本文件——那是策略/骨架/讲稿阶段，无视觉交付。本文件只在 Phase 4 进场时加载。

## 架构原则：Clone & Adapt + 风格模板与颜色方案分离

Phase 4 采用 Clone & Adapt 模型生成 HTML：
- **T1（模板骨架）**：匹配到模板时，复制模板 slide HTML，替换 `data-replace` 标记的内容区域——保留 100% 模板视觉 DNA
- **T2（通用骨架）**：内容类型无模板角色匹配时，从 layout-catalog.md 选通用骨架，应用 Style Transfer 继承模板 composition 特征
- **颜色方案**：`--accent`、`--bg`、`--text-1`、`--grad`……与模板正交，独立注入

标注语法（`data-replace`）见 `references/annotation-spec.md`；模板文件约定（1920×1080 画布 / slide 无 `<style>` / SVG 坐标 / 暗色变体）见 `references/template-tech-facts.md`。

## 4.1 品牌资产与设计方向

**这是 Phase 4 的第一步，品牌资产收集和设计方向确定合并为一次确认。**

> ⚠️ **reference 精读纪律**：进入 Phase 4 后**禁止整批读全部 Phase 4 参考文件**——整批读会显著拖慢并浪费上下文，懒加载（按需局部读）快得多，必须懒加载。
>
> 规则：deck 选定**之前**，只读索引/匹配类文件（`slides-gallery.md`、`color-schemes.json`）做选型；deck 选定**之后**，**只局部读**该 deck 必需的 `slides-gallery-details.md#<deck>` / `slide-roles.md` / `style-presets-details.md#<deck>` / `color-schemes.json`。这几个独立文件可在**一个 turn 内并行 Read**（一次工具往返），不要逐个串行读。Phase 4.2 之后才需要的大参考（layout-catalog / t2-skeletons）在 4.1 **不预读**。

### Step A：Agent 分析内容 → 推荐风格模板 + 颜色方案

Agent 从 strategy.md（文稿类型/受众/核心信息）和 outline.md（场景/行业）提取信号，分别匹配风格模板和颜色方案：

**风格模板匹配**（布局/字体/圆角/组件）：
- 按 `references/slides-gallery.md` **结构化选型矩阵**匹配（本文件已精简为索引+匹配表，~280 行）：先按文稿类型（Phase 1 已定）分流到 A/B/C/D 组，再在组内按「选型判据」定（23 选 1 → 两步小决策）。**选定后**按 `### <deck-name>` 锚点局部读 `references/slides-gallery-details.md`（395 行）取该 deck 色板/组件/匹配条件——勿整文件加载详情。
- 组内仍难分时用三步语义推理兜底
- **零匹配预警**：候选都不达「完整复制/提取组件」门槛时（无模板场景重合 >50%），**显式告知用户**「此 deck 预计高比例走 T2，校验较重」+ 给降级菜单（接受高 T2 / 裁剪篇幅 / 选最近似提取组件），不默默回退
- 无任何匹配时回退到通用模板 `templates/shared/tokens.css`

**颜色方案匹配**（40 个预设，按 mood 标签匹配）：读取 `scripts/color-schemes.json`，按文稿类型对应的 mood 倾向（说服→专业/可信赖、传授→科技/未来感、信息同步→专业/可信赖、启发→温暖/亲和力）匹配 `mood` 字段取候选方案。完整 mood 标签与方案在 json，不在此内联。

**颜色方案来源（二选一）**：

| 来源 | 适用场景 | 操作 |
|------|---------|------|
| **A) 预置方案（默认）** | 无品牌约束，开箱即用 | 从 40 个预设中按 mood 匹配推荐 |
| **B) 参考文件提取（新增）** | 有现成品牌 PPT 或设计截图，要求颜色对齐 | 用户提供 `.pptx` 或 `.png/.jpg`，AI 提取配色生成自定义色板 |

**选项 B 操作流程（E1–E4）**：

> 仅当用户明确提供参考文件、或在 Step B 选择「使用品牌规范」并提供 PPTX/截图时触发。

**E1：接收文件，提取配色**

```bash
# PPTX 输入
node scripts/extract-colors.mjs \
  --input <参考文件路径> \
  --output slides-output/<name>/custom-scheme.json

# 图片输入：先用 Read 工具查看图片，识别 primary/secondary/accent 后：
node scripts/extract-colors.mjs \
  --colors '{"primary":"#XX","secondary":"#XX","accent":"#XX"}' \
  --output slides-output/<name>/custom-scheme.json
```

质量评估处理：
- `good`：正常继续
- `limited`：告知用户「配色信息有限，提取结果可能不准确，建议在 E3 确认时仔细检查」
- `poor`：**必须询问用户是否继续**，不可默默跳过；建议改用预置方案

**E2：读取输出的 custom-scheme.json**，确认 `primary / secondary / accent / data-1..6` 字段。

**E3：渲染色板预览，输出用户确认话术**

读取 `custom-scheme.json` 后，向用户展示配色概览：

```
已从参考文件提取到以下配色：

  整体色调：[深色系/浅色系/暖色/冷色]
  主色：[primary]（页眉/背景）
  辅色：[secondary]（卡片/区域）
  强调色：[accent]（高亮/按钮）

⚠️ 说明：本功能只克隆配色，排版风格（布局密度、装饰等级）
   在下一步正常选择演示模板时决定。

是否保留这套配色？可以描述你想调整的部分。
```

用户可以：直接确认 / 描述微调（如「强调色换成红色」）/ 放弃改用预置方案。

**E4：将 custom-scheme.json 注入 deck**（在 Step C 的命令流中替代 `--scheme` 参数，见下方 Step C 说明）

可选——用户确认后询问是否保存到颜色方案库：

```bash
node scripts/extract-colors.mjs \
  --colors '{"primary":"...","secondary":"...","accent":"..."}' \
  --output slides-output/<name>/custom-scheme.json \
  --save --name "企业品牌蓝-2026"
```

**组合选项**：将推荐模板和颜色方案组合为 3-4 个选项。格式：`"<模板名> + <颜色方案名> <描述>"`。

### Step B：单次 AskUserQuestion 确认（视觉偏好门，合并样张决策）

> 这是 Phase 4 唯一的视觉偏好硬阻塞确认点。设计方向 + 是否先看样张在此一次问完，避免 Step D 再开一个独立往返（见 Step D「默认可选」说明）。

> **继承优先**：检测到已有 `brand-spec.md`（同项目 `slides-output/` 下）时，默认"继承 + 异议才停"——告知用户"检测到已有 brand-spec.md（模板 X + 方案 Y），默认继承，如需改请说明"，异议才走下方完整 Step B 提问。只有首次创建或用户明确要换风格时才走完整提问。`brand-spec.md` 的 `文稿类型` 字段供相似场景匹配（同类型文稿优先沿用上次选择）。

**示例**——系统建设方案汇报（B2B方案推介，企业IT决策层）：
- Question: "设计方向：有品牌资产请选第一项，否则选风格+颜色（如需先看样张再继续，请在选项里说明）——"
- Options:
  1. `"使用品牌规范（稍后提供）"` — 我有 logo/色板文件
  2. `"corporate-clean + ocean-depths 深海蓝（推荐）"` — 商务风深蓝专业
  3. `"corporate-clean + midnight-ink 午夜蓝"` — 商务风暗色高端
  4. `"其他组合 / 先看样张再继续"` — 用户自定义模板+颜色方案，或要求先出样张预览

**偏好记忆**：扫描已有 `brand-spec.md`，上次选过的模板/颜色在同类型文稿中高亮标注。

**可接受格式**：`.png` `.jpg` `.svg`（用视觉能力提取色值等信息）
**不可接受格式**：`.ai` `.psd` `.sketch` `.fig` `.key`（要求用户导出为 PNG/SVG）

**用户确认前，禁止继续。**

### Step C：产生产物

用户确认设计方向后：

1. **生成 `slides-output/<name>/brand-spec.md`**，必须记录：
   - `风格模板: <模板名>`
   - `颜色方案: <颜色方案名>` — 记录用户本次选择的颜色方案
   - `骨架来源: <模板名>` — 指明 Phase 4.2 使用哪个模板的 slide-roles.md（无匹配时填 `layout-catalog`）
   - `文稿类型: <类型>` — 从 strategy.md 提取，供后续相似场景匹配
2. **加载 slide-roles.md**：读取 `templates/starter-decks/<模板名>/slide-roles.md`，理解模板的角色目录、Adapt 规则和 Style Transfer 规则。Phase 4.2 的路由表生成以 slide-roles.md 为首选骨架来源。
   - **并行 Read（精读纪律）**：本步与第 4 步（style-presets-details.md#<deck>）是 deck 选定后必需的两个独立文件，**在一个 turn 内并行 Read**（一次工具往返），不要串行逐个读。这两个文件**常驻本轮**，4.2 填路由表时引用，不重读。
3. **生成 tokens.css**（三命令流，零推理——deck tokens 已是自包含的）：
   ```bash
   # (a) 复制选中模板的自包含 tokens.css（:root 已含 14 个 --brand-* + --border-strong + --grad-soft，overlay 只留半径/字体/排版）
   cp templates/starter-decks/<模板名>/shared/tokens.css  export/<name>-live/shared/tokens.css
   # (a+) 按行业检索 CTA + 数据系列色 → palette.json（advisor BM25，纯标准库 ~3ms；CTA/数据系列随行业，与 brand 解耦）
   node scripts/style_advisor.mjs "<行业/文稿主题，从 strategy.md 提取>" --json > export/<name>-live/shared/palette.json
   # (b) 换上选中的颜色方案 + 注入 advisor palette（15 brand 键来自 color-schemes.json；CTA/数据系列来自 palette.json）
   node scripts/switch-theme.mjs --deck export/<name>-live --scheme <方案名> --palette export/<name>-live/shared/palette.json
   ```
   **【风格克隆分支】若颜色来源为选项 B（参考文件提取）**，Step (b) 改为：
   ```bash
   # custom-scheme.json 已含完整 brand-* + hi-strong + data-1..6，直接作为 scheme 写入
   # switch-theme 不支持直接读 custom-scheme.json，需先注册到 color-schemes.json 再用 --scheme
   # extract-colors.mjs --save 已完成注册（scheme name = custom-from-reference 或用户命名）
   node scripts/switch-theme.mjs --deck export/<name>-live --scheme <custom-scheme-name>
   # 无需 --palette，hi-strong/data-1..6 已内嵌在 custom scheme tokens 中
   ```
   - 14 个 `--brand-*` 变量是 switch-theme 换色的入口（详见 `scripts/switch-theme.mjs` 的 `COLOR_TOKEN_MAP`）。
   - **advisor palette**：`--hi-strong`（CTA）+ `--data-1..6`（数据系列）来自 `palette.json`（行业检索，非 color-schemes）——**随行业变、不随 mood 变**。switch-theme `--palette` 与 15 brand 键同批正则写入 + `mergeSemanticTokens` 幂等合并稳定语义层。
   - **CTA 兜底（C1/D14，2026-06-25）**：每个 scheme 已在 `color-schemes.json` 预置与底色协调的 `hi-strong`（HSL 调和，对比度 ≥ 3.5）+ `data-1..6`（Okabe-Ito）。**无 `palette.json` 时 switch-theme 仍会用 scheme 自带 CTA**（不再留占位橙）——advisor 行业 CTA 更精准（优先），scheme 预设作兜底。**禁止带 `#f97316` 占位橙进 4.2**：validate 的 `cta-placeholder` check 会拦（ERROR `CTA_PLACEHOLDER_LEAK`）。
   - 每个 starter-deck 的 `shared/tokens.css` 是**手写源文件**（self-contained：包含该 deck 的颜色字面量 + 组件层 + §2.5 shared motion utilities + `.tpl-<deck>` overlay 精调）。换色只走 `switch-theme.mjs`，**不存在 tokens 生成器**。
   - **deck tokens.css 结构**（23 个 deck 全部已按此接入 switch-theme）：`[motion tokens :root]` → `[主 :root：14 个 --brand-* 字面色（= deck 默认风格）+ --border-strong + --grad-soft + 7 个 --brand-*-rgb 通道 + 14 个语义色 var(--brand-*) 链路]` → `[组件层]` → `[§2.5 motion utilities]` → `[.tpl-<deck> overlay：deck-private vars 重定向 var(--brand-*)，字面色/rgba 用 var(--brand-*)/rgba(var(--brand-*-rgb),*)]`。换肤时 switch-theme 替换主 :root 的 15 个 brand 键 + 7 个 -rgb 通道，全 deck 联动。
   - **保留字面色**：overlay 内的反白文字（`#fff`/`rgba(255,255,255,*)`）、code-box 深黑、chart 霓虹色、彩虹渐变、语法高亮等**设计装饰色保持字面**，有意不参与换肤。
3. **复制图片资产**到 `export/<name>-live/assets/`，brand-spec.md 只记录 `assets/` 相对路径
4. **加载风格预设**：**按 `## <deck-name>` 锚点局部读** [`references/style-presets-details.md`](./style-presets-details.md) 取该模板完整 8 维度：空间密度、装饰等级分布、组件偏好、排版基调、页面节奏、专属组件、禁用组件、稀疏空间策略。这些约束在 Phase 4.2 填进路由表，在 Phase 4.3 写入 design-decisions.md。**与第 2 步（slide-roles.md）一个 turn 内并行 Read**。
   - （速查表 `references/style-presets.md` ~92 行，仅作密度速查；完整 8 维度走 details 文件局部读，勿整文件加载 details。）

**每次更新 brand-spec.md 后必须立即重跑 `switch-theme --scheme --palette` 同步 tokens.css**（改方案即重跑 (b)；换模板即重跑 (a)+(b)；改行业/主题即重跑 (a+)+(b)）。

**资产本地化硬要求**：
- 所有 HTML 引用 `brand-spec.md` 里的资产文件路径
- Logo / 产品图作为 `<img>` 引用真实文件，NEVER 用 CSS 剪影或占位符代替
- CSS 变量从 brand-spec.md 注入：`:root { --brand-primary: ...; }`，HTML 只用 `var(--brand-*)`
- 想临时加色或改设计参数，先改 `brand-spec.md`
- **禁止在 slides 中引用 assets/ 目录之外的图片路径**

> 完整模板和兜底方案参考 `references/brand-spec-guide.md`。

**Gate**：设计方向已确定 + `brand-spec.md` 已生成 + `tokens.css` 已生成 + 所有图片资产已复制到 `export/<name>-live/assets/` + brand-spec.md 中所有路径均为 `assets/` 相对路径 + 无任何 slide 引用 assets/ 外部路径 + **CTA 已按行业注入**（`tokens.css` 的 `--hi-strong` 非 `#f97316` 占位橙——验证：`grep -E '^\s*--hi-strong:' export/<name>-live/shared/tokens.css` 应为 advisor 检索的行业 CTA，如 B2B Service → `#0369A1`；若仍是占位橙，说明 Step C 的 `style_advisor --json → palette.json` 未执行，**回 Step C 重跑 (a+)+(b)**，禁止带占位橙进 4.2）。

### Step D：样张确认（默认可选，与 Step B 合并为单一视觉门）

> **默认降级为可选**：为减少往返，Step B（设计方向确认）已锁定视觉偏好，**标准模式下默认跳过单独的样张门**，直接进入 4.2 规格生成，在 4.4 交付时一次性确认全部页面。**仅当用户在 Step B 选择"我要先看样张再继续"时**才执行下方样张流程。快速通道模式同样默认跳过。

**制作样张**（仅在用户要求时）：品牌规范和 tokens.css 生成后，**制作 2 张样张**（封面 + 一张典型内容页），写入 `slides-output/<name>/export/<name>-live/slides/`。

样张生成后，**导出为单文件 HTML 供用户预览**：
1. 从模板复制 `index.html`（见 §4.4 的 index/runtime 分离规范），`DECK_MANIFEST` 只填这 2 张样张
2. 运行 `export_single.mjs` 生成 `slides-output/<name>/index.html`（样张预览版）

**走用户确认流程**（仅当执行了样张流程）：
- 告知设计方向（主色调、字体、整体风格），以 Markdown 链接提供单文件 HTML 预览路径
- 在同一个回复中调用 `AskUserQuestion`：
  - Question: "样张风格是否满意？"
  - Options: `["确认，继续"]` + `["调整配色"]` + `["调整字体"]` + `["全面重做"]`

> 样张版 `index.html` 是临时预览文件。Phase 4.4 全部页面生成后，会用完整版 `DECK_MANIFEST` 重新运行 `export_single.mjs` 覆盖生成最终单文件。

> Step D 的样张门默认合并进 Step B 的视觉偏好确认——绝大多数情况下用户只需确认一次设计方向即可推进。

## 4.2 逐页骨架路由（T1 直生，不写 spec 文件）

> **T1 不写 spec 文件**：T1 页的骨架源（模板文件路径）+ chart key 直接写进**路由表**；T1 主 agent 在 4.3 按 outline + 路由表直生 HTML。**仅 T2 需派 subagent 时**写一份精简 brief 给 subagent；T2 若主 agent 直生（≤3 页或超 K_max 回退）也不写 spec。

骨架来源由模板匹配决定：

- **T1（模板骨架）**：从 slide-roles.md 角色匹配 → 使用模板 slide HTML（带 data-replace 标注）
- **T2（通用骨架）**：无角色匹配 → 从 layout-catalog.md 默认匹配池选择通用骨架

**产出物 = 一份路由表**（写入 `slides-output/<name>/routing.md`，作为本次生成决策的留档），覆盖**全部页**（T1/T2 通用）。路由表是 4.3 的唯一驱动——主 agent 直生 T1 时读 outline + 路由表行；T2 派 subagent 时把对应行转成 brief。格式：

```markdown
# 路由表 / Routing

## 页面路由
| 页 | 类型 | 骨架源 | chart | emph | 容量标注 |
|----|------|--------|-------|------|----------|
| P01 | T1 | templates/starter-decks/<deck>/slides/01-cover.html | — | — | — |
| P03 | T1 | .../03-content-metrics.html | — | — | ⚠ arch-infographic: 模块6,脚本检查skip |
| P05 | T2 | t2-skeletons.md#<deck>-L19 | — | — | — |
| P06 | T2 | layout-catalog L06 @ offset=220 | — | — | — |
| P07 | T1 | .../07-content-chart.html | bar_chart | — | card-bg 4 ≤ maxItems 5 ✓ |

## T2 Style Transfer delta（仅 T2 页，从 <deck>/slide-roles.md 复制，不凭记忆）
### P05（t2-skeletons.md#<deck>-L19 — 预置骨架已合并 delta，跳过）
### P06（layout-catalog L06 @ offset=220 — 回退，需注入 delta）
- 空间密度：body padding ...
- 排版层级：h2 82px / 800 / -0.03em
- 装饰模式：.section-num 293px 水印 + .num-tag + 分隔线
- 组件统一：卡片圆角 var(--radius)=27px、grid gap 32px
- 禁止元素：[从 slide-roles.md「禁止引入的视觉元素」表复制]

## 内容映射（data-replace key → 真实内容，来自 outline.md + speech.md PPT-NN 指针）
- P01: section_title → "...", section_tag → "..."
- P07: data-replace key → value（T1 替换槽）；[占位符] → value（T2 替换槽）
- 逐字稿一律指针引用 speech.md PPT-NN，不内联全文
```

> 路由表只承载**决策 + 指针**，不内联讲稿/骨架 HTML 全文。`t2-skeletons.md`/`layout-catalog.md` 是「数据」按锚点/offset 局部读，不并入路由表。T2 派 subagent 时，主 agent 把路由表对应行 + 该页内容映射段封装成 brief prompt（格式见 4.3）。

**排期/甘特/多阶段类页强制分流闸**（在「第零步」分配之前执行，仿冲击页识别模式）：

扫描 outline.md 该页的 `[visual:]` 标签 + 标题/正文关键词。命中以下任一信号 → **即使 slide-roles 角色匹配判为 T1，也强制改判 T2**，骨架源指向 `t2-skeletons.md#consultant-strategy-gantt`（consultant-strategy deck）或 `layout-catalog L23 @ offset=474`（其他 deck 回退）：
- `[visual: gantt]` / `[visual: timeline]` 标签
- 标题/正文含关键词：排期、甘特、月份、阶段、路线图、里程碑、波次、Sprint、季度交付、N 阶段
- outline 显式标注多阶段（≥3 阶段且每阶段有起止时间/月份）

此闸**仅 override 这一类页**——其他页（封面/目录/单卡内容/图表/对比/矩阵等）仍走下方「第零步」步骤 1-4 的 T1 短路逻辑，不受影响。命中后路由表该页 `类型` 列标 `T2（强制分流：gantt）`，`骨架源` 列写锚点/L23 offset。

> **为什么需要这道闸**（dialectic 层 5 根因）：consultant-strategy 等模板的 `process-flow` 角色只做成时间轴，T1 命中即短路，排期类页被锁死在时间轴，L23 甘特选型表 + charts-index 的 roadmap→gantt 首选形同虚设。强制分流让排期类页走 T2 甘特骨架（A' 已预置 `#consultant-strategy-gantt`），不依赖模板角色是否做成甘特变体。**L1（补甘特角色变体）与 L2（本闸）双保险**：模板有甘特变体时 T1 直出，无变体时本闸兜底走 T2 预置锚点。

**第零步：确定每页骨架来源（T1/T2 分配，一次性对所有页算完）**

对 outline.md 中的每一页，按 slide-roles.md 的"角色匹配决策树"执行：

1. 封面/目录/结束/Q&A 页 → 匹配模板对应角色 → T1
2. 内容页在 slide-roles.md 中有角色匹配 → T1
3. 内容页最近角色可通过 Adapt 规则适配 → T1 Adapt（如 3 卡扩为 4 卡）
4. 以上都不匹配 → T2: layout-catalog.md 默认匹配池（12 种）

T2 页面必须应用 Style Transfer 规则（从 slide-roles.md 中读取），确保与 T1 页面视觉一致。Style Transfer 的通用流程和 6 维度检查清单见 `references/style-transfer-guide.md`——执行时先读通用指南了解流程，再从模板 `slide-roles.md` 读取该模板特定的间距值、装饰模式和禁止元素。

**冲击页识别**（在所有分配之前执行，冲击页仍使用 L10/L09 语义，但优先匹配模板角色）：

从 `outline.md` 和 `speech.md` 中扫描冲击信号（大数字/对比结论/转折陈述）。如果该页有模板角色匹配 → T1（优先用模板的数据页角色，如 `content-section-metrics`、`content-chart`）；无匹配 → T2 L10/L09。

**数据页图表选型**（角色 C / 任何 `.page-body` 含图表的页，T1/T2 通用）：

为避免「主 agent 选布局、subagent 再重推图表」两路径割裂，**主 agent 在此步就把图表定下来写进路由表 `chart` 列**，subagent 照抄即可：

1. 读 `templates/charts/charts-index.json` 的 `quickLookup`，按该页数据意图取首选图表（意图键见 json，不在此枚举）
2. 意图重叠时按 tiebreaker（见 `references/subagent-brief.md` §数据页 tiebreaker 决策规则）消歧
3. 在路由表该页 `chart` 列写 `<chart_key>`（如 `bar_chart`），T2 页同时记 L 码
4. **L 码与图表不再各说各话**：L13-L16 仅决定「这是个图表页 + 大致布局」，具体图表以 `chart:` 字段为准

> `charts-index.json` 是主 agent 与 subagent 共同的唯一选型真相源（机器选型）。人工规划"数据类型→布局 L 码"的决策表与反模式速查见 `references/layout-catalog-index.md` §数据可视化决策。subagent 见 `chart:` 字段直接复制对应 `templates/charts/*.html`，不再自行重推。

**容量预检（容量前移，Phase 2.3 跑，不依赖 spec）**：路由表的「容量标注」列对照 `scripts/check-spec-capacity.mjs` 的 `LAYOUT_BUDGETS`（`--list-budgets` 打印）。

> ⚠️ **`--outline` 模式覆盖面有洞，路由表人工补**：`check-spec-capacity.mjs --outline <outline.md>`（Phase 2.3 跑，吃 outline 的 `[visual:]` + `[card-bg:N]` 标签）只认 `VISUAL_TO_LAYOUT` 映射的 **11 种 visual**（stat-grid/feature-cards/comparison/process-flow/timeline/gantt 等）且**必须有 `[card-bg:N]` 标签**；cover/section-divider/illustration/**arch-infographic** 等不在映射里或没标 `[card-bg:]` 的页型被**静默 skip**（不报错也不报容量）。被 skip 的多为装饰页（溢出风险低），但**数据/架构类页（arch-infographic 等）是真实漏检**——对这些页型，主 agent 在路由表「容量标注」列保留**一行人工容量标注**（如 `⚠ arch-infographic: 6 模块, 脚本 skip, 人工确认 ≤4 列`）。
>
> Phase 2.3 容量预检命令：
> ```bash
> node scripts/check-spec-capacity.mjs --outline slides-output/<name>/outline.md
> ```
> （容量门禁在 Phase 2.3 跑 `--outline`，吃 outline 标签。）

> **批量产出许可（减少串行往返）**：路由表是单文件、各页行之间**无 page 间依赖**——节奏检查是事后产物（并入路由表末尾的节奏摘要），不阻塞路由表的写入。因此**允许在 1-2 个 turn 内用 heredoc 批量写出整份路由表**（含全页路由 + T2 delta + 内容映射），而非逐页一个 turn 串行。
>
> 推荐做法：
> 1. 先把"第零步骨架来源分配 + 图表选型 + 冲击页识别"对**所有页一次性算完**（这些决策可整体规划），填进路由表的「页面路由」表
> 2. 选定 deck 后已加载的模板上下文（slide-roles / style-preset / Style Transfer delta）**常驻本轮**，逐页填路由表时引用即可，不重读
> 3. 然后**批量 heredoc 写出** `routing.md`（一次写完整份）
> 4. Phase 2.3 已跑过 `--outline` 容量预检；路由表写完后**再统一跑**节奏检查（并入路由表末尾）
>
> Adapt/拆页/冲击页等**需要页间或容量决策**的少数页，可单独留到路由表初稿写完后处理；不影响主体批量流。

> **T2 骨架源优先路径**（按此顺序，命中即用，不重推理）：
> 1. **`t2-skeletons.md#<template>-<layout>`** —— **首选**。当 `<模板名> × <布局>` 在 `references/t2-skeletons.md` 有预置锚点时，**必须引用该锚点**。当前预置覆盖：pitch-deck × {L19, L21}、tech-sharing × {L21, L17}、weekly-report × {L11, L18}（完整锚点表见 t2-skeletons.md「锚点索引」）。预置骨架已合并 Style Transfer delta，subagent 原样复制 + 替换 `[占位符]` 即可。
> 2. **`layout-catalog Lxx @ offset=N`** —— 回退。无预置锚点时，路由表该页「骨架源」列写明布局编号 + offset（offset 取自 `layout-catalog-index.md`），subagent 直接 `Read layout-catalog.md offset=N limit≈44` 局部读对应布局段，再应用 Style Transfer delta + 替换占位符。

**动画注入规则**（T1/T2 通用，详见 `references/motion-system.md`）：
- 动效强度按模板分 4 档（强/中/轻/零），先查 motion-system.md §6 确认本 deck 的档位。**opt-out 模板（dir-key-nav-minimal、knowledge-arch-blueprint）严禁任何 `anim-*` class。**
- T1 页面：从模板源 HTML **连同 `.anim-*` class 一起复制**（不要只复制 `data-replace` 结构而丢掉 anim class）；内容替换后保留模板原有的动画挂载
- T2 页面：按 motion-system.md §5 的 stagger 配方挂 class——page-header 区域 kicker `anim-fade anim-d1`、title `anim-up anim-d2`、卡片网格用 `.anim-stagger-list` 或手写 `anim-fade-up anim-dN`、KPI `anim-zoom-pop` 等
- **`data-anim` 属性已弃用**（无 JS 消费的死代码），生成 slide 时删除，只保留同名 `.anim-*` class

**跨页节奏检查**（T1/T2 通用，同现有规则）
- 视觉等级：L[1/2/3]

**产出物**：`slides-output/<name>/routing.md`（单一文件，含全页路由表 + T2 Style Transfer delta + 内容映射 + 节奏摘要）。T1 页不产 `specs/PPT-NN.md`。

> **Gate**：路由表覆盖全部页 + 每页骨架来源明确（T1=模板文件路径+角色；**T2 有预置锚点时必须引用 `t2-skeletons.md#<template>-<layout>`**，无预置才用 layout-catalog Lxx @ offset）+ T2 页面的 **Style Transfer delta 与 `<模板名>/slide-roles.md` 的 Style Transfer 段逐项对齐**（主 agent 从 slide-roles.md **复制** padding/标题字号/装饰/禁止元素，不凭记忆）+ 节奏检查通过（视觉角色分布达标 + 无连续 3+ 页同布局 + 无连续 3+ 卡片网格）+ **容量预检已在 Phase 2.3 通过**（`check-spec-capacity.mjs --outline` 无 NEEDS_SPLIT；arch-infographic 等脚本 skip 的页型已有人工容量标注补洞）+ **排期/甘特/多阶段类页已走 T2 + L23/锚点**（强制分流闸已执行——含 `[visual: gantt]`/`[visual: timeline]` 或排期关键词的页，路由表 `类型` 列含「T2（强制分流：gantt）」标注，`骨架源` 指向 `t2-skeletons.md#consultant-strategy-gantt` 或 L23 offset，不允许这类页停留在 T1 时间轴角色）。


## 4.3 生成 HTML 初稿

**前置步骤**：生成前先清空 slides/ 目录，避免上次生成的旧文件残留导致 index.html 的 DECK_MANIFEST 与实际可用文件不匹配：

```bash
rm -f slides-output/<name>/export/<name>-live/slides/*.html || true
```

**生成策略（T1 主 agent 直生，T2 按 K_max 受控调度 subagent）**：

> 🛡️ **护栏基调**：本节是「防 subagent 失控护栏」，不是「加并行提速」。原则：**subagent 不是越多越快，最慢的 subagent 决定 wall-clock**；subagent 派太多会让最慢者拖长整体耗时。因此 T1 一律主 agent 直生（不派 subagent），T2 才在 K_max 约束下派 subagent，K_max=4 为硬上限。

- **T1 页（主 agent 直接生成，无 spec，不派 subagent）**：按模板源文件**分组批量**处理，而非逐页串行——
  1. **批量 cp（一次 tool call 复制多个模板源）**：先扫路由表，按「骨架源」列的模板文件路径分组，同一模板源（如多个 `content-section-card` 页）一次性 `cp` 到各自 `slides/XX-slug.html`：
     ```bash
     # 同一模板源的多页，单次 bash 批量复制
     cp templates/starter-decks/<模板名>/slides/03-content-section-card.html slides/03-foo.html
     cp templates/starter-decks/<模板名>/slides/03-content-section-card.html slides/07-bar.html
     cp templates/starter-decks/<模板名>/slides/05-content-metrics.html     slides/05-baz.html
     # … 其余模板源同理，一组一条 bash
     ```
  2. **复用读入的模板上下文**：同一模板源只 Read 一次（理解其 `data-replace` 槽位结构 + `.anim-*` 编排），同组的后续页引用该上下文逐页替换，不重复读模板。
  3. **逐页替换内容**（读路由表「内容映射」段，对每个 `data-replace="key"` 元素替换）：
     - 纯文本槽（`<p data-replace="kicker">旧</p>`）：替换 textContent
     - 带子标签槽（`<div data-replace="stat"><span>旧</span></div>`）：**保留 `<span>`/`<b>` 包装**，替换其内文本节点（子标签无 class，class 在外层 data-replace 元素上）
     - 模板已把混合内容拆成独立 key（如 `headline` + `headline_accent` 分开），每个 key 的 value 都是纯文本，无需处理"一槽多语义"
  4. 将路由表「逐字稿」指针（`见 speech.md PPT-NN`）对应的讲稿放入 `<aside class="notes">`
  5. 确保 `<body>` 保留 `data-skeleton="t1"` + `tpl-<deck>` class（模板源自带，复制后不可删）
  6. 保留模板源的所有 `.anim-*` class（入场动效编排，属模板视觉语言）

  > 这是 T1「并行」的正确形态——**主 agent 内批量（分组 cp + 复用模板上下文）**，不是派 subagent 并行。T1 派 subagent 是负优化（冷启动税 + 最慢者拖长 wall-clock），绝不采用。

- **T2 页（按 K_max 受控调度 subagent）**：T2 是否派 subagent、派几个，按下方三档决策表。**T2 ≤3 页** 和 **T2 超出 K_max 的页** 都走主 agent 直生（与 T1 同一套替换逻辑，骨架源改为 layout-catalog 局部读 + Style Transfer delta + 占位符替换）。

  | T2 页数 | 调度策略 | subagent 数 K |
  |---------|---------|---------------|
  | ≤ 3 | **主 agent 直生**（冷启动税不划算，不派 subagent） | 0 |
  | 4–12 | 派 subagent，每批约 3 页 | `K = ceil(T2页数 / 3)` |
  | > 12 | **K_max=4 触发**：派 4 个 subagent，超出部分回主 agent 直生 | `min(ceil(T2页数 / 3), 4)` = 4 |

  - 派 subagent 时，每个 subagent 承接约 3 个 T2 页（一个 subagent 可处理少量 T2 页，不必一页一个）。subagent **启动只读 `references/subagent-brief.md` 一份**（若 brief 缺失则回退读 `subagent-rules.md`），主 agent 在 prompt 里给出该批页的路由表行 + 内容映射段。T2 三分支处理（prebaked 锚点 / layout-catalog offset + Style Transfer delta + 占位符替换）见 brief §T2 操作步骤。
  - **K_max=4 是硬上限**：T2 页再多也不无限加 subagent，超出部分回主 agent 直生——宁可主 agent 多干几页，也不让最慢 subagent 把 wall-clock 拖长。

**T1/T2 都不写 CSS、不发明 class 名、不创建自定义组件**。所需 HTML 结构来自模板原件（T1）或 layout-catalog 布局段（T2）。

**技术规范**参考 `references/html-design-system.md`，核心要点：

- **`index.html` 必须从 `templates/index-shell.html` 复制，`index-runtime.js` 必须从 `templates/index-runtime.js` 原样复制。NEVER 使用 starter-deck 模板自带的 index.html——它们是独立演示入口，不与标准 runtime 兼容。**
- `slides/*.html` 每页独立，引用 `../shared/tokens.css`，**不需要 `<style>` 块**（所有样式来自 tokens.css 和骨架已有的 inline style）
- 逐字稿嵌入 `<aside class="notes">` + 写入 `DECK_NOTES` 全局变量

**生成顺序（T1 主 agent 直生为主线，T2 subagent 受 K_max 约束后台并行）**：

1. **先算 T2 调度档位**：按路由表统计 T2 页数，查上方三档决策表定 K（0 / ceil(n/3) / 4）。K=0 时全 deck 主 agent 直生，无 subagent 环节，直接走 T1+T2 直生流。
2. **派 T2 subagent（background 异步，仅 K>0 时）**：按 K 个 subagent 分批，每批约 3 个 T2 页，用 Agent 工具 `run_in_background` 派出。subagent 启动后并行跑（**读 `references/subagent-brief.md` 一份** + 主 agent prompt 里给的路由表行/内容映射 + 按需局部读骨架）。超出 K_max 的 T2 页留在主 agent 队列，不派。
3. **主 agent 同时直生 T1（分组批量）**：派出 T2 subagent 后立即回头做 T1 页（按模板源分组批量 cp → 复用模板上下文逐页替换 data-replace → 注入逐字稿），T2 subagent 在后台跑、T1 在前台跑。T1 做完后若还有「超 K_max 回退主 agent」的 T2 页，继续直生这部分 T2。
4. **join subagent 结果**：T1 + 回退 T2 全部做完后，收集 T2 subagent 的产出，合并进 slides/。若某 subagent 超时/产出 < 500 bytes（见 4.3.1 步骤 0），该批 T2 页回退主 agent 直生补上——**不重新派 subagent**（避免再次冷启动税）。

> 不生成 `specs/` 目录，也不归档——路由表（`routing.md`）是本次生成的决策留档，留原地即可。

> **耗时视角（防失控）**：并行后总耗时 ≈ max(T1 主 agent 耗时, T2 subagent 耗时)。多数 deck T2 页少（K=0 或 K=1），T2 subagent 在 T1 直生期间就跑完，几乎零额外等待。**本节目标不是提速，而是防亏损**：K_max=4 把 subagent 数量与最慢者钳制在可控范围，兜底 subagent 失控风险。

**T2 subagent 任务分配格式**（仅 T2 页需要；T1 页主 agent 直接处理无此格式）：

T2 subagent 的 prompt 构造、任务分配格式、操作步骤详见 `references/subagent-brief.md` §T2 操作步骤。主 agent 调度时把**该批**（约 3 个 T2 页）路由表行 + 内容映射段 + 模板名传入一个 subagent，subagent **启动读 `references/subagent-brief.md` 一份**，按需再局部读 t2-skeletons/layout-catalog 对应段（Read ≤ 2）。一个 subagent 处理多个 T2 页时，prompt 里逐页给出路由表行 + 内容映射，subagent 顺序生成该批全部页后一次性返回。

**Subagent prompt 原则**：包含页面映射（页码 → 路由表行/骨架源）+ 内容映射（data-replace key → 真实内容 / T2 `[占位符]` → 真实内容）；不包含逐字稿全文（subagent 自行从 `speech.md PPT-NN` 指针读取）、tokens.css 内容、模板设计说明。

**Subagent 启动只读 `references/subagent-brief.md` 一份**，按 brief 指示的骨架源局部读一次（T2-prebaked 额外局部读 t2-skeletons.md 对应锚点；T2-offset 额外局部读 layout-catalog.md 对应 offset 段）。不需要读 tokens.css。

**Subagent prompt 构造原则**：
- **包含**：页面映射表（页码 → 路由表「骨架源」列/骨架源）+ 内容映射表（data-replace key → 真实内容 / `[占位符]` → 真实内容，来自路由表「内容映射」段）+ 该页 Style Transfer delta（仅 T2-offset 回退路径）
- **不包含**：逐字稿全文（subagent 自行按 `speech.md PPT-NN` 指针读取）、tokens.css 内容、模板设计说明
- **T1 页面额外要求**：prompt 中明确 `<body>` 必须保留 `data-skeleton="t1"` 属性（模板文件自带，复制后不可删除）

## 4.3.1 全局一致性审查（所有页面生成完成后立即执行）

**步骤 0：验证 T2 subagent 产出**（T1 页主 agent 直接生成无需此验证；仅 T2 页由 subagent 产出，需确认文件实质性生成）：

```bash
for f in slides-output/<name>/export/<name>-live/slides/*.html; do
  size=$(wc -c < "$f" 2>/dev/null || echo 0)
  if [ "$size" -lt 500 ]; then
    echo "MISSING/EMPTY: $f ($size bytes) — 主 agent 直生补上（不重新派 subagent）"
  fi
done
```

T2 页 < 500 bytes 或不存在 = subagent 失败，**回退主 agent 直生该页**（走 T2 直生路径：layout-catalog 局部读 + Style Transfer delta + 占位符替换），不再重新派 subagent——避免再次冷启动税推高 wall-clock。无 T2 页时跳过本步。

**步骤 0.5：自动化后处理**（在手动审查之前运行，消除跨页共性问题）：

```bash
# 一站式后处理：footer 间距、compact-header、manifest 同步、notes 同步、硬编码颜色、组件使用率、风格违规检查
node scripts/post-process.mjs --deck slides-output/<name>/export/<name>-live --style <模板名>
```

此命令自动完成 footer-padding、compact-header、DECK_MANIFEST 同步、DECK_NOTES 提取、硬编码颜色替换、slide-top-bar 补全、**组件使用率检查**、**风格违规检查**，然后运行 validate。只有 post-process 报告 ERROR 时才需要手动介入。

**审查清单**（主 agent 直接审查所有 slide HTML）：

| 检查项 | 方法 | 严重度 |
|--------|------|--------|
| footer 结构一致 | 所有内容页 `.tech-footer` 内部子元素标签是否统一（都是 `<span>` 不是 `<p>`） | ERROR |
| 标题 class 一致 | 所有内容页是否都用 `<h2 class="title">`，无自创 class | ERROR |
| 信息密度均匀 | 相邻页面的内容占画布比例不应一页极松一页极紧（差异 > 30 个百分点需检查） | WARNING |
| 装饰等级达标 | 所有页面满足对应等级（L1/L2/L3），详见 `references/subagent-brief.md` §骨架速查 | ERROR |


发现不一致时，直接修改对应 slide HTML 修复，不重新调度 subagent。

## 4.3.2 审查后复跑后处理（仅当手动改过文件）

**前置**：步骤 0.5 已在审查前运行过一次完整 post-process。本步骤**仅在审查中手动修改了 slide HTML** 时才需要重跑，目的是把手动修改后的文件重新对齐 footer/compact-header/manifest/notes、并复跑 validate。若审查未改动任何文件，**跳过本步骤**直接进入 4.3.3。

```bash
# 仅当审查中手动改过 slide 文件才执行
node scripts/post-process.mjs --deck slides-output/<name>/export/<name>-live --style <模板名>
```

此命令自动完成：footer-padding、compact-header、DECK_MANIFEST 同步、DECK_NOTES 提取、硬编码颜色替换、slide-top-bar 补全，然后运行 validate。只有 post-process 报告 ERROR 时才需要手动介入。如需单独修复某项，使用 `scripts/batch-fix.mjs`（详见 `--help`）。

## 4.3.3 结构校验

post-process 已在步骤 0.5 / 4.3.2 跑过 `validate --mode strict`（全 26 check，含 runtime）。**本步不再单独跑 `--check runtime`**——strict 模式已覆盖且更严（全量 ERROR），单独 `--check` 是冗余调用。仅当 post-process 报 `RUNTIME_*` ERROR 时才人工复查 `index-runtime.js`（独立文件存在 + index.html 以 `<script src="index-runtime.js">` 外链引用）。

**PPTX 专项预检**（editable 导出前可选执行，所有检查均为 WARNING）：
```bash
node scripts/validate-pptx.mjs --slides slides-output/<name>/export/<name>-live/slides --mode editable
```

**Gate**：所有页面 HTML 已生成 + `export/<name>-live/index.html` 已从 `templates/index-shell.html` 复制（非 starter-deck 版本）+ **`export/<name>-live/index-runtime.js` 已从 `templates/index-runtime.js` 原样复制为独立文件**（非内联，此条一票否决；已含在 post-process strict 的 `runtime` check 内）+ slide 数量在"确认篇幅"阶段约定的范围内 + 所有 slides 引用 tokens.css + `<aside class="notes">` 已嵌入逐字稿 + post-process 报告 0 ERROR + 全局一致性审查通过。

> ⚠️ **runtime 文件硬要求**（post-process strict 已查，此处仅说明）：`index-runtime.js` 必须作为独立文件存在（≥5000 字节，非 stub）。若缺失，演讲者视图(S键)、逐字稿覆盖层(N键)、深链接、Presenter Window 全部失效。post-process 报 `RUNTIME_FILE_MISSING`/`RUNTIME_FILE_STUB`/`RUNTIME_SCRIPT_MISSING` 时按提示修复：
> ```bash
> test -f slides-output/<name>/export/<name>-live/index-runtime.js && echo "OK" || echo "MISSING: copy templates/index-runtime.js"
> ```

## 4.3.4 视觉验收（程序静态分析，禁 AI/浏览器看图）

**职责边界（见 SKILL.md 开头"校验分层原则 + 能力克制"）**：主流程视觉验收只走程序静态扫描；观感判断交用户。**不**在此调 `preview_slides.mjs`、**不**用 AI 图像分析。

post-process 已在步骤 0.5 / 4.3.2 跑过 `validate --mode strict`，其中含 `visual` check（`image-manifest.md` 与 outline 视觉标注一致性：`VISUAL_MANIFEST_MISSING`/`VISUAL_ALL_FAILED`）。**本步不再单独跑 `--check visual`**——strict 已覆盖。仅当 post-process 报 `VISUAL_*` ERROR 时才人工复查 image-manifest。

**静态 grep 抽查**（程序，零浏览器依赖；丰富度兜底，非 ERROR——validate 无对应正检查，仅作交付前肉眼可见的丰富度底线）：
- 每页有 ≥1 个 gradient（L1 底线）：`grep -c 'linear-gradient\|radial-gradient' slides/*.html` 应每页 ≥ 1
- 章节分隔/封面页有 box-shadow（L2+）：`grep -c 'box-shadow' slides/<cover/section>*.html` ≥ 1
- 内容溢出提示：validate 的 `OVERFLOW_HINT`（> 900 字符）标注的页，交付时让用户人工瞄一眼是否需要拆页

> 「无硬编码颜色残留」已由 post-process 的 `hardcoded-colors` fix（强制替换 hex/rgb → var(--xxx)）+ `theme-compliance` check 覆盖，不再单独 grep。gradient / box-shadow 丰富度属正向视觉检查，validate 暂无对应 check，故保留 grep 兜底。

> **不截图、不调 AI**：浏览器截图（`preview_slides.mjs`）和 AI 图像分析仅在 4.4 用户确认环节、且**用户主动要求**时触发。主流程不预判观感。

**Gate**：post-process 0 ERROR（含 `visual` check）+ 静态 grep 抽查通过。**通过后自动生成单文件 HTML**：
```bash
node scripts/export_single.mjs --deck slides-output/<name>/export/<name>-live --out slides-output/<name>/index.html
```

## 4.4 用户确认与导出

1. 输出入口链接：
   - 单文件：`[index.html](./slides-output/<name>/index.html)`
   - Elevo 内：如有 `AGENT_FRONTEND_BASE_URL` 和 `AGENT_WORKSPACE_ID`，运行 `print_preview_url.mjs` 输出 Markdown 链接
   - 如有 `present_result` 工具，调用它输出结构化结果卡片：两个 `file` item——多文件站点入口 `display_mode: "preview"` + `presentation_mode: "site"`，单文件入口默认渲染。参考交互风格指南中的 present_result 示例
2. **S 键**打开演讲者视图，逐页检查
3. 根据用户反馈迭代调整（修改多页 HTML 后重新运行 `export_single.mjs` 更新单文件）
4. 用户确认最终版本后提醒可导出，用户确认需要导出时执行：
   ```bash
   # hybrid 模式（默认）：装饰截图保留 + 文字可编辑
   node scripts/export_pptx.mjs --slides export/<name>-live/slides --out export/<标题>.pptx --mode editable
   # 纯图片模式：视觉 100% 保真，文字不可编辑
   node scripts/export_pptx.mjs --slides export/<name>-live/slides --out export/<标题>.pptx --mode image
   # PDF：逐页截图合并
   node scripts/export_pdf.mjs --slides export/<name>-live/slides --out export/<标题>.pdf
   ```

**PPTX editable 降级策略**：editable 失败 → `validate-pptx.mjs` 查报错 → 修复最多 2 轮 → 仍失败则向用户说明并改用 `--mode image`（视觉 100% 保真，仅文字不可编辑）。
