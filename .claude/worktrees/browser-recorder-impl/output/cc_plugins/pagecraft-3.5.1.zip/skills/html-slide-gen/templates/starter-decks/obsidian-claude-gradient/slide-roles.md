# obsidian-claude-gradient — Slide Role Catalog

> **模板气质**：GitHub-dark, purple-blue-green gradient titles, center-aligned, purple pill tag, purple left-border highlight
> **默认 color-scheme**：#0d1117, purple #7c3aed → blue #60a5fa → green #34d399 gradient
> **适用文稿类型**：传授/赋能
> **叙事结构**：flow
> **叙事结构（14 页，按出现顺序）**：cover → agenda → big-statement → section → comparison → feature-grid → diagram → illustration → steps → code → timeline → stats → quote-cta → thanks
>
> 01–03 为「开篇」（封面 + 目录 + 论点宣言）；04–08 为「机制」（章节切入 + 对比 + 能力 + 架构图 + 插图，对应 Why & How-it-works）；09–11 为「落地」（步骤 + 配置 + 路线图，对应 How-to）；12–14 为「收束」（数据 + 行动号召 + 致谢）。其中 02/03/06/07/08/11 为 v2 新增板式（目录/宣言/能力矩阵/SVG 架构图/SVG 插图/时间线）。

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面 | .oc-h1(渐变 accent), .oc-sub, .oc-pill×3 |
| 02 | `agenda` | 目录/路线图 | .oc-agenda(.oc-agenda-row×4: .oc-agenda-num + .oc-agenda-body), mono 编号 |
| 03 | `big-statement` | 单句宣言 | .oc-statement(.oc-statement-bar 渐变竖条 + .oc-statement-text + .oc-statement-foot) |
| 04 | `section` | 章节分隔 | .oc-h1(146px), .oc-sub, .oc-tag 章节标签 |
| 05 | `comparison` | 双卡片对比+高亮条 | .oc-grid-2, .oc-card, .oc-badge, .oc-hl |
| 06 | `feature-grid` | 3×2 能力矩阵 + inline SVG 图标 | .oc-feat(3 col grid), .oc-card×6, .oc-feat-icon(inline `<svg>`), .oc-feat h4/p |
| 07 | `diagram` | SVG 架构图（数据流+反馈回路） | .oc-diagram(full-width), inline `<svg>`(rect/text/line/path + markers), gradient core node |
| 08 | `illustration` | 插图页：左 SVG 双链图谱 + 右标题/要点 | .oc-illus(2 col grid), .oc-illus-figure(inline `<svg>` node-link graph), .oc-illus-point×3, .oc-illus-caption |
| 09 | `steps` | 步骤列表 | .oc-steps, .oc-step(.oc-sn+.oc-sc), 渐变序号圆圈 |
| 10 | `code` | 代码展示 | .oc-code(pre+语法高亮), .oc-sub caption |
| 11 | `timeline` | 水平时间线（4 节点，中间渐变高亮） | .oc-timeline, .oc-tl-track(4 col), .oc-tl-line, .oc-tl-node(.done/.active)+.oc-tl-dot, .oc-hl |
| 12 | `stats` | 三大数字卡片+高亮条 | .oc-grid-3, .oc-card, .oc-big, .oc-hl |
| 13 | `quote-cta` | 引用+CTA 行动号召 | .oc-quote(blockquote+.attr), .oc-pill×4 |
| 14 | `thanks` | 结尾致谢 | .oc-big.oc-g, .oc-sub |

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`page-num`, `tagline`, `heading`, `subtitle`, `pill-1`, `pill-2`, `pill-3`
- **不可改动**：.oc-cbg / .oc-cgrid 背景层、.oc-tag 结构、.oc-h1 字号(96px)/字重(800)、.oc-pill 容器结构
- **内容适配规则**：
  - `heading` 中保留 `<span class="oc-g">` 包裹渐变词，替换时只改文字不改 class
  - `subtitle` 控制在 50 字以内，可用 `<br>` 断行
  - `pill-1`~`pill-3` 每项控制在 12 字以内，emoji + 英文组合风格；icon 用 `<svg class="oc-ic">` inline（不要换回 `<img src=...svg>`，本 deck 无 assets 目录）

### `agenda`  *(v2 新增)*
- **源文件**：`slides/02-agenda.html`
- **可替换键**：`page-num`, `tag`, `heading`, `agenda1-num`~`agenda4-num`, `agenda1-title`~`agenda4-title`, `agenda1-body`~`agenda4-body`
- **不可改动**：.oc-agenda / .oc-agenda-row 结构、.oc-agenda-num(mono 编号 78px 宽列)、行底 border-bottom 分割线
- **内容适配规则**：
  - 章节数 3~6，增删 `.oc-agenda-row` 元素，每行含 `.oc-agenda-num`(编号) + `.oc-agenda-body > h4 + p`
  - `agendaN-num` 用 `01`/`02`… mono 风格两位编号
  - `agendaN-title` 控制在 20 字以内，`agendaN-body` 控制在 30 字以内

### `big-statement`  *(v2 新增)*
- **源文件**：`slides/03-big-statement.html`
- **可替换键**：`page-num`, `statement`, `footnote`
- **不可改动**：.oc-statement 容器、.oc-statement-bar(渐变竖条 purple→green)、.oc-statement-text 字号(76px)/字重(800)
- **内容适配规则**：
  - `statement` 保留 `<span class="oc-g">` 包裹一个渐变关键词，整体 1~3 行，每行 ≤ 12 字（用 `<br>` 断行）
  - `footnote` 为脚注说明，控制在 50 字以内
  - 这是「一句话打透」的板式，宁可短不要挤

### `section`
- **源文件**：`slides/04-section.html`
- **可替换键**：`page-num`, `chapter-label`, `heading`, `subtitle`
- **不可改动**：.oc-cbg / .oc-cgrid 背景层、.oc-h1 字号(146px inline style)保留、.oc-sub 结构
- **内容适配规则**：
  - `chapter-label` 格式 `CHAPTER XX`，表示章节编号
  - `heading` 中保留 `<span class="oc-g">` 包裹渐变词
  - `subtitle` 控制在 30 字以内

### `comparison`
- **源文件**：`slides/05-content.html`
- **可替换键**：`page-num`, `tag`, `heading`, `card1-badge`, `card1-title`, `card1-body`, `card2-badge`, `card2-title`, `card2-body`, `highlight`
- **不可改动**：.oc-grid-2 (grid 1fr 1fr)、.oc-card 结构(含 `::before` 渐变顶边)、.oc-badge 样式(保留 oc-bb / oc-bp class)、.oc-hl(紫色左边框)
- **内容适配规则**：
  - `card1-badge` 与 `card2-badge` 使用对应 class：`oc-bb`(蓝色) / `oc-bp`(紫色) / `oc-bg`(绿色) / `oc-bo`(橙色)
  - `card1-body` / `card2-body` 可用 `•` 列点，每项控制在 25 字以内
  - `highlight` 格式 `<svg class="oc-ic">…</svg><b>标签：</b>内容`，icon 用 inline SVG（不要换回 `<img>`），保留 `<b>` 包裹的关键词

### `feature-grid`  *(v2 新增)*
- **源文件**：`slides/06-feature-grid.html`
- **可替换键**：`page-num`, `tag`, `heading`, `feat1-icon`~`feat6-icon`, `feat1-title`~`feat6-title`, `feat1-body`~`feat6-body`
- **不可改动**：.oc-feat (grid 3 col)、.oc-card 结构、.oc-feat-icon 容器(inline `<svg>` + `fill:currentColor`，颜色由 `.oc-feat-icon` 的 color 控制)
- **内容适配规则**：
  - 能力数 3~6（3 的倍数填满行最整齐），增删 `.oc-card`；grid 列数可在 inline style 改 `grid-template-columns:repeat(N,1fr)`
  - `featN-icon` 是 inline `<svg viewBox="0 0 16 16">` 片段（path 自带），替换图标时换 `<svg>...</svg>` 整段，**不要换成 `<img>`**（本 deck 无 assets 目录）。图标库见 `templates/assets/icons/*.svg`（取其 `<path>` 内联进来）
  - `featN-title` 控制在 8 字以内，`featN-body` 控制在 25 字以内

### `diagram`  *(v2 新增)*
- **源文件**：`slides/07-diagram.html`
- **可替换键**：`page-num`, `tag`, `heading`, `diagram`(整段 inline SVG)
- **不可改动**：.oc-diagram 满宽容器、SVG viewBox(1200×460)、`<defs>` 内 `oc-grad`/`oc-arrow`/`oc-arrow-w` 引用
- **内容适配规则**：
  - `diagram` 是一整段 `<svg>`，节点用 `<rect>` + `<text>`，箭头用 `<line marker-end>`，反馈回路用虚线 `<path stroke-dasharray>`
  - 核心节点用 `fill="url(#oc-grad)"`（渐变），普通节点用 `fill="#161b22" stroke="#30363d"`
  - 改节点数量/位置时同步改连线坐标；文字用 `<text text-anchor="middle">`，注释色 `#8b949e`/`#484f58`
  - 保持「一条读流（实线灰）+ 一条写回路（虚线紫）」的双向叙事，这是本板式的视觉重点

### `illustration`  *(v2 新增)*
- **源文件**：`slides/08-illustration.html`
- **可替换键**：`page-num`, `figure`(左 inline SVG), `caption`, `title`, `subtitle`, `point1-title`~`point3-title`, `point1-body`~`point3-body`
- **不可改动**：.oc-illus (grid 2 col, gap 72px)、.oc-illus-figure SVG 结构、.oc-illus-point(.num + .pt-title + .pt-desc)
- **内容适配规则**：
  - `figure` 是一整段 `<svg>`（node-link 图谱：`<line>` 边 + `<circle>` 节点 + `<text>` 标签），中心 hub 用 `fill="url(#oc-hub)"` 渐变。替换时换整段 `<svg>`
  - `title` 保留 `<span class="oc-g">` 包裹渐变词
  - 要点 2~4 个，增删 `.oc-illus-point`；`pointN-title` ≤ 8 字，`pointN-body` ≤ 30 字
  - 左图右文是固定 split，若改图文比例调 inline grid-template-columns

### `steps`
- **源文件**：`slides/09-steps.html`
- **可替换键**：`page-num`, `tag`, `heading`, `step1-title`, `step1-body`, `step2-title`, `step2-body`, `step3-title`, `step3-body`, `step4-title`, `step4-body`
- **不可改动**：.oc-steps 容器、.oc-step(.oc-sn+.oc-sc) 结构、.oc-sn 渐变序号圆圈、.oc-step 底部分割线
- **内容适配规则**：
  - 步骤数 3~6，增删 `.oc-step` 元素，每步含 `.oc-sn`(数字) + `.oc-sc > h4 + p`
  - `.oc-sn` 内数字随步骤序号同步更新
  - `stepN-title` 控制在 25 字以内，`stepN-body` 控制在 40 字以内

### `code`
- **源文件**：`slides/10-code.html`
- **可替换键**：`page-num`, `tag`, `heading`, `caption`
- **不可改动**：.oc-code (pre 结构，#010409 暗底)、语法高亮 span 结构(.cm/.cc/.cs/.cp/.ca)、代码内容为结构骨架保留原样
- **内容适配规则**：
  - `heading` 为代码文件名或配置标题
  - `caption` 为代码下的说明文字，控制在 40 字以内
  - 代码块本身保留语法高亮 span 结构，替换时维护 class 分配

### `timeline`  *(v2 新增)*
- **源文件**：`slides/11-timeline.html`
- **可替换键**：`page-num`, `tag`, `heading`, `node1-when`~`node4-when`, `node1-title`~`node4-title`, `node1-body`~`node4-body`, `highlight`
- **不可改动**：.oc-timeline / .oc-tl-track(4 col grid)、.oc-tl-line(横线)、.oc-tl-node(.done/.active) + .oc-tl-dot 结构、.active 节点渐变高亮
- **内容适配规则**：
  - 节点数 3~6，增删 `.oc-tl-node`，同步改 `.oc-tl-track` 的 `grid-template-columns:repeat(N,1fr)`
  - `nodeN-when` 用 mono 风格 `DAY 0–30 · 标签`，大写带分隔符
  - `.done` = 已完成（灰点），`.active` = 当前高亮（渐变点 + 光晕），不加 class = 未来。整页只给 1 个 `.active`
  - `nodeN-title` ≤ 12 字，`nodeN-body` ≤ 30 字；`highlight` 可选，格式同 comparison

### `stats`
- **源文件**：`slides/12-stats.html`
- **可替换键**：`page-num`, `tag`, `heading`, `stat1-value`, `stat1-label`, `stat2-value`, `stat2-label`, `stat3-value`, `stat3-label`, `highlight`
- **不可改动**：.oc-grid-3 (grid 1fr 1fr 1fr)、.oc-card 结构、.oc-big 字号(106px inline style)/字重(900)
- **内容适配规则**：
  - `statN-value` 为数字/百分比，控制在 10 字符以内
  - `statN-label` 为标签说明，控制在 15 字以内
  - `highlight` 格式同 comparison 角色

### `quote-cta`
- **源文件**：`slides/13-quote-cta.html`
- **可替换键**：`page-num`, `tag`, `quote`, `attribution`, `cta-1`, `cta-2`, `cta-3`, `cta-4`
- **不可改动**：.oc-quote(blockquote + .attr) 结构、blockquote `::before` 装饰引号、.oc-pill 容器结构
- **内容适配规则**：
  - `quote` 保留 `<span class="oc-g">` 包裹渐变词，整体控制在 40 字以内
  - `attribution` 格式 `— 来源身份`，控制在 25 字以内
  - `cta-1`~`cta-4` 为行动号召链接，每项控制在 20 字以内

### `thanks`
- **源文件**：`slides/14-thanks.html`
- **可替换键**：`page-num`, `heading`, `url`
- **不可改动**：.oc-big.oc-g (渐变大字 186px/900)、.oc-cbg / .oc-cgrid 背景层
- **内容适配规则**：
  - `heading` 控制在 15 字以内
  - `url` 保留 `<b style="color:var(--oc-accent3)">` 包裹链接文本

---

## 角色匹配决策树

1. 封面 → `cover` | 结尾致谢 → `thanks` | 章节分隔 → `section`
2. 全篇目录/大纲（带编号的并列项） → `agenda`
3. 一句话打透的论点/宣言（单句大字 + 脚注） → `big-statement`
4. 有两列对比内容+高亮结论 → `comparison`
5. 多个并列能力/特性（每项 icon + 标题 + 说明） → `feature-grid`
6. 有系统架构/数据流/时序（用方框+箭头） → `diagram`
7. 有概念结构图解（node-link 图谱 + 右侧说明） → `illustration`
8. 有步骤/流程/操作指引(带序号) → `steps`
9. 有代码或配置块 → `code`
10. 有时间轴/路线图/里程碑(带时序) → `timeline`
11. 有3个数据指标展示+高亮结论 → `stats`
12. 有引用语+行动号召链接 → `quote-cta`
13. 不匹配 → T2 fallback（见 Style Transfer）

---

## Style Transfer — T2 页面继承规则

### 空间密度对齐
- body padding: 对齐 `85px 130px`
- grid gap: `.oc-grid-2` 用 25px, `.oc-grid-3` 用 21px, `.oc-feat` 用 24px, `.oc-illus` 用 72px, `.oc-tl-track` 用 24px
- steps gap: `.oc-step` 用 0 (由 padding 25px 0 + border-bottom 控制间距)
- agenda gap: `.oc-agenda-row` 用 0 (由 padding 25px + border-bottom 控制)

### 装饰模式继承
- 所有页面统一带 `.oc-cbg`(双径向渐变辉光) + `.oc-cgrid`(网格叠加)（cover/section/thanks/illustration 等居中页都带；agenda/statement 等也带）
- 内容页顶部用 `.oc-tag`（紫色 pill 标签，`oc-bp` 紫色底）
- 高亮结论统一用 `.oc-hl`（紫色左边框 + 紫色半透明底）
- 卡片统一用 `.oc-card`（暗底 `#161b22` + 渐变顶边 `::before`）

### 组件类名统一
- 标签：`.oc-tag`（紫色 pill）+ `.oc-badge.oc-bp/oc-bb/oc-bg/oc-bo`（卡片内小标签）
- 卡片：`.oc-card`（不用 `.card` / `.card-accent`）
- 行动号召：`.oc-pill`（暗底 `#21262d`）
- 代码：`.oc-code`（不用 `.terminal`）
- 渐变文字：`.oc-g`（purple→blue→green 135deg 渐变）
- 图标：`<svg class="oc-ic">`（inline svg，`fill:currentColor`，不用 `<img src=...svg>`——本 deck 无 assets 目录）

### 排版层级对齐
- 封面标题：`.oc-h1`, 96px, weight 800, letter-spacing -0.02em
- 章节标题：`.oc-h1`, 146px (inline override)
- 内容页标题：`.oc-h2`, 59px, weight 700, letter-spacing -0.015em
- 宣言大字：`.oc-statement-text`, 76px, weight 800（介于 h1 与章节之间）
- 副标题/说明：`.oc-sub`, 26px, color: `--oc-dim` (#8b949e)
- 标签：`.oc-tag`, 14px, weight 700, uppercase, letter-spacing 0.12em
- 代码：`.oc-code`, 19px, JetBrains Mono
- mono 编号：`.oc-agenda-num` / `.oc-tl-when` / `.oc-illus-point .num`, SF Mono, accent3 色

### SVG 板式（diagram / illustration / feature-grid）继承
- 颜色一律用 deck 色板：节点底 `#161b22` + 边 `#30363d`，核心节点 `fill="url(#oc-grad)"` 渐变，文字 `#e6edf3`/`#8b949e`/`#484f58`
- inline SVG 自包含，**不引用 `../assets/icons/*.svg`**（本 deck 无 assets 目录，`<img>` 会 404）。需要图标时把 `templates/assets/icons/*.svg` 的 `<path>` 内联进来，`fill="currentColor"`
- 箭头用 `<defs><marker>` + `marker-end` 引用；反馈/异步流用 `stroke-dasharray` 虚线

### T2 fallback 规则
当内容不匹配以上任何角色时，按此优先级继承：
1. 多个并列能力项 → 继承 `feature-grid`，增删 `.oc-card`，grid 列数随项数调
2. 有系统结构 → 继承 `diagram`，改 inline SVG 节点/连线
3. 有概念图解+说明 → 继承 `illustration`，左图右文
4. 有时序 → 继承 `timeline`，增删 `.oc-tl-node`
5. 正文为主+无视觉元素 → 继承 `comparison` 骨架，改为单卡 `.oc-card`
6. 有编号流程 → 继承 `steps`，增删 `.oc-step`
7. 有数据 → 继承 `stats`，调整卡片数量(2~4)
8. 有引用 → 继承 `quote-cta`

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| `.terminal` / `.bar` / `.dot` | obsidian-claude-gradient 用 `.oc-code` 的纯暗底 pre，无 macOS chrome |
| `.card-accent` | 用 `.oc-card`(渐变顶边 ::before) 代替顶部 accent 色条 |
| `.kicker` | 用 `.oc-tag`(pill 标签) 做章节标识 |
| `.deck-footer` | 用 `.oc-snum`(右上角页码) 代替底栏 |
| `.gradient-text` | 用 `.oc-g`(specific gradient class) 代替通用渐变 |
| `<img src="../assets/icons/*.svg">` | 本 deck 无 assets 目录，`<img>` 会 404；图标一律 inline `<svg class="oc-ic">` |
| 白色/浅色底 | 此模板暗底 `#0d1117`，不兼容浅底组件 |
