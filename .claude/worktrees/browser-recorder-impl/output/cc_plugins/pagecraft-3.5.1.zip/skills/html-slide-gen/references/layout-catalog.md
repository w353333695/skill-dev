# 布局目录：32 种 Slide 布局参考

> **轻量速查**：[layout-catalog-index.md](layout-catalog-index.md) — 32 种布局的名称、视觉等级、容量、一句话描述。subagent 优先加载索引页，确定布局后按需读取本文件获取完整 CSS/HTML 骨架。
>
> **分层选择**（降低 AI 默认决策复杂度）：
> - **默认匹配池（12 种）**：AI 正常决策时仅从这些中选择——L01 L02 L03 L04 L05 L06 L08 L09 L10 L11 L12 L17
> - **扩展武器库（20 种）**：以下场景按需加载——①用户指定特定布局、②内容类型在默认池无匹配、③用户反馈想换表现方式
> - 默认池覆盖 80%+ 内容页需求；扩展池仅在上述三类场景按需加载

## 快速决策图（默认匹配池）

| 内容类型 | 布局 | 说明 |
|---------|------|------|
| 封面 | L01 | 全屏垂直居中，h1+lede+pills |
| 目录/议程 | L02 | 双列卡片网格，编号+标题+描述 |
| 章节分隔 | L03 | 居中列，112px h1+divider-accent |
| 感谢/结束 | L04 | 居中，contact info+pills |
| 行动号召 | L05 | 居中，h1+lede+cta button |
| 要点列表 | L06 | page-header+.point 列表 |
| 三卡片 | L08 | page-header+.grid.g3+.card |
| 大引用 | L09 | 居中，serif h1+attribution |
| 大数字 | L10 | 居中，mega 数字+lede |
| KPI 指标 | L11 | .grid.g4+.kpi-card |
| 柱状图 | L12 | page-header+.chart-bars |
| 时间线 | L17 | page-header+.timeline |

> 以上 12 种覆盖 80%+ 的内容页需求。其余 20 种为扩展武器库——当用户明确要求或默认池无匹配时按需加载。

## 目录（8 类，共 32 种布局）

- [一、结构型页面（5 个）](#一结构型页面5-个)
- [二、文本型页面（5 个）](#二文本型页面5-个)
- [三、数据型页面（6 个）](#三数据型页面6-个)
- [四、图表型页面（7 个）](#四图表型页面7-个)
- [五、对比与媒体型（4 个）](#五对比与媒体型4-个)
- [六、代码/开发型（3 个）](#六代码开发型3-个)
- [七、工具型（1 个）](#七工具型1-个)
- [八、次级信息型（1 个）](#八次级信息型1-个)

---

本文档描述 32 种 slide 布局（分 8 类）的 CSS 模式和 HTML 骨架，供 Phase 4.2 逐页规划时参考。

布局中使用的工具类（`.kicker` `.h1` `.card` `.grid` `.row` 等）定义在 `templates/shared/tokens.css` 模板中，生成时直接使用。

> **PPTX V2 引擎——零约束**：TreeWalker 全覆盖文本提取、渐变/SVG/背景图自动截图保留、`::before`/`::after` 伪元素自动转换。HTML 生成阶段无需遵守任何特殊规则。导出说明见 `references/editable-pptx.md`。

## 一、结构型页面（5 个）

### L01

**视觉等级要求**: L3
**必须包含**: 渐变顶条 + ambient glow(×2) + card shadow + icon halo 或 deco-circle
**布局**：垂直居中列，全屏。

```
kicker
h1 (.gradient-text 可选)
lede
.row.wrap > .pill ×N
```

**变体**：顶部 `.deck-header`（eyebrow 元信息如活动名/日期），底部 `.deck-footer`（作者/页码）。


---

### L02 目录 (toc)

**视觉等级要求**: L1
**必须包含**: 至少 1 个 gradient（渐变顶条或背景渐变）
**布局**：`.grid.g2` 双列卡片网格。

```html
<div class="grid g2 mt-l">
  <div class="card"><div class="row">
    <div class="h3 dim2" style="width:56px">01</div>
    <div><h4>标题</h4><p class="dim">描述</p></div>
  </div></div>
  <!-- 最后一项可 grid-column:span 2 全宽 -->
</div>
```

---

### L03

**视觉等级要求**: L2
**必须包含**: 渐变顶条 + card shadow + ambient glow（至少 1 个）+ decor circle
**布局**：居中列，限宽 780px。

```
kicker（章节编号）
h1（112px，.gradient-text）
.divider-accent
lede
```


---

### L04

**视觉等级要求**: L3
**必须包含**: 渐变顶条 + ambient glow(×2) + card shadow + icon halo + 装饰圆点
**布局**：`.center.tc` 居中列。

```
h1（180px，.gradient-text "Thank You"）
lede
联系信息 .row（name/email, github, year）
```


---

### L05 行动号召 (cta)

**视觉等级要求**: L2
**必须包含**: 渐变顶条 + card shadow（CTA 按钮）+ ambient glow（至少 1 个）
**布局**：`.center.tc` 居中列，限宽 900px。

```
kicker
h1（96px）
lede
两个按钮：主按钮（bg:var(--accent) pill）+ 次按钮（outline border）
```

**按钮 CSS**：
```css
.btn     { display:inline-flex; padding:16px 28px; border-radius:999px; background:var(--accent); color:#0b1024; font-size:18px; font-weight:600; box-shadow:var(--shadow-lg); text-decoration:none; }
.btn.out { background:transparent; border:1.5px solid var(--border-strong); color:var(--text-1); box-shadow:none; }
```

---

## 二、文本型页面（5 个）

### L06

**视觉等级要求**: L1
**容量**: 3-5 条，每条约 25 字符。超出 5 条建议拆为两页。
**必须包含**: 至少 1 个 gradient（渐变顶条或背景渐变）
**布局**：垂直 `.card.card-accent` 堆叠。

```html
<ul style="list-style:none;padding:0;display:grid;gap:14px;">
  <li class="card" style="border-left:3px solid var(--accent);">
    <h4>① 标题</h4>
    <p class="dim">描述文字</p>
  </li>
</ul>
```

**要点**：用圆圈数字 ①②③ 做 h4 前缀，不用 `list-style`。


---

### L07 双栏 (two-column)

**视觉等级要求**: L1
**布局**：`.grid.g2` 双卡片。

```html
<div class="grid g2 mt-l" style="align-items:start;">
  <div class="card">左栏内容：h3 + p.dim + ul</div>
  <div class="card">右栏内容：h3 + pre.mono 代码块</div>
</div>
```

**适用**：概念 vs 示例、文字 vs 代码、图文并排。

---

### L08 三栏 (three-column)

**视觉等级要求**: L1
**容量**: 3 卡片，每卡标题 ≤15 字符 + 正文 ≤40 字符。**不可加第 4 卡**（grid 列数固定 3）。
**超限处理**: 5 项内容 → L08 3+2 变体（上行 3 卡 `.g3` + 下行 2 卡居中用 `.g2` + `justify-content:center`），或拆两页各 3 项 + 2 项

```html
<div class="grid g3 mt-l">
  <div class="card"><div style="font-size:40px">🧩</div><h4 class="mt-s">标题</h4><p class="dim">描述</p></div>
  <div class="card">...</div>
  <div class="card">...</div>
</div>
```

**适用**：3 个并列概念/特性/步骤概述。

---

### L09 大引用 (big-quote)

**视觉等级要求**: L1
**布局**：`.center.tc` 居中，限宽 1040px。

```html
<div style="font-size:140px;color:var(--accent);opacity:.6;line-height:1">"</div>
<blockquote class="serif" style="font-size:56px;line-height:1.25;font-style:italic;font-weight:600;margin:-40px 0 24px;">
  金句正文<br>可多行
</blockquote>
<p class="dim" style="font-size:20px;letter-spacing:.08em;">—— 出处/人物</p>
```

---

### L10

**视觉等级要求**: L2
**必须包含**: 渐变背景 + ambient glow + card shadow
**布局**：`.center.tc` 居中，单个超大数字。

```html
<div style="font-size:260px;font-weight:900;line-height:1;letter-spacing:-.05em;">
  <span class="gradient-text">97</span><span class="gradient-text">%</span>
</div>
<h3 class="mt-s">支撑说明</h3>
<p class="lede">补充描述</p>
```


---

## 三、数据型页面（6 个）

### L11 KPI 网格 (kpi-grid)

**视觉等级要求**: L1
**容量**: 固定 4 卡（`.grid.g4`）。**不可加第 5 卡**（grid 列数固定 4）。
**超限处理**: 5-6 个指标 → 用 `.kpi-grid.col3` 双行（上 3 + 下 2/3），或拆两页"核心指标"+"辅助指标"
**必须包含**: 渐变顶条 + KPI 卡片使用 .kpi-card 组件
**布局**：`.grid.g4` 四列指标卡。

```html
<div class="grid g4 mt-l">
  <div class="card">
    <p class="eyebrow">指标名</p>
    <div style="font-size:56px;font-weight:800">数值<span style="font-size:20px">单位</span></div>
    <p class="dim" style="color:var(--good);font-size:14px">↑ 12% vs 上月</p>
  </div>
  <!-- ×4 -->
</div>
```

**趋势颜色**：`var(--good)` 增长，`var(--warn)` 持平，`var(--bad)` 下降。


---

### L12 表格 (table)

**视觉等级要求**: L1
**容量**: ≤7 行（含表头）。超出 → 拆为两表或分页
**布局**：卡片内全宽表格。

```css
.t { width:100%; border-collapse:collapse; font-size:16px; }
.t th, .t td { padding:14px 16px; text-align:left; border-bottom:1px solid var(--border); }
.t th { font-size:12px; text-transform:uppercase; letter-spacing:.1em; color:var(--text-3); }
.t tr:hover td { background:var(--surface-2); }
.t td.num { font-variant-numeric:tabular-nums; text-align:right; }
.up { color:var(--good); } .dn { color:var(--bad); }
```

**要点**：数值列用 `.num` 右对齐 + `tabular-nums`；趋势用 `.up`/`.dn` 着色。

---

### L13 柱状图 (chart-bar)

**视觉等级要求**: L1
**推荐**: 使用 `templates/charts/bar-chart.html` 纯 CSS 柱状图组件（PPTX 导出友好）。spec 的 `chart:` 字段决定具体图表类型（bar / grouped_bar / stacked_bar / horizontal_bar 等），subagent 复制对应 `templates/charts/*.html`。
**布局**：卡片内放图表组件 `.chart-bars`。

```html
<div class="card mt-l" style="padding:28px">
  <!-- 复制 templates/charts/bar-chart.html 的 .chart-bars 片段 -->
</div>
```

> ⚠️ 不再用 Chart.js（导出会 rasterize 失真，且与 token 主题联动不稳）。仅当页面需交互/动态数据时才退回 Chart.js。

**Token 读取**：`--accent`、`--text-2`、`--border`。

---

### L14 折线图 (chart-line)

**视觉等级要求**: L1
**推荐**: 使用 `templates/charts/line-chart.html` 内联 SVG 折线组件（token 着色，PPTX 导出友好，2 系列）。如需交互或动态数据再用 Chart.js `type:'line'`（`tension:.4`、`fill:true`、`borderWidth:3`）。

**Token 读取**：`--accent`、`--accent-2`、`--text-2`、`--border`。

---

### L15 饼图 (chart-pie)

**视觉等级要求**: L1
**推荐**: 使用 `templates/charts/donut-chart.html` 纯 CSS 环形图组件，或 Chart.js
**布局**：`.grid.g2`，左=甜甜圈图，右=洞察卡片。

```
type:'doughnut', cutout:'62%'
```

5 个 segment 颜色：`--accent`、`--accent-2`、`--accent-3`、`--good`、`--warn`。

**Token 读取**：`--accent`×3、`--accent-2`、`--accent-3`、`--good`、`--warn`、`--text-2`。

---

### L16 雷达图 (chart-radar)

**视觉等级要求**: L1
**推荐**: 使用 `templates/charts/radar-chart.html` 内联 SVG 雷达组件（5 轴、2 系列多边形，token 着色）。如需交互或动态数据再用 Chart.js `type:'radar'`（`suggestedMin:0, suggestedMax:10`）。

**Token 读取**：`--accent`、`--accent-2`、`--text-2`。

---

## 四、图表型页面（7 个）

### L17 流程图 (flow-diagram)

**视觉等级要求**: L1
**容量**: 3-5 节点。超出 → 拆为子流程（"总览 + 详情 A + 详情 B"）
**推荐**: 使用 `templates/charts/process-flow.html` 纯 CSS 流程图组件
**布局**：水平 flex 管道。

```css
.flow { display:flex; align-items:center; gap:16px; margin-top:40px; max-width:1200px; }
.flow .node { flex:1; background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:22px; text-align:center; box-shadow:var(--shadow); }
.flow .node .ic { font-size:32px; margin-bottom:6px; }
.flow .node h4 { font-size:16px; }
.flow .node p { font-size:12px; color:var(--text-3); margin:0; }
.flow .arr { color:var(--text-3); font-size:28px; flex-shrink:0; }
.flow .node.hl { border-color:var(--accent); box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 18%,transparent),var(--shadow); }
```

```
[.node] → [.node.hl] → [.node] → [.node]
```


---

### L18

**视觉等级要求**: L1
**容量**: 3-5 时间点。超出 → 拆两行或分页
**推荐**: 使用 `templates/charts/timeline.html` 纯 CSS 时间线组件
**布局**：5 列水平时间线。

```css
.tl { position:relative; margin-top:40px; }
.tl::before { content:""; position:absolute; left:0; right:0; top:48px; height:2px; background:var(--border); }
.tl .row { display:grid; grid-template-columns:repeat(5,1fr); gap:22px; align-items:start; }
.tl .item { position:relative; padding-top:80px; text-align:center; }
.tl .dot { position:absolute; top:36px; left:50%; transform:translateX(-50%); width:24px; height:24px; border-radius:50%; background:var(--accent); border:4px solid var(--bg); box-shadow:0 0 0 2px var(--accent); }
.tl .year { font-size:14px; color:var(--text-3); letter-spacing:.12em; text-transform:uppercase; position:absolute; top:0; font-weight:600; }
```

**要点**：`::before` 伪元素画水平线；圆点 `top:36px` 坐标需与线条对齐。


---

### L19 路线图 (roadmap)

**视觉等级要求**: L1
**容量**: 固定 4 列。**不可加列**（grid 列数固定 4）。
**超限处理**: 5+ 阶段 → 拆两页或改用 L18 时间线
**布局**：4 列无缝网格（gap:0，共享 border）。

```css
.rm { display:grid; grid-template-columns:repeat(4,1fr); gap:0; margin-top:28px; border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; }
.rm .col { padding:20px 22px; border-right:1px solid var(--border); }
.rm .col:last-child { border-right:none; }
.rm .col .tag { display:inline-block; padding:3px 12px; border-radius:999px; font-size:11px; background:var(--surface-2); color:var(--text-2); }
.rm .col.now { background:color-mix(in srgb,var(--accent) 6%,var(--surface)); }
.rm .col.now .tag { background:var(--accent); color:#fff; }
```

**要点**：当前阶段 `.now` 高亮；tag pill 标记阶段。


---

### L20

**视觉等级要求**: L1
**布局**：绝对定位节点 + SVG 连接线。

```css
.mm { position:relative; max-width:1200px; height:520px; margin:30px auto 0; }
.mm .n { position:absolute; background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:12px 18px; box-shadow:var(--shadow); font-weight:600; }
.mm .root { top:calc(50% - 34px); left:calc(50% - 100px); width:200px; padding:22px; background:var(--accent); color:#fff; border:none; text-align:center; font-size:20px; border-radius:24px; }
.mm svg { position:absolute; inset:0; width:100%; height:100%; pointer-events:none; }
.mm svg path { stroke:var(--border-strong); stroke-width:1.5; fill:none; }
```

**要点**：子节点用 inline `top`/`left`/`right` 定位；SVG `path` 画贝塞尔连接线。需根据内容数量手动计算坐标。


---

### L21 架构图 (arch-diagram)

**视觉等级要求**: L1
**布局**：多行分层网格，自适应 tier 数量撑满画布。

> **设计原则**：架构图是 slide 上最需要"大气"的图表类型。宁可元素内部留白、字体放大，也要利用好整个 1920×1080 画布空间。不要缩成一小坨。

```css
.arch { margin-top:28px; display:grid; grid-template-rows:auto auto auto; gap:32px; flex:1; }
.arch .tier { display:grid; grid-template-columns:140px 1fr; align-items:stretch; gap:28px; }
.arch .tname { display:flex; align-items:center; justify-content:center; background:var(--surface-2); border-radius:var(--radius); padding:24px 18px; font-weight:600; font-size:18px; color:var(--text-2); text-transform:uppercase; letter-spacing:.1em; text-align:center; }
.arch .cells { display:grid; grid-template-columns:repeat(4,1fr); gap:22px; }
.arch .cells.three { grid-template-columns:repeat(3,1fr); }
.arch .cells.two { grid-template-columns:repeat(2,1fr); }
.arch .cell { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:28px 24px; text-align:center; box-shadow:var(--shadow); }
.arch .cell .ic { font-size:34px; }
.arch .cell h4 { font-size:21px; margin:0 0 8px; }
.arch .cell p { font-size:16px; color:var(--text-2); margin:0; line-height:1.5; }
.arch .tier.hl .cell { border-top:3px solid var(--accent); }
```

```
[tier-name] | [cell] [cell] [cell] [cell]
[tier-name] | [cell] [cell] [cell] [cell]  ← .hl 高亮
[tier-name] | [cell] [cell] [cell]
```

**层级数量适配**：
- 2 层：加大 gap 到 48px，每层自然增高
- 3-4 层：标准 gap 32px，`.arch` 加 `flex:1` 自动撑满
- 5+ 层：拆为 2 页或改用表格

> **层名必填（A1，D15）**：每个 `.tier` 的 `.tname` **必须填层名**（如「访问入口/核心模块/数据底座/采集执行」），不可留空。空层名会触发 validate `ARCH_LAYER_UNNAMED`。层名是架构图的语义骨架，缺名 = 架构无意义。
> **空间撑满（V2）**：`.arch` 用 `flex:1` 自适应高度撑满 page-body（≥80%）；每层 cell 用 `.cells.two/.three`（默认）控制列数，2-3 个 cell 时用更宽列，**不要把 5 层挤成小卡片**——层数多就拆页。

**每层 cell 数量**：
- 2 个 cell → `.cells.two`（2 列，每个 cell 自然变宽）
- 3 个 cell → `.cells.three`（3 列）
- 4 个 cell → 默认 `.cells`（4 列）
- 5+ 个 cell：拆为子层或用 `.grid` 替代

**body 布局**：架构图页 body 用 `style="justify-content:flex-start;padding:80px 150px 60px"` 顶对齐，让架构图从上往下自然展开。标题区保持紧凑（h2 + lede 一行概括），把更多垂直空间留给图。

**禁止**：不要把 `p` 的文字颜色设为 `var(--text-3)`（太淡投影看不清），用 `var(--text-2)`。

---

### L22 步骤图 (process-steps)

**视觉等级要求**: L1
**容量**: 固定 4 步。超出 → 拆为"总览（4 步）+ 详情（N 页）"
**推荐**: 也可使用 `templates/charts/process-flow.html` 水平流程组件
**布局**：`.grid.g4` 四列步骤卡，圆形数字徽章半嵌入顶部。

```css
.steps { display:grid; grid-template-columns:repeat(4,1fr); gap:22px; margin-top:24px; }
.step { position:relative; padding:24px 26px; border:1px solid var(--border); border-radius:var(--radius); background:var(--surface); box-shadow:var(--shadow); }
.step .num { position:absolute; top:-24px; left:22px; width:48px; height:48px; border-radius:50%; background:var(--accent); color:#fff; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:20px; box-shadow:var(--shadow); }
.step h4 { margin:18px 0 8px; font-size:17px; }
.step p { font-size:13px; color:var(--text-2); line-height:1.6; }
.step .tag { display:inline-block; margin-top:10px; font-size:11px; padding:3px 10px; border-radius:999px; background:var(--surface-2); color:var(--text-3); }
```

**要点**：`.num` 用 `top:-24px` 浮在卡片上方；可选 `.tag` 标注耗时。

---

### L23 甘特图 (gantt)

**视觉等级要求**: L1
**布局**：13 列网格（标签 + 12 周列），绝对定位条形。

```css
.gantt { margin-top:24px; background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:24px; }
.gantt .hd { display:grid; grid-template-columns:200px repeat(12,1fr); gap:4px; font-size:12px; color:var(--text-3); text-transform:uppercase; margin-bottom:10px; padding-bottom:10px; border-bottom:1px solid var(--border); }
.gantt .row { display:grid; grid-template-columns:200px repeat(12,1fr); gap:4px; align-items:center; height:40px; }
.gantt .lbl { font-size:14px; font-weight:500; }
.gantt .cells { grid-column:2/-1; position:relative; height:28px; background:linear-gradient(90deg,var(--surface-2) 1px,transparent 1px) 0 0/calc(100%/12) 100%; }
.gantt .bar { position:absolute; top:4px; height:20px; border-radius:6px; background:var(--gradient); display:flex; align-items:center; padding:0 10px; font-size:11px; color:#fff; font-weight:600; box-shadow:var(--shadow); }
```

**条形定位**：`style="left:X%; width:Y%"` 百分比对应周数位置。


---

## 五、对比与媒体型（4 个）

### L24 对比 (comparison)

**视觉等级要求**: L1
**推荐**: 使用 `templates/charts/comparison-table.html` 对比表格组件
**布局**：3 列网格 — 左卡 | 箭头 | 右卡。

```css
.vs { display:grid; grid-template-columns:1fr 90px 1fr; gap:28px; align-items:stretch; margin-top:30px; }
.vs .side { padding:30px; }
.vs .mid { font-size:56px; font-weight:800; color:var(--text-3); display:flex; align-items:center; justify-content:center; }
.vs .bad-side { border-top:3px solid var(--bad); }
.vs .good-side { border-top:3px solid var(--good); }
.vs .bad-side li::marker { color:var(--bad); }
.vs .good-side li::marker { color:var(--good); }
```

---

### L25 优劣势 (pros-cons)

**视觉等级要求**: L1
**推荐**: 也可使用 `templates/charts/matrix-2x2.html` 四象限组件
**布局**：`.grid.g2` 双列，绿/红色彩编码。

```css
.pc { display:grid; grid-template-columns:1fr 1fr; gap:28px; margin-top:30px; }
.pc .card h3 { display:flex; align-items:center; gap:10px; }
.pc .card h3 .b { display:inline-flex; width:36px; height:36px; border-radius:10px; align-items:center; justify-content:center; font-size:20px; }
.pc .pro h3 .b { background:color-mix(in srgb,var(--good) 18%,transparent); color:var(--good); }
.pc .con h3 .b { background:color-mix(in srgb,var(--bad) 18%,transparent); color:var(--bad); }
.pc .pro { border-top:3px solid var(--good); }
.pc .con { border-top:3px solid var(--bad); }
```

**要点**：h3 内 `.b` 是彩色图标徽章（✓ / ✗）。


---

### L26

**视觉等级要求**: L2
**必须包含**: gradient overlay + 装饰性 shadow（图片卡片）+ ambient glow
**布局**：全幅卡片内分层渐变 + Ken Burns 动画 + 底部文字叠层。

```css
.hero { position:relative; height:calc(100% - 112px); border-radius:var(--radius-lg); overflow:hidden; box-shadow:var(--shadow-lg); }
.hero .bg { position:absolute; inset:0; background:radial-gradient(...) ,linear-gradient(...); animation:kb 12s ease-in-out infinite alternate; }
.hero .overlay { position:absolute; inset:0; background:linear-gradient(180deg,transparent 40%,rgba(10,12,20,.65)); }
.hero .caption { position:absolute; bottom:48px; left:56px; right:56px; color:#fff; z-index:2; }
.hero h1 { font-size:72px; line-height:1; font-weight:800; letter-spacing:-.03em; color:#fff; }
.hero p { font-size:20px; opacity:.85; color:#fff; }
@keyframes kb { from{transform:scale(1)} to{transform:scale(1.08)} }
```

**要点**：实际使用时 `.bg` 改为 `<img>` 标签（需遵守 editable-pptx 约束）。渐变方案适合无图兜底。


---

### L27 图片网格 (image-grid)

**视觉等级要求**: L1
**布局**：Bento 网格（4 列 × 180px 行）。

```css
.gg { display:grid; grid-template-columns:repeat(4,1fr); grid-auto-rows:180px; gap:14px; margin-top:24px; }
.gg .cell { border-radius:var(--radius); overflow:hidden; position:relative; box-shadow:var(--shadow); }
.gg .cell span { position:absolute; inset:auto 0 0 0; padding:12px 14px; color:#fff; font-size:13px; font-weight:500; background:linear-gradient(transparent,rgba(0,0,0,.55)); }
.gg .c1 { grid-column:span 2; grid-row:span 2; }  /* 大卡 2×2 */
.gg .c7 { grid-column:span 2; }                     /* 宽卡 2×1 */
```

**要点**：7 格 bento 布局（1 大 + 5 小 + 1 宽）。每格用渐变色或 `<img>` 做背景。


---

## 六、代码/开发型（3 个）

### L28 代码 (code)

**视觉等级要求**: L1
**布局**：卡片内代码块，highlight.js 语法高亮。

```html
<!-- highlight.js -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/tokyo-night-dark.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/javascript.min.js"></script>

<pre class="card mt-m" style="padding:24px;margin-top:16px;">
  <code class="language-javascript">代码内容</code>
</pre>
<script>hljs.highlightAll();</script>
```

**要点**：HTML 中 `>` 需转义为 `&gt;`。

---

### L29 Diff

**视觉等级要求**: L1
**布局**：卡片内 Git 风格 diff 显示。

```css
.diff { font-family:var(--font-mono); font-size:14px; line-height:1.6; border-radius:var(--radius); overflow:hidden; border:1px solid var(--border); }
.diff .ln { display:block; padding:2px 16px; white-space:pre; }
.diff .add { background:rgba(26,175,108,.12); color:var(--good); }
.diff .del { background:rgba(224,68,90,.12); color:var(--bad); }
.diff .ctx { color:var(--text-2); }
.diff .hd { background:var(--surface-2); color:var(--text-3); padding:8px 16px; font-size:12px; letter-spacing:.08em; text-transform:uppercase; border-bottom:1px solid var(--border); }
```

```html
<div class="card diff mt-l" style="padding:0">
  <div class="hd">filename.js</div>
  <span class="ln ctx"> context line</span>
  <span class="ln del">- removed line</span>
  <span class="ln add">+ added line</span>
  <span class="ln ctx"> context line</span>
</div>
```


---

### L30 终端 (terminal)

**视觉等级要求**: L1
**布局**：终端模拟器美学。

```css
.term { font-family:var(--font-mono); font-size:16px; background:#020803; border:1px solid rgba(0,255,120,.3); border-radius:10px; padding:24px 28px; box-shadow:0 0 60px rgba(0,255,136,.08) inset; }
.term .bar { display:flex; gap:6px; margin-bottom:16px; }
.term .bar span { width:12px; height:12px; border-radius:50%; background:#222; border:1px solid rgba(0,255,120,.3); }
.term .p { color:var(--accent); }   /* prompt */
.term .c { color:var(--text-1); }   /* command */
.term .o { color:var(--text-2); }   /* output */
.term .caret { display:inline-block; width:9px; height:18px; background:var(--accent); animation:blink 1s step-end infinite; }
@keyframes blink { 50% { opacity:0; } }
```

```html
<div class="term mt-l">
  <div class="bar"><span></span><span></span><span></span></div>
  <div><span class="p">$ </span><span class="c">command here</span></div>
  <div class="o">output here</div>
  <div><span class="p">$ </span><span class="caret"></span></div>
</div>
```


---

## 七、工具型（1 个）

### L31 待办清单 (todo-checklist)

**视觉等级要求**: L1
**容量**: 4-8 项。超出 8 项 → 拆两页
**布局**：垂直清单，自定义复选框。

```css
.todo { max-width:820px; margin-top:26px; list-style:none; padding:0; }
.todo li { display:flex; align-items:flex-start; gap:14px; padding:14px 18px; border-bottom:1px solid var(--border); }
.todo li .b { flex-shrink:0; width:22px; height:22px; border:2px solid var(--border-strong); border-radius:6px; display:flex; align-items:center; justify-content:center; margin-top:2px; }
.todo li.done .b { background:var(--good); border-color:var(--good); color:#fff; }
.todo li.done .b::after { content:"✓"; font-weight:900; }
.todo li.done .t { text-decoration:line-through; color:var(--text-3); }
.todo li .t { font-size:18px; }
.todo li .tag { margin-left:auto; font-size:12px; color:var(--text-3); }
```

```html
<ul class="todo">
  <li class="done"><span class="b"></span><span class="t">已完成项</span><span class="tag">#tag</span></li>
  <li><span class="b"></span><span class="t">待办项</span><span class="tag">#tag</span></li>
</ul>
```

---

## 八、次级信息型（1 个）

### L32 次级信息条 (secondary-info-bar)

**视觉等级要求**: L1
**容量**: 3-6 项信息标签，全宽横条
**用途**: 团队规模、工具链、网络环境、技术栈等补充信息——视觉层级低于主卡片，放在内容区底部

**布局**：全宽横条，浅底卡片承载多个并排信息项。

```css
.info-bar {
  display: flex; gap: 32px; align-items: center;
  padding: 14px 24px;
  background: var(--surface-2);
  border-radius: var(--radius-sm);
  border: 1px solid var(--border);
  font-size: 14px;
}
.info-bar .info-item {
  display: flex; align-items: center; gap: 8px;
}
.info-bar .info-label {
  color: var(--text-3); font-size: 12px; font-weight: 500;
  text-transform: uppercase; letter-spacing: .06em;
}
.info-bar .info-value {
  color: var(--text-1); font-weight: 600;
}
```

```html
<div class="info-bar">
  <div class="info-item"><span class="info-label">团队</span><span class="info-value">60+ 人</span></div>
  <div class="info-item"><span class="info-label">一线</span><span class="info-value">35 人</span></div>
  <div class="info-item"><span class="info-label">二线</span><span class="info-value">15 人</span></div>
  <div class="info-item"><span class="info-label">工具链</span><span class="info-value">Jira + Confluence + GitLab</span></div>
</div>
```

**与主内容的关系**：`.info-bar` 放在 `.page-body` 底部，与上方主卡片保持间距（`margin-top: 20px`）。它是"二级信息"——观众快速扫读，不需要长时间注视。

---

## 九、复合 page-body 骨架（composite）

> **解决**（003 主线三 F）：单页需同时承载**两类异类组件**时（如「能力卡矩阵 + 闭环流程图」「KPI 条 + 明细表」），L01-L32 单组件骨架无法表达。复合骨架 = 同一 `.page-body` 内两个区域用**现有 class 组合**，不新增容器 class、不破「禁发明 class」。
> **驱动**：主 agent 在 outline 标 `[composite: cards+flow]` 等（见 `annotation-spec.md` §三），4.2 路由表 `骨架源` 指向本段对应形态。
> **视觉等级**：L2（单组件 L1，组合跨区域需更强视觉层级）。
> **不叠加**：一页一个 composite，不三类混用（容量爆炸 + 视觉混乱）。

### 形态 1 — cards+flow（上半卡片网格 + 下半流程管道）

**容量**：3 卡片（`.grid.g3` 固定）+ 3-5 flow 节点。复用 L07（`.grid.g3`）+ L17（`.flow`）。
**适用**：先列要素再展示要素间流转（如「三大监控能力 → 告警闭环流程」）。

```html
<div class="page-body">
  <!-- 上半：能力卡矩阵 -->
  <div class="grid g3">
    <div class="card"><h4>[CARD_1_TITLE]</h4><p class="dim">[CARD_1_DESC]</p></div>
    <div class="card"><h4>[CARD_2_TITLE]</h4><p class="dim">[CARD_2_DESC]</p></div>
    <div class="card"><h4>[CARD_3_TITLE]</h4><p class="dim">[CARD_3_DESC]</p></div>
  </div>
  <!-- 下半：闭环流程（L17 flow，mt-l 分隔两区域） -->
  <div class="flow mt-l">
    <div class="node">[NODE_1]</div><div class="arr">→</div>
    <div class="node">[NODE_2]</div><div class="arr">→</div>
    <div class="node">[NODE_3]</div><div class="arr">→</div>
    <div class="node">[NODE_4]</div>
  </div>
</div>
```

### 形态 2 — list+flow（左栏要点列表 + 右栏流程图）

**容量**：左 3-5 `.point` + 右 3-5 `.node`。复用 L06（`.point`）+ L17（`.flow`，垂直变体 `flex-direction:column`）。
**适用**：要点清单 + 对应执行流程并排（如「五项原则 → 落地流程」）。

```html
<div class="page-body">
  <div class="grid g2" style="align-items:start;">
    <!-- 左栏：要点列表 -->
    <div class="point-list">
      <div class="point"><div class="num">01</div><div><div class="title">[POINT_1_TITLE]</div><div class="desc">[POINT_1_DESC]</div></div></div>
      <!-- 2-5 个 .point -->
    </div>
    <!-- 右栏：垂直流程 -->
    <div class="flow" style="flex-direction:column;gap:16px;">
      <div class="node">[NODE_1]</div>
      <div class="node">[NODE_2]</div>
      <div class="node">[NODE_3]</div>
    </div>
  </div>
</div>
```

### 形态 3 — kpi+table（顶部 KPI 条 + 底部明细表）

**容量**：4 KPI（`.grid.g4`）+ 表 4-6 行。复用 L11（`.kpi`）+ L32（`.info-bar`）/ L12（`.table` / `.cs-table`）。
**适用**：核心指标 + 支撑明细（如「4 个北极指标 + 各业务线明细表」）。

```html
<div class="page-body">
  <!-- 顶部：KPI 条 -->
  <div class="grid g4">
    <div class="kpi"><div class="kpi-value">[KPI_1_VALUE]</div><div class="kpi-label">[KPI_1_LABEL]</div></div>
    <div class="kpi"><div class="kpi-value">[KPI_2_VALUE]</div><div class="kpi-label">[KPI_2_LABEL]</div></div>
    <div class="kpi"><div class="kpi-value">[KPI_3_VALUE]</div><div class="kpi-label">[KPI_3_LABEL]</div></div>
    <div class="kpi"><div class="kpi-value">[KPI_4_VALUE]</div><div class="kpi-label">[KPI_4_LABEL]</div></div>
  </div>
  <!-- 底部：明细表（L12 .table 或 deck 专属 .cs-table），mt-l 分隔 -->
  <div class="cs-table mt-l">[TABLE_ROWS]</div>
</div>
```

> **区域间距**：两区域间用 `.mt-l`（margin-top 40px）或 deck overlay 约定的分区间距，不用额外容器 class。
> **复合骨架组合白名单**：见 `subagent-rules.md`「复合骨架组合白名单」——subagent 见 `[composite:]` 标注即按本段 3 形态组合，class 全部来自 tokens.css 已有，不发明新 class。

---

## 布局选择速查

| 内容类型 | 推荐布局 |
|---------|---------|
| 核心结论/数字 | L10 stat-highlight 或 L09 big-quote |
| 多个并列要点 | L06 bullets 或 L08 three-column |
| 数据对比 | L12 table、L13 chart-bar、L24 comparison |
| 流程/步骤 | L17 flow-diagram、L22 process-steps、L18 timeline |
| 系统架构 | L21 arch-diagram、L20 mindmap |
| 规划/排期 | L19 roadmap、L23 gantt |
| 产品截图 | L26 image-hero、L27 image-grid |
| 代码展示 | L28 code、L29 diff、L30 terminal |
| 优劣势分析 | L25 pros-cons |
| 检查清单 | L31 todo-checklist |
| 次级信息 | L32 secondary-info-bar |
| 仪表盘指标 | L11 kpi-grid |
| 多维对比 | L16 chart-radar |
| 占比分布 | L15 chart-pie |
| 趋势变化 | L14 chart-line |
| 要素+流转双展示 | composite-cards-flow（上半卡 + 下半流程） |
| 要点+流程并排 | composite-list-flow（左列表 + 右流程） |
| 指标+明细 | composite-kpi-table（顶 KPI + 底明细表） |
