# keynote-formal · 庄重主题演讲

10-slide formal keynote deck: cover（主题演讲式版心 · 主题+演讲人+大会名+日期）· belief-statement（信念宣言 / Why · 极大字+极简）· narrative-beat（挣扎 · 大字金句+留白+剪影意象）· pull-quote（情感高潮 · 居中超大字引言）· narrative-beat（转折 · 一扇打开的门）· image-hero（新的理解 · 章节式全幅金光）· narrative-beat（成长 · 年轮同心圆）· milestone（十年 · 一个数字叙事）· call-to-action（行动号召 · 号召+签名）· thanks（金句回响+大会署名）。

庄重单色调色板 — 近黑底 `#171717` + 庄重金 `#d4af37` 唯一强调（不堆多彩），极大字 serif（Noto Serif SC）叙事、大留白克制；装饰语言 = 金线 `.gold-rule`、章节序号 `.kf-mark`、叙事弧节点 `.arc-step`。庄重、有分量、叙事感染力。

**Use when:** 公司年度大会 CEO 主题演讲、全员大会 keynote、十周年/司庆叙事演讲、品牌信念发布、毕业典礼/开学典礼致辞。
**Feel:** 一场庄重的叙事演讲——黄金圈/英雄之旅的情感弧（信念 → 挣扎 → 转折 → 理解 → 号召），大字金句 + 留白 + 一张意象，每页一个故事节拍。

---

## 配色

默认 `炭黑金`（庄重金 #d4af37 / #e5c687，近黑底 #171717，权威有分量）—— 单色克制，金色是唯一强调，靠留白与节奏而非多彩堆砌。

已接入 `switch-theme.mjs`，可一键切换：

```bash
node scripts/switch-theme.mjs --deck templates/starter-decks/keynote-formal --scheme charcoal        # 默认：炭黑金（庄重金/黑）
node scripts/switch-theme.mjs --deck templates/starter-decks/keynote-formal --scheme midnight-ink      # 午夜墨蓝（单色叙事）
node scripts/switch-theme.mjs --deck templates/starter-decks/keynote-formal --scheme morandi-dusk      # 莫兰迪·暮蓝（克制庄重）
```

配套方案见 `scripts/color-schemes.json`（40 个预设）。建议切换后保留**单色克制**调性的 scheme（避免高饱和多彩，会破坏"庄重"质感）。

## 结构

10 页叙事弧 = **庄重主题演讲体裁（黄金圈/英雄之旅：信念 Why → 挣扎故事 → 转折点 → 新的理解 → 行动号召）**，非咨询 SCQA、非 dir-key 逐点递进：

| 段落 | 页 | 角色 |
|------|-----|------|
| 开篇·信念 | 01-02 | cover（主题演讲式版心）· **belief-statement（信念宣言 · 黄金圈 Why）** |
| 挣扎与高潮 | 03-04 | **narrative-beat（挣扎 · 山峰攀登者意象）** · **pull-quote（情感高潮大引语）** |
| 转折与理解 | 05-06 | **narrative-beat（转折 · 一扇门意象）** · image-hero（新的理解 · 章节式全幅金光，L26） |
| 成长与十年 | 07-08 | **narrative-beat（成长 · 年轮意象）** · milestone（十年 · 一个数字叙事 + 成长弧） |
| 号召与回响 | 09-10 | **call-to-action（行动号召 · 号召+签名）** · thanks（金句回响+大会署名） |

**叙事演讲身份证**（区别于 consultant/dir-key/presenter/product-launch 的标志版式）：信念宣言 `.belief-statement`（极大字+极简 Why）、叙事节拍 `.narrative-beat`（大字金句+留白+剪影 SVG）、情感高潮大引语 `.pull-quote`（居中超大字+巨型开引号）、行动号召 `.call-to-action`（号召+演讲式签名）；辅助金线 `.gold-rule`、章节序号 `.kf-mark`、叙事弧节点 `.arc-step`。详见 [`slide-roles.md`](slide-roles.md)。

完整角色目录与替换键见 [`slide-roles.md`](slide-roles.md)。

## 用法

复制本目录到产出目录后修改 `slides/*.html` 中的 `data-replace="key"` 内容。示例填充为「拓见科技 2026 年度大会 CEO 主题演讲：我们的十年」（典型庄重叙事演讲，有信念/挣扎/转折/理解/号召，映射全部 10 角色）。

```bash
# 预览
open index.html
# 截图所有页
node scripts/preview_slides.mjs --slides slides --out /tmp/preview
# 导出单文件 HTML
node scripts/export_single.mjs --deck . --out ../keynote-formal.html
# 导出 PPTX
node scripts/export_pptx.mjs --slides slides --out ../keynote-formal.pptx --mode editable
```

## 设计依据

按 `docs/horizontal-decks-build-prompts.md`（会话 4 · 庄重主题演讲）规格构建：从 `references/layout-catalog.md` 选 L03 section-divider / L05 cta / L09 big-quote / L26 image-hero 拼装，加 4 个该体裁独有标志组件（belief-statement / narrative-beat / pull-quote / call-to-action）。**反换皮**：不克隆 consultant-strategy 页面、不克隆 dir-key 逐点列表、不克隆 presenter 工具壳——叙事弧 + 庄重金线装饰语言是本 deck 的独立身份证。配色取 `scripts/color-schemes.json` 的 `炭黑金`（庄重金/黑）。详见 `docs/template-system-requirements.md` §3+§5、`docs/deck-differentiation-spec.md`。

⚠️ 节拍页的剪影意象（山峰/门/年轮）均为 **inline SVG**（金色描边+淡填，无外部图依赖），适配 PPTX 导出与无图兜底；如需真实摄影意象，替换 `.tpl-keynote-beat-figure svg` 为 `<img>`（遵守 editable-pptx 约束）。
