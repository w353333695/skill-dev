# weekly-report — Slide Role Catalog

> **模板气质**：严肃可扫描、左侧色条 KPI、分类标签(shipped/blockers/next)、信息密度高。Corporate-clarity：近白底 + 蓝→青 accent + amber 数据强调，细边框 + 几乎无阴影的扁平 `.wr-*` 容器，mono 标签（FEAT/FIX/EXP/INFRA）。
> **默认 color-scheme**：cerulean（蓝 #2e63eb / 青 #0ea5b5 / 琥珀 #f59e0b accent）
> **适用文稿类型**：信息同步（周报、月报、squad review、skip-level 更新）
> **叙事结构（14 页，按出现顺序）**：cover → agenda → kpis → wins → shipped → velocity → funnel → metrics → okr → blockers → decisions → next-week → team → thanks
>
> 叙事弧：**开篇**（01-02 封面 + 议程）→ **成果脉搏**（03-04 KPI 八宫格 + 高光插图）→ **本周活动**（05-07 发布 + 速度曲线 + 转化漏斗）→ **指标深潜**（08 柱状趋势）→ **健康/跟踪**（09 OKR 进度 + 10 阻塞）→ **向前看**（11 待决策 + 12 下周计划）→ **人与收束**（13 团队产能 + 14 致谢）。
> 其中 **02(agenda) / 04(wins · SVG 插图) / 06(velocity · SVG 折线) / 07(funnel · CSS 漏斗) / 09(okr · 进度条+SVG gauge) / 11(decisions) / 13(team)** 为本次扩充新增板式页。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 封面 | .cover-head(.logo+.week-chip), .kicker, .h1(accent 色高亮数字), .lede |
| 02 | `content-agenda` | 议程目录（双栏编号） | .grid.g2, .wr-agenda-item(.wr-num + .wr-at-title/.wr-at-desc/.wr-at-pill) |
| 03 | `content-kpis` | KPI 八宫格 | .kpi(.good/.bad/.warn), .label+.value+.delta |
| 04 | `content-wins` | 本周高光（SVG 插图 + 大数字） | .wr-hero-art(svg art-bar/art-line/art-arrow), .wr-win(.wr-w-value.accent/.good) |
| 05 | `content-shipped` | 本周发布列表 | .ship-item(.tag+.title+.desc+.owner) |
| 06 | `content-velocity` | Sprint 速度 SVG 折线 | .wr-chart(svg .grid/.axis/.line.ser-a/ser-b/.guide), .wr-panel.bar |
| 07 | `content-funnel` | 转化漏斗（CSS 渐窄） | .wr-funnel, .wr-stage(.wr-stage-label/.wr-stage-value/.wr-stage-conv) |
| 08 | `content-chart` | 趋势柱状图深潜 | .chart, .chart-bars, .col(.b+.lbl), .pill target |
| 09 | `content-okr` | OKR 进度（进度条 + SVG gauge） | .wr-panel.bar, .wr-progress/.wr-progress-fill(.good/.warn/.bad), .wr-dot, .wr-gauge(svg arc) |
| 10 | `content-blockers` | 阻塞项列表 | .blocker(红色左边框, h4+p+.meta) |
| 11 | `content-decisions` | 待决策请求 | .wr-decision(.wr-d-title/.wr-d-bg/.wr-d-meta + .wr-rec .wr-rec-tag/.wr-rec-opt/.wr-rec-due) |
| 12 | `content-next-week` | 下周计划 | .next-row(.owner+.task) |
| 13 | `content-team` | 团队 roster + 产能 | .wr-team-row(.wr-t-owner/.wr-t-role/.wr-t-focus), .wr-capacity(.wr-progress mini + .wr-cap-pct) |
| 14 | `thanks` | 感谢/结束 | .center.tc, 133px h1, .week-chip |

---

## 角色详情

### `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`team_name`, `week_label`, `report_type`, `headline`, `headline_accent`, `subtitle`, `footer_info`
- **不可改动**：.cover-head(.logo+.week-chip) 结构、.kicker 位置
- **内容适配规则**：
  - `headline` 含一个用 `<span style="color:var(--accent)">` 高亮的数字(key: `headline_accent`)
  - `week_label` 格式 `"W15 · 2026-04-07 → 2026-04-13"`

### `content-agenda`
- **源文件**：`slides/02-agenda.html`
- **可替换键**：`section_label`, `section_title`, `subtitle`, `footer_info`；6 组 `agenda_N_num/title/desc/meta`
- **不可改动**：`.grid.g2` 双栏、`.wr-agenda-item` 的 `grid-template-columns:96px 1fr`、`.wr-num` mono 蓝色编号
- **内容适配规则**：议程项 4~6 个（增删 `.wr-agenda-item`），`meta` 是 `slide NN` 跳转提示；标题 ≤ 14 字

### `content-kpis`
- **源文件**：`slides/03-kpis.html`
- **可替换键**：`section_label`, `section_title`, 8 组 `kpi_N_label`, `kpi_N_value`, `kpi_N_delta`
- **不可改动**：.grid.g4 四列、.kpi 左侧色条(.good=绿/.bad=红/.warn=琥珀)、.delta(.up=绿/.down=红/.flat=灰)
- **内容适配规则**：
  - KPI 数量 4~8，增删 `.kpi` 元素
  - `kpi_N_delta` 格式 `"▲/▼/— +N%"`，对应 class `.up`/`.down`/`.flat`
  - .kpi 的 status class(.good/.bad/.warn) 按指标健康度选择

### `content-wins`
- **源文件**：`slides/04-wins.html`
- **可替换键**：`section_label`, `section_title`, `art_caption`；3 组 `win_N_label/value/delta`
- **不可改动**：`.grid.g2` 左插图右大数字、`.wr-hero-art` 内联 SVG 的 `.art-bar`/`.art-line`/`.art-arrow` 结构（token 着色，PPTX 友好）
- **内容适配规则**：
  - 左侧 SVG 是"上升趋势插图"，改数据时调 `<rect>` 高度 + `<polyline>` 顶点坐标；颜色由 `.wr-hero-art .art-bar/.peak/.art-line/.art-arrow` 控制
  - 右侧 3 个 `.wr-win`，大数字用 `.wr-w-value.accent`(蓝) / `.good`(绿)；`.wr-win.good::before` 绿色左条
  - 只放结果，归因留给 08 指标深潜

### `content-shipped`
- **源文件**：`slides/05-shipped.html`
- **可替换键**：`section_label`, `section_title`, 6 组 `ship_N_tag`, `ship_N_title`, `ship_N_desc`, `ship_N_owner`
- **不可改动**：.ship-item 行结构、.tag(.feat=蓝/.fix=琥珀/.exp=紫/.infra=灰)
- **内容适配规则**：
  - 发布项数 3~8，增删 `.ship-item`
  - `ship_N_tag` 值：FEAT / FIX / EXP / INFRA，对应 class

### `content-velocity`
- **源文件**：`slides/06-velocity.html`
- **可替换键**：`section_label`, `section_title`, `legend_actual/legend_plan/legend_target`, `footer_info`；3 组 `vel_N_label/value`
- **不可改动**：`.wr-chart` 内联 SVG 的 `viewBox="0 0 900 380"`、绘图区 x∈[60,860] y∈[30,320]、`.line.ser-a`(实际实线)/`.ser-b`(计划虚线)/`.guide`(目标线) 的 class
- **内容适配规则**：
  - svg-inline = PPTX 导出友好（无 JS）
  - 改数据点：重算 polyline 坐标，公式 `y = 320 - (值/60)*290`；x 按 7 点均分 `60,193,327,460,593,727,860`
  - `.ser-b` 虚线（`stroke-dasharray:10 9`）表示计划，`.ser-a` 实线表示实际；目标线 `.guide` 用 amber 虚线 + `guide-label`
  - 右侧 3 个 `.wr-panel.bar` 小结（本轮/均值/对比），可改 `.bar`/`.bar.good`/`.bar.warn` 左条色

### `content-funnel`
- **源文件**：`slides/07-funnel.html`
- **可替换键**：`section_label`, `section_title`, `footer_info`；5 组 `funnel_N_label/value/conv`；`funnel_kpi_label/value/delta`, `funnel_drop_label/value/note`
- **不可改动**：`.wr-funnel` 的 5 个 `.wr-stage`（`:nth-child(N)` 控制渐窄宽度 100/84/68/52/36% 与配色）
- **内容适配规则**：
  - 漏斗级数 4~5；每级 `funnel_N_value` 是绝对数，`funnel_N_conv` 是相对首级的累计 %
  - 配色由 `:nth-child` 决定（1-2 蓝、3 青、4 amber、5 绿），改级数需同步调 nth-child 宽度序列
  - 右侧 `.wr-panel.bar.good`(端到端转化) + `.wr-panel.bar.bad`(最大流失点) 双指标块

### `content-chart`
- **源文件**：`slides/08-metrics.html`
- **可替换键**：`section_label`, `section_title`, `chart_title`, `chart_target`, 8 组 `bar_N_label`+`bar_N_height`, `chart_note`
- **不可改动**：.chart-bars 结构、.col(.b+.lbl)
- **内容适配规则**：
  - 柱数 6~12，`bar_N_height` 按比例计算（=值/最大值×100%，最小 5%）
  - `chart_target` 格式 `"target: X.X%"`

### `content-okr`
- **源文件**：`slides/09-okr.html`
- **可替换键**：`section_label`, `section_title`, `footer_info`；4 组 `okr_N_title/now/pct`；`gauge_value/label/note`
- **不可改动**：`.grid` 1.6fr/1fr 左进度右gauge、`.wr-progress`/`.wr-progress-fill` 结构、`.wr-gauge` SVG 半圆 arc（`viewBox="0 0 300 200"`，track 全弧 + fill 部分弧）
- **内容适配规则**：
  - 4 个 OKR 行，`.wr-panel.bar.good/.warn/.bad` 左条色 + `.wr-dot.good/.warn/.bad` 状态点 + `.wr-progress-fill.good/.warn/.bad` 同步
  - `okr_N_pct` 数字与 `.wr-progress-fill style="width:N%"` 必须一致
  - gauge fill 弧路径：`M 30 160 A 120 120 0 [0/1] 1 (终点)`，终点 `x=150+120cos(θ) y=160-120sin(θ)`，θ=180°×(1-达成率)；达成率>50% 时 large-arc-flag=1。`gauge_val` 文本居中
  - 延迟类 OKR（越小越好）：达成率 = 已压缩比例，非 当前/目标

### `content-blockers`
- **源文件**：`slides/10-blockers.html`
- **可替换键**：`section_label`, `section_title`, 3 组 `blocker_N_title`, `blocker_N_desc`, `blocker_N_meta`
- **不可改动**：.blocker 红色左边框、.meta 灰色小字
- **内容适配规则**：
  - 阻塞项数 1~4
  - 与 `content-decisions` 区分：blockers = 卡住的事（被动），decisions = 等人拍板（主动）

### `content-decisions`
- **源文件**：`slides/11-decisions.html`
- **可替换键**：`section_label`, `section_title`, `subtitle`, `footer_info`；3 组 `dec_N_title/bg/meta/rec_tag/rec_opt/due`
- **不可改动**：`.wr-decision` 的 amber 左边框 + `grid-template-columns:1fr auto`、`.wr-rec` 右栏结构（RECOMMENDED tag + 推荐选项 + due）
- **内容适配规则**：
  - 决策项数 2~4；每项 = 决策问题(`dec_N_title`) + 背景(`dec_N_bg`) + owner/类型/依赖(`dec_N_meta`) + 推荐项(`dec_N_rec_opt`) + 截止(`dec_N_due`)
  - 默认采纳 RECOMMENDED，否决在 due 前批注；`dec_N_due` 用 `.wr-rec-due` 红色强调

### `content-next-week`
- **源文件**：`slides/12-next-week.html`
- **可替换键**：`section_label`, `section_title`, 5 组 `next_N_owner`, `next_N_title`, `next_N_note`
- **不可改动**：.next-row 结构(.owner+.task)
- **内容适配规则**：
  - 计划项数 3~7

### `content-team`
- **源文件**：`slides/13-team.html`
- **可替换键**：`section_label`, `section_title`, `col_owner/col_role/col_focus/col_cap`, `footer_info`；5 组 `team_N_owner/role/focus/cap`；`team_sum_1/2/3`
- **不可改动**：`.wr-team-row` 的 `grid-template-columns:170px 150px 1fr 180px`、表头行 `border-bottom:2px solid var(--border-strong)`、`.wr-capacity` mini 进度条结构
- **内容适配规则**：
  - 成员行 4~7；`.wr-t-owner` mono 蓝色；`team_N_cap` 数字与 `.wr-progress-fill style="width:N%"` 一致
  - 产能 >100% 用 `.wr-progress-fill.bad`(红) 示警（如 @may 104%）；新成员 ramp 用偏低值
  - 底部 `.week-chip` 汇总行（在岗/on-call/超载提示）

### `thanks`
- **源文件**：`slides/14-thanks.html`
- **可替换键**：`closing_label`, `thanks_text`, `thanks_sub`, `info_1`, `info_2`
- **不可改动**：.center.tc 居中、h1 133px、.week-chip 样式

---

## 组件层（`shared/tokens.css` `.tpl-weekly-report` overlay）

### 原生组件族（weekly-report 既有）
| class | 作用 |
|------|------|
| `.cover-head` / `.logo` / `.week-chip` | 封面页头 + logo + 周次徽章 |
| `.kpi` / `.kpi.good/.warn/.bad` | KPI 卡（左侧色条，绿/琥珀/红） |
| `.kpi .delta.up/.down/.flat` | KPI 增减标签 |
| `.ship-item` / `.tag.feat/.fix/.exp/.infra` | 发布行 + 类型标签 |
| `.chart` / `.chart-bars` / `.col .b/.lbl` | 柱状趋势图 |
| `.blocker` | 阻塞项（红色左边框） |
| `.next-row` / `.owner` / `.task` | 下周计划行 |

### 扁平 `.wr-*` 容器族（本次扩充新增，corporate-clarity 气质）
| class | 作用 |
|------|------|
| `.wr-panel` / `.wr-panel.bar` / `.wr-panel.bar.good/.warn/.bad` | 扁平容器（细边框，可选 4.5px 左色条，无阴影） |
| `.wr-tile` | 扁平瓦片（同 panel，无左条） |
| `.wr-agenda-item` / `.wr-num` / `.wr-at-title/.wr-at-desc/.wr-at-pill` | 议程目录行（mono 编号 + 标题 + 说明 + slide 跳转 pill） |
| `.wr-win` / `.wr-win.good` / `.wr-w-label/.wr-w-value(.accent/.good)/.wr-w-delta` | 高光大数字块（复用 .kpi 的色条/delta 语言，数字更大） |
| `.wr-hero-art` / `.art-bar/.peak/.art-line/.art-arrow` | SVG 装饰插图容器（token 着色，PPTX 友好） |
| `.wr-chart` / `.grid/.axis/.line.ser-a/ser-b/.area/.dot.dot-a/dot-b/.guide/.guide-label` | 内联 SVG 图表着色类（折线/面积，参照 charts/line-chart.html） |
| `.wr-funnel` / `.wr-stage(.nth-child)` / `.wr-stage-label/.wr-stage-value/.wr-stage-conv` | 转化漏斗（CSS 渐窄，5 级配色由 nth-child 控制） |
| `.wr-progress` / `.wr-progress-fill(.good/.warn/.bad/.at)` | 进度条（fill 颜色按状态；`.at` 为蓝→青渐变） |
| `.wr-dot.good/.warn/.bad` | RAG 状态点 |
| `.wr-gauge` / `.arc-track/.arc-fill(.good)` / `.gauge-val/.gauge-label` | SVG 半圆 gauge（达成率单值） |
| `.wr-decision` / `.wr-d-head/.wr-d-title/.wr-d-bg/.wr-d-meta` / `.wr-rec/.wr-rec-tag/.wr-rec-opt/.wr-rec-due` | 待决策项（amber 左条 + 推荐项右栏） |
| `.wr-team-row` / `.wr-t-owner/.wr-t-role/.wr-t-focus` / `.wr-capacity/.wr-cap-pct` | 团队 roster 行 + 产能 mini 条 |

> 所有 `.wr-*` 颜色均 `var(--brand-*)` / `rgba(var(--brand-*-rgb),α)` 链路，跟随换肤。

---

## Style Transfer — T2 页面继承规则

### 空间密度对齐
- body padding: 对齐 `85px 130px`
- ship-item / blocker / next-row / wr-agenda-item / wr-decision / wr-team-row 间距保持一致

### 装饰模式继承
- 内容页顶部用 `.kicker`（大写标签，如 `HIGHLIGHTS · WPIs`）
- 不引入 .section-num 水印、.cover-bg 等非本模板装饰

### 组件类名统一
- KPI 指标：`.kpi` + status class(.good/.bad/.warn)
- 标签：`.tag.feat/.fix/.exp/.infra`
- 阻塞项：`.blocker`（红色左边框）
- 计划项：`.next-row`
- 扁平容器/数据块：`.wr-*` 族（见上表）

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| `.card` / `.card-accent` / `.card-amber` | weekly-report 用扁平 `.wr-panel`/`.wr-tile`（细边框无阴影）替代 consultant 的卡片系统；`.card`/`.card-accent` 是 consultant 重阴影卡，与本 deck 气质冲突 |
| `.section-num` 水印 | weekly-report 用 kicker 做章节标识 |
| `.terminal` | weekly-report 无代码展示 |
| `.gradient-text` | weekly-report 用 accent 色高亮数字，无渐变文字 |
| `box-shadow` 重阴影 | 扁平气质；`.wr-*` 容器均不投影 |

> 注：`.wr-panel`/`.wr-tile`/`.wr-win` 等 `.wr-*` 扁平容器是 weekly-report 原生组件（**允许**），区别于被禁的 consultant `.card*`。基础层 `.card` 在 overlay 内已被 `.tpl-weekly-report .card{background:var(--surface)}` 接管，但新页一律用 `.wr-panel`/`.wr-tile` 而非 `.card`。
