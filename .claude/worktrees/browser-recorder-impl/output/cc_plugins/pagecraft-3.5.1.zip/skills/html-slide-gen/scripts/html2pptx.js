/**
 * ============================================================================
 * html2pptx.js — Convert HTML slide to pptxgenjs slide with positioned elements
 *
 * V2 引擎核心流程：
 *   1. 注入系统字体 CSS（统一浏览器/PPTX 字体对齐）
 *   2. TreeWalker 遍历所有可见文本节点 → 可编辑文本框
 *   3. 纯色+边框 DIV → PPTX 原生形状
 *   4. 渐变/SVG/背景图/backdrop-filter → 截图背景保留
 *   5. ::before/::after 伪元素（有背景） → 原生形状
 *
 * USAGE:
 *   const pptx = new pptxgen();
 *   pptx.layout = 'LAYOUT_16x9';  // Must match HTML body dimensions
 *
 *   const { slide, placeholders } = await html2pptx('slide.html', pptx);
 *   slide.addChart(pptx.charts.LINE, data, placeholders[0]);
 *
 *   await pptx.writeFile('output.pptx');
 *
 * FEATURES:
 *   - Converts HTML to PowerPoint with accurate positioning
 *   - Supports text, images, shapes, and bullet lists
 *   - Extracts placeholder elements (class="placeholder") with positions
 *   - Handles CSS gradients, borders, and margins
 *
 * VALIDATION:
 *   - Uses body width/height from HTML for viewport sizing
 * ============================================================================
 */

const path = require('path');

const PT_PER_PX = 0.75;
const PX_PER_IN = 96;
const EMU_PER_IN = 914400;

// 懒加载：仅在独立调用 html2pptx() 时才需要 playwright 和 sharp
let _chromium, _sharp;
function getChromium() {
  if (!_chromium) _chromium = require('playwright').chromium;
  return _chromium;
}
function getSharp() {
  if (!_sharp) _sharp = require('sharp');
  return _sharp;
}

// Helper: Get body dimensions and check for overflow
async function getBodyDimensions(page) {
  const bodyDimensions = await page.evaluate(() => {
    const body = document.body;
    const style = window.getComputedStyle(body);

    return {
      width: parseFloat(style.width),
      height: parseFloat(style.height),
      scrollWidth: body.scrollWidth,
      scrollHeight: body.scrollHeight
    };
  });

  const errors = [];
  const widthOverflowPx = Math.max(0, bodyDimensions.scrollWidth - bodyDimensions.width - 1);
  const heightOverflowPx = Math.max(0, bodyDimensions.scrollHeight - bodyDimensions.height - 1);

  const widthOverflowPt = widthOverflowPx * PT_PER_PX;
  const heightOverflowPt = heightOverflowPx * PT_PER_PX;

  if (widthOverflowPt > 0 || heightOverflowPt > 0) {
    const directions = [];
    if (widthOverflowPt > 0) directions.push(`${widthOverflowPt.toFixed(1)}pt horizontally`);
    if (heightOverflowPt > 0) directions.push(`${heightOverflowPt.toFixed(1)}pt vertically`);
    const reminder = heightOverflowPt > 0 ? ' (Remember: leave 0.5" margin at bottom of slide)' : '';
    errors.push(`HTML content overflows body by ${directions.join(' and ')}${reminder}`);
  }

  return { ...bodyDimensions, errors };
}

// Helper: Validate dimensions match presentation layout
function validateDimensions(bodyDimensions, pres) {
  const errors = [];
  const widthInches = bodyDimensions.width / PX_PER_IN;
  const heightInches = bodyDimensions.height / PX_PER_IN;

  if (pres.presLayout) {
    const layoutWidth = pres.presLayout.width / EMU_PER_IN;
    const layoutHeight = pres.presLayout.height / EMU_PER_IN;

    if (Math.abs(layoutWidth - widthInches) > 0.1 || Math.abs(layoutHeight - heightInches) > 0.1) {
      errors.push(
        `HTML dimensions (${widthInches.toFixed(1)}" × ${heightInches.toFixed(1)}") ` +
        `don't match presentation layout (${layoutWidth.toFixed(1)}" × ${layoutHeight.toFixed(1)}")`
      );
    }
  }
  return errors;
}

function validateTextBoxPosition(slideData, bodyDimensions) {
  const errors = [];
  const slideHeightInches = bodyDimensions.height / PX_PER_IN;
  const minBottomMargin = 0.5; // 0.5 inches from bottom

  for (const el of slideData.elements) {
    // Check text elements (p, h1-h6, list)
    if (['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'list'].includes(el.type)) {
      const fontSize = el.style?.fontSize || 0;
      const bottomEdge = el.position.y + el.position.h;
      const distanceFromBottom = slideHeightInches - bottomEdge;

      if (fontSize > 12 && distanceFromBottom < minBottomMargin) {
        const getText = () => {
          if (typeof el.text === 'string') return el.text;
          if (Array.isArray(el.text)) return el.text.find(t => t.text)?.text || '';
          if (Array.isArray(el.items)) return el.items.find(item => item.text)?.text || '';
          return '';
        };
        const textPrefix = getText().substring(0, 50) + (getText().length > 50 ? '...' : '');

        errors.push(
          `Text box "${textPrefix}" ends too close to bottom edge ` +
          `(${distanceFromBottom.toFixed(2)}" from bottom, minimum ${minBottomMargin}" required)`
        );
      }
    }
  }

  return errors;
}

// Helper: Add background to slide
async function addBackground(slideData, targetSlide, tmpDir, screenshotPath) {
  if (screenshotPath) {
    targetSlide.background = { path: screenshotPath };
    return;
  }
  if (slideData.background.type === 'image' && slideData.background.path) {
    let imagePath = slideData.background.path.startsWith('file://')
      ? slideData.background.path.replace('file://', '')
      : slideData.background.path;
    targetSlide.background = { path: imagePath };
  } else if (slideData.background.type === 'color' && slideData.background.value) {
    targetSlide.background = { color: slideData.background.value };
  }
}

// Helper: Add elements to slide
function addElements(slideData, targetSlide, pres, screenshotPath, nativeShapes) {
  for (const el of slideData.elements) {
    // hybrid 模式：装饰元素已在截图中，只叠加可编辑文本
    if (screenshotPath && !nativeShapes && (el.type === 'shape' || el.type === 'image' || el.type === 'line')) {
      continue;
    }
    // nativeShapes 模式：简单形状和边框线已从截图中移除，作为原生元素添加；image 仍在截图中
    if (screenshotPath && nativeShapes && el.type === 'image') {
      continue;
    }

    if (el.type === 'image') {
      let imagePath = el.src.startsWith('file://') ? el.src.replace('file://', '') : el.src;
      targetSlide.addImage({
        path: imagePath,
        x: el.position.x,
        y: el.position.y,
        w: el.position.w,
        h: el.position.h
      });
    } else if (el.type === 'line') {
      targetSlide.addShape(pres.ShapeType.line, {
        x: el.x1,
        y: el.y1,
        w: el.x2 - el.x1,
        h: el.y2 - el.y1,
        line: { color: el.color, width: el.width }
      });
    } else if (el.type === 'shape') {
      // Decide ellipse vs roundRect:
      //   - Near-square (aspect 0.7..1.4) with large radius → real circle/ellipse
      //   - Wide pill (CSS uses an extreme radius like 9999px to force pill) → roundRect
      //     with radius clamped to half the short side. (Bug 3 fix.)
      const minDim = Math.min(el.position.w, el.position.h);
      const maxDim = Math.max(el.position.w, el.position.h);
      const aspect = maxDim / Math.max(minDim, 0.0001);
      const isNearSquare = aspect <= 1.4;
      const isEllipse = isNearSquare && el.shape.rectRadius >= minDim * 0.45;
      let rectRadius = el.shape.rectRadius;
      // Clamp oversized radius (e.g. CSS border-radius:9999px on a pill) so pptxgenjs
      // renders a clean roundRect instead of degenerating into an oval.
      if (!isEllipse && rectRadius > minDim / 2) rectRadius = minDim / 2;
      let shapeType = isEllipse ? pres.ShapeType.ellipse
        : rectRadius > 0 ? pres.ShapeType.roundRect
        : pres.ShapeType.rect;

      const shapeOptions = {
        x: el.position.x,
        y: el.position.y,
        w: el.position.w,
        h: el.position.h,
        shape: shapeType
      };

      if (el.shape.fill) {
        shapeOptions.fill = { color: el.shape.fill };
        if (el.shape.transparency != null) shapeOptions.fill.transparency = el.shape.transparency;
      }
      if (el.shape.line) shapeOptions.line = el.shape.line;
      if (!isEllipse && rectRadius > 0) shapeOptions.rectRadius = rectRadius;
      if (el.shape.shadow) shapeOptions.shadow = el.shape.shadow;

      if (el.text && el.text.trim()) {
        targetSlide.addText(el.text, shapeOptions);
      } else {
        targetSlide.addShape(shapeType, shapeOptions);
      }
    } else if (el.type === 'list') {
      const listOptions = {
        x: el.position.x,
        y: el.position.y,
        w: el.position.w,
        h: el.position.h,
        fontSize: el.style.fontSize,
        fontFace: el.style.fontFace,
        color: el.style.color,
        align: el.style.align,
        valign: 'top',
        lineSpacing: el.style.lineSpacing,
        paraSpaceBefore: el.style.paraSpaceBefore,
        paraSpaceAfter: el.style.paraSpaceAfter,
        margin: el.style.margin
      };
      if (el.style.margin) listOptions.margin = el.style.margin;
      targetSlide.addText(el.items, listOptions);
    } else {
      // Text element (p, h1-h6, or formatted text) — apply width buffer for hybrid mode
      let { x, y, w, h } = el.position;

      if (screenshotPath) {
        // Bug #8: detect CJK by actual text glyphs, not by fontFace name. System-font
        // injection often resolves mixed CJK+Latin headings to a Latin-first font stack
        // (e.g. "Arial"), so the old fontFace-string test missed them and applied the
        // smaller 8% Latin width buffer → long Chinese headings got clipped on the right.
        const textForCJK = typeof el.text === 'string'
          ? el.text
          : (Array.isArray(el.text) ? el.text.map(r => r?.text || '').join('') : '');
        const isCJK = /[一-鿿぀-ヿ가-힯]/.test(textForCJK) ||
          (el.style?.fontFace && /YaHei|SimHei|SimSun|微软雅黑|黑体|宋体|KaiTi|楷体|MS Gothic/.test(el.style.fontFace));

        // Minimum-width guard: a SPAN text box (chip / flex-item owner / inline label)
        // has its rect measured tight to the glyph run in the BROWSER font, but PPTX
        // renders with a different font (e.g. Consolas) whose advance widths differ —
        // so the box can be too narrow and the text wraps. Estimate the needed width
        // from font size × char count and grow the box if undersized. Keep the right
        // edge fixed for right-aligned boxes (e.g. @owner) so they stay anchored.
        //
        // SINGLE-LINE GATE (overflow fix): only grow boxes the browser itself rendered
        // on ONE line. Multi-line paragraphs (browser already wrapped them to 2+ lines)
        // MUST keep their measured rect width — otherwise this guard forces the entire
        // paragraph onto a single line wider than the card, and text overflows the card
        // boundary in PPTX. The browser rect width is the correct wrap width for
        // multi-line content; PPTX then wraps to the same number of lines.
        const fontSizePx = (el.style?.fontSize || 0) / PT_PER_PX;
        // SINGLE-LINE GATE: only apply the min-width grow to boxes the browser
        // rendered on ONE line. Compare box height (in) to one text line (pt).
        const lineHeightPt = el.style?.lineSpacing || (el.style?.fontSize || 0) * 1.2;
        const isSingleLine = h * 72 <= lineHeightPt * 1.5 + 1.5;
        if (fontSizePx > 0 && textForCJK && isSingleLine) {
          const cjkChars = (textForCJK.match(/[一-鿿぀-ヿ가-힯]/g) || []).length;
          const otherChars = textForCJK.length - cjkChars;
          // Latin/mono chars: ~0.66em average, but @ and uppercase are wider — use 0.72
          // plus a flat 0.06in floor so single-token boxes (e.g. "@raj") aren't clipped.
          const estimatedPx = cjkChars * fontSizePx * 1.05 + otherChars * fontSizePx * 0.72;
          const estimatedIn = estimatedPx / PX_PER_IN + 0.06;
          if (estimatedIn > w) {
            const grow = estimatedIn - w;
            const align = el.style?.align || 'left';
            if (align === 'center') x -= grow / 2;
            else if (align === 'right') x -= grow;
            w = estimatedIn;
          }
        }

        // WIDTH BUFFER: only for single-line boxes, and small. The old 15% CJK buffer
        // was meant to absorb browser-vs-PPTX font-metric drift on tight single-line
        // runs, but 15% routinely pushed card-contained titles/labels past the card's
        // right edge (card content ~5.3in, +15% → 6.1in > card 6.06in → overflow). The
        // min-width grow guard above already handles genuinely-too-narrow boxes; this
        // buffer is now a slim 3% safety for right-edge clipping only. Multi-line
        // paragraphs get NO buffer (they wrap inside their measured width).
        const widthBuffer = isSingleLine ? w * 0.03 : 0;
        const align = el.style?.align || 'left';
        if (widthBuffer > 0) {
          if (align === 'center') {
            x -= widthBuffer / 2;
            w += widthBuffer;
          } else if (align === 'right') {
            x -= widthBuffer;
            w += widthBuffer;
          } else {
            w += widthBuffer;
          }
        }
        // HEIGHT FLOOR (overflow fix): the box height comes from the browser rect, but
        // PPTX renders with a different font whose advance widths differ, so the same
        // text may wrap to MORE lines than the browser did — the extra lines then spill
        // past the rect (and past the card boundary, since addText doesn't clip). Estimate
        // the PPTX line count from char count × box width (using the SAME per-glyph factors
        // as the width guard) and grow h to fit. This only ADDS height downward (never
        // shrinks), so single-line boxes are unaffected; it just guarantees multi-line
        // paragraphs have room for however PPTX wraps them.
        const fsPt = el.style?.fontSize || 0;
        if (fsPt > 0 && textForCJK) {
          const cjkN = (textForCJK.match(/[一-鿿぀-ヿ가-힯]/g) || []).length;
          const otherN = textForCJK.length - cjkN;
          // HEIGHT FLOOR: PPTX renders with a different font whose advance widths differ
          // from the browser, so the same text may wrap to MORE lines in PPTX. Use TWO
          // signals and take the max:
          //   (a) browserLineCount — the rect height ÷ line height. The browser already
          //       wrapped the text correctly in its font, so this is the true layout-intent
          //       line count. PPTX almost never wraps to FEWER lines than this.
          //   (b) charEstimate — pessimistic advance (CJK 1.2em + Latin 0.72em) ÷ box width.
          //       catches cases where PPTX's wider font adds a line beyond the browser.
          const lineSpacingPt = el.style?.lineSpacing || fsPt * 1.2;
          const browserLineCount = Math.max(1, Math.round((h * 72) / lineSpacingPt));
          const textWidthPt = cjkN * fsPt * 1.2 + otherN * fsPt * 0.72;
          const boxWidthPt = w * 72;                          // already buffered, in inches
          const charEstimate = boxWidthPt > 0
            ? Math.max(1, Math.ceil(textWidthPt / boxWidthPt))
            : 1;
          // +1 slack line: PowerPoint's CJK inter-character spacing and font-fallback
          // differences commonly add one line vs the browser. The cost of the slack is
          // small (one extra empty line height, ~0.2in), but it prevents text from
          // overflowing the card boundary.
          const estLines = Math.max(browserLineCount, charEstimate);
          const neededH = (estLines + 0.5) * lineSpacingPt / 72;   // inches, +0.5 line slack
          if (neededH > h) h = neededH;
        }
        h += h * 0.05;
      } else {
        // Non-hybrid: single-line text 2% wider
        const lineHeight = el.style.lineSpacing || el.style.fontSize * 1.2;
        const isSingleLine = el.position.h <= lineHeight * 1.5;
        if (isSingleLine) {
          const widthIncrease = w * 0.02;
          const align = el.style?.align || 'left';
          if (align === 'center') {
            x -= widthIncrease / 2;
            w += widthIncrease;
          } else if (align === 'right') {
            x -= widthIncrease;
            w += widthIncrease;
          } else {
            w += widthIncrease;
          }
        }
      }

      // Clamp text box to slide bounds — width buffer / centering can push the
      // right edge past the slide width (e.g. a near-full-width quote whose box
      // gets +8% buffer), causing text to overflow the visible canvas. Shrink w
      // rather than move x so left-aligned text keeps its left edge. (Quote-overflow fix.)
      if (pres.presLayout) {
        const slideW = pres.presLayout.width / EMU_PER_IN;
        const slideH = pres.presLayout.height / EMU_PER_IN;
        if (x < 0) { w += x; x = 0; }
        if (y < 0) { h += y; y = 0; }
        if (x + w > slideW) w = Math.max(0.1, slideW - x);
        if (y + h > slideH) h = Math.max(0.1, slideH - y);
      }

      const textOptions = {
        x, y, w, h,
        fontSize: el.style.fontSize,
        fontFace: el.style.fontFace,
        color: el.style.color,
        bold: el.style.bold,
        italic: el.style.italic,
        underline: el.style.underline,
        valign: 'top',
        lineSpacing: el.style.lineSpacing,
        paraSpaceBefore: el.style.paraSpaceBefore,
        paraSpaceAfter: el.style.paraSpaceAfter,
        inset: 0  // Remove default PowerPoint internal padding
      };

      if (el.style.align) textOptions.align = el.style.align;
      if (el.style.margin) textOptions.margin = el.style.margin;
      if (el.style.rotate !== undefined) textOptions.rotate = el.style.rotate;
      if (el.style.transparency !== null && el.style.transparency !== undefined) textOptions.transparency = el.style.transparency;
      // Bug #9: apply text-shadow neon glow
      if (el.style.glow) textOptions.glow = el.style.glow;

      targetSlide.addText(el.text, textOptions);
    }
  }
}

// ── Font Unification ──────────────────────────────────────────────────────────
// Inject system font CSS so browser renders with fonts that PPTX will actually use.
// This ensures text box positions match the screenshot background.

function getSystemFontCSS() {
  const isMac = process.platform === 'darwin';
  // Platform-optimal system font mapping: browser renders with these → PPTX uses same fonts
  const SANS = isMac
    ? "'SF Pro Display', 'Helvetica Neue', Arial, sans-serif"
    : "'Segoe UI', Arial, sans-serif";
  const SANS_CN = isMac
    ? "'PingFang SC', 'STHeiti', 'Microsoft YaHei', sans-serif"
    : "'Microsoft YaHei', 'SimHei', sans-serif";
  const SERIF = isMac
    ? "'Georgia', 'Times New Roman', serif"
    : "'Georgia', 'Times New Roman', serif";
  const MONO = isMac
    ? "'SF Mono', 'Menlo', 'Consolas', monospace"
    : "'Consolas', 'Courier New', monospace";

  return `
/* [UWIN] System font unification for PPTX alignment */
* {
  font-family: ${SANS} !important;
}
[lang="zh-CN"], [lang="zh"], :lang(zh), :lang(zh-CN),
body, html, p, h1, h2, h3, h4, h5, h6, li, div, span, a, td, th {
  font-family: ${SANS}, ${SANS_CN} !important;
}
code, pre, kbd, samp, .mono, [class*="mono"], [class*="code"], [data-uwin-mono] {
  font-family: ${MONO} !important;
}
.serif, [class*="serif"], blockquote {
  font-family: ${SERIF}, ${SANS_CN} !important;
}
  `.trim();
}

async function injectSystemFonts(page) {
  // Before forcing SANS on everything, tag elements whose OWN font-family (from the
  // deck's tokens.css, before our !important override) is a monospace stack. The CSS
  // `[data-uwin-mono]` rule above then keeps them in MONO so PPTX (which mapResolvedFont
  // maps to Consolas) matches the browser's monospace metric — otherwise a mono title
  // like .hc-h1 renders as Arial in PPTX while the browser measured glyph widths in a
  // mono font, misaligning trailing decorations (e.g. the blinking .hc-cursor bar).
  await page.evaluate(() => {
    const monoRe = /mono|consol|menlo|courier|cascadia|jetbrains|sf mono/i;
    document.querySelectorAll('*').forEach(el => {
      const ff = window.getComputedStyle(el).fontFamily;
      if (monoRe.test(ff)) el.setAttribute('data-uwin-mono', '');
    });
  });
  await page.addStyleTag({ content: getSystemFontCSS() });
}

// Helper: Extract slide data from HTML page
// V2: TreeWalker-based universal text extraction — covers ALL visible text regardless of HTML tag
async function extractSlideData(page) {
  return await page.evaluate(() => {
    const PT_PER_PX = 0.75;
    const PX_PER_IN = 96;

    // Fonts that are single-weight and should not have bold applied
    const SINGLE_WEIGHT_FONTS = ['impact'];

    const shouldSkipBold = (fontFamily) => {
      if (!fontFamily) return false;
      const normalizedFont = fontFamily.toLowerCase().replace(/['"]/g, '').split(',')[0].trim();
      return SINGLE_WEIGHT_FONTS.includes(normalizedFont);
    };

    const pxToInch = (px) => px / PX_PER_IN;
    const pxToPoints = (pxStr) => parseFloat(pxStr) * PT_PER_PX;
    const rgbToHex = (rgbStr) => {
      if (rgbStr === 'rgba(0, 0, 0, 0)' || rgbStr === 'transparent') return 'FFFFFF';
      const match = rgbStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      if (!match) return 'FFFFFF';
      return match.slice(1).map(n => parseInt(n).toString(16).padStart(2, '0')).join('');
    };

    const extractAlpha = (rgbStr) => {
      const match = rgbStr.match(/rgba\((\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\)/);
      if (!match || !match[4]) return null;
      return Math.round((1 - parseFloat(match[4])) * 100);
    };

    const applyTextTransform = (text, textTransform) => {
      if (textTransform === 'uppercase') return text.toUpperCase();
      if (textTransform === 'lowercase') return text.toLowerCase();
      if (textTransform === 'capitalize') return text.replace(/\b\w/g, c => c.toUpperCase());
      return text;
    };

    const resolveTextColor = (el) => {
      const computed = window.getComputedStyle(el);
      const isTransparent = (c) => c === 'transparent' || c === 'rgba(0, 0, 0, 0)' ||
        (c.startsWith('rgba') && extractAlpha(c) === 100);
      const textFill = computed.webkitTextFillColor;
      if (textFill && !isTransparent(textFill)) return textFill;
      let current = el;
      while (current && current !== document.body) {
        const curStyle = window.getComputedStyle(current);
        const bgClip = curStyle.webkitBackgroundClip || curStyle.backgroundClip;
        if (bgClip === 'text') {
          const bgImg = curStyle.backgroundImage;
          if (bgImg && bgImg !== 'none' && bgImg.includes('gradient')) {
            // Bug #4 (revised): gradient text can't be reproduced natively, so degrade
            // to a solid color. Pick the MIDDLE color stop (more representative of the
            // gradient's overall hue than the first stop — e.g. a pink→yellow→green→blue
            // rainbow resolves to a greenish midtone instead of pink).
            const stops = bgImg.match(/(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\))/g);
            if (stops && stops.length) return stops[Math.floor(stops.length / 2)];
          }
          const bgColor = curStyle.backgroundColor;
          if (bgColor && !isTransparent(bgColor)) return bgColor;
          break;
        }
        current = current.parentElement;
      }
      if (!isTransparent(computed.color)) return computed.color;
      let ancestor = el.parentElement;
      while (ancestor) {
        const ancColor = window.getComputedStyle(ancestor).color;
        if (!isTransparent(ancColor)) return ancColor;
        ancestor = ancestor.parentElement;
      }
      return computed.color;
    };

    // Map resolved font (after system font injection) to PPTX font name.
    // Since fonts are already unified to system fonts, just extract the
    // first clean font name from the font-family stack.
    const mapResolvedFont = (fontFamily) => {
      if (!fontFamily) return 'Arial';
      const fonts = fontFamily.split(',').map(f => f.trim().replace(/['"]/g, ''));
      const first = fonts[0];
      // Normalize common system font names
      const lower = first.toLowerCase();
      if (lower.includes('sf pro') || lower.includes('helvetica') || lower.includes('arial') || lower === 'sans-serif') return 'Arial';
      if (lower.includes('segoe')) return 'Segoe UI';
      if (lower.includes('pingfang') || lower.includes('microsoft yahei') || lower.includes('stheiti') || lower.includes('simhei')) return 'Microsoft YaHei';
      if (lower.includes('georgia') || lower.includes('times')) return 'Times New Roman';
      if (lower.includes('sf mono') || lower.includes('menlo') || lower.includes('consolas') || lower.includes('courier')) return 'Consolas';
      return first.charAt(0).toUpperCase() + first.slice(1);
    };

    // Extract rotation angle from CSS transform and writing-mode
    const getRotation = (transform, writingMode) => {
      let angle = 0;
      if (writingMode === 'vertical-rl') angle = 90;
      else if (writingMode === 'vertical-lr') angle = 270;
      if (transform && transform !== 'none') {
        const rotateMatch = transform.match(/rotate\((-?\d+(?:\.\d+)?)deg\)/);
        if (rotateMatch) { angle += parseFloat(rotateMatch[1]); }
        else {
          const matrixMatch = transform.match(/matrix\(([^)]+)\)/);
          if (matrixMatch) {
            const values = matrixMatch[1].split(',').map(parseFloat);
            angle += Math.round(Math.atan2(values[1], values[0]) * (180 / Math.PI));
          }
        }
      }
      angle = angle % 360;
      if (angle < 0) angle += 360;
      return angle === 0 ? null : angle;
    };

    const getPositionAndSize = (el, rect, rotation) => {
      if (rotation === null) return { x: rect.left, y: rect.top, w: rect.width, h: rect.height };
      const isVertical = rotation === 90 || rotation === 270;
      if (isVertical) {
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        return { x: centerX - rect.height / 2, y: centerY - rect.width / 2, w: rect.height, h: rect.width };
      }
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      return { x: centerX - el.offsetWidth / 2, y: centerY - el.offsetHeight / 2, w: el.offsetWidth, h: el.offsetHeight };
    };

    const parseBoxShadow = (boxShadow) => {
      if (!boxShadow || boxShadow === 'none') return null;
      const shadowParts = boxShadow.split(/\)\s*,/);
      let firstShadow = shadowParts[0].trim();
      if (!firstShadow.endsWith(')') && (firstShadow.includes('rgba') || firstShadow.includes('rgb('))) firstShadow += ')';
      if (firstShadow.includes('inset')) return null;
      const colorMatch = firstShadow.match(/rgba?\([^)]+\)|#[0-9a-fA-F]{3,8}/);
      const parts = firstShadow.match(/([-\d.]+)(px|pt)/g);
      if (!parts || parts.length < 2) return null;
      const offsetX = parseFloat(parts[0]), offsetY = parseFloat(parts[1]);
      const blur = parts.length > 2 ? parseFloat(parts[2]) : 0;
      let angle = 0;
      if (offsetX !== 0 || offsetY !== 0) {
        angle = Math.atan2(offsetY, offsetX) * (180 / Math.PI);
        if (angle < 0) angle += 360;
      }
      const offset = Math.sqrt(offsetX * offsetX + offsetY * offsetY) * PT_PER_PX;
      let opacity = 0.5;
      if (colorMatch) {
        const rgbaStr = colorMatch[0];
        if (rgbaStr.startsWith('rgba')) {
          const alphaMatch = rgbaStr.match(/[\d.]+\)$/);
          if (alphaMatch) opacity = parseFloat(alphaMatch[0].replace(')', ''));
        }
      }
      return { type: 'outer', angle: Math.round(angle), blur: Math.max(blur * 0.75, 4), color: colorMatch ? rgbToHex(colorMatch[0]) : '000000', offset: Math.max(offset, 2), opacity: Math.max(opacity, 0.25) };
    };

    // Bug #9: parse CSS text-shadow into a pptxgenjs text `glow` effect. pptxgenjs
    // glow is a single {size, color, opacity} (no offset/direction), so we pick the
    // largest-blur shadow (the dominant halo) and ignore offset-only shadows. Neon
    // glow text (.hc-h1, .hc-big) uses stacked 0 0 Npx rgba(...) halos — these map
    // cleanly to glow. Returns null when there's no blur halo.
    const parseTextShadowGlow = (textShadow) => {
      if (!textShadow || textShadow === 'none') return null;
      const shadows = textShadow.split(/\)\s*,/).map(s => { s = s.trim(); if (!s.endsWith(')') && (s.includes('rgba') || s.includes('rgb('))) s += ')'; return s; });
      let best = null;
      for (const sh of shadows) {
        const colorMatch = sh.match(/rgba?\([^)]+\)|#[0-9a-fA-F]{3,8}/);
        const parts = sh.match(/([-\d.]+)(px|pt)/g);
        if (!parts || parts.length < 3) continue; // need offset-x offset-y blur
        const blur = parseFloat(parts[2]);
        if (blur <= 0) continue;
        let opacity = 0.5;
        if (colorMatch) {
          const rgbaStr = colorMatch[0];
          if (rgbaStr.startsWith('rgba')) {
            const alphaMatch = rgbaStr.match(/[\d.]+\)$/);
            if (alphaMatch) opacity = parseFloat(alphaMatch[0].replace(')', ''));
          }
        }
        if (!best || blur > best.size) {
          // pptxgenjs text glow spreads far more aggressively than a CSS text-shadow
          // halo at the same numeric size, so scale the blur down hard (÷3) and cap the
          // opacity low. This keeps a subtle accent without the "neon sign" blowout
          // users see on .gd-cmd / .hc-h1 command lines. (Bug #9 — tuned down.)
          best = { size: Math.max(2, Math.round(blur * PT_PER_PX / 3)), color: colorMatch ? rgbToHex(colorMatch[0]) : '000000', opacity: Math.min(0.28, Math.max(opacity * 0.4, 0.15)) };
        }
      }
      return best;
    };

    // Parse inline formatting tags into text runs
    const parseInlineFormatting = (element, baseOptions = {}, runs = [], baseTextTransform = (x) => x) => {
      // Bug #2: detect <pre> / white-space:pre* ancestry so newlines in code blocks
      // are preserved instead of collapsed by \s+ → ' '.
      const preservesNewlines = (() => {
        let n = element;
        while (n && n !== document.body) {
          if (n.tagName === 'PRE') return true;
          const ws = window.getComputedStyle(n).whiteSpace;
          if (ws === 'pre' || ws === 'pre-wrap' || ws === 'break-spaces') return true;
          n = n.parentElement;
        }
        return false;
      })();
      const collapseWs = (s) => preservesNewlines
        ? s.replace(/[ \t\f\v]+/g, ' ').replace(/ *\n */g, '\n')
        : s.replace(/\s+/g, ' ');
      let prevNodeIsText = false;
      element.childNodes.forEach((node) => {
        let textTransform = baseTextTransform;
        const isText = node.nodeType === Node.TEXT_NODE || node.tagName === 'BR';
        if (isText) {
          const text = node.tagName === 'BR' ? '\n' : textTransform(collapseWs(node.textContent));
          const prevRun = runs[runs.length - 1];
          if (prevNodeIsText && prevRun) { prevRun.text += text; }
          else { runs.push({ text, options: { ...baseOptions } }); }
        } else if (node.nodeType === Node.ELEMENT_NODE && node.textContent.trim()) {
          const computed = window.getComputedStyle(node);
          // Bug #4 (revised): gradient-text descendants are NO LONGER skipped — they
          // emit as native text runs with a solid color picked from the gradient
          // (resolveTextColor handles background-clip:text → middle gradient stop).
          // This keeps gradient text editable and present (no data loss).
          const options = { ...baseOptions };
          // Bug #6: handle ALL inline formatting elements, not just a partial whitelist.
          // Previously SUB/SUP/ABBR/CITE/DFN/KBD/Q/SAMP/TIME/VAR were silently dropped
          // (their textContent never emitted). Now any inline element with text is
          // recursed into with its computed style applied.
          const INLINE_FORMATTING_TAGS = new Set(['SPAN', 'B', 'STRONG', 'I', 'EM', 'U', 'A', 'CODE', 'SMALL', 'MARK', 'SUB', 'SUP', 'ABBR', 'CITE', 'DFN', 'KBD', 'Q', 'SAMP', 'TIME', 'VAR', 'DEL', 'INS', 'FONT', 'TT']);
          const isInlineFormatting = INLINE_FORMATTING_TAGS.has(node.tagName) ||
            (computed.display === 'inline' && node.tagName !== 'BR' && node.tagName !== 'IMG');
          if (isInlineFormatting) {
            const isBold = computed.fontWeight === 'bold' || parseInt(computed.fontWeight) >= 600;
            if (isBold && !shouldSkipBold(computed.fontFamily)) options.bold = true;
            if (computed.fontStyle === 'italic') options.italic = true;
            if (computed.textDecoration && computed.textDecoration.includes('underline')) options.underline = true;
            const textColor = resolveTextColor(node);
            if (textColor && textColor !== 'rgb(0, 0, 0)') {
              options.color = rgbToHex(textColor);
              const transparency = extractAlpha(textColor);
              if (transparency !== null) options.transparency = transparency;
            }
            if (computed.fontSize) options.fontSize = pxToPoints(computed.fontSize);
            if (computed.textTransform && computed.textTransform !== 'none') {
              textTransform = (text) => applyTextTransform(text, computed.textTransform);
            }
            parseInlineFormatting(node, options, runs, textTransform);
          }
        }
        prevNodeIsText = isText;
      });
      if (runs.length > 0) {
        // Bug #2: for <pre>/white-space:pre* blocks, keep leading indentation on
        // the first run and internal newlines; only trim outer whitespace.
        if (!preservesNewlines) {
          runs[0].text = runs[0].text.replace(/^\s+/, '');
          runs[runs.length - 1].text = runs[runs.length - 1].text.replace(/\s+$/, '');
          runs.forEach(r => { r.text = r.text.replace(/\n\s+/g, '\n'); });
        } else {
          runs[0].text = runs[0].text.replace(/^\n+/, '');
          runs[runs.length - 1].text = runs[runs.length - 1].text.replace(/\n+$/, '');
        }
      }
      return runs.filter(r => r.text.length > 0);
    };

    // Bug #1: parse CSS `content` value into visible text.
    // Handles: "literal" | 'literal' | attr(name) | "lit " attr(name) | url(...) | counter(...)
    const parsePseudoContent = (contentValue, hostEl) => {
      if (!contentValue || contentValue === 'none' || contentValue === 'normal') return '';
      let result = '';
      const re = /("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|attr\(\s*[\w-]+\s*\)|url\([^)]*\)|counter\([^)]*\)|[^\s]+)/g;
      let m;
      while ((m = re.exec(contentValue)) !== null) {
        const atom = m[1];
        if (atom.startsWith('"') || atom.startsWith("'")) {
          result += atom.slice(1, -1).replace(/\\(.)/g, '$1');
        } else if (atom.startsWith('attr(')) {
          const nameMatch = atom.match(/attr\(\s*([\w-]+)\s*\)/);
          if (nameMatch) {
            const attrVal = hostEl.getAttribute(nameMatch[1]);
            if (attrVal != null) result += attrVal;
          }
        } else if (atom.startsWith('url(') || atom.startsWith('counter(')) {
          // skip — image or counter, no text equivalent
        } else {
          result += atom;
        }
      }
      return result;
    };

    // ── TreeWalker: find all visible text nodes ──────────────────────────────────
    const INLINE_TAGS = new Set(['B', 'I', 'U', 'EM', 'STRONG', 'A', 'CODE', 'SMALL', 'MARK', 'SUB', 'SUP', 'ABBR', 'CITE', 'DFN', 'KBD', 'Q', 'SAMP', 'TIME', 'VAR']);
    const TEXT_BLOCK_TAGS = new Set(['P', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'LI', 'TD', 'TH', 'FIGCAPTION', 'BLOCKQUOTE', 'PRE', 'DT', 'DD', 'LABEL', 'BUTTON', 'SUMMARY', 'LEGEND']);
    const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'TEMPLATE']);

    // Find the "text block" ancestor for a text node — the nearest ancestor
    // that defines a visual text container (not an inline formatting element)
    function findTextBlock(textNode) {
      let el = textNode.parentElement;
      while (el && el !== document.body) {
        const tag = el.tagName;
        if (SKIP_TAGS.has(tag)) return null;
        if (el.closest('aside.notes')) return null; // skip speaker notes
        if (INLINE_TAGS.has(tag)) {
          // Pure-emphasis inline tags (B/STRONG/I/EM/U/…) are inline RUNS, not standalone
          // boxes — they never carry their own layout and are always merged into the
          // parent text block, where parseInlineFormatting preserves their bold/italic/
          // color as text runs. Emitting them standalone (a) duplicates the text, since
          // the parent's textContent already includes it, and (b) drops the run styling.
          // The standalone-emit logic below is only for non-emphasis inline elements that
          // are genuine visual chips with their own offset. (POC subtitle "<b>通过</b>"
          // duplicate fix: the dot <span> sibling has margin-right, which previously made
          // the <b> emit standalone → a stray duplicate "通过" box.)
          const PURE_EMPHASIS = new Set(['B', 'STRONG', 'I', 'EM', 'U', 'A', 'CODE', 'SMALL', 'MARK', 'SUB', 'SUP', 'ABBR', 'CITE', 'DFN', 'KBD', 'Q', 'SAMP', 'TIME', 'VAR']);
          const parent = el.parentElement;
          if (!PURE_EMPHASIS.has(tag)) {
            // An inline element that carries its OWN horizontal margin is visually offset
            // from its siblings (e.g. a non-emphasis inline tag with margin-left). Emit it
            // as its own text block at its own rect so the gap survives. The parent won't
            // re-emit this text (it's attributed here), so no ghost.
            const ins = window.getComputedStyle(el);
            const selfHasMargin = parseFloat(ins.marginLeft) > 0 || parseFloat(ins.marginRight) > 0;
            if (selfHasMargin) return el;
            // Also emit as its own block when a SIBLING inline element has a margin —
            // a multi-segment inline row. Returning self uses this element's own tight
            // rect (text width only).
            if (parent) {
              let siblingHasMargin = false;
              for (const sib of parent.children) {
                if (sib === el) continue;
                const ss = window.getComputedStyle(sib);
                if (parseFloat(ss.marginLeft) > 0 || parseFloat(ss.marginRight) > 0) { siblingHasMargin = true; break; }
              }
              if (siblingHasMargin) return el;
            }
          }
          el = parent;
          continue;
        }
        // SPAN: if parent is a text block, SPAN is inline formatting → parent is the block.
        // Otherwise SPAN is standalone (brand, section-num) → itself is the text block.
        // EXCEPT: if the SPAN's parent (a DIV/SECTION/etc) also contains direct text
        // node siblings, the SPAN is inline within that DIV — defer to the parent so
        // its textContent is emitted once and parseInlineFormatting preserves the SPAN's
        // styling. Without this, both the parent DIV (full text) and the SPAN (its own
        // text) emit, causing a ghost overlap of the SPAN's content. (Bug 1 fix.)
        if (tag === 'SPAN') {
          // Bug (tag/pill alignment): a SPAN that is itself a visual chip —
          // display:inline-block/inline-flex WITH a background — is a standalone
          // "shape + label" unit (e.g. .hc-tag, .gd-tag, .tag, .pill, .owner chip).
          // Its shape is emitted by the SPAN-shape branch using the SPAN's own rect,
          // so its TEXT must also use the SPAN's own rect to stay aligned. Deferring
          // to the parent (the Bug-1 fallthrough below) would merge several chips'
          // text into one parent text block → text piled in a row, misaligned with
          // the individual chip shapes. So return the SPAN itself as the text block.
          const spanStyle = window.getComputedStyle(el);
          // A SPAN with its own horizontal margin is offset from siblings (e.g.
          // .task span { margin-left:12px }) — emit as its own block so the gap
          // survives instead of being jammed into the parent text flow.
          if (parseFloat(spanStyle.marginLeft) > 0 || parseFloat(spanStyle.marginRight) > 0) return el;
          const spanHasBg = spanStyle.backgroundColor && spanStyle.backgroundColor !== 'rgba(0, 0, 0, 0)';
          const spanIsChip = spanHasBg && (spanStyle.display === 'inline-block' || spanStyle.display === 'inline-flex' || spanStyle.display === 'flex' || spanStyle.display === 'block');
          if (spanIsChip) return el;
          // A SPAN that is a flex/grid item of its parent (positioned independently via
          // margin/flex order, e.g. .owner "@may" with margin-left:auto in a flex row)
          // must also be emitted as its own text block at its own rect — otherwise it
          // gets merged into the parent's text flow and lands at the wrong position.
          const parentStyle = el.parentElement ? window.getComputedStyle(el.parentElement) : null;
          if (parentStyle && (parentStyle.display === 'flex' || parentStyle.display === 'inline-flex' || parentStyle.display === 'grid' || parentStyle.display === 'inline-grid')) {
            return el;
          }

          const parent = el.parentElement;
          const parentTag = parent ? parent.tagName : '';
          if (TEXT_BLOCK_TAGS.has(parentTag) || parentTag === 'SPAN') {
            el = parent; continue;
          }
          if (parent) {
            // Defer to the parent if it contains ANY other text content besides this
            // SPAN — either a direct text-node sibling (e.g. "主机 Agent ... <span>")
            // OR another inline element sibling carrying text (e.g. <b>Title</b><span>note</span>).
            // In both cases the parent's textContent already includes the SPAN's text,
            // so emitting the SPAN as its own block would double it. (Bug 1 fix, extended.)
            let hasOtherText = false;
            for (const sib of parent.childNodes) {
              if (sib === el) continue;
              if (sib.nodeType === Node.TEXT_NODE && sib.textContent.trim()) { hasOtherText = true; break; }
              if (sib.nodeType === Node.ELEMENT_NODE && sib.textContent.trim()) { hasOtherText = true; break; }
            }
            if (hasOtherText) { el = parent; continue; }
          }
          return el;
        }
        if (TEXT_BLOCK_TAGS.has(tag)) return el;
        // DIV or other block — check if it's a shape container (has bg/border)
        if (tag === 'DIV' || tag === 'SECTION' || tag === 'ARTICLE' || tag === 'HEADER' || tag === 'FOOTER' || tag === 'MAIN' || tag === 'NAV' || tag === 'ASIDE' || tag === 'FORM') {
          // Check if any intermediate ancestor between here and textNode is a text block
          // If so, use the nearest text block instead
          let intermediate = textNode.parentElement;
          while (intermediate && intermediate !== el) {
            if (TEXT_BLOCK_TAGS.has(intermediate.tagName)) return intermediate;
            intermediate = intermediate.parentElement;
          }
          return el;
        }
        el = el.parentElement;
      }
      return el; // body or null
    }

    function isElementVisible(el) {
      if (!el) return false;
      const style = window.getComputedStyle(el);
      if (style.display === 'none' || style.visibility === 'hidden') return false;
      if (parseFloat(style.opacity) === 0) return false;
      if (style.fontSize === '0px') return false;
      if (el.closest('aside.notes')) return false;
      return true;
    }

    // Walk all text nodes and group them by text block
    const textBlockGroups = new Map(); // key: textBlock element → array of {textNode, rect}

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: function(node) {
          const text = node.textContent.trim();
          if (!text) return NodeFilter.FILTER_REJECT;
          // Bug #3: skip text inside SVG — <text> elements are handled by a
          // dedicated SVG-text pass (their findTextBlock would otherwise attribute
          // them to the outer HTML container at the wrong position).
          if (node.parentElement && node.parentElement.closest('svg')) return NodeFilter.FILTER_REJECT;
          const block = findTextBlock(node);
          if (!block || !isElementVisible(block)) return NodeFilter.FILTER_REJECT;
          // Skip text inside UL/OL — those are handled separately by list extraction
          if (block.tagName === 'LI' && block.parentElement && (block.parentElement.tagName === 'UL' || block.parentElement.tagName === 'OL')) {
            // Only reject if the UL/OL will be processed as a list (it has visible dimensions)
            const listEl = block.parentElement;
            const listRect = listEl.getBoundingClientRect();
            if (listRect.width > 0 && listRect.height > 0) return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    let textNode;
    while ((textNode = walker.nextNode())) {
      const block = findTextBlock(textNode);
      if (!block) continue;
      if (!textBlockGroups.has(block)) textBlockGroups.set(block, []);
      const range = document.createRange();
      range.selectNodeContents(textNode);
      const rects = range.getClientRects();
      textBlockGroups.get(block).push({ textNode, rects: Array.from(rects) });
    }

    // ── Background extraction ────────────────────────────────────────────────────
    const body = document.body;
    const bodyStyle = window.getComputedStyle(body);
    const bgImage = bodyStyle.backgroundImage;
    const bgColor = bodyStyle.backgroundColor;
    const errors = [];

    let background;
    if (bgImage && bgImage !== 'none') {
      const urlMatch = bgImage.match(/url\(["']?([^"')]+)["']?\)/);
      if (urlMatch) {
        background = { type: 'image', path: urlMatch[1] };
      } else {
        background = { type: 'color', value: rgbToHex(bgColor) };
      }
    } else {
      background = { type: 'color', value: rgbToHex(bgColor) };
    }

    // ── Element extraction ───────────────────────────────────────────────────────
    const elements = [];
    const placeholders = [];
    const processed = new Set();

    // Track which elements have been covered by text extraction
    const textCoveredElements = new Set(textBlockGroups.keys());

    document.querySelectorAll('*').forEach((el) => {
      if (processed.has(el)) return;
      if (el instanceof SVGElement || !el.getBoundingClientRect) return;
      const tag = el.tagName;

      // ── Placeholders ──
      if (el.className && typeof el.className === 'string' && el.className.includes('placeholder')) {
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
          errors.push(`Placeholder "${el.id || 'unnamed'}" has ${rect.width === 0 ? 'width: 0' : 'height: 0'}. Check the layout CSS.`);
        } else {
          placeholders.push({ id: el.id || `placeholder-${placeholders.length}`, x: pxToInch(rect.left), y: pxToInch(rect.top), w: pxToInch(rect.width), h: pxToInch(rect.height) });
        }
        processed.add(el);
        return;
      }

      // ── Images ──
      if (tag === 'IMG') {
        const rect = el.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          elements.push({ type: 'image', src: el.src, position: { x: pxToInch(rect.left), y: pxToInch(rect.top), w: pxToInch(rect.width), h: pxToInch(rect.height) } });
          processed.add(el);
        }
        return;
      }

      // ── SPAN shapes (pills, tags with bg + inline-block) ──
      if (tag === 'SPAN') {
        const computed = window.getComputedStyle(el);
        const hasBg = computed.backgroundColor && computed.backgroundColor !== 'rgba(0, 0, 0, 0)';
        const display = computed.display;
        if (hasBg && (display === 'inline-block' || display === 'block' || display === 'inline-flex' || display === 'flex')) {
          const rect = el.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0) {
            const fill = rgbToHex(computed.backgroundColor);
            const transparency = extractAlpha(computed.backgroundColor);
            const shadow = parseBoxShadow(computed.boxShadow);
            const hasBorder = parseFloat(computed.borderWidth) > 0;
            const rectRadius = (() => {
              const radius = computed.borderRadius, rv = parseFloat(radius);
              if (rv === 0) return 0;
              if (radius.includes('%')) return rv >= 50 ? 1 : (rv / 100) * pxToInch(Math.min(rect.width, rect.height));
              if (radius.includes('pt')) return rv / 72;
              return rv / PX_PER_IN;
            })();
            elements.push({
              type: 'shape', text: '', shapeClass: 'native',
              position: { x: pxToInch(rect.left), y: pxToInch(rect.top), w: pxToInch(rect.width), h: pxToInch(rect.height) },
              shape: { fill, transparency, line: hasBorder ? { color: rgbToHex(computed.borderColor), width: pxToPoints(computed.borderWidth) } : null, rectRadius, shadow, gradient: null }
            });
            processed.add(el);
          }
        }
        return;
      }

      // ── Shapes (DIVs/TDs with background/border) ──
      if (tag === 'DIV' || tag === 'SECTION' || tag === 'ARTICLE' || tag === 'HEADER' || tag === 'FOOTER' || tag === 'MAIN' || tag === 'NAV' || tag === 'ASIDE' || tag === 'TD' || tag === 'TH') {
        const computed = window.getComputedStyle(el);
        const hasBg = computed.backgroundColor && computed.backgroundColor !== 'rgba(0, 0, 0, 0)';
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return;

        // Shape background — check if gradient or complex
        const elBgImage = computed.backgroundImage;
        const hasGradient = elBgImage && elBgImage !== 'none' && (elBgImage.includes('linear-gradient') || elBgImage.includes('radial-gradient'));
        const hasBgImage = elBgImage && elBgImage !== 'none' && !hasGradient;
        const hasBackdropFilter = computed.backdropFilter && computed.backdropFilter !== 'none';

        // Border handling
        const borderTop = computed.borderTopWidth, borderRight = computed.borderRightWidth;
        const borderBottom = computed.borderBottomWidth, borderLeft = computed.borderLeftWidth;
        const borders = [borderTop, borderRight, borderBottom, borderLeft].map(b => parseFloat(b) || 0);
        const hasBorder = borders.some(b => b > 0);
        const hasUniformBorder = hasBorder && borders.every(b => b === borders[0]);
        const borderLines = [];

        if (hasBorder && !hasUniformBorder) {
          const x = pxToInch(rect.left), y = pxToInch(rect.top), w = pxToInch(rect.width), h = pxToInch(rect.height);
          if (parseFloat(borderTop) > 0) {
            const widthPt = pxToPoints(borderTop), inset = (widthPt / 72) / 2;
            borderLines.push({ type: 'line', x1: x, y1: y + inset, x2: x + w, y2: y + inset, width: widthPt, color: rgbToHex(computed.borderTopColor) });
          }
          if (parseFloat(borderRight) > 0) {
            const widthPt = pxToPoints(borderRight), inset = (widthPt / 72) / 2;
            borderLines.push({ type: 'line', x1: x + w - inset, y1: y, x2: x + w - inset, y2: y + h, width: widthPt, color: rgbToHex(computed.borderRightColor) });
          }
          if (parseFloat(borderBottom) > 0) {
            const widthPt = pxToPoints(borderBottom), inset = (widthPt / 72) / 2;
            borderLines.push({ type: 'line', x1: x, y1: y + h - inset, x2: x + w, y2: y + h - inset, width: widthPt, color: rgbToHex(computed.borderBottomColor) });
          }
          if (parseFloat(borderLeft) > 0) {
            const widthPt = pxToPoints(borderLeft), inset = (widthPt / 72) / 2;
            borderLines.push({ type: 'line', x1: x + inset, y1: y, x2: x + inset, y2: y + h, width: widthPt, color: rgbToHex(computed.borderLeftColor) });
          }
        }

        const isBodyCover = rect.width > document.documentElement.clientWidth * 0.95 && rect.height > document.documentElement.clientHeight * 0.95;

        if ((hasBg || hasBorder) && !isBodyCover) {
          const shadow = parseBoxShadow(computed.boxShadow);
          const fill = hasBg ? rgbToHex(computed.backgroundColor) : null;
          const transparency = hasBg ? extractAlpha(computed.backgroundColor) : null;

          let shapeClass = 'native';
          if (hasGradient || hasBgImage || hasBackdropFilter) {
            shapeClass = 'complex';
          }
          // Symmetric to the hide step: a plain-bg container that WRAPS complex
          // descendants (gradient bars, bg-image, backdrop-filter) must NOT be emitted
          // as a native solid-fill shape — that shape would paint over the screenshot
          // (which kept the container + its complex children visible) and hide them.
          // E.g. .chart (plain surface bg) wrapping gradient .chart-bars. Skip native
          // shape emission; the whole container stays as screenshot pixels.
          // (weekly bar-chart fix — extract side.)
          if (shapeClass === 'native' && hasBg) {
            let hasComplexDescendant = false;
            const desc = el.querySelectorAll('*');
            for (let k = 0; k < desc.length && k < 200; k++) {
              const ds = window.getComputedStyle(desc[k]);
              const dbg = ds.backgroundImage;
              if (dbg && dbg !== 'none' && (dbg.includes('gradient') || dbg.includes('url('))) { hasComplexDescendant = true; break; }
              if (ds.backdropFilter && ds.backdropFilter !== 'none') { hasComplexDescendant = true; break; }
            }
            if (hasComplexDescendant) {
              processed.add(el);
              return;
            }
          }

          if (hasBg || hasUniformBorder) {
            const rectRadius = (() => {
              const radius = computed.borderRadius, radiusValue = parseFloat(radius);
              if (radiusValue === 0) return 0;
              if (radius.includes('%')) {
                if (radiusValue >= 50) return 1;
                return (radiusValue / 100) * pxToInch(Math.min(rect.width, rect.height));
              }
              if (radius.includes('pt')) return radiusValue / 72;
              return radiusValue / PX_PER_IN;
            })();

            elements.push({
              type: 'shape',
              text: '',
              shapeClass: shapeClass,  // 'native' | 'gradient' | 'complex'
              position: { x: pxToInch(rect.left), y: pxToInch(rect.top), w: pxToInch(rect.width), h: pxToInch(rect.height) },
              shape: {
                fill, transparency,
                line: hasUniformBorder ? { color: rgbToHex(computed.borderColor), width: pxToPoints(computed.borderWidth) } : null,
                rectRadius, shadow,
                // Store gradient info for pre-rendering
                gradient: shapeClass === 'gradient' ? { css: elBgImage } : null,
              }
            });
          }
          elements.push(...borderLines);

          // ::before / ::after pseudo-elements as extra native shapes
          ['::before', '::after'].forEach(pseudo => {
            const pseudoStyle = window.getComputedStyle(el, pseudo);
            const content = pseudoStyle.content;
            if (!content || content === 'none') return;
            const pseudoBg = pseudoStyle.backgroundColor;
            const pseudoHasBg = pseudoBg && pseudoBg !== 'rgba(0, 0, 0, 0)';
            const pseudoW = parseFloat(pseudoStyle.width) || 0;
            const pseudoH = parseFloat(pseudoStyle.height) || 0;
            if (pseudoStyle.display === 'none') return;
            if (!pseudoHasBg && pseudoW === 0 && pseudoH === 0) return;
            let px = rect.left, py = rect.top, pw = pseudoW, ph = pseudoH;
            const pos = pseudoStyle.position;
            if (pos === 'absolute' || pos === 'fixed') {
              const left = pseudoStyle.left, top = pseudoStyle.top;
              const right = pseudoStyle.right, bottom = pseudoStyle.bottom;
              const inset = pseudoStyle.inset;
              if (inset && inset !== 'auto') {
                const parts = inset.split(' ').map(s => parseFloat(s) || 0);
                const iTop = parts[0], iRight = parts.length > 1 ? parts[1] : iTop;
                const iBottom = parts.length > 2 ? parts[2] : iTop;
                const iLeft = parts.length > 3 ? parts[3] : iRight;
                px = rect.left + iLeft; py = rect.top + iTop;
                pw = rect.width - iLeft - iRight; ph = rect.height - iTop - iBottom;
              } else {
                if (left !== 'auto') px = rect.left + parseFloat(left);
                else if (right !== 'auto') px = rect.right - pw - parseFloat(right);
                if (top !== 'auto') py = rect.top + parseFloat(top);
                else if (bottom !== 'auto') py = rect.bottom - ph - parseFloat(bottom);
              }
            }
            if (pw === 0 && (pos === 'absolute' || pos === 'fixed')) {
              pw = rect.width - (parseFloat(pseudoStyle.left) || 0) - (parseFloat(pseudoStyle.right) || 0);
            }
            if (ph === 0 && (pos === 'absolute' || pos === 'fixed')) {
              ph = rect.height - (parseFloat(pseudoStyle.top) || 0) - (parseFloat(pseudoStyle.bottom) || 0);
            }
            if (pw === 0) pw = rect.width;
            if (ph === 0) ph = rect.height;
            // Bug #7: if the pseudo has a non-rotate transform (skew/matrix), pptxgenjs
            // can't reproduce it — emitting an axis-aligned rect would mis-render (e.g.
            // the testing-safety diagonal strike-through would become a flat bar). Leave
            // such pseudos in the screenshot instead.
            const pseudoTransform = pseudoStyle.transform;
            const hasSkew = pseudoTransform && pseudoTransform !== 'none' &&
              (pseudoTransform.includes('skew') || pseudoTransform.includes('matrix'));
            if (hasSkew) return;
            if (pw > 0 && ph > 0) {
              const bRadius = pseudoStyle.borderRadius, bRadiusVal = parseFloat(bRadius);
              let pseudoRectRadius = 0;
              if (bRadiusVal > 0) {
                if (bRadius.includes('%')) pseudoRectRadius = (bRadiusVal / 100) * pxToInch(Math.min(pw, ph));
                else if (bRadius.includes('pt')) pseudoRectRadius = bRadiusVal / 72;
                else pseudoRectRadius = bRadiusVal / PX_PER_IN;
              }
              elements.push({
                type: 'shape', text: '', shapeClass: 'native',
                position: { x: pxToInch(px), y: pxToInch(py), w: pxToInch(pw), h: pxToInch(ph) },
                shape: { fill: pseudoHasBg ? rgbToHex(pseudoBg) : null, transparency: pseudoHasBg ? extractAlpha(pseudoBg) : null, line: null, rectRadius: pseudoRectRadius, shadow: parseBoxShadow(pseudoStyle.boxShadow), gradient: null }
              });
            }
          });

          processed.add(el);
          return;
        }
      }

      // ── List extraction (UL / OL) ──
      if (tag === 'UL' || tag === 'OL') {
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return;
        const liElements = Array.from(el.querySelectorAll('li'));
        const items = [];
        const ulComputed = window.getComputedStyle(el);
        const ulPaddingLeftPt = pxToPoints(ulComputed.paddingLeft);
        const marginLeft = ulPaddingLeftPt * 0.5;
        const textIndent = ulPaddingLeftPt * 0.5;

        liElements.forEach((li, idx) => {
          const isLast = idx === liElements.length - 1;
          const runs = parseInlineFormatting(li, { breakLine: false });
          if (runs.length > 0) {
            runs[0].text = runs[0].text.replace(/^[•\-\*▪▸]\s*/, '');
            runs[0].options.bullet = { indent: textIndent };
          }
          if (runs.length > 0 && !isLast) runs[runs.length - 1].options.breakLine = true;
          items.push(...runs);
        });

        const liStyle = window.getComputedStyle(liElements[0] || el);
        elements.push({
          type: 'list', items,
          position: { x: pxToInch(rect.left), y: pxToInch(rect.top), w: pxToInch(rect.width), h: pxToInch(rect.height) },
          style: {
            fontSize: pxToPoints(liStyle.fontSize),
            fontFace: mapResolvedFont(liStyle.fontFamily),
            color: rgbToHex(resolveTextColor(el)),
            transparency: extractAlpha(resolveTextColor(el)),
            align: liStyle.textAlign === 'start' ? 'left' : liStyle.textAlign,
            lineSpacing: liStyle.lineHeight && liStyle.lineHeight !== 'normal' ? pxToPoints(liStyle.lineHeight) : null,
            paraSpaceBefore: 0, paraSpaceAfter: pxToPoints(liStyle.marginBottom),
            margin: [marginLeft, 0, 0, 0]
          }
        });

        liElements.forEach(li => processed.add(li));
        processed.add(el);
        return;
      }
    });

    // ── Text extraction from TreeWalker groups ────────────────────────────────────
    for (const [blockEl, textNodeInfos] of textBlockGroups) {
      // Code blocks (<pre>) are kept as screenshot pixels only — their multi-line
      // monospace syntax-highlighted layout can't be faithfully reproduced as native
      // PPTX text runs (run-splitting + \n handling mangles the formatting). The
      // hide step leaves <pre> visible so the screenshot preserves it 100%. Skip
      // native text emission here to avoid a garbled overlay. (Code-page fix.)
      if (blockEl.tagName === 'PRE') continue;
      // A DIV with both background and text gets both — a native shape (visual box)
      // and an editable text element overlaid on top. The shape has text: '' so no duplication.
      // Prior behavior: if (processed.has(blockEl)) continue; — this silently dropped
      // text from any DIV that also had a background/border, killing tier labels,
      // Gantt labels, and any other styled container with text.
      if (processed.has(blockEl) && !(blockEl.tagName === 'DIV' || blockEl.tagName === 'TD' || blockEl.tagName === 'TH' || blockEl.tagName === 'SPAN')) continue;

      const rect = blockEl.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;

      // Bug #2: preserve newlines for <pre>/white-space:pre* blocks (code listings);
      // collapse only tabs/multi-spaces to single space, keep line breaks.
      const blockWs = window.getComputedStyle(blockEl).whiteSpace;
      const blockPreservesNewlines = blockEl.tagName === 'PRE' || blockWs === 'pre' || blockWs === 'pre-wrap' || blockWs === 'break-spaces';
      const text = blockPreservesNewlines
        ? blockEl.textContent.replace(/^\n+/, '').replace(/\n+$/, '').replace(/[ \t\f\v]+/g, ' ').replace(/ *\n */g, '\n')
        : blockEl.textContent.trim().replace(/\s+/g, ' ').replace(/^ | $/g, '');
      if (!text) continue;

      // Bug #4 (revised): gradient/rainbow text (background-clip:text + gradient bg)
      // cannot be reproduced as native PPTX text (pptxgenjs has no gradient text fill).
      // Instead of skipping native emission + relying on the screenshot (which broke
      // mixed blocks — gradient spans vanished when the parent was hidden, and rainbow
      // animations only captured one frame), we now degrade gradient text to a SOLID
      // color picked from the gradient's middle stop. The whole block emits as normal
      // native text — editable, no data loss, no screenshot-timing dependency.
      // Color resolution happens in resolveTextColor() / parseInlineFormatting().

      // Validate: Check for manual bullet symbols (only for p/h* tags, not div/span containers)
      const blockTag = blockEl.tagName;
      const isTextSemantic = TEXT_BLOCK_TAGS.has(blockTag) && blockTag !== 'TD' && blockTag !== 'TH';
      // Validate: warn (do NOT drop) when a non-list element starts with a bullet-like
      // symbol. Authors should use <ul>/<ol>, but silently dropping the entire
      // element's text causes worse damage than a noisy slide. ▸ removed from the
      // set — it is a directional/step indicator (▸ NEXT STEP), not a bullet.
      // (Bug 2 fix.)
      if (isTextSemantic && blockTag !== 'LI' && /^[•\-\*▪○●◆◇■□]\s/.test(text.trimStart())) {
        errors.push(`Text element <${blockTag.toLowerCase()}> starts with bullet symbol. Use <ul> or <ol> lists instead.`);
        // fall through — keep the text rather than dropping it
      }

      const computed = window.getComputedStyle(blockEl);
      const rotation = getRotation(computed.transform, computed.writingMode);
      const { x, y, w, h } = getPositionAndSize(blockEl, rect, rotation);

      const baseStyle = {
        fontSize: pxToPoints(computed.fontSize),
        fontFace: mapResolvedFont(computed.fontFamily),
        color: rgbToHex(resolveTextColor(blockEl)),
        align: (() => {
          if (computed.textAlign !== 'start') return computed.textAlign;
          // Check parent alignment — flex justify-content:center doesn't propagate
          // to children's textAlign, so we must inspect both text-align and flex properties.
          const parentStyle = window.getComputedStyle(blockEl.parentElement);
          if (parentStyle.textAlign === 'center' || parentStyle.textAlign === 'right') return parentStyle.textAlign;
          // Also check the block's own flex alignment — justify-content:center means
          // content is visually centered even if text-align is still 'start'
          if (computed.display === 'flex' || computed.display.includes('flex')) {
            if (computed.justifyContent === 'center') return 'center';
            if (computed.justifyContent === 'flex-end' || computed.justifyContent === 'end') return 'right';
          }
          return 'left';
        })(),
        lineSpacing: pxToPoints(computed.lineHeight),
        paraSpaceBefore: pxToPoints(computed.marginTop),
        paraSpaceAfter: pxToPoints(computed.marginBottom),
        margin: [pxToPoints(computed.paddingLeft), pxToPoints(computed.paddingRight), pxToPoints(computed.paddingBottom), pxToPoints(computed.paddingTop)]
      };

      const transparency = extractAlpha(resolveTextColor(blockEl));
      if (transparency !== null) baseStyle.transparency = transparency;
      if (rotation !== null) baseStyle.rotate = rotation;
      // Bug #9: capture text-shadow neon glow as pptxgenjs text glow.
      const textGlow = parseTextShadowGlow(computed.textShadow);
      if (textGlow) baseStyle.glow = textGlow;

      // Bug #1 (mixed host): build ::before/::after pseudo-text runs so that
      // prefixes like `$ ` (hermes prompt) or suffixes get prepended/appended to
      // the block's native text in the pseudo's own color. Only for static
      // (inline-flow) pseudos — absolute/fixed pseudos are decorative overlays
      // handled by the pseudo-shape pass. Skipped when host has NO direct text
      // (those hosts are handled by the dedicated pseudo-text pass at the end).
      const buildPseudoRuns = (hostHasText) => {
        if (!hostHasText) return { before: null, after: null };
        const makeRun = (slot) => {
          const ps = window.getComputedStyle(blockEl, slot);
          if (ps.display === 'none' || ps.visibility === 'hidden') return null;
          if (ps.position === 'absolute' || ps.position === 'fixed') return null;
          const t = parsePseudoContent(ps.content, blockEl);
          if (!t) return null;
          const tFinal = applyTextTransform(t, ps.textTransform);
          const color = resolveTextColor(blockEl); // pseudo inherits color unless ::before sets its own
          const pseudoColor = ps.color && ps.color !== 'rgba(0, 0, 0, 0)' ? ps.color : color;
          const isBold = ps.fontWeight === 'bold' || parseInt(ps.fontWeight) >= 600;
          const opts = {
            color: rgbToHex(pseudoColor),
            fontSize: pxToPoints(ps.fontSize),
            fontFace: mapResolvedFont(ps.fontFamily),
            bold: isBold && !shouldSkipBold(ps.fontFamily),
            italic: ps.fontStyle === 'italic'
          };
          const aTransparency = extractAlpha(pseudoColor);
          if (aTransparency !== null) opts.transparency = aTransparency;
          return { text: tFinal, options: opts };
        };
        return { before: makeRun('::before'), after: makeRun('::after') };
      };
      const hostHasDirectText = Array.from(blockEl.childNodes).some(
        n => n.nodeType === Node.TEXT_NODE && n.textContent.trim()
      );
      const pseudoRuns = buildPseudoRuns(hostHasDirectText);

      // Detect inline formatting: check for span/b/i/em/strong children
      const hasFormatting = blockEl.querySelector('span, b, i, u, strong, em, a, code, small, mark, br');

      if (hasFormatting) {
        const transformStr = computed.textTransform;
        const runs = parseInlineFormatting(blockEl, {}, [], (str) => applyTextTransform(str, transformStr));
        // Bug #1: prepend ::before run / append ::after run
        if (pseudoRuns.before) runs.unshift(pseudoRuns.before);
        if (pseudoRuns.after) runs.push(pseudoRuns.after);
        const adjustedStyle = { ...baseStyle };
        if (adjustedStyle.lineSpacing) {
          const maxFontSize = Math.max(adjustedStyle.fontSize, ...runs.map(r => r.options?.fontSize || 0));
          if (maxFontSize > adjustedStyle.fontSize) {
            adjustedStyle.lineSpacing = maxFontSize * (adjustedStyle.lineSpacing / adjustedStyle.fontSize);
          }
        }
        elements.push({
          type: blockTag.toLowerCase(),
          text: runs,
          position: { x: pxToInch(x), y: pxToInch(y), w: pxToInch(w), h: pxToInch(h) },
          style: { ...adjustedStyle, align: baseStyle.align }
        });
      } else {
        const textTransform = computed.textTransform;
        const transformedText = applyTextTransform(text, textTransform);
        const isBold = computed.fontWeight === 'bold' || parseInt(computed.fontWeight) >= 600;
        // Bug #1: if ::before/::after pseudo text exists, emit as runs (so the
        // pseudo keeps its own color, e.g. cyan `$ `). Otherwise plain string.
        if (pseudoRuns.before || pseudoRuns.after) {
          const runs = [];
          if (pseudoRuns.before) runs.push(pseudoRuns.before);
          runs.push({ text: transformedText, options: { color: baseStyle.color, fontSize: baseStyle.fontSize, fontFace: baseStyle.fontFace, bold: isBold && !shouldSkipBold(computed.fontFamily), italic: computed.fontStyle === 'italic' } });
          if (pseudoRuns.after) runs.push(pseudoRuns.after);
          elements.push({
            type: blockTag.toLowerCase(),
            text: runs,
            position: { x: pxToInch(x), y: pxToInch(y), w: pxToInch(w), h: pxToInch(h) },
            style: { ...baseStyle, bold: isBold && !shouldSkipBold(computed.fontFamily), italic: computed.fontStyle === 'italic', underline: computed.textDecoration.includes('underline') }
          });
        } else {
          elements.push({
            type: blockTag.toLowerCase(),
            text: transformedText,
            position: { x: pxToInch(x), y: pxToInch(y), w: pxToInch(w), h: pxToInch(h) },
            style: { ...baseStyle, bold: isBold && !shouldSkipBold(computed.fontFamily), italic: computed.fontStyle === 'italic', underline: computed.textDecoration.includes('underline') }
          });
        }
      }

      processed.add(blockEl);
    }

    // ── Pseudo-element text extraction (Bug #1 fix) ──────────────────────────────
    // CSS `content: attr(...) | "literal" | "literal " attr(...)` produces visible
    // text that lives ONLY in the pseudo-element (the host element's textContent
    // is empty). The TreeWalker never sees it. Without this pass, page numbers
    // (.slide-number::before content:attr(data-current)), shell prompts
    // (.hc-prompt::before content:'$ '), alert icons (.ts-alert-tag::before
    // content:'⚠'), and bar-chart value labels (.col .b::after content:attr(data-v))
    // all silently vanish from the PPTX.
    //
    // Strategy: for every element, inspect ::before and ::after. Parse `content`
    // (resolving attr() from the host's dataset, unwrapping string literals,
    // skipping url()/counter()/empty). If non-empty, emit a native text element
    // positioned at the pseudo's rendered box.
    const pseudoTextEmitted = new Set(); // dedupe host+pseudo pairs
    document.querySelectorAll('*').forEach((el) => {
      if (el instanceof SVGElement) return;
      if (el.closest('aside.notes, script, style')) return;
      // Pseudos only render on elements with a box
      if (!el.getBoundingClientRect) return;
      const hostRect = el.getBoundingClientRect();
      if (hostRect.width === 0 || hostRect.height === 0) return;

      // Collect ::before and ::after text+style for this host first, so when BOTH
      // are present we emit them as ONE merged text element (e.g. page-number
      // ".slide-number" renders "3" + " / 7" as a single "3 / 7" string). Emitting
      // them as two separate elements at the same host rect made them overlap.
      const hostHasDirectText = Array.from(el.childNodes).some(
        n => n.nodeType === Node.TEXT_NODE && n.textContent.trim()
      );
      const slots = {};
      for (const pseudo of ['::before', '::after']) {
        const pseudoStyle = window.getComputedStyle(el, pseudo);
        if (pseudoStyle.display === 'none' || pseudoStyle.visibility === 'hidden') continue;
        const text = parsePseudoContent(pseudoStyle.content, el);
        if (!text) continue;
        slots[pseudo] = { pseudoStyle, text };
      }
      if (hostHasDirectText || Object.keys(slots).length === 0) {
        // mixed-host pseudos are handled inline by the text-extraction loop; or no pseudo text.
        return;
      }

      // Build the merged text and a representative style.
      const hasBefore = !!slots['::before'];
      const hasAfter = !!slots['::after'];
      // Prefer ::before's style for the merged box (usually the leading content);
      // fall back to ::after.
      const refSlot = slots['::before'] || slots['::after'];
      const refStyle = refSlot.pseudoStyle;
      const beforeText = hasBefore ? applyTextTransform(slots['::before'].text, slots['::before'].pseudoStyle.textTransform) : '';
      const afterText = hasAfter ? applyTextTransform(slots['::after'].text, slots['::after'].pseudoStyle.textTransform) : '';
      const finalText = beforeText + afterText;

      // Position (same logic as before, using the reference slot's positioning).
      const pos = refStyle.position;
      let px = hostRect.left, py = hostRect.top, pw = hostRect.width, ph = hostRect.height;
      if (pos === 'absolute' || pos === 'fixed') {
        const inset = refStyle.inset;
        const left = refStyle.left, top = refStyle.top;
        const right = refStyle.right, bottom = refStyle.bottom;
        const pseudoW = parseFloat(refStyle.width) || 0;
        const pseudoH = parseFloat(refStyle.height) || 0;
        if (inset && inset !== 'auto') {
          const parts = inset.split(' ').map(s => parseFloat(s) || 0);
          const iTop = parts[0], iRight = parts.length > 1 ? parts[1] : iTop;
          const iBottom = parts.length > 2 ? parts[2] : iTop;
          const iLeft = parts.length > 3 ? parts[3] : iRight;
          px = hostRect.left + iLeft; py = hostRect.top + iTop;
          pw = hostRect.width - iLeft - iRight; ph = hostRect.height - iTop - iBottom;
        } else {
          if (left !== 'auto') px = hostRect.left + parseFloat(left);
          else if (right !== 'auto' && pseudoW) px = hostRect.right - pseudoW - parseFloat(right);
          if (top !== 'auto') py = hostRect.top + parseFloat(top);
          else if (bottom !== 'auto' && pseudoH) py = hostRect.bottom - pseudoH - parseFloat(bottom);
          if (pseudoW) pw = pseudoW;
          if (pseudoH) ph = pseudoH;
        }
        if (pw === 0) pw = hostRect.width;
        if (ph === 0) ph = hostRect.height;
      }

      const color = resolveTextColor(el);
      const transparency = extractAlpha(color);
      const fontFace = mapResolvedFont(refStyle.fontFamily);
      const isBold = refStyle.fontWeight === 'bold' || parseInt(refStyle.fontWeight) >= 600;
      const isCJK = /[一-鿿]/.test(finalText);
      // Width must cover BOTH before+after glyphs (e.g. "3 / 7"), so estimate from
      // the merged string length rather than the host rect (which may be 0-width
      // for an empty <span> that only carries pseudo content).
      const fontSizePx = parseFloat(refStyle.fontSize) || 14;
      const otherChars = finalText.length - (finalText.match(/[一-鿿]/g) || []).length;
      const cjkChars = finalText.length - otherChars;
      const estimatedIn = (cjkChars * fontSizePx * 1.05 + otherChars * fontSizePx * 0.62) / PX_PER_IN + 0.06;
      let bw = Math.max(pw + pw * (isCJK ? 0.15 : 0.08), estimatedIn);
      let bx = px;
      const textAlign = refStyle.textAlign && refStyle.textAlign !== 'start' ? refStyle.textAlign : 'left';
      const wBuf = bw - px;
      if (textAlign === 'center') { bx -= (bw - pw) / 2; }
      else if (textAlign === 'right') { bx -= (bw - pw); }

      elements.push({
        type: 'pseudo',
        text: finalText,
        position: { x: pxToInch(bx), y: pxToInch(py), w: pxToInch(bw), h: pxToInch(ph + ph * 0.05) },
        style: {
          fontSize: pxToPoints(refStyle.fontSize),
          fontFace,
          color: rgbToHex(color),
          bold: isBold && !shouldSkipBold(refStyle.fontFamily),
          italic: refStyle.fontStyle === 'italic',
          align: textAlign,
          lineSpacing: refStyle.lineHeight && refStyle.lineHeight !== 'normal' ? pxToPoints(refStyle.lineHeight) : null,
          transparency,
          margin: [0, 0, 0, 0]
        }
      });
    });

    // ── SVG <text> extraction (Bug #3 fix) ───────────────────────────────────────
    // SVG <text> labels (architecture diagrams, chart axis labels) are skipped by
    // the main element loop (`instanceof SVGElement` bail) and now skipped by the
    // TreeWalker too. Without this pass, all SVG labels vanish or get mis-attributed
    // to the outer HTML container. Here we emit each <text> as a native text box at
    // its real rendered position (getBoundingClientRect works on SVG elements).
    document.querySelectorAll('svg text').forEach((tEl) => {
      if (tEl.closest('aside.notes, script, style')) return;
      const raw = tEl.textContent.trim();
      if (!raw) return;
      const rect = tEl.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      const cs = window.getComputedStyle(tEl);
      // SVG fill drives glyph color; fall back to computed color.
      const fill = cs.fill;
      let color = 'FFFFFF';
      if (fill && fill !== 'none' && fill !== 'rgba(0, 0, 0, 0)') {
        color = rgbToHex(fill);
      } else {
        color = rgbToHex(resolveTextColor(tEl.parentElement || tEl));
      }
      const transparency = (fill && fill.startsWith('rgba')) ? extractAlpha(fill) : null;
      const isBold = cs.fontWeight === 'bold' || parseInt(cs.fontWeight) >= 600;
      // SVG text-anchor → PPTX align
      const anchor = tEl.getAttribute('text-anchor') || cs.textAnchor;
      let align = 'left';
      if (anchor === 'middle') align = 'center';
      else if (anchor === 'end') align = 'right';
      // Width buffer so labels don't clip
      const wBuf = rect.width * 0.1;
      let bx = rect.left;
      let bw = rect.width + wBuf;
      if (align === 'center') { bx -= wBuf / 2; }
      else if (align === 'right') { bx -= wBuf; }
      elements.push({
        type: 'svgtext',
        text: raw,
        position: { x: pxToInch(bx), y: pxToInch(rect.top), w: pxToInch(bw), h: pxToInch(rect.height + rect.height * 0.05) },
        style: {
          fontSize: pxToPoints(cs.fontSize),
          fontFace: mapResolvedFont(cs.fontFamily),
          color,
          bold: isBold && !shouldSkipBold(cs.fontFamily),
          italic: cs.fontStyle === 'italic',
          align,
          transparency,
          margin: [0, 0, 0, 0]
        }
      });
    });

    return { background, elements, placeholders, errors, textCoveredCount: textBlockGroups.size };
  });
}

async function html2pptx(htmlFile, pres, options = {}) {
  const {
    tmpDir = process.env.TMPDIR || '/tmp',
    slide = null,
    screenshotPath = null,
    nativeShapes = false,
    browser: externalBrowser = null,
    injectFonts = false
  } = options;

  try {
    let browser = externalBrowser;
    const ownsBrowser = !externalBrowser;

    if (ownsBrowser) {
      const launchOptions = { env: { TMPDIR: tmpDir } };
      if (process.platform === 'darwin') {
        launchOptions.channel = 'chrome';
      }
      browser = await getChromium().launch(launchOptions);
    }

    let bodyDimensions;
    let slideData;

    const filePath = path.isAbsolute(htmlFile) ? htmlFile : path.join(process.cwd(), htmlFile);
    const validationErrors = [];

    try {
      const page = await browser.newPage();
      page.on('console', (msg) => {
        console.log(`Browser console: ${msg.text()}`);
      });

      await page.goto(`file://${filePath}`, { waitUntil: 'load' });

      // Inject system fonts for PPTX alignment
      if (injectFonts) {
        await injectSystemFonts(page);
      }

      await page.evaluate(() => document.fonts.ready);

      await page.evaluate(() => {
        document.getAnimations().forEach(a => a.finish());
      });

      bodyDimensions = await getBodyDimensions(page);

      await page.setViewportSize({
        width: Math.round(bodyDimensions.width),
        height: Math.round(bodyDimensions.height)
      });

      slideData = await extractSlideData(page);
    } finally {
      if (ownsBrowser) await browser.close();
    }

    // Collect all validation errors
    if (bodyDimensions.errors && bodyDimensions.errors.length > 0) {
      validationErrors.push(...bodyDimensions.errors);
    }

    const dimensionErrors = validateDimensions(bodyDimensions, pres);
    if (dimensionErrors.length > 0) {
      validationErrors.push(...dimensionErrors);
    }

    const textBoxPositionErrors = validateTextBoxPosition(slideData, bodyDimensions);
    if (textBoxPositionErrors.length > 0) {
      validationErrors.push(...textBoxPositionErrors);
    }

    if (slideData.errors && slideData.errors.length > 0) {
      // hybrid/v2 模式：装饰元素错误（渐变、背景图）已通过原生形状处理，不再是致命错误
      const decorationErrors = new Set([
        'CSS gradients are not supported',
        'Background images on DIV elements are not supported',
        'el.className.includes is not a function',
        'DIV element contains unwrapped text',  // V2: TreeWalker handles all text
      ]);
      for (const e of slideData.errors) {
        const isDecoration = [...decorationErrors].some(msg => e.includes(msg));
        if (!screenshotPath || !isDecoration) {
          validationErrors.push(e);
        }
      }
    }

    // Throw all errors at once if any exist
    if (validationErrors.length > 0) {
      const errorMessage = validationErrors.length === 1
        ? validationErrors[0]
        : `Multiple validation errors found:\n${validationErrors.map((e, i) => `  ${i + 1}. ${e}`).join('\n')}`;
      throw new Error(errorMessage);
    }

    const targetSlide = slide || pres.addSlide();

    await addBackground(slideData, targetSlide, tmpDir, screenshotPath);
    addElements(slideData, targetSlide, pres, screenshotPath, nativeShapes);

    return { slide: targetSlide, placeholders: slideData.placeholders };
  } catch (error) {
    if (!error.message.startsWith(htmlFile)) {
      throw new Error(`${htmlFile}: ${error.message}`);
    }
    throw error;
  }
}

module.exports = html2pptx;
module.exports.extractSlideData = extractSlideData;
module.exports.getBodyDimensions = getBodyDimensions;
module.exports.validateDimensions = validateDimensions;
module.exports.validateTextBoxPosition = validateTextBoxPosition;
module.exports.addBackground = addBackground;
module.exports.addElements = addElements;
module.exports.injectSystemFonts = injectSystemFonts;
module.exports.getSystemFontCSS = getSystemFontCSS;