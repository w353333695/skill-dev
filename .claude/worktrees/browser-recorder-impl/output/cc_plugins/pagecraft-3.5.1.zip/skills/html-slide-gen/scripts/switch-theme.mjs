#!/usr/bin/env node
/**
 * switch-theme.mjs — 一键切换 deck 颜色方案（只换色，不动布局/字体/圆角/阴影）
 *
 * Color Scheme ≠ Style Template
 *   - Color Scheme: 纯色板（--accent, --bg, --text-1, --grad...）
 *   - Style Template: 布局骨架（radius, shadow, font, spacing, 组件类）
 *   两者独立组合：同一颜色方案可以套到任意风格模板上。
 *
 * 用法:
 *   # 列所有可用颜色方案
 *   node switch-theme.mjs --list
 *
 *   # 只换 colors
 *   node switch-theme.mjs --deck <deck-dir> --scheme <scheme-name>
 *
 *   # 换色 + 注入 advisor CTA/数据系列色（04-visual-richness：补真强调色）
 *   node style_advisor.mjs "<行业>" --json > /tmp/palette.json
 *   node switch-theme.mjs --deck <deck-dir> --scheme <scheme-name> --palette /tmp/palette.json
 *
 *   # 换色 + 重新生成单文件 HTML + 导出 PPTX（并行渲染加速）
 *   node switch-theme.mjs --deck <deck-dir> --scheme <scheme-name> --html --pptx --parallel 4
 *
 * 示例:
 *   node switch-theme.mjs --deck slides-output/<name>/export/<name>-live --scheme dracula --html --pptx --parallel 4
 *
 * 注入链（CTA 为例，BM25 只在 4.1 跑一次，逐页生成零查色）:
 *   style_advisor --json → palette{ hi-strong, data-1..6 }
 *   → switch-theme --palette：与 15 brand key 同批正则写入 deck :root
 *   → tokens.css 组件/强调 class(.kpi-emph) 引用 var(--hi-strong)
 *   → 稳定语义层（--hi-positive/warning）由 mergeSemanticTokens 幂等并入
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function parseArgs() {
  const args = {};
  const a = process.argv.slice(2);
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '--list') { args.list = true; continue; }
    if (a[i] === '--html') { args.html = true; continue; }
    if (a[i] === '--pptx') { args.pptx = true; continue; }
    if (a[i].startsWith('--')) {
      args[a[i].replace('--', '')] = a[i + 1];
      i++;
    }
  }
  // --theme is an alias for --scheme
  if (args.theme && !args.scheme) args.scheme = args.theme;
  return args;
}

function loadColorSchemes() {
  const schemasPath = path.join(__dirname, 'color-schemes.json');
  const data = JSON.parse(fs.readFileSync(schemasPath, 'utf-8'));
  const schemes = data.schemes || {};
  // 合并 custom 分组（extract-colors.mjs --save 写入的自定义色板）
  for (const entry of (data.custom || [])) {
    const id = entry.id || entry.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    schemes[id] = entry;
  }
  return schemes;
}

// ONLY color variables — never radius, shadow, font, or spacing
const COLOR_TOKEN_MAP = {
  'brand-primary':    '--brand-primary:',
  'brand-secondary':  '--brand-secondary:',
  'brand-accent':     '--brand-accent:',
  'brand-bg':         '--brand-bg:',
  'brand-surface':    '--brand-surface:',
  'brand-text':       '--brand-text:',
  'brand-text-dim':   '--brand-text-dim:',
  'brand-text-faint': '--brand-text-faint:',
  'brand-border':     '--brand-border:',
  'border-strong':    '--border-strong:',
  'brand-good':       '--brand-good:',
  'brand-warn':       '--brand-warn:',
  'brand-bad':        '--brand-bad:',
  'brand-gradient':   '--brand-gradient:',
  'grad-soft':        '--grad-soft:',
  // -rgb channels for rgba() compositions in deck overlays
  'brand-primary-rgb':   '--brand-primary-rgb:',
  'brand-secondary-rgb': '--brand-secondary-rgb:',
  'brand-accent-rgb':    '--brand-accent-rgb:',
  'brand-good-rgb':      '--brand-good-rgb:',
  'brand-warn-rgb':      '--brand-warn-rgb:',
  'brand-bad-rgb':       '--brand-bad-rgb:',
  'brand-text-rgb':      '--brand-text-rgb:',
  // === per-palette 强调层（值来自 advisor --palette，与 brand key 同批注入）===
  // --hi-strong ← CTA（独立对比色，补 HTML「重点不突出」最缺的真强调色）
  'hi-strong':      '--hi-strong:',
  'hi-strong-rgb':  '--hi-strong-rgb:',
  // --data-1..6 ← Okabe-Ito 色盲安全 6 色（多系列图表分色，不再全 brand 单色循环）
  'data-1': '--data-1:',
  'data-2': '--data-2:',
  'data-3': '--data-3:',
  'data-4': '--data-4:',
  'data-5': '--data-5:',
  'data-6': '--data-6:',
  // === per-scheme 语义色层（C1/D14，2026-06-26：语义不变色号随主题协调）===
  // --hi-positive（正绿）/ --hi-warning（负红）：原写死在 semantic-tokens.css 稳定层，
  // 导致 evergreen 绿底 + #16a34a 绿撞主色。现 per-scheme 预置（绿主题正向偏青绿区分主色）。
  // semantic-tokens.css 的写死值降级为兜底（scheme 无预设时用）。
  'hi-positive':     '--hi-positive:',
  'hi-positive-rgb': '--hi-positive-rgb:',
  'hi-warning':      '--hi-warning:',
  'hi-warning-rgb':  '--hi-warning-rgb:',
};

// 稳定语义层标记（检测 semantic-tokens.css 是否已并入 tokens.css）
const SEMANTIC_MARKER = '--hi-positive:';
const SEMANTIC_SOURCE = path.join(__dirname, '..', 'templates', 'shared', 'semantic-tokens.css');

// hex → HSL（用于 CTA 色相协调门）
function hexToHsl(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex).trim());
  if (!m) return null;
  const r = parseInt(m[1].slice(0, 2), 16) / 255;
  const g = parseInt(m[1].slice(2, 4), 16) / 255;
  const b = parseInt(m[1].slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  if (max === min) return { h: 0, s: 0, l: (max + min) / 2 * 100 };
  const d = max - min;
  const l = (max + min) / 2;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  let h;
  if (max === r) h = ((g - b) / d + (g < b ? 6 : 0));
  else if (max === g) h = ((b - r) / d + 4);
  else h = ((r - g) / d + 2);
  return { h: h * 60, s: s * 100, l: l * 100 };
}
// 两色色相距离（0-180）
function hueDistance(hexA, hexB) {
  const a = hexToHsl(hexA), b = hexToHsl(hexB);
  if (!a || !b) return 0;
  const d = Math.abs(a.h - b.h) % 360;
  return Math.min(d, 360 - d);
}

function applyColorScheme(tokensPath, scheme) {
  let content = fs.readFileSync(tokensPath, 'utf-8');
  const tokens = scheme.tokens;
  const missing = [];

  for (const [presetKey, cssVar] of Object.entries(COLOR_TOKEN_MAP)) {
    if (tokens[presetKey]) {
      const regex = new RegExp(`${cssVar.replace(/[-\/]/g, '\\$&')}\\s*[^;]+;`);
      const before = content;
      content = content.replace(regex, `${cssVar} ${tokens[presetKey]};`);
      // Detect silent no-op: scheme has a value but the CSS var isn't in the file
      // (regex matched nothing). This is the H2 class of bug — switch-theme prints
      // "✓ (N colors)" giving false confidence while rgba() overlays stay on the
      // deck's default color. Surface it as a warn instead of failing silently.
      if (content === before) {
        missing.push(`${cssVar} (--${presetKey.replace(/:/, '')})`);
      }
    }
  }

  fs.writeFileSync(tokensPath, content, 'utf-8');
  return {
    applied: Object.keys(COLOR_TOKEN_MAP).filter(k => tokens[k]).length,
    missing,
  };
}

// 稳定语义层幂等合并：把 semantic-tokens.css 内容并到 tokens.css 末尾。
// 不走 @import（export_single.mjs 只读 tokens.css 一个文件、裸拼进 <style>，不递归内联 @import，
// 单文件导出会断链）。幂等：tokens.css 已含 --hi-positive 标记则跳过。
function mergeSemanticTokens(tokensPath) {
  const content = fs.readFileSync(tokensPath, 'utf-8');
  if (content.includes(SEMANTIC_MARKER)) {
    return { merged: false, reason: 'already present' };
  }
  if (!fs.existsSync(SEMANTIC_SOURCE)) {
    return { merged: false, reason: 'source not found' };
  }
  const semantic = fs.readFileSync(SEMANTIC_SOURCE, 'utf-8');
  const banner = '\n\n/* === semantic-tokens (idempotent merge by switch-theme; source: templates/shared/semantic-tokens.css) ===\n'
    + '     稳定语义层（--hi-positive/warning 跨 deck 不变）+ 预置强调 class（.kpi-emph 等，subagent 只引用不发明）。\n'
    + '     不走 @import：export_single.mjs 不内联 @import，单文件导出会断链。=== */\n';
  fs.writeFileSync(tokensPath, content + banner + semantic + '\n', 'utf-8');
  return { merged: true };
}

function main() {
  const args = parseArgs();

  if (args.list) {
    const schemes = loadColorSchemes();
    console.log('可用颜色方案 (Color Schemes):');
    console.log('');
    for (const [id, scheme] of Object.entries(schemes)) {
      const badge = scheme.isDark ? '暗色' : '浅色';
      const mood = scheme.mood.join('·');
      console.log(`  ${id.padEnd(22)} ${scheme.tokens['brand-primary'].padEnd(10)} ${badge}  ${mood}`);
      console.log(`  ${''.padEnd(22)} 适用: ${scheme.bestFor.join(' / ')}`);
      console.log('');
    }
    return;
  }

  if (!args.deck || !args.scheme) {
    console.error('用法: node switch-theme.mjs --deck <deck-dir> --scheme <scheme-name> [--html] [--pptx] [--parallel N]');
    console.error('      node switch-theme.mjs --list');
    process.exit(1);
  }

  const schemes = loadColorSchemes();
  const scheme = schemes[args.scheme];
  if (!scheme) {
    console.error(`未知颜色方案: ${args.scheme}`);
    console.error(`可用: ${Object.keys(schemes).join(', ')}`);
    process.exit(1);
  }

  // advisor --palette 合并：把 CTA(--hi-strong) + 数据系列(--data-1..6) 并入 scheme.tokens。
  // palette 值走与 brand key 同一条 applyColorScheme 正则替换链 + missing 检测，零新注入逻辑。
  let paletteInfo = null;
  let paletteCtaOverride = null;
  if (args.palette) {
    const palettePath = path.resolve(args.palette);
    if (!fs.existsSync(palettePath)) {
      console.error(`找不到 palette 文件: ${palettePath}`);
      process.exit(1);
    }
    const advisor = JSON.parse(fs.readFileSync(palettePath, 'utf-8'));
    const pal = advisor.palette || {};
    // ── CTA 协调门（C1/D14，2026-06-26）──
    // 实战 v46/v47：用户选 evergreen/amber 非「蓝系」主题，但 advisor 检索 B2B Service →
    // CTA 固定蓝 #0369A1，无条件覆盖 scheme 预设的协调 CTA（金/橙），蓝色 CTA 出现在绿/橙主题里刺眼。
    // 修法：advisor CTA 与 scheme 主色**色相兼容**（距离 ≤ 60°，同色系/邻色）才采用；否则保留
    // scheme 预设 CTA（已 HSL 调和、与主色协调）。data-1..6（图表系列色）不受此门影响。
    const advisorCta = pal['hi-strong'];
    const advisorCtaRgb = pal['hi-strong-rgb'];
    const schemePrimary = scheme.tokens['brand-primary'];
    if (advisorCta && schemePrimary) {
      const dist = hueDistance(advisorCta, schemePrimary);
      if (dist > 60) {
        // 色相冲突（如蓝 CTA vs 绿/橙主色）→ 丢弃 advisor CTA，保留 scheme 预设
        delete pal['hi-strong'];
        delete pal['hi-strong-rgb'];
        paletteCtaOverride = { advisorCta, schemeCta: scheme.tokens['hi-strong'], dist };
      }
    }
    for (const [k, v] of Object.entries(pal)) scheme.tokens[k] = v;
    paletteInfo = {
      industry: advisor.industry,
      via: advisor.via,
      cta: (advisor.colors && advisor.colors.cta),
      keys: Object.keys(pal),
    };
  }

  // 1. Apply color scheme to tokens.css
  const tokensPath = path.join(args.deck, 'shared', 'tokens.css');
  if (!fs.existsSync(tokensPath)) {
    console.error(`找不到 tokens.css: ${tokensPath}`);
    process.exit(1);
  }

  const start = Date.now();
  // 2. 稳定语义层幂等合并：先于 applyColorScheme 执行——把 semantic-tokens.css 并入
  //    tokens.css（含写死的 --hi-positive/warning 占位 + 强调 class），随后 applyColorScheme
  //    用 scheme 预设值覆盖这些占位（per-scheme 协调语义色，治 C1 配色撞色）。
  //    不走 @import（export_single.mjs 不内联 @import，单文件导出会断链）。幂等：已含标记则跳过。
  const sem = mergeSemanticTokens(tokensPath);
  if (sem.merged) {
    console.log(`✓ 语义层（--hi-positive/warning + 强调 class）幂等并入 tokens.css`);
  } else if (sem.reason === 'source not found') {
    console.warn(`⚠ 语义层源缺失: ${SEMANTIC_SOURCE}（强调 class 不可用）`);
  }

  // 1. Apply color scheme to tokens.css（在语义层并入后，确保 hi-positive/warning 预设能覆盖占位）
  const { applied, missing } = applyColorScheme(tokensPath, scheme);
  const mood = scheme.mood.join('·');
  const isDark = scheme.isDark ? '暗色' : '浅色';
  console.log(`✓ "${scheme.name}" (${isDark} ${mood}) → tokens.css (${applied} 个颜色变量) — ${Date.now() - start}ms`);
  if (paletteInfo) {
    console.log(`✓ advisor palette [${paletteInfo.industry}, via ${paletteInfo.via}] → CTA ${paletteInfo.cta} + ${paletteInfo.keys.length} 个强调/数据 token 同批注入`);
    if (paletteCtaOverride) {
      console.log(`  ℹ️  CTA 协调门：advisor CTA ${paletteCtaOverride.advisorCta} 与主色色相距离 ${Math.round(paletteCtaOverride.dist)}°（>60°冲突）→ 改用 scheme 预设 CTA ${paletteCtaOverride.schemeCta}（与主题协调）`);
    }
  }
  if (missing.length > 0) {
    console.warn(`⚠ ${missing.length} 个颜色变量在 tokens.css 中缺失，switch-theme 对它们是 no-op（换肤不完整）:`);
    for (const m of missing) console.warn(`    • ${m}`);
    console.warn(`  修复：在 deck 的 shared/tokens.css :root 中补齐对应 --brand-*-rgb / --brand-* / --hi-strong / --data-* 通道。`);
  }


  // 2. Regenerate single-file HTML
  if (args.html) {
    const exportSingle = path.join(__dirname, 'export_single.mjs');
    const deckName = path.basename(args.deck).replace(/-live$/, '');
    const parentDir = path.dirname(path.dirname(args.deck));
    const outFile = path.join(parentDir, 'index.html');

    const t0 = Date.now();
    execSync(`node "${exportSingle}" --deck "${args.deck}" --out "${outFile}"`, {
      stdio: 'pipe',
      timeout: 60000
    });
    console.log(`✓ 单文件 HTML 已更新 — ${Date.now() - t0}ms`);
  }

  // 3. Export PPTX
  if (args.pptx) {
    const exportPptx = path.join(__dirname, 'export_pptx.mjs');
    const slidesDir = path.join(args.deck, 'slides');
    const deckName = path.basename(args.deck).replace(/-live$/, '');
    const parentDir = path.dirname(path.dirname(args.deck));
    const outFile = path.join(parentDir, 'export', `${deckName}.pptx`);
    const parallel = args.parallel || 4;

    const t0 = Date.now();
    try {
      execSync(`node "${exportPptx}" --slides "${slidesDir}" --out "${outFile}" --mode editable --parallel ${parallel}`, {
        stdio: 'inherit',
        timeout: 300000
      });
      console.log(`✓ PPTX 已导出 — ${Date.now() - t0}ms`);
    } catch (e) {
      console.error(`✗ PPTX 导出失败: ${e.message}`);
    }
  }

  console.log(`\n总耗时: ${Date.now() - start}ms`);
}

main();
