# 模板文件约定 — 画布 / Slide HTML / SVG / 暗色变体

> 编辑或新增 starter-deck 模板时需了解的技术约定。运行时生成（subagent）一般不读本文件——由 tokens.css + subagent-rules.md 覆盖；本文件面向"改模板"的人。

## C.1 画布与缩放

- **所有模板统一 1920×1080 横版**（无竖版模板）
- `index.html` 通过 `transform: scale()` 将 1920×1080 画布适配到任意屏幕
- 每个 slide HTML 的 `<body>` 设置 `width: var(--deck-width, 1920px); height: var(--deck-height, 1080px)`
- slide 的 viewport meta 用 `width=1920px`（不是 `device-width`）

## C.2 Slide HTML 文件规范

```html
<!DOCTYPE html>
<html lang="en">                          <!-- 或 zh-CN -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1920px">
<title>NN - Title</title>
<link rel="stylesheet" href="../shared/tokens.css">
</head>
<body class="tpl-<template-name>">        <!-- 模板 class 在 body 上 -->
<!-- data-title: Title -->               <!-- HTML 注释，供 index.html 读取 -->
<!-- slide 内容——纯 HTML，无 <style> 块 -->
</body>
</html>
```

**关键约束**：
- ❌ slide HTML **不应有 `<style>` 块**——所有样式来自 tokens.css
- ❌ slide HTML **不应内联颜色**——颜色一律用 `var(--xxx)` token
- ✅ inline style 仅用于布局/尺寸（如 `style="height:18%"` 柱状图高度）
- ✅ 逐字稿放在 `<aside class="notes">`（tokens.css 已 `.notes { display: none !important }`）

## C.3 index.html 壳层

```
index.html 结构：
├─ <style> 块              ← 壳层专用 CSS（stage、iframe、counter、nav-zone、hint-bar、notes-overlay）
├─ <div id="stage">        ← 包含所有 iframe
│   └─ <iframe data-src="slides/01-xxx.html" data-title="TITLE">
├─ <div class="counter">   ← 页码显示
├─ <div class="nav-zone">  ← 左右点击区域
├─ <div class="hint-bar">  ← 键盘提示栏
├─ <div class="notes-overlay"> ← 逐字稿抽屉
└─ <script src="index-runtime.js">  ← 运行时（导航/缩放/键盘/notes）
```

> ⚠️ **生产用入口壳**是 `templates/index-shell.html` + `templates/index-runtime.js`（JS 分离、含完整演讲者视图）。模板自带的 `index.html` 仅作 demo，生产路径强制用模板版（见 SKILL.md）。**模板标注不涉及 index.html 修改**——只在 `slides/*.html` 和 `slide-roles.md` 中进行。

## C.4 模板专属 class 前缀

每个模板有自己的 class 命名约定，不与通用 token（`.card` `.h1` `.grid`）冲突：

| 模板 | class 前缀 |
|------|-----------|
| pitch-deck | `.section-num` `.num-tag` `.metric` `.traction-bar` `.cover-blob` `.ask-box` `.mega` `.brand-dot` `.team-card` `.big-q` |
| tech-sharing | `.terminal` `.kw` `.fn` `.str` `.cmt` `.agenda-row` `.speaker` |
| weekly-report | `.kpi` `.ship-item` `.tag` `.blocker` `.next-row` `.chart-bars` |
| product-launch | `.hero-shot` `.feature-card` `.step` `.price-card` `.cta-btn` `.testimonial` |
| course-module | `.sidebar` `.learning-objective` `.module-tag` |
| dir-key-nav-minimal | `.dk-accent` `.dk-list` `.dk-snum` `.dk-page` |
| graphify-dark-graph | `.glass` `.cmd-glow` |
| hermes-cyber-terminal | `.terminal` `.scanlines` `.cyber-grid` |
| knowledge-arch-blueprint | `.blueprint-grid` `.pipeline` `.step-box` `.hero-box` `.insight-callout` |
| obsidian-claude-gradient | `.pill` `.highlight`（通用 class） |
| presenter-mode-reveal | 复用通用 class + 演讲者专用 |
| testing-safety-alert | `.alert-stripe` `.strike-through` `.severity-L1` `.policy-yaml` |
| xhs-pastel-card | `.xp-blob` `.xp-topbar` `.xp-chip` `.xp-h1` `.xp-card` `.xp-divider` |
| xhs-white-editorial | `.xw-rainbow` `.xw-brand` `.xw-h1` `.xw-card` `.xw-focus` `.xw-hero-quote` |

## C.5 body flex 居中

所有模板的 `body` 统一为：

```css
body { display: flex; flex-direction: column; justify-content: center; }
```

即模板 slide 内容默认**垂直居中**。`data-replace` 替换内容不改变布局，替换后仍居中。

## C.6 SVG 元素

部分模板含内联 SVG（图表、架构图）。SVG 坐标属性（`x` `y` `width` `height` `cx` `cy` `r` `d`）是 **viewBox 坐标系**，不是 CSS px：
- ✅ 可以替换 SVG 内 `<text>` 文字内容
- ❌ 不要修改 SVG 坐标属性（会导致图表变形）
- ❌ 不要在 SVG 元素上加 `data-replace` 标注坐标属性

## C.7 暗色/亮色页

- **product-launch**：`<body class="tpl-product-launch dark">` — 暗色背景页（`.tpl-product-launch.dark` 覆盖背景色）
- **dir-key-nav-minimal**：每页独立底色 class（`.t-indigo` `.t-charcoal`…）
- **tech-sharing / graphify-dark-graph / hermes-cyber-terminal / obsidian-claude-gradient / presenter-mode-reveal**：全局暗色

`data-replace` 不涉及 body class——body class 由模板角色决定，不属于可替换内容。
