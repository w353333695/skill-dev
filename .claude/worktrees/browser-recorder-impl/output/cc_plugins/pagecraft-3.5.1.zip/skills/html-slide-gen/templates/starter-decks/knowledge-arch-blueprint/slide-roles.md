# knowledge-arch-blueprint — Slide Role Catalog

> **模板气质**：warm paper, 48px blueprint grid background (`kb-grid-bg`), rust-red accent `#B5392A`, 2px hard-border cards (`kb-card`), no gradients / no box-shadows / no soft-radius blur
> **默认 color-scheme**：rust-red single accent (CSS variable `--kb-rust: #B5392A`, `--kb-rust-soft: #F0EAE0`)
> **适用文稿类型**：传授 / 赋能（knowledge-transfer, architecture explainer, system walkthrough）
> **叙事结构（16 页，按出现顺序）**：cover → quote → big-statement → section-divider → comparison → definition → feature-grid → timeline → table → diagram → illustration → code → stats → faq → cta → thanks
>
> 01–04 为「开篇」（封面 + 钩子引用 + 论点宣言 + 章节切入）；05–09 为「展开」（对比、术语、能力、演进、方案选型）；10–13 为「机制」（架构图、结构图解、代码、数据）；14–16 为「收束」（答疑、行动号召、致谢）。其中 02/03/06/07/08/09/11/14 为 v2 新增板式（引用/宣言/术语/特性网格/时间轴/对比表/插图/问答）。

---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 密集信息封面：标题 + 洞察框 + 4步管道图 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-sub`, `kb-insight`, `kb-section-label`, `kb-pipeline`(4 steps), `kb-footer` |
| 02 | `quote` | 大字引用：装饰引号 + 衬线斜体金句 + 出处 | `kb-grid-bg`, `kb-kicker`, 巨型 `"` 字形(inline serif), `blockquote`(inline serif italic), attribution(inline), `kb-footer` |
| 03 | `big-statement` | 单句宣言：rust 竖条 + 超大标题 + 脚注 | `kb-grid-bg`, `kb-kicker`, `kb-h1`(104px), footnote(inline), `kb-footer` |
| 04 | `section-divider` | 大字号章节分隔：居中排版，纯排版无卡片 | `kb-grid-bg`, `kb-kicker`, `kb-h1`(160px), `kb-sub`, `kb-footer` |
| 05 | `comparison` | 双栏卡片对比 + 图例 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-grid-2`(2 cards), `kb-card`, `kb-legend`, `kb-footer` |
| 06 | `definition` | 术语定义：左侧巨大术语词 + 右侧定义卡 + 要点 + 标签 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-grid-2`, `kb-card`, `.point`(×3), pill 标签(inline), `kb-footer` |
| 07 | `feature-grid` | 特性矩阵：3×2 卡片网格，每卡内联 SVG 图标 + 标题 + 说明 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-card`(×6), inline `<svg>` 图标(`fill=var(--kb-rust)`), `kb-footer` |
| 08 | `timeline` | 水平时间轴：5 节点等分，中间一个 rust 高亮节点 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, inline 横线 + `<svg>` 节点圆点, `kb-footer` |
| 09 | `table` | 对比表：硬边表格，表头 rust-soft 底，推荐列 rust 高亮 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-card`(包裹), `<table>`(硬边), `kb-footer` |
| 10 | `diagram` | SVG 流程架构图：方框、实线箭头、虚线反馈回路 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, inline SVG (rect/text/line/path with markers), `kb-footer` |
| 11 | `illustration` | 插图页：左侧 blueprint 线稿 SVG（分层堆栈 + 反馈回路） + 右侧标题/副标题/3 要点 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-sub`, inline SVG(含 `#arrow-r` marker + 虚线回路), `.point`(×3), 图注(inline), `kb-footer` |
| 12 | `code` | 代码展示：标题 + 语法高亮代码块 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-sub`, `kb-codebox`(pre with spans), `kb-footer` |
| 13 | `stats` | 数据指标：大数字 + 统计卡片 + 详情卡片 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-big-num`, `kb-card`(stat cards), `kb-grid-2`(detail cards), `kb-footer` |
| 14 | `faq` | 问答列表：3 个 Q&A 卡片，rust Q / gray A 大字母 + 问答文 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-card`(×3), inline serif Q/A 字母, `kb-footer` |
| 15 | `cta` | 行动号召：标题 + 副标题 + 4步行动规划管道 | `kb-grid-bg`, `kb-kicker`, `kb-h1`, `kb-sub`, `kb-pipeline`(4 steps, 1 hero), `kb-footer` |
| 16 | `thanks` | 结束致谢：居中大字排版，链接信息 | `kb-grid-bg`, `kb-kicker`, `kb-h1`(186px), `kb-sub`, `kb-footer` |

---

## 角色详情

### 01 — `cover`

- **源文件**：`slides/01-cover.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Karpathy Stack · 架构图 v2` | `div.kb-kicker` |
| `title` | `LLM <span class="rust">知识库</span> 的<br>工程化蓝图` | `h1.kb-h1` |
| `subtitle` | `从「乱贴笔记」到「可审计、...」` | `p.kb-sub` |
| `insight-label` | `KEY INSIGHT` | `span.kk` |
| `insight-body` | `Karpathy 原版缺一块：<br>反馈闭环让错误能回流纠正。` | `span` (insight body) |
| `section-label` | `Pipeline · End-to-end` | `div.kb-section-label` |
| `step1-num` | `STEP 01` | `div.kb-step-num` |
| `step1-title` | `采集` | `div.kb-step-title` |
| `step1-body` | `浏览器剪藏、PDF、Podcast 转写、聊天记录` | `div.kb-step-body` |
| `step2-num` | `STEP 02` | `div.kb-step-num` |
| `step2-title` | `去噪` | `div.kb-step-title` |
| `step2-body` | `清洗导航栏、广告、重复段落、低信噪素材` | `div.kb-step-body` |
| `step3-num` | `STEP 03 · CORE` | `div.kb-step-num` |
| `step3-title` | `Wiki 化` | `div.kb-step-title` |
| `step3-body` | `结构化成双链笔记，实体、关系、属性全在一起` | `div.kb-step-body` |
| `step4-num` | `STEP 04` | `div.kb-step-num` |
| `step4-title` | `使用` | `div.kb-step-title` |
| `step4-body` | `Agent 随时检索、回答、再写入` | `div.kb-step-body` |
| `footer-left` | `Blueprint · v2 · 2026.04` | `span` (left) |
| `page-num` | `01 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`(蓝图网格层), `div.kb-pipeline`(管道容器), `div.kb-step` / `.hero`(步骤结构), `div.kb-footer`(页脚容器), `div.kb-insight`(洞察框容器), `div.kb-section-label`(标签容器). 排版字号(font-size)不可改.
- **内容适配规则**：pipeline 保持 4 步，step3 始终标记 `.hero`. 如管道步骤少于 4，填充 placeholder 或合并相邻步骤文案. `insight` 区域必须有：标签 + 一句话洞察.
- **扩展/收缩**：不可缩减 pipeline 步骤为 3 或更少. 可追加第 5 步(需新增 `div.kb-step`，同步添加 `step5-*` 键).

### 02 — `quote`

- **源文件**：`slides/02-quote.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Voices · Testimonial` | `div.kb-kicker` |
| `quote-mark` | `&ldquo;` | 装饰引号 `span`(inline serif 300px rust) |
| `quote` | `你的笔记不是仓库，是一张 <span class="rust">活的图</span>。每次 AI 用它，它就该比上一次更准一点。` | `blockquote`(inline serif italic 50px) |
| `attribution` | `—— Andrej Karpathy · 知识库分享` | 出处 `div`(inline uppercase gray) |
| `footer-left` | `Content · Quote` | `span` (left) |
| `page-num` | `02 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 装饰引号 `span`(结构 + 字号 300px + line-height .62), `blockquote` 的衬线斜体样式, `div.kb-footer`. **本角色无 h1**（引用本身即标题）.
- **内容适配规则**：`quote` 文案控制在 1-3 行，可用一个 `<span class="rust">` 标记关键词. `attribution` 必须有出处（人物 / 来源 / 场合）. 装饰引号固定为 `&ldquo;`（左双引号），不可改为其他符号.
- **扩展/收缩**：纯排版角色，不加卡片/管道. 引号与文字的左右两栏布局不可改为上下堆叠.

### 03 — `big-statement`

- **源文件**：`slides/03-big-statement.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Thesis` | `div.kb-kicker` |
| `statement` | `错误不是终点，<br>而是 <span class="rust">回路</span> 的入口。` | `h1.kb-h1`(inline 104px) |
| `footnote` | `一个能自我纠错的知识库，远胜于一个"更大但更脆"的知识库。...` | 脚注 `div`(inline gray 20px) |
| `footer-left` | `Content · Statement` | `span` (left) |
| `page-num` | `03 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 左侧 rust 竖条 `border-left:8px solid var(--kb-rust)` 容器, `h1` 字号(104px，刻意例外——介于内容 78 与 section-divider 160 之间，突出宣言语气), `div.kb-footer`. 不加副标题（区别于 section-divider）.
- **内容适配规则**：`statement` 为一句结论/宣言，控制在 1-2 行（可用 `<br>` 换行）, 用一个 `<span class="rust">` 标记核心词. `footnote` 为一行补充说明，可选留空.
- **扩展/收缩**：纯排版角色，不加卡片/管道/图标. 与 `section-divider` 区别：无副标题、非章节性、聚焦单句结论.

### 04 — `section-divider`

- **源文件**：`slides/04-section-divider.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Chapter One` | `div.kb-kicker` |
| `title` | `为什么 <span class="rust">笔记</span><br>不够用了` | `h1.kb-h1` |
| `subtitle` | `当你的知识量超过记忆容量，<br>你需要的不是更多文件，而是一张<b>可导航的图</b>。` | `p.kb-sub` |
| `footer-left` | `Section · Chapter 1` | `span` (left) |
| `page-num` | `04 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 排版容器 `style="margin:auto 0"`, `h1` 字号(160px), `p.kb-sub` 字号(32px)和间距. 垂直居中布局不可改为顶部对齐.
- **内容适配规则**：标题必须在 `<span class="rust">` 中标注一个关键词. 副标题必须用 `<b>` 标记一个核心短语. 总文案量不超过 3 行.
- **扩展/收缩**：不可在此角色添加卡片或管道组件. 纯排版角色——只允许标题+副标题.

### 05 — `comparison`

- **源文件**：`slides/05-content-2.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Problem · Solution` | `div.kb-kicker` |
| `title` | `原版 vs <span class="rust">升级版</span>` | `h1.kb-h1` |
| `card1-label` | `原版 Karpathy` | `div.kb-kicker`(in card) |
| `card1-title` | `一次性写入` | `h4` |
| `card1-body` | `采集 → 转写 → 存档，错了就错了。...` | `p` |
| `card2-label` | `升级 v2` | `div.kb-kicker`(in card) |
| `card2-title` | `反馈闭环` | `h4` |
| `card2-body` | `AI 使用知识库时记录每次 miss / 幻觉...` | `p` |
| `legend-normal` | `普通节点` | `span` |
| `legend-core` | `核心节点 · 反馈回路入口` | `span` |
| `legend-flow` | `—— 数据流     ┈┈ 反馈回路` | `span` |
| `footer-left` | `Content · Compare` | `span` (left) |
| `page-num` | `05 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, `div.kb-grid-2`(2列容器), `div.kb-card`(卡片结构), `div.kb-legend`(图例容器), `div.kb-footer`. 右侧卡片样式 `background:var(--kb-rust-soft);border-color:var(--kb-rust)` 为 hero 卡标记.
- **内容适配规则**：card1 始终为"原版/现状/旧方案"，card2 始终为"升级/新方案/目标". 右侧卡片始终用 rust 软底突出. `kb-legend` 中的图例条目数量可变(`legend-*` 键对应增减).
- **扩展/收缩**：卡片数量固定为 2. 如需要 3 栏对比，不应使用此角色——改用 `table` 角色(09)或 `kb-grid-3` 变体. 图例条目可增可减.

### 06 — `definition`

- **源文件**：`slides/06-definition.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Glossary · Core Concept` | `div.kb-kicker` |
| `title` | `什么是 <span class="rust">反馈回路</span>` | `h1.kb-h1` |
| `term-label` | `TERM` | `div.kb-kicker`(gray) |
| `term` | `Feedback<br>Loop` | 术语词 `div`(inline serif 118px ink) |
| `definition-title` | `让错误回流，让笔记自愈` | `h4`(rust) |
| `definition-body` | `AI 每次使用知识库时记录 hit / miss / wrong...` | `p` |
| `def1-title` / `def1-body` | `观测` / `每次检索自动记录结果与偏差` | `.point`(×3) |
| `def2-title` / `def2-body` | `聚合` / `夜间把 miss/wrong 聚成 diff-patch` | `.point`(×3) |
| `def3-title` / `def3-body` | `回写` / `人工 review 后合并进 vault 与 git` | `.point`(×3) |
| `tag1` / `tag2` / `tag3` | `self-correcting` / `audit trail` / `nightly batch` | pill 标签(inline) |
| `footer-left` | `Content · Definition` | `span` (left) |
| `page-num` | `06 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, `kb-grid-2` 两列结构, 左列术语词(serif 118px)与右列 `kb-card`, `div.kb-footer`. `tag1` 为 hero 标签(rust 边)，`tag2/3` 为普通(ink 边).
- **内容适配规则**：左列 `term` 为被定义术语（1-2 词，可用 `<br>` 换行）；右列 `definition-body` 为一句话定义；3 条 `.point` 为"拆解/构成"步骤（编号 01/02/03 固定）. 标签 1-3 个.
- **扩展/收缩**：`.point` 固定 3 条. 标签可 1-4 个. 左右两列不可互换（术语在左、定义在右）.

### 07 — `feature-grid`

- **源文件**：`slides/07-feature-grid.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Capabilities · Six Pillars` | `div.kb-kicker` |
| `title` | `系统的 <span class="rust">六个</span> 核心能力` | `h1.kb-h1` |
| `feat1-icon` … `feat6-icon` | (整段 inline `<svg>`, `fill="var(--kb-rust)"`) | 每卡顶部图标 |
| `feat1-title` … `feat6-title` | `结构化存储` / `Agent 可用` / ... | `h4` |
| `feat1-body` … `feat6-body` | `双链笔记 + 实体/关系，全在一个 vault。` / ... | `p` |
| `footer-left` | `Content · Feature Grid` | `span` (left) |
| `page-num` | `07 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 3×2 inline grid(`repeat(3,1fr)`), 6 个 `kb-card`, `div.kb-footer`. 图标为 inline SVG（**非 icon 字体**，`fill=var(--kb-rust)`），来源 `templates/assets/icons/*.svg` 的裸 path.
- **内容适配规则**：6 格固定(3 列 × 2 行). 每格：图标 + 标题(2-4 字) + 一行说明(< 20 字). 图标 path 可换，但必须 inline 且 fill 用 `var(--kb-rust)`.
- **扩展/收缩**：固定 6 格，不可减为 4 或 3（会破坏 3×2 网格）. 网格列数固定 3，不可改 4.

### 08 — `timeline`

- **源文件**：`slides/08-timeline.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Evolution · v1 → v2` | `div.kb-kicker` |
| `title` | `从 <span class="rust">乱贴笔记</span> 到自愈回路` | `h1.kb-h1` |
| `tl1-date` … `tl5-date` | `2023 · V1` / `2024 · V1.5` / `2025 · V2` / ... | 日期(uppercase) |
| `tl1-title` … `tl5-title` | `原始笔记` / `双链 Wiki` / `接入 Agent` / ... | 节点标题(38px ink) |
| `tl1-body` … `tl5-body` | `Markdown 散落，靠记忆找。` / ... | 节点说明(gray) |
| `footer-left` | `Content · Timeline` | `span` (left) |
| `page-num` | `08 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 横向 ink 主线(`border-top`/`background:#1a1a1a`), 5 节点等分 flex, `div.kb-footer`. **中间节点(第 3 个)固定为 rust 高亮**(实心 rust 圆 + rust 日期/标题)——不可移动到其他位置.
- **内容适配规则**：5 节点等分横向轴，每节点：日期(上) + 标题 + 圆点 + 说明(下). 中间节点为"当前/核心"里程碑，用 rust 突出. 其余节点为普通(ink 描边圆点). 末节点(第 5)为"未来/下一步"用空心圆.
- **扩展/收缩**：固定 5 节点. 如需 3-4 节点，保留中点 rust 高亮位置（居中）.

### 09 — `table`

- **源文件**：`slides/09-table.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Decision · Three Options` | `div.kb-kicker` |
| `title` | `三种 <span class="rust">知识库</span> 方案对比` | `h1.kb-h1` |
| `table` | (整段 `<table>` inner HTML，含 thead/tbody，硬边 + rust-soft 表头 + 推荐列 rust 高亮) | `kb-card` 内 `<table>` |
| `footer-left` | `Content · Comparison Table` | `span` (left) |
| `page-num` | `09 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, `kb-card` 外框(包裹整表), `border-collapse:collapse` + 硬边(`2px/1.5px solid #1a1a1a`), 表头 `background:var(--kb-rust-soft)`, `div.kb-footer`.
- **内容适配规则**：`table` 替换整个 `<table>` 内容. 表头行 uppercase kicker 风；数字单元格右对齐 `tabular-nums`；**推荐列**整列用 rust 文字 + `rgba(181,57,42,.05)` 软底 + rust 边突出（hero 列思想）. 行数 ≤ 7.
- **扩展/收缩**：表格行列数自由（行 ≤ 7）. 必须保持"一个推荐列用 rust 高亮". 无圆角（cells 锐角）.

### 10 — `diagram`

- **源文件**：`slides/10-diagram.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `System Diagram` | `div.kb-kicker` |
| `title` | `反馈回路全貌` | `h1.kb-h1` |
| `footer-left` | `Diagram · Feedback Loop` | `span` (left) |
| `page-num` | `10 / 16` | `span` (right) |

- **不可改动(全部 SVG)**：`<svg>` 及其全部子元素——`<defs>`, `<marker>`, `<rect>`, `<text>`, `<line>`, `<path>`, `<g>` 及其属性. 这是结构性蓝图图，不可替换内容.
- **内容适配规则**：SVG 内文本为蓝图固定标注. 如需不同架构图，替换整个 SVG 元素(保持相同 viewBox `0 0 1200 520`). 新 SVG 必须保持：实线箭头(marker `#arrow`)、虚线反馈路径(marker `#arrow-r` 或等价样式)、核心节点用 rust 填充.
- **扩展/收缩**：SVG 不可删减，只能整体替换. 替换时 viewBox 可调整但 max-width 保持 1597px.

### 11 — `illustration`

- **源文件**：`slides/11-illustration.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Structure · The Vault` | `div.kb-kicker` |
| `title` | `vault 不是文件夹，<br>是 <span class="rust">四层堆栈</span>` | `h1.kb-h1` |
| `subtitle` | `每一层职责单一、向下单向流动；...` | `p.kb-sub` |
| `figure-svg` | (整段 blueprint 线稿 SVG：分层堆栈 + rust 核心层 + 虚线反馈回路 + `#arrow-r` marker) | 左列 `<svg>`(viewBox `0 0 600 560`) |
| `caption` | `FIG 01 · Vault 结构：四层堆栈，一条回路` | 图注 `div`(uppercase gray) |
| `point1-title`/`-body` … `point3-title`/`-body` | `单向下沉`/`采集→去噪→Wiki化→使用...` | `.point`(×3) |
| `footer-left` | `Content · Illustration` | `span` (left) |
| `page-num` | `11 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 左右双列 inline grid, 左列 SVG 容器 + 图注, `div.kb-footer`. SVG 必须含 rust 虚线反馈回路(`stroke-dasharray="6 6"` + `#arrow-r` marker，沿用 §装饰模式继承).
- **内容适配规则**：`figure-svg` 整体替换左列线稿，保持 blueprint 线稿风（ink 描边 + 一个 rust 核心层 + 虚线回路）. 右列 3 条 `.point` 为线稿要点解读. 图示需配 `caption`（FIG 编号 + 一句话）.
- **扩展/收缩**：左右双列不可互换. `.point` 固定 3 条. SVG 可整体替换但须保留反馈回路元素.

### 12 — `code`

- **源文件**：`slides/12-code.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Implementation · Skill Manifest` | `div.kb-kicker` |
| `title` | `反馈回路 <span class="rust">怎么实现</span>` | `h1.kb-h1` |
| `subtitle` | `一个 100 行的 Agent Skill，把「AI 用得顺不顺」回写成 vault 的一条条修订记录。` | `p.kb-sub` |
| `codeblock` | (全部代码内容，带 `<span class="cm/kw/st/hl">` 语法高亮) | `pre.kb-codebox` |
| `footer-left` | `Content · Code` | `span` (left) |
| `page-num` | `12 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, `pre.kb-codebox`(容器元素), `div.kb-footer`. 代码块内 `<span>` 的 class 名(`.cm`, `.kw`, `.st`, `.hl`)为语法高亮标记，应保留.
- **内容适配规则**：`codeblock` 替换整个 `<pre>` 内部 HTML. 新代码应使用相同的高亮 span class：`.cm`=注释, `.kw`=关键字, `.st`=字符串/值, `.hl`=高亮. 行数控制在 10-25 行.
- **扩展/收缩**：代码块高度自然流动. 过长时依赖 kb-codebox 的 overflow-y. 此角色不包含 `<style>` 块.

### 13 — `stats`

- **源文件**：`slides/13-stats.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `After 6 Months` | `div.kb-kicker` |
| `title` | `升级版 <span class="rust">跑了半年</span> 的数据` | `h1.kb-h1` |
| `big-num` | `13` | `div.kb-big-num` |
| `big-num-desc` | `关键优化项 · 全部落地` | `p` |
| `stat1-value` | `-62%` | `h4`(color:var(--kb-rust)) |
| `stat1-desc` | `幻觉率（相比无反馈回路版本）` | `p` |
| `stat2-value` | `+4.1×` | `h4`(color:var(--kb-rust)) |
| `stat2-desc` | `单次检索命中率` | `p` |
| `stat3-title` | `自动修订 227 条` | `h4` |
| `stat3-body` | `其中 189 条被人工批准合并，38 条被拒绝（数据已归档）。` | `p` |
| `stat4-title` | `新增笔记 412 篇` | `h4` |
| `stat4-body` | `从 miss 日志聚类而来，每篇都有来源追溯。` | `p` |
| `footer-left` | `Content · Stats` | `span` (left) |
| `page-num` | `13 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 3列布局容器(`display:grid;grid-template-columns:1.3fr 1fr 1fr`), `div.kb-big-num`(大数字容器), `div.kb-card`(4 个卡片), `div.kb-grid-2`(底部2列容器), `div.kb-footer`.
- **内容适配规则**：`big-num` 必须是单个数字(≤3 位). `stat1-value` / `stat2-value` 必须带符号/单位(-62%, +4.1×). 底部 `stat3`/`stat4` 为长文本卡片——标题一行 + 正文 1-2 行. `stat1` 卡片始终在右列(相比组).
- **扩展/收缩**：顶部指标固定为 3 列(big-num + stat1 + stat2). 底部 detail 卡片固定为 2 卡片. 如需更多 stat 卡片，在底部 kb-grid-2 中增加.

> **间距注记**：`big-num-desc` 的 `margin-top` 为 **38px**（非旧文档的 6.5px）。`kb-big-num` 为 266px / `line-height:.9`，字形墨迹下沿会溢出 line-box 约 20px；6.5px 间距会导致数字与下方文案重叠，38px 留出干净可视间距。这是第 6 页（现 13 页）已修复并验证的值。

### 14 — `faq`

- **源文件**：`slides/14-faq.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `FAQ · Common Concerns` | `div.kb-kicker` |
| `title` | `你大概会 <span class="rust">问</span> 这几个` | `h1.kb-h1` |
| `faq1-qmark` / `faq1-amark` | `Q` / `A` | serif 大字母(inline；Q=rust 54px, A=gray 40px) |
| `faq1-q` | `AI 乱改我的笔记怎么办？` | `h4` |
| `faq1-a` | `所有修订都以 git PR 形式提交...` | `p` |
| `faq2-qmark` / `faq2-amark` / `faq2-q` / `faq2-a` | `Q` / `A` / `已有的几千篇笔记要重写吗？` / `不用。...` | 同上 |
| `faq3-qmark` / `faq3-amark` / `faq3-q` / `faq3-a` | `Q` / `A` / `和向量数据库 RAG 有什么不同？` / `RAG 是"只读检索"...` | 同上 |
| `footer-left` | `Content · FAQ` | `span` (left) |
| `page-num` | `14 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 3 个 `kb-card` 垂直 stack(gap 22px), 每卡左侧 `Q`/`A` serif 大字母列(rust Q / gray A), `div.kb-footer`.
- **内容适配规则**：每对 Q&A：`q` 为一句疑问(h4 粗 ink)，`a` 为 1-3 句解答(p gray). `Q` 字母固定 rust 色，`A` 字母固定 gray 色. 问答围绕用户的常见顾虑/误解.
- **扩展/收缩**：默认 3 对. 可增减为 2-4 对（增减时同步增减 `faqN-*` 键与卡片）；超过 4 对会超出画布，需精简文案.

### 15 — `cta`

- **源文件**：`slides/15-cta.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `Next Step` | `div.kb-kicker` |
| `title` | `开始你的 <span class="rust">Wiki v2</span>` | `h1.kb-h1` |
| `subtitle` | `不用重写所有笔记。先接一条回路，让 AI 的每次使用都在「改好」你的 vault。` | `p.kb-sub` |
| `step1-num` | `TONIGHT` | `div.kb-step-num` |
| `step1-title` | `装 Skill` | `div.kb-step-title` |
| `step1-body` | `pnpm i -g @lewis/wiki-feedback` | `div.kb-step-body` |
| `step2-num` | `DAY 2` | `div.kb-step-num` |
| `step2-title` | `跑 7 天` | `div.kb-step-title` |
| `step2-body` | `观察 miss log 自动累积` | `div.kb-step-body` |
| `step3-num` | `DAY 8 · CORE` | `div.kb-step-num` |
| `step3-title` | `第一次审 PR` | `div.kb-step-title` |
| `step3-body` | `花 15 分钟 review 自动生成的修订` | `div.kb-step-body` |
| `step4-num` | `MONTH 1` | `div.kb-step-num` |
| `step4-title` | `开始信它` | `div.kb-step-title` |
| `step4-body` | `你的 vault 会变成活的` | `div.kb-step-body` |
| `footer-left` | `CTA` | `span` (left) |
| `page-num` | `15 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, `div.kb-pipeline`, `div.kb-step` / `.hero`, `div.kb-footer`. step3 始终为 hero 步骤.
- **内容适配规则**：pipeline 步骤描述用户从"今夜"到"第1个月"的渐进式行动路径. step1 为立即行动(今晚/现在), step2-3 为渐进, step4 为最终成果. `step*-num` 应为时间标记(TONIGHT/DAY2/WEEK1/...), `step*-body` 可为命令/观察结果.
- **扩展/收缩**：pipeline 保持 4 步，step3 始终 `.hero`. 如果行动路径少于 4 步，填充 placeholder 步骤.

### 16 — `thanks`

- **源文件**：`slides/16-thanks.html`
- **可替换键**：

| 键 | 原值示例 | 元素 |
|----|---------|------|
| `kicker` | `END · blueprint v2` | `div.kb-kicker` |
| `title` | `谢谢 <span class="rust">·</span> thanks` | `h1.kb-h1` |
| `subtitle` | `图纸、Skill、笔记模板都在 <b>github.com/lewis/karpathy-wiki-v2</b>` | `p.kb-sub` |
| `footer-left` | `End of deck` | `span` (left) |
| `page-num` | `16 / 16` | `span` (right) |

- **不可改动**：`div.kb-grid-bg`, 居中容器(`style="margin:auto 0;text-align:center"`), `h1` 字号(186px), `p.kb-sub` 字号(29px)和居中, `div.kb-footer`.
- **内容适配规则**：标题必须同时包含中文和英文(用 `<span class="rust">·</span>` 分隔). subtitle 必须包含一个链接/GitHub 地址/联系方式(用 `<b>` 标记). 不可在此角色添加卡片或管道.
- **扩展/收缩**：纯排版角色——仅允许标题+副标题+kicker.

---

## 角色匹配决策树

```
用户文稿需求
│
├── 需要封面？                                → cover
├── 需要放一句金句 / 证言 / 名人引言？           → quote
├── 需要一句强有力的结论/宣言（无副标题）？       → big-statement
├── 需要在章节间做视觉断点+大字章标题？         → section-divider
├── 需要对比两个方案/概念/版本的优劣？           → comparison
├── 需要定义/解释一个术语或核心概念？            → definition
├── 需要并列展示多个特性/能力（带图标）？         → feature-grid
├── 需要展示时间线/演进/里程碑？                → timeline
├── 需要多列方案的逐维对比表？                  → table
├── 需要展示架构图/流程图/系统拓扑？             → diagram
├── 需要插图+说明（图解一个结构/场景）？          → illustration
├── 需要展示代码/配置/Script 片段？             → code
├── 需要展示数据指标/统计结果/前后对比数字？      → stats
├── 需要解答常见问题/顾虑（Q&A）？              → faq
├── 需要号召行动/给出渐进式 onboarding 路径？     → cta
└── 需要结束页/致谢/联系方式？                   → thanks
```

**组合规则**：
- 一个完整 deck 最小集：`cover` → (任选 1-3 个内容角色) → `thanks`
- 多章节 deck：`cover` → `section-divider` → (内容角色) → `section-divider` → (内容角色) → ... → `thanks`
- `cover` 和 `cta` 共享 `kb-pipeline` 组件——如果 deck 以 `cover` 开头 `cta` 结尾，两端管道形成首尾呼应
- 开篇节奏：`cover` → `quote`(钩子) → `big-statement`(论点) → 进入正文，是本模板推荐的强开篇组合
- `diagram` 角色不可连续使用超过 1 页(连续图表需交替 `comparison` / `illustration` / `stats` 缓冲)
- `code` 和 `diagram` 为互补角色——`diagram` 给全局视图，`code` 给实现细节
- `comparison`(2 卡) 与 `table`(多列表格) 都做对比：二选一用 `comparison`，三选及以上用 `table`

---

## Style Transfer — T2 页面继承规则

### 空间密度对齐

| 属性 | 基准值 | 容差 |
|------|--------|------|
| 蓝图网格 | 48px × 48px (`kb-grid-bg`) | 固定不可变 |
| 卡片间距 | 32px (`gap` in `kb-grid-2` and stat grid) | ±8px |
| 管道步骤间距 | 由 `kb-pipeline` flex 自然流动 | 保持 |
| 页面内边距 | 由 `kb-grid-bg` + 布局 margin 隐式定义 | 保持 |
| `kb-card` padding | 继承自 `shared/tokens.css` | 不可覆盖 |
| 大数字与其他元素间距 | `margin-top: 38px`(big-num-desc) | ±4px（见 stats 角色注记：266px/line-height .9 字形溢出 line-box ~20px，6.5px 会重叠） |

### 装饰模式继承

| 元素 | 规则 | 备注 |
|------|------|------|
| `kb-grid-bg` | **必须**在每个 T2 slide 的 body 内作为第一个子元素 | 蓝图网格是此模板的视觉签名，不可省略 |
| `kb-card` | 统一 2px 硬边框(`stroke:#1a1a1a`), 无阴影无渐变 | T2 卡片**禁止**添加 `box-shadow`, `background-image:linear-gradient` |
| hero 卡片 | 背景 `var(--kb-rust-soft)`, 边框 `var(--kb-rust)`, 始终为右侧/居中位置 | 不可把 hero 样式移到左侧卡片 |
| rust accent | `#B5392A` — 仅通过 `<span class="rust">` 或 `color:var(--kb-rust)` 使用 | T2 **禁止**将 rust 色用作大面积背景 |
| pipeline step hero | class `.hero` 保持 step3 位置 | 不可将 hero 移到 step1 或 step4 |
| SVG markers | `#arrow`(#1a1a1a), `#arrow-r`(#B5392A) | 替换 SVG 时必须保留 marker 定义 |
| 反馈回路路径 | `stroke-dasharray="6 6"` 虚线, rust 色 | 新 SVG 中的反馈线必须用虚线+rust |

### 组件类名统一

所有 T2 slide **必须使用**以下 kb- 前缀 class 名，不可自创类名：

> **v2 新增板式（02 quote / 03 big-statement / 06 definition / 07 feature-grid / 08 timeline / 09 table / 11 illustration / 14 faq）一律复用现有 kb-\* class + inline style，不新建 class。** 下表「出现于」列已纳入新角色。

| Class | 用途 | 出现于 |
|-------|------|--------|
| `kb-grid-bg` | 蓝图网格背景层 | 全部 16 个角色 |
| `kb-kicker` | 小标签/眉题 | 全部内容角色（quote/big-statement/section-divider/comparison/definition/feature-grid/timeline/table/diagram/illustration/code/stats/faq/cta/thanks/cover） |
| `kb-h1` | 主标题 | 除 quote 外全部（quote 用 blockquote 替代） |
| `kb-sub` | 副标题 | cover, section-divider, illustration, code, cta, thanks |
| `kb-insight` | 洞察框 | cover |
| `kb-section-label` | 区域标签 | cover |
| `kb-pipeline` | 管道容器 | cover, cta |
| `kb-step` | 管道步骤(含 `.hero`) | cover, cta |
| `kb-step-num` | 步骤编号 | cover, cta |
| `kb-step-title` | 步骤标题 | cover, cta |
| `kb-step-body` | 步骤描述 | cover, cta |
| `kb-grid-2` | 双列网格 | comparison, definition, stats |
| `kb-card` | 硬边卡片 | comparison, definition, feature-grid, table(包裹), faq, stats |
| `kb-legend` | 图例栏 | comparison |
| `kb-codebox` | 代码块 | code |
| `kb-big-num` | 大数字 | stats |
| `kb-footer` | 页脚 | 全部 |

### 排版层级对齐

| 层级 | 元素 | 字号/样式 | 出现于 |
|------|------|-----------|--------|
| 封面标题 | `h1.kb-h1` | 默认(token控制) | cover |
| 章节标题 | `h1.kb-h1` | 160px | section-divider |
| 致谢标题 | `h1.kb-h1` | 186px | thanks |
| 宣言句 | `h1.kb-h1` | 104px(刻意例外) | big-statement |
| 引用句 | `blockquote`(inline serif) | 50px italic | quote |
| 术语词 | 术语 `div`(inline serif) | 118px | definition |
| 节点标题 | inline `div` | 38px | timeline |
| 内容标题 | `h1.kb-h1` | 59-78px(按角色) | comparison, definition, feature-grid, timeline, table, diagram, illustration, code, stats, faq, cta |
| 卡片标题 | `h4` | token 控制 | comparison, definition, feature-grid, faq, stats |
| kicker | `div.kb-kicker` | token 控制 | 全部内容角色 |
| subtitle | `p.kb-sub` | token 控制 / 19-32px(按角色) | cover, section-divider, illustration, code, cta, thanks |
| 代码 | `pre.kb-codebox` | token 控制(mono) | code |
| 大数字 | `div.kb-big-num` | token 控制 | stats |
| 页脚 | `div.kb-footer` | token 控制 | 全部 |

**关键排版约束**：
- T2 不可改 `h1` 字号——如需调整，仅可通过 token CSS 变量（例外：`big-statement` 104px 为该角色固定值）
- `kb-kicker` 始终使用 `text-transform: uppercase; letter-spacing: 0.1em`
- 中文标题中的 `<span class="rust">` 关键词高亮仅影响颜色，不影响字号或粗细
- 代码块使用等宽字体(由 token `--font-mono` 控制)，不可切换为衬线/无衬线

### 禁止引入的视觉元素

以下视觉元素在 T2 的 **任何** slide 中**禁止出现**——这些会破坏 knowledge-arch-blueprint 模板的"工程蓝图"气质：

| 禁止元素 | 原因 |
|----------|------|
| `box-shadow`(任何形式) | 与 2px 硬边卡片冲突 |
| `background-image: linear-gradient()` | 硬边蓝图风格不允许渐变 |
| `background-image: radial-gradient()` | 同上 |
| `border-radius` 滥用 | 标准 `kb-card`(16px)/`kb-step`/`kb-insight`/pill 标签(999px) 为既定组件，沿用即可；**禁止**新增超过这些既定值的圆角，或给表格/网格单元加圆角（表格 cells 保持锐角） |
| `backdrop-filter: blur()` | 毛玻璃效果不属于蓝图风格 |
| `filter: drop-shadow()` | 不允许阴影 |
| 软过渡色/马卡龙色系 | 调色板限于 warm paper(`#FAF8F5`), ink(`#1a1a1a`), rust(`#B5392A`), rust-soft(`#F0EAE0`), gray(`#888`, `#666`) |
| emoji/icons 图标字体 | 蓝图风格使用纯文字标注，不依赖 icon font |
| 大面积纯色背景(非 grid) | 蓝图网格必须始终可见 |
| 动画/transition | 中档动效：.anim-fade / .anim-fade-up-soft / .anim-dN（kicker fade / 标题 fade-up-soft / 列表 stagger），不用 rise/zoom/blur，保持蓝图精确感 |
| 照片/位图背景 | SVG 和蓝图网格是此模板唯一允许的图形元素 |
