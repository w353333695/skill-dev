# insight-report — 行业/数据研究报告 Deck

> **体裁**：研究报告（行业洞察、市场/数据研究、趋势白皮书、年度行业复盘）
> **受众**：决策者 / 行业读者
> **调性**：克制可打印、结论先行（BLUF）、图表为主、扫描可读
> **默认配色**：`ocean-depths`（深海蓝 `#0a2540` + 数据蓝 `#1d4ed8` + slate + amber 强调，白底省墨可打印）
> **页数**：14 页

## 叙事骨架（BLUF 结论先行，非 SCQA）

执行摘要(一句话结论) → 背景 → 方法论 → 发现①②③ → 数据深挖 → 对比 → 影响 → 建议 → 下一步 → 附录

```
01 cover              研究报告封面（标题+副标题+机构+报告编号+日期）
02 toc                目录（BLUF 章节脊柱）
03 executive-summary  执行摘要 BLUF（一句话结论 + 支撑要点 + 关键数字）★
04 background         背景（行业现状/研究缘起）
05 methodology        方法论（研究方法网格：数据源/样本/分析方法）★
06 finding-1          发现①（编号发现卡 + 证据 + 启示）
07 finding-2          发现②
08 finding-3          发现③
09 data-deepdive      数据深挖（关键图表 + Fig.编号 + 来源标注）
10 comparison         厂商/方案对比
11 impact             趋势与影响
12 recommendations    建议
13 next-steps         局限与展望
14 appendix           附录（方法论细节/数据来源/术语表）+ 封底 ★
```

★ = 特色/身份证角色页（区别于 consultant-strategy 的核心标志）

## 关键组件（`ir-*` + BLUF 组件）

- `.exec-summary` — BLUF 执行摘要框（一句话结论 + 支撑要点 + 关键数字）
- `.finding-card` — 编号发现卡（发现①②③ + 证据 + 启示）
- `.ir-method-grid` / `.ir-method-item` — 研究方法网格（透明化研究过程）
- `.research-chart` — 图表容器（带 Fig. 编号 + 坐标轴 + 来源标注）
- `.appendix-block` — 附录块（方法论细节/数据来源/术语表，小字可打印）
- `.ir-keynums` — 关键数字墙
- `.ir-colophon` — 报告版权页（作者团队/联系方式/免责声明/版本号）

## 配色

默认 `ocean-depths`（深海蓝墨色，白底可打印）。已接入 `switch-theme.mjs`：

```bash
node scripts/switch-theme.mjs --deck templates/starter-decks/insight-report --scheme consulting-navy  # 深蓝投行
node scripts/switch-theme.mjs --deck templates/starter-decks/insight-report --scheme mckinsey-blue    # 麦肯锡蓝
```

配套方案见 `scripts/color-schemes.json`。

## 用法

复制本目录到产出目录后修改 `slides/*.html` 中的 `data-replace="key"` 内容。示例填充为「2026 中国新能源汽车市场洞察报告」（典型行业研究报告，替换键示意最清晰）。

```bash
open index.html                                                                      # 预览
node scripts/preview_slides.mjs --slides slides --out /tmp/preview                   # 截图
node scripts/export_single.mjs --deck . --out ../insight-report.html                 # 单文件 HTML
node scripts/export_pptx.mjs --slides slides --out ../insight-report.pptx --mode editable  # PPTX
```

## 区分度（反换皮）

- **≠ consultant-strategy**：consultant 是咨询诊断（SCQA→方案择优→90 天行动），insight-report 是研究报告（BLUF+方法论+发现+附录），有方法论页和可打印附录。
- **≠ xhs-white-editorial**：那偏轻量图文，insight-report 是严肃可打印研究报告。
- **标志身份证**：BLUF 执行摘要框 + 方法论网格 + 编号发现卡 + 可打印附录——四者共同构成研究报告版式身份证。

## 设计依据

按 `docs/template-system-requirements.md` §3（insight-report 提案）+ `docs/deck-differentiation-spec.md`（反换皮铁律）构建，布局从 `references/layout-catalog.md` 选取按体裁拼装。详见 `docs/horizontal-decks-build-prompts.md`。
