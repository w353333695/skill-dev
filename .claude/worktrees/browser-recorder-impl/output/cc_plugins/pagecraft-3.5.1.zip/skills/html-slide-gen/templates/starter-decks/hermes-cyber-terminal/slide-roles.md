# hermes-cyber-terminal -- Slide Role Catalog

> **模板气质**：CRT scanlines, cyber grid, terminal window chrome, mint green glow
> **默认 color-scheme**：bg `#0a0c10`, accent `#7ed3a4` (mint), surface `#12141a`, amber `#e9c58a`, cyan `#64dfdf`
> **适用文稿类型**：tech product review, tool benchmark, deep-dive evaluation, developer-facing deck
> **叙事结构**：cover -> section-divider -> content-cards -> code-trace -> chart-comparison -> stats-verdict -> timeline -> comparison-table -> architecture -> image-feature -> quote -> faq -> cta-steps -> thanks
>
> **结构特征**：
> - 每页顶部有终端 chrome（三色圆点 + 标题栏），类 macOS 窗口装饰
> - `hc-grid` 层：75px 网格线 + radial-gradient mask（中心亮、边缘暗）
> - `hc-scanlines` 层：repeating-linear-gradient 扫描线（4px 间距）
> - `hc-vignette` 层（仅 cover）：径向渐变暗角
> - 底部 `hc-footer`：左侧元信息 + 右侧页码，顶部分割线
> - 字体栈：JetBrains Mono 为主显示字体，Inter/Noto Sans SC 为正文 fallback
> - 装饰性文字（prompt、code 注释、chrome title）不承载叙事信息，仅为氛围元素

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 封面 -- 标题、副标题、标签云 | hc-h1, hc-lede, hc-tag x4, hc-cursor |
| 02 | `section-divider` | 章节分隔 -- 大号章节标题 + 一句摘要 | hc-h1 (146px), hc-lede, inline code |
| 03 | `content-cards` | 卡片网格 -- 3列数据卡片 + 2列 verdict 卡片 | hc-grid-3 (3 cards), hc-grid-2 (2 cards), hc-h2 |
| 04 | `code-trace` | 终端 trace -- 命令提示符 + 代码块 | hc-prompt, hc-codebox, hc-h3 |
| 05 | `chart-comparison` | 对比柱状图 -- h2 + lede + SVG bar chart | hc-h2, hc-lede, SVG (4+3 bars + legend) |
| 06 | `stats-verdict` | 评分总评 -- 超大数字 + 一句话 + 优缺点双栏 | hc-big, hc-prompt, hc-grid-2 (pros/cons) |
| 07 | `timeline` | 横向时间线 -- 4 节点进程/版本演进 | hc-timeline, hc-tl-node, hc-h2 |
| 08 | `comparison-table` | 特性矩阵表 -- 多产品多指标对照 | hc-table, hc-h2 |
| 09 | `architecture` | 架构关系图 -- 分层节点 + 箭头连线 SVG | hc-h2, SVG node diagram |
| 10 | `image-feature` | 插图主视觉 -- 左截图 + 右要点列表 | hc-screenshot, hc-media-row, hc-points |
| 11 | `quote` | 大段引用/金句 -- 巨引号 + 左竖条 + 署名 | hc-quote |
| 12 | `faq` | 问答双列 -- 编号问 + 答案 | hc-qa, hc-q |
| 13 | `cta-steps` | CTA 行动指南 -- 三步命令 + 标签 | hc-h2, hc-lede, hc-codebox, hc-tag x3 |
| 14 | `thanks` | 结束页 -- 大号标题 + 链接 + hc-cursor | hc-h1 (160px), hc-prompt, hc-cursor |

## 角色详情

### 01 -- cover

**源文件**：`slides/01-cover.html`
**可替换键**：`chrome-title`, `prompt`, `title`, `subtitle`, `tag-1`, `tag-2`, `tag-3`, `tag-4`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-vignette`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `hc-cursor`, `hc-footer` 结构, body class
**内容适配规则**：
- `prompt`：终端风格的命令式短语，模拟 shell 输入，如 `whoami --<product>`，保留 `::before '$ '` 前缀
- `title`：产品名 + 版本号格式 `<NAME><br>TAGLINE / v<VER>`，支持两行
- `subtitle`：一句话概述 + 问题式钩子，2-3 行，中文用「」包裹关键词
- `tag-1` ~ `tag-4`：3-5 个关键词标签，默认样式为绿色边框，可用 `amber` / `red` class 切换颜色
- `footer-left`：`<project> · <author> · <year>` 格式
- `page-num`：`01 / 08` 格式，总页数以实际 deck 为准
**扩展/收缩**：tags 可增删至 2-5 个，超过 5 个建议换行

### 02 -- section-divider

**源文件**：`slides/02-section-divider.html`
**可替换键**：`chrome-title`, `prompt`, `section-title`, `subtitle`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `hc-h1` 的 font-size:146px, `hc-footer` 结构, body class
**内容适配规则**：
- `chrome-title`：`section · <N>/<total>` 格式
- `prompt`：终端命令风格，如 `cat chapter_<N>.md`
- `section-title`：`// <Title>` 格式，保持 `//` 前缀，简短有力，一个英文词或 2-4 个中文字
- `subtitle`：一行总结章节主题，可含 `<code>` 内联术语高亮（amber 色）
- `footer-left`：`section · <slug>` 格式
**扩展/收缩**：可复用为多个 section-divider（每个章节一张），改 chrome-title 和 prompt 中的序号即可

### 03 -- content-cards

**源文件**：`slides/03-content.html`
**可替换键**：`chrome-title`, `heading`, `subtitle`, `card-1-lbl/val/desc`, `card-2-lbl/val/desc`, `card-3-lbl/val/desc`, `verdict-plus-lbl/val/desc`, `verdict-minus-lbl/val/desc`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `hc-grid-3` / `hc-grid-2` 容器, `hc-card` 结构（lbl/val/desc 三层）, `::before` 渐变装饰线, body class
**内容适配规则**：
- `heading`：页面标题，12 字以内
- `subtitle`：数据说明或范围限定，一行
- 上排 3 卡 (`hc-grid-3`)：
  - `card-N-lbl`：指标名（英文 uppercase），5 字以内
  - `card-N-val`：数值（含单位），如 `42s`, `1.8s`, `4m22s`
  - `card-N-desc`：指标说明，一句中文
- 下排 2 卡 (`hc-grid-2`)：
  - `verdict-plus-lbl`：`// verdict +` 或改为其他标签
  - `verdict-plus-val`：正面结论，绿色 `color:var(--hc-green)`
  - `verdict-plus-desc`：支持性说明
  - `verdict-minus-lbl`：`// verdict -` 格式
  - `verdict-minus-val`：负面结论，红色 `color:var(--hc-red)`
  - `verdict-minus-desc`：具体问题描述
- 上排卡片数量固定为 3，不可增减
- 下排固定为 2（正反各一），可改为双正面或双负面
**扩展/收缩**：如需更多数据卡片，建议另开一页复用此角色；不支持在单页内增加超过 3 的卡片

### 04 -- code-trace

**源文件**：`slides/04-code.html`
**可替换键**：`chrome-title`, `prompt`, `heading`, `code-trace`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `hc-codebox` 容器样式, body class
**内容适配规则**：
- `prompt`：触发 trace 的命令，如 `hermes run "<task>"`
- `heading`：对 trace 的说明，如 `↓ 真实 trace (节选)`
- `code-trace`：整个 `<pre>` 块内容，模拟终端 trace 输出，使用 span class 标注语法高亮：
  - `.cm` 注释（灰色 `#5a6068`）
  - `.kw` 关键字（amber）
  - `.st` 字符串（绿色）
  - `.fn` 函数/工具名（cyan）
  - `.var` 变量/参数（rose）
  - `.hl` 高亮变更（白色 + 绿色半透明背景）
- 代码块总长度控制在 8-14 行，超出会溢出可视区域
**扩展/收缩**：codebox 内行数范围 6-16 行，超过建议拆分为两页

### 05 -- chart-comparison

**源文件**：`slides/05-chart.html`
**可替换键**：`chrome-title`, `heading`, `subtitle`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, **整个 SVG 元素及其所有子元素**, body class
**内容适配规则**：
- `heading`：图表标题，10 字以内
- `subtitle`：数据来源与方法说明
- SVG 柱状图**不可通过 data-replace 修改**，需要替换数据时整段替换 SVG
- SVG 结构说明（仅供整段替换参考）：
  - y 轴：百分比 0-100%，5 档
  - 两组柱（hermes 绿色 / openclaw 琥珀色），每组 4 个指标：resolved, one-shot, test-pass, pr-merged
  - 图例：右上角两个色块 + 标签
  - 字体：JetBrains Mono, monospace, 13px
  - 画布：1000x380 viewBox，渲染宽度 max-width 1450px，水平居中（`margin: auto`）
**扩展/收缩**：柱数固定为 4+3（不含 pr-merged 的第二组），不支持增减

### 06 -- stats-verdict

**源文件**：`slides/06-stats.html`
**可替换键**：`chrome-title`, `prompt`, `score`, `verdict-text`, `pros-lbl`, `pros-list`, `cons-lbl`, `cons-list`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `hc-big` 的数字样式（大号绿色 + glow text-shadow）, `hc-grid-2` 结构, body class
**内容适配规则**：
- `prompt`：终端风格总评命令，如 `echo $VERDICT`
- `score`：`<big number><span>/ 10</span>` 格式，大数字字体 186px JetBrains Mono，绿色 glow；scale 固定 `/ 10` 但可改文字
- `verdict-text`：一句话总结评分，中文 15 字以内
- `pros-lbl`：正面标签，如 `+ strong points`
- `pros-list`：bullet 列表，用 `<br>` 分隔，每项以 `•` 开头，建议 3-5 项
- `cons-lbl`：负面标签，如 `- weak points`
- `cons-list`：bullet 列表，格式同 pros，建议 3-5 项
**扩展/收缩**：pros/cons 各 2-6 条，超出可能溢出卡片

### 07 -- timeline

**源文件**：`slides/07-timeline.html`
**可替换键**：`chrome-title`, `heading`, `subtitle`, `timeline` (整个 `.hc-timeline` 容器), `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `.hc-timeline` 容器与 `::before` 横线, body class
**内容适配规则**：
- `heading`：时间线主题，如 `版本演进`、`项目里程碑`，10 字以内
- `subtitle`：一句话总括时间跨度或趋势
- `timeline`：由若干 `.hc-tl-node` 子元素组成，每个节点结构：
  - `<div class="dot"></div>`：节点圆点，加 `done` class 的父节点变琥珀色（已完成）
  - `.when`：时间/版本号，mono 字体 cyan 色，uppercase，如 `2026 · 03`
  - `.name`：节点名称，6 字以内
  - `.note`：一句话说明
  - 节点默认 4 个（对应 4 列网格），改列数需同步改 `.hc-timeline` 的 `grid-template-columns`
**扩展/收缩**：节点建议 3-5 个；超过 5 个换行后横线 `::before` 不会自动跟随，需拆页

### 08 -- comparison-table

**源文件**：`slides/08-comparison-table.html`
**可替换键**：`chrome-title`, `heading`, `subtitle`, `table` (整个 `.hc-table`), `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, body class
**内容适配规则**：
- `heading`：表格主题，如 `能力对照`，10 字以内
- `subtitle`：图例说明（绿=赢/琥珀=平/红=输），一行
- `table`：标准 `<table class="hc-table">`，结构：
  - `thead th`：列名，首列是 capability，后续列是产品/方案名
  - 给想高亮的列的 `<th>` 和 `<td>` 加 `col-hl` class（淡绿底）
  - `td .feat`：行名（左侧特性，sans 字体）
  - 单元格内用 `<span class="check">✓</span>`（绿）/ `<span class="cross">✗</span>`（红）/ `<span class="mid">~</span>`（琥珀）标注状态，可后跟短文字
  - 行数建议 4-7 行，列数 3-5 列
**扩展/收缩**：行列数自由增减，行过多会撑高；建议不超过 8 行

### 09 -- architecture

**源文件**：`slides/09-architecture.html`
**可替换键**：`chrome-title`, `heading`, `subtitle`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, **整个 SVG 元素及其所有子元素**, body class
**内容适配规则**：
- `heading`：架构主题，如 `内部结构`、`系统拓扑`，8 字以内
- `subtitle`：一句话概括分层逻辑
- SVG 架构图**不可通过 data-replace 修改**，需替换数据时整段替换 SVG
- SVG 结构说明（仅供整段替换参考）：
  - 自顶向下分层：input → core → (model | tools) → output
  - 节点用 `<rect>` + `<text>`，颜色按层分：cyan(io)、green(core/tools)、amber(model)、rose(output)
  - 连线用 `<line>` + `<marker id="hcArrow">` 箭头
  - 字体：JetBrains Mono, monospace，正文 14-20px
  - 画布：1000x460 viewBox，渲染宽度 max-width 1500px，水平居中
**扩展/收缩**：节点数固定，不支持增减；如需更复杂拓扑建议拆两页

### 10 -- image-feature

**源文件**：`slides/10-image-feature.html`
**可替换键**：`chrome-title`, `heading`, `subtitle`, `screenshot` (整个 `.hc-screenshot`), `points` (整个 `.hc-points`), `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `.hc-media-row` 网格结构, body class
**内容适配规则**：
- `heading`：图片主题，10 字以内
- `subtitle`：一句话图片看点
- `screenshot`：`.hc-screenshot` 容器，模拟终端窗口框：
  - `.bar`：窗口标题栏（三色圆点 + `.tt` 标题文字）
  - `.stage`：图片容器。放真实截图时把 `.placeholder` 替换为 `<img src="../assets/xxx.png" alt="...">`；`assets/` 放该 deck 的 `assets/` 目录，slide 用相对路径 `../assets/` 引用
  - 无图时保留 `.placeholder`（空心方块 + 提示文字），不破坏版式
- `points`：右侧要点 `.hc-points`，每项 `<li>` 结构：
  - `.k`：编号（mono 绿，如 `01`）
  - `.v .t`：要点标题，`.v .d`：一句说明
  - 建议 3-4 条
**扩展/收缩**：要点 2-4 条，每增一条加一条 `border-top` 分隔线

### 11 -- quote

**源文件**：`slides/11-quote.html`
**可替换键**：`chrome-title`, `quote` (整个 `.hc-quote`), `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `.hc-quote` 的 `::before`（引号）/`::after`（竖条）装饰, body class
**内容适配规则**：
- `quote`：`.hc-quote` 容器，结构：
  - `.text`：引文正文，sans 字体 52px，`<em>` 标记的关键词变绿色加粗
  - `.cite`：署名行，mono 字体；`.who` 子元素（作者名）变琥珀色
- 引文建议 2-4 行（版面竖直居中），中文每行约 20-26 字
- 适合放：用户原话、评测金句、争议性观点
**扩展/收缩**：无固定槽位；引文过长会自动换行但可能顶到 footer，控制在 120 字内

### 12 -- faq

**源文件**：`slides/12-faq.html`
**可替换键**：`chrome-title`, `heading`, `subtitle`, `qa` (整个 `.hc-qa`), `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `.hc-qa` 双列网格结构, body class
**内容适配规则**：
- `heading`：FAQ 标题，如 `你可能想问`，10 字以内
- `subtitle`：一句话定调（如「不绕弯子」「真实回答」）
- `qa`：`.hc-qa` 容器，含若干 `.hc-q` 卡片（2 列网格），每卡结构：
  - `.no`：编号，mono cyan，如 `Q01`
  - `.q`：问题，sans 24px 加粗
  - `.a`：答案，sans 17px；`<strong>` 标记的关键结论变绿色加粗
  - 建议 4 卡（2×2），可增减到 2-6 卡
**扩展/收缩**：卡片偶数对齐美观；超过 6 卡换行后双列仍成立但会顶到 footer

### 13 -- cta-steps

**源文件**：`slides/13-cta.html`
**可替换键**：`chrome-title`, `heading`, `subtitle`, `install-steps`, `tag-1`, `tag-2`, `tag-3`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `hc-codebox` 容器, body class
**内容适配规则**：
- `heading`：行动号召标题，问句或祈使句，如 `想自己跑一遍？`
- `subtitle`：CTA 的吸引力描述，一行
- `install-steps`：整个 `<pre>` 块内容，终端命令风格，每步用 `.cm` 注释标注，命令用 `.kw` 高亮 `$` 前缀，参数用 `.st` 包裹
  - 固定 3 步：install -> auth -> first task
  - 格式：`<span class="cm"># N. step-name</span>\n<span class="kw">$</span> command <span class="st">"arg"</span>`
- `tag-1` ~ `tag-3`：环境/依赖标签
**扩展/收缩**：步骤固定 3 步，不支持增减；tag 可增减至 2-5 个

### 14 -- thanks

**源文件**：`slides/14-thanks.html`
**可替换键**：`chrome-title`, `prompt`, `title`, `subtitle`, `footer-left`, `page-num`
**不可改动**：`hc-grid`, `hc-scanlines`, `hc-chrome` 结构和 dots span, `hc-cursor`, `hc-h1` 的 font-size:160px, body class
**内容适配规则**：
- `chrome-title`：终端会话结束提示，如 `EOF`、`exit`、`logout`
- `prompt`：退出命令，如 `exit 0`
- `title`：`// <word>` 格式，如 `// thanks`，保持 `//` 前缀
- `subtitle`：致谢、链接、联系方式，可含 `<span style="color:var(--hc-amber)">` 高亮关键链接
- `footer-left`：`session closed` 或类似结束标记
**扩展/收缩**：无

## 角色匹配决策树

```
deck type = tech review?
  -> 有 benchmark 数据?
    -> 需要对比图? -> 05-chart-comparison
    -> 需要能力矩阵? -> 08-comparison-table
    -> 需要评分?   -> 06-stats-verdict
  -> 有安装教程?    -> 13-cta-steps
  -> 有代码演示?    -> 04-code-trace
  -> 有截图/UI?     -> 10-image-feature
  -> 讲系统结构?    -> 09-architecture
  -> 讲演进/路线?   -> 07-timeline
  -> 引述用户/专家? -> 11-quote
  -> 集中答疑?      -> 12-faq

需要章节过渡?      -> 02-section-divider
需要数据展示?      -> 03-content-cards
封面/结束?         -> 01-cover / 14-thanks
```

## Style Transfer -- 目标页面继承规则

当在 hermes-cyber-terminal 模板内新建 slide（T2），或从其他模板迁移 slide 到此模板时，必须遵循以下继承规则。

### 空间密度对齐

- T2 页面 body padding：`80px 124px`（与 tokens.css 中 `body.tpl-hermes-cyber-terminal` 一致）
- 卡片内边距：`27px 35px`（`.hc-card`）
- 代码块内边距：`29px 39px`（`.hc-codebox`）
- 卡片间距：`hc-grid-3` gap 21px, `hc-grid-2` gap 27px
- 标题与正文间距：`hc-h1` margin `19px 0 16px`, `hc-h2` margin `0 0 13px`

### 装饰模式继承

T2 页面**必须**包含以下结构层（顺序固定）：
```html
<div class="hc-grid"></div>      <!-- 1. 网格背景 -->
<div class="hc-scanlines"></div>  <!-- 2. 扫描线（z-index:3） -->
<!-- 3. hc-vignette 仅 cover 页使用，其他页不加 -->
<div class="hc-chrome">...</div>  <!-- 4. 终端窗口 chrome -->
<!-- 5. 页面内容 -->
<div class="hc-footer">...</div>  <!-- 6. 底部状态栏 -->
```

### 组件类名统一

T2 页面只能使用以下 `hc-*` 前缀类名：
- 排版：`hc-prompt`, `hc-h1`, `hc-h2`, `hc-h3`, `hc-lede`
- 容器：`hc-card`, `hc-codebox`, `hc-grid-3`, `hc-grid-2`, `hc-big`
- 引用/插图/时间线/表格/问答：`hc-quote`, `hc-screenshot` + `hc-media-row` + `hc-points`, `hc-timeline` + `hc-tl-node`, `hc-table`, `hc-qa` + `hc-q`
- 标签：`hc-tag` (默认绿色) / `hc-tag.amber` / `hc-tag.red`
- 装饰：`hc-cursor`, `hc-chrome`, `hc-grid`, `hc-scanlines`, `hc-vignette`, `hc-footer`

禁止使用通用 `.card`, `.grid`, `.g2`, `.g3`, `.lede`, `.h1`, `.h2`, `.h3`（这些是 light theme 通用类，与本模板颜色体系不兼容）。

### 排版层级对齐

- **页面标题**：`hc-h2` (61px, weight 600) -- 内容页默认标题
- **卡片标签**：`hc-card .lbl` (13px, letter-spacing .22em, uppercase)
- **卡片数值**：`hc-card .val` (29px, weight 700, JetBrains Mono)
- **卡片说明**：`hc-card .desc` (18px, Inter)
- **正文引导**：`hc-lede` (25px, Inter/Noto Sans SC)
- **特大数字**：`hc-big` (186px, JetBrains Mono) -- 仅在 stats-verdict 使用
- **终端命令**：`hc-prompt` (继承 body font-size, `::before '$ '`)
- **代码块**：`hc-codebox` (19px, JetBrains Mono, line-height 1.85)

### 禁止引入的视觉元素
- 白色/浅色背景（任何 `#fff`, `#ffffff`, `white`）
- 彩色渐变（`var(--grad)`, `var(--grad-soft)`）
- 圆角卡片阴影（`var(--shadow)`, `var(--shadow-lg)`）
- 非 mono 字体的标题（hc-h1/hc-h2 必须用 JetBrains Mono）
- 蓝色系 accent（`#3b6cff`）-- 本模板 accent 为 mint `#7ed3a4`
- 任何不在 `hc-*` 命名空间下的自定义 CSS 类
