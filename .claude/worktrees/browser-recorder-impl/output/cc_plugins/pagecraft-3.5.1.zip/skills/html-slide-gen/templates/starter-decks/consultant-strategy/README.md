# consultant-strategy · 战略咨询

16-slide strategy-advisory deck: cover, agenda, executive summary (pyramid), SCQA diagnosis (situation/complication/question), chapter divider, 2×2 framework, options comparison, data deep dive, benchmark table, 3-wave roadmap, quarterly RAG review, risk-mitigation, 90-day next steps, thank-you.

Restrained consulting palette — McKinsey Blue (`#005587`) + Amber data accent (`#f5a623`) on white, hard-edge cards with no shadows, tight typography, conclusion-first (Pyramid Principle) and MECE-structured.

**Use when:** strategy advisory, board presentations, investment analysis, quarterly business review, M&A proposals, executive briefings.
**Feel:** McKinsey deck meets a clean board readout — data-driven, structured, every page is a takeaway.

---

## 配色

默认 `mckinsey-blue`（麦肯锡蓝 + Amber）。已接入 `switch-theme.mjs`，可一键切换：

```bash
node scripts/switch-theme.mjs --deck templates/starter-decks/consultant-strategy --scheme consulting-navy  # 深蓝投行风
node scripts/switch-theme.mjs --deck templates/starter-decks/consultant-strategy --scheme ocean-depths     # 深海蓝
```

配套方案见 `scripts/color-schemes.json`（40 个预设）。

## 结构

16 页叙事弧 = **SCQA + 金字塔原则 + 季度复盘扩展**：

| 段落 | 页 | 角色 |
|------|-----|------|
| 开篇 | 01-03 | cover · agenda · executive-summary（金字塔顶） |
| 诊断 (SCQA) | 04-06 | situation · complication · question（MECE 分解） |
| 章节切换 | 07 | chapter-divider |
| 方案 | 08-12 | framework（2×2 矩阵）· recommendation · data-deepdive · comparison-table · process-flow |
| 治理 | 13-15 | quarterly-review（RAG）· risks-mitigation · next-steps（90 天） |
| 收束 | 16 | thanks |

完整角色目录与替换键见 [`slide-roles.md`](slide-roles.md)。

## 用法

复制本目录到产出目录后修改 `slides/*.html` 中的 `data-replace="key"` 内容。示例填充为「某区域零售集团全渠道数字化转型战略」（通用咨询场景，不绑定行业，替换键示意最清晰）。

```bash
# 预览
open index.html
# 截图所有页
node scripts/preview_slides.mjs --slides slides --out /tmp/preview
# 导出单文件 HTML
node scripts/export_single.mjs --deck . --out ../consultant-strategy.html
# 导出 PPTX
node scripts/export_pptx.mjs --slides slides --out ../consultant-strategy.pptx --mode editable
```

## 设计依据

参考 pagecraft-2.0.0 `layouts/mckinsey/design_spec.md`（配色、字号体系、麦肯锡设计原则、装饰元素）经 HTML 多文件 iframe 架构重做。详见 `docs/starter-decks-expansion-plan.md`。
