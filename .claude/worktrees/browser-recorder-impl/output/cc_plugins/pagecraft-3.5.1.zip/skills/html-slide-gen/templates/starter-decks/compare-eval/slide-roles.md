# compare-eval — Slide Role Catalog

> **模板气质**：客观评测风（对比评测/选型体裁）—— 深色墨蓝底 + 中性主色 + amber 优胜标记、硬边评分矩阵、无阴影、克制打分（不偏袒）。每个维度独立 0–10 评分 + 权重，结论可复现。
> **默认 color-scheme**：`midnight-ink`（墨蓝 `#1e3a5f` + 亮蓝 `#2563eb`，深色 slate-900 底，amber `#f59e0b` 优胜标记）。
> **switch-theme**：已接入。`shared/tokens.css` §2 主 `:root` 的 14 个 `--brand-*` + `--border-strong` + `--grad-soft` + 7 个 `--brand-*-rgb` 为换肤入口；所有 `ce-*` 组件与语义 token 均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 一键切换。客观评测推荐中性深色系（`consulting-navy`/`nord-frost`），避免厂商品牌色偏袒观感。
> **适用文稿类型**：信息同步（评测）/ 决策支持（选型）—— vendor/tool selection, RFP scoring, build-vs-buy, "honest review"。
> **叙事结构（10 页，按出现顺序）**：cover → eval-scope → candidate-a → candidate-b → candidate-c → eval-matrix → dim-deepdive → pros-cons → verdict → recommendation。
>
> 01–02 为「开篇」（封面 + 评测方法论/加权模型）；03–05 为「参评方」（三参评方统一画像卡）；06–08 为「评测」（评分矩阵★ + 维度深挖 + 优劣双栏）；09–10 为「裁决」（加权裁决卡★ + 推荐结论与下一步选型）。其中 **06（eval-matrix）/ 09（verdict）为本 deck 标志角色页**（评测体裁身份证：评分矩阵 + 加权裁决卡，区别于 consultant 的纯文字对标表）。
>
> **布局节奏**：内容页 02–09 统一 `body.vcenter`（整块垂直居中，平衡上下留白）；书挡页 01（cover）/ 10（recommendation）用各自全屏自定义布局（左竖条 + 两栏 / 左竖条 + 居中三步）。
> **动效节奏**（按 `references/motion-system.md` §4–§5 配方，避免单一 fade）：kicker `anim-fade`→ title `anim-fade-up`→ 论据卡片 stagger；封面/收束 hero（h1 / verdict name / recommendation h1）`anim-blur-in`；裁决卡 + 下一步首步 hero `anim-rise-in`（落地时刻）；KPI / 适配分 / 加权分 `anim-scale-pop`（数字独立砸）；**候选画像双栏 `anim-slide-l`/`anim-slide-r`**（§5.7 对比配方，方向暗示两维度对照）；**评分矩阵按行 cascade**（thead→6 行逐行 `anim-fade`，tfoot 加权总分行 `anim-rise-in` 最后落地）；**维度深挖基准条 `anim-bar-grow` 晚于卡片**（§5.6 图表配方：卡片先落，bar 后长，对角 stagger d7→d11）。


---

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|----------|
| 01 | `cover` | 封面：评测报告式（评测对象 + 评测方 + 日期 + 评测范围） | `.bar-left`, `.kicker`(报告编号), `.h1`(含 `.gradient-text` accent 词), `.lede`, KPI 三栏, `.ce-cover-meta`, `.confidential` |
| 02 | `eval-scope` | 评测方法论：6 维度加权模型（维度卡 × 权重） + 评分标尺 + 数据来源 | `.ce-scope`, `.ce-dim-card`(`.ce-dim-num`/`name`/`desc`/`weight`), `.ce-rubric` |
| 03 | `candidate-a` | 参评方 A 画像：定位 + 架构 + 关键能力 + 适配度评分 | `.ce-cand-head`(`.ce-cand-logo`/`vendor`/tagrow), `.ce-cand-grid`, `.ce-cand-list`, `.ce-cand-fit` |
| 04 | `candidate-b` | 参评方 B 画像（同上结构） | 同 candidate-a |
| 05 | `candidate-c` | 参评方 C 画像（同上结构） | 同 candidate-a |
| 06 | `eval-matrix` | 评分矩阵★：6 维度 × 3 参评方评分单元格 + 权重列 + 加权总分行 + 图例 | `.ce-eval-matrix`(`.ce-row-dim`, `.ce-weight`, `.ce-score.high/mid/low`, `tfoot.ce-total`), `.ce-legend` |
| 07 | `dim-deepdive` | 维度深挖：选 1 关键维度（性能）展开 3 项基准对比（条形图） | `.ce-dd-head`(`.ce-dd-pick`), `.ce-dd-metrics`, `.ce-dd-metric`(`.ce-dd-bar-row.winner`) |
| 08 | `pros-cons` | 优劣对照：三参评方优缺点双栏（✓/✗） | `.ce-pc-grid`, `.ce-pc-col.hero`, `.ce-pc-pros`/`.ce-pc-cons`, `.ce-pc-list` |
| 09 | `verdict` | 加权裁决★：裁决卡（推荐方 + 综合分 + 一句话理由） + 加权计算明细表 | `.ce-verdict`, `.ce-verdict-hero`(`.ce-vd-name`/`score`/`reason`), `.ce-verdict-calc`(`.ce-vc-table` + bar) |
| 10 | `recommendation` | 推荐结论摘要 + 下一步选型建议（致谢式收束，非人员卡） | `.bar-left`, `.h1`(含 `.gradient-text`), `.ce-nextsteps`, `.ce-next-step.hero`, `.ce-cover-meta` |

---

## 角色详情

### 01 — `cover`
- **源文件**：`slides/01-cover.html`
- **可替换键**：`project_code`, `client_label`, `headline`, `headline_accent`, `subtitle`, `kpi_1~3_value/label`, `meta_subject`, `meta_evaluator`, `meta_date`, `meta_confidential`, `footer_source`
- **不可改动**：`.bar-left` 左侧 9px 蓝竖条、`.h1` 字号(80px)/字重(800)、`.ce-cover-meta` 底部绝对定位(left:90px;bottom:80px)、内联 SVG 评测意象（三列柱+天平）坐标
- **内容适配规则**：
  - `headline` 含一个 `<span class="gradient-text">` 渐变 accent 词(key: `headline_accent`)，替换时保留 span
  - KPI 三栏分隔（竖线），改指标数时同步调整 gap
  - `meta_confidential` 用 `.confidential` amber 大写

### 02 — `eval-scope`
- **可替换键**：`kicker`, `title`, `subtitle`, `dim1~6_num/name/desc/weight`, `source`, `footer_source`
- **不可改动**：`.ce-scope` 3 列网格(2 行)、`.ce-dim-weight` 用 amber mono、评分标尺 3 档色阶(绿/amber/红)
- **内容适配规则**：6 维度卡，权重之和必须 = 100%（评测可信度前提）；`source` 是数据来源溯源

### 03 — `candidate-a`
- **可替换键**：`kicker`, `title`, `cand_logo`, `cand_vendor`, `tag_1~4`, `arch_1~4`, `cap_1~4`, `fit_score`, `fit_max`, `fit_label`, `footer_source`
- **不可改动**：`.ce-cand-head` logo 72×72、`.ce-cand-grid` 1.2fr/1fr 双栏、`.ce-fit-num` 42px amber mono、`ce-cand-list` 方块 marker
- **内容适配规则**：架构/能力各 3~4 条；`fit_score` 与第 6 页矩阵加权总分口径一致（候选页用综合适配度，矩阵页用加权总分，二者数值相符）

### 04 — `candidate-b`
- 同 candidate-a 结构，替换键前缀同（`cand_*`/`tag_*`/`arch_*`/`cap_*`/`fit_*`）

### 05 — `candidate-c`
- 同 candidate-a 结构

### 06 — `eval-matrix`（标志页★）
- **可替换键**：`kicker`, `title`, `subtitle`, `col_a`/`col_b`/`col_c`, `r1~6_dim/w`, `tot_a`/`tot_b`/`tot_c`, `note`, `footer_source`
- **不可改动**：`.ce-eval-matrix` 硬边表、`.ce-weight` 列 amber mono、`.ce-score.high/mid/low` 色阶(绿≥9/amber 7-8.9/红<7)、`tfoot` 加权总分行、领先方列 `.col-hero` amber 高亮
- **内容适配规则**：
  - 每行评分单元格 = `0–10` 分 + 颜色档（high/mid/low 三选一），替换分数时同步迁移 class
  - `tfoot` 加权总分 = Σ(维度分 × 权重)，必须与各 `r*_w` 权重数学一致
  - 领先方变更时，把 `.col-hero` class 迁到对应列（thead th + tfoot td 都要迁移）
  - 维度行增删需同步第 2 页 `ce-dim-card`

### 07 — `dim-deepdive`
- **可替换键**：`kicker`, `title`, `subtitle`, `pick`, `metric` 内 `ce-dd-mlabel/munit`、每行 `ce-dd-name`/`bar-fill width`/`ce-dd-val`、`insight_1~2`, `footer_source`
- **不可改动**：`.ce-dd-metrics` 3 列、`.ce-dd-bar-row` 96px/1fr/84px 三段网格、`.winner` 行 amber 高亮、`.anim-bar-grow` 从左生长
- **内容适配规则**：选 1 个权重最高维度展开（默认性能 D1）；每项基准 3 个参评方条形，`width:%` 按值/最大值换算；指标全部「越高越好」以保持条形语义一致（低越好指标需反转映射）

### 08 — `pros-cons`
- **可替换键**：`kicker`, `title`, `subtitle`, `a/b/c_name/sub/pro_1~3/con_1~3`, `footer_source`（三方 × ~5）
- **不可改动**：`.ce-pc-grid` 3 列、领先方列 `.ce-pc-col.hero`（amber 顶边）、`.ce-pc-pros`（✓ 绿）/`.ce-pc-cons`（✗ 红）marker
- **内容适配规则**：每方优势 3 条 + 短板 2~3 条，优劣项应可追溯到第 6 页矩阵的高/低分维度；`hero` 列随领先方迁移

### 09 — `verdict`（标志页★）
- **可替换键**：`kicker`, `title`, `vd_eyebrow`, `vd_name`, `vd_score`, `vd_score_max`, `vd_reason`, `vc_a/b/c_name`, 加权明细表数值, `vc_note`, `footer_source`
- **不可改动**：`.ce-verdict-hero` 双 amber 边框 + 顶渐变条、`.ce-vd-score` 96px amber mono、`.ce-verdict-calc` 明细表、领先行 `.hero` amber
- **内容适配规则**：
  - `vd_score` = 第 6 页加权总分领先值，必须一致
  - `vd_reason` 一句话理由应点出「领先维度 + 可接受的代价」
  - 加权明细表三方数值与第 6 页 tfoot 一致；领先方变更时迁移 `.hero` class

### 10 — `recommendation`
- **可替换键**：`kicker`, `headline`, `headline_accent`, `subtitle`, `ns1~3_title/body/meta`, `meta_evaluator`, `meta_version`, `meta_date`, `meta_confidential`, `footer_source`
- **不可改动**：`.bar-left`、`.h1` 72px、`.ce-nextsteps` 3 列、首步 `.ce-next-step.hero`（amber 顶边）、`.ce-ns-meta` mono（OWNER/EXIT 格式）
- **内容适配规则**：
  - `headline` 推荐结论应与第 9 页裁决一致，含一个 `.gradient-text` accent 词
  - 下一步 3 步（POC 验证 → TCO 复核 → 灰度迁移），每步含 OWNER + 可验证 EXIT + 时间窗口
  - 致谢式收束（推荐结论摘要 + 下一步），**不放人员联系卡**（区别于 consultant thanks）

---

## 组件层（`shared/tokens.css` `.tpl-compare-eval` overlay）

| class | 作用 |
|------|------|
| `.ce-pagehead` | 页头：kicker（评测报告编号） + h2.title |
| `.ce-scope` / `.ce-dim-card` / `.ce-dim-weight` | 评测方法论：维度卡网格 + amber 权重 |
| `.ce-rubric` | 评分标尺 + 数据来源条 |
| `.ce-cand-head` / `.ce-cand-logo` / `.ce-cand-grid` / `.ce-cand-list` / `.ce-cand-fit` | 参评方画像（logo+定位+架构/能力双栏+适配度） |
| `.ce-eval-matrix` / `.ce-row-dim` / `.ce-weight` / `.ce-score.high/mid/low` / `.ce-total` / `.col-hero` | ★ 评分矩阵（维度×参评方 评分单元格 + 权重列 + 加权总分） |
| `.ce-legend` | 评分色阶图例 |
| `.ce-dd-metrics` / `.ce-dd-metric` / `.ce-dd-bar-row.winner` | 维度深挖（基准条形对比） |
| `.ce-pc-grid` / `.ce-pc-col.hero` / `.ce-pc-pros` / `.ce-pc-cons` | 优劣双栏对照（✓/✗） |
| `.ce-verdict` / `.ce-verdict-hero` / `.ce-verdict-calc` / `.ce-vc-table` | ★ 裁决卡（综合分+推荐+理由+加权明细） |
| `.ce-nextsteps` / `.ce-next-step.hero` / `.ce-ns-meta` | 下一步选型计划（POC/TCO/迁移） |
| `.ce-cover-meta` | 封面/收束页评测元数据 |
| `body.vcenter` | 内容页（02–09）整块垂直居中修饰符（书挡页 01/10 不用） |
| `.anim-rise-in` / `.anim-slide-l` / `.anim-slide-r` / `.anim-scale-pop` / `.anim-bar-grow` / `.anim-blur-in` | 动效层（hero 落地 / 对比方向 / 数字弹 / 基准条生长 / 收束 blur），均含 reduced-motion + print 兜底 |
| `.bar-top` / `.bar-left` / `.card-amber` / `.card-accent` / `.pill-amber` / `.pill-accent` / `.pill-good` | 装饰条 + 强调卡 + 标签（通用层定义） |

> 所有 `ce-*` 组件颜色均 `var(--brand-*)` 链接，`switch-theme.mjs --scheme <name>` 切换时自动联动。推荐配套方案：`midnight-ink`（默认客观墨蓝）、`consulting-navy`（深蓝投行）、`nord-frost`（冷静学术）。
