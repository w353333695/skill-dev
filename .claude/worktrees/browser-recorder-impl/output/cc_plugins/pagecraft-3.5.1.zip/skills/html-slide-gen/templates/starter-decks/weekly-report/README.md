# weekly-report · 周报

14-slide team weekly report: cover (week range), agenda, KPI grid, wins (SVG trend illustration), shipped items, sprint velocity (SVG line), conversion funnel, a metric trend chart, OKR progress (bars + SVG gauge), blockers, decisions-needed, next-week plan, team capacity roster, thanks.

Corporate-clarity palette: near-white background, blue→teal accent, ruled dividers and tiny mono tags (`FEAT`, `FIX`, `EXP`, `INFRA`). Data-dense, readable at a glance, and easy to skim in a standup. Flat `.wr-*` containers (thin border, optional left color-bar, no heavy shadow) carry the data/chart blocks; SVG illustrations (wins hero art, velocity line, OKR gauge) are inline + token-colored so they export cleanly to PPTX/PDF with no JS.

**Use when:** team weekly readouts, squad reviews, skip-level updates, cross-team "what shipped this week" mails.
**Feel:** Linear changelog meets a McKinsey KPI deck — serious, measured, actionable.
