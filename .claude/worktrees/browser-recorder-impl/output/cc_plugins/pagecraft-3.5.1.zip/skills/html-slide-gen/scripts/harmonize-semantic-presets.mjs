// 一次性脚本：为 color-schemes.json 每个 scheme 预置 hi-positive / hi-warning（+ rgb）。
// 治 C1 用户反馈："不同主题配不同强调色，橙色锁定色号有问题"。
// 当前 semantic-tokens.css 把 --hi-positive(绿)/--hi-warning(红) 写死成稳定层，
// 导致 evergreen 绿底 + #16a34a 绿(撞主色) + #dc2626 红 → "黄绿配搭乱"。
//
// 正确做法（呼应用户"颜色变量库 pre-set"）：语义不变（正=绿系、负=红系），
// 但色号随主题协调——绿主题里正向色偏青/亮绿区分主色，红/橙主题里负向色调深/偏绛。
// 同时避免与 brand-primary/hi-strong 撞色。
//
// 幂等：已有 hi-positive 的 scheme 不覆盖。
// 用法：node scripts/harmonize-semantic-presets.mjs
import { readFileSync, writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PATH = join(__dirname, 'color-schemes.json');

function hexToHsl(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  const r = parseInt(m[1].slice(0, 2), 16) / 255;
  const g = parseInt(m[1].slice(2, 4), 16) / 255;
  const b = parseInt(m[1].slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0; const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) * 60;
    else if (max === g) h = ((b - r) / d + 4) * 60;
    else h = ((r - g) / d + 2) * 60;
  }
  return { h, s: s * 100, l: l * 100 };
}
function hslToHex(h, s, l) {
  s /= 100; l /= 100;
  const a = s * Math.min(l, 1 - l);
  const f = n => { const k = (n + h / 30) % 12; const c = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); return Math.round(255 * c).toString(16).padStart(2, '0'); };
  return `#${f(0)}${f(8)}${f(4)}`;
}
function lum(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim()); if (!m) return 0.5;
  const rgb = [0, 2, 4].map(o => parseInt(m[1].slice(o, o + 2), 16) / 255).map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4));
  return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
}
function contrast(fg, bg) {
  const l1 = lum(fg), l2 = lum(bg);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}
function hexToRgbTriple(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return '0,0,0';
  return [0, 2, 4].map(o => parseInt(m[1].slice(o, o + 2), 16)).join(',');
}
// 色相距离（0-180，越大越不撞）
function hueDist(h1, h2) {
  const d = Math.abs(h1 - h2) % 360;
  return Math.min(d, 360 - d);
}

// 在目标色相区间 [hueMin, hueMax]（hueMax 可 >360，自动回绕）内，选一个与 bg 对比 ≥3、
// 且与 avoid 色（主色/CTA）距离最大的色。候选按 8° 步进扫描，明度按底色定。
function pickSemantic(hueMin, hueMax, bg, avoid) {
  const bgLum = lum(bg);
  const wantDark = bgLum > 0.45;
  let best = null, bestScore = -1;
  for (let hh = hueMin; hh <= hueMax; hh += 8) {
    const h = hh % 360;
    for (const s of [70, 62, 55]) {
      let l = wantDark ? 38 : 56;
      let cand = hslToHex(h, s, l);
      for (let i = 0; i < 5 && contrast(cand, bg) < 3; i++) {
        l = wantDark ? Math.max(22, l - 6) : Math.min(78, l + 6);
        cand = hslToHex(h, s, l);
      }
      const ct = contrast(cand, bg);
      if (ct < 3) continue;
      let score = ct;
      for (const a of avoid) {
        const ah = hexToHsl(a);
        if (ah) score += hueDist(h, ah.h) / 180;
      }
      if (score > bestScore) { bestScore = score; best = cand; }
    }
  }
  return best;
}

const raw = readFileSync(PATH, 'utf8');
const json = JSON.parse(raw);
const schemes = json.schemes;
let added = 0, skipped = 0;
for (const [name, sch] of Object.entries(schemes)) {
  if (!sch.tokens) continue;
  if (sch.tokens['hi-positive']) { skipped++; continue; }
  const bg = sch.tokens['brand-bg'];
  const primary = sch.tokens['brand-primary'];
  const cta = sch.tokens['hi-strong'];
  const avoid = [primary, cta].filter(Boolean);
  // 正向：绿系（色相 90-160，青绿→翠绿）。负向：红系（色相 350-360 + 0-15，绛红→朱红）
  const positive = bg ? (pickSemantic(95, 165, bg, avoid) || '#16a34a') : '#16a34a';
  const warning = bg ? (pickSemantic(350, 375, bg, avoid) || '#dc2626') : '#dc2626';
  // pickSemantic 的 hue 上限 >360 时需回绕，单独处理 warning 的 350-15 跨 0 区间
  sch.tokens['hi-positive'] = positive;
  sch.tokens['hi-positive-rgb'] = hexToRgbTriple(positive);
  sch.tokens['hi-warning'] = warning;
  sch.tokens['hi-warning-rgb'] = hexToRgbTriple(warning);
  added++;
}
writeFileSync(PATH, JSON.stringify(json, null, 2) + '\n', 'utf8');
console.log(`✓ 已为 ${added} 个 scheme 预置 hi-positive/warning（跳过 ${skipped} 个已有）`);
for (const n of ['evergreen', 'amber-ember', 'ocean-depths', 'sakura-blossom']) {
  const t = schemes[n].tokens;
  console.log(`  ${n}: positive=${t['hi-positive']} warning=${t['hi-warning']} (primary=${t['brand-primary']} cta=${t['hi-strong']})`);
}
