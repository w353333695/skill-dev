# course-module — Slide Role Catalog

> **模板气质**：教科书风、左侧 sidebar 学习目标(进度跟踪)、.concept-box 讲义卡片、.callout 提示框、Playfair Display 衬线
> **默认 color-scheme**：forest-canopy（暖米色纸底、绿 #3a7d44 + 陶土 #c4735b 双 accent）
> **适用文稿类型**：传授/赋能
> **叙事结构**：Cover → Objectives(sidebar+4box) → Concept(sidebar+2box+callout) → Example(sidebar+code+trace) → Exercise(sidebar+tasks) → Check(sidebar+MCQ) → Summary(full, 4box+callout) → Thanks(full, 轻量收尾)。另有可选板式 Figure / Quote / Compare，按内容需要插入任意位置。

## 角色索引

| 页码 | 角色 ID | 描述 | 核心组件 |
|------|---------|------|---------|
| 01 | `cover` | 封面(.full, 无sidebar) | .full, .pill-academic |
| 02 | `content-objectives` | 学习目标页(sidebar+4box) | .sidebar(.brand+.obj-list), .concept-box |
| 03 | `content-concept` | 概念讲解(sidebar+2box+callout) | .sidebar, .concept-box, .callout |
| 04 | `content-example` | 范例演示(sidebar+code+trace) | .sidebar, .code(pre), .callout |
| 05 | `content-exercise` | 练习题(sidebar+tasks) | .sidebar, .exercise(ol) |
| 06 | `content-check` | 理解测验(sidebar+MCQ×5) | .sidebar, .mcq(.correct=正确答案) |
| 07 | `content-summary` | 模块总结(.full, 4box+callout) | .full, .concept-box, .callout |
| 08 | `content-figure` | 插图/图示页(sidebar+figure) | .sidebar, .figure(.figure-media[img/svg]+.figure-caption) |
| 09 | `content-quote` | 金句/引言页(sidebar+quote) | .sidebar, .quote(blockquote+cite), .callout |
| 10 | `content-compare` | 对比页(sidebar+双栏vs) | .sidebar, .compare(.grid.g2+.concept-box), .callout |
| 11 | `thanks` | 结束页(.full, 无sidebar) | .full, .pill-academic |

> **封面/结束页对称**：01 cover 与 11 thanks 同为 `.full`（无 sidebar、垂直居中），用相同的 kicker → h1 → lede → pill-row 骨架，形成首尾呼应。结束页保持简洁——一句话收尾 + 一行 meta pill（如"下一模块 / 练习"）即可，**不要**堆卡片或 callout，让页面有呼吸感、为整场画上句号。
>
> **可选板式说明**：08–10 不是固定顺序，而是**板式库**——agent 生成时按内容需要选用并插入合适位置。例如讲概念前用 09 金句开场、讲完用 08 图示加深、讲对比时插 10。用任意一种时记得同步 sidebar 的 objective 进度（done/current）与页脚计数。

## 特殊机制：Sidebar 进度跟踪

`.sidebar` 中的 `.obj-list` 用 `class="done"` / `class="current"` 追踪学习进度：
- `class="done"` — 已完成的 objective（灰色/划线）
- `class="current"` — 当前正在讲的 objective（高亮）
- 无 class — 尚未覆盖的 objective

标注时每个 `<li>` 的 textContent 用 data-replace 标注，class 由 AI 按内容进度设置。

## Style Transfer — T2 页面继承规则

### 空间密度对齐
- body padding: 对齐模板
- sidebar 宽度：280px，main 区 flex:1
- `.full` 页无 sidebar（封面和总结页使用）

### 装饰模式继承
- 讲义卡片：`.concept-box`
- 提示/规则：`.callout`
- 代码块：`.code > pre`
- 练习题：`.exercise`
- 选择题：`.mcq` + `.mcq.correct`（正确答案高亮）
- 元信息标签：`.pill-academic`
- 插图/图示：`.figure` > `.figure-media`（放 `<img>` 或内联 `<svg>`）+ `.figure-caption`
- 金句/引言：`.quote` > `blockquote` + `cite`
- 双栏对比：`.compare`（基于 `.grid.g2` + `.concept-box`，配 `.tag` 小标签，可选 `.good`/`.bad` 配色）

### 响应式换行规范（重要）
- **标题与正文一律不写死 `<br>`**——文字让其自然换行。`data-replace` 槽位在生成时会被替换成不同长度的真实内容，写死 `<br>` 会在长内容下断在不该断的地方、在短内容下留出难看的空行。
- 关键 display 级标题字号已用 `clamp()` 做下限保护（`.h1` / `.h2` / `.quote blockquote`），内容偏长时自动缩小而不溢出；正文用 `max-width` 限制阅读宽度。
- 唯一允许 `<br>` 的场景：卡片**正文内部**有意的视觉分行（如"……错了 Ctrl+Z，零代价。<br>策略：放开跑"这种短句配标签的结构），且分行不依赖内容长度变化。判断标准：若该处文本会被 `data-replace` 替换，就不要用 `<br>`。

### 禁止引入的视觉元素
| 禁止 | 原因 |
|------|------|
| .card / .card-accent | course-module 用 .concept-box 和 .callout |
| .section-num / .num-tag | course-module 用 sidebar 做章节导航 |
| .feature-card / .price-card | 产品模板专属 |
| .terminal | course-module 用 .code（简单深色代码块，无 macOS chrome） |
