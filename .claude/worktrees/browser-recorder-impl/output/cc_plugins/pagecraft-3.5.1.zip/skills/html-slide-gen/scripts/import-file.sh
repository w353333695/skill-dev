#!/usr/bin/env bash
# import-file.sh — 将 PPTX/DOCX 转换为 Markdown 供 AI 读取
# 依赖：pip install 'markitdown[pptx,docx]'
#
# 用法：
#   ./scripts/import-file.sh <input.pptx|input.docx> [output.md]
#
# 如果不指定 output，默认输出到 <input>-imported.md

set -euo pipefail

INPUT="$1"
OUTPUT="${2:-}"

if [ -z "$INPUT" ]; then
  echo "Usage: $0 <input.pptx|input.docx> [output.md]"
  exit 1
fi

if [ ! -f "$INPUT" ]; then
  echo "Error: file not found: $INPUT"
  exit 1
fi

EXT="${INPUT##*.}"
case "$EXT" in
  pptx|docx) ;;
  *)
    echo "Error: unsupported format .${EXT}. Only .pptx and .docx are supported."
    exit 1
    ;;
esac

if ! command -v markitdown &>/dev/null; then
  echo "Error: markitdown not found. Install with: pip install 'markitdown[pptx,docx]'"
  exit 1
fi

if [ -z "$OUTPUT" ]; then
  OUTPUT="${INPUT%.*}-imported.md"
fi

markitdown "$INPUT" -o "$OUTPUT"

echo "Converted: $INPUT -> $OUTPUT"
