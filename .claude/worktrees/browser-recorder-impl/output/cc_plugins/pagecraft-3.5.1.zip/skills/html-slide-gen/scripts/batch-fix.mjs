#!/usr/bin/env node
// batch-fix.mjs — Apply common fixes across all slides in a deck
// Zero-dependency, works alongside validate.mjs

'use strict';

import { readdirSync, readFileSync, writeFileSync, existsSync } from 'fs';
import { join, resolve } from 'path';
import { fileURLToPath } from 'url';
import { VOID_ELEMENTS, TEXT_CONTAINER_TAGS, IGNORED_TAGS, DIV_TEXT_WHITELIST_CLASSES, extractTagName, isT1Page, tokenize } from './_html-model.mjs';

// ── Tag/token model ── VOID_ELEMENTS / TEXT_CONTAINER_TAGS / IGNORED_TAGS /
// DIV_TEXT_WHITELIST_CLASSES / extractTagName / isT1Page / tokenize now live in
// ./_html-model.mjs (shared with validate.mjs + validate-pptx.mjs so div-bare-text
// detection + in-place rewriting match the validator exactly — a fix that doesn't
// match what the validator flags is worse than no fix). The shared tokenizer
// emits tagEnd/end offsets that only batch-fix reads (for html.slice rewriting);
// validate/validate-pptx ignore them. ──────────────────────────────────────

// ── Color token map (common hex → var(--xxx)) ──────────────────────

const COLOR_TOKEN_MAP = {
  '#3b6cff': 'var(--accent)',
  '#7a5cff': 'var(--accent-2)',
  '#ff5c8a': 'var(--accent-3)',
  '#111216': 'var(--text-1)',
  '#55596a': 'var(--text-2)',
  '#8a8f9e': 'var(--text-3)',
  '#ffffff': 'var(--bg)',
  '#f7f7f8': 'var(--bg-soft)',
  '#f2f2f4': 'var(--surface-2)',
  '#1aaf6c': 'var(--good)',
  '#f5a524': 'var(--warn)',
  '#e0445a': 'var(--bad)',
};

// ── Fix implementations ────────────────────────────────────────────

function fixFooterPadding(html) {
  // Add padding-bottom: 90px to .page-body if missing
  let changed = false;
  let result = html;

  // Fix inline style on page-body elements
  result = result.replace(
    /(<[^>]*class\s*=\s*["']([^"']*\bpage-body\b[^"']*)["'])([^>]*style\s*=\s*["'])([^"']*)(["'])/gi,
    (match, tagStart, cls, styleStart, styles, styleEnd) => {
      if (/padding-bottom/.test(styles)) return match;
      changed = true;
      return `${tagStart}${styleStart}${styles}; padding-bottom: 90px${styleEnd}`;
    }
  );

  // Fix page-body without any style attribute — add one
  result = result.replace(
    /(<[^>]*class\s*=\s*["']([^"']*\bpage-body\b[^"']*)["'])(?![\s\S]*?style\s*=)/gi,
    (match, tagStart) => {
      // Only match if no style attribute follows in the same tag
      if (/style\s*=/.test(tagStart)) return match;
      changed = true;
      return `${tagStart} style="padding-bottom: 90px"`;
    }
  );

  // Fix CSS block: .page-body { ... } without padding-bottom
  result = result.replace(
    /(\.page-body\s*\{)/g,
    (match) => {
      // Check if padding-bottom already exists after this opening brace
      const afterBrace = result.substring(result.indexOf(match) + match.length);
      const closeBrace = afterBrace.indexOf('}');
      const blockContent = afterBrace.substring(0, closeBrace);
      if (/padding-bottom/.test(blockContent)) return match;
      changed = true;
      return `${match}\n  padding-bottom: 90px;`;
    }
  );

  return { html: result, changed };
}

function fixSlideTopBar(html) {
  // Ensure .slide-top-bar exists on content pages (those with tech-footer)
  // Skip T1 pages — they get their structure from template slide HTML
  let changed = false;
  let result = html;
  // F13 (2026-06-22): use isT1Page (recognizes both data-skeleton="t1" AND
  // <body class="tpl-...">) instead of inline regex that only matched data-skeleton.
  // Pages with only a tpl- class (pre-injection state) were misjudged as non-T1 and
  // wrongly had footer/top-bar fixes applied. Single source of truth = isT1Page.
  if (isT1Page(html)) return { html: result, changed };

  const hasTechFooter = /class\s*=\s*["'][^"']*\btech-footer\b/.test(html);
  const hasTopBar = /class\s*=\s*["'][^"']*\bslide-top-bar\b/.test(html);

  if (hasTechFooter && !hasTopBar) {
    result = html.replace(/(<body[^>]*>)/i, '$1\n  <div class="slide-top-bar"></div>');
    changed = true;
  }
  return { html: result, changed };
}

function fixHardcodedColors(html) {
  let changed = false;
  let result = html;

  // Only replace inside <style> blocks and inline styles, skip SVG attributes
  // Split into segments: <style> blocks and everything else
  const styleBlocks = [];
  result = result.replace(/<style[^>]*>([\s\S]*?)<\/style>/gi, (match, content) => {
    let modified = content;
    for (const [hex, token] of Object.entries(COLOR_TOKEN_MAP)) {
      // Case-insensitive hex replacement
      const regex = new RegExp(hex.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      const before = modified;
      modified = modified.replace(regex, token);
      if (modified !== before) changed = true;
    }
    return '<style>' + modified + '</style>';
  });

  // Replace inline style hex colors
  result = result.replace(/style\s*=\s*["']([^"']+)["']/gi, (match, styles) => {
    let modified = styles;
    for (const [hex, token] of Object.entries(COLOR_TOKEN_MAP)) {
      const regex = new RegExp(hex.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      const before = modified;
      modified = modified.replace(regex, token);
      if (modified !== before) changed = true;
    }
    return 'style="' + modified + '"';
  });

  // Replace rgba() patterns that map to known colors
  result = result.replace(
    /(?:color|background|border-color|box-shadow)\s*:\s*rgba\(59,\s*108,\s*255,\s*(0?\.\d+)\)/gi,
    (match, alpha) => {
      changed = true;
      const pct = Math.round(parseFloat(alpha) * 100);
      return match.replace(/rgba\(59,\s*108,\s*255,\s*0?\.\d+\)/i, `color-mix(in srgb, var(--accent) ${pct}%, transparent)`);
    }
  );

  return { html: result, changed };
}

function fixFooterConsistency(html, referenceFooter) {
  // Replace .tech-footer inner content with reference structure
  let changed = false;
  let result = html;
  const footerRe = /(<div[^>]*class\s*=\s*["'][^"']*\btech-footer\b[^"']*["'][^>]*>)([\s\S]*?)(<\/div>)/gi;

  result = result.replace(footerRe, (match, open, inner, close) => {
    // Extract reference inner content
    const refInnerMatch = referenceFooter.match(/<div[^>]*class\s*=\s*["'][^"']*\btech-footer\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i);
    if (!refInnerMatch) return match;
    const refInner = refInnerMatch[1].trim();
    const currentInner = inner.trim();
    if (currentInner === refInner) return match;
    changed = true;
    return `${open}\n      ${refInner}\n    ${close}`;
  });

  return { html: result, changed };
}

function fixCompactHeader(html, style) {
  // Add class="compact-header" to body for high-density pages
  // Skip T1 pages — they have their own spacing system from the template
  let changed = false;
  let result = html;
  // F13 (2026-06-22): isT1Page instead of inline regex (see add-slide-top-bar fix).
  if (isT1Page(html)) return { html: result, changed };

  // Skip blacklisted styles that don't use page-header/page-body system
  const COMPACT_HEADER_STYLE_BLACKLIST = ['pitch-deck', 'product-launch', 'xhs-pastel-card',
    'xhs-white-editorial', 'dir-key-nav-minimal'];
  if (style && COMPACT_HEADER_STYLE_BLACKLIST.includes(style)) {
    return { html: result, changed };
  }

  // Skip pages that already have compact-header
  if (/class\s*=\s*["'][^"']*\bcompact-header\b/.test(html)) {
    return { html: result, changed };
  }

  // Rule 1: bullet cards (L06) ≥ 5
  const cardCount = (html.match(/class="[^"]*\bcard\b/g) || []).length;
  // Rule 2: table rows ≥ 7 (count <tr> tags)
  const trCount = (html.match(/<tr[\s>]/g) || []).length;
  // Rule 3: architecture layers ≥ 5 (count tier/arch layer divs)
  const hasArch = /class="[^"]*\barch\b/.test(html);
  // Rule 4: 3+1 variant detection (g3 + centered single card)
  const has31Variant = /class="[^"]*\bg3\b/.test(html) && /justify-content\s*:\s*center/.test(html);

  const needsCompact = cardCount >= 5 || trCount >= 7 || (hasArch && cardCount >= 5) || has31Variant;

  if (needsCompact) {
    result = html.replace(
      /(<body)([^>]*)(>)/i,
      (match, open, attrs, close) => {
        if (/class\s*=/.test(attrs)) {
          return `${open}${attrs.replace(/class\s*=\s*["']/, '$&compact-header ')}${close}`;
        } else {
          return `${open} class="compact-header"${attrs}${close}`;
        }
      }
    );
    changed = true;
  }

  return { html: result, changed };
}

function fixNormalizeGaps(html) {
  // Normalize non-standard gap values on .page-body to 20px (tokens.css default)
  let changed = false;
  let result = html;

  result = result.replace(
    /(<[^>]*class\s*=\s*["'][^"']*\bpage-body\b[^"']*["'][^>]*style\s*=\s*["'])([^"']*)(["'])/gi,
    (match, tagStart, styles, tagEnd) => {
      const gapMatch = styles.match(/gap\s*:\s*(\d+)px/i);
      if (!gapMatch) return match;
      const currentGap = parseInt(gapMatch[1]);
      if (currentGap === 20) return match; // already default
      changed = true;
      const newStyles = styles.replace(/gap\s*:\s*\d+px/i, 'gap: 20px');
      return `${tagStart}${newStyles}${tagEnd}`;
    }
  );

  return { html: result, changed };
}

// Emoji → SVG icon mapping (common patterns found in past decks)
// 每个目标必须是 templates/assets/icons/ 下真实存在的 .svg（见该目录 README / icons-index.json）。
// 历史上多处映射指向不存在的文件（gear/lock/mail/search/pen/bolt/...），会产出坏 <img src>。
// 201 计划 H3 修复：全部重映射到真实文件。
const EMOJI_ICON_MAP = {
  '🧩': 'layers.svg',
  '👥': 'users.svg',
  '⚙️': 'cog.svg',
  '🎯': 'target.svg',
  '💡': 'lightbulb.svg',
  '🔒': 'lock-closed.svg',
  '⭐': 'star.svg',
  '⏱️': 'clock.svg',
  '📊': 'chart-bar.svg',
  '📈': 'arrow-trend-up.svg',
  '📉': 'arrow-trend-down.svg',
  '🔧': 'wrench.svg',
  '🚀': 'rocket.svg',
  '💬': 'bell.svg',
  '📋': 'clipboard.svg',
  '🔍': 'magnifying-glass.svg',
  '✅': 'circle-checkmark.svg',
  '❌': 'circle-x.svg',
  '⚠️': 'triangle-exclamation.svg',
  '🏆': 'trophy.svg',
  '📱': 'mobile.svg',
  '🌐': 'globe.svg',
  '📧': 'envelope.svg',
  '💰': 'money.svg',
  '🏗️': 'building.svg',
  '🔗': 'link.svg',
  '📝': 'pencil.svg',
  '🛡️': 'shield-check.svg',
  '⚡': 'sparkles.svg',
  '🗄️': 'database.svg',
  '📡': 'signal.svg',
  '📖': 'book.svg',
  '📕': 'book.svg',
  '📚': 'books.svg',
};

// 纯装饰性符号（非语义图标），直接移除而非替换 —— 装饰星/花不应出现在 B 端 deck。
const EMOJI_DECORATIVE_STRIP = ['✦', '✧', '✪', '✫', '✬', '✭', '✮', '⋆', '※', '❋', '❉'];

function fixReplaceEmojiWithIcons(html) {
  let changed = false;
  let result = html;

  for (const [emoji, iconFile] of Object.entries(EMOJI_ICON_MAP)) {
    const escapedEmoji = emoji.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const before = result;
    // 替换为内联尺寸的 img（width/height 属性，不依赖 .icon-md class 是否在 deck tokens.css 定义）。
    // v63 实证：consultant-strategy 等多数 deck 的 tokens.css 无 .icon-md 定义 → SVG 以原生
    // viewBox 渲染撑满页面。用 width="24" height="24" 属性自包含，任何 deck 都正确缩放。
    const imgTag = `<img src="../assets/icons/${iconFile}" width="24" height="24" alt="" style="display:inline-block;vertical-align:middle;margin-right:6px;">`;
    // Replace emoji used as decorative icon (inside card headers, standalone divs, etc.)
    result = result.replace(
      new RegExp(`>${escapedEmoji}\\s*<`, 'g'),
      `>${imgTag}<`
    );
    // Also match emoji at start of text content (after > with optional spaces)
    result = result.replace(
      new RegExp(`>\\s*${escapedEmoji}\\s*`, 'g'),
      `>${imgTag} `
    );
    if (result !== before) changed = true;
  }

  // 纯装饰符号（✦/✧/※…）直接移除——它们无语义，B 端 deck 不该出现。
  for (const deco of EMOJI_DECORATIVE_STRIP) {
    const before = result;
    const esc = deco.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    result = result.replace(new RegExp(esc, 'g'), '');
    if (result !== before) changed = true;
  }

  return { html: result, changed };
}

// ── div-bare-text wrap (L1.2.2 / suggestion A / P2.6) ─────────────────────
// Wraps bare text that is a direct child of a <div> in <span>, exactly matching
// what validate.mjs DIV_BARE_TEXT flags. NEVER changes the tag to <p> (subagents
// historically did this and broke template structure). T1 template pages and
// whitelisted template-native classes are skipped — their bare text is intentional.

function fixDivBareText(html) {
  // Skip T1 template pages — their HTML structure is correct by design (mirrors
  // validate.mjs pptxCheckDivBareText which returns [] for T1 pages).
  if (isT1Page(html)) return { html, changed: false };

  const tokens = tokenize(html);
  // Collect bare-text spans (offset ranges) to wrap. Each entry = a TEXT token
  // whose nearest non-void/non-ignored ancestor is a non-whitelisted div.
  const wraps = [];
  const tagStack = [];
  for (const token of tokens) {
    if (token.type === 'TAG_OPEN') {
      tagStack.push({ tagName: token.tagName, offset: token.offset, tagEnd: token.tagEnd });
    } else if (token.type === 'TAG_CLOSE') {
      const idx = tagStack.findLastIndex(t => t.tagName === token.tagName);
      if (idx >= 0) tagStack.splice(idx, 1);
    } else if (token.type === 'TEXT') {
      const trimmed = token.text.trim();
      if (!trimmed) continue;
      for (let i = tagStack.length - 1; i >= 0; i--) {
        const { tagName } = tagStack[i];
        if (VOID_ELEMENTS.has(tagName)) continue;
        if (IGNORED_TAGS.has(tagName)) break;
        if (TEXT_CONTAINER_TAGS.has(tagName)) break;
        if (tagName === 'div') {
          // Whitelisted template-native class → intentional bare text, skip.
          const frame = tagStack[i];
          const tagHtml = html.slice(frame.offset, frame.tagEnd);
          const classMatch = tagHtml.match(/class\s*=\s*["']([^"']*)["']/);
          if (classMatch) {
            const classes = classMatch[1].split(/\s+/);
            if (classes.some(c => DIV_TEXT_WHITELIST_CLASSES.has(c))) break;
          }
          // Trim leading/trailing whitespace from the text node so we wrap only
          // the visible text, preserving the original indentation/spacing around it.
          const lead = token.text.length - token.text.replace(/^\s+/, '').length;
          const trail = token.text.length - token.text.replace(/\s+$/, '').length;
          const textStart = token.offset + lead;
          const textEnd = token.end - trail;
          if (textEnd > textStart) {
            wraps.push({ start: textStart, end: textEnd });
          }
        }
        break;
      }
    }
  }

  if (wraps.length === 0) return { html, changed: false };

  // Apply wraps right-to-left so offsets stay valid.
  wraps.sort((a, b) => b.start - a.start);
  let result = html;
  for (const w of wraps) {
    const slice = result.slice(w.start, w.end);
    result = result.slice(0, w.start) + `<span>${slice}</span>` + result.slice(w.end);
  }
  return { html: result, changed: true };
}

// ── inject-data-skeleton (L1.2.3 / suggestion B / P0.3) ───────────────────
// Detects pages that carry T1 template signals (a tpl-<deck> body class) but
// lack the data-skeleton="t1" marker, and injects it. Without the marker, the
// validator's T1 exemptions (SVG whitelist, DIV_BARE_TEXT skip, compact-header
// skip) all silently no-op, producing a flood of false positives. Adding the
// marker to the <body> is a one-flag, three-birds fix.

function fixInjectDataSkeleton(html) {
  // Must look like a T1 template page: body carries a tpl-<deck> class.
  const bodyMatch = html.match(/<body\b[^>]*>/i);
  if (!bodyMatch) return { html, changed: false };
  const bodyTag = bodyMatch[0];
  if (!/\btpl-[a-z0-9-]+/i.test(bodyTag)) return { html, changed: false };

  // Body already carries a data-skeleton marker (any value) — leave it as-is.
  // v14b root cause: this fix only checked for `data-skeleton="t1"` and skipped
  // detection of `t2`. A T2 page whose body keeps a tpl-<deck> class (template
  // source HTML carries it; subagent must not touch body class) matched the
  // tpl- gate below, got `data-skeleton="t1"` injected, and collided with the
  // subagent-set `data-skeleton="t2"` → duplicate attribute (invalid HTML).
  // Detecting ANY existing data-skeleton on the body (not just t1) makes the
  // inject a no-op for pages the subagent already marked, regardless of value.
  // Detection runs on the body tag slice only, so a stray data-skeleton inside
  // slide content can't fool it.
  if (/data-skeleton\s*=/i.test(bodyTag)) return { html, changed: false };

  // Inject data-skeleton="t1" into the <body> tag (after class if present, else
  // as the first attribute).
  let newBodyTag;
  if (/class\s*=/i.test(bodyTag)) {
    newBodyTag = bodyTag.replace(/(class\s*=\s*["'][^"']*["'])/i, '$1 data-skeleton="t1"');
  } else {
    newBodyTag = bodyTag.replace(/<body\b/i, '<body data-skeleton="t1"');
  }
  if (newBodyTag === bodyTag) return { html, changed: false };

  const result = html.slice(0, bodyMatch.index) + newBodyTag + html.slice(bodyMatch.index + bodyTag.length);
  return { html: result, changed: true };
}



export function syncManifest(deckPath) {
  const slidesDir = join(deckPath, 'slides');
  const indexPath = join(deckPath, 'index.html');

  if (!existsSync(slidesDir) || !existsSync(indexPath)) {
    console.error('  ⚠️  sync-manifest: slides/ or index.html not found');
    return false;
  }

  const slides = readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();
  let indexHtml = loadText(indexPath);

  // Extract title from each slide HTML
  const manifest = slides.map(file => {
    const slideHtml = loadText(join(slidesDir, file));
    const titleMatch = slideHtml.match(/<title>([^<]*)<\/title>/);
    const label = titleMatch ? titleMatch[1].replace(/^\d+\s*[-—]\s*/, '').trim() : file;
    return `  { file: "slides/${file}", label: "${label}" }`;
  });

  const newManifest = `window.DECK_MANIFEST = [\n${manifest.join(',\n')}\n];`;

  // Replace existing DECK_MANIFEST or insert after opening script tag
  if (/window\.DECK_MANIFEST\s*=/.test(indexHtml)) {
    indexHtml = indexHtml.replace(
      /window\.DECK_MANIFEST\s*=\s*\[[\s\S]*?\];/,
      newManifest
    );
  } else {
    // Insert after the <script> tag that precedes DECK_MANIFEST
    indexHtml = indexHtml.replace(
      /(<script>\s*\n)/,
      `$1${newManifest}\n`
    );
  }

  saveText(indexPath, indexHtml);
  console.log(`  ✅ sync-manifest: ${slides.length} entries written`);
  return true;
}

export function syncNotes(deckPath) {
  const slidesDir = join(deckPath, 'slides');
  const indexPath = join(deckPath, 'index.html');

  if (!existsSync(slidesDir) || !existsSync(indexPath)) {
    console.error('  ⚠️  sync-notes: slides/ or index.html not found');
    return false;
  }

  const slides = readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();
  let indexHtml = loadText(indexPath);

  const notes = slides.map(file => {
    const slideHtml = loadText(join(slidesDir, file));
    const notesMatch = slideHtml.match(/<aside class="notes">([\s\S]*?)<\/aside>/);
    if (!notesMatch) return null;
    // Escape for safe JSON-like embedding: backslash first, then double-quotes
    let content = notesMatch[1].trim();
    content = content.replace(/\\/g, '\\\\');
    content = content.replace(/"/g, '\\"');
    content = content.replace(/\u201c/g, '\u300c');
    content = content.replace(/\u201d/g, '\u300d');
    content = content.replace(/\u2018/g, '\u300c');
    content = content.replace(/\u2019/g, '\u300d');
    content = content.replace(/\s+/g, ' ');
    return `  "slides/${file}": "${content}"`;
  }).filter(Boolean);

  const newNotes = `window.DECK_NOTES = {\n${notes.join(',\n')}\n};`;

  if (/window\.DECK_NOTES\s*=/.test(indexHtml)) {
    indexHtml = indexHtml.replace(
      /window\.DECK_NOTES\s*=\s*\{[\s\S]*?\};/,
      newNotes
    );
  } else {
    console.error('  ⚠️  sync-notes: no DECK_NOTES block found in index.html');
    return false;
  }

  saveText(indexPath, indexHtml);
  console.log(`  ✅ sync-notes: ${notes.length} notes extracted`);
  return true;
}

// ── sync-image-manifest (L1.2.1 / suggestion F / plan B.2) ────────────────
// When image-manifest.md is MISSING, materialize it from outline.md by scanning
// every page-level [visual: <type>] annotation (type != none) and writing an
// all-SKIPPED 5-column table. This unblocks the validator's visual check for
// decks that render all page-level visuals via template/CSS rather than AI
// images (the common pitch-deck case).
//
// SAFETY (risk M2): never overwrite a real manifest. If image-manifest.md
// already exists — whether empty, all-OK, or containing FAILED rows — we leave
// it untouched. The validator's sentinel handles an empty existing manifest;
// this fix is strictly for the absent-file case.

export function syncImageManifest(deckPath) {
  // image-manifest.md lives two levels above the live deck dir (sibling of outline.md),
  // matching validate.mjs checkVisualAnnotations' projectDir resolution.
  const projectDir = resolve(deckPath, '..', '..');
  const outlinePath = join(projectDir, 'outline.md');
  const manifestPath = join(projectDir, 'image-manifest.md');

  if (existsSync(manifestPath)) {
    console.log(`  ⏭️  sync-image-manifest: ${manifestPath} already exists — leaving untouched (never overwrite a real manifest)`);
    return false;
  }
  if (!existsSync(outlinePath)) {
    console.error(`  ⚠️  sync-image-manifest: outline.md not found at ${outlinePath}`);
    return false;
  }

  const text = readFileSync(outlinePath, 'utf8');
  // Extract one visual per page. outline.md typically has TWO places carrying
  // [visual: ...] for the same page — a summary table row (`| P01 | ... | [visual: cover] | ...`)
  // and a per-page detail heading (`### P01 ... [visual: cover]`). Scan both but
  // de-duplicate by page id so each page appears at most once. Prefer non-none.
  const byPage = new Map(); // pageId -> { type }
  for (const line of text.split(/\r?\n/)) {
    const pageMatch = line.match(/\b(P\d{1,3})\b/);
    if (!pageMatch) continue;
    const pageId = pageMatch[1];
    const visualRe = /\[visual:\s*([^\]]+)\]/g;
    let vm;
    while ((vm = visualRe.exec(line)) !== null) {
      const type = vm[1].trim();
      if (type === 'none' || !type) continue;
      if (!byPage.has(pageId)) byPage.set(pageId, { type });
    }
  }
  const rows = [...byPage.entries()].map(([id, { type }]) =>
    `| ${id} | ${type} | 模板/CSS 渲染（未调用 AI 生图） | (CSS) | SKIPPED |`
  );

  if (rows.length === 0) {
    console.log('  ⏭️  sync-image-manifest: no page-level [visual:] annotations in outline.md — nothing to write');
    return false;
  }

  // Derive a title from outline.md's first H1, fallback to deck dir name.
  const h1 = text.match(/^#\s+(.+)$/m);
  const title = h1 ? h1[1].trim() : deckPath.split('/').filter(Boolean).pop() || 'Untitled';

  const body = [
    `# AI 生图清单 / Image Manifest — ${title}`,
    '',
    '> 由 sync-image-manifest 自动生成：本 deck 的页面级视觉由模板原生组件/CSS 渲染，未调用 AI 生图。',
    '> 如需为某些页生成 AI 图，将对应行状态改为 FAILED 并执行 Phase 4.1.5。',
    '',
    '| 页 | 视觉类型 | 实现方式 | 资产路径 | 状态 |',
    '|----|---------|---------|---------|------|',
    ...rows,
    '',
  ].join('\n');

  writeFileSync(manifestPath, body, 'utf8');
  console.log(`  ✅ sync-image-manifest: ${rows.length} SKIPPED entries written to ${manifestPath}`);
  return true;
}

// ── Main ──────────────────────────────────────────────────────────

// ── Fix: page numbers (B1, 003 主线五) ──────────────────────────────
// deck-level: 按 DECK_MANIFEST 顺序重写每页 .page-num/.slide-number 文本。
// 实战 v31 P02 显示「04」/ P11 显示「15」——subagent 填模板源页码或随机。
// 按 manifest 顺序强制重写为该页序号（zero-padded 2 位），纯数字字段可安全 fix。
function fixPageNumbers(deckPath) {
  const indexPath = join(deckPath, 'index.html');
  if (!existsSync(indexPath)) {
    console.error('  fixPageNumbers: index.html not found, skip');
    return 0;
  }
  const indexHtml = readFileSync(indexPath, 'utf8');
  let manifest = null;
  try { manifest = parseDeckManifestLocal(indexHtml); } catch (e) { /* fallthrough */ }
  const slidesDir = join(deckPath, 'slides');
  if (!existsSync(slidesDir)) return 0;
  const files = readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();

  // 如果有 manifest，用 manifest 顺序映射页码；否则用排序顺序
  let changed = 0;
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const expected = String(i + 1).padStart(2, '0');
    const filePath = join(slidesDir, file);
    let html = readFileSync(filePath, 'utf8');
    let fileChanged = false;
    // 匹配 class 含 page-num 或 slide-number 的元素，重写其文本为 expected
    // 形如 <span class="page-num">09</span> 或 <div class="...slide-number...">9</div>
    const re = /(<[^>]*class="[^"]*(?:page-num|slide-number)[^"]*"[^>]*>)(\s*)([0-9]{1,3})(\s*)(<\/[^>]+>)/g;
    html = html.replace(re, (full, openTag, ws1, num, ws2, closeTag) => {
      if (num === expected) return full;
      fileChanged = true;
      return `${openTag}${ws1}${expected}${ws2}${closeTag}`;
    });
    if (fileChanged) {
      writeFileSync(filePath, html, 'utf8');
      changed++;
      console.log(`  FIXED page-num: slides/${file} → ${expected}`);
    }
  }
  return changed;
}

// 本地 parseDeckManifest（避免 import 循环）：提取 window.DECK_MANIFEST = [...]
function parseDeckManifestLocal(indexHtml) {
  const re = /window\.DECK_MANIFEST\s*=\s*\[/;
  const m = re.exec(indexHtml);
  if (!m) return null;
  const start = indexHtml.indexOf('[', m.index);
  let depth = 0, end = start;
  for (let i = start; i < indexHtml.length; i++) {
    if (indexHtml[i] === '[') depth++;
    else if (indexHtml[i] === ']') { depth--; if (depth === 0) { end = i + 1; break; } }
  }
  return JSON.parse(indexHtml.slice(start, end).replace(/'/g, '"'));
}

// ── Fix: body-tag comment leak (B2, 003 主线五) ─────────────────────
// 实战 v32 P04-P08: <body class="..." data-skeleton="t2"\n<!-- role: kpi-grid -->>
// body 开标签内含注释 → 注释被当属性，最后的 > 作为 body 文本子节点渲染出来。
// 修法：把 <!-- ... --> 移出 body 开标签，到 <body ...> 闭合之后作为子节点。
// per-slide fix，进 FIXES 字典。
function fixBodyTagComment(html) {
  let changed = false;
  // 检测 <body ... >  开标签内含 <!-- 注释
  // body 开标签从 <body 到第一个 >（但 > 在注释里不算，需手工扫描）
  const bodyStart = html.search(/<body[\s>]/);
  if (bodyStart === -1) return { html, changed: false };

  // 找 body 开标签真正闭合的 >（跳过注释内的 >）
  let i = bodyStart + 5; // skip "<body"
  let inComment = false;
  let closeIdx = -1;
  while (i < html.length) {
    if (!inComment) {
      if (html.slice(i, i + 4) === '<!--') { inComment = true; i += 4; continue; }
      if (html[i] === '>') { closeIdx = i; break; }
      i++;
    } else {
      if (html.slice(i, i + 3) === '-->') { inComment = false; i += 3; continue; }
      i++;
    }
  }
  if (closeIdx === -1) return { html, changed: false };

  const openTag = html.slice(bodyStart, closeIdx + 1); // 含 <body ... >
  // 开标签内是否有 <!-- ... -->？
  const commentRe = /<!--[\s\S]*?-->/g;
  const comments = openTag.match(commentRe);
  if (!comments) return { html, changed: false };

  // 把注释从开标签里移出，放到开标签后
  let cleanedOpenTag = openTag.replace(commentRe, '').replace(/\s+/g, ' ').replace(/\s*>$/, '>');
  // 清理可能残留的多余空格在 > 前
  cleanedOpenTag = cleanedOpenTag.replace(/\s+>/g, '>');
  const movedComments = comments.join('\n');
  const after = html.slice(closeIdx + 1);
  // 在开标签后插入注释（注意 body 后通常直接是子节点；放最前）
  const newHtml = html.slice(0, bodyStart) + cleanedOpenTag + '\n' + movedComments + after;
  return { html: newHtml, changed: true };
}

// ── Fix: gantt months (G1/G2/G4, 003 主线六) ────────────────────────
// 模板 17-process-flow-gantt 的甘特图周期由 .cs-gantt 的 data-gantt-start（起始月 1-12）
// + data-gantt-months（月数）驱动。本 fix 据此：
//   ① 生成正确的月份表头（替换 <!-- GANTT_MONTHS_AUTO --> 占位 + 清除任何残留 cs-g-head）
//   ② 设置 --gantt-cols 让 CSS 列数 = 月数
//   ③ 按每条 .cs-g-bar 的 data-mstart/data-mspan 重算 left/width 百分比
// 把 AI 从「月份标注」「百分比计算」两个最易错环节彻底移除（治本 G1/G2/G4）。
// per-slide fix（只在含 .cs-gantt 且有 data-gantt-months 的页生效）。
const MONTH_NAMES = ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'];
function fixGanttMonths(html) {
  if (html.indexOf('cs-gantt') === -1) return { html, changed: false };
  // 读取周期声明
  const startM = /data-gantt-start="(\d{1,2})"/.exec(html);
  const monthsM = /data-gantt-months="(\d{1,2})"/.exec(html);
  if (!startM || !monthsM) return { html, changed: false };
  const start = Math.min(12, Math.max(1, parseInt(startM[1], 10)));
  const months = Math.min(12, Math.max(1, parseInt(monthsM[1], 10)));
  let changed = false;

  // ① 生成月份表头 cells（跨年回绕 12→1）
  const headCells = [];
  for (let k = 0; k < months; k++) {
    const m = ((start - 1 + k) % 12) + 1;
    const gold = (k === months - 1) ? ' gold' : ''; // 末月高亮（收官）
    headCells.push(`  <div class="cs-g-head${gold}"><span>${MONTH_NAMES[m - 1]}</span></div>`);
  }
  const headBlock = headCells.join('\n');

  // 清除所有已存在的 cs-g-head 行（避免残留/重复）+ 占位注释，统一重建
  let out = html;
  // 删除每一个 <div class="cs-g-head...">...</div>（单行或多行，无子标签嵌套，安全）
  const beforeHead = out;
  out = out.replace(/[ \t]*<div class="cs-g-head[^"]*"[^>]*>[\s\S]*?<\/div>\n?/g, '');
  // 在 cs-g-corner 之后插入新表头（优先替换占位注释，否则插到 corner 后）
  if (out.indexOf('<!-- GANTT_MONTHS_AUTO -->') !== -1) {
    out = out.replace(/[ \t]*<!-- GANTT_MONTHS_AUTO -->/, headBlock);
  } else {
    out = out.replace(/(<div class="cs-g-corner"[^>]*>[\s\S]*?<\/div>)/, `$1\n${headBlock}`);
  }
  if (out !== beforeHead) changed = true;

  // ② 设置 --gantt-cols（注入到 .cs-gantt 开标签 style）
  out = out.replace(/(<div class="cs-gantt[^"]*"[^>]*?)(\sstyle="([^"]*)")?(\s*data-gantt-start)/,
    (full, pre, styleAttr, styleVal, post) => {
      const decl = `--gantt-cols:${months}`;
      let newStyle;
      if (styleVal != null) {
        if (/--gantt-cols\s*:/.test(styleVal)) newStyle = styleVal.replace(/--gantt-cols\s*:\s*\d+/, decl);
        else newStyle = `${styleVal.replace(/;?\s*$/, '')};${decl}`;
      } else {
        newStyle = decl;
      }
      changed = true;
      return `${pre} style="${newStyle}"${post}`;
    });

  // ③ 重算每条 bar 的 left/width（按 data-mstart/data-mspan）
  const colW = 100 / months;
  out = out.replace(/(<div class="cs-g-bar[^"]*"[^>]*?)(\sstyle="[^"]*")?([^>]*\sdata-mstart="(\d{1,2})"\sdata-mspan="(\d{1,2})")/g,
    (full, pre, styleAttr, post, ms, sp) => {
      const mstart = Math.max(1, parseInt(ms, 10));
      const mspan = Math.max(1, parseInt(sp, 10));
      const left = +((mstart - 1) * colW).toFixed(2);
      const width = +Math.min(months - (mstart - 1), mspan) * colW;
      const styleVal = `left:${left}%;width:${(+width.toFixed(2))}%`;
      changed = true;
      return `${pre} style="${styleVal}"${post}`;
    });

  return { html: out, changed };
}

// ── Fix: table empty trailing column (T1b, 003 §12.5) ───────────────
// T1 comparison-table 列数 > 内容列 → 每行末尾残留整列空 <td>。
// 检测「所有行末尾都有连续空单元格」→ 删除这些列（含 thead 对应 th）。
// 走精确扫描，逐行处理单元格，不用正则删带子标签的单元格。
function fixTableEmptyTrailingCol(html) {
  if (html.indexOf('<table') === -1) return { html, changed: false };
  let changed = false;
  let out = html;
  // 逐个 table 处理
  out = out.replace(/<table[\s\S]*?<\/table>/g, (tableHtml) => {
    const rows = tableHtml.match(/<tr[\s\S]*?<\/tr>/g);
    if (!rows || rows.length < 2) return tableHtml;
    // 解析每行的单元格（th/td），保留原文与是否为空
    const parsed = rows.map(r => {
      const cells = r.match(/<(t[hd])\b[\s\S]*?<\/\1>/g) || [];
      return cells.map(c => ({ raw: c, empty: isCellEmpty(c) }));
    });
    const colCount = Math.max(...parsed.map(p => p.length));
    if (colCount < 2) return tableHtml;
    // 找出「所有行在该列都为空」的尾列数（从右往左连续）
    let trailingEmpty = 0;
    for (let col = colCount - 1; col >= 1; col--) {
      const allEmpty = parsed.every(p => col >= p.length || p[col].empty);
      const someExist = parsed.some(p => col < p.length);
      if (allEmpty && someExist) trailingEmpty++;
      else break;
    }
    if (trailingEmpty === 0) return tableHtml;
    // 重建每行：去掉末尾 trailingEmpty 个单元格
    let newTable = tableHtml;
    for (let i = 0; i < rows.length; i++) {
      const keep = parsed[i].slice(0, Math.max(1, parsed[i].length - trailingEmpty));
      const cellsJoined = keep.map(c => c.raw).join('');
      // 用首尾单元格之间内容替换：保留 <tr ...> 与 </tr>，替换中间单元格序列
      const newRow = rows[i].replace(/(<tr[^>]*>)[\s\S]*?(<\/tr>)/, (m, open, close) => {
        // 保留 open 后到第一个单元格前的空白、close 前空白由 join 决定
        return `${open}${cellsJoined}${close}`;
      });
      newTable = newTable.replace(rows[i], newRow);
    }
    changed = true;
    return newTable;
  });
  return { html: out, changed };
}

function isCellEmpty(cellHtml) {
  // 去标签后无可见文本，且无 img/svg 等内容
  const inner = cellHtml.replace(/^<t[hd]\b[^>]*>/, '').replace(/<\/t[hd]>$/, '');
  if (/<(img|svg|input|canvas|video)\b/i.test(inner)) return false;
  const text = inner.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, '').replace(/\s+/g, '');
  return text.length === 0;
}

// ── Fix: inline style semicolon (B2 延伸, 003 A1 配套) ──────────────
// var(--token) 后紧跟字母（缺分号）→ 在 var(--token)) 与字母间补 ;
// 仅修 var() 闭合括号后紧跟字母的情况，安全（不影响合法的 var() 嵌套）。
function fixStyleSemicolon(html) {
  const re = /(var\(--[a-z0-9-]+\))(\s*)([a-z-]+\s*:)/gi;
  let count = 0;
  const out = html.replace(re, (full, v, ws, decl) => { count++; return `${v};${ws}${decl}`; });
  return { html: out, changed: count > 0 };
}

// ── Fix: font-size floor (FONT_SIZE_TINY / V2 过度压缩) ─────────────
// 实战 v35/v37：inline font-size 被压到 9-11px（过度压缩副产物）。本 fix 把所有
// inline font-size 提升到可读下限：正文 ≥15px、标题(h1-h3 上下文)/KPI ≥20px。
// 安全：放大字号不破坏语义结构；只动 inline font-size，不动 class/Tokens。
// per-slide fix（进 FIXES 字典）。
const FONT_FLOOR_PX = 15;        // 正文下限（V2 表：正文 ≥15px）
const FONT_FLOOR_PX_LARGE = 20;  // 标题/KPI 下限（V2 表：标题 ≥20px）
function fixFontSizeFloor(html) {
  let count = 0;
  // inline font-size:N(px|pt) → 若换算 px < 下限则提升
  const out = html.replace(/font-size\s*:\s*(\d+(?:\.\d+)?)\s*(px|pt)/gi, (full, val, unit) => {
    let px = parseFloat(val);
    if (unit.toLowerCase() === 'pt') px = px * 1.333; // pt→px
    if (px >= FONT_FLOOR_PX) return full; // 已达标，不动
    const targetPx = px < 13 ? FONT_FLOOR_PX_LARGE : FONT_FLOOR_PX; // 极小（<13px）多半是标题被误压，提升到 20px
    const targetUnit = unit.toLowerCase() === 'pt' ? `${(targetPx / 1.333).toFixed(1)}pt` : `${targetPx}px`;
    count++;
    return `font-size:${targetUnit}`;
  });
  return { html: out, changed: count > 0 };
}

// ── Fix: bare grid columns (v46 实证，display:grid 无列数堆叠) ──────
// display:grid 但无 grid-template-columns → 按 grid 直接子元素数补列数。
// 安全：只给"确实缺列数且子元素数明确"的 grid 补，列数 = min(子数, 4)。
// 用括号深度扫描统计 grid 内直接子元素（不用正则匹配带子标签元素）。
function fixBareGridColumns(html) {
  let changed = false;
  // 找每个 display:grid 的容器开标签
  const re = /<(div|section|ul|main)([^>]*\bstyle="[^"]*display:\s*grid[^"]*"[^>]*)>/g;
  let m;
  const edits = [];
  while ((m = re.exec(html)) !== null) {
    const tag = m[1];
    const attrs = m[2];
    // 已有列数（inline 或 .g2-.g6）跳过
    if (/grid-template-columns/i.test(attrs)) continue;
    if (/\bclass="[^"]*\bg[2-6]\b/.test(attrs)) continue;
    // 找该容器的闭合标签（同名 tag，括号深度）
    const openStart = m.index;
    const closeIdx = findMatchingClose(html, openStart, tag);
    if (closeIdx === -1) continue;
    const inner = html.slice(m.index + m[0].length, closeIdx);
    // 统计直接子元素（顶层 <tag ...> 数量）
    const childCount = countTopLevelChildren(inner);
    if (childCount < 2) continue; // 1 个子元素不需要补列数
    const cols = Math.min(childCount, 4);
    const colsDecl = `grid-template-columns:repeat(${cols},1fr);`;
    // 把 colsDecl 插入 style 末尾（display:grid 后）
    const newAttrs = attrs.replace(/(display:\s*grid\s*;?)/i, `$1${colsDecl}`);
    const newTag = `<${tag}${newAttrs}>`;
    edits.push({ start: m.index, end: m.index + m[0].length, replacement: newTag });
    changed = true;
  }
  // 倒序应用编辑（避免位移）
  for (let i = edits.length - 1; i >= 0; i--) {
    const e = edits[i];
    html = html.slice(0, e.start) + e.replacement + html.slice(e.end);
  }
  return { html, changed };
}

// 从 idx 处的 <tag...> 开始，找匹配的 </tag> 位置（同深度）
function findMatchingClose(html, idx, tag) {
  const openRe = new RegExp(`<${tag}\\b`, 'gi');
  const closeRe = new RegExp(`</${tag}>`, 'gi');
  let depth = 0;
  let i = idx;
  const all = [];
  const or = new RegExp(`<${tag}\\b|</${tag}>`, 'gi');
  or.lastIndex = idx;
  let mm;
  while ((mm = or.exec(html)) !== null) {
    if (mm[0].startsWith('</')) {
      depth--;
      if (depth === 0) return mm.index;
    } else {
      depth++;
    }
  }
  return -1;
}

// 统计 inner 中顶层（深度1）子元素开标签数
function countTopLevelChildren(inner) {
  let count = 0, depth = 0;
  const re = /<(\w+)(\s[^>]*)?\/?>|<\/(\w+)>/g;
  let m;
  while ((m = re.exec(inner)) !== null) {
    if (m[3]) { // close tag
      if (depth > 0) depth--;
    } else { // open tag
      const t = m[1];
      // 自闭合（img/br/hr 等）不计为结构子元素
      if (/^(img|br|hr|meta|link|input|area|base|col|embed|source|track|wbr|path|rect|circle|line|polyline|polygon|ellipse|use|stop)$/i.test(t)) continue;
      if (depth === 0) count++;
      depth++;
    }
  }
  return count;
}

export const FIXES = {
  'inject-data-skeleton': fixInjectDataSkeleton,
  'footer-padding': fixFooterPadding,
  'hardcoded-colors': fixHardcodedColors,
  'footer-consistency': (html, ref) => fixFooterConsistency(html, ref),
  'add-slide-top-bar': fixSlideTopBar,
  'compact-header': fixCompactHeader,
  'normalize-gaps': fixNormalizeGaps,
  'replace-emoji-icons': fixReplaceEmojiWithIcons,
  'div-bare-text': fixDivBareText,
  'body-tag-comment': fixBodyTagComment,
  'gantt-months': fixGanttMonths,
  'table-empty-col': fixTableEmptyTrailingCol,
  'style-semicolon': fixStyleSemicolon,
  'font-size-floor': fixFontSizeFloor,
  'bare-grid-columns': fixBareGridColumns,
};

function parseArgs(argv) {
  const args = { deck: null, fix: null, ref: null, style: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--deck' && argv[i + 1]) { args.deck = argv[++i]; continue; }
    if (a === '--fix' && argv[i + 1]) { args.fix = argv[++i]; continue; }
    if (a === '--ref' && argv[i + 1]) { args.ref = argv[++i]; continue; }
    if (a === '--style' && argv[i + 1]) { args.style = argv[++i]; continue; }
    if (a === '--help' || a === '-h') { printUsage(); process.exit(0); }
  }
  return args;
}

function printUsage() {
  console.log('Usage: node batch-fix.mjs --deck <dir> --fix <name> [--ref <file>] [--style <name>]');
  console.log('');
  console.log('  --deck <dir>    Deck root directory (parent of slides/)');
  console.log('  --fix <name>    Fix to apply:');
  console.log('    footer-padding      Add padding-bottom: 90px to all .page-body');
  console.log('    hardcoded-colors    Replace hex/rgb with var(--xxx) tokens');
  console.log('    footer-consistency  Unify .tech-footer structure (needs --ref)');
  console.log('    add-slide-top-bar   Add .slide-top-bar to all content pages');
  console.log('    compact-header      Add compact-header to high-density pages');
  console.log('    sync-manifest       Sync DECK_MANIFEST from slides/ directory');
  console.log('    sync-notes          Extract <aside class="notes"> into DECK_NOTES');
  console.log('    sync-image-manifest Materialize an all-SKIPPED image-manifest.md from outline.md (only if missing)');
  console.log('    normalize-gaps       Normalize all .page-body gap values to 20px');
  console.log('    replace-emoji-icons  Replace emoji with SVG icons from assets/icons/');
  console.log('    div-bare-text        Wrap bare div text in <span> (never <p>); matches DIV_BARE_TEXT');
  console.log('    body-tag-comment     Move <!-- role --> comment out of <body> opening tag (B2 leak fix)');
  console.log('    fix-page-numbers     Rewrite .page-num/.slide-number text to match manifest order (B1)');
  console.log('    inject-data-skeleton Add data-skeleton="t1" to tpl-<deck> body tags missing it');
  console.log('    all                 Apply all slide-level fixes (except footer-consistency)');
  console.log('  --ref <file>   Reference file for footer-consistency fix');
  console.log('  --style <name>  Template style name (defensive: compact-header skips blacklisted styles)');
}

function loadText(path) {
  return readFileSync(path, 'utf8');
}

function saveText(path, content) {
  writeFileSync(path, content, 'utf8');
}

function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.deck) {
    console.error('Error: --deck <dir> is required.\n');
    printUsage();
    process.exit(2);
  }

  if (!args.fix) {
    console.error('Error: --fix <name> is required.\n');
    printUsage();
    process.exit(2);
  }

  const deckPath = resolve(args.deck);
  const slidesDir = join(deckPath, 'slides');

  if (!existsSync(slidesDir)) {
    console.error(`Error: slides/ directory not found at ${slidesDir}`);
    process.exit(2);
  }

  // Load reference footer if needed
  let referenceFooter = null;
  if (args.fix === 'footer-consistency' || args.fix === 'all') {
    if (args.ref) {
      try {
        referenceFooter = loadText(resolve(args.ref));
      } catch (e) {
        console.error(`Error: cannot read reference file: ${args.ref}`);
        process.exit(2);
      }
    } else if (args.fix === 'footer-consistency') {
      // Auto-detect: use the first slide as reference
      const slides = readdirSync(slidesDir).filter(f => f.endsWith('.html')).sort();
      if (slides.length > 0) {
        referenceFooter = loadText(join(slidesDir, slides[0]));
        console.log(`Auto-detected reference: slides/${slides[0]}`);
      }
    }
  }

  const slides = readdirSync(slidesDir).filter(f => f.endsWith('.html'));
  const fixesToApply = args.fix === 'all'
    ? Object.keys(FIXES).filter(f => f !== 'footer-consistency')
    : [args.fix];

  if (args.fix !== 'all' && !FIXES[args.fix] && args.fix !== 'sync-manifest' && args.fix !== 'sync-notes' && args.fix !== 'sync-image-manifest' && args.fix !== 'fix-page-numbers') {
    console.error(`Error: unknown fix "${args.fix}". Valid: ${Object.keys(FIXES).join(', ')}, sync-manifest, sync-notes, sync-image-manifest, fix-page-numbers, all`);
    process.exit(2);
  }

  // Handle deck-level fixes (operate on index.html / outline.md, not individual slides)
  if (args.fix === 'sync-manifest') {
    syncManifest(deckPath);
    return;
  }
  if (args.fix === 'sync-notes') {
    syncNotes(deckPath);
    return;
  }
  if (args.fix === 'sync-image-manifest') {
    syncImageManifest(deckPath);
    return;
  }
  if (args.fix === 'fix-page-numbers') {
    const n = fixPageNumbers(deckPath);
    console.log(`\nDone. ${n} slides had page-num corrected.`);
    return;
  }
  if (args.fix === 'all') {
    // Apply slide-level fixes first, then deck-level fixes
    // (slide-level logic continues below, we add deck-level at the end)
  }

  let totalChanged = 0;
  for (const file of slides) {
    const filePath = join(slidesDir, file);
    let html = loadText(filePath);
    let fileChanged = 0;

    for (const fixName of fixesToApply) {
      const fixFn = FIXES[fixName];
      const { html: newHtml, changed } = fixName === 'footer-consistency'
        ? fixFn(html, referenceFooter)
        : fixName === 'compact-header'
        ? fixFn(html, args.style)
        : fixFn(html);
      html = newHtml;
      if (changed) fileChanged++;
    }

    if (fileChanged > 0) {
      saveText(filePath, html);
      totalChanged++;
      console.log(`  FIXED: slides/${file} (${fileChanged} fixes applied)`);
    }
  }

  console.log(`\nDone. ${totalChanged}/${slides.length} files modified.`);

  // After all slide-level fixes, run deck-level fixes if --fix all
  if (args.fix === 'all') {
    console.log('');
    syncManifest(deckPath);
    syncNotes(deckPath);
    syncImageManifest(deckPath);
    fixPageNumbers(deckPath);
  }
}

// ESM guard: only run main() when invoked directly via `node batch-fix.mjs ...`,
// not when imported as a module (e.g. by post-process.mjs). resolve() normalizes
// relative CLI invocations to an absolute path for a robust comparison.
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main();
}
