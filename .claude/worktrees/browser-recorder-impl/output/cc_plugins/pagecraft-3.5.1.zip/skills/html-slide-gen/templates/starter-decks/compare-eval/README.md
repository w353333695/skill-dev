# compare-eval · 对比评测 / 选型

10-slide comparison-evaluation deck: cover, evaluation methodology (6 weighted dimensions), three candidate profiles, weighted scoring matrix, single-dimension deep dive, pros/cons double-column, weighted verdict card, recommendation summary + next-step selection plan.

Objective, impartial dark palette — midnight ink-blue (`#1e3a5f` / `#2563eb`) on slate-900 with a single amber (`#f59e0b`) reserved for marking the leading/recommended option. Hard-edge scoring matrix, no shadows, restrained scoring (green ≥9 / amber 7–8.9 / red <7).

**Use when:** vendor / tool selection, technology evaluation, RFP scoring, build-vs-buy, "honest review" comparisons (cloud DBs, BI tools, frameworks, SaaS).
**Feel:** a procurement evaluation report — data-driven, weighted, every page is a reproducible score; the amber column marks the leader without cheerleading.

---

## 区分度（不与同类 deck 混淆）

- **≠ hermes-cyber-terminal**：那是 CLI / agent 评测（CRT 扫描线 + 终端主题绑死）。compare-eval 是**泛化的对比评测骨架**（任意选型场景），主题由 `color-schemes.json` 注入、不绑终端。
- **≠ consultant-strategy 的 comparison-table**：那是方案对标（推荐列高亮、纯文字）。compare-eval 是**多维加权评分矩阵**（带权重列、0–10 评分单元格、勾叉标记、加权总分行、可复现裁决）。
- 标志组件：`.ce-eval-matrix`（评分矩阵 = 评测身份证）、`.ce-verdict`（裁决卡）、`.ce-dim-deepdive`（维度深挖基准）、`.ce-pros-cons`（优劣双栏）。

## 配色

默认 `midnight-ink`（午夜墨蓝 + amber 优胜标记，深色客观基调）。已接入 `switch-theme.mjs`，可一键切换：

```bash
node scripts/switch-theme.mjs --deck templates/starter-decks/compare-eval --scheme consulting-navy  # 深蓝投行风
node scripts/switch-theme.mjs --deck templates/starter-decks/compare-eval --scheme nord-frost       # 冷静学术风
```

配套方案见 `scripts/color-schemes.json`（40 个预设）。客观评测推荐中性深色系，避免单一厂商品牌色造成偏袒观感。

## 结构

10 页叙事弧 = **评测方法论 → 参评方画像 → 评分矩阵 → 维度深挖 → 优劣对照 → 加权裁决 → 推荐结论**：

| 段落 | 页 | 角色 |
|------|-----|------|
| 开篇 | 01-02 | cover（评测报告式）· eval-scope（6 维度加权模型） |
| 参评方 | 03-05 | candidate-a · candidate-b · candidate-c（统一画像卡） |
| 评测 | 06-08 | eval-matrix（评分矩阵★）· dim-deepdive（维度深挖）· pros-cons（优劣双栏） |
| 裁决 | 09-10 | verdict（加权裁决卡★）· recommendation（推荐结论 + 下一步选型） |

完整角色目录与替换键见 [`slide-roles.md`](slide-roles.md)。

## 用法

复制本目录到产出目录后修改 `slides/*.html` 中的 `data-replace="key"` 内容。示例填充为「三大主流云原生数据库对比评测」（典型技术选型评测，替换键示意最清晰）。

```bash
# 预览
open index.html
# 截图所有页
node scripts/preview_slides.mjs --slides slides --out /tmp/preview
# 导出单文件 HTML
node scripts/export_single.mjs --deck . --out ../compare-eval.html
# 导出 PPTX
node scripts/export_pptx.mjs --slides slides --out ../compare-eval.pptx --mode editable
```

## 设计依据

布局参考 `references/layout-catalog.md` L12（表格）/ L24（对比）/ L10（数据亮点）；评分矩阵为 compare-eval 原创 `ce-*` 组件（L24 纯文字对比凑不出权重+评分单元格，故新建）。详见 `docs/starter-decks-expansion-plan.md` 与 `docs/horizontal-decks-build-prompts.md`。
