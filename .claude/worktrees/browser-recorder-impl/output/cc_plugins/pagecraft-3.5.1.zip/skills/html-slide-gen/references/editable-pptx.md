# PPTX 可编辑导出：Hybrid V2 模式说明

本文档说明 **Hybrid V2 模式**的 PPTX 导出原理。

> **核心原理（V2）**：导出时注入系统字体 CSS 统一字体对齐，TreeWalker 全元素文本提取覆盖所有可见文字，原生形状重建（纯色+渐变），仅复杂 CSS 特性（backdrop-filter 模糊、mix-blend-mode、复杂 SVG）保留为截图背景。
>
> **HTML 生成阶段无需遵守任何特殊规则**——渐变、SVG、背景图、CSS 动画随便用。导出引擎自动适配。

---

## 导出流程

1. `validate-pptx.mjs --mode editable` 预检（仅检查内容溢出和尺寸问题，无阻断性 ERROR）
2. `export_pptx.mjs --mode editable`（hybrid v2）导出：
   - 注入系统字体 CSS（Inter→Segoe UI/SF Pro, Noto Sans SC→Microsoft YaHei/PingFang SC）
   - TreeWalker 遍历所有可见文本节点，提取为可编辑文本框
   - 纯色+边框 DIV → PPTX 原生形状
   - 渐变背景 → 保留在截图中
   - backdrop-filter / blend-mode → 保留在截图中
   - 文字元素以 `visibility:hidden` 隐藏后截图（不含文字）
3. 生成的 PPTX：文字可双击编辑，形状可调色/调边框/调圆角，复杂装饰以截图背景保留

---

## 字体映射表

导出时自动注入以下字体映射，确保浏览器渲染和 PPTX 渲染使用相同字体：

| Web 字体 | macOS | Windows |
|----------|-------|---------|
| Inter, Roboto, Open Sans | SF Pro Display | Segoe UI |
| Noto Sans SC, PingFang SC | PingFang SC | Microsoft YaHei |
| Playfair Display, Noto Serif SC | Georgia | Times New Roman |
| JetBrains Mono, IBM Plex Mono | SF Mono | Consolas |

---

## 自动处理（零约束）

### 截图保留（全自动）

| 特性 | 说明 |
|------|------|
| CSS 渐变（linear/radial-gradient） | 截图保留完整渐变效果 |
| DIV background-image | 截图保留背景图片 |
| SVG 元素 | 截图保留 SVG 渲染结果 |
| backdrop-filter | 截图保留模糊效果 |
| mix-blend-mode | 截图保留混合效果 |

### 原生 PPTX 元素（可直接编辑）

| 特性 | 说明 |
|------|------|
| 所有可见文字 | TreeWalker 全覆盖——无论 p/h*/li/div/span，均可编辑 |
| 纯色背景+边框 DIV | 自动转为可编辑 PPTX 形状（颜色/边框/圆角） |
| `::before`/`::after` 伪元素 | 有背景色的伪元素转为原生形状 |
| box-shadow | 转换为 PPTX 外阴影 |

---

## 导出命令

```bash
# 1. 预检（所有检查均为 WARNING，不阻断）
node scripts/validate-pptx.mjs --slides slides-output/<name>/export/<name>-live/slides --mode editable

# 2. 导出 hybrid v2 PPTX（推荐）
node scripts/export_pptx.mjs --slides slides-output/<name>/export/<name>-live/slides --out slides-output/<name>/export/<标题>.pptx --mode editable

# 3. 图片模式（editable 遇到问题时兜底）
node scripts/export_pptx.mjs --slides slides-output/<name>/export/<name>-live/slides --out slides-output/<name>/export/<标题>.pptx --mode image
```

---
