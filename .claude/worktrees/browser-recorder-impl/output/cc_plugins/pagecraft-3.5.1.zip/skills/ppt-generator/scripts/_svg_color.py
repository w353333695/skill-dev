# -*- coding: utf-8 -*-
"""Color resolution for PPTX → SVG conversion.

Handles theme color parsing, scheme color resolution, lumMod/lumOff adjustments,
solidFill/schemeClr extraction, and lstStyle color inheritance.
"""

import zipfile
from xml.etree import ElementTree as ET

from _svg_constants import A_NS, MSO_TO_SCHEME


# ---------------------------------------------------------------------------
# Theme color map
# ---------------------------------------------------------------------------

def build_theme_color_map(pptx_path):
    """从 theme1.xml 解析 clrScheme → {scheme_tag: hex_rgb}"""
    colors = {}

    try:
        with zipfile.ZipFile(str(pptx_path), "r") as zf:
            theme_files = [n for n in zf.namelist()
                           if n.startswith("ppt/theme/") and n.endswith(".xml")]
            if not theme_files:
                return {}

            with zf.open(theme_files[0]) as f:
                tree = ET.parse(f)
                root = tree.getroot()

            for elem in root.iter(f"{{{A_NS}}}clrScheme"):
                for child in elem:
                    tag = child.tag.replace(f"{{{A_NS}}}", "")
                    srgb = child.find(f"{{{A_NS}}}srgbClr")
                    sys_clr = child.find(f"{{{A_NS}}}sysClr")
                    if srgb is not None:
                        colors[tag] = srgb.get("val", "")
                    elif sys_clr is not None:
                        colors[tag] = sys_clr.get("lastClr", sys_clr.get("val", ""))
    except Exception:
        return {}

    # 标准 Office 主题映射 fallback（自定义主题可能缺少 bg1/tx1/bg2/tx2）
    std_map = {"bg1": "lt1", "tx1": "dk1", "bg2": "lt2", "tx2": "dk2"}
    for alias, target in std_map.items():
        if alias not in colors and target in colors:
            colors[alias] = colors[target]

    return colors


# ---------------------------------------------------------------------------
# Luminance modification
# ---------------------------------------------------------------------------

def _apply_lum_mod(hex_color, lum_mod_val):
    """应用 lumMod 亮度修改，lum_mod_val 是百分比 * 1000（如 50000 = 50%）"""
    if lum_mod_val is None:
        return hex_color
    try:
        factor = int(lum_mod_val) / 100000
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        r = min(255, max(0, round(r * factor)))
        g = min(255, max(0, round(g * factor)))
        b = min(255, max(0, round(b * factor)))
        return f"{r:02X}{g:02X}{b:02X}"
    except Exception:
        return hex_color


# ---------------------------------------------------------------------------
# Color resolution from python-pptx objects
# ---------------------------------------------------------------------------

def resolve_color(fore_color, theme_map):
    """统一解析颜色 → hex RGB (不带 #)"""
    try:
        if fore_color.type is None:
            return None
        if fore_color.type == 1:  # RGB
            return str(fore_color.rgb)
        elif fore_color.type == 2:  # SCHEME
            idx = int(fore_color.theme_color)
            tag = MSO_TO_SCHEME.get(idx)
            if tag and tag in theme_map:
                return theme_map[tag]
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# XML-level color helpers (unified patterns)
# ---------------------------------------------------------------------------

def resolve_solid_fill(solid_fill_elem, theme_map):
    """解析 <a:solidFill> 元素 → (hex_color, alpha_fraction)，或 (None, None)。

    处理 srgbClr / schemeClr 子元素，应用 lumMod，提取 alpha。
    """
    if solid_fill_elem is None:
        return None, None

    srgb = solid_fill_elem.find(f"{{{A_NS}}}srgbClr")
    scheme = solid_fill_elem.find(f"{{{A_NS}}}schemeClr")

    hex_color = None
    color_elem = None

    if srgb is not None:
        hex_color = srgb.get("val")
        color_elem = srgb
        lum = srgb.find(f"{{{A_NS}}}lumMod")
        if lum is not None:
            hex_color = _apply_lum_mod(hex_color, lum.get("val"))
    elif scheme is not None:
        scheme_val = scheme.get("val")
        color_elem = scheme
        if scheme_val and theme_map:
            hex_color = theme_map.get(scheme_val)
            lum = scheme.find(f"{{{A_NS}}}lumMod")
            if lum is not None and hex_color:
                hex_color = _apply_lum_mod(hex_color, lum.get("val"))

    if hex_color is None:
        return None, None

    # Extract alpha
    alpha = None
    if color_elem is not None:
        alpha_elem = color_elem.find(f"{{{A_NS}}}alpha")
        if alpha_elem is not None:
            try:
                alpha = int(alpha_elem.get("val")) / 100000
            except (ValueError, TypeError):
                pass

    return hex_color, alpha


def resolve_fill_ref(fill_ref_elem, theme_map):
    """解析 style 中的 <a:fillRef> 元素 → hex_color 或 None。

    当 idx > 0 时读取 schemeClr / srgbClr。
    """
    if fill_ref_elem is None:
        return None

    idx = fill_ref_elem.get("idx")
    if not idx or int(idx) <= 0:
        return None

    schemeClr = fill_ref_elem.find(f"{{{A_NS}}}schemeClr")
    if schemeClr is not None:
        scheme_val = schemeClr.get("val")
        if scheme_val and theme_map:
            return theme_map.get(scheme_val)

    srgbClr = fill_ref_elem.find(f"{{{A_NS}}}srgbClr")
    if srgbClr is not None:
        return srgbClr.get("val")

    return None


def _color_from_lstStyle(lstStyle, theme_map):
    """从 lstStyle 的 lvl1pPr/defRPr/solidFill 提取颜色 hex，无则返回 None"""
    if lstStyle is None:
        return None

    lvl1 = lstStyle.find(f"{{{A_NS}}}lvl1pPr")
    if lvl1 is None:
        return None
    defRPr = lvl1.find(f"{{{A_NS}}}defRPr")
    if defRPr is None:
        return None
    solidFill = defRPr.find(f"{{{A_NS}}}solidFill")
    if solidFill is None:
        return None

    hex_color, _ = resolve_solid_fill(solidFill, theme_map)
    return hex_color


def _resolve_font_size_from_styles(*lst_styles):
    """遍历 lstStyle 元素，返回第一个 lvl1pPr/defRPr/@sz 字号 (pt)，或 None"""
    for lstStyle in lst_styles:
        if lstStyle is None:
            continue
        lvl1 = lstStyle.find(f"{{{A_NS}}}lvl1pPr")
        if lvl1 is None:
            continue
        defRPr = lvl1.find(f"{{{A_NS}}}defRPr")
        if defRPr is None:
            continue
        sz = defRPr.get("sz")
        if sz:
            return int(sz) / 100
    return None


def _collect_shape_colors(shapes, theme_map, color_counter):
    """递归收集形状的填充色和描边色频率"""
    for shape in shapes:
        try:
            if shape.shape_type == 6:  # GROUP
                _collect_shape_colors(shape.shapes, theme_map, color_counter)
                continue
        except Exception:
            pass
        try:
            fill = shape.fill
            if fill.type is not None:
                c = resolve_color(fill.fore_color, theme_map)
                if c:
                    color_counter[c] = color_counter.get(c, 0) + 1
        except Exception:
            pass
        try:
            line = shape.line
            # 只收集纯色线条颜色，跳过渐变（访问 line.color 会触发 python-pptx
            # 内部状态变化，导致后续渲染时 line.fill.type 从 GRADIENT 变为 SOLID）
            if line.fill.type is not None and line.fill.type != 3:  # 3 = GRADIENT
                c = resolve_color(line.color, theme_map)
                if c:
                    color_counter[c] = color_counter.get(c, 0) + 1
        except Exception:
            pass
