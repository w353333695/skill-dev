"""Design spec generation for PPTX template extraction."""


def _pt_to_px(pt):
    """将 pt 转换为 px（SVG 使用 px 单位）"""
    return round(pt * 4 / 3)


def _role_from_placeholder(placeholder):
    """从占位符推断文本角色

    对多词前缀的占位符（如 CHAPTER_TITLE、TOC_ITEM_1），
    先尝试完整匹配，再尝试前缀匹配。
    """
    ROLE_MAP = {
        "TITLE": "main_title",
        "SUBTITLE": "subtitle",
        "AUTHOR": "author",
        "PRESENTER": "presenter",
        "DATE": "date",
        "ORGANIZATION": "organization",
        "INSTITUTION": "institution",
        "PAGE_TITLE": "page_title",
        "CHAPTER_NUM": "chapter_number",
        "CHAPTER_TITLE": "chapter_title",
        "CHAPTER_DESC": "chapter_description",
        "CHAPTER_SUBTITLE": "chapter_subtitle",
        "PAGE_NUM": "page_number",
        "SECTION_NAME": "section_name",
        "THANK_YOU": "closing_title",
        "CONTACT_INFO": "contact_info",
        "TAGLINE": "tagline",
        "COPYRIGHT": "copyright",
        "CLOSING_MESSAGE": "closing_message",
        "LOGO": "logo",
        "LOGO_LARGE": "logo_large",
        "CONTENT_AREA": "content_area",
    }
    key = placeholder.strip("{}")

    # 精确匹配
    if key in ROLE_MAP:
        return ROLE_MAP[key]

    # TOC_ITEM 前缀匹配
    if key.startswith("TOC_ITEM"):
        return "toc_item"

    return "text"


def _role_display_name(role):
    """将角色 ID 映射为用户可读的中文名"""
    DISPLAY_MAP = {
        "main_title": "主标题",
        "subtitle": "副标题",
        "author": "作者",
        "presenter": "汇报人",
        "date": "日期",
        "organization": "组织",
        "institution": "机构",
        "page_title": "页面标题",
        "chapter_number": "章节编号",
        "chapter_title": "章节标题",
        "chapter_description": "章节描述",
        "chapter_subtitle": "章节副标题",
        "page_number": "页码",
        "section_name": "章节名称",
        "toc_item": "目录条目",
        "closing_title": "感谢语",
        "contact_info": "联系方式",
        "tagline": "标语",
        "copyright": "版权",
        "closing_message": "结束语",
        "logo": "Logo",
        "logo_large": "大Logo",
        "content_area": "内容区域",
        "text": "文本",
    }
    return DISPLAY_MAP.get(role, role)


def _page_type_cn(page_type):
    """页面类型 → 中文名"""
    MAP = {
        "cover": "封面页",
        "toc": "目录页",
        "chapter": "章节页",
        "content": "内容页",
        "ending": "结尾页",
    }
    return MAP.get(page_type, page_type)


def _collect_page_semantics(template_data, decision=None):
    """从 template_data 和 decision 中提取每页语义信息

    优先使用 decision.pages 中的 LLM 补充信息（layout），
    texts 的 font_size_px/color 优先取自 decision（LLM 可能修正），
    缺失时从 template_data.shapes 中补充。
    自动将 decision 中的旧模板名（如 slide_02_unknown）映射到标准名（如 02_toc）。
    """
    slides = template_data.get("slides", [])
    semantics = {}

    # 构建旧模板名→标准模板名映射
    standard_templates = template_data.get("standard_templates", {})
    type_to_template = template_data.get("type_to_template", {})
    unknown_to_standard = {}
    for slide_info in slides:
        assigned = slide_info.get("assigned_template", "")
        if assigned and assigned not in standard_templates.values():
            # 从 type_to_template 推断标准名
            slide_type = slide_info.get("type", "")
            if slide_type and slide_type in type_to_template:
                std_name = type_to_template[slide_type]
                svg_file = slide_info.get("svg_file", "")
                # 尝试从 svg_file 提取旧名
                for f in template_data.get("svg_files", []):
                    if f.startswith(f"slide_{slide_info['slide_index'] + 1:02d}"):
                        unknown_to_standard[f.replace(".svg", "")] = std_name
                        break
                # 也通过 slide_index 直接查找
                for svg_file, _assigned in template_data.get("standard_templates", {}).items():
                    pass  # standard_templates maps name→slide_index

    # 从 replacements 或 pages 构建一个旧名→数据的映射
    # 首先处理 decision.pages 中的信息
    decision_data_by_name = {}
    if decision:
        for page in decision.get("pages", []):
            tname = page.get("template", "")
            decision_data_by_name[tname] = page

    # 构建旧名→标准名的精确映射（通过 slide_index）
    old_to_standard = {}
    if decision and "pages" in decision:
        for page in decision["pages"]:
            slide_idx = page.get("slide_index")
            old_name = page.get("template", "")
            for slide_info in slides:
                if slide_info.get("slide_index") == slide_idx:
                    assigned = slide_info.get("assigned_template", "")
                    if assigned:
                        old_to_standard[old_name] = assigned
                    break

    # 1. 从 decision 中提取 LLM 补充的语义和文本映射
    if decision:
        for page in decision.get("pages", []):
            old_name = page.get("template", "")
            template_name = old_to_standard.get(old_name, old_name)
            semantics[template_name] = {
                "layout_description": page.get("layout", {}).get("description", ""),
                "bg_description": page.get("layout", {}).get("bg_description", ""),
                "decorations": page.get("layout", {}).get("decorations", []),
                "texts": page.get("texts", []),
            }

    # 2. 从 template_data 补充缺失的 font_size_px 和 color，
    #    当 decision 未提供 texts 时，从 shapes 创建文本条目
    for slide_info in slides:
        template_name = slide_info.get("assigned_template", "")
        if not template_name:
            continue

        sem = semantics.setdefault(template_name, {
            "layout_description": "",
            "bg_description": "",
            "decorations": [],
            "texts": [],
        })

        # 从 shapes 收集文本信息
        shapes_texts = []
        for sh in slide_info.get("shapes", []):
            text = sh.get("text", "").strip()
            if not text or len(text) > 100:
                continue
            pos = sh.get("position", {})
            font_pt = sh.get("font_size_pt")
            if font_pt is None:
                font_info = sh.get("font", {})
                font_pt = font_info.get("size_pt")
            if font_pt is None:
                font_pt = slide_info.get("features", {}).get("max_font_size_pt", 18)
            font_info = sh.get("font", {})
            shapes_texts.append({
                "original": text,
                "font_size_px": _pt_to_px(font_pt),
                "color": sh.get("fill", ""),
                "font_weight": "Bold" if font_info.get("bold") else "Regular",
            })

        # 如果 decision 未提供 texts，从 shapes 创建
        existing_texts = sem.get("texts", [])
        if not existing_texts:
            sem["texts"] = shapes_texts
        else:
            # 补充已有 texts 中缺失的 font_size_px、color、font_weight
            shapes_by_text = {st["original"]: st for st in shapes_texts}
            # 也按首行索引（多行文本）
            for st in shapes_texts:
                first_line = st["original"].split("\n")[0].strip()
                if first_line and first_line != st["original"]:
                    shapes_by_text.setdefault(first_line, st)

            # 默认文字色：从 theme 中取 tx1
            default_color = "#" + template_data.get("color_theme", {}).get("colors", {}).get("tx1", "36393B")
            if not default_color.startswith("#"):
                default_color = "#" + default_color

            for t in existing_texts:
                original = t.get("original", "")
                if original and original in shapes_by_text:
                    info = shapes_by_text[original]
                    if not t.get("font_size_px"):
                        t["font_size_px"] = info["font_size_px"]
                    if not t.get("color"):
                        t["color"] = info.get("color") or default_color
                    if not t.get("font_weight"):
                        t["font_weight"] = info.get("font_weight", "Regular")

        # 补充 decorations（从非文本 shape）
        if not sem.get("decorations"):
            decorations = []
            for sh in slide_info.get("shapes", []):
                if sh.get("type") == "PLACEHOLDER (14)":
                    continue
                pos = sh.get("position", {})
                fill = sh.get("fill", "")
                if fill:
                    decorations.append({
                        "type": sh.get("type", "").split(" ")[0].lower(),
                        "position": f"x={pos.get('x')}, y={pos.get('y')}, w={pos.get('w')}, h={pos.get('h')}",
                        "color": fill,
                    })
            if decorations:
                sem["decorations"] = decorations

    return semantics


def _derive_font_size_hierarchy(semantics):
    """从所有页面的文本字号推导字号层级表

    返回 [(level, purpose, size_px, weight)]，按 level 去重保留最大字号。
    字重取该层级中最常见的值。
    """
    # 收集 (size_px, weight) 对
    size_weights = {}
    for sem in semantics.values():
        for t in sem.get("texts", []):
            fs = t.get("font_size_px", 0)
            if fs > 0:
                fw = t.get("font_weight", "Regular")
                if fs not in size_weights:
                    size_weights[fs] = []
                size_weights[fs].append(fw)

    if not size_weights:
        return []

    sorted_sizes = sorted(size_weights.keys(), reverse=True)
    seen_levels = set()
    tiers = []

    LEVEL_MAP = [
        (48, "H1", "封面主标题"),
        (36, "H1", "封面主标题"),
        (32, "H2", "页面标题"),
        (28, "H3", "章节/卡片标题"),
        (24, "H3", "章节/卡片标题"),
        (20, "H4", "卡片标题"),
        (18, "P", "正文内容"),
        (14, "Sub", "辅助说明"),
        (0,  "XS", "页码/版权"),
    ]

    for sz in sorted_sizes:
        for threshold, level, purpose in LEVEL_MAP:
            if sz >= threshold:
                if level not in seen_levels:
                    seen_levels.add(level)
                    # 取该字号最常见的字重
                    weights = size_weights[sz]
                    weight = max(set(weights), key=weights.count) if weights else "Regular"
                    tiers.append((level, purpose, sz, weight))
                break

    return tiers


def _derive_color_groups(theme_colors):
    """将 PPTX theme color 标签映射为语义分组（主色系/文字色系/中性色）"""
    primary_keys = ["accent1", "accent2", "accent3", "accent4", "accent5", "accent6"]
    text_keys = ["tx1", "tx2", "dk1", "dk2"]
    bg_keys = ["bg1", "bg2", "lt1", "lt2"]
    link_keys = ["hlink", "folHlink"]

    primary = {}
    text = {}
    bg = {}
    other = {}

    for tag, color in sorted(theme_colors.items()):
        hex_color = f"#{color}" if not color.startswith("#") else color
        if tag in primary_keys:
            primary[tag] = hex_color
        elif tag in text_keys:
            text[tag] = hex_color
        elif tag in bg_keys:
            bg[tag] = hex_color
        elif tag in link_keys:
            other[tag] = hex_color
        else:
            other[tag] = hex_color

    return primary, text, bg, other


_STYLE_TONE_MAP = {
    ("light", "minimal"): "简洁专业",
    ("light", "moderate"): "清新现代",
    ("dark", "minimal"): "沉稳极简",
    ("dark", "moderate"): "高端深色",
}


def generate_design_spec(template_data, decision=None):
    """从 template_data 和 decision 生成完整 design_spec.md（11 章，对齐内置模板）"""
    canvas = template_data["canvas"]
    viewBox = canvas.get("viewBox", f"0 0 {canvas['width']} {canvas['height']}")
    slides = template_data["slides"]
    theme_colors = template_data.get("color_theme", {}).get("colors", {})
    style_tags = template_data.get("style_tags", {})
    theme_mode = style_tags.get("theme_mode", "light")
    palette_complexity = style_tags.get("palette_complexity", "moderate")
    fonts = template_data.get("fonts", {}).get("all", [])
    title_fonts = template_data.get("fonts", {}).get("title", [])
    body_fonts = template_data.get("fonts", {}).get("body", [])
    tone = _STYLE_TONE_MAP.get((theme_mode, palette_complexity), "专业通用")

    # 收集配色使用位置
    color_usage = {}
    for slide_info in slides:
        slide_type = slide_info.get("type", "unknown")
        for color, count in slide_info.get("colors", {}).items():
            if color not in color_usage:
                color_usage[color] = {"count": 0, "pages": []}
            color_usage[color]["count"] += count
            if slide_type not in color_usage[color]["pages"]:
                color_usage[color]["pages"].append(slide_type)

    # 提取页面语义
    semantics = _collect_page_semantics(template_data, decision)

    # 配色语义分组
    primary, text_colors, bg_colors, other_colors = _derive_color_groups(theme_colors)

    # 字号层级
    font_hierarchy = _derive_font_size_hierarchy(semantics)

    lines = []

    # === 一、模板概述 ===
    lines.extend([
        "# 设计规范 (PPTX 模板提取)",
        "",
        "## 一、模板概述",
        "",
        "| 属性 | 描述 |",
        "| ---- | ---- |",
        "| **模板来源** | PPTX 模板提取（选项 C） |",
        "| **适用场景** | 基于用户 PPTX 模板的自定义演示 |",
        f"| **设计调性** | {tone} |",
        f"| **主题模式** | {'深色' if theme_mode == 'dark' else '亮色'}主题 |",
        "",
        "---",
        "",
    ])

    # === 二、画布规范 ===
    margin = "左右 40px，上 10px，下 60px"
    safe_w = canvas['width'] - 80
    safe_h = canvas['height'] - 70
    lines.extend([
        "## 二、画布规范",
        "",
        "| 属性 | 值 |",
        "| ---- | ---- |",
        f"| **格式** | PPT 16:9 |",
        f"| **尺寸** | {canvas['width']} × {canvas['height']} px |",
        f"| **viewBox** | `{viewBox}` |",
        f"| **页面边距** | {margin} |",
        f"| **内容安全区** | x: 40–{canvas['width'] - 40}, y: 90–{canvas['height'] - 60} |",
        "",
        "---",
        "",
    ])

    # === 三、配色方案 ===
    lines.append("## 三、配色方案")
    lines.append("")

    # 主色系
    if primary:
        lines.append("### 主色系")
        lines.append("")
        lines.append("| 角色 | 色值 | 说明 | PPTX 标签 |")
        lines.append("| ---- | ---- | ---- | --------- |")
        accent_hints = {
            "accent1": "主强调色",
            "accent2": "辅助强调色",
            "accent3": "第三强调色",
            "accent4": "第四强调色",
            "accent5": "第五强调色",
            "accent6": "第六强调色",
        }
        for tag, color in primary.items():
            hint = accent_hints.get(tag, "强调色")
            lines.append(f"| 强调色 | `{color}` | {hint} | `{tag}` |")
        lines.append("")

    # 文字色系
    if text_colors:
        lines.append("### 文字色系")
        lines.append("")
        lines.append("| 角色 | 色值 | PPTX 标签 |")
        lines.append("| ---- | ---- | --------- |")
        for tag, color in text_colors.items():
            role = "正文色" if tag in ("tx1", "tx2") else "深色"
            lines.append(f"| {role} | `{color}` | `{tag}` |")
        lines.append("")

    # 背景色系
    if bg_colors:
        lines.append("### 背景/中性色")
        lines.append("")
        lines.append("| 角色 | 色值 | PPTX 标签 |")
        lines.append("| ---- | ---- | --------- |")
        for tag, color in bg_colors.items():
            role = "主背景" if tag in ("bg1", "lt1") else "次背景"
            lines.append(f"| {role} | `{color}` | `{tag}` |")
        lines.append("")

    # 实际使用颜色
    if color_usage:
        lines.append("### 实际使用颜色统计")
        lines.append("")
        lines.append("| 色值 | 使用频次 | 出现页面 |")
        lines.append("| ---- | -------- | -------- |")
        for color, info in sorted(color_usage.items(), key=lambda x: -x[1]["count"]):
            pages_str = ", ".join(info["pages"])
            lines.append(f"| `#{color}` | {info['count']} | {pages_str} |")
        lines.append("")

    lines.extend([
        "---",
        "",
    ])

    # === 四、排版体系 ===
    lines.extend([
        "## 四、排版体系",
        "",
        "### 字体方案",
        "",
        "| 字体 | 用途 |",
        "| ---- | ---- |",
    ])
    for f in title_fonts:
        lines.append(f"| {f} | 标题 |")
    for f in body_fonts:
        lines.append(f"| {f} | 正文 |")
    for f in fonts:
        if f not in title_fonts and f not in body_fonts:
            lines.append(f"| {f} | 其他 |")

    # 字体栈
    all_fonts = title_fonts + body_fonts + [f for f in fonts if f not in title_fonts and f not in body_fonts]
    if all_fonts:
        font_stack = ", ".join(f'"{f}"' for f in all_fonts[:4])
        lines.append(f"")
        lines.append(f"**字体栈**: `{font_stack}, sans-serif`")

    lines.append(f"")

    # 字号层级表
    if font_hierarchy:
        lines.extend([
            "### 字号层级",
            "",
            "| 层级 | 用途 | 字号 | 字重 |",
            "| ---- | ---- | ---- | ---- |",
        ])
        for level, purpose, sz, weight in font_hierarchy:
            lines.append(f"| {level} | {purpose} | {sz}px | {weight} |")
        lines.append("")

    lines.extend([
        "---",
        "",
    ])

    # === 五、页面结构 ===
    lines.extend([
        "## 五、页面结构",
        "",
        "### 通用布局",
        "",
        "| 区域 | 位置/高度 | 内容说明 |",
        "| ---- | --------- | -------- |",
        f"| **页眉** | y=0, h=70px | 页面标题 + 装饰线 |",
        f"| **内容区** | y=90, h={(safe_h - 90)}px | 主要内容区域 |",
        f"| **页脚** | y={canvas['height'] - 60}, h=60px | 章节标识 + 页码 |",
        "",
        "### 装饰设计",
        "",
    ])
    # 收集所有页面的装饰元素描述
    all_decorations = set()
    for sem in semantics.values():
        for d in sem.get("decorations", []):
            if isinstance(d, str):
                all_decorations.add(d)
            elif isinstance(d, dict):
                all_decorations.add(f"{d.get('type', '')} ({d.get('color', '')})")
    if all_decorations:
        for d in sorted(all_decorations):
            lines.append(f"- {d}")
    else:
        lines.append("- 按原始 PPTX 模板布局装饰")

    lines.extend([
        "",
        "---",
        "",
    ])

    # === 六、页面类型 ===
    lines.extend([
        "## 六、页面类型",
        "",
    ])

    type_to_template = template_data.get("type_to_template", {})
    template_to_type = {v: k for k, v in type_to_template.items()}
    page_order = ["01_cover", "02_toc", "03_chapter", "04_content", "05_ending"]
    page_count = 0

    for template_name in page_order:
        if template_name not in semantics:
            continue
        page_count += 1
        sem = semantics[template_name]
        page_type = template_to_type.get(template_name, "unknown")
        cn_name = _page_type_cn(page_type)

        lines.append(f"### {page_count}. {cn_name} ({template_name}.svg)")
        lines.append("")

        if sem.get("layout_description"):
            lines.append(f"- **布局**: {sem['layout_description']}")
        if sem.get("bg_description"):
            lines.append(f"- **背景**: {sem['bg_description']}")

        if sem.get("decorations"):
            dec_lines = []
            for d in sem["decorations"]:
                if isinstance(d, str):
                    dec_lines.append(d)
                elif isinstance(d, dict):
                    dec_lines.append(f"{d.get('type', '')} ({d.get('color', '')})")
            if dec_lines:
                lines.append(f"- **装饰**: {'、'.join(dec_lines)}")

        # 文本占位符表格
        text_items = [t for t in sem.get("texts", []) if t.get("placeholder")]
        if text_items:
            lines.append("")
            lines.append("| 占位符 | 原始文本 | 角色 | 字号 | 颜色 |")
            lines.append("|--------|---------|------|------|------|")
            for t in text_items:
                placeholder = t.get("placeholder", "")
                original = t.get("original", "")
                role = _role_from_placeholder(placeholder) if placeholder else "text"
                role_cn = _role_display_name(role)
                font_size = t.get("font_size_px", "")
                color = t.get("color", "")
                fs_str = f"{font_size}px" if font_size else ""
                lines.append(f"| `{placeholder}` | {original} | {role_cn} | {fs_str} | {color} |")

        lines.append("")

    lines.extend([
        "---",
        "",
    ])

    # === 七、布局模式 ===
    lines.extend([
        "## 七、布局模式",
        "",
        "| 模式 | 适用场景 |",
        "| ---- | -------- |",
        "| **单栏居中** | 封面、结语 |",
        "| **上下分栏** | 标题 + 内容 |",
        "| **左右分栏** | 图文混排、目录 |",
        "| **三栏卡片** | 并列要点 |",
        "| **表格布局** | 数据展示 |",
        "| **自由布局** | 章节过渡页 |",
        "",
        "---",
        "",
    ])

    # === 八、间距规范 ===
    lines.extend([
        "## 八、间距规范",
        "",
        "| 元素 | 数值 |",
        "| ---- | ---- |",
        "| 卡片间距 | 20px |",
        "| 内容块间距 | 24px |",
        "| 卡片内边距 | 20px |",
        "| 卡片圆角 | 8px |",
        "| 图标与文字 | 12px |",
        "",
        "---",
        "",
    ])

    # === 九、SVG 技术约束 ===
    lines.extend([
        "## 九、SVG 技术约束",
        "",
        "### 必须遵守",
        "",
        f"1. viewBox: `{viewBox}`",
        "2. 背景使用 `<rect>` 元素",
        "3. 文本换行使用 `<tspan>`（禁止 `<foreignObject>`）",
        "4. 透明度使用 `fill-opacity` / `stroke-opacity`，禁止 `rgba()`",
        "5. 禁止使用：`clipPath`、`mask`、`<style>`、`class`（内容元素）、`foreignObject`",
        "6. 禁止使用：`textPath`、`animate*`、`script`、`marker`/`marker-end`",
        "7. 箭头使用 `<polygon>` 三角形替代 `<marker>`",
        "8. 渐变使用 `<defs>` 定义 `<linearGradient>`",
        "",
        "### PPT 兼容性规则",
        "",
        '- 禁止 `<g opacity="...">`（组透明度），每个子元素单独设置',
        "- 图片透明度使用遮罩层替代",
        "- 仅使用内联样式，禁止外部 CSS 和 `@font-face`",
        "",
        "---",
        "",
    ])

    # === 十、占位符规范 ===
    lines.extend([
        "## 十、占位符规范",
        "",
        "| 占位符 | 说明 | 默认角色 |",
        "| ------ | ---- | -------- |",
        "| `{{TITLE}}` | 主标题 | main_title |",
        "| `{{SUBTITLE}}` | 副标题 | subtitle |",
        "| `{{AUTHOR}}` | 作者/机构 | author |",
        "| `{{DATE}}` | 日期 | date |",
        "| `{{PRESENTER}}` | 汇报人 | presenter |",
        "| `{{ORGANIZATION}}` | 组织/单位 | organization |",
        "| `{{INSTITUTION}}` | 机构名 | institution |",
        "| `{{LOGO}}` / `{{LOGO_LARGE}}` | Logo | logo |",
        "| `{{PAGE_TITLE}}` | 页面标题 | page_title |",
        "| `{{TOC_ITEM_1}}` ~ `{{TOC_ITEM_N}}` | 目录条目 | toc_item |",
        "| `{{CHAPTER_NUM}}` | 章节编号 | chapter_number |",
        "| `{{CHAPTER_TITLE}}` | 章节标题 | chapter_title |",
        "| `{{CHAPTER_DESC}}` | 章节描述 | chapter_description |",
        "| `{{PAGE_NUM}}` | 页码 | page_number |",
        "| `{{SECTION_NAME}}` | 章节名称（页脚） | section_name |",
        "| `{{CONTENT_AREA}}` | 内容区域（由脚本自动插入） | content_area |",
        "| `{{THANK_YOU}}` | 感谢语 | closing_title |",
        "| `{{CONTACT_INFO}}` | 联系方式 | contact_info |",
        "| `{{TAGLINE}}` | 标语/品牌语 | tagline |",
        "| `{{COPYRIGHT}}` | 版权信息 | copyright |",
        "",
        "---",
        "",
    ])

    # === 十一、使用说明 ===
    lines.extend([
        "## 十一、使用说明",
        "",
        "> **选项 C (PPTX 模板提取) 特殊约束**",
        ">",
        "> 本模板从 PPTX 直接解析生成，Executor 必须将 `$PPT_DIR/templates/` 中的对应 SVG 模板文件作为骨架，仅替换占位符内容。",
        ">",
        "> **禁止行为**：",
        "> - 添加模板中不存在的装饰元素（如渐变顶条、卡片阴影、角落光晕等）",
        "> - 修改模板原始布局结构（背景、图片位置、装饰元素位置）",
        "> - 更改模板原始配色方案",
        ">",
        "> **允许行为**：",
        "> - 替换占位符为实际内容文本",
        "> - 内容页的内容区域（`{{CONTENT_AREA}}`）内自由布局",
        "> - 根据内容量微调字号（但应保持原始层级关系）",
        ">",
        "> **模板消费方式**：",
        "> 1. 读取 `$PPT_DIR/templates/` 中的对应 SVG 模板文件（如 `01_cover.svg`）",
        "> 2. 将模板中的占位符（如 `{{TITLE}}`）替换为实际内容",
        "> 3. 保留所有原始视觉元素（图片、形状、渐变、装饰）",
        "> 4. 内容页仅替换 `{{CONTENT_AREA}}` 区域，保留页眉/页脚/背景",
        "",
    ])

    return "\n".join(lines)
