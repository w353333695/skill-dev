# Phase 1: 源内容处理

> 将用户提供的源材料（PDF/URL/Markdown）转换为统一的 Markdown 格式，归档到项目 sources 目录

## 目标

- 将所有源材料转换为可分析的 Markdown 格式
- 归档源材料到 `$PPT_DIR/sources/` 目录
- 为 Strategist 提供结构化的内容输入

## 产出物

- `$PPT_DIR/sources/input.md` — 转换后的 Markdown 文件
- `$PPT_DIR/sources/` — 源材料归档（原件/URL 记录）

## 前置条件

- Phase 0 已完成（`$PPT_DIR` 已创建，Python 依赖已验证）
- 用户已提供源材料（PDF 文件路径 / 网页 URL / Markdown 文件路径）

---

## 执行步骤

### Step 1: 识别源材料类型

根据用户提供的内容判断处理方式：

| 用户输入 | 处理工具 | 命令 |
|----------|----------|------|
| **PDF 文件** | `pdf_to_md.py` | 见 Step 2 |
| **网页链接** | `web_to_md.py` | 见 Step 3 |
| **微信/高防站 URL** | `web_to_md.cjs` | 见 Step 4 |
| **Markdown 文件** | 直接复制 | 见 Step 5 |

**强制规则**：识别到 PDF/URL 后**必须立即调用工具转换**，不得仅询问"是否需要转换"。

### Step 2: PDF 转 Markdown

使用 `pdf_to_md.py` 将 PDF 转换为 Markdown：

```bash
python3 $SCRIPTS_DIR/pdf_to_md.py "用户提供的PDF路径" -o $PPT_DIR/sources/input.md
```

**参数说明**：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| 位置参数 | PDF 文件路径 | 必填 |
| `-o` | 输出 Markdown 文件路径 | 当前目录下的 `output.md` |

**预期输出**：
```
📄 正在处理: 用户提供的PDF路径
✅ 转换完成，共 15 页
📝 输出文件: output/ppt-generator/20260326_143052/sources/input.md
```

**错误处理**：

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| `PyMuPDF not found` | 缺少依赖 | `pip install PyMuPDF` |
| 转换结果乱码/空白 | 扫描版 PDF 或复杂排版 | 提示用户使用 MinerU（需 OCR） |
| `File not found` | 路径错误 | 确认文件路径 |

**Tool 选择策略**：

| 场景 | 推荐工具 | 说明 |
|------|----------|------|
| 原生 PDF（Word/LaTeX 导出） | `pdf_to_md.py` | 优先使用，本地快速 |
| 简单表格 | `pdf_to_md.py` | 数据不出本机 |
| 扫描版/图片 PDF | MinerU | 需要 OCR |
| 复杂多栏排版 | MinerU | 版面分析更准 |
| 数学公式 | MinerU | AI 识别能力强 |

### Step 3: 网页转 Markdown（普通网页）

使用 `web_to_md.py` 将网页转换为 Markdown：

```bash
python3 $SCRIPTS_DIR/web_to_md.py "https://example.com/article" -o $PPT_DIR/sources/input.md
```

**参数说明**：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| 位置参数 | 网页 URL | 必填 |
| `-o` | 输出文件路径 | 当前目录 |
| `-f` | 批量处理（从文件读取 URL 列表） | 无 |

**适用场景**：
- 普通文章/新闻网页
- 图文内容（游记、攻略等，自动下载图片到 `_files/`）
- 政府/机构网站（支持中文站点元数据提取）

**预期输出**：
```
🌐 正在抓取: https://example.com/article
📄 标题: 文章标题
📝 输出文件: output/ppt-generator/20260326_143052/sources/input.md
✅ 转换完成
```

### Step 4: 微信/高防站 URL 转 Markdown

微信公众号、部分高防站点需要使用 Node.js 版本绕过 TLS 拦截：

```bash
node $SCRIPTS_DIR/web_to_md.cjs "https://mp.weixin.qq.com/s/xxx" -o $PPT_DIR/sources/input.md
```

**前置条件**：Node.js 已安装

**错误处理**：
- 若 `node` 命令不可用，提示用户安装 Node.js
- 若转换失败，建议用户手动复制网页内容为 Markdown

### Step 5: Markdown 文件直接处理

用户直接提供 Markdown 文件时，复制到项目目录：

```bash
cp "用户提供的Markdown路径" $PPT_DIR/sources/input.md
```

验证文件可读：

```bash
wc -l $PPT_DIR/sources/input.md
head -20 $PPT_DIR/sources/input.md
```

### Step 6: 验证转换结果

转换完成后，验证 Markdown 内容质量：

```bash
# 检查文件大小（过小可能转换失败）
FILE_SIZE=$(wc -c < $PPT_DIR/sources/input.md)
echo "文件大小: ${FILE_SIZE} bytes"

# 检查行数
LINE_COUNT=$(wc -l < $PPT_DIR/sources/input.md)
echo "行数: $LINE_COUNT"

# 检查是否有实际内容
grep -c "." $PPT_DIR/sources/input.md
```

**质量判断标准**：

| 指标 | 最低要求 | 说明 |
|------|----------|------|
| 文件大小 | > 500 bytes | 过小表示可能转换失败 |
| 非空行数 | > 10 行 | 至少有基本内容结构 |
| 标题数量 | > 1 个 | `#` 开头的行 |

### Step 7: 归档源材料

将原始材料信息归档到 `sources/` 目录：

```bash
# 如果是 PDF，复制原件到 sources/
cp "用户提供的PDF路径" $PPT_DIR/sources/original.pdf 2>/dev/null

# 如果是 URL，记录 URL 信息
echo "# 源材料信息" > $PPT_DIR/sources/source_info.md
echo "- 类型: URL" >> $PPT_DIR/sources/source_info.md
echo "- URL: 用户提供的URL" >> $PPT_DIR/sources/source_info.md
echo "- 转换时间: $(date)" >> $PPT_DIR/sources/source_info.md
```

## 常见问题

### Q: PDF 转换后中文乱码？

检查 PDF 是否为扫描版。尝试：
1. 使用 `pdf_to_md.py` 的 OCR 选项（如支持）
2. 推荐使用 MinerU 工具处理扫描版 PDF

### Q: 网页转换后图片缺失？

`web_to_md.py` 会自动将图片下载到同目录的 `_files/` 文件夹。若图片仍缺失：
- 检查网络连接
- 图片可能被防盗链保护，需手动保存

### Q: 需要合并多个源文件？

多个 Markdown 文件可直接合并：

```bash
cat source1.md source2.md source3.md > $PPT_DIR/sources/input.md
```
