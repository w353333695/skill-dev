#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PPTX 模板提取工具

从 PPTX 模板文件中提取画布尺寸、配色方案、字体信息、形状布局等，
输出结构化 JSON 供后续 SVG 模板生成使用。

Usage:
    python3 pptx_to_template.py input.pptx -o output_dir/
    python3 pptx_to_template.py input.pptx -o output_dir/ --screenshot
"""

import argparse
import json
import re
import sys
from pathlib import Path

try:
    from pptx import Presentation
    from pptx.util import Emu
except ImportError:
    print("错误: 缺少 python-pptx 库", file=sys.stderr)
    print("请运行: pip install python-pptx", file=sys.stderr)
    sys.exit(1)

# Re-export for tests (import pptx_to_template as mod)
from _pptx_design_spec import generate_design_spec
from _pptx_svg_render import (
    build_theme_color_map,
    classify_slide,
    resolve_color,
    shape_to_svg,
    slide_to_svg,
    _collect_shape_colors,
)


# ============ CONFIGURATION ============

SCRIPTS_DIR = Path(__file__).parent


# ============ EXTRACTION ============

def extract_canvas_info(prs):
    """提取画布尺寸信息"""
    width_emu = prs.slide_width
    height_emu = prs.slide_height
    width_px = int(width_emu / 914400 * 96)
    height_px = int(height_emu / 914400 * 96)
    return {
        "width": width_px,
        "height": height_px,
        "width_emu": width_emu,
        "height_emu": height_emu,
        "viewBox": f"0 0 {width_px} {height_px}",
        "aspect_ratio": f"{width_px}:{height_px}"
    }


def extract_fonts(prs):
    """提取字体信息（含主题字体 fallback）"""
    fonts = {"title": [], "body": [], "all": set()}

    # 1. 从所有文本 run 读取直接设置的字体
    for slide in prs.slides:
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            for paragraph in shape.text_frame.paragraphs:
                for run in paragraph.runs:
                    font = run.font
                    name = font.name
                    if name:
                        fonts["all"].add(name)

    # 2. 若 run 无字体，尝试从主题字体读取（latin typeface）
    if not fonts["all"]:
        theme_fonts = _extract_theme_fonts(prs)
        fonts["all"].update(theme_fonts)

    fonts["all"] = sorted(fonts["all"])
    # 推断标题字体和正文字体
    if len(fonts["all"]) >= 1:
        fonts["title"] = [fonts["all"][0]]
    if len(fonts["all"]) >= 2:
        fonts["body"] = [fonts["all"][-1]]
    elif fonts["all"]:
        fonts["body"] = [fonts["all"][0]]

    return fonts


def _extract_theme_fonts(prs):
    """从主题 XML 提取 latin 字体名

    python-pptx 的 SlideMaster 没有 .theme 属性，需要通过 package.iter_parts()
    遍历找到 theme 部分，再解析其中的 a:fontScheme。
    """
    theme_fonts = set()
    try:
        from lxml import etree

        package = prs.part.package
        ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}

        for part in package.iter_parts():
            if not part.partname.startswith("/ppt/theme/"):
                continue
            root = etree.fromstring(part.blob)
            for fs in root.findall(".//a:fontScheme", ns):
                for major in fs.findall("a:majorFont", ns):
                    for latin in major.findall("a:latin", ns):
                        typeface = latin.get("typeface")
                        if typeface and typeface.strip() and typeface not in ("+", "+mj-lt", "+mn-lt", "+mj-ea", "+mn-ea"):
                            theme_fonts.add(typeface)
                    for ea in major.findall("a:ea", ns):
                        typeface = ea.get("typeface")
                        if typeface and typeface.strip() and typeface not in ("+", "+mj-lt", "+mn-lt", "+mj-ea", "+mn-ea"):
                            theme_fonts.add(typeface)
                for minor in fs.findall("a:minorFont", ns):
                    for latin in minor.findall("a:latin", ns):
                        typeface = latin.get("typeface")
                        if typeface and typeface.strip() and typeface not in ("+", "+mj-lt", "+mn-lt", "+mj-ea", "+mn-ea"):
                            theme_fonts.add(typeface)
                    for ea in minor.findall("a:ea", ns):
                        typeface = ea.get("typeface")
                        if typeface and typeface.strip() and typeface not in ("+", "+mj-lt", "+mn-lt", "+mj-ea", "+mn-ea"):
                            theme_fonts.add(typeface)
    except Exception:
        pass
    return theme_fonts


# ============ SCREENSHOT ============

def find_libreoffice():
    """查找 LibreOffice 可执行文件路径"""
    import shutil
    import platform

    # 先通过 PATH 查找
    cmd = shutil.which("libreoffice") or shutil.which("soffice")
    if cmd:
        return cmd

    # macOS Homebrew Cask 安装路径
    if platform.system() == "Darwin":
        macos_paths = [
            "/Applications/LibreOffice.app/Contents/MacOS/soffice",
        ]
        for p in macos_paths:
            if Path(p).exists():
                return p

    return None


def check_libreoffice():
    """检查 LibreOffice 是否可用"""
    return find_libreoffice() is not None


def take_screenshots_png_only(pptx_path, output_dir, max_slides=20, dpi=150):
    """只生成 PNG 截图（不写 SVG 和 svg_palette.json），避免污染模板目录"""
    import subprocess
    import tempfile

    try:
        import fitz
    except ImportError:
        return {"success": False, "reason": "PyMuPDF (fitz) not installed"}

    cmd = find_libreoffice()
    if not cmd:
        return {"success": False, "reason": "libreoffice_not_found"}

    with tempfile.TemporaryDirectory() as tmpdir:
        pdf_result = subprocess.run(
            [cmd, "--headless", "--convert-to", "pdf",
             "--outdir", tmpdir, str(pptx_path)],
            capture_output=True, text=True, timeout=120
        )
        if pdf_result.returncode != 0:
            return {"success": False, "reason": f"PDF conversion failed: {pdf_result.stderr}"}

        pdf_files = list(Path(tmpdir).glob("*.pdf"))
        if not pdf_files:
            return {"success": False, "reason": "No PDF generated"}
        pdf_path = pdf_files[0]

        from string import Template
        render_script = Template('''
import fitz
doc = fitz.open("$pdf_path")
count = min(len(doc), $max_slides)
for i in range(count):
    page = doc[i]
    pix = page.get_pixmap(dpi=$dpi)
    png_path = "$output_dir/slide_%02d.png" % (i + 1)
    pix.save(png_path)
doc.close()
''').substitute(
            pdf_path=str(pdf_path),
            output_dir=str(output_dir),
            max_slides=max_slides,
            dpi=dpi,
        )
        render_result = subprocess.run(
            [sys.executable, "-c", render_script],
            capture_output=True, text=True, timeout=120
        )
        if render_result.returncode != 0:
            return {"success": False, "reason": f"Render failed: {render_result.stderr}"}

        screenshots = sorted([f.name for f in output_dir.glob("slide_*.png")])
        return {"success": True, "screenshots": screenshots}


# ============ IMAGE EXTRACTION ============


# ============ SVG TEMPLATE CONVERSION ============

def convert_pptx_to_svg_templates(pptx_path, output_dir, take_screenshots_flag=False):
    """PPTX → SVG 模板主入口"""
    prs = Presentation(str(pptx_path))
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    theme_map = build_theme_color_map(pptx_path)
    canvas = extract_canvas_info(prs)
    total_slides = len(prs.slides)

    # ===== 输入校验（在写任何文件之前）=====
    if total_slides < 3:
        raise ValueError(
            f"PPTX 至少需要 3 页（cover + 至少 1 页中间内容 + ending），"
            f"当前 {total_slides} 页。Phase 5 需要 04_content.svg 模板，"
            f"请提供包含封面、内容页和结尾页的模板文件。"
        )

    images_dir = output_dir.parent / "images"
    images_dir.mkdir(parents=True, exist_ok=True)
    image_hashes = {}

    unresolved_all = []
    slide_summaries = []
    svg_files = []

    # ===== Phase 1: 逐页生成 SVG，收集分类信息 =====
    # C2 只做确定性分类：cover（第1页）、ending（最后一页）
    # 中间页全部保留为 unknown，不做 framework 替换，等 C3 分类提升
    raw_svgs = {}  # slide_index → (svg_content, summary)
    for slide_index, slide in enumerate(prs.slides):
        unresolved_slide = []
        summary = classify_slide(slide, slide_index, total_slides, theme_map, canvas)

        # 收集颜色频次（fill + stroke，递归进入 group）
        from collections import Counter
        colors_in_slide = Counter()
        _collect_shape_colors(slide.shapes, theme_map, colors_in_slide)
        summary["colors"] = dict(colors_in_slide.most_common())
        slide_summaries.append(summary)

        # C2 不预判中间页类型，所有中间页保留完整内容
        # content_framework=False：保留所有 shapes，不做 CONTENT_AREA 替换
        svg_content = slide_to_svg(slide, slide_index, total_slides, canvas,
                                   theme_map, images_dir, image_hashes, unresolved_slide,
                                   content_framework=False)

        raw_svgs[slide_index] = (svg_content, summary)
        unresolved_all.extend(unresolved_slide)

    # ===== Phase 2: 写入确定性模板 + 中间页 unknown =====
    # 固定命名（与 22 个内置模板对齐）：01_cover, 02_toc, 03_chapter, 04_content, 05_ending
    STANDARD_TEMPLATES = ["01_cover", "02_toc", "03_chapter", "04_content", "05_ending"]
    TYPE_TO_TEMPLATE = {
        "cover": "01_cover",
        "toc": "02_toc",
        "chapter": "03_chapter",
        "content": "04_content",
        "ending": "05_ending",
    }

    # C2 确定性分类：第一页 → cover，最后一页 → ending
    template_mapping = {}  # template_name → slide_index
    template_mapping["01_cover"] = 0
    if total_slides > 1:
        template_mapping["05_ending"] = total_slides - 1

    # 写入确定性模板
    for template_name, slide_idx in template_mapping.items():
        svg_content, summary = raw_svgs[slide_idx]
        svg_path = output_dir / f"{template_name}.svg"
        with open(svg_path, "w", encoding="utf-8") as f:
            f.write(svg_content)
        svg_files.append(svg_path.name)
        summary["assigned_template"] = template_name

    # 中间页全部保存为 slide_XX_unknown.svg，等 C3 分类后提升为标准模板
    for slide_index in range(1, total_slides - 1):
        svg_content, summary = raw_svgs[slide_index]
        raw_name = f"slide_{slide_index + 1:02d}_unknown.svg"
        svg_path = output_dir / raw_name
        with open(svg_path, "w", encoding="utf-8") as f:
            f.write(svg_content)
        svg_files.append(svg_path.name)
        summary["assigned_template"] = None  # 待 C3 分配
        summary["type"] = "unknown"

    # 按标准模板序号排序 svg_files
    def _sort_svg_files(filenames):
        order = {name: i for i, name in enumerate(STANDARD_TEMPLATES)}
        def key(name):
            stem = name.replace(".svg", "")
            return order.get(stem, 99)
        return sorted(filenames, key=key)
    svg_files = _sort_svg_files(svg_files)

    # 写入 unresolved_shapes.json
    unresolved_path = output_dir / "unresolved_shapes.json"
    with open(unresolved_path, "w", encoding="utf-8") as f:
        json.dump({"unresolved": unresolved_all}, f, ensure_ascii=False, indent=2)

    # 生成 template_data.json
    fonts = extract_fonts(prs)
    # 输入约束评估
    available_types = set()
    unclassified_middle_count = 0
    for slide_index, (svg_content, summary) in raw_svgs.items():
        if slide_index == 0:
            available_types.add("cover")
        elif slide_index == total_slides - 1:
            available_types.add("ending")
        else:
            # 中间页类型待 C3 分类，C2 不预判
            unclassified_middle_count += 1

    has_enough_slides = total_slides >= 3 and unclassified_middle_count > 0

    template_data = {
        "canvas": canvas,
        "color_theme": {
            "source": "theme_xml" if theme_map else "none",
            "colors": theme_map,
        },
        "fonts": fonts,
        "slides": slide_summaries,
        "standard_templates": {name: idx for name, idx in template_mapping.items()},
        "type_to_template": TYPE_TO_TEMPLATE,
        "svg_files": svg_files,
        "unresolved_count": len(unresolved_all),
        "slide_count": total_slides,
        "source_file": str(pptx_path),
        "style_tags": _compute_style_tags(slide_summaries, theme_map),
        "input_assessment": {
            "has_enough_slides": has_enough_slides,
            "available_page_types": sorted(available_types),
            "unclassified_candidates": unclassified_middle_count,
            "note": (
                f"结构合法（cover + {unclassified_middle_count} 页中间候选 + ending），"
                f"中间页待 C3 分类提升为 content/chapter/toc 等标准模板"
                if unclassified_middle_count > 0
                else "结构异常：无中间页"
            ),
        },
    }

    # 截图 (best-effort)
    if take_screenshots_flag:
        screenshot_result = take_screenshots_png_only(pptx_path, output_dir)
        template_data["screenshots_available"] = screenshot_result["success"]
        template_data["screenshot_method"] = "libreoffice" if screenshot_result["success"] else "none"
    else:
        template_data["screenshots_available"] = False
        template_data["screenshot_method"] = "none"

    td_path = output_dir / "template_data.json"
    with open(td_path, "w", encoding="utf-8") as f:
        json.dump(template_data, f, ensure_ascii=False, indent=2)

    # 生成 C3 决策骨架（供 Agent 参考）
    _generate_c3_skeleton(template_data, output_dir)

    # 生成基础 design_spec.md（C3 通过 pptx_template_apply.py 后重新生成完整版）
    base_spec = generate_design_spec(template_data, None)
    spec_path = output_dir / "design_spec.md"
    with open(spec_path, "w", encoding="utf-8") as f:
        f.write(base_spec)
    print(f"  ✅ design_spec.md 已生成: {spec_path}")

    return template_data


def _extract_texts_from_svg(svg_content):
    """从 SVG 提取文本及属性，返回 [{"text": str, "font_size_px": int, "color": str}]"""
    import html
    import xml.etree.ElementTree as ET

    results = []
    seen = set()

    try:
        root = ET.fromstring(svg_content)
    except ET.ParseError:
        return results

    def _parse_font_size_px(elem):
        """从 font-size 属性提取 px 值（pt → px 转换）"""
        fs = elem.get("font-size", "")
        if not fs:
            return 0
        if fs.endswith("pt"):
            try:
                return round(float(fs[:-2]) * 96 / 72)
            except (ValueError, TypeError):
                return 0
        try:
            return round(float(fs))
        except (ValueError, TypeError):
            return 0

    def _parse_fill(elem):
        """提取 fill 属性中的 #RRGGBB 颜色"""
        fill = elem.get("fill", "")
        if fill and fill != "none" and fill != "transparent" and fill.startswith("#"):
            return fill
        return ""

    # 先收集每个元素及其父元素的映射
    parent_map = {}
    for parent in root.iter():
        for child in parent:
            parent_map[child] = parent

    for elem in root.iter():
        tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        if tag not in ("tspan", "text"):
            continue
        text = html.unescape(elem.text or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)

        font_size_px = _parse_font_size_px(elem)
        if font_size_px == 0:
            parent = parent_map.get(elem)
            if parent is not None:
                font_size_px = _parse_font_size_px(parent)

        color = _parse_fill(elem)
        if not color:
            parent = parent_map.get(elem)
            if parent is not None:
                color = _parse_fill(parent)

        results.append({
            "text": text,
            "font_size_px": font_size_px,
            "color": color,
        })

    return results


def _generate_c3_skeleton(template_data, templates_dir):
    """生成 c3_decision.json 骨架，自动提取文本及属性供 Agent 参考

    输出格式（按页面分组）：
    {
      "pages": [
        {
          "slide_index": 1,
          "template": "01_cover",
          "type": "cover",
          "promotion_reason": "",
          "layout": {"description": "", "bg_description": "", "decorations": []},
          "texts": [
            {"original": "...", "placeholder": "", "font_size_px": 60, "color": "#36393B"}
          ]
        }
      ]
    }

    font_size_px 和 color 由脚本自动从 SVG 提取，LLM 只需填写 placeholder。
    """
    pages = []
    standard_templates = template_data.get("standard_templates", {})

    # 收集所有 slide_index（确定性模板 + unknown 页）
    all_slide_indices = set()
    for slide_info in template_data.get("slides", []):
        all_slide_indices.add(slide_info["slide_index"])

    for slide_idx in sorted(all_slide_indices):
        # 查找该 slide 对应的模板名和类型
        template_name = None
        slide_type = "unknown"
        for tname, tidx in standard_templates.items():
            if tidx == slide_idx:
                template_name = tname
                # 从模板名推断类型
                if "cover" in tname:
                    slide_type = "cover"
                elif "ending" in tname or "end" in tname:
                    slide_type = "ending"
                elif "toc" in tname:
                    slide_type = "toc"
                elif "chapter" in tname:
                    slide_type = "chapter"
                elif "content" in tname:
                    slide_type = "content"
                break

        if template_name is None:
            # unknown 页
            template_name = f"slide_{slide_idx + 1:02d}_unknown"
            slide_type = ""

        # 读取 SVG 提取文本
        svg_path = templates_dir / f"{template_name}.svg"
        if not svg_path.exists():
            svg_path = templates_dir / f"slide_{slide_idx + 1:02d}_unknown.svg"

        texts = []
        if svg_path.exists():
            svg_content = svg_path.read_text(encoding="utf-8")
            raw_texts = _extract_texts_from_svg(svg_content)
            texts = [
                {
                    "original": t["text"],
                    "placeholder": "",
                    "font_size_px": t["font_size_px"],
                    "color": t["color"],
                }
                for t in raw_texts
            ]

        page = {
            "slide_index": slide_idx,
            "template": template_name,
            "type": slide_type,
            "promotion_reason": "",
            "layout": {
                "description": "",
                "bg_description": "",
                "decorations": []
            },
            "texts": texts
        }
        pages.append(page)

    skeleton = {"pages": pages}

    # 写入文件
    output_path = templates_dir / "c3_decision.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(skeleton, f, ensure_ascii=False, indent=2)

    unknown_count = sum(1 for p in pages if p["type"] == "")
    print(f"  ✅ C3 决策骨架已生成: {output_path}")
    print(f"     - {unknown_count} 个中间页待分类")
    print(f"     - {len(pages)} 个页面待配置占位符")


def _compute_style_tags(slide_summaries, theme_map):
    """基于实际背景色和实际使用颜色数计算风格标签"""
    # theme_mode：从每页 dominant_bg_color 投票
    dark_votes = 0
    light_votes = 0
    for s in slide_summaries:
        bg = s.get("features", {}).get("dominant_bg_color")
        if bg:
            bg_hex = bg.lstrip("#")
            try:
                r, g, b = int(bg_hex[:2], 16), int(bg_hex[2:4], 16), int(bg_hex[4:6], 16)
                if (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.3:
                    dark_votes += 1
                else:
                    light_votes += 1
            except (ValueError, IndexError):
                light_votes += 1
        else:
            light_votes += 1  # 无背景色默认浅色

    theme_mode = "dark" if dark_votes > light_votes else "light"

    # palette_complexity：从实际使用的颜色种类数（colors 是 dict {hex: count}）
    all_colors = set()
    for s in slide_summaries:
        for c in s.get("colors", {}).keys():
            all_colors.add(c)
    n = len(all_colors)
    palette_complexity = "minimal" if n <= 4 else ("rich" if n > 6 else "moderate")

    return {
        "theme_mode": theme_mode,
        "palette_complexity": palette_complexity,
    }


# ============ STYLE-ONLY MODE ============

def extract_style_only(pptx_path, output_dir, take_screenshots_flag=False):
    """风格克隆模式：只提取配色/字体/调性，输出 style_profile.md。
    不生成 SVG 骨架、c3_decision.json、design_spec.md。
    """
    from collections import Counter

    prs = Presentation(str(pptx_path))
    output_dir = Path(output_dir) / "style"
    output_dir.mkdir(parents=True, exist_ok=True)

    theme_map = build_theme_color_map(pptx_path)
    canvas = extract_canvas_info(prs)
    total_slides = len(prs.slides)

    # ---- 只采样前 5 页 ----
    sample_slides = list(prs.slides)[:min(5, total_slides)]

    # ---- 加权颜色采样 ----
    from lxml import etree as _etree
    _A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"

    canvas_area = canvas["width"] * canvas["height"]
    weighted_colors = Counter()
    slide_h = canvas["height"]

    for slide_idx, slide in enumerate(sample_slides):
        # Pass 1: 通过 python-pptx 高层 API 采集（带位置权重）
        for shape in slide.shapes:
            try:
                top = shape.top or 0
                w = shape.width or 0
                h = shape.height or 0
                shape_area = (w / 914400 * 96) * (h / 914400 * 96)
                area_ratio = shape_area / canvas_area if canvas_area > 0 else 0
                if area_ratio < 0.005:
                    continue
                top_px = top / 914400 * 96
                position_weight = 3 if (top_px < slide_h * 0.15 or top_px > slide_h * 0.90) else 1
                shape_colors = Counter()
                _collect_shape_colors([shape], theme_map, shape_colors)
                for c, cnt in shape_colors.items():
                    if c and len(c) == 6:
                        weighted_colors["#" + c.upper()] += cnt * position_weight
            except Exception:
                continue

        # Pass 2: XML 直扫 schemeClr / srgbClr（权重 ×1，补充高层 API 遗漏的主题色）
        try:
            root = _etree.fromstring(_etree.tostring(slide._element))
            for elem in root.iter(f"{{{_A_NS}}}srgbClr"):
                val = elem.get("val")
                if val and len(val) == 6:
                    weighted_colors["#" + val.upper()] += 1
            for elem in root.iter(f"{{{_A_NS}}}schemeClr"):
                val = elem.get("val")
                resolved = theme_map.get(val) if val else None
                if resolved and len(resolved) == 6:
                    weighted_colors["#" + resolved.upper()] += 1
        except Exception:
            pass

    # ---- 颜色角色分类 ----
    def hex_to_rgb(h):
        h = h.lstrip("#")
        return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

    def luminance(h):
        r, g, b = hex_to_rgb(h)
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255

    def saturation(h):
        r, g, b = [x / 255.0 for x in hex_to_rgb(h)]
        mx, mn = max(r, g, b), min(r, g, b)
        return (mx - mn) / mx if mx > 0 else 0

    def color_distance(h1, h2):
        r1, g1, b1 = hex_to_rgb(h1)
        r2, g2, b2 = hex_to_rgb(h2)
        return ((r1-r2)**2 + (g1-g2)**2 + (b1-b2)**2) ** 0.5

    # 合并色差 ΔE < 30（近似）的颜色
    merged = {}
    for color, weight in weighted_colors.most_common():
        found = False
        for existing in merged:
            if color_distance(color, existing) < 30:
                merged[existing] += weight
                found = True
                break
        if not found:
            merged[color] = weight

    sorted_colors = sorted(merged.items(), key=lambda x: -x[1])

    # 提取背景色（最高权重的浅色）
    background = "#FFFFFF"
    for c, _ in sorted_colors:
        if luminance(c) > 0.85:
            background = c
            break

    # 提取主色（最高权重的深色，排除背景色和低饱和纯黑/灰文字色）
    primary = "#1A3A5C"
    for c, _ in sorted_colors:
        if luminance(c) < 0.5 and c != background and saturation(c) > 0.1:
            primary = c
            break

    # 提取辅助色（第二高权重的中间色）
    secondary = "#E8F0F8"
    for c, _ in sorted_colors:
        if c != primary and c != background and 0.5 <= luminance(c) <= 0.9:
            secondary = c
            break

    # 提取强调色：优先用 theme_map 的 accent1/accent2/accent3（Office 明确定义的品牌色）
    # 从中选饱和度最高的作为强调色；若主题中无合适项，再从 sorted_colors 打分选取
    accent = "#F5A623"
    best_score = 0
    theme_accents = [theme_map.get(k) for k in ("accent1", "accent2", "accent3") if theme_map.get(k)]
    theme_accent_candidates = [("#" + c.upper()) for c in theme_accents if len(c) == 6]
    for c in theme_accent_candidates:
        if c in (primary, secondary, background):
            continue
        s = saturation(c)
        if s > best_score:
            best_score = s
            accent = c
    # 若主题色未选出有效强调色，回退到 sorted_colors 打分
    if best_score < 0.2:
        best_score = 0
        total_weight = sum(w for _, w in sorted_colors) or 1
        for c, w in sorted_colors:
            if c in (primary, secondary, background):
                continue
            s = saturation(c)
            if s < 0.2:
                continue
            freq = w / total_weight
            score = s * 0.6 + freq * 0.4
            if score > best_score:
                best_score = score
                accent = c

    # 文字色：最深的颜色
    text_primary = "#1A1A1A"
    for c, _ in sorted_colors:
        if luminance(c) < 0.15:
            text_primary = c
            break

    text_secondary = "#666666"

    # ---- 字体提取 ----
    fonts = extract_fonts(prs)
    title_font = fonts["title"][0] if fonts["title"] else "微软雅黑"
    body_font = fonts["body"][0] if fonts["body"] else "微软雅黑"

    # 匹配字体预设
    font_preset_map = {
        ("微软雅黑", "微软雅黑"): ("P1", "现代商务"),
        ("黑体", "宋体"): ("P2", "政务公文"),
        ("楷体", "微软雅黑"): ("P3", "文化艺术"),
        ("宋体", "微软雅黑"): ("P4", "传统稳重"),
        ("Arial", "Calibri"): ("P5", "英文为主"),
    }
    font_preset, font_scene = font_preset_map.get(
        (title_font, body_font), ("P1", "现代商务")
    )

    # ---- 风格调性推断 ----
    dark_count = sum(1 for s in sample_slides
                     for shape in s.shapes
                     if _is_dark_bg_shape(shape, theme_map, canvas))
    dominant_theme = "dark" if dark_count > len(sample_slides) else "light"

    # executor 推断
    style_signals = _compute_style_tags(
        [classify_slide(s, i, total_slides, theme_map, canvas)
         for i, s in enumerate(sample_slides)],
        theme_map
    )
    palette_complexity = style_signals.get("palette_complexity", "moderate")

    if dominant_theme == "dark" or palette_complexity == "rich":
        inferred_style = "general"
        executor = "executor-general（通用灵活）"
    elif palette_complexity == "minimal":
        inferred_style = "consultant_top"
        executor = "executor-consultant-top（顶级咨询）"
    else:
        inferred_style = "consultant"
        executor = "executor-consultant（一般咨询）"

    # ---- 参考文件质量评估 ----
    # 统计非默认值的颜色角色数（而非 sorted_colors 长度，避免简洁配色被误判）
    default_colors = {"#1A3A5C", "#E8F0F8", "#F5A623", "#FFFFFF"}
    extracted_roles = sum(1 for c in [primary, secondary, accent, background]
                          if c not in default_colors)
    has_fonts = bool(fonts["all"])
    if extracted_roles >= 3 and has_fonts:
        assessment = "good"
        assessment_note = "配色和字体信息充足"
    elif extracted_roles >= 2 or (extracted_roles >= 1 and has_fonts):
        assessment = "limited"
        assessment_note = "设计元素偏少，提取结果可能不够准确"
    else:
        assessment = "poor"
        assessment_note = "无法识别有效配色，建议改用选项 B（内置模板+自定义配色）"

    # ---- 截图（用于调性判断，best-effort）----
    if take_screenshots_flag:
        take_screenshots_png_only(pptx_path, output_dir, max_slides=5)

    # ---- 生成精简版 template_data.json ----
    style_data = {
        "canvas": canvas,
        "colors": {
            "primary": primary,
            "secondary": secondary,
            "accent": accent,
            "background": background,
            "text_primary": text_primary,
            "text_secondary": text_secondary,
        },
        "fonts": {
            "title": title_font,
            "body": body_font,
            "all_detected": fonts["all"],
        },
        "style_signals": {
            "dominant_theme": dominant_theme,
            "inferred_style": inferred_style,
            "palette_complexity": palette_complexity,
        },
        "input_assessment": {
            "quality": assessment,
            "note": assessment_note,
            "color_count": len(sorted_colors),
        },
        "source_file": str(pptx_path),
    }
    td_path = output_dir / "template_data.json"
    with open(td_path, "w", encoding="utf-8") as f:
        json.dump(style_data, f, ensure_ascii=False, indent=2)

    # ---- 生成 style_profile.md ----
    from datetime import date
    today = date.today().strftime("%Y-%m-%d")
    style_profile = f"""# 风格档案 — {pptx_path.name}

> 由 pptx_to_template.py --style-only 自动生成
> 生成时间：{today}
> 质量评估：{assessment}（{assessment_note}）

## 配色方案

| 角色 | 色值 | 用途 |
|------|------|------|
| 主色 | {primary} | 页眉背景、标题色 |
| 辅助色 | {secondary} | 卡片背景、区域填充 |
| 强调色 | {accent} | 数据高亮、按钮、箭头 |
| 背景色 | {background} | 页面背景 |
| 主文字 | {text_primary} | 正文 |
| 次文字 | {text_secondary} | 注释、副标题 |

配色法则：60-30-10（主色 60%、辅助色 30%、强调色 10%）

## 字体方案

- 标题字体：{title_font} Bold
- 正文字体：{body_font} Regular
- 匹配预设：{font_preset}（{font_scene}）

## 风格调性

- 整体风格：{"深色系" if dominant_theme == "dark" else "浅色系"}商务风格
- 推断执行师：{executor}
- 配色复杂度：{palette_complexity}
- 主题模式：{dominant_theme}

## 使用说明

Phase 3 Strategist 加载本档案时：
- 第 5 项（配色方案）：直接使用上方色值，不调用 style_advisor 配色推荐
- 第 8 项（排版方案）：直接使用上方字体，匹配 {font_preset} 预设
- 第 4 项（设计风格）：优先推荐 {executor}，可由用户覆盖

Phase 5 SVG 生成约束：
- 必须使用本档案的配色方案（用户未修改的情况下）
- 装饰风格参考调性描述，可自由发挥（非模板填充模式）
- 视觉丰富度规则正常适用（L1/L2/L3）
"""
    profile_path = output_dir / "style_profile.md"
    with open(profile_path, "w", encoding="utf-8") as f:
        f.write(style_profile)

    # ---- 生成色板预览图 style_preview.svg（供 AI Read 展示给用户）----
    colors_for_preview = [
        (primary, "主色"),
        (secondary, "辅助色"),
        (accent, "强调色"),
        (background, "背景色"),
    ]
    _generate_style_preview(colors_for_preview, title_font, body_font, output_dir)

    print(f"✅ 风格提取完成")
    print(f"   质量评估: {assessment}（{assessment_note}）")
    print(f"   主色: {primary} | 辅助色: {secondary} | 强调色: {accent}")
    print(f"   字体: {title_font} / {body_font}")
    print(f"   调性: {dominant_theme} / {inferred_style}")
    print(f"   输出: {output_dir}")

    return style_data


def _is_dark_bg_shape(shape, theme_map, canvas):
    """判断一个 shape 是否是深色大面积背景"""
    try:
        w = shape.width or 0
        h = shape.height or 0
        shape_area = (w / 914400 * 96) * (h / 914400 * 96)
        canvas_area = canvas["width"] * canvas["height"]
        if shape_area / canvas_area < 0.1:
            return False
        fill = shape.fill
        if fill.type is None:
            return False
        c = resolve_color(fill.fore_color, theme_map)
        if not c:
            return False
        r, g, b = int(c[:2], 16), int(c[2:4], 16), int(c[4:6], 16)
        lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255
        return lum < 0.3
    except Exception:
        return False


def _generate_style_preview(colors, title_font, body_font, output_dir):
    """生成色板预览 SVG，供 AI Read 工具展示给用户"""
    swatch_w, swatch_h = 160, 100
    padding = 20
    label_h = 30
    total_w = len(colors) * (swatch_w + padding) + padding
    total_h = swatch_h + label_h + padding * 2 + 60  # 60px 字体示例区

    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_w}" height="{total_h}" viewBox="0 0 {total_w} {total_h}">',
        f'  <rect width="{total_w}" height="{total_h}" fill="#F5F5F5"/>',
        f'  <text x="{padding}" y="20" font-family="Arial" font-size="12" fill="#666">风格色板预览</text>',
    ]

    for i, (color, label) in enumerate(colors):
        x = padding + i * (swatch_w + padding)
        y = padding + 10
        # 色块
        lines.append(f'  <rect x="{x}" y="{y}" width="{swatch_w}" height="{swatch_h}" fill="{color}" rx="6"/>')
        # 边框（背景色块加边框）
        if label == "背景色":
            lines.append(f'  <rect x="{x}" y="{y}" width="{swatch_w}" height="{swatch_h}" fill="none" stroke="#CCC" stroke-width="1" rx="6"/>')
        # 色值
        lines.append(f'  <text x="{x + swatch_w//2}" y="{y + swatch_h + 16}" font-family="Arial" font-size="11" fill="#333" text-anchor="middle">{color}</text>')
        # 角色标签
        lines.append(f'  <text x="{x + swatch_w//2}" y="{y + swatch_h + 30}" font-family="Arial" font-size="11" fill="#888" text-anchor="middle">{label}</text>')

    # 字体示例
    font_y = padding + 10 + swatch_h + label_h + 20
    lines.append(f'  <text x="{padding}" y="{font_y}" font-family="{title_font}, Arial" font-size="16" fill="#333" font-weight="bold">标题字体：{title_font} Bold</text>')
    lines.append(f'  <text x="{padding}" y="{font_y + 22}" font-family="{body_font}, Arial" font-size="13" fill="#555">正文字体：{body_font} Regular — 示例文字 Sample Text</text>')

    lines.append('</svg>')

    svg_path = output_dir / "style_preview.svg"
    with open(svg_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"   色板预览: {svg_path}")


# ============ MAIN ============

def main():
    parser = argparse.ArgumentParser(
        description="PPTX 模板提取工具 - 直接解析生成 SVG 模板"
    )
    parser.add_argument("input", type=str, help="输入 PPTX 文件路径")
    parser.add_argument("-o", "--output", type=str, required=True, help="输出目录")
    parser.add_argument("--screenshot", action="store_true",
                        help="best-effort 截图（失败不阻塞）")
    parser.add_argument("--style-only", action="store_true",
                        help="风格克隆模式：只提取配色/字体/调性，输出 style_profile.md，不生成 SVG 模板骨架")
    args = parser.parse_args()

    pptx_path = Path(args.input)
    if not pptx_path.exists():
        print(f"错误: 文件不存在: {pptx_path}", file=sys.stderr)
        sys.exit(1)
    if not pptx_path.suffix.lower() == ".pptx":
        print(f"错误: 仅支持 .pptx 文件", file=sys.stderr)
        sys.exit(1)

    if args.style_only:
        extract_style_only(
            pptx_path, args.output,
            take_screenshots_flag=args.screenshot
        )
        return

    try:
        data = convert_pptx_to_svg_templates(
            pptx_path, args.output,
            take_screenshots_flag=args.screenshot
        )
    except ValueError as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)
    print(f"SVG 模板生成完成: {data['slide_count']} 页")
    print(f"SVG 文件: {', '.join(data['svg_files'])}")
    print(f"未解析形状: {data['unresolved_count']} 个")
    print(f"截图: {'可用' if data['screenshots_available'] else '不可用'}")
    print(f"输出目录: {args.output}")


if __name__ == "__main__":
    main()
