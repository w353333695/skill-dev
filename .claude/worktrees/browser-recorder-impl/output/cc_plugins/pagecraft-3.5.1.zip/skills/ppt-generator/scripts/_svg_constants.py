# -*- coding: utf-8 -*-
"""Shared constants, namespace URIs, and unit conversion utilities."""

# XML namespace URIs
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

# python-pptx qn helper
try:
    from pptx.oxml.ns import qn
except ImportError:
    qn = None  # type: ignore[assignment]

# MSO theme color index → scheme tag
MSO_TO_SCHEME = {
    1: "dk1", 2: "dk2", 3: "lt1", 4: "lt2",
    5: "accent1", 6: "accent2", 7: "accent3",
    8: "accent4", 9: "accent5", 10: "accent6",
    11: "hlink", 12: "folHlink",
    13: "tx1", 14: "bg1", 15: "tx2", 16: "bg2",
}

# Unit constants
EMU_PER_PT = 12700
EMU_PER_PX = 9525  # at 96 dpi
DEFAULT_INSET_L_R = 91440   # 0.1 inch
DEFAULT_INSET_T_B = 45720   # 0.05 inch


def emu_to_px(emu):
    """EMU → pixel (96 dpi)"""
    if emu is None:
        return 0
    return round(int(emu) / EMU_PER_PX)


def emu_to_pt(emu):
    """EMU → point"""
    if emu is None:
        return 0
    return round(int(emu) / EMU_PER_PT, 1)


def escape_xml(s):
    """XML 转义"""
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
