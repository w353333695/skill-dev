#!/usr/bin/env python3
"""
pipeline.py - PPT 后处理统一入口

将讲稿拆分、SVG 后处理、PPTX 导出三步合并为单一命令。

Usage:
    python3 pipeline.py <project_path>
    python3 pipeline.py <project_path> --step split
    python3 pipeline.py <project_path> --step finalize
    python3 pipeline.py <project_path> --step export
    python3 pipeline.py <project_path> --step split --step finalize
    python3 pipeline.py <project_path> --continue-on-error
"""

import argparse
import subprocess
import sys
from pathlib import Path


SCRIPTS_DIR = Path(__file__).parent


def run_step(name: str, args: list, quiet: bool = False) -> bool:
    """执行单个处理步骤，返回是否成功

    Args:
        name: 脚本名（不含 .py 后缀）
        args: 传递给脚本的参数列表
        quiet: 是否静默输出

    Returns:
        True 表示成功，False 表示失败
    """
    script = SCRIPTS_DIR / f"{name}.py"
    if not script.exists():
        print(f"❌ Script not found: {script}", file=sys.stderr)
        return False

    result = subprocess.run(
        [sys.executable, str(script)] + args,
        capture_output=True, text=True
    )

    if result.stdout and not quiet:
        print(result.stdout.rstrip())

    if result.returncode != 0:
        stderr = result.stderr.strip()
        if stderr:
            print(f"❌ {name} failed: {stderr}", file=sys.stderr)
        else:
            print(f"❌ {name} failed (exit code {result.returncode})", file=sys.stderr)
        return False

    return True


# 各步骤配置：step_name → (实际脚本名, 参数生成函数)
STEP_SCRIPTS = {
    "split":    "total_md_split",
    "finalize": "finalize_svg",
    "export":   "svg_to_pptx",
}

STEP_ARGS = {
    "split":    lambda p: [p],
    "finalize": lambda p: [p],
    "export":   lambda p: [p, "-s", "final"],
}

ALL_STEPS = list(STEP_SCRIPTS.keys())


def main():
    parser = argparse.ArgumentParser(
        description="PPT post-processing pipeline (split → finalize → export)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s output/ppt-generator/20260326_120000
  %(prog)s output/ppt-generator/20260326_120000 --step split
  %(prog)s output/ppt-generator/20260326_120000 --step split --step export
  %(prog)s output/ppt-generator/20260326_120000 --continue-on-error
"""
    )
    parser.add_argument("project_path", help="Project directory path")
    parser.add_argument(
        "--step", nargs="*", choices=ALL_STEPS,
        help="Run specific steps only (default: all)"
    )
    parser.add_argument(
        "--continue-on-error", action="store_true",
        help="Continue on step failure instead of stopping"
    )
    parser.add_argument(
        "-q", "--quiet", action="store_true",
        help="Suppress step output"
    )

    args = parser.parse_args()

    project_path = args.project_path
    steps = args.step or ALL_STEPS

    # Validate project path exists
    if not Path(project_path).exists():
        print(f"❌ Project path does not exist: {project_path}", file=sys.stderr)
        sys.exit(1)

    print(f"🚀 Pipeline: {len(steps)} step(s) on {project_path}")

    results = {}
    for step in steps:
        print(f"\n📋 Running: {step}...")
        step_args = STEP_ARGS[step](project_path)
        script_name = STEP_SCRIPTS[step]
        results[step] = run_step(script_name, step_args, quiet=args.quiet)

        if not results[step] and not args.continue_on_error:
            print(f"\n❌ Pipeline stopped at '{step}'", file=sys.stderr)
            sys.exit(1)

    succeeded = sum(results.values())
    total = len(steps)
    if succeeded == total:
        print(f"\n✅ Pipeline complete: all {total} steps succeeded")
    else:
        failed = total - succeeded
        print(f"\n⚠️ Pipeline complete: {succeeded}/{total} succeeded, {failed} failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
