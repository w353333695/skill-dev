#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Style Advisor - PPT 风格推荐引擎

基于 BM25 搜索的本地风格推荐，无联网依赖。

Usage:
    python3 style_advisor.py "深色科技风 企业级" --domain color
    python3 style_advisor.py "战略汇报 高管演示" --design-system
    python3 style_advisor.py "极简风格 学术报告" --domain typography
"""

import argparse
import csv
import re
from math import log
from collections import defaultdict
from pathlib import Path


# ============ CONFIGURATION ============
DATA_DIR = Path(__file__).parent.parent / "references" / "advisor"
MAX_RESULTS = 3

CSV_CONFIG = {
    "style": {
        "file": "styles.csv",
        "search_cols": ["Style Category", "Keywords", "Best For", "Type", "AI Prompt Keywords"],
        "output_cols": ["Style Category", "Type", "Keywords", "Primary Colors",
                        "Effects & Animation", "Best For", "Performance",
                        "Accessibility", "Complexity", "AI Prompt Keywords",
                        "Design System Variables"]
    },
    "color": {
        "file": "colors.csv",
        "search_cols": ["Product Type", "Notes"],
        "output_cols": ["Product Type", "Primary (Hex)", "Secondary (Hex)",
                        "CTA (Hex)", "Background (Hex)", "Text (Hex)", "Notes"]
    },
    "typography": {
        "file": "typography.csv",
        "search_cols": ["Font Pairing Name", "Category", "Mood/Style Keywords",
                        "Best For", "Heading Font", "Body Font"],
        "output_cols": ["Font Pairing Name", "Category", "Heading Font", "Body Font",
                        "Mood/Style Keywords", "Best For", "Notes"]
    },
    "chart": {
        "file": "charts.csv",
        "search_cols": ["Data Type", "Keywords", "Best Chart Type", "Accessibility Notes"],
        "output_cols": ["Data Type", "Keywords", "Best Chart Type", "Secondary Options",
                        "Color Guidance", "Accessibility Notes", "Library Recommendation",
                        "Interactive Level"]
    },
}

REASONING_FILE = "ui-reasoning.csv"

DESIGN_SYSTEM_SEARCH = {
    "style": {"max_results": 3},
    "color": {"max_results": 2},
    "typography": {"max_results": 2},
    "chart": {"max_results": 2},
}


# ============ BM25 IMPLEMENTATION ============
class BM25:
    """BM25 ranking algorithm for text search"""

    def __init__(self, k1=1.5, b=0.75):
        self.k1 = k1
        self.b = b
        self.corpus = []
        self.doc_lengths = []
        self.avgdl = 0
        self.idf = {}
        self.doc_freqs = defaultdict(int)
        self.N = 0

    def tokenize(self, text):
        text = re.sub(r'[^\w\s]', ' ', str(text).lower())
        return [w for w in text.split() if len(w) > 2]

    def fit(self, documents):
        self.corpus = [self.tokenize(doc) for doc in documents]
        self.N = len(self.corpus)
        if self.N == 0:
            return
        self.doc_lengths = [len(doc) for doc in self.corpus]
        self.avgdl = sum(self.doc_lengths) / self.N

        for doc in self.corpus:
            seen = set()
            for word in doc:
                if word not in seen:
                    self.doc_freqs[word] += 1
                    seen.add(word)

        for word, freq in self.doc_freqs.items():
            self.idf[word] = log((self.N - freq + 0.5) / (freq + 0.5) + 1)

    def score(self, query):
        query_tokens = self.tokenize(query)
        scores = []

        for idx, doc in enumerate(self.corpus):
            score = 0
            doc_len = self.doc_lengths[idx]
            term_freqs = defaultdict(int)
            for word in doc:
                term_freqs[word] += 1

            for token in query_tokens:
                if token in self.idf:
                    tf = term_freqs[token]
                    idf = self.idf[token]
                    numerator = tf * (self.k1 + 1)
                    denominator = tf + self.k1 * (1 - self.b + self.b * doc_len / self.avgdl)
                    score += idf * numerator / denominator

            scores.append((idx, score))

        return sorted(scores, key=lambda x: x[1], reverse=True)


# ============ SEARCH FUNCTIONS ============
def _load_csv(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def _search_csv(filepath, search_cols, output_cols, query, max_results):
    if not filepath.exists():
        return []

    data = _load_csv(filepath)
    documents = [" ".join(str(row.get(col, "")) for col in search_cols) for row in data]

    bm25 = BM25()
    bm25.fit(documents)
    ranked = bm25.score(query)

    results = []
    for idx, score in ranked[:max_results]:
        if score > 0:
            row = data[idx]
            results.append({col: row.get(col, "") for col in output_cols if col in row})

    return results


def detect_domain(query):
    query_lower = query.lower()

    domain_keywords = {
        "color": ["color", "palette", "hex", "#", "rgb", "配色", "颜色"],
        "chart": ["chart", "graph", "visualization", "trend", "bar", "pie",
                   "scatter", "heatmap", "funnel", "图表", "可视化"],
        "style": ["style", "design", "ui", "minimalism", "glassmorphism",
                   "neumorphism", "brutalism", "dark mode", "flat",
                   "风格", "设计", "极简", "科技", "商务"],
        "typography": ["font", "typography", "heading", "serif", "sans",
                        "字体", "排版"],
    }

    scores = {domain: sum(1 for kw in keywords if kw in query_lower)
              for domain, keywords in domain_keywords.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "style"


def search(query, domain=None, max_results=MAX_RESULTS):
    if domain is None:
        domain = detect_domain(query)

    config = CSV_CONFIG.get(domain, CSV_CONFIG["style"])
    filepath = DATA_DIR / config["file"]

    if not filepath.exists():
        return {"error": f"File not found: {filepath}", "domain": domain}

    results = _search_csv(filepath, config["search_cols"], config["output_cols"],
                          query, max_results)

    return {
        "domain": domain,
        "query": query,
        "file": config["file"],
        "count": len(results),
        "results": results
    }


# ============ DESIGN SYSTEM GENERATOR ============
class DesignSystemGenerator:
    """Generates design system recommendations for PPT."""

    def __init__(self):
        self.reasoning_data = self._load_reasoning()

    def _load_reasoning(self):
        filepath = DATA_DIR / REASONING_FILE
        if not filepath.exists():
            return []
        with open(filepath, 'r', encoding='utf-8') as f:
            return list(csv.DictReader(f))

    def _find_reasoning_rule(self, category: str) -> dict:
        category_lower = category.lower()

        for rule in self.reasoning_data:
            if rule.get("UI_Category", "").lower() == category_lower:
                return rule

        for rule in self.reasoning_data:
            ui_cat = rule.get("UI_Category", "").lower()
            if ui_cat in category_lower or category_lower in ui_cat:
                return rule

        for rule in self.reasoning_data:
            ui_cat = rule.get("UI_Category", "").lower()
            keywords = ui_cat.replace("/", " ").replace("-", " ").split()
            if any(kw in category_lower for kw in keywords):
                return rule

        return {}

    def _apply_reasoning(self, category: str) -> dict:
        rule = self._find_reasoning_rule(category)

        if not rule:
            return {
                "style_priority": ["Minimalism", "Flat Design"],
                "color_mood": "Professional",
                "typography_mood": "Clean",
                "key_effects": "Subtle transitions",
                "anti_patterns": "",
            }

        style_priority = [s.strip() for s in rule.get("Style_Priority", "").split("+")]

        return {
            "style_priority": style_priority,
            "color_mood": rule.get("Color_Mood", ""),
            "typography_mood": rule.get("Typography_Mood", ""),
            "key_effects": rule.get("Key_Effects", ""),
            "anti_patterns": rule.get("Anti_Patterns", ""),
        }

    def _select_best_match(self, results: list, priority_keywords: list) -> dict:
        if not results:
            return {}
        if not priority_keywords:
            return results[0]

        for priority in priority_keywords:
            priority_lower = priority.lower().strip()
            for result in results:
                style_name = result.get("Style Category", "").lower()
                if priority_lower in style_name or style_name in priority_lower:
                    return result

        scored = []
        for result in results:
            result_str = str(result).lower()
            score = 0
            for kw in priority_keywords:
                kw_lower = kw.lower().strip()
                if kw_lower in result.get("Style Category", "").lower():
                    score += 10
                elif kw_lower in result.get("Keywords", "").lower():
                    score += 3
                elif kw_lower in result_str:
                    score += 1
            scored.append((score, result))

        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[0][1] if scored and scored[0][0] > 0 else results[0]

    def generate(self, query: str, project_name: str = None) -> dict:
        # Step 1: Search style domain
        style_result = search(query, "style", 3)
        style_results = style_result.get("results", [])
        category = style_results[0].get("Type", "General") if style_results else "General"

        # Step 2: Get reasoning rules
        reasoning = self._apply_reasoning(category)
        style_priority = reasoning.get("style_priority", [])

        # Step 3: Multi-domain search
        color_result = search(query, "color", 2)
        typography_result = search(query, "typography", 2)
        chart_result = search(query, "chart", 2)

        # Step 4: Select best matches
        color_results = color_result.get("results", [])
        typography_results = typography_result.get("results", [])
        chart_results = chart_result.get("results", [])

        best_style = self._select_best_match(style_results, style_priority)
        best_color = color_results[0] if color_results else {}
        best_typography = typography_results[0] if typography_results else {}

        # Step 5: Build recommendation
        style_effects = best_style.get("Effects & Animation", "")
        reasoning_effects = reasoning.get("key_effects", "")
        combined_effects = style_effects if style_effects else reasoning_effects

        return {
            "project_name": project_name or query.upper(),
            "category": category,
            "style": {
                "name": best_style.get("Style Category", "Minimalism"),
                "type": best_style.get("Type", "General"),
                "effects": combined_effects,
                "keywords": best_style.get("Keywords", ""),
                "best_for": best_style.get("Best For", ""),
                "performance": best_style.get("Performance", ""),
                "accessibility": best_style.get("Accessibility", ""),
                "design_variables": best_style.get("Design System Variables", ""),
            },
            "colors": {
                "primary": best_color.get("Primary (Hex)", "#2563EB"),
                "secondary": best_color.get("Secondary (Hex)", "#3B82F6"),
                "accent": best_color.get("CTA (Hex)", "#F97316"),
                "background": best_color.get("Background (Hex)", "#F8FAFC"),
                "text": best_color.get("Text (Hex)", "#1E293B"),
                "notes": best_color.get("Notes", ""),
            },
            "typography": {
                "heading": best_typography.get("Heading Font", "Inter"),
                "body": best_typography.get("Body Font", "Inter"),
                "mood": best_typography.get("Mood/Style Keywords",
                                           reasoning.get("typography_mood", "")),
                "best_for": best_typography.get("Best For", ""),
            },
            "charts": chart_results[:3] if chart_results else [],
            "key_effects": combined_effects,
            "anti_patterns": reasoning.get("anti_patterns", ""),
        }


# ============ OUTPUT FORMATTERS ============
def format_ascii_box(design_system: dict) -> str:
    project = design_system.get("project_name", "PROJECT")
    style = design_system.get("style", {})
    colors = design_system.get("colors", {})
    typography = design_system.get("typography", {})
    effects = design_system.get("key_effects", "")

    W = 80
    lines = []
    lines.append("+" + "-" * W + "+")
    lines.append(f"|  PPT DESIGN RECOMMENDATION: {project}".ljust(W + 1) + "|")
    lines.append("+" + "-" * W + "+")
    lines.append("|" + " " * (W + 1) + "|")

    lines.append(f"|  STYLE: {style.get('name', '')}".ljust(W + 1) + "|")
    if style.get("keywords"):
        lines.append(f"|    Keywords: {style.get('keywords', '')}".ljust(W + 1) + "|")
    if style.get("best_for"):
        lines.append(f"|    Best For: {style.get('best_for', '')}".ljust(W + 1) + "|")
    lines.append("|" + " " * (W + 1) + "|")

    lines.append("|  COLORS:".ljust(W + 1) + "|")
    lines.append(f"|    Primary:    {colors.get('primary', '')}".ljust(W + 1) + "|")
    lines.append(f"|    Secondary:  {colors.get('secondary', '')}".ljust(W + 1) + "|")
    lines.append(f"|    Accent:     {colors.get('accent', '')}".ljust(W + 1) + "|")
    lines.append(f"|    Background: {colors.get('background', '')}".ljust(W + 1) + "|")
    lines.append(f"|    Text:       {colors.get('text', '')}".ljust(W + 1) + "|")
    lines.append("|" + " " * (W + 1) + "|")

    lines.append(f"|  TYPOGRAPHY: {typography.get('heading', '')} / {typography.get('body', '')}".ljust(W + 1) + "|")
    if typography.get("mood"):
        lines.append(f"|    Mood: {typography.get('mood', '')}".ljust(W + 1) + "|")
    lines.append("|" + " " * (W + 1) + "|")

    if effects:
        lines.append("|  KEY EFFECTS:".ljust(W + 1) + "|")
        lines.append(f"|    {effects}".ljust(W + 1) + "|")
        lines.append("|" + " " * (W + 1) + "|")

    charts = design_system.get("charts", [])
    if charts:
        lines.append("|  RECOMMENDED CHARTS:".ljust(W + 1) + "|")
        for i, chart in enumerate(charts, 1):
            ctype = chart.get("Best Chart Type", "")
            dtype = chart.get("Data Type", "")
            lines.append(f"|    {i}. {ctype} ({dtype})".ljust(W + 1) + "|")
        lines.append("|" + " " * (W + 1) + "|")

    anti = design_system.get("anti_patterns", "")
    if anti:
        lines.append("|  AVOID: ".ljust(W + 1) + "|")
        lines.append(f"|    {anti[:70]}".ljust(W + 1) + "|")
        lines.append("|" + " " * (W + 1) + "|")

    lines.append("+" + "-" * W + "+")
    return "\n".join(lines)


def format_json(design_system: dict) -> str:
    import json
    return json.dumps(design_system, ensure_ascii=False, indent=2)


# ============ CLI ============
def main():
    parser = argparse.ArgumentParser(
        description="PPT Style Advisor - BM25 search for style/color/typography recommendations"
    )
    parser.add_argument("query", help="Search query (e.g., '深色科技风 企业级')")
    parser.add_argument("--domain", "-d",
                        choices=["style", "color", "typography", "chart"],
                        help="Search specific domain")
    parser.add_argument("--design-system", action="store_true",
                        help="Generate full design system recommendation")
    parser.add_argument("--format", "-f", choices=["ascii", "json"], default="ascii",
                        help="Output format (default: ascii)")
    parser.add_argument("--max-results", "-n", type=int, default=3,
                        help="Max results per domain (default: 3)")

    args = parser.parse_args()

    if args.design_system:
        generator = DesignSystemGenerator()
        ds = generator.generate(args.query)
        if args.format == "json":
            print(format_json(ds))
        else:
            print(format_ascii_box(ds))
    else:
        result = search(args.query, args.domain, args.max_results)
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            sys.exit(1)
        if args.format == "json":
            print(format_json(result))
        else:
            print(f"\nDomain: {result['domain']} | Results: {result['count']}\n")
            for i, r in enumerate(result["results"], 1):
                print(f"--- Result {i} ---")
                for k, v in r.items():
                    if v:
                        print(f"  {k}: {v}")
                print()


if __name__ == "__main__":
    import sys
    main()
