#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C3 模板提升与占位符替换工具

读取 Agent 输出的 JSON 决策文件，执行：
1. 分类提升（slide_XX_unknown.svg → 标准模板名）
2. content 页 framework 替换（保留页眉页脚，正文区替换为 CONTENT_AREA）
3. 占位符文本替换
4. 回写 template_data.json
5. 重新生成 design_spec.md

Usage:
    python3 pptx_template_apply.py $PPT_DIR/templates/template_data.json \
        --decision $PPT_DIR/templates/c3_decision.json

Decision JSON format (按页面分组):
    {
      "pages": [
        {
          "slide_index": 1,
          "template": "02_toc",
          "type": "toc",
          "promotion_reason": "...",
          "layout": {
            "description": "左右分栏布局...",
            "bg_description": "白色背景",
            "decorations": [
              {"type": "rect", "position": "left_top", "color": "#4A5EE6", "note": "..."}
            ]
          },
          "texts": [
            {
              "original": "议程",
              "placeholder": "{{PAGE_TITLE}}",
              "font_size_px": 48,
              "color": "#36393B"
            }
          ]
        }
      ]
    }

Allowed placeholders (from built-in templates):
    cover: {{TITLE}}, {{SUBTITLE}}, {{AUTHOR}}, {{DATE}}, {{PRESENTER}}, {{ORGANIZATION}}, {{INSTITUTION}}, {{LOGO}}, {{LOGO_LARGE}}
    toc: {{PAGE_TITLE}}, {{TOC_ITEM_1..6}}, {{TOC_ITEM_1..N_TITLE}}, {{TOC_ITEM_1..N_DESC}}
    chapter: {{CHAPTER_NUM}}, {{CHAPTER_TITLE}}, {{CHAPTER_DESC}}, {{CHAPTER_SUBTITLE}}, {{PAGE_NUM}}, {{SECTION_NAME}}
    content: {{PAGE_TITLE}}, {{PAGE_NUM}}, {{SECTION_NAME}}, {{CHAPTER_NUM}}
    ending: {{THANK_YOU}}, {{CONTACT_INFO}}, {{TAGLINE}}, {{COPYRIGHT}}, {{CLOSING_MESSAGE}}, {{AUTHOR}}, {{DATE}}
    Note: {{CONTENT_AREA}} is auto-inserted for content pages, do not include in replacements.
"""

import argparse
import json
import re
import sys
from pathlib import Path

# Import from sibling modules
_SCRIPTS_DIR = Path(__file__).parent
sys.path.insert(0, str(_SCRIPTS_DIR))

from _pptx_design_spec import generate_design_spec


def load_template_data(td_path):
    """读取 template_data.json"""
    with open(td_path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_decision(decision_path):
    """读取 C3 决策文件"""
    with open(decision_path, "r", encoding="utf-8") as f:
        return json.load(f)


def _get_promotions(decision):
    """从 decision 中提取 promotions"""
    pages = decision.get("pages", [])
    return [
        {
            "slide_index": p["slide_index"],
            "type": p.get("type", ""),
            "reason": p.get("promotion_reason", ""),
        }
        for p in pages
    ]


def _get_replacements(decision):
    """从 decision 中提取 replacements"""
    pages = decision.get("pages", [])
    return [
        {
            "template": p["template"],
            "mappings": [
                {
                    "original": t.get("original", ""),
                    "placeholder": t.get("placeholder", ""),
                }
                for t in p.get("texts", [])
            ],
        }
        for p in pages
    ]


def apply_classification(td, decision, templates_dir):
    """执行分类提升：复制/重命名 unknown SVG → 标准模板名"""
    promotions = _get_promotions(decision)
    type_to_template = td.get("type_to_template", {})
    standard_templates = td.get("standard_templates", {})

    promoted_indices = set()
    # 用现有 standard_templates 预填占用表，避免覆盖 C2 已生成的确定性模板
    used_templates = dict(standard_templates)  # template_name → slide_index
    # unknown → template 映射，用于 replacement 重定向
    unknown_to_template = {}  # "slide_XX_unknown" → "0N_template"

    for promo in promotions:
        slide_index = promo["slide_index"]
        page_type = promo.get("type", "").strip()

        # 跳过未分类的页面
        if not page_type:
            print(f"  ⏭️  slide {slide_index} 未分类，跳过")
            continue

        template_name = type_to_template.get(page_type)
        if not template_name:
            print(f"  ⚠️ 未知类型 '{page_type}'，跳过 slide {slide_index}", file=sys.stderr)
            continue

        # 校验：每个标准模板只能被一个 slide 占用
        # 允许幂等重跑：同一 slide 重新 promote 到同一模板时不报错
        if template_name in used_templates:
            existing_idx = used_templates[template_name]
            if existing_idx == slide_index:
                # 幂等：同一 slide 重复 promote，跳过但不算错误
                promoted_indices.add(slide_index)
                unknown_to_template[f"slide_{slide_index + 1:02d}_unknown"] = template_name
                continue
            print(
                f"  ⚠️ 模板 {template_name} 已被 slide {existing_idx} 占用，"
                f"跳过 slide {slide_index}。如需更换代表页，"
                f"请先将 slide {existing_idx} 的 type 置空。",
                file=sys.stderr,
            )
            continue

        src = templates_dir / f"slide_{slide_index + 1:02d}_unknown.svg"
        dst = templates_dir / f"{template_name}.svg"

        if not src.exists():
            print(f"  ⚠️ 源文件不存在: {src}", file=sys.stderr)
            continue

        # 复制文件
        dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
        print(f"  ✅ {src.name} → {dst.name} ({page_type})")

        # 删除原始 unknown 文件（提升后不再需要）
        src.unlink()
        print(f"  🗑️  已清理: {src.name}")

        promoted_indices.add(slide_index)
        used_templates[template_name] = slide_index
        unknown_to_template[f"slide_{slide_index + 1:02d}_unknown"] = template_name

        # 更新 standard_templates
        standard_templates[template_name] = slide_index

        # 更新对应 slide 的 type 和 assigned_template
        for slide_info in td["slides"]:
            if slide_info["slide_index"] == slide_index:
                slide_info["type"] = page_type
                slide_info["assigned_template"] = template_name
                break

    td["standard_templates"] = standard_templates
    td["_unknown_to_template"] = unknown_to_template  # 供 replacement 重定向用

    # 同步更新 svg_files 列表（移除 unknown，加入标准模板名）
    svg_files = td.get("svg_files", [])
    new_svg_files = []
    for f in svg_files:
        if f.startswith("slide_") and f.endswith("_unknown.svg"):
            # 只移除已被提升的 unknown 文件；保留未分类的
            idx = int(f.split("_")[1]) - 1
            if idx in promoted_indices:
                continue
        new_svg_files.append(f)
    # 加入新提升的标准模板文件
    for template_name in standard_templates:
        svg_name = f"{template_name}.svg"
        if svg_name not in new_svg_files:
            new_svg_files.append(svg_name)
    # 按标准序号排序
    order = {"01_cover": 0, "02_toc": 1, "03_chapter": 2, "04_content": 3, "05_ending": 4}
    new_svg_files.sort(key=lambda name: order.get(name.replace(".svg", ""), 99))
    td["svg_files"] = new_svg_files

    return td


def apply_placeholder_replacement(td, decision, templates_dir):
    """执行占位符替换"""
    replacements = _get_replacements(decision)

    # 获取模板名 → 类型的映射
    type_to_template = td.get("type_to_template", {})
    template_to_type = {v: k for k, v in type_to_template.items()}
    # C3 提升产生的 unknown → template 映射，用于 replacement 重定向
    unknown_to_template = td.get("_unknown_to_template", {})

    for rep in replacements:
        template_name = rep.get("template", "")
        # 若 template 仍是 slide_XX_unknown，尝试重定向到已提升的标准模板名
        if template_name.startswith("slide_") and template_name.endswith("_unknown"):
            redirected = unknown_to_template.get(template_name)
            if redirected:
                template_name = redirected
                print(f"  🔄 replacement 重定向: {rep['template']} → {template_name}")
            else:
                # 未提升的 unknown 模板，跳过
                continue

        svg_path = templates_dir / f"{template_name}.svg"
        if not svg_path.exists():
            print(f"  ⚠️ SVG 文件不存在: {svg_path}", file=sys.stderr)
            continue

        svg_content = svg_path.read_text(encoding="utf-8")

        # 处理映射（跳过 placeholder 为空的）
        page_type = template_to_type.get(template_name)
        for mapping in rep.get("mappings", []):
            old_text = mapping.get("original", "")
            new_text = mapping.get("placeholder", "")
            if not old_text or not new_text:
                continue
            # content 类型模板：跳过 {{CONTENT_AREA}} 的替换（由 framework 处理）
            # 但保留 {{PAGE_TITLE}} 等其他占位符替换
            if page_type == "content" and new_text == "{{CONTENT_AREA}}":
                continue
            svg_content = _replace_text_in_svg(svg_content, old_text, new_text)

        svg_path.write_text(svg_content, encoding="utf-8")
        print(f"  ✅ 占位符替换完成: {svg_path.name}")

    warn_missing_placeholders(decision, template_to_type, unknown_to_template)

    return td


def _replace_text_in_svg(svg_content, old_text, new_text):
    """在 SVG 内容中替换文本，保留 XML 结构

    支持 old_text 与 SVG 中的文本有首尾空格差异（SVG 中常保留尾部空格）。
    """
    def _xml_escape(s):
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    old_escaped = _xml_escape(old_text)
    new_escaped = _xml_escape(new_text)

    # 匹配 tspan 中的文本，允许首尾有额外空格
    pattern = rf'(<tspan[^>]*>)(\s*{re.escape(old_escaped)}\s*)(</tspan>)'

    def _replacer(match):
        prefix = match.group(1)
        # 保留原始的首尾空格，只替换中间内容
        original = match.group(2)
        suffix = match.group(3)
        leading = original[:len(original) - len(original.lstrip())]
        trailing = original[len(original.rstrip()):]
        return f"{prefix}{leading}{new_escaped}{trailing}{suffix}"

    svg_content = re.sub(pattern, _replacer, svg_content)

    return svg_content


def _replace_toc_list_items(svg_content, item_placeholders):
    """替换 TOC 列表项：将包含多个列表项的 <text> 元素内的 tspan 替换为占位符

    item_placeholders: 列表，如 ["{{TOC_ITEM_1}}", "{{TOC_ITEM_2}}", ...]
    或 ["{{TOC_ITEM_1_TITLE}}", "{{TOC_ITEM_1_DESC}}", ...]
    只替换包含 ≥2 个非空 tspan 的 <text> 元素（即列表容器），跳过单 tspan 的标题 text。
    """
    import re

    def _replace_in_text_element(match):
        text_content = match.group(0)

        # 统计非空 tspan 数量
        tspans = re.findall(r'(<tspan[^>]*>)([^<]*)(</tspan>)', text_content)
        non_empty_tspans = [t for t in tspans if t[1].strip() and not t[1].strip().startswith("{{")]

        # 只有 ≥2 个非空 tspan 才认为是列表容器（TOC 列表）
        if len(non_empty_tspans) < 2:
            return text_content

        placeholder_idx = 0

        def _replace_tspan(tspan_match):
            nonlocal placeholder_idx
            prefix = tspan_match.group(1)
            tspan_text = tspan_match.group(2)
            suffix = tspan_match.group(3)

            # 跳过空文本或已替换的占位符
            if not tspan_text.strip() or tspan_text.strip().startswith("{{"):
                return tspan_match.group(0)

            if placeholder_idx < len(item_placeholders):
                ph = item_placeholders[placeholder_idx]
                placeholder_idx += 1
                return f"{prefix}{ph}{suffix}"

            return tspan_match.group(0)

        return re.sub(
            r'(<tspan[^>]*>)([^<]*)(</tspan>)',
            _replace_tspan,
            text_content
        )

    svg_content = re.sub(
        r'(<text[^>]*>(?:(?!</text>).)*</text>)',
        _replace_in_text_element,
        svg_content,
        flags=re.DOTALL
    )

    return svg_content


def apply_content_framework(td, decision, templates_dir):
    """对 content 类型的模板执行 framework 替换

    注意：path 元素（<path d="...">）因 d 属性解析不可靠，不参与 bbox 计算且不被删除。
    这避免了误删页眉/页脚装饰线，但也意味着正文 path（arc、custom geometry）会保留在
    SVG 中，可能与 {{CONTENT_AREA}} 共存。如需清理，请在 C3-e 或 C4 阶段手动编辑 SVG。
    """
    type_to_template = td.get("type_to_template", {})
    template_to_type = {v: k for k, v in type_to_template.items()}
    standard_templates = td.get("standard_templates", {})

    # 按实际成功提升的 standard_templates 中的 content 类型模板执行 framework 替换
    # 不直接读取 decision["promotions"]，因为 apply_classification() 可能因占用冲突跳过某些 promotion
    content_templates = [
        name for name, idx in standard_templates.items()
        if template_to_type.get(name) == "content"
    ]

    for template_name in content_templates:
        svg_path = templates_dir / f"{template_name}.svg"

        if not svg_path.exists():
            continue

        # 读取原始 SVG
        svg_content = svg_path.read_text(encoding="utf-8")

        # 防重复：若已包含 CONTENT_AREA，跳过
        if "{{CONTENT_AREA}}" in svg_content:
            print(f"  ⏭️  {svg_path.name} 已包含 CONTENT_AREA，跳过")
            continue

        # 解析 viewBox 获取画布尺寸
        vb_match = re.search(r'viewBox="(\d+)\s+(\d+)\s+(\d+)\s+(\d+)"', svg_content)
        if vb_match:
            canvas_w = int(vb_match.group(3))
            canvas_h = int(vb_match.group(4))
        else:
            canvas_w, canvas_h = 1280, 720

        # 提取所有 shape 元素的 bbox
        content_bboxes = _extract_content_bboxes(svg_content, canvas_h)

        if content_bboxes:
            # 计算内容区包围盒
            min_x = min(b[0] for b in content_bboxes)
            min_y = min(b[1] for b in content_bboxes)
            max_x = max(b[0] + b[2] for b in content_bboxes)
            max_y = max(b[1] + b[3] for b in content_bboxes)

            # 留边距
            cx = max(0, min_x - 20)
            cy = max(100, min_y - 20)
            cw = min(canvas_w - cx, max_x - cx + 40)
            ch = min(canvas_h - cy - 60, max_y - cy + 40)
        else:
            # 无可解析 bbox（如纯 path 页面），使用画布安全区域兜底
            margin = 60
            cx = margin
            cy = 120  # 页眉下方
            cw = canvas_w - margin * 2
            ch = canvas_h - cy - margin  # 页脚上方

        if cw > 50 and ch > 50:
            # 收集当前模板的 replacement 信息，用于 framework 移除时判断 text 是否为框架
            unknown_to_template = td.get("_unknown_to_template", {})
            framework_texts = _collect_framework_texts(decision, template_name, unknown_to_template)

            # 移除内容区内的非框架元素
            svg_content = _remove_non_framework_elements(svg_content, canvas_h, framework_texts)

            # 在 </svg> 之前插入 CONTENT_AREA
            content_area_svg = (
                f'\n<rect x="{cx}" y="{cy}" width="{cw}" height="{ch}" '
                f'fill="none" stroke="#E2E8F0" stroke-width="1" stroke-dasharray="8,4"/>\n'
                f'<text x="{cx + cw/2}" y="{cy + ch/2}" text-anchor="middle" '
                f'fill="#CBD5E1" font-size="16">{{{{CONTENT_AREA}}}}</text>'
            )
            svg_content = svg_content.replace("</svg>", content_area_svg + "\n</svg>")

        svg_path.write_text(svg_content, encoding="utf-8")
        print(f"  ✅ Framework 替换完成: {svg_path.name}")

        # 若 SVG 中仍有 path 元素，提示手动审查
        if '<path ' in svg_content or '<path\n' in svg_content or '<path\t' in svg_content:
            print(f"  ⚠️  {svg_path.name} 包含 <path> 元素（arc/custom geometry），"
                  f"已保留未删除。如为正文内容，请在 C3-e/C4 手动清理。")

    return td


def _extract_element_bbox(elem):
    """从单个 SVG 元素字符串中提取 (x, y, w, h)，无法提取时返回 None"""
    # rect/image/text: x/y/width/height
    x_match = re.search(r'\sx="([^"]+)"', elem)
    y_match = re.search(r'\sy="([^"]+)"', elem)
    w_match = re.search(r'\swidth="([^"]+)"', elem)
    h_match = re.search(r'\sheight="([^"]+)"', elem)

    x = y = w = h = None
    try:
        if x_match:
            x = float(x_match.group(1))
        if y_match:
            y = float(y_match.group(1))
        if w_match:
            w = float(w_match.group(1))
        if h_match:
            h = float(h_match.group(1))
    except (ValueError, AttributeError):
        pass

    # ellipse: cx/cy/rx/ry
    if x is None or y is None or w is None or h is None:
        cx_m = re.search(r'\scx="([^"]+)"', elem)
        cy_m = re.search(r'\scy="([^"]+)"', elem)
        rx_m = re.search(r'\srx="([^"]+)"', elem)
        ry_m = re.search(r'\sry="([^"]+)"', elem)
        r_m = re.search(r'\sr="([^"]+)"', elem)  # circle
        try:
            if cx_m and cy_m:
                cx = float(cx_m.group(1))
                cy = float(cy_m.group(1))
                if rx_m and ry_m:
                    rx = float(rx_m.group(1))
                    ry = float(ry_m.group(1))
                    x = cx - rx
                    y = cy - ry
                    w = 2 * rx
                    h = 2 * ry
                elif r_m:
                    r = float(r_m.group(1))
                    x = cx - r
                    y = cy - r
                    w = 2 * r
                    h = 2 * r
        except (ValueError, AttributeError):
            pass

    # line: x1/y1/x2/y2
    if x is None or y is None or w is None or h is None:
        x1_m = re.search(r'\sx1="([^"]+)"', elem)
        y1_m = re.search(r'\sy1="([^"]+)"', elem)
        x2_m = re.search(r'\sx2="([^"]+)"', elem)
        y2_m = re.search(r'\sy2="([^"]+)"', elem)
        try:
            if x1_m and y1_m and x2_m and y2_m:
                x1 = float(x1_m.group(1))
                y1 = float(y1_m.group(1))
                x2 = float(x2_m.group(1))
                y2 = float(y2_m.group(1))
                x = min(x1, x2)
                y = min(y1, y2)
                w = abs(x2 - x1)
                h = abs(y2 - y1)
        except (ValueError, AttributeError):
            pass

    # polygon/polyline: points
    if x is None or y is None or w is None or h is None:
        pts_m = re.search(r'\spoints="([^"]+)"', elem)
        if pts_m:
            pts_str = pts_m.group(1).strip()
            coords = []
            for pt in pts_str.split():
                if ',' in pt:
                    try:
                        px, py = map(float, pt.split(','))
                        coords.append((px, py))
                    except ValueError:
                        pass
            if coords:
                xs = [p[0] for p in coords]
                ys = [p[1] for p in coords]
                x = min(xs)
                y = min(ys)
                w = max(xs) - x
                h = max(ys) - y

    # path: 不解析 d 属性。
    # SVG path 的 d 属性包含 M/L/C/A 等多种命令，参数数量和语义各不相同
    #（如 A 命令的 rx/ry/flags 不是坐标）。精确解析需要完整的状态机，
    # 而简单的数字提取会把非坐标参数误当坐标，导致 bbox 严重错误。
    # 保守策略：path 不参与 bbox 计算，避免错误框覆盖版面。

    if x is None or y is None or w is None or h is None:
        return None
    return (x, y, w, h)


def _extract_content_bboxes(svg_content, canvas_h):
    """从 SVG 内容中提取非框架元素的 bbox"""
    bboxes = []

    # text 元素（跳过已替换为占位符的标题/页脚 text）
    for m in re.finditer(r'(<text[^>]*x="([^"]+)"[^>]*y="([^"]+)"[^>]*>(?:(?!</text>).)*</text>)', svg_content, re.DOTALL):
        try:
            x = float(m.group(2))
            y = float(m.group(3))
            text_elem = m.group(1)
            # 跳过标题占位符（不属于正文内容区）
            if '{{PAGE_TITLE}}' in text_elem:
                continue
            # 跳过页脚/页码占位符
            if '{{SECTION_NAME}}' in text_elem or '{{PAGE_NUM}}' in text_elem:
                continue
            bboxes.append((x, y, 200, 30))
        except ValueError:
            pass

    # rect / image / ellipse / circle / line / polygon / polyline
    # path 不参与 bbox 计算（d 属性解析不可靠，见 _extract_element_bbox 注释）
    for tag in ['rect', 'image', 'ellipse', 'circle', 'line', 'polygon', 'polyline']:
        for m in re.finditer(rf'<{tag}\b[^>]*?/>', svg_content):
            bbox = _extract_element_bbox(m.group(0))
            if bbox:
                bboxes.append(bbox)
        for m in re.finditer(rf'<{tag}\b[^>]*>.*?</{tag}>', svg_content, flags=re.DOTALL):
            bbox = _extract_element_bbox(m.group(0))
            if bbox:
                bboxes.append(bbox)

    # 过滤掉框架元素（页眉/页脚）
    filtered = []
    for x, y, w, h in bboxes:
        if _is_framework_element_from_bbox(x, y, w, h, canvas_h):
            continue
        filtered.append((x, y, w, h))

    return filtered


def _is_framework_element_from_bbox(x, y, w, h, canvas_h, canvas_w=1280):
    """根据 bbox 判断是否为框架元素"""
    # 页眉区域：顶部 120px 内的大宽度元素
    if y <= 120 and w > canvas_w * 0.5:
        return True
    # 页脚区域：底部 80px 内
    if y >= canvas_h - 80:
        return True
    # 右侧竖排页脚/章节标识
    if x > canvas_w * 0.7 and h < 60 and w < 800:
        return True
    # 小装饰元素
    if h <= 4 and (y <= 120 or y >= canvas_h - 100):
        return True
    # 页码/章节标识类小 shape
    if w < 100 and h <= 45 and (y >= canvas_h - 80 or y <= 80):
        return True
    return False


def _collect_framework_texts(decision, template_name, unknown_to_template=None):
    """从 decision 的 replacements 中提取框架文本（有非空 placeholder 且非 CONTENT_AREA）

    只收集属于当前 template_name 的 replacement，避免把其他 unknown 页的
    框架文本误纳入。

    返回 set，包含所有被标记为框架的 original 文本。
    """
    if unknown_to_template is None:
        unknown_to_template = {}

    framework_texts = set()
    for mapping in _iter_template_mappings(decision, template_name, unknown_to_template):
        placeholder = mapping.get("placeholder", "")
        if placeholder and placeholder != "{{CONTENT_AREA}}":
            framework_texts.add(mapping.get("original", ""))
    return framework_texts


def warn_missing_placeholders(decision, template_to_type=None, unknown_to_template=None):
    """对 replacement 中 original 非空但 placeholder 为空的项输出非阻塞警告。"""
    if template_to_type is None:
        template_to_type = {}
    if unknown_to_template is None:
        unknown_to_template = {}

    missing_content = []
    missing_other = []
    for rep in _get_replacements(decision):
        template_name = rep.get("template", "")
        resolved_template = unknown_to_template.get(template_name, template_name)
        page_type = template_to_type.get(resolved_template)
        for mapping in rep.get("mappings", []):
            original = mapping.get("original", "")
            placeholder = mapping.get("placeholder", "")
            if original and not placeholder:
                item = (template_name, original)
                if page_type == "content":
                    missing_content.append(item)
                else:
                    missing_other.append(item)

    if not missing_content and not missing_other:
        return

    if missing_content:
        print(
            "  ⚠️  以下 content 页文本未配置 placeholder，framework 替换时会被视为正文，"
            "由 {{CONTENT_AREA}} 替换；如需保留为模板框架请补充 placeholder，"
            "作为正文内容则可以确认后忽略：",
            file=sys.stderr,
        )
        for template_name, original in missing_content:
            print(f"     - {template_name}: {original}", file=sys.stderr)

    if missing_other:
        print(
            "  ⚠️  以下文本未配置 placeholder，替换时会保留原文；"
            "如需模板化请补充 placeholder，也可以确认后忽略：",
            file=sys.stderr,
        )
        for template_name, original in missing_other:
            print(f"     - {template_name}: {original}", file=sys.stderr)


def _iter_template_mappings(decision, template_name, unknown_to_template=None):
    """遍历属于当前模板的 replacement mappings。"""
    if unknown_to_template is None:
        unknown_to_template = {}

    for rep in _get_replacements(decision):
        rep_template = rep.get("template", "")
        # 精确匹配：当前模板名，或重定向到当前模板的 unknown 名
        if rep_template == template_name:
            pass
        elif rep_template in unknown_to_template and unknown_to_template[rep_template] == template_name:
            pass
        else:
            continue
        yield from rep.get("mappings", [])


def _remove_non_framework_elements(svg_content, canvas_h, framework_texts=None, canvas_w=1280):
    """移除 SVG 中的非框架元素，保留页眉/页脚/装饰等框架元素"""
    import re

    if framework_texts is None:
        framework_texts = set()

    # 先保护 <clipPath>...</clipPath> 内的内容不被正则误删
    clipPath_placeholders = {}
    clipPath_counter = [0]

    def _protect_clipPath(match):
        key = f"__CLIPPATH_{clipPath_counter[0]}__"
        clipPath_counter[0] += 1
        clipPath_placeholders[key] = match.group(0)
        return key

    svg_content = re.sub(r'<clipPath[^>]*>.*?</clipPath>', _protect_clipPath, svg_content, flags=re.DOTALL)

    def _is_framework_svg_element(elem_match):
        """判断 SVG 元素是否为框架元素"""
        elem = elem_match.group(0)
        bbox = _extract_element_bbox(elem)
        if bbox is None:
            # 无法推断位置 → 不认为是框架元素（保守保留）
            return False
        x, y, w, h = bbox
        return _is_framework_element_from_bbox(x, y, w, h, canvas_h, canvas_w)

    # 移除非框架的 rect 元素
    def _remove_rect(match):
        if _is_framework_svg_element(match):
            return match.group(0)
        return ""

    svg_content = re.sub(r'<rect[^/]*/>', _remove_rect, svg_content)
    svg_content = re.sub(r'<rect[^>]*>.*?</rect>', _remove_rect, svg_content, flags=re.DOTALL)

    # 移除非框架的 text 元素（按 tspan 粒度清理）
    # 保留规则（按优先级）：
    # 1. tspan 内容包含 {{...}} 占位符 → 保留该 tspan
    # 2. tspan 内容在 framework_texts 中 → 保留该 tspan
    # 3. 其他 tspan → 删除
    # 4. 若 <text> 的所有 tspan 都被删除，则删除整个 <text>
    def _remove_text(match):
        elem = match.group(0)
        text_tag = match.group(1)
        inner = match.group(2)

        def _remove_tspan(tspan_match):
            tspan_elem = tspan_match.group(0)
            tspan_text = tspan_match.group(2)
            # 已替换占位符 → 保留
            if '{{' in tspan_text and '}}' in tspan_text:
                return tspan_elem
            # 检查文本内容是否在 framework_texts 中
            for text in framework_texts:
                if text and text in tspan_text:
                    return tspan_elem
            # 非框架 tspan → 删除
            return ""

        new_inner = re.sub(
            r'(<tspan[^>]*>)([^<]*)(</tspan>)',
            _remove_tspan,
            inner
        )

        # 清理空 tspan 后若 inner 为空，删除整个 text
        if not new_inner.strip():
            return ""

        # 重建 <text> 元素
        return f"{text_tag}{new_inner}</text>"

    svg_content = re.sub(r'(<text[^>]*>)(.*?)(</text>)', _remove_text, svg_content, flags=re.DOTALL)

    # 移除非框架的 image 元素
    def _remove_image(match):
        if _is_framework_svg_element(match):
            return match.group(0)
        return ""

    svg_content = re.sub(r'<image\b[^>]*?/>', _remove_image, svg_content)

    # 移除非框架的 ellipse/line/circle/polygon/polyline 元素
    for tag in ['ellipse', 'line', 'circle', 'polygon', 'polyline']:
        def _make_remove(tag_name):
            def _remove(match):
                if _is_framework_svg_element(match):
                    return match.group(0)
                return ""
            return _remove

        svg_content = re.sub(rf'<{tag}\b[^>]*?/>', _make_remove(tag), svg_content)
        svg_content = re.sub(rf'<{tag}\b[^>]*>.*?</{tag}>', _make_remove(tag), svg_content, flags=re.DOTALL)

    # path 不删除：d 属性无法可靠推断 bbox，删除可能误删页眉/页脚装饰线
    # path 保留在 SVG 中，由 CONTENT_AREA 覆盖或后续内容覆盖

    # 清理空行
    svg_content = re.sub(r'\n\s*\n', '\n', svg_content)

    # 恢复被保护的 clipPath
    for key, val in clipPath_placeholders.items():
        svg_content = svg_content.replace(key, val)

    return svg_content


def save_template_data(td, td_path):
    """回写 template_data.json"""
    with open(td_path, "w", encoding="utf-8") as f:
        json.dump(td, f, ensure_ascii=False, indent=2)
    print(f"  ✅ template_data.json 已更新")


def regenerate_design_spec(td, decision, templates_dir):
    """重新生成 design_spec.md"""
    spec = generate_design_spec(td, decision)
    spec_path = templates_dir / "design_spec.md"
    with open(spec_path, "w", encoding="utf-8") as f:
        f.write(spec)
    print(f"  ✅ design_spec.md 已重新生成")


def main():
    parser = argparse.ArgumentParser(
        description="C3 模板提升与占位符替换工具"
    )
    parser.add_argument("template_data", type=str,
                        help="template_data.json 路径")
    parser.add_argument("--decision", type=str, required=True,
                        help="C3 决策 JSON 文件路径")
    parser.add_argument("--templates-dir", type=str, default=None,
                        help="模板目录（默认从 template_data 路径推断）")
    args = parser.parse_args()

    td_path = Path(args.template_data)
    if not td_path.exists():
        print(f"错误: template_data.json 不存在: {td_path}", file=sys.stderr)
        sys.exit(1)

    templates_dir = Path(args.templates_dir) if args.templates_dir else td_path.parent
    td = load_template_data(td_path)

    decision_path = Path(args.decision)
    if not decision_path.exists():
        print(f"错误: 决策文件不存在: {decision_path}", file=sys.stderr)
        sys.exit(1)

    decision = load_decision(decision_path)

    print(f"读取 template_data: {td_path}")
    print(f"读取决策文件: {decision_path}")
    print(f"模板目录: {templates_dir}")
    print()

    # 1. 分类提升
    print("Step 1: 分类提升...")
    td = apply_classification(td, decision, templates_dir)
    print()

    # 2. 占位符替换（必须在 framework 替换之前）
    print("Step 2: 占位符替换...")
    td = apply_placeholder_replacement(td, decision, templates_dir)
    print()

    # 3. content 页 framework 替换
    print("Step 3: content 页 framework 替换...")
    td = apply_content_framework(td, decision, templates_dir)
    print()

    # 4. 回写 template_data.json
    print("Step 4: 回写 template_data.json...")
    save_template_data(td, td_path)
    print()

    # 5. 重新生成 design_spec.md
    print("Step 5: 重新生成 design_spec.md...")
    regenerate_design_spec(td, decision, templates_dir)
    print()

    print("✅ C3 应用完成")


if __name__ == "__main__":
    main()
