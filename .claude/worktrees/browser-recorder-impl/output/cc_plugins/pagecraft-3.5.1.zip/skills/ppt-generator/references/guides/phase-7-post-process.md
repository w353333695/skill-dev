# Phase 7: 后处理与导出

> 执行 SVG 后处理、讲稿拆分、PPTX 导出，将中间产物转化为最终交付物

## 目标

- 将 `svg_output/` 中的原始 SVG 处理为 `svg_final/` 中的最终版本
- 将 SVG 批量导出为 PPTX 演示文稿
- 确保最终产物可直接在 PowerPoint 中打开和使用

## 产出物

- `$PPT_DIR/svg_final/*.svg` — 后处理完成的 SVG 最终版本
- `$PPT_DIR/notes/*.md` — 拆分后的独立备注文件
- `$PPT_DIR/*.pptx` — 导出的 PowerPoint 演示文稿

## 前置条件

- Phase 5 已完成（所有 SVG 已生成到 `svg_output/`）
- Phase 6 已完成（演讲备注 `total.md` 已生成）

---

## 执行步骤

### Step 1: 使用 pipeline.py 统一执行

**推荐方式**：使用 `pipeline.py` 一条命令完成后处理和导出（讲稿拆分已在 Phase 6 完成）：

```bash
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize --step export
```

若 Phase 6 未执行或需要重新拆分讲稿，可运行全流程：

```bash
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR
```

该命令按顺序执行以下步骤：
1. **split** — 讲稿拆分（`total_md_split.py`）
2. **finalize** — SVG 后处理（`finalize_svg.py`）
3. **export** — PPTX 导出（`svg_to_pptx.py`）

**pipeline.py 参数说明**：

| 参数 | 说明 | 示例 |
|------|------|------|
| 位置参数 | 项目目录路径 | `$PPT_DIR` |
| `--step` | 仅执行指定步骤（可多次指定） | `--step split --step finalize` |
| `--continue-on-error` | 某步骤失败不中断，继续执行后续步骤 | 无需值 |
| `-q` / `--quiet` | 静默模式，减少输出 | 无需值 |

**常用命令**：

```bash
# 执行全部步骤（推荐）
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR

# 仅执行讲稿拆分
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step split

# 仅执行 SVG 后处理
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize

# 仅执行 PPTX 导出
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step export

# 执行讲稿拆分和导出（跳过后处理）
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step split --step export

# 失败不中断
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --continue-on-error

# 静默模式
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR -q
```

**预期输出**：
```
🚀 Pipeline: 3 step(s) on output/ppt-generator/20260326_143052

📋 Running: split...
[PPT Master - 讲稿拆分工具]
  找到 12 个 SVG 文件
  找到 12 个讲稿章节
[OK] SVG 文件与讲稿一一对应
[完成] 讲稿拆分完成

📋 Running: finalize...
[DIR] 项目: 20260326_143052
[FILE] 12 个 SVG 文件
[1/6] 嵌入图标...
      8 个图标已嵌入
[2/6] 智能裁剪图片...
      3 张图片已裁剪
[3/6] 修复图片宽高比...
      3 张图片已修复
[4/6] 嵌入图片...
      5 张图片已嵌入
[5/6] 文本扁平化...
      12 个文件已处理
[6/6] 圆角转 Path...
      24 个圆角矩形已转换
[OK] 完成!

📋 Running: export...
[正在导出 PPTX...]
[OK] 导出完成: output/ppt-generator/20260326_143052/演示文稿.pptx

✅ Pipeline complete: all 3 steps succeeded
```

---

### Step 2: 分步执行（如需单独控制）

若需要单独控制某个步骤，可分别调用对应脚本。

#### 2.1 讲稿拆分

```bash
python3 $SCRIPTS_DIR/total_md_split.py $PPT_DIR
```

#### 2.2 SVG 后处理

```bash
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR
```

**finalize_svg.py 执行的 6 个处理步骤**：

| 步骤 | 名称 | 说明 |
|------|------|------|
| 1 | embed-icons | 替换 `{{icon:xxx}}` 占位符为实际图标 SVG 代码 |
| 2 | crop-images | 根据 `preserveAspectRatio="slice"` 智能裁剪图片 |
| 3 | fix-aspect | 修复图片宽高比（防止 PPT 转形状时拉伸） |
| 4 | embed-images | 将外部图片转换为 Base64 嵌入（避免外部引用丢失） |
| 5 | flatten-text | 将 `<tspan>` 转为独立 `<text>` 元素（提高兼容性） |
| 6 | fix-rounded | 将 `<rect rx="..."/>` 转为 `<path>`（提高 PPT 兼容性） |

**可选参数**：

```bash
# 仅执行指定处理
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR --only embed-icons fix-rounded

# 预览不执行
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR --dry-run

# 静默模式
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR -q
```

**可用处理选项（用于 `--only`）**：

```
embed-icons   嵌入图标
crop-images   智能裁剪图片
fix-aspect    修复图片宽高比
embed-images  嵌入图片
flatten-text  文本扁平化
fix-rounded   圆角转 Path
```

#### 2.3 PPTX 导出

```bash
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final
```

**参数说明**：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| 位置参数 | 项目目录路径 | 必填 |
| `-s` | SVG 来源目录（`final` 从 `svg_final/` 读取） | `final` |
| `-o` | 输出文件名 | 自动生成 |
| `--no-notes` | 不嵌入演讲备注 | 嵌入备注 |

**常用命令**：

```bash
# 标准导出（从 svg_final/ 读取，嵌入备注）
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final

# 指定输出文件名
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final -o "季度报告.pptx"

# 不嵌入演讲备注
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final --no-notes
```

**预期输出**：
```
[正在导出 PPTX...]
  处理: 01_封面.svg
  处理: 02_目录.svg
  ...
[OK] 导出完成: output/ppt-generator/20260326_143052/演示文稿.pptx
```

---

### Step 3: 验证导出结果

```bash
# 检查 PPTX 文件是否生成
ls -lh $PPT_DIR/*.pptx

# 检查 svg_final 目录
ls $PPT_DIR/svg_final/*.svg | wc -l
```

**验证清单**：

| 检查项 | 说明 |
|--------|------|
| `svg_final/` 文件数量 | 与 `svg_output/` 一致 |
| PPTX 文件大小 | > 100KB（过小可能内容缺失） |
| 图标嵌入 | `svg_final/` 中无 `{{icon:}}` 占位符 |
| 图片嵌入 | `svg_final/` 中无 `href="../images/"` 外部引用 |

### Step 4: 修复后重新导出

若发现问题需要修复 SVG 后重新导出：

```bash
# 1. 修复 svg_output/ 中的 SVG 文件
# （由 Claude Code 直接编辑）

# 2. 重新执行后处理和导出
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize --step export
```

> **禁止**：使用 `cp` 命令将 SVG 从 `svg_output/` 复制到 `svg_final/`，必须通过 `finalize_svg.py` 处理。

## 常见问题

### Q: pipeline.py 执行失败怎么办？

1. 查看错误信息确定失败的步骤
2. 使用 `--continue-on-error` 跳过失败步骤继续
3. 单独执行失败的步骤排查问题

### Q: PPTX 导出后打开发现 SVG 显示异常？

常见原因：
- 使用了禁用的 SVG 功能（clipPath、mask 等）
- rgba() 颜色格式未被处理
- 图片外部引用丢失

解决方案：返回 Phase 8 质量检查，使用 `svg_lint.py` 检测问题。

### Q: 需要重新生成某几页 SVG？

1. 删除 `svg_output/` 中需要重新生成的 SVG
2. 重新生成这些 SVG
3. 重新执行 pipeline（finalize + export）

```bash
# 删除需要重生的 SVG
rm $PPT_DIR/svg_output/03_市场分析.svg

# 重新生成（由 Claude Code 执行）

# 重新后处理和导出
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize --step export
```

### Q: 导出的 PPTX 没有演讲备注？

确认以下步骤：
1. `notes/total.md` 是否存在且内容完整
2. `notes/` 目录下是否有与 SVG 同名的 `.md` 文件
3. 导出时是否误用了 `--no-notes` 参数
