#!/usr/bin/env python3
"""
svg_lint.py - SVG 质量门禁

检测 SVG 文件中的 PPT 不兼容问题和视觉质量规则。

Usage:
    python3 svg_lint.py <directory>              # PPT 兼容性检查
    python3 svg_lint.py <directory> --visual     # + 视觉质量检查
    python3 svg_lint.py <file.svg>               # 检查单个 SVG 文件
    python3 svg_lint.py <directory> --json       # JSON 格式输出

Exit codes:
    0 - 全部通过（或无 SVG 文件）
    1 - 检测到问题
"""

import argparse
import json
import re
import sys
from pathlib import Path


# ============================================================
# PPT 兼容性检查规则
# ============================================================

FORBIDDEN_ELEMENTS = [
    "clipPath",
    "mask",
    "foreignObject",
    "textPath",
    "animate",
    "animateMotion",
    "animateTransform",
    "animateColor",
    "set",
    "script",
    "iframe",
    "style",
    "symbol",
]

FORBIDDEN_ATTRIBUTES = [
    "class",
    "marker-end",
    "onclick",
    "onload",
    "onmouseover",
    "onmouseout",
    "onfocus",
    "onblur",
    "onchange",
]

# id 属性特殊处理：defs 内允许（gradient/filter 定义需要），defs 外禁止
DEF_ALLOWED_ATTRIBUTES = ["id"]

FORBIDDEN_PATTERNS = [
    (r"rgba\s*\(", "rgba() color (PPT incompatible)"),
    (r"<g[^>]*\sopacity\s*=", "<g opacity=...> (use fill opacity instead)"),
    (r"<image[^>]*\sopacity\s*=", "<image opacity=...> (use fill opacity instead)"),
    (r"@font-face", "@font-face (web font not supported in PPT)"),
    (r"@import\s+", "@import (external CSS not supported)"),
]


# ============================================================
# 视觉质量检查规则
# ============================================================

# 最小字号（px），低于此值警告
MIN_FONT_SIZE_BODY = 18
MIN_FONT_SIZE_CAPTION = 12

# 常见低对比度颜色对（浅色文字 on 浅色背景）
LOW_CONTRAST_ON_LIGHT_BG = [
    ("#86868B", "#FBFBFD", 3.0),   # Apple 系统灰 on 近白
    ("#AEAEB2", "#FBFBFD", 2.3),   # Apple 浅灰 on 近白
    ("#86868B", "#FFFFFF", 3.0),    # 系统灰 on 纯白
    ("#AEAEB2", "#FFFFFF", 2.3),    # 浅灰 on 纯白
    ("#86868B", "#F5F5F7", 3.1),    # 系统灰 on Apple 浅灰背景
    ("#AEAEB2", "#F5F5F7", 2.4),    # 浅灰 on Apple 浅灰背景
]

# 常见低对比度颜色对（浅色文字 on 深色背景）
LOW_CONTRAST_ON_DARK_BG = [
    ("#6E6E73", "#000000", 3.5),    # 弱文字 on 纯黑
    ("#6E6E73", "#1C1C1E", 3.2),    # 弱文字 on 卡片深色
]


# ============================================================
# 检测引擎 - PPT 兼容性
# ============================================================

def _is_inside_defs(lines: list, line_num: int) -> bool:
    """检查指定行号是否在 <defs>...</defs> 块内。

    id 属性在 defs 内是必需的（gradient/filter 定义），
    但在内容元素上是禁止的（PPT 不支持 CSS 选择器）。
    """
    in_defs = False
    for i in range(line_num - 1):
        if re.search(r"<defs[\s>]", lines[i], re.IGNORECASE):
            in_defs = True
        if re.search(r"</defs>", lines[i], re.IGNORECASE):
            in_defs = False
    return in_defs


def lint_svg(svg_path: Path) -> list:
    """检查单个 SVG 文件的 PPT 兼容性问题"""
    issues = []

    try:
        content = svg_path.read_text(encoding="utf-8")
    except Exception as e:
        return [{"type": "error", "message": f"Read failed: {e}", "line": None}]

    lines = content.split("\n")

    # 1. 禁用元素检测
    for elem in FORBIDDEN_ELEMENTS:
        pattern = re.compile(rf"<{re.escape(elem)}[\s/>]", re.IGNORECASE)
        for i, line in enumerate(lines, 1):
            if pattern.search(line):
                issues.append({
                    "type": "forbidden_element",
                    "message": f"Forbidden element: <{elem}>",
                    "line": i,
                })

    # 2. 禁用属性检测（id 仅在 <defs> 内允许）
    all_forbidden = FORBIDDEN_ATTRIBUTES + DEF_ALLOWED_ATTRIBUTES
    for attr in all_forbidden:
        pattern = re.compile(rf'\b{re.escape(attr)}\s*=', re.IGNORECASE)
        for i, line in enumerate(lines, 1):
            if attr in DEF_ALLOWED_ATTRIBUTES and _is_inside_defs(lines, i):
                continue  # 允许 defs 内的 id
            if pattern.search(line):
                issues.append({
                    "type": "forbidden_attribute",
                    "message": f"Forbidden attribute: {attr}",
                    "line": i,
                })

    # 3. 禁用模式检测
    for pattern_str, description in FORBIDDEN_PATTERNS:
        pattern = re.compile(pattern_str, re.IGNORECASE)
        for i, line in enumerate(lines, 1):
            if pattern.search(line):
                issues.append({
                    "type": "forbidden_pattern",
                    "message": description,
                    "line": i,
                })

    # 4. viewBox 一致性检查
    _check_viewbox(content, lines, issues)

    return issues


def _check_viewbox(content: str, lines: list, issues: list):
    """检查 viewBox 与 width/height 的比例一致性"""
    vb_match = re.search(r'viewBox="([^"]+)"', content)
    if not vb_match:
        return

    vb_parts = vb_match.group(1).split()
    if len(vb_parts) < 4:
        return

    try:
        vb_w, vb_h = float(vb_parts[2]), float(vb_parts[3])
    except ValueError:
        return

    if vb_w == 0 or vb_h == 0:
        return

    w_match = re.search(r'<svg[^>]*\swidth="([^"]+)"', content)
    h_match = re.search(r'<svg[^>]*\sheight="([^"]+)"', content)

    if not w_match or not h_match:
        return

    try:
        svg_w = float(re.sub(r"[^\d.]", "", w_match.group(1)))
        svg_h = float(re.sub(r"[^\d.]", "", h_match.group(1)))
    except ValueError:
        return

    if svg_w == 0 or svg_h == 0:
        return

    vb_ratio = vb_w / vb_h
    svg_ratio = svg_w / svg_h

    if abs(vb_ratio - svg_ratio) > 0.01:
        issues.append({
            "type": "viewbox_mismatch",
            "message": (
                f"viewBox/size ratio mismatch: "
                f"viewBox={vb_w:.0f}x{vb_h:.0f} (ratio {vb_ratio:.3f}) "
                f"vs width/height={svg_w:.0f}x{svg_h:.0f} (ratio {svg_ratio:.3f})"
            ),
            "line": 1,
        })


# ============================================================
# 检测引擎 - 视觉质量
# ============================================================

def lint_svg_visual(svg_path: Path) -> list:
    """检查单个 SVG 文件的视觉质量问题"""
    issues = []

    try:
        content = svg_path.read_text(encoding="utf-8")
    except Exception as e:
        return [{"type": "error", "message": f"Read failed: {e}", "line": None}]

    lines = content.split("\n")

    _check_visual_richness(svg_path, content, lines, issues)
    _check_flat_layout(svg_path, content, lines, issues)
    _check_card_shadow(svg_path, content, lines, issues)
    _check_font_sizes(svg_path, content, lines, issues)
    _check_text_contrast(svg_path, content, lines, issues)
    _check_color_count(svg_path, content, lines, issues)

    return issues


def _extract_gradient_ids(content: str) -> set:
    """提取 defs 中定义的所有 gradient ID"""
    ids = set()
    # linearGradient
    for m in re.finditer(r'<linearGradient[^>]*\sid="([^"]+)"', content, re.IGNORECASE):
        ids.add(m.group(1))
    # radialGradient
    for m in re.finditer(r'<radialGradient[^>]*\sid="([^"]+)"', content, re.IGNORECASE):
        ids.add(m.group(1))
    return ids


def _extract_filter_ids(content: str) -> set:
    """提取 defs 中定义的所有 filter ID"""
    ids = set()
    for m in re.finditer(r'<filter[^>]*\sid="([^"]+)"', content, re.IGNORECASE):
        ids.add(m.group(1))
    return ids


def _extract_def_refs(content: str) -> set:
    """提取内容中引用的所有 def ID（url(#xxx) 或 fill="url(#xxx)"）"""
    refs = set()
    for m in re.finditer(r'url\(#([^)]+)\)', content):
        refs.add(m.group(1))
    return refs


def _extract_bg_color(content: str) -> str:
    """提取页面主背景色（第一个全尺寸 rect 的 fill）"""
    # 匹配全宽全高的背景 rect
    m = re.search(r'<rect\s[^>]*width="1280"[^>]*\sheight="720"[^>]*fill="([^"]+)"', content)
    if m:
        return m.group(1).lower()
    # 备选：任何全宽 rect
    m = re.search(r'<rect\s[^>]*width="1280"[^>]*fill="([^"]+)"', content)
    if m:
        return m.group(1).lower()
    return ""


def _count_distinct_colors(content: str) -> int:
    """统计页面中使用的非黑白灰颜色数量"""
    colors = set()
    # 提取所有 HEX 颜色
    for m in re.finditer(r'fill="#([0-9A-Fa-f]{6})"', content):
        hex_color = m.group(1).upper()
        # 跳过黑白灰（R≈G≈B）
        r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
        if not (r == g == b):  # 不是灰度色
            colors.add(hex_color)
    # 提取 stroke 颜色
    for m in re.finditer(r'stroke="#([0-9A-Fa-f]{6})"', content):
        hex_color = m.group(1).upper()
        r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
        if not (r == g == b):
            colors.add(hex_color)
    return len(colors)


def _check_visual_richness(svg_path: Path, content: str, lines: list, issues: list):
    """检查视觉丰富度：gradient 定义 + 实际使用"""
    defined_gradients = _extract_gradient_ids(content)
    defined_filters = _extract_filter_ids(content)
    used_refs = _extract_def_refs(content)

    if not defined_gradients and not defined_filters:
        issues.append({
            "type": "visual_richness",
            "severity": "error",
            "message": "L0: defs 中无 gradient 或 filter 定义（最低要求 L1）",
            "line": None,
        })
        return

    # 检查 gradient 是否被实际引用
    used_gradients = defined_gradients & used_refs
    unused_gradients = defined_gradients - used_refs

    if not used_gradients and defined_gradients:
        issues.append({
            "type": "visual_richness",
            "severity": "warning",
            "message": (
                f"L0.5: 定义了 {len(defined_gradients)} 个 gradient 但未实际引用 "
                f"(unused: {', '.join(unused_gradients) or 'all'})"
            ),
            "line": None,
        })


def _count_text_elements(content: str) -> int:
    """统计页面中非 defs 内的 <text> 元素数量"""
    count = 0
    lines = content.split("\n")
    in_defs = False
    for line in lines:
        if re.search(r"<defs[\s>]", line, re.IGNORECASE):
            in_defs = True
        if re.search(r"</defs>", line, re.IGNORECASE):
            in_defs = False
        if not in_defs and re.search(r"<text[\s>]", line, re.IGNORECASE):
            count += 1
    return count


def _count_containers(content: str) -> int:
    """统计页面中的视觉分组容器数量（卡片 rect、分隔线、分组 rect）"""
    count = 0

    # 有 rx 的 rect（圆角矩形 = 卡片）
    card_pattern = re.compile(r'<rect[^>]*\srx="\d+"')
    for m in card_pattern.finditer(content):
        rect_text = content[m.start():m.start() + 200]
        # 排除全屏背景
        if re.search(r'width="1280"', rect_text) and re.search(r'height="720"', rect_text):
            continue
        count += 1

    # 无圆角但尺寸较小的填充 rect（可能用作分区背景）
    for m in re.finditer(r'<rect[^>]+fill="[^"]+"[^>]*>', content):
        rect_text = content[m.start():m.start() + 200]
        # 排除 defs 内、全屏背景、已计入的圆角 rect、线条类 rect
        if re.search(r'rx=', rect_text):
            continue
        if re.search(r'width="1280"', rect_text):
            continue
        w_match = re.search(r'width="(\d+)"', rect_text)
        h_match = re.search(r'height="(\d+)"', rect_text)
        if w_match and h_match:
            w, h = int(w_match.group(1)), int(h_match.group(1))
            # 面积 > 5000px² 的 rect 视为容器/分区背景
            if w * h > 5000:
                count += 1

    # 水平/垂直分隔线
    for m in re.finditer(r'<line[^>]+stroke="[^"]+"[^>]*/>', content):
        line_text = content[m.start():m.start() + 200]
        if re.search(r'<defs', line_text, re.IGNORECASE):
            continue
        count += 1

    return count


def _check_flat_layout(svg_path: Path, content: str, lines: list, issues: list):
    """检测平面布局：大量文本但没有视觉分组容器

    症状：纯文字硬堆，没有卡片、分隔线、分区背景等结构化元素。
    典型问题：>5 个 text 元素但 ≤1 个容器 → 文字直接平铺在背景上。
    """
    text_count = _count_text_elements(content)
    container_count = _count_containers(content)

    # 文本很多但几乎没有容器结构
    if text_count > 5 and container_count <= 1:
        issues.append({
            "type": "flat_layout",
            "severity": "warning",
            "message": (
                f"平面布局: {text_count} 个文本元素但仅 {container_count} 个容器 — "
                "缺乏视觉层级，建议用卡片/分区背景/分隔线组织内容"
            ),
            "line": None,
        })
    # 文本较多，容器也不少但比例失衡（>3:1）
    elif text_count > 8 and container_count > 0 and container_count < text_count // 3:
        issues.append({
            "type": "flat_layout",
            "severity": "info",
            "message": (
                f"布局结构偏弱: {text_count} 个文本元素 vs {container_count} 个容器 — "
                "文字密集区域可能需要更多视觉分组"
            ),
            "line": None,
        })


def _check_card_shadow(svg_path: Path, content: str, lines: list, issues: list):
    """检查有卡片的页面是否使用了 filter 阴影"""
    defined_filters = _extract_filter_ids(content)

    # 检测卡片模式：有 rx 的 rect（圆角矩形）通常代表卡片
    card_pattern = re.compile(r'<rect[^>]*\srx="\d+"')
    card_rects = list(card_pattern.finditer(content))

    # 排除全屏背景 rect（width=1280 且 height=720 或接近的）
    real_cards = []
    for m in card_rects:
        rect_text = content[m.start():m.start() + 200]
        # 排除全屏背景
        if re.search(r'width="1280"', rect_text) and re.search(r'height="720"', rect_text):
            continue
        real_cards.append(m)

    if not real_cards:
        return  # 没有卡片，无需检查

    # 检查是否有 filter 被引用
    filter_usage = re.findall(r'filter="url\(#([^)]+)\)"', content)
    has_shadow_usage = len(filter_usage) > 0

    if not defined_filters and not has_shadow_usage:
        issues.append({
            "type": "card_shadow",
            "severity": "warning",
            "message": (
                f"{len(real_cards)} 个卡片元素无 filter 阴影定义 — "
                "建议在 defs 中添加 cardShadow filter 并用 <g filter> 包裹卡片"
            ),
            "line": None,
        })
    elif defined_filters and not has_shadow_usage:
        issues.append({
            "type": "card_shadow",
            "severity": "warning",
            "message": (
                f"定义了 filter ({', '.join(defined_filters)}) 但 {len(real_cards)} 个卡片未使用 — "
                "建议用 <g filter=\"url(#cardShadow)\"> 包裹卡片 rect"
            ),
            "line": None,
        })


def _check_font_sizes(svg_path: Path, content: str, lines: list, issues: list):
    """检查字号是否满足最小要求"""
    # 提取所有 font-size 值
    for i, line in enumerate(lines, 1):
        for m in re.finditer(r'font-size="(\d+)"', line):
            size = int(m.group(1))
            if size < MIN_FONT_SIZE_CAPTION:
                # 检查上下文：如果是页码/日期等辅助文字，允许 12-14px
                context = line[max(0, m.start() - 100):m.end() + 100]
                if size >= 10 and ('页码' in context or '日期' in context or 'footer' in context.lower()):
                    continue
                issues.append({
                    "type": "font_size",
                    "severity": "warning",
                    "message": f"字号过小: {size}px (最小 {MIN_FONT_SIZE_CAPTION}px)",
                    "line": i,
                })


def _check_text_contrast(svg_path: Path, content: str, lines: list, issues: list):
    """检查常见低对比度颜色对"""
    bg_color = _extract_bg_color(content)

    if not bg_color:
        return

    # 确定背景是浅色还是深色
    bg_hex = bg_color.lstrip("#")
    if len(bg_hex) != 6:
        return
    bg_r, bg_g, bg_b = int(bg_hex[0:2], 16), int(bg_hex[2:4], 16), int(bg_hex[4:6], 16)
    bg_luminance = 0.299 * bg_r + 0.587 * bg_g + 0.114 * bg_b

    # 浅色背景检查
    if bg_luminance > 200:
        for fg, expected_bg, ratio in LOW_CONTRAST_ON_LIGHT_BG:
            if bg_color != expected_bg.lower():
                continue
            # 检查是否有这个颜色用于文字
            fg_pattern = re.compile(rf'fill="{re.escape(fg)}"', re.IGNORECASE)
            matches = list(fg_pattern.finditer(content))
            if matches:
                # 排除 defs 内和 fill-opacity 的装饰用途
                real_text_matches = []
                for match in matches:
                    line_idx = content[:match.start()].count("\n")
                    if _is_inside_defs(content.split("\n"), line_idx + 1):
                        continue
                    real_text_matches.append(match)

                if real_text_matches:
                    issues.append({
                        "type": "contrast",
                        "severity": "warning",
                        "message": (
                            f"低对比度: {fg} on {expected_bg} (~{ratio}:1) "
                            f"— 出现 {len(real_text_matches)} 次，建议改为 #48484A 或 #6E6E73"
                        ),
                        "line": None,
                    })

    # 深色背景检查
    elif bg_luminance < 50:
        for fg, expected_bg, ratio in LOW_CONTRAST_ON_DARK_BG:
            if bg_color != expected_bg.lower():
                continue
            fg_pattern = re.compile(rf'fill="{re.escape(fg)}"', re.IGNORECASE)
            matches = list(fg_pattern.finditer(content))
            if matches:
                real_text_matches = []
                for match in matches:
                    line_idx = content[:match.start()].count("\n")
                    if _is_inside_defs(content.split("\n"), line_idx + 1):
                        continue
                    real_text_matches.append(match)

                if real_text_matches:
                    issues.append({
                        "type": "contrast",
                        "severity": "info",
                        "message": (
                            f"低对比度: {fg} on {expected_bg} (~{ratio}:1) "
                            f"— 出现 {len(real_text_matches)} 次，建议改为 #86868B 或 #AEAEB2"
                        ),
                        "line": None,
                    })


def _check_color_count(svg_path: Path, content: str, lines: list, issues: list):
    """检查单页颜色数量是否超限"""
    distinct_colors = _count_distinct_colors(content)
    if distinct_colors > 5:
        issues.append({
            "type": "color_count",
            "severity": "warning",
            "message": f"颜色过多: {distinct_colors} 种非灰度色 (建议 ≤ 5 种)",
            "line": None,
        })


# ============================================================
# 输出格式化
# ============================================================

def format_text(results: dict) -> str:
    """文本格式输出"""
    lines = []
    total = results["total"]
    passed = results["passed"]
    failed = total - passed

    for path, info in results["files"].items():
        if info["issues"]:
            lines.append(f"⚠️  {path}: {len(info['issues'])} issue(s)")
            for issue in info["issues"]:
                loc = f":L{issue['line']}" if issue["line"] else ""
                severity = f"[{issue.get('severity', 'error')}]" if "severity" in issue else ""
                lines.append(f"   {severity}[{issue['type']}]{loc} {issue['message']}")
        else:
            lines.append(f"✅ {path}")

    if total == 0:
        lines.append("No SVG files found.")
    elif failed == 0:
        lines.append(f"\n✅ All {total} file(s) passed.")
    else:
        lines.append(f"\n⚠️  {failed}/{total} file(s) have issues.")

    return "\n".join(lines)


def format_json_output(results: dict) -> str:
    """JSON 格式输出"""
    return json.dumps(results, ensure_ascii=False, indent=2)


# ============================================================
# 主逻辑
# ============================================================

def lint_directory(dir_path: Path, visual: bool = False) -> dict:
    """检查目录下所有 SVG 文件"""
    svg_files = sorted(dir_path.glob("*.svg"))

    results = {
        "total": len(svg_files),
        "passed": 0,
        "mode": "compatibility + visual" if visual else "compatibility",
        "files": {},
    }

    for svg_file in svg_files:
        issues = lint_svg(svg_file)
        if visual:
            issues.extend(lint_svg_visual(svg_file))
        results["files"][str(svg_file)] = {"issues": issues}
        if not issues:
            results["passed"] += 1

    return results


def lint_file(file_path: Path, visual: bool = False) -> dict:
    """检查单个 SVG 文件"""
    issues = lint_svg(file_path)
    if visual:
        issues.extend(lint_svg_visual(file_path))

    results = {
        "total": 1,
        "passed": 1 if not issues else 0,
        "mode": "compatibility + visual" if visual else "compatibility",
        "files": {str(file_path): {"issues": issues}},
    }

    return results


def main():
    parser = argparse.ArgumentParser(
        description="SVG quality gate - detect PPT-incompatible elements and visual quality issues",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s svg_output/               # PPT compatibility check
  %(prog)s svg_output/ --visual      # + Visual quality check
  %(prog)s slide_01_title.svg        # Check single file
  %(prog)s svg_output/ --json        # JSON output

Compatibility checks:
  Forbidden elements: clipPath, mask, foreignObject, animate, script, ...
  Forbidden attributes: id (outside defs), class, marker-end, onclick, ...
  Forbidden patterns: rgba(), <g opacity=...>, @font-face, ...
  ViewBox consistency: viewBox ratio vs width/height ratio

Visual quality checks (--visual):
  Visual richness: gradient/filter definitions and usage (L1 minimum)
  Flat layout: text elements without visual grouping containers
  Card shadow: cards should use filter shadows
  Font size: minimum font size check (12px caption, 18px body)
  Text contrast: common low-contrast color pair detection
  Color count: max 5 non-gray colors per page
"""
    )
    parser.add_argument("path", help="SVG file or directory to check")
    parser.add_argument("--json", action="store_true", help="JSON output")
    parser.add_argument(
        "--visual",
        action="store_true",
        help="Enable visual quality checks (richness, shadow, contrast, colors)",
    )

    args = parser.parse_args()

    target = Path(args.path)

    if not target.exists():
        print(f"❌ Path not found: {target}", file=sys.stderr)
        sys.exit(1)

    if target.is_file():
        results = lint_file(target, visual=args.visual)
    elif target.is_dir():
        results = lint_directory(target, visual=args.visual)
    else:
        print(f"❌ Not a file or directory: {target}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        print(format_json_output(results))
    else:
        print(format_text(results))

    # Exit code: 0 = all pass, 1 = issues found
    if results["passed"] < results["total"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
