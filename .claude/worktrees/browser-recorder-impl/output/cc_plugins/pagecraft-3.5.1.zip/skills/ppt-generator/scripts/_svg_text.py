# -*- coding: utf-8 -*-
"""Text rendering for PPTX → SVG conversion.

Handles textbox-to-SVG conversion with full style inheritance:
font size, color, alignment, anchor, insets, rotation, line spacing.
"""

from _svg_constants import (
    A_NS, P_NS, qn,
    EMU_PER_PT, EMU_PER_PX,
    DEFAULT_INSET_L_R, DEFAULT_INSET_T_B,
    emu_to_px, emu_to_pt, escape_xml,
)
from _svg_color import (
    _apply_lum_mod, resolve_color, resolve_solid_fill,
    _color_from_lstStyle, _resolve_font_size_from_styles,
)
from _svg_shapes import (
    _get_layout_placeholder, _get_master_placeholder, _shape_position,
)

def _render_textbox_svg(shape, slide_index, total_slides, theme_map):
    """文本框 → SVG <text> 元素"""

    x, y, w, h = _shape_position(shape)

    # 读取 bodyPr / lstStyle — 优先从 slide shape，无则从 layout placeholder 继承
    sp = shape.element
    txBody = sp.find(qn("p:txBody"))
    anchor = "t"  # default top
    l_ins_px = emu_to_px(DEFAULT_INSET_L_R)
    t_ins_px = emu_to_px(DEFAULT_INSET_T_B)
    b_ins_px = emu_to_px(DEFAULT_INSET_T_B)
    layout_lstStyle = None  # 从 layout 继承的 lstStyle（含 defRPr）
    master_lstStyle = None  # 从 master 继承的 lstStyle

    if txBody is not None:
        bodyPr = txBody.find(qn("a:bodyPr"))
        if bodyPr is not None:
            anchor = bodyPr.get("anchor", "t")
            # bodyPr 存在但无 lIns/tIns 时：
            # - placeholder 默认 0（通常无内边距）
            # - 普通文本框使用 DEFAULT_INSET
            is_placeholder = False
            try:
                if shape.placeholder_format is not None:
                    is_placeholder = True
            except Exception:
                pass
            l_ins_raw = bodyPr.get("lIns")
            t_ins_raw = bodyPr.get("tIns")
            b_ins_raw = bodyPr.get("bIns")
            if l_ins_raw is not None:
                l_ins_px = emu_to_px(int(l_ins_raw))
            else:
                l_ins_px = 0
            if t_ins_raw is not None:
                t_ins_px = emu_to_px(int(t_ins_raw))
            else:
                t_ins_px = 0
            if b_ins_raw is not None:
                b_ins_px = emu_to_px(int(b_ins_raw))
            else:
                b_ins_px = 0
        lstStyle = txBody.find(qn("a:lstStyle"))
        if lstStyle is not None and len(lstStyle) > 0:
            layout_lstStyle = lstStyle

    # slide shape 没有显式 bodyPr / lstStyle 时，从 layout placeholder 继承
    # 判断条件：anchor 为默认值 "t" 且 lIns/tIns 为默认值（说明 slide 上没有自定义）
    slide_has_custom_bodypr = False
    if txBody is not None:
        bodyPr = txBody.find(qn("a:bodyPr"))
        if bodyPr is not None:
            # 如果 bodyPr 有 anchor 属性（即使是 None/空，也代表有定义）
            if bodyPr.get("anchor") is not None:
                slide_has_custom_bodypr = True
            # 或者 lIns/tIns/rIns/bIns 任意一个有值
            for attr in ("lIns", "tIns", "rIns", "bIns"):
                if bodyPr.get(attr) is not None:
                    slide_has_custom_bodypr = True
                    break

    def _inherit_from_placeholder(ph_shape):
        """从 placeholder shape 继承 bodyPr 和 lstStyle，返回 (anchor, l_ins, t_ins, b_ins, lstStyle)"""
        if ph_shape is None or not ph_shape.has_text_frame:
            return None
        ltxBody = ph_shape.element.find(qn("p:txBody"))
        if ltxBody is None:
            return None
        result = {"anchor": None, "l_ins": None, "t_ins": None, "b_ins": None, "lstStyle": None}
        lbodyPr = ltxBody.find(qn("a:bodyPr"))
        if lbodyPr is not None:
            result["anchor"] = lbodyPr.get("anchor")
            result["l_ins"] = lbodyPr.get("lIns")
            result["t_ins"] = lbodyPr.get("tIns")
            result["b_ins"] = lbodyPr.get("bIns")
        llstStyle = ltxBody.find(qn("a:lstStyle"))
        if llstStyle is not None and len(llstStyle) > 0:
            result["lstStyle"] = llstStyle
        return result

    if not slide_has_custom_bodypr:
        # 优先从 layout 继承，layout 没有则从 master 继承
        inherited = None
        lph = _get_layout_placeholder(shape)
        if lph is not None:
            inherited = _inherit_from_placeholder(lph)
        if inherited is None:
            mph = _get_master_placeholder(shape)
            if mph is not None:
                inherited = _inherit_from_placeholder(mph)

        if inherited is not None:
            if inherited["anchor"] is not None:
                anchor = inherited["anchor"]
            if inherited["l_ins"] is not None:
                l_ins_px = emu_to_px(int(inherited["l_ins"]))
            else:
                l_ins_px = 0
            if inherited["t_ins"] is not None:
                t_ins_px = emu_to_px(int(inherited["t_ins"]))
            else:
                t_ins_px = 0
            if inherited["b_ins"] is not None:
                b_ins_px = emu_to_px(int(inherited["b_ins"]))
            else:
                b_ins_px = 0
            if inherited["lstStyle"] is not None:
                layout_lstStyle = inherited["lstStyle"]

    # 同时收集 master lstStyle（用于颜色 fallback）
    mph = _get_master_placeholder(shape)
    if mph is not None and mph.has_text_frame:
        mtxBody = mph.element.find(qn("p:txBody"))
        if mtxBody is not None:
            mlstStyle = mtxBody.find(qn("a:lstStyle"))
            if mlstStyle is not None and len(mlstStyle) > 0:
                master_lstStyle = mlstStyle

    # 处理旋转 — 优先从 slide shape 的 xfrm 读取，无则从 layout/master 继承
    rot_deg = 0
    try:
        spPr = sp.find(qn("p:spPr"))
        if spPr is not None:
            xfrm = spPr.find(qn("a:xfrm"))
            if xfrm is not None:
                rot = xfrm.get("rot")
                if rot:
                    rot_deg = int(rot) / 60000
    except Exception:
        pass

    if rot_deg == 0:
        # 尝试从 layout/master 继承旋转
        for ph_shape in (_get_layout_placeholder(shape), _get_master_placeholder(shape)):
            if ph_shape is not None:
                try:
                    ph_spPr = ph_shape.element.find(qn("p:spPr"))
                    if ph_spPr is not None:
                        ph_xfrm = ph_spPr.find(qn("a:xfrm"))
                        if ph_xfrm is not None:
                            rot = ph_xfrm.get("rot")
                            if rot:
                                rot_deg = int(rot) / 60000
                                break
                except Exception:
                    pass

    # 提取首个字号（供 line_spacing 百分比计算用）
    _first_font_pt = 12
    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            for run in para.runs:
                if run.font.size:
                    _first_font_pt = emu_to_pt(run.font.size)
                    break
            if _first_font_pt != 12:
                break
    # runs 无显式字号时，从 layout → master 的 lstStyle defRPr 读取
    if _first_font_pt == 12:
        for lst_style in (layout_lstStyle, master_lstStyle):
            if lst_style is not None:
                lvl1 = lst_style.find(f"{{{A_NS}}}lvl1pPr")
                if lvl1 is not None:
                    defRPr = lvl1.find(f"{{{A_NS}}}defRPr")
                    if defRPr is not None:
                        sz = defRPr.get("sz")
                        if sz:
                            _first_font_pt = int(sz) / 100
                            break
    # fallback 3: placeholder 使用 PPT 标准默认值
    if _first_font_pt == 12:
        try:
            if shape.placeholder_format is not None:
                ph_type = shape.placeholder_format.type
                if ph_type in (1, 3):  # TITLE, CENTER_TITLE
                    _first_font_pt = 44
                else:
                    _first_font_pt = 18
        except Exception:
            pass
    # fallback 4: 从 slide master 的 txStyles otherStyle 读取（非 placeholder 文本框的默认字号）
    if _first_font_pt == 12:
        try:
            master = shape.part.slide_layout.slide_master
            txStyles = master.element.find(qn("p:txStyles"))
            if txStyles is not None:
                otherStyle = txStyles.find(qn("p:otherStyle"))
                if otherStyle is not None:
                    lvl1 = otherStyle.find(qn("a:lvl1pPr"))
                    if lvl1 is not None:
                        defRPr = lvl1.find(qn("a:defRPr"))
                        if defRPr is not None:
                            sz = defRPr.get("sz")
                            if sz:
                                _first_font_pt = int(sz) / 100
        except Exception:
            pass
    _first_font_px = _first_font_pt * 96 / 72

    # 提取段落文本、字体信息、间距属性
    paragraphs = []
    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            runs_info = []
            # 处理 runs (<a:r>)
            for run in para.runs:
                font = run.font
                run_info = {
                    "text": run.text,
                    "font_size_pt": None,
                    "font_family": font.name,
                    "bold": font.bold,
                    "italic": font.italic,
                    "color": None,
                }
                if font.size:
                    run_info["font_size_pt"] = emu_to_pt(font.size)
                else:
                    # fallback 1: 从 XML 的 <a:rPr sz="..."> 读取（hundredths of a point）
                    rPr_elem = run._r.find(f"{{{A_NS}}}rPr")
                    if rPr_elem is not None:
                        sz_attr = rPr_elem.get("sz")
                        if sz_attr:
                            run_info["font_size_pt"] = int(sz_attr) / 100
                    # fallback 2: 从 layout → master 的 lstStyle defRPr 读取
                    if run_info["font_size_pt"] is None:
                        for lst_style in (layout_lstStyle, master_lstStyle):
                            if lst_style is not None:
                                lvl1 = lst_style.find(f"{{{A_NS}}}lvl1pPr")
                                if lvl1 is not None:
                                    defRPr = lvl1.find(f"{{{A_NS}}}defRPr")
                                    if defRPr is not None:
                                        sz = defRPr.get("sz")
                                        if sz:
                                            run_info["font_size_pt"] = int(sz) / 100
                                            break
                    # fallback 3: placeholder 使用 PPT 标准默认值
                    if run_info["font_size_pt"] is None:
                        try:
                            if shape.placeholder_format is not None:
                                ph_type = shape.placeholder_format.type
                                # 标题 placeholder (TITLE, CENTER_TITLE) 默认 44pt
                                if ph_type in (1, 3):  # PP_PLACEHOLDER.TITLE, .CENTER_TITLE
                                    run_info["font_size_pt"] = 44
                                # 正文/副标题 placeholder 默认 18pt
                                else:
                                    run_info["font_size_pt"] = 18
                        except Exception:
                            pass
                    # fallback 4: 从 slide master 的 txStyles otherStyle 读取（非 placeholder 文本框）
                    if run_info["font_size_pt"] is None:
                        try:
                            master = shape.part.slide_layout.slide_master
                            txStyles = master.element.find(qn("p:txStyles"))
                            if txStyles is not None:
                                otherStyle = txStyles.find(qn("p:otherStyle"))
                                if otherStyle is not None:
                                    lvl1 = otherStyle.find(qn("a:lvl1pPr"))
                                    if lvl1 is not None:
                                        defRPr = lvl1.find(qn("a:defRPr"))
                                        if defRPr is not None:
                                            sz = defRPr.get("sz")
                                            if sz:
                                                run_info["font_size_pt"] = int(sz) / 100
                        except Exception:
                            pass
                # 优先从 XML 读取颜色（包含 lumMod 等精确信息）
                rPr_elem = run._r.find(f"{{{A_NS}}}rPr")
                if rPr_elem is not None:
                    solidFill = rPr_elem.find(f"{{{A_NS}}}solidFill")
                    if solidFill is not None:
                        srgb = solidFill.find(f"{{{A_NS}}}srgbClr")
                        scheme = solidFill.find(f"{{{A_NS}}}schemeClr")
                        if srgb is not None:
                            hex_color = srgb.get("val")
                            lumMod = srgb.find(f"{{{A_NS}}}lumMod")
                            if lumMod is not None:
                                hex_color = _apply_lum_mod(hex_color, lumMod.get("val"))
                            run_info["color"] = hex_color
                        elif scheme is not None:
                            scheme_val = scheme.get("val")
                            lumMod = scheme.find(f"{{{A_NS}}}lumMod")
                            lumMod_val = lumMod.get("val") if lumMod is not None else None
                            if scheme_val and theme_map:
                                hex_color = theme_map.get(scheme_val)
                                if hex_color and lumMod_val:
                                    hex_color = _apply_lum_mod(hex_color, lumMod_val)
                                run_info["color"] = hex_color
                # XML 无颜色时，尝试 API
                if run_info["color"] is None:
                    try:
                        if font.color and font.color.type is not None:
                            run_info["color"] = resolve_color(font.color, theme_map)
                    except Exception:
                        pass
                # run 无显式颜色时，尝试从 layout → master 的 defRPr 继承
                if run_info["color"] is None:
                    run_info["color"] = _color_from_lstStyle(layout_lstStyle, theme_map)
                if run_info["color"] is None:
                    run_info["color"] = _color_from_lstStyle(master_lstStyle, theme_map)
                runs_info.append(run_info)

            # 处理字段 (<a:fld>)，如页码、日期等
            fld_elems = para._p.findall(f"{{{A_NS}}}fld")
            for fld in fld_elems:
                t_elem = fld.find(f"{{{A_NS}}}t")
                text = t_elem.text if t_elem is not None else ""
                rPr_elem = fld.find(f"{{{A_NS}}}rPr")
                run_info = {
                    "text": text,
                    "font_size_pt": None,
                    "font_family": None,
                    "bold": False,
                    "italic": False,
                    "color": None,
                }
                if rPr_elem is not None:
                    sz_attr = rPr_elem.get("sz")
                    if sz_attr:
                        run_info["font_size_pt"] = int(sz_attr) / 100
                    # 从 rPr 的 solidFill 读取颜色
                    solidFill = rPr_elem.find(f"{{{A_NS}}}solidFill")
                    if solidFill is not None:
                        srgb = solidFill.find(f"{{{A_NS}}}srgbClr")
                        scheme = solidFill.find(f"{{{A_NS}}}schemeClr")
                        if srgb is not None:
                            run_info["color"] = srgb.get("val")
                        if scheme is not None:
                            scheme_val = scheme.get("val")
                            if scheme_val and theme_map:
                                run_info["color"] = theme_map.get(scheme_val)
                # 字段无颜色时，从 layout → master 的 defRPr 继承
                if run_info["color"] is None:
                    run_info["color"] = _color_from_lstStyle(layout_lstStyle, theme_map)
                if run_info["color"] is None:
                    run_info["color"] = _color_from_lstStyle(master_lstStyle, theme_map)
                runs_info.append(run_info)

            # 段落间距属性（转 px）
            space_before_px = 0
            space_after_px = 0
            line_spacing_px = None  # None = 使用字体默认行高
            has_explicit_spacing = False
            try:
                pf = para._pPr
                if pf is None:
                    pf = para._p.getparent()
                pPr = para._p.find(qn("a:pPr"))
                # spaceBefore
                spc_bef = para._p.find(f".//{{http://schemas.openxmlformats.org/drawingml/2006/main}}spcBef")
                if spc_bef is not None:
                    spc_pts = spc_bef.find(f"{{http://schemas.openxmlformats.org/drawingml/2006/main}}spcPts")
                    if spc_pts is not None:
                        val = int(spc_pts.get("val", "0"))
                        space_before_px = val * 96 / 7200  # hundredths of a pt → px
                        has_explicit_spacing = True
            except Exception:
                pass
            try:
                spc_aft = para._p.find(f".//{{http://schemas.openxmlformats.org/drawingml/2006/main}}spcAft")
                if spc_aft is not None:
                    spc_pts = spc_aft.find(f"{{http://schemas.openxmlformats.org/drawingml/2006/main}}spcPts")
                    if spc_pts is not None:
                        val = int(spc_pts.get("val", "0"))
                        space_after_px = val * 96 / 7200
                        has_explicit_spacing = True
            except Exception:
                pass
            try:
                lnSpc = para._p.find(f".//{{http://schemas.openxmlformats.org/drawingml/2006/main}}lnSpc")
                if lnSpc is not None:
                    spc_pts = lnSpc.find(f"{{http://schemas.openxmlformats.org/drawingml/2006/main}}spcPts")
                    spc_pct = lnSpc.find(f"{{http://schemas.openxmlformats.org/drawingml/2006/main}}spcPct")
                    if spc_pts is not None:
                        val = int(spc_pts.get("val", "0"))
                        line_spacing_px = val * 96 / 7200
                        has_explicit_spacing = True
                    elif spc_pct is not None:
                        val = int(spc_pct.get("val", "100000"))
                        line_spacing_px = _first_font_px * 1.2 * val / 100000
                        has_explicit_spacing = True
            except Exception:
                pass

            # 无显式段间距时，根据 placeholder 类型应用 PPT 默认值
            # Body/Content placeholder 默认段后间距 = 1.0 * font_size
            if not has_explicit_spacing:
                try:
                    ph_type = shape.placeholder_format.type
                    if ph_type in (2, 7):  # BODY, OBJECT (content)
                        # 使用 _first_font_px（在段落循环前已计算）
                        space_after_px = _first_font_px
                except Exception:
                    pass

            paragraphs.append({
                "runs": runs_info,
                "space_before_px": space_before_px,
                "space_after_px": space_after_px,
                "line_spacing_px": line_spacing_px,
            })

    # 无文本则跳过
    all_text = "".join(r["text"] for para in paragraphs for r in para["runs"])
    if not all_text.strip():
        return ""

    # 确定首个字号（px，用于坐标计算）
    first_font_size_pt = None
    for para in paragraphs:
        for r in para["runs"]:
            if r["font_size_pt"]:
                first_font_size_pt = r["font_size_pt"]
                break
        if first_font_size_pt is not None:
            break

    # 如果所有 runs 都没有字号，尝试从段落 defRPr 读取
    if first_font_size_pt is None:
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                pPr = para._p.find(f"{{{A_NS}}}pPr")
                if pPr is not None:
                    defRPr = pPr.find(f"{{{A_NS}}}defRPr")
                    if defRPr is not None:
                        sz = defRPr.get("sz")
                        if sz:
                            first_font_size_pt = int(sz) / 100
                            break

    # 最终 fallback: 从 layout → master placeholder 的 lstStyle defRPr 读取
    if first_font_size_pt is None:
        for lst_style in (layout_lstStyle, master_lstStyle):
            if lst_style is not None:
                lvl1 = lst_style.find(f"{{{A_NS}}}lvl1pPr")
                if lvl1 is not None:
                    defRPr = lvl1.find(f"{{{A_NS}}}defRPr")
                    if defRPr is not None:
                        sz = defRPr.get("sz")
                        if sz:
                            first_font_size_pt = int(sz) / 100
                            break

    # 最终 fallback: placeholder shape 用 PPT 默认字号
    if first_font_size_pt is None:
        try:
            ph_idx = shape.placeholder_format.idx
            # PPT 默认: idx 0 = 标题 (44pt), idx 1 = 正文 (18pt), 其他 = 14pt
            if ph_idx == 0:
                first_font_size_pt = 44
            elif ph_idx == 1:
                first_font_size_pt = 18
            else:
                first_font_size_pt = 14
        except Exception:
            first_font_size_pt = 12
    first_font_size_px = first_font_size_pt * 96 / 72  # pt → px at 96 dpi

    # 计算默认行高：所有 placeholder 默认 1.0 倍行距
    # PPT 的段间距通过 spaceAfter/spaceBefore 控制，不在 line spacing 中
    default_line_height = first_font_size_px * 1.0
    total_block_height = 0
    for i, para in enumerate(paragraphs):
        lh = para["line_spacing_px"] if para["line_spacing_px"] else default_line_height
        total_block_height += lh
        if i > 0:
            total_block_height += para["space_before_px"]
        if i < len(paragraphs) - 1:
            total_block_height += para["space_after_px"]
    if total_block_height == 0:
        total_block_height = default_line_height

    # 计算 text_y（全部用 px）
    # 不使用 dominant-baseline（Office SVG 渲染器不支持），直接计算 alphabetic baseline 的 y 坐标。
    # 参考 ppt-master 的 txbody_to_svg.py：首行 baseline 在文字块顶部下方 0.85 * font_size 处，
    # 该经验值在视觉上更接近 PowerPoint 的文本渲染效果。
    BASELINE_OFFSET_RATIO = 0.85
    multi_para = len(paragraphs) > 1
    if anchor == "ctr":
        # 整块文本居中：文字块顶部 = y + (h - total_block_height) / 2
        block_top = y + (h - total_block_height) / 2
        text_y = block_top + first_font_size_px * BASELINE_OFFSET_RATIO
    elif anchor == "b":
        # 整块文本底对齐：文字块顶部 = y + h - total_block_height
        block_top = y + h - total_block_height
        text_y = block_top + first_font_size_px * BASELINE_OFFSET_RATIO
    else:
        # anchor="t" (top): 文字块顶部 = y + t_ins
        block_top = y + t_ins_px
        text_y = block_top + first_font_size_px * BASELINE_OFFSET_RATIO

    # 判断水平对齐：段落 pPr algn 优先，无则从 lstStyle lvl1pPr 读取默认 algn
    h_align = "l"  # default left
    try:
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                pPr = para._p.find(f"{{{A_NS}}}pPr")
                if pPr is not None:
                    algn = pPr.get("algn")
                    if algn is not None:
                        h_align = algn
                        break
    except Exception:
        pass

    # 段落无显式 algn 时，从 lstStyle 的 lvl1pPr 读取默认 algn
    if h_align == "l":
        for lst_style in (layout_lstStyle, master_lstStyle):
            if lst_style is not None:
                lvl1 = lst_style.find(f"{{{A_NS}}}lvl1pPr")
                if lvl1 is not None:
                    algn = lvl1.get("algn")
                    if algn is not None:
                        h_align = algn
                        break

    # 水平对齐：left / center / right
    text_anchor_attr = ""
    if h_align == "ctr":
        text_x = x + w / 2
        text_anchor_attr = ' text-anchor="middle"'
    elif h_align == "r":
        text_x = x + w - l_ins_px
        text_anchor_attr = ' text-anchor="end"'
    else:
        text_x = x + l_ins_px

    # 旋转：PPT rot 正值为顺时针，SVG rotate 正值也为顺时针
    # 但 PPT 的坐标系原点在左上角，旋转中心是 shape 中心
    rot_attr = ""
    if rot_deg != 0:
        cx = x + w / 2
        cy = y + h / 2
        rot_attr = f' transform="rotate({rot_deg:.1f} {cx:.1f} {cy:.1f})"'

    # 多段落且字号不同：每个段落生成独立的 <text> 元素，避免
    # dominant-baseline / font-size 冲突导致 y 坐标重叠
    para_font_sizes = [para["runs"][0]["font_size_pt"] if para["runs"] else None for para in paragraphs]
    has_different_font_sizes = len(set(fs for fs in para_font_sizes if fs)) > 1

    if multi_para and has_different_font_sizes:
        # 每个段落独立渲染为 <text> 元素
        parts = []
        cumulative_y = 0
        prev_non_empty_idx = None
        for i, para in enumerate(paragraphs):
            raw_text = "".join(r["text"] for r in para["runs"])
            if not raw_text.strip():
                continue

            para_font_pt = para["runs"][0]["font_size_pt"] if para["runs"] else first_font_size_pt
            para_font_pt = para_font_pt or first_font_size_pt
            para_font_px = para_font_pt * 96 / 72

            if prev_non_empty_idx is not None:
                prev_para = paragraphs[prev_non_empty_idx]
                prev_line_h = prev_para["line_spacing_px"] if prev_para["line_spacing_px"] else default_line_height
                empty_lines_h = 0
                for j in range(prev_non_empty_idx + 1, i):
                    empty_lines_h += paragraphs[j]["line_spacing_px"] if paragraphs[j]["line_spacing_px"] else default_line_height
                dy = prev_line_h + prev_para["space_after_px"] + para["space_before_px"] + empty_lines_h
                cumulative_y += dy
            else:
                dy = 0
                cumulative_y = 0

            para_y = text_y + cumulative_y
            attrs = _tspan_style_attrs(para["runs"], "")
            parts.append(f'<text x="{text_x}" y="{para_y:.1f}"'
                         f' font-size="{para_font_pt}pt"{text_anchor_attr}{rot_attr}>')
            parts.append(f'<tspan{attrs}>{escape_xml(raw_text)}</tspan>')
            parts.append('</text>')
            prev_non_empty_idx = i
        return "\n".join(parts)

    # 单 text 元素渲染（单段落或同字号多段落）
    parts = []
    parts.append(f'<text x="{text_x}" y="{text_y:.1f}"'
                 f' font-size="{first_font_size_pt}pt"{text_anchor_attr}{rot_attr}>')

    font_fam = ""
    for para in paragraphs:
        for r in para["runs"]:
            if r["font_family"]:
                font_fam = f' font-family="{escape_xml(r["font_family"])}"'
                break
        if font_fam:
            break

    # 单段落 → 一个 tspan（保留原始文本）；多段落 → 逐段累加行高
    if len(paragraphs) <= 1:
        attrs = _tspan_style_attrs(paragraphs[0]["runs"] if paragraphs else [], font_fam)
        raw_text = "".join(r["text"] for r in (paragraphs[0]["runs"] if paragraphs else []))
        parts.append(f'<tspan{attrs}>{escape_xml(raw_text)}</tspan>')
    else:
        cumulative_y = 0
        prev_non_empty_idx = None
        for i, para in enumerate(paragraphs):
            raw_text = "".join(r["text"] for r in para["runs"])
            # 跳过空段落（不生成 tspan，也不贡献行高）
            if not raw_text.strip():
                continue

            if prev_non_empty_idx is not None:
                # 累加从上一个非空段落开始到当前段落的行高和间距
                prev_para = paragraphs[prev_non_empty_idx]
                prev_line_h = prev_para["line_spacing_px"] if prev_para["line_spacing_px"] else default_line_height
                # 累加中间空段落的默认行高
                empty_lines_h = 0
                for j in range(prev_non_empty_idx + 1, i):
                    empty_lines_h += paragraphs[j]["line_spacing_px"] if paragraphs[j]["line_spacing_px"] else default_line_height
                dy = prev_line_h + prev_para["space_after_px"] + para["space_before_px"] + empty_lines_h
                cumulative_y += dy
            else:
                dy = 0

            attrs = _tspan_style_attrs(para["runs"], font_fam)
            dy_attr = f' dy="{dy:.1f}"' if dy else ""
            parts.append(f'<tspan x="{text_x}"{dy_attr}{attrs}>{escape_xml(raw_text)}</tspan>')
            prev_non_empty_idx = i

    parts.append("</text>")
    return "\n".join(parts)
def _tspan_style_attrs(runs, font_fam=""):
    """从 runs 中提取第一个有样式的 run 的属性，返回 tspan 属性字符串"""
    bold = False
    italic = False
    color = None
    size_pt = None

    for r in runs:
        if r.get("bold"):
            bold = True
        if r.get("italic"):
            italic = True
        if r.get("color") and not color:
            color = r["color"]
        if r.get("font_size_pt") and not size_pt:
            size_pt = r["font_size_pt"]

    attrs = font_fam
    if size_pt:
        attrs += f' font-size="{size_pt}pt"'
    if bold:
        attrs += ' font-weight="bold"'
    if italic:
        attrs += ' font-style="italic"'
    if color:
        attrs += f' fill="#{color}"'
    return attrs
