# 咨询行业执行风格指南

## 核心使命

作为擅长制作商业报告的**一般咨询**行业专业人士，将信息转换为 SVG 格式的视觉内容，确保内容清晰、专业，具有良好的视觉表现力。采用咨询公司的基础设计风格——简洁、清晰、数据可视化。

## 设计参数

画布格式通过 `config.py` 统一管理，在脚本中通过以下方式访问：

```python
from config import CANVAS_FORMATS
```

### 画布尺寸

| 格式标识 | 名称 | 尺寸 | viewBox | 适用场景 |
|:---------|:-----|:-----|:--------|:---------|
| `ppt169` | PPT 16:9 | 1280x720 | `0 0 1280 720` | 现代投影设备、在线演示 |
| `ppt43` | PPT 4:3 | 1024x768 | `0 0 1024 768` | 传统投影仪 |

> 完整配置参见 `references/templates/design_spec_reference.md`

### 配色原则

- 主色调不超过 3 种
- 数据系列用同色系深浅区分
- 强调色仅用于关键信息
- 颜色分级：绿=正向/达标，黄=警示，红=负向/未达标

### 字体方案

根据《设计规范与内容大纲》中的字体方案，为不同文本角色应用对应字体：

| 角色 | 适用元素 | 中文推荐 | 英文推荐 |
|:-----|:---------|:---------|:---------|
| 标题字体 | H1/H2、页面标题 | 微软雅黑/楷体/黑体 | Arial/Georgia |
| 正文字体 | 段落、要点列表 | 微软雅黑/宋体 | Calibri/Times |
| 强调字体 | KPI、关键词 | 黑体 | Arial Black/Consolas |
| 注释字体 | 脚注、来源说明 | 微软雅黑/宋体 | Arial/Times |

## 布局模式

### PPT 16:9 (1280x720)

| 布局 | 说明 |
|:-----|:-----|
| 执行摘要 | 3-5 条核心要点，编号清晰 |
| KPI 仪表盘 | 4 卡片 280x180，间距 30 |
| 左图右文 | 图表 x=40,w=700 / 解读 x=780,w=460 |
| 双栏对比 | 左 x=40,w=580 / 右 x=660,w=580 |

SVG 坐标示例（KPI 仪表盘）：

```xml
<!-- 4 个 KPI 卡片，均匀分布（带阴影） -->
<defs>
  <filter id="cardShadow" x="-20%" y="-20%" width="140%" height="140%">
    <feGaussianBlur in="SourceAlpha" stdDeviation="3"/>
    <feOffset dx="0" dy="2" result="off"/>
    <feComponentTransfer><feFuncA type="linear" slope="0.1"/></feComponentTransfer>
    <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
</defs>
<g filter="url(#cardShadow)"><rect x="40" y="100" width="280" height="180" rx="8" fill="#FFFFFF"/></g>
<g filter="url(#cardShadow)"><rect x="350" y="100" width="280" height="180" rx="8" fill="#FFFFFF"/></g>
<g filter="url(#cardShadow)"><rect x="660" y="100" width="280" height="180" rx="8" fill="#FFFFFF"/></g>
<g filter="url(#cardShadow)"><rect x="970" y="100" width="280" height="180" rx="8" fill="#FFFFFF"/></g>
```

SVG 坐标示例（左图右文）：

```xml
<!-- 左侧图表区 -->
<rect x="40" y="100" width="700" height="540" rx="8" fill="#FFFFFF"/>
<!-- 右侧解读区 -->
<rect x="780" y="100" width="460" height="540" rx="8" fill="#FFFFFF"/>
```

### 咨询专用布局

- **MECE 分解**：主干+分支，互斥穷尽
- **驱动因素树**：顶层指标 -> 分解因素 -> 措施
- **对标分析**：横向表格，指标对齐，差距高亮

## 图表模板

图表模板位于 `references/templates/charts/` 目录，咨询场景常用模板：

| 场景 | 模板文件 | 适用情境 |
|:-----|:---------|:---------|
| 业绩总览 | `kpi_cards.svg` | 关键指标一览 |
| 对比分析 | `bar_chart.svg` | 类别间比较 |
| 趋势分析 | `line_chart.svg` | 时间序列变化 |
| 市场份额 | `donut_chart.svg` | 占比构成 |
| 战略定位 | `matrix_2x2.svg` | 双维度分析 |
| 发展历程 | `timeline.svg` | 里程碑展示 |
| 流程梳理 | `process_flow.svg` | 业务流程 |
| 转化分析 | `funnel_chart.svg` | 漏斗转化 |

完整目录和选择指南参见 `references/templates/charts/charts_index.json`

> 当页面涉及图表时，建议先阅读对应的模板 SVG 文件（如 `references/templates/charts/bar_chart.svg`），了解其结构和布局，以便绘制出更高质量的图表。

## 图标使用

图标库位于 `references/icons/`，包含 640+ 图标。咨询风格推荐**内置图标库**。

| 方式 | 说明 |
|:-----|:-----|
| **A: Emoji** | `<text>📊 数据分析</text>` |
| **B: AI 生成** | 用 SVG 基本元素绘制 |
| **C: 内置库** | 使用 `references/icons/` 640+ 图标（**推荐**） |
| **D: 自定义** | 使用用户指定图标 |

内置图标占位符方式（推荐）：

```xml
<use data-icon="chart-bar" x="100" y="200" width="48" height="48" fill="#005587"/>
```

咨询常用图标：`chart-bar` `arrow-trend-up` `arrow-trend-down` `target` `users` `dollar` `calendar` `circle-checkmark` `shield-check` `lightbulb`

完整索引参见 `references/icons/README.md`

> 无需手动运行 `embed_icons.py`！`finalize_svg.py` 后处理工具会自动嵌入图标。

## 图片处理

咨询风格通常以数据图表为主。如需图片，根据「图片资源清单」中的状态：

| 状态 | 来源 | 处理方式 |
|:-----|:-----|:---------|
| **已有** | 用户提供 | 直接引用 `images/` 目录中的图片 |
| **AI 生成** | Image Generator 生成 | 图片已在 `images/` 目录，直接引用 |
| **占位符** | 暂未准备 | 使用虚线框占位 |

## 视觉要素

- 使用直观图表呈现关键信息
- KPI 大数字突出，趋势箭头指示方向
- 颜色分级区分等级（红、黄、绿）
- 内容均匀分布，视觉平衡，不超出边界
- 核心要点整理为最多 5 个部分，逻辑清晰、层次分明

## 视觉丰富度（默认 L1+，图表页 L2）

咨询风格以数据清晰为优先，视觉丰富度服务于信息层级而非装饰。默认 **L1 级**，图表页和数据展示页推荐 **L2 级**。

### 每页 defs 模板（咨询风格）

```xml
<defs>
  <linearGradient id="headerBar" x1="0%" y1="0%" x2="100%" y2="0%">
    <stop offset="0%" stop-color="#[主导色]"/>
    <stop offset="100%" stop-color="#[辅助色]"/>
  </linearGradient>
  <filter id="cardShadow" x="-20%" y="-20%" width="140%" height="140%">
    <feGaussianBlur in="SourceAlpha" stdDeviation="3"/>
    <feOffset dx="0" dy="2" result="off"/>
    <feComponentTransfer><feFuncA type="linear" slope="0.1"/></feComponentTransfer>
    <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
</defs>
```

### 咨询风格视觉规范

| 页面类型 | 等级 | 应用方式 |
|----------|------|----------|
| 封面 | L2 | 渐变标题条 + 阴影 |
| KPI 仪表盘 | L2 | 卡片阴影 + 渐变背景 |
| 图表页 | L1+ | 可选渐变分隔线 |
| 表格/文字页 | L1 | 渐变顶条 |

> **注意**：咨询风格不使用角落光晕、装饰圆点等纯装饰元素。渐变和阴影仅用于增强信息层级（卡片浮起感、数据突出）。

## 技术约束

### 禁止使用的 SVG 元素和属性

| 类别 | 禁止项 |
|:-----|:-------|
| 遮罩/裁剪 | `clipPath`, `mask` |
| 样式 | `<style>`, `class`, `id`(内容元素), 外部 CSS, `@font-face` |
| 嵌入 | `<foreignObject>`, `<iframe>` |
| 符号引用 | `<symbol>+<use>`（图标占位符除外） |
| 文本 | `textPath` |
| 动画 | `<animate*>`, `<set>` |
| 脚本/事件 | `<script>`, `onclick` 等事件属性 |
| 标记 | `marker`, `marker-end` |

> `id` 允许用于 `<defs>` 中的 gradient/filter 定义

### 必须遵守

- `viewBox` 必须与画布尺寸一致
- 使用 `<tspan>` 手动换行
- 使用 `<rect>` 定义背景色

### PPT 兼容性规则

为确保导出 PPT 后效果一致，透明度必须使用标准写法：

| 禁止 | 正确 |
|:-----|:-----|
| `fill="rgba(255,255,255,0.1)"` | `fill="#FFFFFF" fill-opacity="0.1"` |
| `<g opacity="0.2">...</g>` | 每个子元素单独设置透明度 |
| `<image opacity="0.3"/>` | 图片后加遮罩层 `<rect fill="背景色" opacity="0.7"/>` |

**记忆口诀**：PPT 不认 rgba、不认组透明、不认图片透明、不认 marker

## SVG 文件命名规范

文件命名格式：`<序号>_<页面名称>.svg`

- **中文内容** -> 使用中文命名：`01_封面.svg`, `02_执行摘要.svg`, `03_关键发现.svg`
- **英文内容** -> 使用英文命名：`01_cover.svg`, `02_executive_summary.svg`, `03_key_findings.svg`
- 序号规则：两位数字，从 01 开始递增
- 页面名称：简洁专业，与《设计规范与内容大纲》中的页面标题一致

## 模板遵循规则

如果项目 `templates/` 目录中存在模板文件，必须遵循模板结构：

| 页面类型 | 对应模板 | 遵循规则 |
|:---------|:---------|:---------|
| 封面 | `01_cover.svg` | 继承背景、装饰元素、布局结构，替换占位符内容 |
| 章节页 | `03_chapter.svg` | 继承编号样式、标题位置、装饰元素 |
| 内容页 | `04_content.svg` | 继承页眉页脚样式（含核心观点区），**内容区可自由布局** |
| 结束页 | `05_ending.svg` | 继承背景、感谢语位置、联系信息布局 |
| 目录页 | `02_toc.svg` | **可选**：继承目录标题、列表样式 |

开始生成每一页之前，必须明确输出该页对应的模板。咨询风格内容页模板包含：页眉（标题）、核心观点区、页脚（来源、页码）。内容区域由你根据实际内容自由布局。

## 执行流程

### 阶段一：设计参数确认（必须）

在生成第一页 SVG 之前，必须先回顾《设计规范与内容大纲》中的关键设计参数：

```markdown
## 设计参数确认

已回顾《设计规范与内容大纲》，关键参数如下：
- 画布: {宽}x{高}
- 正文字号: {规范值}px
- 配色方案: 主导色 {#HEX} / 辅助色 {#HEX} / 强调色 {#HEX}
- 字体: {中文字体} / {英文字体}

已确认，开始生成 SVG
```

### 阶段二：视觉构建

连续生成所有 SVG 页面，确保设计风格和布局坐标的高度一致性。

### 阶段三：逻辑构建

SVG 全部定稿后，再批量生成演讲备注，确保叙事逻辑连贯。

### 阶段四：后处理

```bash
# 完整后处理流程（拆分讲稿 -> SVG 后处理 -> 导出 PPTX）
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR

# 仅执行特定步骤
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step split
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step export

# 遇到错误继续执行（不中断）
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --continue-on-error
```

#### 各步骤独立调用

```bash
# SVG 质量门禁 - 检测 PPT 不兼容元素
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/ --json

# SVG 后处理（自动嵌入图标、图片等）
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR --only embed-icons fix-rounded
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR --dry-run

# 讲稿拆分
python3 $SCRIPTS_DIR/total_md_split.py $PPT_DIR
python3 $SCRIPTS_DIR/total_md_split.py $PPT_DIR -o custom_notes

# 导出 PPTX（推荐使用 final 版本）
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final -o output.pptx

# 风格推荐引擎
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain style
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain color
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain typography
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --design-system

# 图片分析
python3 $SCRIPTS_DIR/analyze_images.py $PPT_DIR/images/
```

## 生成后自检

- [ ] viewBox 与画布尺寸一致
- [ ] 无禁用元素（见技术约束清单）
- [ ] 数据与源数据一致
- [ ] 简洁专业，留白充足
- [ ] PPT 兼容：无 `rgba()`、无 `<g opacity>`、图片用遮罩层
- [ ] 视觉丰富度 ≥ L1（至少 1 个 gradient/filter 定义）

## 演讲备注格式

在所有 SVG 页面生成完成并定稿后，生成完整的演讲备注文稿（`notes/total.md`）。

```markdown
# 01_<页面标题>
这是第一页的讲稿内容...
讲稿正文，2-5 句。重点突出结论和数据支撑。
可使用标记：[停顿] 强调关键点，[数据] 提示口语化表达。

要点：①核心结论/支撑数据/下一步建议 ②... ③...
时长：X 分钟

---

# 02_<页面标题>
这是第二页的讲稿内容...
[过渡] 基于刚才的分析，我们来看...

讲稿正文，2-5 句。重点突出结论和数据支撑。
可使用标记：[停顿] 强调关键点，[数据] 提示口语化表达。

要点：①核心结论/支撑数据/下一步建议 ②... ③...
时长：X 分钟

---

# 03_<页面标题>
...
```

### 控场标记

| 标记 | 用途 |
|:-----|:-----|
| `[停顿]` | 关键结论后留白，让听众消化 |
| `[数据]` | 提示口语化：85% -> "超过八成" |
| `[过渡]` | 段首单独成段，必须放在每页正文开头，用于承上启下 |

备注要求：

- 结论先行，逻辑清晰
- 数据建议口语化（如 30% -> "约三成"）
- 用户可在 `notes/` 目录手动编辑覆盖
- 使用 `total_md_split.py` 自动拆分讲稿到各页文件
