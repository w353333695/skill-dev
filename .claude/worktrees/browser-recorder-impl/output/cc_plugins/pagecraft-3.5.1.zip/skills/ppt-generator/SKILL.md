---
name: ppt-generator
description: 生成原生可编辑 PPTX 文件的演示稿——产物是标准 PowerPoint 文件，可在 PowerPoint/WPS/Keynote 中直接二次编辑文字、形状与版式。核心场景：① 把已有文档（PDF/URL/Markdown/Word）转换为 PPT；② 生成**传统方案类、架构图类、企业汇报类**的规整 PPT（这类版式它最擅长，效果扎实）。技术栈为 Python（SVG 幻灯片 → 原生 PPTX 重建），交付的是「文件」而非「网页」。触发词：转成 PPT / 转 pptx / 生成 ppt 文件 / 可编辑 PPTX / 企业 PPT 模板 / 方案 PPT / 架构图 PPT / 把这份文档（PDF/MD/URL）做成 PPT。**与 html-slide-gen 的分工**：若用户要的是**现场演示、丰富动画与视觉效果、网页展示、演讲汇报的视觉冲击**（而非一个可编辑的 .pptx 文件），改用 html-slide-gen。两者产物虽都可编辑，但本 skill 的 PPTX 是原生 PowerPoint 元素（为二次编辑/文件交付而生），html-slide-gen 的 PPTX 是 HTML 的导出快照（为演示/视觉而生）。
category: project-management
version: 1.1.0
allowed-tools: Read, Write, Bash, Task
---

# PPT Generator SKILL

通用文档转 PPT 能力。将 PDF、URL、Markdown 等源文档通过 10 个 Phase 转换为 SVG 幻灯片，最终导出为可编辑的 PPTX 文件。

## 流程概览

```
源文档 → 8项确认 → 设计规范 → [图片生成] → SVG页面 → 视觉验收 → 演讲备注 → 后处理 → PPTX
```

## Phase 间硬检查点

> **每个 Phase 完成后，必须执行对应的 Gate 检查。** Gate 是 bash 脚本，验证产出物文件必须存在。文件缺失 = 上一个 Phase 未完成，必须回去补做，不允许进入下一个 Phase。

| Gate | 触发时机 | 检查内容 |
|------|---------|---------|
| Gate 0 | Phase 0 完成后 | `$PPT_DIR/` 及子目录存在 |
| Gate 1 | Phase 1 完成后 | `sources/input.md` 存在 |
| Gate 2 | Phase 2 完成后 | `templates/design_spec.md` 存在 + `templates/*.svg` 存在 |
| Gate 3 | Phase 3 完成后 | `design_spec.md` 存在（12 章节） |
| Gate 5 | Phase 5 完成后 | `svg_output/*.svg` 数量 ≥ 设计规范页数 |
| Gate 5.5 | Phase 5.5 完成后 | `previews/*.png` 数量 = SVG 数量 |
| Gate 7 | Phase 7 完成后 | 最终 `.pptx` 文件存在 |

---

### Gate 0: Phase 0 完成检查

```bash
test -d "$PPT_DIR" || { echo "❌ $PPT_DIR 不存在"; exit 1; }
for dir in sources images notes templates svg_output svg_final previews; do
  test -d "$PPT_DIR/$dir" || { echo "❌ $PPT_DIR/$dir/ 不存在"; exit 1; }
done
echo "✅ Gate 0 通过: 项目目录结构完整"
```

### Gate 1: Phase 1 完成检查

```bash
test -f "$PPT_DIR/sources/input.md" || { echo "❌ sources/input.md 不存在，Phase 1 未完成"; exit 1; }
echo "✅ Gate 1 通过: 源文档已归档"
```

### Gate 2: Phase 2 完成检查（关键）

```bash
# Gate 2 通用检查（自动识别选项）
if [ -f "$PPT_DIR/style/style_profile.md" ]; then
  echo "✅ Gate 2 通过（选项 D）: 风格档案已生成"
elif [ -f "$PPT_DIR/templates/design_spec.md" ]; then
  SVG_COUNT=$(ls "$PPT_DIR/templates/"*.svg 2>/dev/null | wc -l | tr -d ' ')
  test "$SVG_COUNT" -ge 2 || { echo "❌ SVG 模板文件不足（仅 ${SVG_COUNT} 个，至少需要 cover + content）"; exit 1; }
  echo "✅ Gate 2 通过（选项 A/B/C）: design_spec.md + ${SVG_COUNT} 个 SVG 模板"
else
  echo "❌ Gate 2 失败: 既无 style/style_profile.md 也无 templates/design_spec.md，Phase 2 未完成"
  exit 1
fi
```

### Gate 3: Phase 3 完成检查

```bash
test -f "$PPT_DIR/design_spec.md" || { echo "❌ design_spec.md 不存在，Phase 3 未完成"; exit 1; }
echo "✅ Gate 3 通过: 设计规范已生成"
```

### Gate 5: Phase 5 完成检查

```bash
SVG_COUNT=$(ls "$PPT_DIR/svg_output/"*.svg 2>/dev/null | wc -l | tr -d ' ')
test "$SVG_COUNT" -ge 1 || { echo "❌ svg_output/ 下无 SVG 文件，Phase 5 未完成"; exit 1; }
echo "✅ Gate 5 通过: ${SVG_COUNT} 个 SVG 页面已生成"
```

### Gate 5.5: Phase 5.5 完成检查

```bash
SVG_COUNT=$(ls "$PPT_DIR/svg_output/"*.svg 2>/dev/null | wc -l | tr -d ' ')
PNG_COUNT=$(ls "$PPT_DIR/previews/"*.png 2>/dev/null | wc -l | tr -d ' ')
test "$PNG_COUNT" -ge 1 || { echo "❌ previews/ 下无 PNG 预览，Phase 5.5 未完成"; exit 1; }
echo "✅ Gate 5.5 通过: ${PNG_COUNT}/${SVG_COUNT} 个预览已生成"
```

### Gate 7: Phase 7 完成检查

```bash
PPTX_COUNT=$(ls "$PPT_DIR/"*.pptx 2>/dev/null | wc -l | tr -d ' ')
test "$PPTX_COUNT" -ge 1 || { echo "❌ PPTX 文件不存在，Phase 7 未完成"; exit 1; }
echo "✅ Gate 7 通过: PPTX 已导出"
```

## 变量约定

在 SKILL 执行过程中，以下变量由 Phase 0 定义，后续 Phase 统一使用：

```
$SCRIPTS_DIR  = plugin/skills/ppt-generator/scripts/      # 工具脚本目录
$REFERENCE_DIR = plugin/skills/ppt-generator/references/  # 参考资源目录
$PPT_DIR      = ${PWD}/output/ppt-generator/$BATCH_ID/    # 当前项目工作目录（基于用户工作目录）
```

## 脚本接口速查

| 脚本 | 用途 | 调用方式 |
|------|------|----------|
| `pipeline.py` | 后处理统一入口（split→finalize→export） | `python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR` |
| `svg_lint.py` | SVG 质量门禁（PPT兼容 + 视觉质量） | `python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/ [--visual]` |
| `style_advisor.py` | 风格推荐引擎（BM25 搜索） | `python3 $SCRIPTS_DIR/style_advisor.py "关键词" --design-system` |
| `pptx_to_template.py` | PPTX 模板提取（画布/配色/字体/布局 + SVG 精确配色） | `python3 $SCRIPTS_DIR/pptx_to_template.py input.pptx -o $PPT_DIR/templates/ [--screenshot]` <br> **注意**：`--style-only` 模式下自动追加 `style/` 子目录，实际输出路径为 `-o $PPT_DIR/style/` |
| `finalize_svg.py` | SVG 后处理（嵌入图标/图片等） | `python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR` |
| `svg_to_pptx.py` | SVG 转 PPTX | `python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final` |
| `total_md_split.py` | 讲稿拆分为各页备注 | `python3 $SCRIPTS_DIR/total_md_split.py $PPT_DIR` |
| `analyze_images.py` | 图片内容分析 | `python3 $SCRIPTS_DIR/analyze_images.py $PPT_DIR/images/` |
| `pdf_to_md.py` | PDF 转 Markdown | `python3 $SCRIPTS_DIR/pdf_to_md.py input.pdf -o output.md` |
| `web_to_md.py` | 网页转 Markdown | `python3 $SCRIPTS_DIR/web_to_md.py "https://..." -o output.md` |
| `web_to_md.cjs` | 微信/高防站点转 Markdown（Node.js） | `node $SCRIPTS_DIR/web_to_md.cjs "https://..."` |

---

## Phase 0: 环境变量初始化

**目标**：定义所有路径变量，验证环境和源文件，创建工作目录。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-0-precheck.md`

**完成后应存在**：`$PPT_DIR/` 目录及所有子目录。

→ 执行 Gate 0 检查（见上方检查点表格），通过后进入 Phase 1。

---

## Phase 1: 源内容处理

**目标**：将 PDF/URL/Markdown 源文档统一转换为 Markdown，保存到 `$PPT_DIR/sources/`。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-1-source-processing.md`

**支持的输入类型**：
- **PDF** → `pdf_to_md.py` 转换
- **URL** → `web_to_md.py` 或 `web_to_md.cjs`（微信等高防站点用 .cjs）
- **Markdown** → 直接读取

→ 执行 Gate 1 检查，通过后进入 Phase 2。

---

## Phase 2: 模板选择（强制）

**目标**：选择模板来源和视觉风格配置。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-2-project-init.md`

**四选一**（用户选一个后只走对应流程）：
- **A) 内置模板** — 选一套内置模板，直接用其配色和布局
- **B) 内置模板 + 自定义配色** — 选内置模板作骨架，自定义配色/字体
- **C) PPTX 模板提取** — 用户提供空白骨架 PPTX，解析 OpenXML 生成 SVG 模板，严格套用原布局
- **D) 风格克隆** — 用户提供任意 PPTX（含内容亦可），只提取配色/字体/调性，内容完全重新生成

→ 执行 Gate 2 检查（**关键**），通过后进入 Phase 3。

---

## Phase 3: Strategist（核心交互）

**目标**：扫描源文档，一次性给出 8 项设计确认推荐，生成《设计规范与内容大纲》。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-3-strategist.md`

**智能 8 项确认**（一次性输出，非 8 轮串行）：
1. 画布格式（PPT 16:9 / 4:3 / 小红书等）
2. 页数范围（基于内容量推荐）
3. 目标受众与场景
4. 设计风格（A 通用灵活 / B 一般咨询 / C 顶级咨询）
5. 配色方案（主导色/辅助色/强调色）
6. 图标使用（Emoji / AI生成 / 内置库 / 自定义）
7. 图片使用（不使用 / 用户提供 / AI生成 / 占位符）
8. 排版方案（字体 + 字号基准）

**产出物**：`$PPT_DIR/design_spec.md`（12 章节设计规范）

→ 执行 Gate 3 检查，通过后进入 Phase 4 或 Phase 5。

---

## Phase 4: 图片生成（条件触发）

**目标**：仅当 Phase 3 的图片方案包含 AI 生成时执行。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-4-image-generator.md`

如果图片方案为「不使用」或「用户提供」，跳过此 Phase。

---

## Phase 5: SVG 页面生成

**目标**：按设计规范逐页生成 SVG 幻灯片。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-5-svg-generation.md`

**关键能力**：
- 根据设计风格选择对应的 executor guide 加载：
  - 通用灵活 → `Read: $REFERENCE_DIR/styles/executor-general.md`
  - 一般咨询 → `Read: $REFERENCE_DIR/styles/executor-consultant.md`
  - 顶级咨询 → `Read: $REFERENCE_DIR/styles/executor-consultant-top.md`
- **7 大类视觉质量规则**：空间利用、元素关系、尺寸比例、色彩可读性、版面构图、跨页一致性、数据可视化
- **断点续传**：通过 `$PPT_DIR/progress.json` 记录进度，支持从指定页码恢复

> ⚠️ **Phase 2 选项 C 分叉**：如果 Phase 2 选择了选项 C（PPTX 模板提取），
> 在生成 SVG 前必须**先读取** `$PPT_DIR/templates/design_spec.md` 中的「使用说明」章节，
> 进入**模板填充模式**：只替换占位符文本，不添加模板中没有的装饰元素，
> 不修改布局结构和配色方案。视觉丰富度规则（L1/L2/L3）在模板填充模式下不适用。

→ 执行 Gate 5 检查，通过后进入 Phase 5.5。

---

## Phase 5.5: SVG 视觉质量验收（强制）

**目标**：生成 PNG 预览图，运行视觉质量自动检查，AI 逐页视觉审查，不合格必须修复。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-5.5-visual-review.md`

**执行流程**：

```bash
# 1. 生成 PNG 预览图（cairosvg）
mkdir -p $PPT_DIR/previews
for svg in $PPT_DIR/svg_output/*.svg; do
  name=$(basename "$svg" .svg)
  python3 -c "import cairosvg; cairosvg.svg2png(url='$svg', write_to='$PPT_DIR/previews/${name}.png', scale=2)"
done

# 2. 运行视觉质量自动检查
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/ --visual
```

**自动检查项**（来自 phase-5 的 7 大规则 + executor guide）：

| 检查维度 | 规则来源 | 检查内容 |
|---------|---------|---------|
| 视觉丰富度 | phase-5 规则8 | 每页 defs 至少1个 gradient 且被引用 |
| 卡片阴影 | executor guide | 有卡片的页面必须有 filter 阴影 |
| 字号层级 | 设计规范 | 标题≥36px，正文≥18px |
| 色彩对比度 | phase-5 规则4 + CRAP-C | 常见低对比度颜色对自动检测 |
| 颜色数量 | 设计规范 | 单页非灰度色≤5种 |
| PPT兼容性 | 现有规则 | 禁用元素/属性/模式（原有检查） |

**AI 逐页视觉审查**（必须用 Read 工具查看 PNG 预览，不能只看 SVG 源码）：

- 整体观感是否有层次（不是"白蒙蒙"或"黑糊糊"）
- 卡片是否有深度感（阴影）
- 渐变装饰是否存在
- 文字是否清晰可辨
- 跨页风格是否一致

**不合格必须修复后重新验收，才能进入 Phase 6。**

→ 执行 Gate 5.5 检查，通过后进入 Phase 6。

---

## Phase 6: 演讲备注生成

**目标**：基于全部 SVG 生成演讲备注 `notes/total.md`，再拆分为各页独立备注。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-6-notes-generation.md`

---

## Phase 7: 后处理 + 导出

**目标**：通过 pipeline.py 一条命令完成讲稿拆分、SVG 后处理、PPTX 导出。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-7-post-process.md`

```bash
# 执行全部步骤
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR

# 仅执行指定步骤
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step split
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step export

# 失败不中断
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --continue-on-error
```

→ 执行 Gate 7 检查，通过后进入 Phase 8（可选）。

---

## Phase 8: 质量检查 + 视觉优化

**目标**：自动质量门禁检测问题，可选 CRAP 视觉优化。

→ 加载指南：`Read: $REFERENCE_DIR/guides/phase-8-quality-check.md`

```bash
# PPT 兼容性检查
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/

# PPT 兼容 + 视觉质量检查
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/ --visual

# 如需视觉优化，加载 CRAP 原则
# Read: $REFERENCE_DIR/styles/optimizer-crap.md

# 优化后重新执行后处理
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR
```

---

## 参考资源索引

| 资源 | 路径 | 说明 |
|------|------|------|
| 风格推荐数据 | `$REFERENCE_DIR/advisor/` | 5 个 CSV（styles, colors, typography, charts, ui-reasoning） |
| Phase 指南 | `$REFERENCE_DIR/guides/` | 10 个 phase-*.md（含 5.5 视觉验收） |
| Executor 指南 | `$REFERENCE_DIR/styles/` | executor-general/consultant/consultant-top + optimizer-crap |
| 页面布局模板 | `$REFERENCE_DIR/templates/layouts/` | 24 套内置模板 |
| 图表模板 | `$REFERENCE_DIR/templates/charts/` | 35 种标准化图表 SVG |
| 设计规范参考 | `$REFERENCE_DIR/templates/design_spec_reference.md` | 12 章节模板 |
| 矢量图标库 | `$REFERENCE_DIR/icons/` | 640+ SVG 图标 |
| 设计参考文档 | `$REFERENCE_DIR/docs/` | 设计指南、画布格式、图片布局、SVG 嵌入 |
