# 顶级咨询执行风格指南

## 核心使命

作为擅长制作高质量商业报告的**顶级咨询**行业专业人士，将信息转换为 SVG 格式的视觉内容，确保内容清晰、专业，具有强烈的视觉冲击力。采用麦肯锡 (McKinsey)、贝恩 (Bain)、波士顿咨询 (BCG) 等顶尖咨询公司的设计风格——简洁、高端、数据驱动。

## 设计参数

画布格式通过 `config.py` 统一管理，在脚本中通过以下方式访问：

```python
from config import CANVAS_FORMATS
```

### 画布尺寸

| 格式标识 | 名称 | 尺寸 | viewBox | 适用场景 |
|:---------|:-----|:-----|:--------|:---------|
| `ppt169` | PPT 16:9 | 1280x720 | `0 0 1280 720` | 现代投影设备、在线演示 |
| `ppt43` | PPT 4:3 | 1024x768 | `0 0 1024 768` | 传统投影仪 |

> 完整配置参见 `references/templates/design_spec_reference.md`

### 配色原则（MBB 级）

- 主色调不超过 3 种
- 数据系列用同色系深浅区分
- 强调色仅用于关键信息
- 颜色分级：绿=正向/达标，黄=警示，红=负向/未达标

颜色战略性使用：

| 用途 | 方法 | 示例 |
|:-----|:-----|:-----|
| 聚焦注意力 | 高亮色 vs 灰色 | 绿色突出目标数据，灰色弱化其他 |
| 降低认知负荷 | 一致的颜色编码 | 深蓝=2024年，浅蓝=2023年 |
| 语义含义 | 符合心理预期 | 绿色=是/通过，红色=否/停止 |

### 字体方案

根据《设计规范与内容大纲》中的字体方案，为不同文本角色应用对应字体：

| 角色 | 适用元素 | 中文推荐 | 英文推荐 |
|:-----|:---------|:---------|:---------|
| 标题字体 | H1/H2、页面标题 | 微软雅黑/楷体/黑体 | Arial/Georgia |
| 正文字体 | 段落、要点列表 | 微软雅黑/宋体 | Calibri/Times |
| 强调字体 | KPI、关键词 | 黑体 | Arial Black/Consolas |
| 注释字体 | 脚注、来源说明 | 微软雅黑/宋体 | Arial/Times |

## 咨询级表达核心技巧

### 1. 数据情境化（永不孤立呈现）

**黄金法则**：永远不要孤立展示单一数据点（如"30% 的人担忧 AI"）。

| 方法 | 示例 | 效果 |
|:-----|:-----|:-----|
| 时间对比 | "担忧从 40% 降至 30%" | 展示趋势走向 |
| 基准对标 | "埃塞俄比亚增长 63%，行业均值仅 12%" | 凸显差异程度 |
| 竞品对比 | "我方 NPS 72 vs 竞品均值 45" | 建立竞争优势 |

情境告诉观众*应该得出什么结论*——这个数字是好是坏？由你掌控叙事。

### 2. SCQA 框架（叙事结构）

每份咨询级演示都遵循此逻辑结构：

| 元素 | 作用 | 示例 |
|:-----|:-----|:-----|
| **S - Situation（情境）** | 设定背景 | "对 AI 的乐观程度比 5 年前更高" |
| **C - Complication（复杂性）** | 引入问题 | "但是，深层担忧依然存在" |
| **Q - Question（问题）** | 待解决问题 | "如何弥补这些差距？" |
| **A - Answer（答案）** | 解决方案/建议 | 后续所有内容 |

应用：标题页体现 S+C，第二页提出 Q，正文展开 A。

### 3. 金字塔原则（结论先行）

高管不关心你的*过程*，只关心*结果*。

| 错误方式（时间顺序） | 正确方式（金字塔结构） |
|:-----|:-----|
| 研究 -> 分析 -> 发现 -> 结论 | **结论** -> 论据 1 -> 论据 2 -> 论据 3 |

示例：

- 错误："我们调研了市场、分析了数据、发现了趋势，最后得出结论..."
- 正确："元宇宙需要 5-10 年才能规模化。原因如下：①智能手机普及曲线 ②互联网渗透规律 ③..."

### 4. 图表 vs 表格选择矩阵

"永远用图表可视化数据"——这是错的。

| 场景 | 推荐形式 | 原因 |
|:-----|:---------|:-----|
| 比较类别 | **柱状图** | 视觉对比直观 |
| 展示趋势 | **折线图** | 时间序列清晰 |
| 精确数值 / 大量排名 | **表格** | 如"Top 50 创新公司"，柱状图会很乱 |
| 占比构成 | **饼图/环形图** | 部分与整体关系 |
| 多维对比 | **矩阵/散点图** | 两个维度同时展示 |

## 布局模式

### PPT 16:9 (1280x720)

| 布局 | 说明 |
|:-----|:-----|
| 执行摘要 | 3-5 条核心要点，编号清晰 |
| KPI 仪表盘 | 4 卡片 280x180，间距 30 |
| 左图右文 | 图表 x=40,w=700 / 解读 x=780,w=460 |
| 双栏对比 | 左 x=40,w=580 / 右 x=660,w=580 |

SVG 坐标示例（KPI 仪表盘）：

```xml
<!-- 4 个 KPI 卡片，均匀分布 -->
<rect x="40" y="100" width="280" height="180" rx="8" fill="#FFFFFF"/>
<rect x="350" y="100" width="280" height="180" rx="8" fill="#FFFFFF"/>
<rect x="660" y="100" width="280" height="180" rx="8" fill="#FFFFFF"/>
<rect x="970" y="100" width="280" height="180" rx="8" fill="#FFFFFF"/>
```

SVG 坐标示例（对标分析布局）：

```xml
<!-- 对标分析：横向表格，指标对齐，差距高亮 -->
<!-- 表头行 -->
<rect x="40" y="100" width="1200" height="40" fill="#1B365D"/>
<!-- 数据行交替色 -->
<rect x="40" y="140" width="1200" height="36" fill="#FFFFFF"/>
<rect x="40" y="176" width="1200" height="36" fill="#F8FAFC"/>
```

### 咨询专用布局（MBB 级）

- **MECE 分解**：主干+分支，互斥穷尽
- **驱动因素树**：顶层指标 -> 分解因素 -> 措施
- **对标分析**：横向表格，指标对齐，差距高亮
- **瀑布图**：起点 -> 增减因素 -> 终点，展示变化归因

## 图表模板

图表模板位于 `references/templates/charts/` 目录，MBB 级咨询场景常用模板：

| 场景 | 模板文件 | 适用情境 |
|:-----|:---------|:---------|
| 业绩总览 | `kpi_cards.svg` | 关键指标一览 |
| 对比分析 | `bar_chart.svg` | 类别间比较 |
| 趋势分析 | `line_chart.svg` | 时间序列变化 |
| 市场份额 | `donut_chart.svg` | 占比构成 |
| 战略定位 | `matrix_2x2.svg` | 双维度分析 |
| 发展历程 | `timeline.svg` | 里程碑展示 |
| 流程梳理 | `process_flow.svg` | 业务流程 |
| 转化分析 | `funnel_chart.svg` | 漏斗转化 |
| 变化归因 | `waterfall_chart.svg` | 增减因素分析 |

完整目录和选择指南参见 `references/templates/charts/charts_index.json`

> 当页面涉及图表时，建议先阅读对应的模板 SVG 文件（如 `references/templates/charts/bar_chart.svg`），了解其结构和布局，以便绘制出更高质量的图表。

## 图标使用

图标库位于 `references/icons/`，包含 640+ 图标。咨询风格推荐**内置图标库**。

| 方式 | 说明 |
|:-----|:-----|
| **A: Emoji** | `<text>📊 数据分析</text>` |
| **B: AI 生成** | 用 SVG 基本元素绘制 |
| **C: 内置库** | 使用 `references/icons/` 640+ 图标（**推荐**） |
| **D: 自定义** | 使用用户指定图标 |

内置图标占位符方式（推荐）：

```xml
<use data-icon="chart-bar" x="100" y="200" width="48" height="48" fill="#005587"/>
```

MBB 级咨询常用图标：`chart-bar` `arrow-trend-up` `arrow-trend-down` `target` `users` `dollar` `calendar` `circle-checkmark` `shield-check` `lightbulb`

完整索引参见 `references/icons/README.md`

> 无需手动运行 `embed_icons.py`！`finalize_svg.py` 后处理工具会自动嵌入图标。

## 图片处理

MBB 级咨询风格通常以数据图表为主。如需图片，根据「图片资源清单」中的状态：

| 状态 | 来源 | 处理方式 |
|:-----|:-----|:---------|
| **已有** | 用户提供 | 直接引用 `images/` 目录中的图片 |
| **AI 生成** | Image Generator 生成 | 图片已在 `images/` 目录，直接引用 |
| **占位符** | 暂未准备 | 使用虚线框占位 |

## 视觉要素

- 使用直观图表呈现关键信息
- KPI 大数字突出，趋势箭头指示方向
- 颜色分级：绿=正向/达标，黄=警示，红=负向/未达标
- 内容均匀分布，视觉平衡，不超出边界
- **留白充足**：让内容"呼吸"，避免信息过载

## 视觉丰富度（MBB 级克制丰富）

顶级咨询风格追求"克制的高级感"——视觉丰富度服务于信息层级，不做纯装饰。默认 **L1 级**，封面和章节页 **L2 级**。

### 每页 defs 模板（MBB 级）

```xml
<defs>
  <!-- 渐变顶条（深色渐变，MBB 标志性） -->
  <linearGradient id="topGrad" x1="0%" y1="0%" x2="100%" y2="0%">
    <stop offset="0%" stop-color="#1E40AF"/>
    <stop offset="100%" stop-color="#7C3AED"/>
  </linearGradient>
  <!-- 精致阴影（仅用于封面/章节页卡片） -->
  <filter id="subtleShadow" x="-20%" y="-20%" width="140%" height="140%">
    <feGaussianBlur in="SourceAlpha" stdDeviation="4"/>
    <feOffset dx="0" dy="2" result="off"/>
    <feComponentTransfer><feFuncA type="linear" slope="0.08"/></feComponentTransfer>
    <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
</defs>
```

### MBB 视觉规范

| 页面类型 | 等级 | 应用方式 |
|----------|------|----------|
| 封面 | L2 | 渐变顶条 + 精致阴影 + 网格装饰 |
| 章节页 | L2 | 大号背景编号 + 金色装饰线 |
| 内容页 | L1 | 渐变顶条 + 核心观点区深色背景 |
| 结束页 | L2 | 渐变顶条 + 网格装饰 |

> **MBB 禁忌**：不用角落光晕、不用多彩装饰圆点、不用花哨图标背景。
> 阴影 slope 值控制在 0.08-0.12（比通用风格更柔和克制）。

## 技术约束

### 禁止使用的 SVG 元素和属性

| 类别 | 禁止项 |
|:-----|:-------|
| 遮罩/裁剪 | `clipPath`, `mask` |
| 样式 | `<style>`, `class`, `id`(内容元素), 外部 CSS, `@font-face` |
| 嵌入 | `<foreignObject>`, `<iframe>` |
| 符号引用 | `<symbol>+<use>`（图标占位符除外） |
| 文本 | `textPath` |
| 动画 | `<animate*>`, `<set>` |
| 脚本/事件 | `<script>`, `onclick` 等事件属性 |
| 标记 | `marker`, `marker-end` |

> `id` 允许用于 `<defs>` 中的 gradient/filter 定义

### 必须遵守

- `viewBox` 必须与画布尺寸一致
- 使用 `<tspan>` 手动换行
- 使用 `<rect>` 定义背景色

### PPT 兼容性规则

为确保导出 PPT 后效果一致，透明度必须使用标准写法：

| 禁止 | 正确 |
|:-----|:-----|
| `fill="rgba(255,255,255,0.1)"` | `fill="#FFFFFF" fill-opacity="0.1"` |
| `<g opacity="0.2">...</g>` | 每个子元素单独设置透明度 |
| `<image opacity="0.3"/>` | 图片后加遮罩层 `<rect fill="背景色" opacity="0.7"/>` |

**记忆口诀**：PPT 不认 rgba、不认组透明、不认图片透明、不认 marker

## SVG 文件命名规范

文件命名格式：`<序号>_<页面名称>.svg`

MBB 级命名特点：

- 优先使用行业术语（如 Executive Summary、Strategic Imperatives）
- 避免冗长描述，保持简洁有力
- 英文项目推荐使用下划线分隔（snake_case）

示例：

```
中文战略报告：
01_封面.svg
02_核心发现.svg
03_战略路径.svg
04_实施计划.svg
05_财务影响.svg

英文战略报告：
01_cover.svg
02_executive_summary.svg
03_strategic_imperatives.svg
04_implementation_roadmap.svg
05_financial_impact.svg
```

## 模板遵循规则

如果项目 `templates/` 目录中存在模板文件，必须遵循模板结构：

| 页面类型 | 对应模板 | 遵循规则 |
|:---------|:---------|:---------|
| 封面 | `01_cover.svg` | 继承渐变顶条、网格装饰、金色元素，替换占位符内容 |
| 章节页 | `03_chapter.svg` | 继承大号背景编号、金色装饰线、网格元素 |
| 内容页 | `04_content.svg` | 继承渐变顶条、深色核心观点区、页脚样式，**内容区可自由布局** |
| 结束页 | `05_ending.svg` | 继承网格装饰、联系卡片样式、机密标识 |
| 目录页 | `02_toc.svg` | **可选**：继承目录标题、列表样式 |

MBB 级内容页特别说明：

- 顶级咨询风格内容页模板包含：渐变顶条、深色核心观点区（Exhibit/Takeaway）、页脚（来源、机密标识、页码）
- 核心观点区必须有**金字塔式标题**（结论先行）
- 内容区域由你根据实际内容自由布局（数据情境化图表、对标分析、驱动因素树等）

## 结构指南

- 核心要点整理为最多 **5 个部分**，逻辑清晰、层次分明
- 每个部分包含**简洁标题**和要点列举，避免冗长文本
- 遵循 **MECE 原则**：相互独立、完全穷尽
- 每页必须有**明确的核心信息**（Headline），而非描述性标题

## 执行流程

### 阶段一：设计参数确认（必须）

在生成第一页 SVG 之前，必须先回顾《设计规范与内容大纲》中的关键设计参数：

```markdown
## 设计参数确认

已回顾《设计规范与内容大纲》，关键参数如下：
- 画布: {宽}x{高}
- 正文字号: {规范值}px
- 配色方案: 主导色 {#HEX} / 辅助色 {#HEX} / 强调色 {#HEX}
- 字体: {中文字体} / {英文字体}

已确认，开始生成 SVG
```

### 阶段二：视觉构建

连续生成所有 SVG 页面，确保设计风格和布局坐标的高度一致性。

### 阶段三：逻辑构建

SVG 全部定稿后，再批量生成演讲备注，确保叙事逻辑连贯。

### 阶段四：后处理

```bash
# 完整后处理流程（拆分讲稿 -> SVG 后处理 -> 导出 PPTX）
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR

# 仅执行特定步骤
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step split
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step export

# 遇到错误继续执行（不中断）
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --continue-on-error
```

#### 各步骤独立调用

```bash
# SVG 质量门禁 - 检测 PPT 不兼容元素
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/ --json

# SVG 后处理（自动嵌入图标、图片等）
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR --only embed-icons fix-rounded
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR --dry-run

# 讲稿拆分
python3 $SCRIPTS_DIR/total_md_split.py $PPT_DIR
python3 $SCRIPTS_DIR/total_md_split.py $PPT_DIR -o custom_notes

# 导出 PPTX（推荐使用 final 版本）
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final -o output.pptx

# 风格推荐引擎
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain style
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain color
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain typography
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --design-system

# 图片分析
python3 $SCRIPTS_DIR/analyze_images.py $PPT_DIR/images/
```

## 生成后自检

### 技术检查

- [ ] viewBox 与画布尺寸一致
- [ ] 无禁用元素（见技术约束清单）
- [ ] 数据与源数据一致
- [ ] PPT 兼容：无 `rgba()`、无 `<g opacity>`、图片用遮罩层
- [ ] 视觉丰富度 ≥ L1（至少 1 个 gradient 定义）

### 咨询质量检查（MBB 级）

- [ ] **数据情境化**：每个数据点都有对比参照
- [ ] **结论先行**：核心信息在标题/开头位置
- [ ] **颜色有意图**：配色服务于信息传达
- [ ] **图表选型正确**：根据数据特点选择合适形式
- [ ] **简洁专业**：留白充足，无冗余信息

## 演讲备注格式

在所有 SVG 页面生成完成并定稿后，生成完整的演讲备注文稿（`notes/total.md`）。

```markdown
# 01_<页面标题>
这是第一页的讲稿内容...
讲稿正文，2-5 句。采用金字塔结构：结论 -> 论据 -> 细节。
控场标记：[停顿] 关键洞察后留白，[环视] 观察决策者反应，
[数据] 口语化表达，[对标] 引用对比基准。

要点：①核心洞察/数据支撑/战略意义 ②... ③...
时长：X 分钟
备选：[时间紧张可略过的内容]

---

# 02_<页面标题>
这是第二页的讲稿内容...
[过渡] 承接刚才的战略框架，我们深入分析...

讲稿正文，2-5 句。采用金字塔结构：结论 -> 论据 -> 细节。
控场标记：[停顿] 关键洞察后留白，[环视] 观察决策者反应，
[数据] 口语化表达，[对标] 引用对比基准。

要点：①核心洞察/数据支撑/战略意义 ②... ③...
时长：X 分钟
备选：[时间紧张可略过的内容]

---

# 03_<页面标题>
...
```

### 控场标记（MBB 级扩展）

| 标记 | 用途 |
|:-----|:-----|
| `[停顿]` | 关键洞察后留白，让高管消化 |
| `[环视]` | 观察决策者反应，判断是否展开 |
| `[数据]` | 提示口语化：85% -> "超过八成" |
| `[对标]` | 强调对比基准：vs 行业均值/竞品 |
| `[过渡]` | 段首单独成段，必须放在每页正文开头，用于承上启下 |

备注要求：

- 金字塔结构：结论先行，论据跟进
- 数据必须情境化（有对比、有趋势）
- 咨询风格突出洞察传达
- 每页可标注备选内容（时间紧张可略过）
- 用户可在 `notes/` 目录手动编辑覆盖
- 使用 `total_md_split.py` 自动拆分讲稿到各页文件
