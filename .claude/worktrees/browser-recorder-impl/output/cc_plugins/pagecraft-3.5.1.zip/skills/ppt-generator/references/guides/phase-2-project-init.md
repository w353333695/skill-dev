# Phase 2: 项目初始化与模板选择

> 创建项目结构、选择模板、配置视觉风格

## 目标

- 确认源材料已归档到 `$PPT_DIR/sources/`
- **选择一种模板来源**（三选一）
- 将模板文件和视觉配置写入 `$PPT_DIR/templates/`

## 产出物

- `$PPT_DIR/templates/design_spec.md` — 设计规范（必选，所有 Phase 共同依赖）
- `$PPT_DIR/templates/*.svg` — 页面模板文件（选项 A/B 从内置复制，选项 C 由 AI 生成）
- `$PPT_DIR/images/` — 图片资源

## 前置条件

- Phase 1 已完成（源材料已转为 Markdown 并保存到 `$PPT_DIR/sources/input.md`）

---

## Step 1: 确认源材料

```bash
ls $PPT_DIR/sources/input.md 2>/dev/null && echo "✅" || echo "❌ 需要补归档"
```

---

## Step 2: 选择模板来源（四选一，必须等用户选择）

> **必须向用户展示以下四个选项并等待用户回复。** 不要自行判断用户适合哪个选项而跳过展示。不要默认帮用户选 A。

向用户展示：

```
请选择模板来源：
  A) 内置模板 — 直接使用内置模板的默认配色和布局
  B) 内置模板 + 自定义配色 — 用内置模板的结构，但自定义配色/字体
  C) PPTX 模板提取 — 你有自己的 PPTX 模板文件，从中提取视觉风格（需要 LibreOffice）
  D) 风格克隆 — 你有一份参考 PPT，希望新 PPT 的配色、字体、整体风格与它保持一致
               （内容完全重新生成，不是填模板；参考文件可以是有内容的完整 PPT）
```

| # | 选项 | 输入 | 说明 |
|---|------|------|------|
| **A** | 使用内置模板 | 选择一套内置模板 | 开箱即用 |
| **B** | 内置模板 + 自定义配色 | 选内置模板 + 描述想要的风格 | 自定义配色/字体 |
| **C** | PPTX 模板提取 | 用户提供空白骨架 PPTX | 从 PPTX 中提取视觉风格并还原为 SVG 模板，严格套用原布局 |
| **D** | 风格克隆 | 用户提供任意 PPTX（可含内容） | 只提取设计语言（配色/字体/调性），内容完全重新生成 |

用户选择后，**只执行对应选项的 Step，跳过其他三个**。

---

## 选项 A：使用内置模板

### Step A1: 展示模板列表，用户选择

读取模板索引：

```bash
python3 -c "
import json
with open('$REFERENCE_DIR/templates/layouts/layouts_index.json', 'r') as f:
    layouts = json.load(f)
for name, info in layouts.items():
    print(f'{name}: {info.get(\"description\", \"\")}')" 2>/dev/null
```

常用模板速查：

| 模板 | 风格 | 适用场景 |
|------|------|----------|
| `general` | 通用灵活 | 一般商业演示、培训 |
| `consultant` | 一般咨询 | 数据报告、项目汇报 |
| `consultant_top` | 顶级咨询 | 战略报告、董事会 |
| `google_style` | Google 风格 | 科技、产品发布 |
| `mckinsey` | 麦肯锡 | 高端咨询交付物 |
| `academic_defense` | 学术答辩 | 学位论文答辩 |
| `government_blue` | 政务蓝 | 政府工作报告 |
| `government_red` | 政务红 | 政府工作报告 |

### Step A2: 复制模板到项目目录

```bash
TEMPLATE_NAME="用户选择的模板名"

cp $REFERENCE_DIR/templates/layouts/$TEMPLATE_NAME/*.svg $PPT_DIR/templates/
cp $REFERENCE_DIR/templates/layouts/$TEMPLATE_NAME/design_spec.md $PPT_DIR/templates/
cp $REFERENCE_DIR/templates/layouts/$TEMPLATE_NAME/*.png $PPT_DIR/images/ 2>/dev/null || true
cp $REFERENCE_DIR/templates/layouts/$TEMPLATE_NAME/*.jpg $PPT_DIR/images/ 2>/dev/null || true
```

**完成。** 进入 Phase 3。

---

## 选项 B：内置模板 + 自定义配色

> 结构用内置模板的，配色/字体由用户自定义。

### Step B1: 选择骨架模板

根据用户风格需求推荐，或让用户自选（列表同选项 A 的 Step A1）。

| 用户风格需求 | 推荐骨架 | 理由 |
|-------------|---------|------|
| 极简/科技 | `consultant_top` | 深色/浅色交替、结构清晰 |
| 营销/产品 | `google_style` | 自由创意、视觉冲击力强 |
| 数据/报告 | `consultant` | 图表组合、KPI 仪表盘 |
| 正式/传统 | `government_blue` | 严谨规范 |
| 不确定 | `general` | 中性灵活 |

选择后复制模板文件（同 Step A2）。

### Step B2: 定制视觉风格

向用户询问想要什么样的视觉风格。用户可以：
- 用自然语言描述：「科技感」「温暖教育」「极简冷淡」
- 发参考截图
- 提及品牌名：「Apple 风格」「Notion 那种感觉」

Claude 根据用户描述生成视觉方案（配色 + 字体 + 装饰风格），格式：

```
为您推荐以下视觉方案（基于 [骨架模板名] 骨架）：
  主色: #XXXXXX    辅色: #XXXXXX
  强调: #XXXXXX    背景: #XXXXXX
  标题字体: 字体名 Weight
  正文字体: 字体名 Weight
  装饰风格: 描述

满意吗？可以调整任何部分。
```

用户可以反复调整直到满意。

> **辅助工具**：如果需要参考，可调用 `python3 $SCRIPTS_DIR/style_advisor.py "关键词" --design-system` 搜索内置风格库。

### Step B3: 写入 design_spec.md

用户确认后，将视觉方案写入 `$PPT_DIR/templates/design_spec.md`（覆盖模板自带的版本）。

**规则：**

| 可以覆盖（皮肤） | 不可覆盖（结构） |
|-----------------|----------------|
| 配色、字体、字号 | 页面结构（页眉/内容区/页脚） |
| 渐变色、阴影样式 | 边距体系、圆角体系 |
| 装饰元素风格 | 页脚格式、页面类型划分 |

**完成。** 进入 Phase 3。

---

## 选项 C：PPTX 模板提取（直接解析）

> 从用户提供的 PPTX 模板中直接解析 OpenXML 生成 SVG 模板和 design_spec.md。
>
> **不依赖 LibreOffice**（截图改为 best-effort，不可用不影响流程）。

### Step C1: 接收 PPTX 文件

用户提供 PPTX 模板文件。保存到 `$PPT_DIR/sources/template.pptx`。

> 仅支持干净模板（几页骨架，无大量真实内容）。如果用户提供了完整内容的 PPTX，引导其导出空白模板或改用选项 B。

### Step C2: 直接解析生成 SVG 骨架

> **C2 只做确定性分类**：封面 → `01_cover.svg`，结尾 → `05_ending.svg`。中间页保留为 `slide_XX_unknown.svg`（保留完整内容），**不预判类型**。标准模板文件（如 `04_content.svg`）由 C3 分类提升后生成。

**截图选项（执行前确认）：**

用 `AskUserQuestion` 询问用户是否添加 `--screenshot` 参数。截图用于 C3 分类和 C4 视觉对比，需要模型具备视觉能力且环境有 LibreOffice（不可用时自动跳过，不阻塞流程）。

```bash
python3 $SCRIPTS_DIR/pptx_to_template.py $PPT_DIR/sources/template.pptx -o $PPT_DIR/templates/
```

**输出：**
- `$PPT_DIR/templates/01_cover.svg` — 封面（确定性）
- `$PPT_DIR/templates/05_ending.svg` — 结尾页（确定性）
- `$PPT_DIR/templates/slide_XX_unknown.svg` — 中间页（保留完整内容，待 C3 分类提升为标准模板）
- `$PPT_DIR/templates/template_data.json` — 结构化数据（画布、字体、shapes 详情、配色、input_assessment）
- `$PPT_DIR/templates/c3_decision.json` — C3 决策骨架（供 Agent 填充分类和占位符）
- `$PPT_DIR/templates/unresolved_shapes.json` — 未解析形状报告（含非纯色填充告警）
- `$PPT_DIR/templates/design_spec.md` — 自动生成的设计规范（配色、字体、风格标签、占位符说明）
- `$PPT_DIR/templates/images/` — 提取的图片/logo（按内容 hash 去重）
- （如加 `--screenshot`）`$PPT_DIR/templates/slide_*.png` — best-effort 截图
  - 截图失败不阻塞流程，`template_data.json` 中标记 `"screenshot_method": "none"`

### Step C3: AI 补充分析（程序化执行）

> **Agent 只输出决策 JSON，不直接编辑文件。** 所有文件操作由 `pptx_template_apply.py` 脚本执行，确保可重复、可追溯。

**Step C3-a: 读取模板数据**

用 Read 工具读取以下文件：
1. `$PPT_DIR/templates/template_data.json` — 查看每页的特征摘要（shape_count, text_box_count, max_font_size_pt, has_image, text_preview）和 `standard_templates` 映射
2. `$PPT_DIR/templates/unresolved_shapes.json` — 查看未解析形状
3. （如有截图）`$PPT_DIR/templates/slide_*.png` — 用于视觉对比

**Step C3-b: Agent 填充决策 → 输出 JSON**

C2 已自动生成决策骨架 `$PPT_DIR/templates/c3_decision.json`。用 Read 工具读取该文件，结合 `template_data.json` 和截图（如有）填充：

| 字段 | Agent 操作 |
|------|-----------|
| `promotions[].type` | 填 `toc` / `chapter` / `content` |
| `promotions[].reason` | 填分类理由 |
| `replacements[].template` | 将 `slide_XX_unknown` 改为标准模板名（如 `02_toc`） |
| `mappings[].placeholder` | 从标准列表中选择占位符 |

**中间页类型判定标准**

| 类型 | 判定依据 |
|------|---------|
| `toc` | 有列表结构（多个段落/文本框）、标题含"目录/议程/contents"等关键词 |
| `chapter` | 大字号标题（>28pt）、文字简短（≤3个文本框）、图片少 |
| `content` | 多个文本框（≥4个）、有表格/图表、字号较小、内容丰富 |

不确定时 → 直接询问用户，展示该页的 `text_preview` 和特征摘要。

**占位符标准（来自内置模板实际使用）**

占位符必须从以下列表中选择，**不能自创**：

**封面 (cover)**

| 占位符 | 用途 |
|--------|------|
| `{{TITLE}}` | 主标题（最常用） |
| `{{SUBTITLE}}` | 副标题 |
| `{{AUTHOR}}` | 作者/机构 |
| `{{DATE}}` | 日期 |
| `{{PRESENTER}}` | 汇报人 |
| `{{ORGANIZATION}}` | 组织/单位 |
| `{{INSTITUTION}}` | 机构名 |
| `{{LOGO}}` / `{{LOGO_LARGE}}` | Logo |

**目录 (toc)**

| 占位符 | 用途 |
|--------|------|
| `{{PAGE_TITLE}}` | 页面标题（如"议程"） |
| `{{TOC_ITEM_1}}` ~ `{{TOC_ITEM_6}}` | 目录条目（简版，纯文本） |
| `{{TOC_ITEM_1_TITLE}}` ~ `{{TOC_ITEM_N_TITLE}}` | 目录条目标题（带描述的条目） |
| `{{TOC_ITEM_1_DESC}}` ~ `{{TOC_ITEM_N_DESC}}` | 目录条目描述 |

> 注意：部分现有模板使用 `{{CHAPTER_01_TITLE}}` / `{{CHAPTER_01_DESC}}` 表示目录条目，但 `CHAPTER_` 前缀易与章节页占位符混淆。生成新模板时**优先使用 `{{TOC_ITEM_N_TITLE}}` / `{{TOC_ITEM_N_DESC}}`**。

**章节页 (chapter)**

| 占位符 | 用途 |
|--------|------|
| `{{CHAPTER_NUM}}` | 章节编号 |
| `{{CHAPTER_TITLE}}` | 章节标题 |
| `{{CHAPTER_DESC}}` | 章节描述 |
| `{{CHAPTER_SUBTITLE}}` | 章节副标题 |
| `{{PAGE_NUM}}` | 页码 |
| `{{SECTION_NAME}}` | 章节名称（页脚） |

**内容页 (content)**

| 占位符 | 用途 |
|--------|------|
| `{{PAGE_TITLE}}` | 页面标题 |
| `{{PAGE_NUM}}` | 页码 |
| `{{SECTION_NAME}}` | 章节名称（页脚） |
| `{{CHAPTER_NUM}}` | 章节编号（页眉） |
| `{{CONTENT_AREA}}` | 内容区域（由脚本自动插入，无需在 replacements 中指定） |

> ⚠️ **content 类型的正文内容会被 `{{CONTENT_AREA}}` 整体替换，不要为卡片、列表项等配置占位符。**

**结尾页 (ending)**

| 占位符 | 用途 |
|--------|------|
| `{{THANK_YOU}}` | 感谢语 |
| `{{CONTACT_INFO}}` | 联系方式 |
| `{{TAGLINE}}` | 标语/品牌语 |
| `{{COPYRIGHT}}` | 版权信息 |
| `{{CLOSING_MESSAGE}}` | 结束语 |
| `{{AUTHOR}}` | 作者 |
| `{{DATE}}` | 日期 |

**3. 写入确认后的决策**

用 Write 工具将填充后的 JSON 写回 `$PPT_DIR/templates/c3_decision.json`。

**Step C3-c: 执行提升和替换（程序化）**

运行脚本，自动完成所有文件操作：

```bash
python3 $SCRIPTS_DIR/pptx_template_apply.py \
  $PPT_DIR/templates/template_data.json \
  --decision $PPT_DIR/templates/c3_decision.json
```

> 不要直接用 Edit/Bash 操作 SVG 文件。所有修改通过 `c3_decision.json` 驱动脚本执行。

**Step C3-d: 验证**

执行 `ls $PPT_DIR/templates/*.svg` 确认标准模板文件存在：`01_cover.svg`、`02_toc.svg`、`03_chapter.svg`、`04_content.svg`、`05_ending.svg`。Phase 5 依赖这些文件名。

**Step C3-e: 处理 unresolved shapes**

如需处理未解析形状，用 Edit 工具直接修改对应 SVG 模板文件。

### Step C4: 质量验收（视觉能力优雅降级）

> ⚠️ 必须执行。不能跳过。

**如果截图可用（`screenshot_method: "libreoffice"`）：**

用 Read 工具查看 SVG 模板和截图，**逐个对比**：

| # | 检查项 | 要求 |
|---|--------|------|
| 1 | 几何还原 | 矩形/椭圆/圆角矩形的位置和大小与截图一致 |
| 2 | 配色还原 | SVG 模板的填充色与截图一致 |
| 3 | 文本定位 | 文本框位置和字号与截图基本一致 |
| 4 | 未解析形状 | unresolved_shapes.json 中的形状已处理或确认可忽略 |

全部通过 → 向用户确认质量报告，然后进入 Phase 3。

有项不通过 → 修复 SVG 文件（用 Edit 工具），重新验收。

**如果截图不可用（`screenshot_method: "none"`）：**

提示用户自行对比：
- "我已从 PPTX 直接解析生成 SVG 模板，但当前环境无截图可供自动对比。请用 PowerPoint 打开原始 PPTX，与 `$PPT_DIR/templates/` 中的 SVG 文件对比，确认布局和颜色是否匹配。"

---

## Step 6: 确认画布格式

无论选择哪个选项，确认画布格式（通常为 PPT 16:9）：

| 格式 | 尺寸 | viewBox |
|------|------|---------|
| PPT 16:9 | 1280x720 | `0 0 1280 720` |
| PPT 4:3 | 1024x768 | `0 0 1024 768` |
| 小红书 | 1242x1660 | `0 0 1242 1660` |
| 朋友圈 | 1080x1080 | `0 0 1080 1080` |
| Story | 1080x1920 | `0 0 1080 1920` |

> 详细格式参考：`$REFERENCE_DIR/docs/canvas_formats.md`

---

---

## 选项 D：风格克隆

> 从用户提供的参考 PPTX 中提取设计语言（配色、字体、调性），用这套风格约束新 PPT 的生成。
> **与选项 C 的核心区别**：选项 C 严格复用原文件的页面结构；选项 D 只复用视觉风格，内容完全重新构建。

### Step D1: 接收参考文件 + 质量评估

用户提供参考 PPTX 文件（可以是有内容的完整 PPT，不限页数）。保存到 `$PPT_DIR/sources/reference.pptx`。

运行风格提取：

```bash
python3 $SCRIPTS_DIR/pptx_to_template.py \
  $PPT_DIR/sources/reference.pptx \
  -o $PPT_DIR/style/ \
  --style-only
```

**产出物：**
- `$PPT_DIR/style/template_data.json` — 精简版数据（canvas/colors/fonts/style_signals/input_assessment）
- `$PPT_DIR/style/style_profile.md` — 风格档案（Phase 3 直接加载）
- `$PPT_DIR/style/style_preview.svg` — 色板预览图（展示给用户确认）

**质量评估处理**（读取 `template_data.json` 的 `input_assessment.quality` 字段）：

| 评估结果 | 处理方式 |
|---------|---------|
| `good` | 正常继续 |
| `limited` | 告知用户："设计信息有限，提取结果可能不够准确，建议确认后再调整" |
| `poor` | **必须**告知用户："无法从该文件提取有效风格信息，建议改用选项 B（内置模板+自定义配色）"，询问是否仍要继续 |

**不允许**在评估为 `poor` 时跳过告知步骤。

### Step D2: 展示色板预览 + 用户确认

用 Read 工具展示 `$PPT_DIR/style/style_preview.svg`，然后输出确认话术：

```
已从参考 PPT 提取到以下视觉风格（见色板预览图）：

  整体调性：[从 style_profile.md 读取]
  标题字体：[字体名] Bold
  正文字体：[字体名] Regular

⚠️ 说明：本功能复刻配色和字体，具体装饰细节（圆角大小、分隔线样式、
   图标风格等）由 AI 参考调性自由生成，不保证与参考 PPT 像素级一致。
   如需严格套用原文件布局，请改用选项 C（PPTX 模板提取）。

是否保留这套风格？可以描述你想调整的部分。
```

用户确认后，如有修改意见，直接用 Edit 工具修改 `$PPT_DIR/style/style_profile.md` 中对应的色值或字体名。

### Step D3: Gate 2 检查

选项 D 的 Gate 2 检查 `style_profile.md` 是否存在（替代原有的 SVG 模板检查）：

```bash
test -f "$PPT_DIR/style/style_profile.md" || {
  echo "❌ style_profile.md 不存在，Phase 2 选项 D 未完成"
  exit 1
}
echo "✅ Gate 2 通过（选项 D）: 风格档案已生成"
```

通过后进入 Phase 3。Phase 3 在 Strategist 开始前需先读取 `$PPT_DIR/style/style_profile.md`，将配色和字体直接带入八项确认的第 4、5、8 项推荐值。

---

## 常见问题

### Q: 用户想完全不使用模板？

不允许。引导其选择最接近的内置模板。

### Q: 用户选了 A 之后又想换配色？

直接进入选项 B 的流程（选骨架模板 + 自定义配色），不需要重新开始。

### Q: LibreOffice 未安装？

选项 C 不依赖 LibreOffice（直接解析 OpenXML）。截图可选（`--screenshot`），不影响主流程。

### Q: 用户提供了完整内容的 PPTX？

引导导出空白模板，或改用选项 B。

### Q: 模板目录中没有 design_spec.md？

Claude 根据模板 SVG 文件和用户需求自行生成。
