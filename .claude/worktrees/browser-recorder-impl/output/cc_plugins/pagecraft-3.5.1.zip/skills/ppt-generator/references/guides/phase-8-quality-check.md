# Phase 8: 质量检查与优化

> 运行 SVG 质量门禁检测 PPT 不兼容问题，按严重程度分级处理，必要时触发 CRAP 优化

## 目标

- 使用 `svg_lint.py` 检测所有 SVG 文件的 PPT 兼容性问题
- 按严重程度分级处理（warning vs error）
- 对视觉质量问题触发 CRAP 优化（Contrast/Repetition/Alignment/Proximity）
- 确保最终交付物质量达标

## 产出物

- 质量检查报告（输出到终端）
- 修复后的 SVG 文件（如有问题）
- 重新导出的 PPTX（如有修复）

## 前置条件

- Phase 7 已完成（PPTX 已导出）
- `svg_final/` 目录存在且包含 SVG 文件

---

## 执行步骤

### Step 1: 运行 SVG 质量门禁

使用 `svg_lint.py` 检测 `svg_final/` 中所有 SVG 文件：

```bash
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_final/
```

**参数说明**：

| 参数 | 说明 | 示例 |
|------|------|------|
| 位置参数 | SVG 文件或目录路径 | `$PPT_DIR/svg_final/` |
| `--json` | JSON 格式输出 | `--json` |

**检查单个文件**：

```bash
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_final/03_市场分析.svg
```

**JSON 格式输出（便于程序化处理）**：

```bash
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_final/ --json
```

**预期输出（文本格式）**：

```
✅ 01_封面.svg
✅ 02_目录.svg
⚠️  03_市场分析.svg: 2 issue(s)
   [forbidden_pattern]:L45 rgba() color (PPT incompatible)
   [forbidden_pattern]:L78 <g opacity=...> (use fill opacity instead)
✅ 04_竞争格局.svg
...
✅ 12_结束页.svg

⚠️  1/12 file(s) have issues.
```

### Step 2: 理解检测结果

#### 检测规则分类

`svg_lint.py` 检测以下 4 类问题：

**1. 禁用元素（forbidden_element）**

以下元素在 PPT 中无法正确渲染：

```
clipPath | mask | foreignObject | textPath |
animate | animateMotion | animateTransform | animateColor |
set | script | iframe | style | symbol
```

**2. 禁用属性（forbidden_attribute）**

以下属性会导致 PPT 兼容性问题：

```
class | id | marker-end | onclick | onload |
onmouseover | onmouseout | onfocus | onblur | onchange
```

**3. 禁用模式（forbidden_pattern）**

以下模式在 PPT 中表现异常：

| 模式 | 问题 | 替代方案 |
|------|------|----------|
| `rgba()` | 颜色无法识别 | `fill="#FFF" fill-opacity="0.1"` |
| `<g opacity="...">` | 组透明度不生效 | 每个子元素单独设置 `fill-opacity` / `stroke-opacity` |
| `<image opacity="...">` | 图片透明度不生效 | 遮罩层叠加方案 |
| `@font-face` | Web 字体不支持 | 使用系统字体栈 |
| `@import` | 外部 CSS 不支持 | 内联样式 |

**4. viewBox 一致性（viewbox_mismatch）**

检查 `<svg>` 标签的 `viewBox` 与 `width`/`height` 比例是否一致，不一致会导致 PPT 中比例变形。

### Step 3: 问题分级处理

#### Error 级（必须修复）

以下问题**必须修复**才能交付：

| 问题 | 修复方法 |
|------|----------|
| 禁用元素（clipPath、mask、foreignObject 等） | 删除或替换为兼容实现 |
| rgba() 颜色 | 替换为 HEX + opacity 属性 |
| `<g opacity>` | 将透明度设置到每个子元素 |
| `<image opacity>` | 使用遮罩层替代 |
| viewBox 不匹配 | 修正 viewBox 或 width/height |

#### Warning 级（建议修复）

以下问题建议修复但不阻塞交付：

| 问题 | 说明 |
|------|------|
| 禁用属性（class、id） | 不影响渲染但可能触发 PPT 安全警告 |
| marker-end | 箭头显示为普通元素 |

### Step 4: 修复检测到的问题

#### 修复 rgba() 颜色

```xml
<!-- 错误 -->
<rect fill="rgba(255,255,255,0.1)"/>

<!-- 正确 -->
<rect fill="#FFFFFF" fill-opacity="0.1"/>
```

#### 修复组透明度

```xml
<!-- 错误：组透明度不生效 -->
<g opacity="0.1">
  <circle cx="100" cy="100" r="50" fill="none" stroke="#FFF" stroke-width="1"/>
  <circle cx="100" cy="100" r="30" fill="none" stroke="#FFF" stroke-width="1"/>
</g>

<!-- 正确：每个元素单独设置 -->
<circle cx="100" cy="100" r="50" fill="none" stroke="#FFF" stroke-width="1" stroke-opacity="0.1"/>
<circle cx="100" cy="100" r="30" fill="none" stroke="#FFF" stroke-width="1" stroke-opacity="0.1"/>
```

#### 修复图片透明度

```xml
<!-- 错误：图片透明度不生效 -->
<image href="bg.png" width="1280" height="720" opacity="0.35"/>

<!-- 正确：使用遮罩层 -->
<image href="bg.png" width="1280" height="720"/>
<rect width="1280" height="720" fill="#2C3E50" opacity="0.65"/>
```

> 注意：原始图片 `opacity=0.35` 对应遮罩层 `opacity=0.65` (1 - 0.35)

### Step 5: 重新运行后处理和导出

修复问题后，必须重新执行后处理和导出：

```bash
# 修改 svg_output/ 中的原始 SVG（而非 svg_final/）
# （由 Claude Code 直接编辑 svg_output/ 中的文件）

# 重新执行后处理和导出
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize --step export
```

**验证修复**：

```bash
# 重新运行质量检查
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_final/
```

### Step 6: CRAP 视觉优化（可选）

> **触发条件**：用户要求优化视觉质量，或质量检查中发现以下问题：
> - 视觉层级不清晰（Contrast 不足）
> - 跨页风格不一致（Repetition 不足）
> - 元素对齐混乱（Alignment 问题）
> - 信息分组不合理（Proximity 问题）

#### 6.1 加载 CRAP 优化指南

读取 CRAP 优化参考文档（如存在）：

```
读取 $REFERENCE_DIR/styles/optimizer-crap.md
```

#### 6.2 四项 CRAP 原则检查

**C - Contrast（对比）**

检查项：
- 标题与正文差异是否明显（字号比 ≥ 1.5:1）
- 重要数据是否用不同颜色高亮
- 背景与前景对比是否清晰（对比度 ≥ 4.5:1）
- 尺寸层级是否分明

**R - Repetition（重复）**

检查项：
- 配色方案是否统一
- 字体使用是否一致
- 卡片样式是否相同
- 间距系统是否规律

**A - Alignment（对齐）**

检查项：
- 所有元素是否沿网格线对齐
- 标题对齐方式是否统一
- 文本对齐是否一致

**P - Proximity（亲密性）**

检查项：
- 相关元素是否靠近
- 不同组块是否分离
- 逻辑分组是否明确
- 空白使用是否合理

#### 6.3 执行优化

根据 CRAP 检查结果，修改 `svg_output/` 中的 SVG 文件，优化后重新运行 pipeline：

```bash
# 优化 SVG 文件（由 Claude Code 直接编辑 svg_output/ 中的文件）

# 重新后处理和导出
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize --step export

# 重新质量检查
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_final/
```

### Step 7: 最终验证

完成所有修复和优化后，执行最终验证：

```bash
# 1. SVG 质量门禁（必须全部通过）
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_final/

# 2. 验证文件完整性
echo "SVG 文件数: $(ls $PPT_DIR/svg_final/*.svg | wc -l)"
echo "备注文件数: $(ls $PPT_DIR/notes/*.md | wc -l)"
echo "PPTX 文件: $(ls $PPT_DIR/*.pptx)"
```

## 完成检查清单

全部 Phase 完成后的最终检查：

| 序号 | 检查项 | 状态 |
|------|--------|------|
| 1 | 源内容已转换为 Markdown | |
| 2 | 项目文件夹已创建 | |
| 3 | 模板选项已确认 | |
| 4 | 八项确认已完成 | |
| 5 | 设计规范已保存 | |
| 6 | 图片已就绪（如需要） | |
| 7 | SVG 文件已生成到 `svg_output/` | |
| 8 | 演讲备注已生成 `notes/total.md` | |
| 9 | 后处理已执行（`finalize_svg.py`） | |
| 10 | SVG 文件已处理到 `svg_final/` | |
| 11 | PPTX 已导出 | |
| 12 | 质量门禁检查通过 | |

---

## 常见问题

### Q: svg_lint.py 检测到大量 id/class 属性？

这些可能来自图标代码或模板残留。处理方式：
- `id` 属性：在 SVG 中无害但建议清理
- `class` 属性：检查是否实际被使用，未使用的可直接删除
- 若数量过多，可使用文本替换批量清理

### Q: 修复后 svg_lint.py 仍然报错？

可能原因：
1. 修复了 `svg_output/` 但没有重新运行 `finalize_svg.py`
2. 修复了 `svg_final/` 但下次 pipeline 会覆盖
3. 问题存在于多个文件中

正确流程：**始终修改 `svg_output/` 中的文件**，然后重新运行 pipeline。

### Q: CRAP 优化后效果不明显？

CRAP 优化主要关注宏观设计原则，微观调整（如颜色微调、间距调整）效果可能有限。若需要显著提升，考虑：
- 重新选择配色方案
- 调整字号层级比例
- 更换布局模式
