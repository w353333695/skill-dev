#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SVG rendering for PPTX template extraction — facade module.

Re-exports all public symbols from the split sub-modules.
Other modules (pptx_to_template.py, etc.) can continue to import from here unchanged.
"""

from _svg_constants import (
    MSO_TO_SCHEME, EMU_PER_PT, EMU_PER_PX,
    DEFAULT_INSET_L_R, DEFAULT_INSET_T_B,
    A_NS, P_NS, R_NS, qn,
    emu_to_px, emu_to_pt, escape_xml,
)
from _svg_color import (
    build_theme_color_map,
    _apply_lum_mod,
    resolve_color,
    resolve_solid_fill,
    resolve_fill_ref,
    _color_from_lstStyle,
    _resolve_font_size_from_styles,
    _collect_shape_colors,
)
from _svg_text import (
    _render_textbox_svg,
    _tspan_style_attrs,
)
from _svg_shapes import (
    _get_shape_fill,
    _get_shape_stroke,
    _geom_type,
    _get_layout_placeholder,
    _get_master_placeholder,
    _shape_position,
    _render_image_svg,
    shape_to_svg,
    _custgeom_to_svg_path,
    _arc_to_svg_path,
    _is_custgeom_ellipse,
    _build_coord_map,
    _group_to_svg,
)
from _svg_slide import (
    _is_framework_element,
    _collect_framework_svg,
    _get_bg_image_svg,
    _get_layout_bg_shapes,
    slide_to_svg,
    _iter_all_shapes,
    classify_slide,
    _extract_shape_details,
)
