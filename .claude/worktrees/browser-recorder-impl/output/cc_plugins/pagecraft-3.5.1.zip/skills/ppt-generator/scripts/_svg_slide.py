# -*- coding: utf-8 -*-
"""Slide-level rendering for PPTX → SVG conversion.

Handles complete slide-to-SVG conversion, background extraction,
layout/master shape inheritance, slide classification, and data extraction.
"""

import hashlib
from pathlib import Path

from _svg_constants import (
    A_NS, P_NS, R_NS, qn,
    EMU_PER_PX,
    emu_to_px, emu_to_pt, escape_xml,
)
from _svg_color import (
    resolve_color, _collect_shape_colors, _resolve_font_size_from_styles,
)
from _svg_shapes import (
    _get_shape_fill, _get_shape_stroke,
    _geom_type, _shape_position,
    _get_layout_placeholder, _get_master_placeholder,
    _build_coord_map,
    shape_to_svg,
)

def _is_framework_element(shape, canvas_h, canvas_w=1280):
    """判断 shape 是否属于内容页的固定框架（页眉/页脚/装饰），而非正文内容"""
    # 表格永远被视为正文内容，不做 framework 替换
    geom = _geom_type(shape)
    if geom == "TABLE":
        return False

    x, y, w, h = _shape_position(shape)
    # 页眉区域：顶部 120px 内的大宽度文本框（标题）
    if y <= 120 and w > canvas_w * 0.5:
        return True
    # 页脚区域：底部 80px 内
    if y >= canvas_h - 80:
        return True
    # 右侧竖排页脚/章节标识（x 在右侧 30% 区域，高度较小）
    if x > canvas_w * 0.7 and h < 60 and w < 800:
        return True
    # 小装饰元素（细线、小矩形等），位于边缘
    if h <= 4 and (y <= 120 or y >= canvas_h - 100):
        return True
    # 页码/章节标识类小 shape
    if w < 100 and h <= 45 and (y >= canvas_h - 80 or y <= 80):
        return True
    return False


def _collect_framework_svg(group_shape, theme_map, images_dir, image_hashes,
                           slide_index, total_slides, unresolved_list,
                           canvas_h, parent_coord_map=None,
                           content_bboxes=None):
    """从 group 中提取框架子 shape 的 SVG（跳过内容子 shape）

    content_bboxes: 若提供（一个 list），非框架子 shape 的 bbox 会被追加进去
    """
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    results = []
    try:
        children = list(group_shape.shapes)
    except Exception:
        return results

    coord_map = _build_coord_map(group_shape, parent_coord_map)

    for child in children:
        if child.shape_type == MSO_SHAPE_TYPE.GROUP:
            nested = _collect_framework_svg(
                child, theme_map, images_dir, image_hashes,
                slide_index, total_slides, unresolved_list,
                canvas_h, parent_coord_map=coord_map,
                content_bboxes=content_bboxes)
            results.extend(nested)
        elif _is_framework_element(child, canvas_h):
            svg = shape_to_svg(child, theme_map, images_dir, image_hashes,
                               slide_index, total_slides, unresolved_list,
                               coord_map=coord_map)
            if svg.strip():
                results.append(svg)
        else:
            # 非框架子 shape：记录其映射后的 bbox
            if content_bboxes is not None:
                cx, cy = coord_map(child.left, child.top)
                cw = round(emu_to_px(child.width) * coord_map.scale_x)
                ch = round(emu_to_px(child.height) * coord_map.scale_y)
                content_bboxes.append((cx, cy, cw, ch))
    return results


def _get_bg_image_svg(slide_or_layout, images_dir, image_hashes, canvas_w, canvas_h):
    """从 slide 或 layout 的 bgPr 中提取背景图片 → SVG <image> 元素

    PPTX 背景通过 <p:bg><p:bgPr><a:blipFill><a:blip r:embed="..."> 设置，
    与 layout shapes 中的 PICTURE 不同。返回 SVG 字符串或空字符串。
    """
    try:
        # 获取 cSld 元素
        if hasattr(slide_or_layout, '_element'):
            elem = slide_or_layout._element
        else:
            return ""
        csld = elem.find(qn('p:cSld'))
        if csld is None:
            return ""
        bg = csld.find(qn('p:bg'))
        if bg is None:
            return ""
        bgPr = bg.find(qn('p:bgPr'))
        if bgPr is None:
            return ""
        blipFill = bgPr.find(qn('a:blipFill'))
        if blipFill is None:
            return ""
        blip = blipFill.find(qn('a:blip'))
        if blip is None:
            return ""
        embed = blip.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed')
        if not embed:
            return ""

        # 通过关系找到图片文件
        import zipfile
        from pathlib import Path
        try:
            # 获取 pptx 文件路径
            prs_part = slide_or_layout.part
            prs_path = Path(str(prs_part.package._pkg_file))
        except Exception:
            return ""

        # 读取关系文件找到图片路径
        rels_path = None
        try:
            part_name = slide_or_layout.part.partname  # e.g. /ppt/slides/slide1.xml
            base_name = part_name.split('/')[-1]
            # slide 关系
            if hasattr(slide_or_layout, 'slide_layout'):
                rels_path = f"ppt/slides/_rels/{base_name}.rels"
            # layout 关系
            elif hasattr(slide_or_layout, 'slide_master'):
                rels_path = f"ppt/slideLayouts/_rels/{base_name}.rels"
            # master 关系
            elif hasattr(slide_or_layout, 'slide_layouts'):
                rels_path = f"ppt/slideMasters/_rels/{base_name}.rels"
        except Exception:
            pass

        if rels_path is None:
            return ""

        image_path = None
        try:
            with zipfile.ZipFile(str(prs_path), 'r') as zf:
                with zf.open(rels_path) as f:
                    from xml.etree import ElementTree as ET
                    tree = ET.parse(f)
                    root = tree.getroot()
                    ns = {'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
                    for rel in root.findall('.//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship'):
                        if rel.get('Id') == embed:
                            target = rel.get('Target')
                            # 相对路径转绝对路径
                            if target.startswith('../'):
                                target = target[3:]
                            elif target.startswith('/'):
                                target = target[1:]
                            else:
                                # 相对于当前目录
                                base = '/'.join(rels_path.split('/')[:-1])
                                target = base + '/' + target
                            image_path = 'ppt/' + target if not target.startswith('ppt/') else target
                            break
        except Exception:
            return ""

        if image_path is None:
            return ""

        # 提取图片 blob
        try:
            with zipfile.ZipFile(str(prs_path), 'r') as zf:
                with zf.open(image_path) as f:
                    blob = f.read()
        except Exception:
            return ""

        # 确定文件扩展名
        ext = image_path.split('.')[-1].lower()
        if ext == 'jpeg':
            ext = 'jpg'

        # hash 去重保存
        import hashlib
        h_hash = hashlib.sha256(blob).hexdigest()[:16]
        if h_hash in image_hashes:
            filename = image_hashes[h_hash]
        else:
            filename = f"{h_hash}.{ext}"
            dest = images_dir / filename
            with open(dest, "wb") as f:
                f.write(blob)
            image_hashes[h_hash] = filename

        return f'<image href="images/{filename}" x="0" y="0" width="{canvas_w}" height="{canvas_h}" preserveAspectRatio="none"/>'
    except Exception:
        return ""




def _get_layout_bg_shapes(slide, theme_map, images_dir, image_hashes,
                         slide_index, total_slides, unresolved_list, canvas_w, canvas_h):
    """从 slide layout 和 master 中提取非 placeholder 的背景/装饰 shapes。

    Layout 和 master 上的图片、自定义几何等装饰元素构成模板的「背景」，
    而 placeholder 会被 slide 自身的 placeholder 覆盖，所以跳过。
    """
    elements = []
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    def _collect_from_shape_tree(shapes):
        for shape in shapes:
            # 跳过 placeholder
            try:
                if shape.placeholder_format is not None:
                    continue
            except Exception:
                pass
            # 跳过空名称
            if not shape.name.strip():
                continue
            svg = shape_to_svg(shape, theme_map, images_dir, image_hashes,
                               slide_index, total_slides, unresolved_list)
            if svg.strip():
                elements.append(svg)

    # PPTX z-order: master (底层) → layout (中层) → slide (顶层)
    # 所以先收集 master，再收集 layout，确保 layout 元素覆盖 master

    # 1. 先提取背景图（bgPr）— 最底层
    # master 背景
    show_master = True
    try:
        show_master = slide._element.get("showMasterSp") != "0"
    except Exception:
        pass

    if show_master:
        try:
            master = slide.slide_layout.slide_master
            bg_svg = _get_bg_image_svg(master, images_dir, image_hashes, canvas_w, canvas_h)
            if bg_svg:
                elements.append(bg_svg)
        except Exception:
            pass

    # layout 背景（覆盖 master）
    try:
        layout = slide.slide_layout
        bg_svg = _get_bg_image_svg(layout, images_dir, image_hashes, canvas_w, canvas_h)
        if bg_svg:
            elements.append(bg_svg)
    except Exception:
        pass

    # slide 背景（覆盖 layout）
    try:
        bg_svg = _get_bg_image_svg(slide, images_dir, image_hashes, canvas_w, canvas_h)
        if bg_svg:
            elements.append(bg_svg)
    except Exception:
        pass

    # 2. 从 master shapes 收集装饰元素
    if show_master:
        try:
            master = slide.slide_layout.slide_master
            _collect_from_shape_tree(master.shapes)
        except Exception:
            pass

    # 3. 从 layout shapes 收集装饰元素
    try:
        layout = slide.slide_layout
        _collect_from_shape_tree(layout.shapes)
    except Exception:
        pass

    return elements




def slide_to_svg(slide, slide_index, total_slides, canvas_info,
                 theme_map, images_dir, image_hashes, unresolved_list,
                 content_framework=False):
    """单页 slide → 完整 SVG 文档

    content_framework: 对中间内容页，只保留固定框架（页眉/页脚/装饰），
                       正文区替换为 {{CONTENT_AREA}} 占位框
    """
    w = canvas_info["width"]
    h = canvas_info["height"]
    vb = canvas_info["viewBox"]

    elements = []

    # 先渲染 layout 上的背景/装饰 shapes（图片、几何等）作为底层
    layout_bg = _get_layout_bg_shapes(
        slide, theme_map, images_dir, image_hashes,
        slide_index, total_slides, unresolved_list, w, h)
    elements.extend(layout_bg)

    content_shapes = []  # 内容区 shape 的 bbox，用于计算 CONTENT_AREA
    for shape in slide.shapes:
        if content_framework and not _is_framework_element(shape, h):
            if _geom_type(shape) == "GROUP":
                # GROUP 递归拆分：保留框架元素，收集内容子 shape 的 bbox
                framework_parts = _collect_framework_svg(
                    shape, theme_map, images_dir, image_hashes,
                    slide_index, total_slides, unresolved_list, h,
                    content_bboxes=content_shapes)
                elements.extend(framework_parts)
            else:
                # 非 GROUP 的内容 shape：直接记录 bbox
                sx, sy, sw, sh = _shape_position(shape)
                content_shapes.append((sx, sy, sw, sh))
            continue
        svg_elem = shape_to_svg(shape, theme_map, images_dir, image_hashes,
                                 slide_index, total_slides, unresolved_list)
        if svg_elem.strip():
            elements.append(svg_elem)

    # 中间页：添加 {{CONTENT_AREA}} 占位框
    if content_framework and content_shapes:
        # 计算内容区包围盒
        min_x = min(s[0] for s in content_shapes)
        min_y = min(s[1] for s in content_shapes)
        max_x = max(s[0] + s[2] for s in content_shapes)
        max_y = max(s[1] + s[3] for s in content_shapes)
        # 留边距
        cx = max(0, min_x - 20)
        cy = max(100, min_y - 20)
        cw = min(w - cx, max_x - cx + 40)
        ch = min(h - cy - 60, max_y - cy + 40)
        # 确保合理尺寸
        if cw > 50 and ch > 50:
            elements.append(
                f'<rect x="{cx}" y="{cy}" width="{cw}" height="{ch}" '
                f'fill="none" stroke="#E2E8F0" stroke-width="1" stroke-dasharray="8,4"/>\n'
                f'<text x="{cx + cw/2}" y="{cy + ch/2}" text-anchor="middle" '
                f'fill="#CBD5E1" font-size="16">{{{{CONTENT_AREA}}}}</text>'
            )

    body = "\n".join(elements)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'xmlns:xlink="http://www.w3.org/1999/xlink" '
            f'viewBox="{vb}" width="{w}" height="{h}">\n'
            f'{body}\n'
            f'</svg>')


def _iter_all_shapes(shapes):
    """递归展平 shapes（含 group 内子 shape），yield 每个 leaf shape"""
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    for shape in shapes:
        yield shape
        try:
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                yield from _iter_all_shapes(shape.shapes)
        except Exception:
            pass



def classify_slide(slide, slide_index, total_slides, theme_map=None, canvas=None):
    """幻灯片类型识别 + 特征摘要"""
    slide_type = "unknown"
    if slide_index == 0:
        slide_type = "cover"
    elif slide_index == total_slides - 1:
        slide_type = "ending"

    shape_count = 0
    text_box_count = 0
    max_font_size = 0
    has_numbered_list = False
    has_image = False
    text_preview = []
    import re

    # 收集背景色候选（全幅矩形或第一个大面积 shape 的填充色）
    bg_color = None
    best_bg_area = 0
    if canvas:
        slide_area = canvas["width_emu"] * canvas["height_emu"]
    else:
        slide_area = 0  # 无画布信息时退化：取最大面积 shape

    for shape in _iter_all_shapes(slide.shapes):
        shape_count += 1
        # 检测背景色候选：面积 > 80% 画布的 shape（或无画布信息时取最大面积）
        try:
            area = int(shape.width) * int(shape.height)
            if slide_area > 0:
                threshold = slide_area * 0.8
            else:
                threshold = 0  # 无画布信息，任何有填充的 shape 都算候选
            if area > threshold:
                fill = _get_shape_fill(shape, theme_map or {})
                if fill:
                    if bg_color is None or area > best_bg_area:
                        # _get_shape_fill 返回 (hex, opacity) 元组，取 hex
                        bg_color = fill[0] if isinstance(fill, tuple) else fill
                        best_bg_area = area
        except Exception:
            pass

        if shape.has_text_frame:
            # 只统计有实际文本内容的文本框（避免空几何形状被计入）
            has_real_text = any(p.text.strip() for p in shape.text_frame.paragraphs)
            if has_real_text:
                text_box_count += 1
            for para in shape.text_frame.paragraphs:
                text = para.text.strip()
                if text:
                    text_preview.append(text)
                    if re.match(r'^\d+[\.\)、]', text):
                        has_numbered_list = True
                for run in para.runs:
                    fs = None
                    if run.font.size:
                        fs = emu_to_pt(run.font.size)
                    else:
                        # fallback 1: 从 XML 的 <a:rPr sz="..."> 读取
                        a_ns = "http://schemas.openxmlformats.org/drawingml/2006/main"
                        rPr_elem = run._r.find(f"{{{A_NS}}}rPr")
                        if rPr_elem is not None:
                            sz_attr = rPr_elem.get("sz")
                            if sz_attr:
                                fs = int(sz_attr) / 100
                        # fallback 2: 从 layout/master placeholder 的 lstStyle defRPr 读取
                        if fs is None:
                            for ph_shape in (_get_layout_placeholder(shape), _get_master_placeholder(shape)):
                                if ph_shape is not None and ph_shape.has_text_frame:
                                    ptxBody = ph_shape.element.find(qn("p:txBody"))
                                    if ptxBody is not None:
                                        plstStyle = ptxBody.find(qn("a:lstStyle"))
                                        if plstStyle is not None:
                                            lvl1 = plstStyle.find(f"{{{A_NS}}}lvl1pPr")
                                            if lvl1 is not None:
                                                defRPr = lvl1.find(f"{{{A_NS}}}defRPr")
                                                if defRPr is not None:
                                                    sz = defRPr.get("sz")
                                                    if sz:
                                                        fs = int(sz) / 100
                                                        break
                    if fs and fs > max_font_size:
                        max_font_size = fs
        try:
            if shape.shape_type in (13, 11):  # PICTURE, LINKED_PICTURE
                has_image = True
        except Exception:
            pass

    return {
        "slide_index": slide_index,
        "type": slide_type,
        "features": {
            "shape_count": shape_count,
            "text_box_count": text_box_count,
            "max_font_size_pt": round(max_font_size, 1),
            "has_numbered_list": has_numbered_list,
            "has_image": has_image,
            "text_preview": text_preview[:5],
            "dominant_bg_color": f"#{bg_color}" if bg_color else None,
        },
        "shapes": _extract_shape_details(slide, theme_map),
    }


def _extract_shape_details(slide, theme_map):
    """提取每页的 shape 级结构化数据（含 group 子 shape，坐标已映射为绝对坐标）"""
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    def _shape_info(shape, coord_map=None):
        """提取单个 shape 的结构化信息，coord_map 用于 group 子 shape 坐标映射"""
        if coord_map:
            x, y = coord_map(shape.left, shape.top)
            w = round(emu_to_px(shape.width) * coord_map.scale_x)
            h = round(emu_to_px(shape.height) * coord_map.scale_y)
        else:
            x = emu_to_px(shape.left)
            y = emu_to_px(shape.top)
            w = emu_to_px(shape.width)
            h = emu_to_px(shape.height)

        info = {
            "name": shape.name,
            "type": str(shape.shape_type).split(".")[-1] if hasattr(shape.shape_type, "name") else str(shape.shape_type),
            "position": {"x": x, "y": y, "w": w, "h": h},
        }
        fill = _get_shape_fill(shape, theme_map)
        if fill:
            if isinstance(fill, tuple):
                fill_color, fill_opacity = fill
                info["fill"] = f"#{fill_color}"
                if fill_opacity is not None:
                    info["fill_opacity"] = round(fill_opacity, 3)
            else:
                info["fill"] = f"#{fill}"
        stroke_color, stroke_w = _get_shape_stroke(shape, theme_map)
        if stroke_color:
            info["stroke"] = f"#{stroke_color}"
            info["stroke_width"] = stroke_w
        if shape.has_text_frame:
            text = shape.text_frame.text.strip()
            if text:
                info["text"] = text[:200]
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    font_info = {}
                    if run.font.size:
                        font_info["size_pt"] = emu_to_pt(run.font.size)
                    if run.font.name:
                        font_info["family"] = run.font.name
                    if run.font.bold:
                        font_info["bold"] = True
                    try:
                        if run.font.color and run.font.color.type is not None:
                            c = resolve_color(run.font.color, theme_map or {})
                            if c:
                                font_info["color"] = f"#{c}"
                    except Exception:
                        pass
                    if font_info:
                        info["font"] = font_info
                    break
        try:
            if shape.shape_type in (MSO_SHAPE_TYPE.PICTURE, MSO_SHAPE_TYPE.LINKED_PICTURE):
                info["image"] = True
                try:
                    import hashlib as _hashlib
                    blob = shape.image.blob
                    h_hash = _hashlib.md5(blob).hexdigest()[:12]
                    info["image_hash"] = h_hash
                except Exception:
                    pass
        except Exception:
            pass
        try:
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                info["group"] = True
                info["child_count"] = len(list(shape.shapes))
        except Exception:
            pass
        return info

    def _extract_recursive(shapes, coord_map=None):
        for shape in shapes:
            yield _shape_info(shape, coord_map)
            try:
                if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                    child_map = _build_coord_map(shape, parent_coord_map=coord_map)
                    yield from _extract_recursive(shape.shapes, child_map)
            except Exception:
                pass

    slide_shapes = list(_extract_recursive(slide.shapes))

    # 同时收集 layout 上的非 placeholder shapes（用于 design_spec 默认值提取）
    layout_shapes = []
    try:
        layout = slide.slide_layout
        for shape in layout.shapes:
            # 跳过 placeholder（会被 slide 上的覆盖）
            try:
                if shape.placeholder_format is not None:
                    continue
            except Exception:
                pass
            # 只收集有文本的 shape
            if shape.has_text_frame:
                text = shape.text_frame.text.strip()
                if text:
                    info = _shape_info(shape)
                    layout_shapes.append(info)
    except Exception:
        pass

    if layout_shapes:
        slide_shapes.extend(layout_shapes)

    return slide_shapes
