# -*- coding: utf-8 -*-
"""Shape rendering for PPTX → SVG conversion.

Handles fill/stroke extraction, geometry conversion (custGeom, arc, ellipse),
image rendering, group flattening, coordinate mapping, and the main shape dispatcher.
"""

import hashlib
from pathlib import Path

from _svg_constants import (
    A_NS, P_NS, R_NS, qn,
    EMU_PER_PX,
    DEFAULT_INSET_L_R, DEFAULT_INSET_T_B,
    emu_to_px, emu_to_pt, escape_xml,
)
from _svg_color import (
    _apply_lum_mod, resolve_color, resolve_solid_fill, resolve_fill_ref,
)

def _get_shape_fill(shape, theme_map, unresolved_entry=None):
    """提取形状填充色 → (hex_rgb, opacity)，None 表示无填充

    unresolved_entry: 若提供（一个 dict），检测到非纯色填充时会记录告警信息
    """
    p_ns = "http://schemas.openxmlformats.org/presentationml/2006/main"

    sp = shape.element
    spPr = sp.find(f"./{{{p_ns}}}spPr")
    if spPr is None:
        spPr = sp.find(f"./{{{A_NS}}}spPr")
    if spPr is None:
        spPr = sp

    solid = spPr.find(f"./{{{A_NS}}}solidFill")
    grad = spPr.find(f"./{{{A_NS}}}gradFill")
    noFill = spPr.find(f"./{{{A_NS}}}noFill")

    # 无填充
    if noFill is not None and solid is None and grad is None:
        # 检查 style 中是否有 fillRef（PPT 默认样式引用）
        style = sp.find(f"./{{{p_ns}}}style")
        if style is not None:
            fillRef = style.find(f"./{{{A_NS}}}fillRef")
            if fillRef is not None:
                idx = fillRef.get("idx")
                if idx and int(idx) > 0:
                    schemeClr = fillRef.find(f"./{{{A_NS}}}schemeClr")
                    srgbClr = fillRef.find(f"./{{{A_NS}}}srgbClr")
                    if schemeClr is not None:
                        scheme_val = schemeClr.get("val")
                        if scheme_val and theme_map:
                            return theme_map.get(scheme_val), None
                    if srgbClr is not None:
                        return srgbClr.get("val"), None
        return None

    # 渐变填充：用第一个色标作为 fallback 色
    if grad is not None and solid is None:
        gsLst = grad.find(f"./{{{A_NS}}}gsLst")
        fallback = "CCCCCC"
        if gsLst is not None:
            stops = gsLst.findall(f"./{{{A_NS}}}gs")
            if stops:
                srgbClr = stops[0].find(f".//{{{A_NS}}}srgbClr")
                if srgbClr is not None:
                    fallback = srgbClr.get("val", "CCCCCC")
        if unresolved_entry is not None:
            unresolved_entry["fill_type"] = "gradient"
            unresolved_entry["fill_note"] = f"渐变填充，fallback 使用第一个色标 #{fallback}"
        return fallback, None

    # 纯色填充：用 python-pptx API（处理 schemeClr 等）
    try:
        fill = shape.fill
        if fill.type is None:
            # fill.type 为 None 时，尝试从 style 的 fillRef 读取
            style = sp.find(f"./{{{p_ns}}}style")
            if style is not None:
                fillRef = style.find(f"./{{{A_NS}}}fillRef")
                if fillRef is not None:
                    idx = fillRef.get("idx")
                    if idx and int(idx) > 0:
                        schemeClr = fillRef.find(f"./{{{A_NS}}}schemeClr")
                        srgbClr = fillRef.find(f"./{{{A_NS}}}srgbClr")
                        if schemeClr is not None:
                            scheme_val = schemeClr.get("val")
                            if scheme_val and theme_map:
                                return theme_map.get(scheme_val), None
                        if srgbClr is not None:
                            return srgbClr.get("val"), None
            return None
        fore = fill.fore_color
        rgb = resolve_color(fore, theme_map)
        if rgb is None:
            return None

        # 从 XML 读取 alpha 值（srgbClr 或 schemeClr 下的 a:alpha）
        alpha_val = None
        if solid is not None:
            srgb = solid.find(f"./{{{A_NS}}}srgbClr")
            scheme = solid.find(f"./{{{A_NS}}}schemeClr")
            if srgb is not None:
                alpha = srgb.find(f"./{{{A_NS}}}alpha")
                if alpha is not None:
                    alpha_val = alpha.get("val")
            elif scheme is not None:
                alpha = scheme.find(f"./{{{A_NS}}}alpha")
                if alpha is not None:
                    alpha_val = alpha.get("val")

        opacity = None
        if alpha_val is not None:
            try:
                opacity = int(alpha_val) / 100000
            except ValueError:
                pass

        return rgb, opacity
    except Exception:
        return None


def _get_shape_stroke(shape, theme_map):
    """提取形状线条 → (color_hex, width_px)，color=None 表示无线条"""
    try:
        line = shape.line
        if line.fill.type is None:
            return None, 0

        # 优先从 XML 直接读取（gradFill/solidFill 等 API 无法解析的情况）
        from pptx.oxml.ns import qn
        sp = shape.element
        spPr = sp.find(qn("p:spPr"))
        if spPr is not None:
            ln = spPr.find(qn("a:ln"))
            if ln is not None:
                # 检查 gradFill：用第一个色标作为 fallback 色
                gradFill = ln.find(qn("a:gradFill"))
                if gradFill is not None:
                    gsLst = gradFill.find(qn("a:gsLst"))
                    if gsLst is not None:
                        stops = gsLst.findall(qn("a:gs"))
                        if stops:
                            srgbClr = stops[0].find(qn("a:srgbClr"))
                            if srgbClr is not None:
                                color = srgbClr.get("val")
                                w = ln.get("w", "12700")
                                width_px = max(emu_to_px(int(w)), 1)
                                return color, width_px
                # 检查 solidFill
                solidFill = ln.find(qn("a:solidFill"))
                if solidFill is not None:
                    srgbClr = solidFill.find(qn("a:srgbClr"))
                    if srgbClr is not None:
                        color = srgbClr.get("val")
                        w = ln.get("w", "12700")
                        width_px = max(emu_to_px(int(w)), 1)
                        return color, width_px
                    # 检查 schemeClr（含 lumMod）
                    schemeClr = solidFill.find(qn("a:schemeClr"))
                    if schemeClr is not None:
                        scheme_val = schemeClr.get("val", "")
                        color = theme_map.get(scheme_val)
                        if color:
                            lumMod = schemeClr.find(qn("a:lumMod"))
                            if lumMod is not None:
                                color = _apply_lum_mod(color, lumMod.get("val", "100000"))
                        w = ln.get("w", "12700")
                        width_px = max(emu_to_px(int(w)), 1)
                        return color, width_px

        # API 解析
        try:
            fore = line.color
            color = resolve_color(fore, theme_map)
        except Exception:
            color = None
        width_px = emu_to_px(line.width) if line.width else 1
        return color, max(width_px, 1)
    except Exception:
        return None, 0


def _geom_type(shape):
    """获取 shape 的几何类型字符串"""
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    st = shape.shape_type

    if st == MSO_SHAPE_TYPE.TEXT_BOX:
        return "TEXT_BOX"
    if st == MSO_SHAPE_TYPE.PICTURE or st == MSO_SHAPE_TYPE.LINKED_PICTURE:
        return "PICTURE"
    if st == MSO_SHAPE_TYPE.GROUP:
        return "GROUP"
    if st == MSO_SHAPE_TYPE.LINE:
        return "line"
    if st == MSO_SHAPE_TYPE.TABLE:
        return "TABLE"
    if st == MSO_SHAPE_TYPE.PLACEHOLDER:
        # placeholder may contain text or image
        if shape.has_text_frame:
            return "TEXT_BOX"
        # 检查是否有图片（pic placeholder 有 blipFill）
        try:
            from pptx.oxml.ns import qn
            sp = shape.element
            blipFill = sp.find(qn("p:blipFill"))
            if blipFill is not None:
                blip = blipFill.find(qn("a:blip"))
                if blip is not None:
                    return "PICTURE"
        except Exception:
            pass
        return "PLACEHOLDER"

    # AUTO_SHAPE, FREEFORM, etc — check geometry
    try:
        from pptx.oxml.ns import qn
        sp = shape.element
        spPr = sp.find(qn("p:spPr"))
        if spPr is None:
            spPr = sp
        prstGeom = spPr.find(qn("a:prstGeom"))
        if prstGeom is not None:
            return prstGeom.get("prst", "unknown")
        custGeom = spPr.find(qn("a:custGeom"))
        if custGeom is not None:
            return "custom"
    except Exception:
        pass

    return "unknown"


def _get_layout_placeholder(shape):
    """从 slide layout 上找到与当前 placeholder 匹配的 layout shape（按 idx）

    返回 layout shape 对象，或 None（非 placeholder / 找不到匹配）
    """
    try:
        ph_idx = shape.placeholder_format.idx
    except Exception:
        return None

    try:
        shapes = shape._parent
        slide = shapes.parent
        layout = slide.slide_layout
    except Exception:
        return None

    for lshape in layout.shapes:
        try:
            if lshape.placeholder_format.idx == ph_idx:
                return lshape
        except Exception:
            pass
    return None




def _get_master_placeholder(shape):
    """从 slide master 上找到与当前 placeholder 匹配的 master shape（按 type）

    Master 和 slide/layout 的 placeholder idx 可能不同，但 type 一致。
    返回 master shape 对象，或 None（非 placeholder / 找不到匹配）
    """
    try:
        ph_type = shape.placeholder_format.type
    except Exception:
        return None

    try:
        shapes = shape._parent
        slide = shapes.parent
        master = slide.slide_layout.slide_master
    except Exception:
        return None

    for mshape in master.shapes:
        try:
            if mshape.is_placeholder and mshape.placeholder_format.type == ph_type:
                return mshape
        except Exception:
            pass
    return None




def _shape_position(shape):
    """获取 shape 位置和尺寸 (x, y, w, h) in px

    placeholder 若无自己的 xfrm，从 layout 继承
    """

    sp = shape.element
    spPr = sp.find(qn("p:spPr"))
    has_xfrm = False
    if spPr is not None:
        has_xfrm = spPr.find(qn("a:xfrm")) is not None

    if not has_xfrm:
        # 尝试从 layout placeholder 继承位置
        lph = _get_layout_placeholder(shape)
        if lph is not None:
            return (
                emu_to_px(lph.left),
                emu_to_px(lph.top),
                emu_to_px(lph.width),
                emu_to_px(lph.height),
            )

    return (
        emu_to_px(shape.left),
        emu_to_px(shape.top),
        emu_to_px(shape.width),
        emu_to_px(shape.height),
    )




def _render_image_svg(shape, images_dir, image_hashes, clip_ellipse=None):
    """图片 → SVG <image> 元素，返回 (svg_string, filename)"""
    x, y, w, h = _shape_position(shape)

    try:
        image = shape.image
        blob = image.blob
        content_type = image.content_type
    except Exception:
        return "", None

    ext = content_type.split("/")[-1]
    if ext == "jpeg":
        ext = "jpg"

    # hash 去重
    import hashlib
    h_hash = hashlib.sha256(blob).hexdigest()[:16]
    if h_hash in image_hashes:
        filename = image_hashes[h_hash]
    else:
        filename = f"{h_hash}.{ext}"
        dest = Path(images_dir) / filename
        with open(dest, "wb") as f:
            f.write(blob)
        image_hashes[h_hash] = filename

    # 裁剪信息：crop 值是 0~1 的比例，表示被裁掉的部分
    try:
        cl = shape.crop_left or 0
        ct = shape.crop_top or 0
        cr = shape.crop_right or 0
        cb = shape.crop_bottom or 0
    except Exception:
        cl = ct = cr = cb = 0

    # 检测旋转
    rot_deg = 0
    try:
        from pptx.oxml.ns import qn
        sp = shape.element
        spPr = sp.find(qn("p:spPr"))
        if spPr is not None:
            xfrm = spPr.find(qn("a:xfrm"))
            if xfrm is not None:
                rot = xfrm.get("rot")
                if rot:
                    rot_deg = int(rot) / 60000
    except Exception:
        pass

    # 检测灰度 / 效果
    has_grayscale = False
    try:
        from pptx.oxml.ns import qn
        sp = shape.element
        blip = sp.find(f".//{qn('a:blip')}")
        if blip is not None:
            grayscl = blip.find(qn("a:grayscl"))
            if grayscl is not None:
                has_grayscale = True
    except Exception:
        pass

    # 构建样式属性
    style_attr = ""
    if has_grayscale:
        style_attr = ' style="filter: grayscale(1)"'

    # 构建 transform 属性（旋转）
    transform_attr = ""
    if rot_deg != 0:
        cx = x + w / 2
        cy = y + h / 2
        transform_attr = f' transform="rotate({rot_deg:.1f} {cx:.1f} {cy:.1f})"'

    # 检测是否有 prstGeom（如 ellipse 裁剪）
    has_prst_geom = False
    prst_type = None
    try:
        from pptx.oxml.ns import qn
        sp = shape.element
        spPr = sp.find(qn("p:spPr"))
        if spPr is not None:
            prstGeom = spPr.find(qn("a:prstGeom"))
            if prstGeom is not None:
                has_prst_geom = True
                prst_type = prstGeom.get("prst", "")
    except Exception:
        pass

    # 构建 clipPath（用于 prstGeom 裁剪）
    clip_def = ""
    clip_attr = ""
    if has_prst_geom and prst_type in ("ellipse", "rect"):
        import hashlib
        clip_id = "clip_" + hashlib.md5(f"{x}_{y}_{w}_{h}_{prst_type}".encode()).hexdigest()[:8]
        if prst_type == "ellipse":
            # 优先使用传入的 clip_ellipse（group 中其他椭圆的位置）
            if clip_ellipse:
                cx_c, cy_c, rx_c, ry_c = clip_ellipse
            else:
                cx_c = x + w / 2
                cy_c = y + h / 2
                rx_c = w / 2
                ry_c = h / 2
            clip_def = (
                f'<clipPath id="{clip_id}">'
                f'<ellipse cx="{cx_c}" cy="{cy_c}" rx="{rx_c}" ry="{ry_c}"/>'
                f'</clipPath>'
            )
        elif prst_type == "rect":
            clip_def = (
                f'<clipPath id="{clip_id}">'
                f'<rect x="{x}" y="{y}" width="{w}" height="{h}"/>'
                f'</clipPath>'
            )
        clip_attr = f' clip-path="url(#{clip_id})"'

    if any(v > 0 for v in [cl, ct, cr, cb]):
        visible_w_ratio = max(1 - cl - cr, 0.001)
        visible_h_ratio = max(1 - ct - cb, 0.001)
        img_x = -cl * w / visible_w_ratio
        img_y = -ct * h / visible_h_ratio
        img_w = w / visible_w_ratio
        img_h = h / visible_h_ratio

        if clip_attr:
            # 有裁剪：使用 clipPath，不需要 svg 包裹
            img_tag = (
                f'<image href="../images/{filename}" x="{x + img_x:.1f}" y="{y + img_y:.1f}" '
                f'width="{img_w:.1f}" height="{img_h:.1f}" '
                f'preserveAspectRatio="none"{style_attr}{clip_attr}/>'
            )
            if transform_attr:
                cx_t = x + w / 2
                cy_t = y + h / 2
                svg = clip_def + f'<g{transform_attr}\n{img_tag}\n</g>'
            else:
                svg = clip_def + img_tag
        else:
            svg = (
                f'<svg x="{x}" y="{y}" width="{w}" height="{h}"{transform_attr}>'
                f'\n<image href="../images/{filename}" x="{img_x:.1f}" '
                f'y="{img_y:.1f}" '
                f'width="{img_w:.1f}" height="{img_h:.1f}" '
                f'preserveAspectRatio="none"{style_attr}/>'
                f'\n</svg>'
            )
    else:
        img_tag = (f'<image href="../images/{filename}" x="{x}" y="{y}" '
                   f'width="{w}" height="{h}"{style_attr}{clip_attr}/>')
        if transform_attr:
            # 旋转需要包裹在 g 中（image 本身不支持 transform 属性）
            cx = x + w / 2
            cy = y + h / 2
            svg = clip_def + f'<g transform="rotate({rot_deg:.1f} {cx:.1f} {cy:.1f})">\n{img_tag}\n</g>'
        else:
            svg = clip_def + img_tag

    return svg, filename


def shape_to_svg(shape, theme_map, images_dir, image_hashes,
                 slide_index, total_slides, unresolved_list, coord_map=None,
                 clip_ellipse=None):
    """单个 shape → SVG 元素字符串

    coord_map: 可选的坐标映射函数 (emu_x, emu_y) -> (px_x, px_y)，
               用于 group 内子 shape 的坐标转换
    clip_ellipse: 可选的椭圆裁剪区域 (cx, cy, rx, ry)，用于图片裁剪
    """
    geom = _geom_type(shape)
    x, y, w, h = _shape_position(shape)

    # group 内的子 shape：临时将映射后的坐标写回 shape，
    # 这样所有子函数（textbox/image 等）内部读 _shape_position 也能拿到正确值
    # 但 GROUP shape 不改写（_group_to_svg 自己处理映射，且需要读取原始 XML）
    restored = False
    if coord_map and geom != "GROUP":
        orig_left, orig_top, orig_width, orig_height = (
            shape.left, shape.top, shape.width, shape.height
        )
        x, y = coord_map(orig_left, orig_top)
        w = round(emu_to_px(orig_width) * coord_map.scale_x)
        h = round(emu_to_px(orig_height) * coord_map.scale_y)
        shape.left = int(x * EMU_PER_PX)
        shape.top = int(y * EMU_PER_PX)
        shape.width = int(w * EMU_PER_PX)
        shape.height = int(h * EMU_PER_PX)
        restored = True

    try:
        # 无尺寸的 shape 跳过（线条允许 w 或 h 为 0）
        if w <= 0 and h <= 0:
            return ""

        # 文本框
        if geom == "TEXT_BOX":
            from _svg_text import _render_textbox_svg
            return _render_textbox_svg(shape, slide_index, total_slides, theme_map)

        # 图片
        if geom == "PICTURE":
            svg, _ = _render_image_svg(shape, images_dir, image_hashes, clip_ellipse=clip_ellipse)
            return svg

        # Group — 递归展平
        if geom == "GROUP":
            return _group_to_svg(shape, theme_map, images_dir, image_hashes,
                                 slide_index, total_slides, unresolved_list,
                                 parent_coord_map=coord_map)

        # 表格 — 用虚线框占位，并标记为 TABLE 以便后续识别
        if geom == "TABLE":
            fill = _get_shape_fill(shape, theme_map) or "CCCCCC"
            if isinstance(fill, tuple):
                fill = fill[0] if fill[0] else "CCCCCC"
            return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" '
                    f'fill="#{fill}" opacity="0.3" stroke="#999999" stroke-dasharray="4"/>')

        # 线条 — 用 begin/end 坐标保证方向正确
        if geom == "line":
            stroke_color, stroke_w = _get_shape_stroke(shape, theme_map)
            if stroke_color is None:
                stroke_color = "000000"
            if stroke_w < 1:
                stroke_w = 1
            try:
                bx, by = shape.begin_x, shape.begin_y
                ex, ey = shape.end_x, shape.end_y
                if coord_map:
                    x1, y1 = coord_map(bx, by)
                    x2, y2 = coord_map(ex, ey)
                else:
                    x1, y1 = emu_to_px(bx), emu_to_px(by)
                    x2, y2 = emu_to_px(ex), emu_to_px(ey)
            except Exception:
                x1, y1, x2, y2 = x, y, x + w, y + h
            return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
                    f'stroke="#{stroke_color}" stroke-width="{stroke_w}"/>')

        # 基础几何
        fill_unresolved = {}
        fill_result = _get_shape_fill(shape, theme_map, unresolved_entry=fill_unresolved)
        if fill_result is None:
            fill_color = None
            fill_opacity = None
        else:
            fill_color, fill_opacity = fill_result
        stroke_color, stroke_w = _get_shape_stroke(shape, theme_map)

        if fill_unresolved:
            xml_snippet = ""
            try:
                from lxml import etree
                xml_snippet = etree.tostring(shape.element, encoding="unicode")[:500]
            except Exception:
                pass
            unresolved_list.append({
                "slide_index": slide_index,
                "shape_name": shape.name,
                "position": {"x": x, "y": y, "w": w, "h": h},
                "fill_type": fill_unresolved.get("fill_type", "unknown"),
                "fill_color": f"#{fill_color}" if fill_color else None,
                "original_xml_snippet": xml_snippet,
                "note": fill_unresolved.get("fill_note", "非纯色填充，已用 fallback 色替代"),
            })

        opacity_attr = ""
        if fill_opacity is not None and fill_opacity < 1.0:
            opacity_attr = f' opacity="{fill_opacity:.3f}"'

        fill_attr = f' fill="#{fill_color}"' if fill_color else ' fill="none"'
        stroke_attr = ""
        if stroke_color:
            stroke_attr = f' stroke="#{stroke_color}" stroke-width="{stroke_w}"'

        # 检查旋转
        rot_attr = ""
        try:
            from pptx.oxml.ns import qn
            sp = shape.element
            spPr = sp.find(qn("p:spPr"))
            if spPr is not None:
                xfrm = spPr.find(qn("a:xfrm"))
                if xfrm is not None:
                    rot = xfrm.get("rot")
                    if rot:
                        # PPT rot 单位：1/60000 度
                        deg = int(rot) / 60000
                        cx = x + w / 2
                        cy = y + h / 2
                        rot_attr = f' transform="rotate({deg:.1f} {cx:.1f} {cy:.1f})"'
        except Exception:
            pass

        # 解析阴影效果
        shadow_filter = ""
        shadow_filter_id = None
        try:
            from pptx.oxml.ns import qn
            sp = shape.element
            spPr = sp.find(qn("p:spPr"))
            if spPr is not None:
                effectLst = spPr.find(qn("a:effectLst"))
                if effectLst is not None:
                    outerShdw = effectLst.find(qn("a:outerShdw"))
                    if outerShdw is not None:
                        blurRad = int(outerShdw.get("blurRad", "0")) / 12700  # EMU to pt
                        algn = outerShdw.get("algn", "ctr")
                        # 颜色
                        prstClr = outerShdw.find(qn("a:prstClr"))
                        srgbClr = outerShdw.find(qn("a:srgbClr"))
                        schemeClr = outerShdw.find(qn("a:schemeClr"))
                        shdw_color = "000000"
                        shdw_alpha = 1.0
                        if prstClr is not None:
                            shdw_color = prstClr.get("val", "000000")
                            if shdw_color == "black":
                                shdw_color = "000000"
                            elif shdw_color == "white":
                                shdw_color = "FFFFFF"
                        elif srgbClr is not None:
                            shdw_color = srgbClr.get("val", "000000")
                        elif schemeClr is not None:
                            scheme_val = schemeClr.get("val")
                            if scheme_val and theme_map:
                                shdw_color = theme_map.get(scheme_val, "000000")
                        # alpha
                        alpha_elem = None
                        if prstClr is not None:
                            alpha_elem = prstClr.find(qn("a:alpha"))
                        elif srgbClr is not None:
                            alpha_elem = srgbClr.find(qn("a:alpha"))
                        elif schemeClr is not None:
                            alpha_elem = schemeClr.find(qn("a:alpha"))
                        if alpha_elem is not None:
                            alpha_val = alpha_elem.get("val")
                            if alpha_val:
                                shdw_alpha = int(alpha_val) / 100000
                        # 生成唯一 filter id
                        import hashlib
                        shdw_key = f"{shdw_color}_{shdw_alpha:.3f}_{blurRad:.1f}_{algn}"
                        shadow_filter_id = "shdw_" + hashlib.md5(shdw_key.encode()).hexdigest()[:8]
                        # 计算偏移（基于对齐）
                        dx, dy = 0, 0
                        if algn == "ctr":
                            dx, dy = 0, 0
                        elif algn == "tl":
                            dx, dy = -blurRad, -blurRad
                        elif algn == "tr":
                            dx, dy = blurRad, -blurRad
                        elif algn == "bl":
                            dx, dy = -blurRad, blurRad
                        elif algn == "br":
                            dx, dy = blurRad, blurRad
                        shadow_filter = (
                            f'<filter id="{shadow_filter_id}" x="-50%" y="-50%" width="200%" height="200%">'
                            f'<feGaussianBlur in="SourceAlpha" stdDeviation="{blurRad:.1f}"/>'
                            f'<feOffset dx="{dx:.1f}" dy="{dy:.1f}" result="offsetblur"/>'
                            f'<feComponentTransfer>'
                            f'<feFuncA type="linear" slope="{shdw_alpha:.3f}"/>'
                            f'</feComponentTransfer>'
                            f'<feMerge>'
                            f'<feMergeNode/>'
                            f'<feMergeNode in="SourceGraphic"/>'
                            f'</feMerge>'
                            f'</filter>'
                        )
        except Exception:
            pass

        # 如果 shape 有文本，同时渲染文本
        text_svg = ""
        if shape.has_text_frame and shape.text_frame.text.strip():
            from _svg_text import _render_textbox_svg
            text_svg = _render_textbox_svg(shape, slide_index, total_slides, theme_map)

        filter_attr = f' filter="url(#{shadow_filter_id})"' if shadow_filter_id else ""
        filter_def = shadow_filter if shadow_filter else ""

        if geom == "rect":
            svg = f'<rect x="{x}" y="{y}" width="{w}" height="{h}"{fill_attr}{stroke_attr}{opacity_attr}{rot_attr}{filter_attr}/>' + text_svg
            return filter_def + svg if filter_def else svg
        elif geom == "roundRect":
            try:
                from pptx.oxml.ns import qn
                sp = shape.element
                avLst = sp.find(f".//{qn('a:avLst')}")
                rx = h // 4  # default
                if avLst is not None:
                    for gd in avLst.findall(qn("a:gd")):
                        name = gd.get("name", "")
                        if "adj" in name:
                            fmla = gd.get("fmla", "val 25000")
                            try:
                                val = int(fmla.split()[-1]) / 100000
                                rx = round(w * val)
                            except (ValueError, IndexError):
                                pass
                            break
            except Exception:
                rx = h // 4
            svg = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}"{fill_attr}{stroke_attr}{opacity_attr}{filter_attr}/>' + text_svg
            return filter_def + svg if filter_def else svg
        elif geom == "ellipse":
            cx = x + w / 2
            cy = y + h / 2
            svg = f'<ellipse cx="{cx}" cy="{cy}" rx="{w/2}" ry="{h/2}"{fill_attr}{stroke_attr}{opacity_attr}{rot_attr}{filter_attr}/>' + text_svg
            return filter_def + svg if filter_def else svg
        elif geom == "arc":
            path_d = _arc_to_svg_path(shape, x, y, w, h)
            if path_d:
                svg = f'<path d="{path_d}"{fill_attr}{stroke_attr}{opacity_attr}{rot_attr}{filter_attr}/>' + text_svg
                return filter_def + svg if filter_def else svg
            # fallback to ellipse outline
            cx = x + w / 2
            cy = y + h / 2
            svg = f'<ellipse cx="{cx}" cy="{cy}" rx="{w/2}" ry="{h/2}" fill="none"{stroke_attr}{opacity_attr}{rot_attr}{filter_attr}/>' + text_svg
            return filter_def + svg if filter_def else svg
        elif geom == "custom":
            # 尝试将 custGeom 转换为 SVG <path>
            path_d = _custgeom_to_svg_path(shape, x, y)
            if path_d:
                svg = f'<path d="{path_d}"{fill_attr}{stroke_attr}{opacity_attr}{rot_attr}{filter_attr}/>' + text_svg
                return filter_def + svg if filter_def else svg
            # 否则 fallback 到 rect 占位
            placeholder_fill = fill_color or "999999"
            svg = (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" '
                   f'fill="#{placeholder_fill}" stroke="#999999" stroke-dasharray="4" opacity="0.5"/>')

            xml_snippet = ""
            try:
                from lxml import etree
                xml_snippet = etree.tostring(shape.element, encoding="unicode")[:500]
            except Exception:
                pass

            unresolved_list.append({
                "slide_index": slide_index,
                "shape_name": shape.name,
                "geom_type": geom,
                "position": {"x": x, "y": y, "w": w, "h": h},
                "fill_color": f"#{fill_color}" if fill_color else None,
                "placeholder_svg": svg,
                "original_xml_snippet": xml_snippet,
                "note": f"Unsupported custom geometry, replaced with dashed rect placeholder",
            })
            return svg
        else:
            # 未支持的几何类型 → rect 占位 + 记录 unresolved
            placeholder_fill = fill_color or "999999"
            svg = (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" '
                   f'fill="#{placeholder_fill}" stroke="#999999" stroke-dasharray="4" opacity="0.5"/>')

            xml_snippet = ""
            try:
                from lxml import etree
                xml_snippet = etree.tostring(shape.element, encoding="unicode")[:500]
            except Exception:
                pass

            unresolved_list.append({
                "slide_index": slide_index,
                "shape_name": shape.name,
                "geom_type": geom,
                "position": {"x": x, "y": y, "w": w, "h": h},
                "fill_color": f"#{fill_color}" if fill_color else None,
                "placeholder_svg": svg,
                "original_xml_snippet": xml_snippet,
                "note": f"Unsupported geometry: {geom}, replaced with dashed rect placeholder",
            })
            return svg
    finally:
        if restored:
            shape.left, shape.top = orig_left, orig_top
            shape.width, shape.height = orig_width, orig_height


def _custgeom_to_svg_path(shape, offset_x=0, offset_y=0):
    """将 custGeom 自定义几何路径转换为 SVG path 数据字符串。

    支持 moveTo、lnTo、cubicBezTo、close 命令。
    坐标从 EMU 转换为 px，并加上 shape 的偏移量。
    返回 path d 属性字符串，解析失败返回 None。
    """
    try:
        from pptx.oxml.ns import qn

        sp = shape.element
        spPr = sp.find(qn("p:spPr"))
        if spPr is None:
            spPr = sp
        custGeom = spPr.find(qn("a:custGeom"))
        if custGeom is None:
            return None

        pathLst = custGeom.find(qn("a:pathLst"))
        if pathLst is None:
            return None

        def _to_px(v):
            return v / 914400 * 96

        # 优先使用传入的 offset（group 内子 shape 已做坐标映射）
        if offset_x != 0 or offset_y != 0:
            off_x_px = offset_x
            off_y_px = offset_y
        else:
            # 从 XML 读取 xfrm 偏移并转换为 px
            xfrm = spPr.find(qn("a:xfrm"))
            if xfrm is not None:
                off = xfrm.find(qn("a:off"))
                if off is not None:
                    off_x_px = _to_px(int(off.get("x", "0")))
                    off_y_px = _to_px(int(off.get("y", "0")))
                else:
                    off_x_px, off_y_px = 0, 0
            else:
                off_x_px, off_y_px = 0, 0

        # custGeom path 坐标是相对于 path@w/path@h 的，需要按 xfrm/ext 缩放
        # 读取 shape 的 xfrm 尺寸（EMU）
        xfrm = spPr.find(qn("a:xfrm"))
        ext_cx, ext_cy = 1, 1
        if xfrm is not None:
            ext = xfrm.find(qn("a:ext"))
            if ext is not None:
                ext_cx = int(ext.get("cx", "1"))
                ext_cy = int(ext.get("cy", "1"))

        parts = []
        for path in pathLst.findall(qn("a:path")):
            pw = int(path.get("w", "1"))
            ph = int(path.get("h", "1"))
            scale_x = ext_cx / pw if pw > 0 else 1
            scale_y = ext_cy / ph if ph > 0 else 1

            # 先遍历一遍计算 path 的实际边界框
            min_x = min_y = float('inf')
            max_x = max_y = float('-inf')
            path_pts = []  # 缓存所有点坐标
            for child in path:
                tag = child.tag.split("}")[-1]
                if tag in ("moveTo", "lnTo"):
                    pt = child.find(qn("a:pt"))
                    if pt is not None:
                        px = int(pt.get("x", "0"))
                        py = int(pt.get("y", "0"))
                        path_pts.append((tag, px, py))
                        min_x = min(min_x, px)
                        min_y = min(min_y, py)
                        max_x = max(max_x, px)
                        max_y = max(max_y, py)
                elif tag == "cubicBezTo":
                    pts = child.findall(qn("a:pt"))
                    if len(pts) == 3:
                        coords = []
                        for pt in pts:
                            px = int(pt.get("x", "0"))
                            py = int(pt.get("y", "0"))
                            coords.append((px, py))
                            min_x = min(min_x, px)
                            min_y = min(min_y, py)
                            max_x = max(max_x, px)
                            max_y = max(max_y, py)
                        path_pts.append((tag, coords))
                elif tag == "close":
                    path_pts.append((tag,))

            # 计算偏移调整：使 path 实际边界框中心与 shape 中心对齐
            # path@w/path@h 的中心对应 shape 的 ext 中心
            # 但实际 path 边界可能偏移，需要补偿
            adj_x = 0
            adj_y = 0
            if min_x != float('inf'):
                actual_cx = (min_x + max_x) / 2 * scale_x
                actual_cy = (min_y + max_y) / 2 * scale_y
                expected_cx = pw / 2 * scale_x
                expected_cy = ph / 2 * scale_y
                adj_x = expected_cx - actual_cx
                adj_y = expected_cy - actual_cy

            for item in path_pts:
                tag = item[0]
                if tag == "moveTo":
                    _, px, py = item
                    raw_x = px * scale_x + adj_x
                    raw_y = py * scale_y + adj_y
                    sx = _to_px(raw_x) + off_x_px
                    sy = _to_px(raw_y) + off_y_px
                    parts.append(f"M {sx:.2f} {sy:.2f}")
                elif tag == "lnTo":
                    _, px, py = item
                    raw_x = px * scale_x + adj_x
                    raw_y = py * scale_y + adj_y
                    sx = _to_px(raw_x) + off_x_px
                    sy = _to_px(raw_y) + off_y_px
                    parts.append(f"L {sx:.2f} {sy:.2f}")
                elif tag == "cubicBezTo":
                    _, coords = item
                    c1x = _to_px(coords[0][0] * scale_x + adj_x) + off_x_px
                    c1y = _to_px(coords[0][1] * scale_y + adj_y) + off_y_px
                    c2x = _to_px(coords[1][0] * scale_x + adj_x) + off_x_px
                    c2y = _to_px(coords[1][1] * scale_y + adj_y) + off_y_px
                    ex = _to_px(coords[2][0] * scale_x + adj_x) + off_x_px
                    ey = _to_px(coords[2][1] * scale_y + adj_y) + off_y_px
                    parts.append(f"C {c1x:.2f} {c1y:.2f} {c2x:.2f} {c2y:.2f} {ex:.2f} {ey:.2f}")
                elif tag == "close":
                    parts.append("Z")

        if not parts:
            return None
        return " ".join(parts)
    except Exception:
        return None




def _arc_to_svg_path(shape, x, y, w, h):
    """将 PPT prstGeom arc 转换为 SVG path 数据字符串。

    PPT arc: adj1/adj2 单位 1/60000 度，0=12点钟方向，顺时针。
    """
    try:
        import math
        from pptx.oxml.ns import qn

        sp = shape.element
        spPr = sp.find(qn("p:spPr"))
        if spPr is None:
            return None
        prstGeom = spPr.find(qn("a:prstGeom"))
        if prstGeom is None:
            return None

        adj1 = 0
        adj2 = 21600000
        avLst = prstGeom.find(qn("a:avLst"))
        if avLst is not None:
            for gd in avLst.findall(qn("a:gd")):
                name = gd.get("name", "")
                fmla = gd.get("fmla", "")
                if name == "adj1" and fmla.startswith("val "):
                    adj1 = int(fmla.split()[-1])
                elif name == "adj2" and fmla.startswith("val "):
                    adj2 = int(fmla.split()[-1])

        # OOXML arc 角度: 0°=right(3点钟), 顺时针为正 (y轴向下)
        # 直接转弧度，用 cos/sin 计算端点（y轴向下所以 sin 不取负）
        def ooxml_to_rad(adj_val):
            return math.radians((adj_val / 60000) % 360)

        start_rad = ooxml_to_rad(adj1)
        end_rad = ooxml_to_rad(adj2)

        cx = x + w / 2
        cy = y + h / 2
        rx = w / 2
        ry = h / 2

        x1 = cx + rx * math.cos(start_rad)
        y1 = cy + ry * math.sin(start_rad)
        x2 = cx + rx * math.cos(end_rad)
        y2 = cy + ry * math.sin(end_rad)

        # OOXML arc 固定从 adj1 顺时针到 adj2 (CW = 角度增大, y轴向下)
        # SVG sweep=1 = 顺时针 (y轴向下)
        ppt_start = (adj1 / 60000) % 360
        ppt_end = (adj2 / 60000) % 360
        cw_diff = (ppt_end - ppt_start) % 360
        sweep = 1
        large_arc = 1 if cw_diff > 180 else 0

        flipH = False
        flipV = False
        try:
            xfrm = spPr.find(qn("a:xfrm"))
            if xfrm is not None:
                flipH = xfrm.get("flipH") == "1"
                flipV = xfrm.get("flipV") == "1"
                if flipH:
                    x1 = 2 * cx - x1
                    x2 = 2 * cx - x2
                    sweep = 1 - sweep
                if flipV:
                    y1 = 2 * cy - y1
                    y2 = 2 * cy - y2
                    sweep = 1 - sweep
        except Exception:
            pass

        return f"M {x1:.2f} {y1:.2f} A {rx:.2f} {ry:.2f} 0 {large_arc} {sweep} {x2:.2f} {y2:.2f}"
    except Exception:
        return None




def _is_custgeom_ellipse(shape):
    """检测 custGeom 路径是否近似椭圆/圆形（已废弃，保留供兼容性使用）。"""
    return _custgeom_to_svg_path(shape) is not None




def _build_coord_map(group_shape, parent_coord_map=None):
    """为 group 构建坐标映射函数 (emu_x, emu_y) -> (px_x, px_y)

    顶层调用时 parent_coord_map=None，映射 group 子 EMU → slide 绝对 px。
    嵌套时传入 parent_coord_map，组合两层映射。
    """
    try:
        sp = group_shape.element
        grpSpPr = sp.find(qn("p:grpSpPr"))
        if grpSpPr is None:
            grpSpPr = sp
        xfrm = grpSpPr.find(qn("a:xfrm"))
        if xfrm is None:
            raise ValueError("no xfrm")
        off = xfrm.find(qn("a:off"))
        ext = xfrm.find(qn("a:ext"))
        chOff = xfrm.find(qn("a:chOff"))
        chExt = xfrm.find(qn("a:chExt"))
        grp_off_x = int(off.get("x", "0"))
        grp_off_y = int(off.get("y", "0"))
        grp_ext_cx = int(ext.get("cx", "1"))
        grp_ext_cy = int(ext.get("cy", "1"))
        ch_off_x = int(chOff.get("x", "0"))
        ch_off_y = int(chOff.get("y", "0"))
        ch_ext_cx = int(chExt.get("cx", "1"))
        ch_ext_cy = int(chExt.get("cy", "1"))
    except Exception:
        grp_off_x, grp_off_y = group_shape.left, group_shape.top
        grp_ext_cx, grp_ext_cy = max(group_shape.width, 1), max(group_shape.height, 1)
        ch_off_x, ch_off_y = 0, 0
        ch_ext_cx, ch_ext_cy = grp_ext_cx, grp_ext_cy

    scale_x = grp_ext_cx / max(ch_ext_cx, 1)
    scale_y = grp_ext_cy / max(ch_ext_cy, 1)

    def _to_parent_emu(emu_x, emu_y):
        return (
            grp_off_x + (emu_x - ch_off_x) * scale_x,
            grp_off_y + (emu_y - ch_off_y) * scale_y,
        )

    if parent_coord_map:
        def coord_map(emu_x, emu_y):
            abs_emu_x, abs_emu_y = _to_parent_emu(emu_x, emu_y)
            return parent_coord_map(abs_emu_x, abs_emu_y)
        coord_map.scale_x = scale_x * parent_coord_map.scale_x
        coord_map.scale_y = scale_y * parent_coord_map.scale_y
    else:
        def coord_map(emu_x, emu_y):
            abs_x, abs_y = _to_parent_emu(emu_x, emu_y)
            return (emu_to_px(abs_x), emu_to_px(abs_y))
        coord_map.scale_x = scale_x
        coord_map.scale_y = scale_y

    return coord_map


def _group_to_svg(group_shape, theme_map, images_dir, image_hashes,
                  slide_index, total_slides, unresolved_list, parent_coord_map=None):
    """递归展平 group shape，将子 shape 坐标映射到 slide 绝对坐标系

    parent_coord_map: 父 group 的坐标映射（嵌套 group 时传入），
                      用于将本层 EMU 偏移映射到 slide 绝对 px
    """
    x, y, w, h = _shape_position(group_shape)
    coord_map = _build_coord_map(group_shape, parent_coord_map)

    # 收集 group 中所有椭圆的位置（用于图片裁剪）
    ellipse_positions = []
    try:
        def _collect_ellipses(shapes, current_coord_map):
            for child in shapes:
                geom = _geom_type(child)
                if geom == "ellipse":
                    cx, cy, cw, ch = _shape_position(child)
                    # 应用 coord_map（如果 child 在 group 内）
                    if current_coord_map and hasattr(child, 'left'):
                        orig_left, orig_top, orig_width, orig_height = child.left, child.top, child.width, child.height
                        mapped_x, mapped_y = current_coord_map(orig_left, orig_top)
                        mapped_w = round(orig_width / 914400 * 96 * current_coord_map.scale_x)
                        mapped_h = round(orig_height / 914400 * 96 * current_coord_map.scale_y)
                        cx, cy, cw, ch = mapped_x, mapped_y, mapped_w, mapped_h
                    ellipse_positions.append((cx + cw/2, cy + ch/2, cw/2, ch/2))
                elif geom == "GROUP":
                    child_coord_map = _build_coord_map(child, current_coord_map)
                    _collect_ellipses(child.shapes, child_coord_map)
        _collect_ellipses(group_shape.shapes, coord_map)
    except Exception:
        pass

    children = []
    try:
        for child in group_shape.shapes:
            # 对图片传递椭圆位置作为裁剪参考
            clip_ellipse = None
            if child.shape_type == 13 and ellipse_positions:  # PICTURE
                clip_ellipse = ellipse_positions[0]

            child_svg = shape_to_svg(child, theme_map, images_dir, image_hashes,
                                     slide_index, total_slides, unresolved_list,
                                     coord_map=coord_map, clip_ellipse=clip_ellipse)

            if child_svg.strip():
                children.append(child_svg)
    except Exception as e:
        unresolved_list.append({
            "slide_index": slide_index,
            "shape_name": group_shape.name,
            "geom_type": "GROUP",
            "position": {"x": x, "y": y, "w": w, "h": h},
            "note": f"Group flattening failed: {e}",
        })
        return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" '
                f'fill="#CCCCCC" stroke="#999" stroke-dasharray="4" opacity="0.3"/>')

    if not children:
        return ""
    return "\n".join(children)
