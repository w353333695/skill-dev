# 通用执行风格指南

## 核心使命

作为精通 SVG 代码的 AI 设计执行师，严格遵循用户提供的**《设计规范与内容大纲》**，一次一页地将规划好的内容转化为高质量、结构清晰的 SVG 代码。支持**多种画布格式**（PPT、小红书、朋友圈、Story 等），根据规范中指定的格式自动适配尺寸和布局。

## 设计参数

画布格式通过 `config.py` 统一管理，在脚本中通过以下方式访问：

```python
from config import CANVAS_FORMATS
```

### 画布尺寸（画布格式配置）

| 格式标识 | 名称 | 尺寸 | viewBox | 适用场景 |
|:---------|:-----|:-----|:--------|:---------|
| `ppt169` | PPT 16:9 | 1280x720 | `0 0 1280 720` | 现代投影设备、在线演示 |
| `ppt43` | PPT 4:3 | 1024x768 | `0 0 1024 768` | 传统投影仪 |
| `xhs` | 小红书 | 1242x1660 | `0 0 1242 1660` | 社交平台竖版 |
| `moments` | 朋友圈 | 1080x1080 | `0 0 1080 1080` | 方形社交图 |
| `story` | Story | 1080x1920 | `0 0 1080 1920` | 短视频竖版 |

> 完整配置参见 `references/templates/design_spec_reference.md`

### 字体方案

根据《设计规范与内容大纲》中的字体方案，为不同文本角色应用对应字体：

| 角色 | 适用元素 | 中文推荐 | 英文推荐 |
|:-----|:---------|:---------|:---------|
| 标题字体 | H1/H2、页面标题 | 微软雅黑/楷体/黑体 | Arial/Georgia |
| 正文字体 | 段落、要点列表 | 微软雅黑/宋体 | Calibri/Times |
| 强调字体 | KPI、关键词 | 黑体 | Arial Black/Consolas |
| 注释字体 | 脚注、来源说明 | 微软雅黑/宋体 | Arial/Times |

## 布局模式

### PPT 16:9 (1280x720)

| 布局 | 坐标 |
|:-----|:-----|
| 双栏 | 左 x=40,w=580 / 右 x=660,w=580 |
| 三栏 | x=40,450,860 各 w=380 |
| 四象限 | (40,100,580,280) 四区 |

SVG 坐标示例（双栏布局）：

```xml
<!-- 左栏内容区 -->
<rect x="40" y="100" width="580" height="540" rx="8" fill="#FFFFFF"/>
<!-- 右栏内容区 -->
<rect x="660" y="100" width="580" height="540" rx="8" fill="#FFFFFF"/>
```

### 小红书 (1242x1660)

- 单栏堆叠：x=60, w=1122
- 双栏卡片：x=60/641, w=541

### 朋友圈 (1080x1080)

- 中心聚焦：x=140, y=140, w=800
- 四象限：480x480

## 图表模板

图表模板位于 `references/templates/charts/` 目录，可用模板如下：

| 模板文件 | 适用场景 |
|:---------|:---------|
| `kpi_cards.svg` | 关键指标卡片 |
| `bar_chart.svg` | 柱状图/对比分析 |
| `line_chart.svg` | 折线图/趋势分析 |
| `donut_chart.svg` | 环形图/占比构成 |
| `funnel_chart.svg` | 漏斗图/转化流程 |
| `matrix_2x2.svg` | 矩阵图/四象限分析 |
| `timeline.svg` | 时间线/里程碑 |
| `process_flow.svg` | 流程图 |
| `pie_chart.svg` | 饼图 |
| `waterfall_chart.svg` | 瀑布图 |
| `radar_chart.svg` | 雷达图 |
| `treemap_chart.svg` | 矩形树图 |

完整目录和选择指南参见 `references/templates/charts/charts_index.json`

> 当页面涉及图表时，建议先阅读对应的模板 SVG 文件，了解其结构和布局，以便绘制出更高质量的图表。

## 图标使用

图标库位于 `references/icons/`，包含 640+ 图标。

根据设计规范中确定的图标方式选择：

| 方式 | 说明 |
|:-----|:-----|
| **A: Emoji** | `<text>🚀 增长</text>` — 最简单，跨平台一致性好 |
| **B: AI 生成** | 用 SVG 基本元素绘制 — 灵活但耗时 |
| **C: 内置库** | 使用 `references/icons/` 640+ 图标 — **推荐** |
| **D: 自定义** | 使用用户指定图标 |

内置图标占位符方式（推荐）：

```xml
<use data-icon="rocket" x="100" y="200" width="48" height="48" fill="#0076A8"/>
```

常用图标：`chart-bar` `arrow-trend-up` `users` `cog` `circle-checkmark` `target` `clock` `file`

完整索引参见 `references/icons/README.md`

> 无需手动运行 `embed_icons.py`！`finalize_svg.py` 后处理工具会自动嵌入图标。

## 图片处理

根据设计规范「图片资源清单」中的状态处理：

| 状态 | 来源 | 处理方式 |
|:-----|:-----|:---------|
| **已有** | 用户提供 | 直接引用 `images/` 目录中的图片 |
| **AI 生成** | Image Generator 生成 | 图片已在 `images/` 目录，直接引用 |
| **占位符** | 暂未准备 | 使用虚线框占位 |

引用已有图片：

```xml
<image href="images/cover_bg.png" x="0" y="0" width="1280" height="720"
       preserveAspectRatio="xMidYMid slice"/>
```

占位符格式：

```xml
<rect x="100" y="200" width="400" height="300" fill="#F0F4F8" stroke="#CBD5E1"
      stroke-width="2" stroke-dasharray="8,4" rx="8"/>
<text x="300" y="350" text-anchor="middle" fill="#64748B" font-size="14">[图片：描述]</text>
```

图片适配规则：

- 竖图严禁横向拉伸，应使用 `<rect>` 创建竖向遮罩或容器
- 宽图避免在左右分栏的狭窄容器中显示
- 全屏背景用 `preserveAspectRatio="xMidYMid slice"`（裁剪）
- 完整展示数据图表用 `preserveAspectRatio="xMidYMid meet"`（包含）

## 视觉丰富度（默认 L2）

通用灵活风格追求视觉冲击力，内容页默认使用 **L2 级视觉丰富度**（渐变 + 阴影 + 装饰）。

### 每页 defs 模板（复制到每页 SVG 头部）

```xml
<defs>
  <!-- 渐变顶条 -->
  <linearGradient id="topBar" x1="0%" y1="0%" x2="100%" y2="0%">
    <stop offset="0%" stop-color="#[主导色]"/>
    <stop offset="100%" stop-color="#[辅助色]"/>
  </linearGradient>
  <!-- 卡片阴影 -->
  <filter id="cardShadow" x="-20%" y="-20%" width="140%" height="140%">
    <feGaussianBlur in="SourceAlpha" stdDeviation="4"/>
    <feOffset dx="0" dy="2" result="off"/>
    <feComponentTransfer><feFuncA type="linear" slope="0.12"/></feComponentTransfer>
    <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
</defs>
```

### 常用装饰元素

**渐变顶条**（替代纯色顶条）：
```xml
<rect x="0" y="0" width="1280" height="5" fill="url(#topBar)"/>
```

**卡片阴影**（用于 KPI 卡、信息卡片）：
```xml
<g filter="url(#cardShadow)">
  <rect x="60" y="150" width="560" height="250" rx="12" fill="#FFFFFF"/>
  <!-- 卡片内容 -->
</g>
```

**角落光晕**（右下角装饰）：
```xml
<circle cx="1200" cy="680" r="180" fill="#[主导色]" fill-opacity="0.04"/>
```

**图标背景光晕**：
```xml
<circle cx="130" cy="250" r="35" fill="#[主导色]" fill-opacity="0.1"/>
```

**渐变分隔线**：
```xml
<line x1="60" y1="300" x2="600" y2="300" stroke="url(#topBar)" stroke-width="2" stroke-opacity="0.3"/>
```

### 视觉丰富度等级速查

| 页面类型 | 最低等级 | 必须包含 |
|----------|----------|----------|
| 封面 | L3 | 渐变 + 阴影 + 光晕 + 装饰几何 |
| 章节页 | L2 | 渐变顶条 + 阴影 |
| 内容页 | L1+ | 渐变顶条（至少） |
| 图表页 | L2 | 卡片阴影 + 渐变 |
| 结束页 | L2 | 渐变 + 光晕 |

## 技术约束

### 禁止使用的 SVG 元素和属性

| 类别 | 禁止项 |
|:-----|:-------|
| 遮罩/裁剪 | `clipPath`, `mask` |
| 样式 | `<style>`, `class`, `id`(内容元素), 外部 CSS, `@font-face` |
| 嵌入 | `<foreignObject>`, `<iframe>` |
| 符号引用 | `<symbol>+<use>`（图标占位符除外） |
| 文本 | `textPath` |
| 动画 | `<animate*>`, `<set>` |
| 脚本/事件 | `<script>`, `onclick` 等事件属性 |

> `id` 允许用于 `<defs>` 中的 gradient/filter 定义
| 标记 | `marker`, `marker-end` |

### 必须遵守

- `viewBox` 必须与画布尺寸一致
- 使用 `<tspan>` 手动换行
- 使用 `<rect>` 定义背景色
- 使用《设计规范与内容大纲》中指定的字体方案

### PPT 兼容性规则

为确保导出 PPT 后效果一致，透明度必须使用标准写法：

| 禁止 | 正确 |
|:-----|:-----|
| `fill="rgba(255,255,255,0.1)"` | `fill="#FFFFFF" fill-opacity="0.1"` |
| `<g opacity="0.2">...</g>` | 每个子元素单独设置透明度 |
| `<image opacity="0.3"/>` | 图片后加遮罩层 `<rect fill="背景色" opacity="0.7"/>` |

**记忆口诀**：PPT 不认 rgba、不认组透明、不认图片透明、不认 marker

## SVG 文件命名规范

文件命名格式：`<序号>_<页面名称>.svg`

命名语言规则（根据内容语言自动匹配）：

- **中文内容** -> 使用中文命名：`01_封面.svg`, `02_目录.svg`, `03_核心优势.svg`
- **英文内容** -> 使用英文命名：`01_cover.svg`, `02_agenda.svg`, `03_key_benefits.svg`
- 序号规则：两位数字，从 01 开始递增
- 页面名称：简洁描述性，与《设计规范与内容大纲》中的页面标题一致

## 模板遵循规则

如果项目 `templates/` 目录中存在模板文件，必须遵循模板结构：

| 页面类型 | 对应模板 | 遵循规则 |
|:---------|:---------|:---------|
| 封面 | `01_cover.svg` | 继承背景、装饰元素、布局结构，替换占位符内容 |
| 章节页 | `03_chapter.svg` | 继承编号样式、标题位置、装饰元素 |
| 内容页 | `04_content.svg` | 继承页眉页脚样式，**内容区可自由布局** |
| 结束页 | `05_ending.svg` | 继承背景、感谢语位置、联系信息布局 |
| 目录页 | `02_toc.svg` | **可选**：继承目录标题、列表样式 |

开始生成每一页之前，必须明确输出该页对应的模板：

```markdown
## 页面生成：01_封面.svg

**模板对应**: `templates/01_cover.svg`
**布局策略**: 继承背景渐变、装饰线条，替换标题/副标题/日期占位符

[生成的 SVG 代码]
```

如果没有模板，则声明"自由生成"并说明布局策略。

---

## 模板填充模式（选项 C 专用）

> **适用条件**：Phase 2 选择了选项 C（PPTX 模板提取），且 `$PPT_DIR/templates/design_spec.md` 中的「使用说明」标注为选项 C 约束。
>
> 在此模式下，「使用说明」具有最高优先级，覆盖以下所有规则。

### 约束优先级

| 优先级 | 规则来源 | 说明 |
|--------|---------|------|
| **最高** | `$PPT_DIR/templates/design_spec.md` 使用说明 | 选项 C 选项特殊约束 |
| 次高 | 本指南「模板遵循规则」 | 继承模板结构 |
| 最低 | 本指南「视觉丰富度」 | **不适用**于模板填充模式 |

### 必须保留

- 模板 SVG 中所有形状的位置 (x, y, width, height)
- 所有文本的坐标、字号、字体
- 装饰形状（矩形、圆形、path）及其 fill/opacity
- 图片引用（如有，修复 `clipPath` 为显式裁剪而非删除）
- 背景和页眉页脚框架

### 允许修改

- 将 `{{PLACEHOLDER}}` 替换为实际文本内容
- 将 `rgba()` 改为 `fill` + `fill-opacity`
- 将 `<g opacity>` 拆分为子元素独立透明度
- 将 `clipPath` 改为显式裁剪（调整 `<image>` 的 x/y/w/h）
- 将 `style="..."` 内联样式拆解为标准属性

### 禁止操作

- 添加模板中不存在的 `<defs>` 定义（gradient、filter 等）
- 添加装饰元素（渐变顶条、卡片阴影、角落光晕、装饰圆点）
- 改变文本位置 (x, y) 或字号 (font-size)
- 重新设计布局结构或配色方案
- 删除模板的装饰形状

## 执行流程

### 阶段一：设计参数确认（必须）

在生成第一页 SVG 之前，必须先回顾《设计规范与内容大纲》中的关键设计参数：

```markdown
## 设计参数确认

已回顾《设计规范与内容大纲》，关键参数如下：
- 画布: {宽}x{高}
- 正文字号: {规范值}px
- 配色方案: 主导色 {#HEX} / 辅助色 {#HEX} / 强调色 {#HEX}
- 字体: {中文字体} / {英文字体}

已确认，开始生成 SVG
```

### 阶段二：视觉构建

连续生成所有 SVG 页面，确保设计风格和布局坐标的高度一致性。

### 阶段三：逻辑构建

SVG 全部定稿后，再批量生成演讲备注，确保叙事逻辑连贯。

### 阶段四：后处理

使用 pipeline.py 执行后处理：

```bash
# 完整后处理流程（拆分讲稿 -> SVG 后处理 -> 导出 PPTX）
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR

# 仅执行特定步骤
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step split
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step finalize
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --step export

# 遇到错误继续执行（不中断）
python3 $SCRIPTS_DIR/pipeline.py $PPT_DIR --continue-on-error
```

#### 各步骤独立调用

```bash
# SVG 质量门禁 - 检测 PPT 不兼容元素
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/
python3 $SCRIPTS_DIR/svg_lint.py $PPT_DIR/svg_output/ --json

# SVG 后处理（自动嵌入图标、图片等）
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR --only embed-icons fix-rounded
python3 $SCRIPTS_DIR/finalize_svg.py $PPT_DIR --dry-run

# 讲稿拆分
python3 $SCRIPTS_DIR/total_md_split.py $PPT_DIR
python3 $SCRIPTS_DIR/total_md_split.py $PPT_DIR -o custom_notes

# 导出 PPTX（推荐使用 final 版本）
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final
python3 $SCRIPTS_DIR/svg_to_pptx.py $PPT_DIR -s final -o output.pptx

# 风格推荐引擎
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain style
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain color
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --domain typography
python3 $SCRIPTS_DIR/style_advisor.py "关键词描述" --design-system

# 图片分析
python3 $SCRIPTS_DIR/analyze_images.py $PPT_DIR/images/
```

## 生成后自检

- [ ] viewBox 与画布尺寸一致
- [ ] 无禁用元素（见技术约束清单）
- [ ] 用 `<tspan>` 换行
- [ ] 元素不超出边界
- [ ] 颜色符合规范
- [ ] PPT 兼容：无 `rgba()`、无 `<g opacity>`、图片用遮罩层
- [ ] 视觉丰富度 ≥ L1（至少 1 个 gradient/filter 定义）

## 演讲备注格式

在所有 SVG 页面生成完成并定稿后，生成完整的演讲备注文稿（`notes/total.md`）。

```markdown
# 01_<页面标题>
这是第一页的讲稿内容...
讲稿正文，2-5 句自然语言。可使用标记：
[停顿] 给观众思考时间，[互动] 提问或引导参与。

要点：①要点一 ②要点二 ③要点三
时长：X 分钟

---

# 02_<页面标题>
这是第二页的讲稿内容...
[过渡] 接下来我们来看...

讲稿正文，2-5 句自然语言。可使用标记：
[停顿] 给观众思考时间，[互动] 提问或引导参与。

要点：①要点一 ②要点二 ③要点三
时长：X 分钟

---

# 03_<页面标题>
...
```

### 控场标记

| 标记 | 用途 |
|:-----|:-----|
| `[停顿]` | 关键展示后留白，让观众消化 |
| `[互动]` | 提问或引导观众参与 |
| `[过渡]` | 段首单独成段，必须放在每页正文开头，用于承上启下 |

备注文件命名：

- **推荐**：与 SVG 同名（如 `01_封面.svg` 对应 `notes/01_封面.md`）
- **兼容**：也支持 `slide01.md` 格式（向后兼容）

使用 `total_md_split.py` 自动拆分讲稿到各页文件。
