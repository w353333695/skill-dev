# Phase 0: 前置检查与环境准备

> 确认环境就绪、验证依赖、生成 BATCH_ID、创建项目工作目录

## 目标

- 验证 Python 运行环境和必要依赖库
- 确认用户提供的源文件可访问且格式有效
- 生成唯一的 BATCH_ID 并创建标准目录结构
- 为后续所有 Phase 奠定目录和变量基础

## 产出物

- 环境变量 `$SCRIPTS_DIR`、`$REFERENCE_DIR`、`$PPT_DIR` 已就绪
- `$PPT_DIR/` 目录结构已创建（含 `sources/`、`images/`、`notes/`、`templates/`、`svg_output/`、`svg_final/`、`previews/`）
- `BATCH_ID` 已生成（格式：`YYYYMMDD_HHmmss`）

## 前置条件

- 用户已触发 ppt-generator SKILL（通过 Command 或直接调用）
- 用户已提供源材料或准备提供（PDF/URL/Markdown 文件路径）
- Python 3.9+ 已安装（运行时使用 `python3`）

## 核心变量定义

以下变量贯穿所有 Phase，在 SKILL.md 主入口处由 Claude Code 注入：

```
$SCRIPTS_DIR  = plugin/skills/ppt-generator/scripts/    # 工具脚本绝对路径
$REFERENCE_DIR = plugin/skills/ppt-generator/references/ # 参考资源绝对路径
$PPT_DIR      = ${PWD}/output/ppt-generator/$BATCH_ID/  # 当前项目工作目录（基于用户工作目录）
```

> 注意：`$SCRIPTS_DIR` 和 `$REFERENCE_DIR` 在 SKILL.md 中注入，本 Phase 负责生成 `$BATCH_ID` 并创建 `$PPT_DIR`。
>
> 注意：`$PPT_DIR` 基于 `${PWD}`（用户当前工作目录），而非 SKILL 安装目录。输出文件应始终创建在用户的工作空间中。

---

## 执行步骤

### Step 1: 生成 BATCH_ID

生成当前时间戳作为批次唯一标识：

```bash
BATCH_ID=$(date +%Y%m%d_%H%M%S)
echo "BATCH_ID=$BATCH_ID"
```

**预期输出**：
```
BATCH_ID=20260326_143052
```

**错误处理**：
- 若 `date` 命令不可用（Windows 环境），使用 Python 生成：
  ```bash
  BATCH_ID=$(python3 -c "from datetime import datetime; print(datetime.now().strftime('%Y%m%d_%H%M%S'))")
  ```

### Step 2: 创建项目工作目录

```bash
BATCH_ID=$(date +%Y%m%d_%H%M%S)
PPT_DIR="${PWD}/output/ppt-generator/$BATCH_ID"
mkdir -p "$PPT_DIR"/{sources,images,notes,templates,svg_output,svg_final,previews}
echo "工作目录: $PPT_DIR"
ls -la "$PPT_DIR"
```

**预期输出**：显示 7 个子目录

```
工作目录: /Users/user/my-project/output/ppt-generator/20260326_143052
drwxr-xr-x  sources/
drwxr-xr-x  images/
drwxr-xr-x  notes/
drwxr-xr-x  templates/
drwxr-xr-x  svg_output/
drwxr-xr-x  svg_final/
drwxr-xr-x  previews/
```

**目录用途说明**：

| 目录 | 用途 |
|------|------|
| `sources/` | 归档源材料（PDF 原件、URL 记录、转换后的 Markdown） |
| `images/` | 图片资源（用户提供、AI 生成、模板自带的图片） |
| `notes/` | 演讲备注（`total.md` + 拆分后的独立文件） |
| `templates/` | 模板文件（`design_spec.md` + `.svg` 模板） |
| `svg_output/` | SVG 原始输出（带占位符，作为中间产物） |
| `svg_final/` | SVG 最终版本（后处理完成，用于 PPTX 导出） |
| `previews/` | PNG 预览图（Phase 5.5 视觉验收时生成） |

### Step 3: Python 依赖检查

检查必要的 Python 依赖库：

```bash
python3 -c "
import sys

deps = {
    'python-pptx': 'pptx',
    'svglib': 'svglib',
    'reportlab': 'reportlab',
    'cairosvg': 'cairosvg',
    'PyMuPDF': 'fitz',
    'beautifulsoup4': 'bs4',
    'requests': 'requests',
    'Pillow': 'PIL',
}

errors = []
for name, module in deps.items():
    try:
        mod = __import__(module)
        ver = getattr(mod, '__version__', 'installed')
        print(f'  {name}: {ver}')
    except ImportError:
        errors.append(name)
        print(f'  {name}: MISSING')

if errors:
    print(f'\n⚠ 缺少 {len(errors)} 个依赖: {', '.join(errors)}')
    print('安装命令: pip install ' + ' '.join(errors))
    sys.exit(1)
else:
    print('\n✅ 所有依赖已就绪')
"
```

**预期输出**：
```
  python-pptx: 0.6.23
  svglib: 1.5.1
  reportlab: 4.2.0
  cairosvg: 2.7.0
  PyMuPDF: 1.24.0
  beautifulsoup4: 4.12.0
  requests: 2.32.0
  Pillow: 10.0.0

✅ 所有依赖已就绪
```

**错误处理**：
- 缺少依赖时提示用户安装，所有依赖声明在项目根目录 `requirements.txt` 中
- 使用 `uv` 管理环境时：`uv pip install -r requirements.txt`

### Step 4: 源文件验证

根据用户提供的源材料类型进行验证：

#### PDF 文件验证

```bash
if [ -f "用户提供路径.pdf" ]; then
    python3 -c "
import fitz
doc = fitz.open('用户提供路径.pdf')
print(f'页数: {len(doc)}')
print(f'✅ PDF 文件有效')
doc.close()
"
else
    echo "❌ PDF 文件不存在"
fi
```

#### URL 验证

```bash
python3 -c "
import urllib.request
req = urllib.request.Request('用户提供URL', headers={'User-Agent': 'Mozilla/5.0'})
resp = urllib.request.urlopen(req, timeout=10)
print(f'状态码: {resp.status}')
print(f'✅ URL 可访问')
"
```

#### Markdown 文件验证

```bash
if [ -f "用户提供路径.md" ]; then
    LINE_COUNT=$(wc -l < "用户提供路径.md")
    echo "行数: $LINE_COUNT"
    echo "✅ Markdown 文件有效"
else
    echo "❌ Markdown 文件不存在"
fi
```

**错误处理**：
- PDF 文件损坏：提示用户检查文件，或尝试使用 MinerU（适用于扫描版 PDF）
- URL 不可访问：提示用户检查网络或提供本地文件
- 文件不存在：提示用户提供正确路径

---

## 常见问题

### Q: Python 版本不满足 3.9+ 要求怎么办？

提示用户升级 Python：

```bash
python3 --version
```

### Q: pip install 速度慢？

所有依赖已声明在项目根目录 `requirements.txt`，一键安装：

```bash
pip install -r requirements.txt
```

使用 `uv` 管理：
```bash
uv pip install -r requirements.txt
```

使用国内镜像：
```bash
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### Q: 工作目录已存在怎么办？

如果 `$PPT_DIR` 已存在，检查是否为上一次未完成的批次。可追加后缀或直接使用已有目录继续。
