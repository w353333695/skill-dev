# Phase 4: 图片生成

> 为设计规范中标记为「待生成」的图片创建优化提示词，通过 AI 工具生成图片

## 目标

- 分析图片资源清单，确定每张图片的类型和生成策略
- 为每张待生成图片创建优化的 AI 提示词
- 通过 AI 工具生成图片并保存到 `$PPT_DIR/images/`

## 产出物

- `$PPT_DIR/images/image_prompts.md` — 所有图片的优化提示词文档
- `$PPT_DIR/images/*.png` / `*.jpg` — 生成的图片文件
- 更新后的图片资源清单（状态从「待生成」变为「已生成」）

## 前置条件

- Phase 3 已完成（《设计规范与内容大纲》已生成）
- 图片使用选项包含「C) AI 生成」
- 图片资源清单中存在「待生成」状态的图片

> **触发条件**：仅当用户在 Phase 3 中选择的图片方案**包含**「C) AI 生成」时才进入此 Phase。否则直接跳到 Phase 5。

---

## 执行步骤

### Step 1: 分析图片资源清单

从《设计规范与内容大纲》中提取所有「状态=待生成」的图片：

```
图片资源清单示例：

| 文件名 | 尺寸 | 用途 | 类型 | 生成描述 |
|--------|------|------|------|----------|
| cover_bg.png | 1920x1080 | 封面背景 | 背景图 | 现代科技感抽象背景 |
| product.png | 600x400 | 第3页配图 | 实景照片 | 产品展示，简洁白底 |
```

### Step 2: 判断图片类型

为每张图片确定生成策略：

```
图片的视觉呈现形式是什么？
    ├─ 全页/大面积铺底 → 背景图 (Step 3)
    ├─ 真实场景/人物/产品 → 实景照片 (Step 3)
    ├─ 扁平/插画/卡通风格 → 插画配图 (Step 3)
    ├─ 流程/架构/关系 → 图表/架构图 (Step 3)
    └─ 局部装饰/纹理 → 装饰图案 (Step 3)
```

**五种图片类型及提示词要点**：

#### 背景图
- 强调 `background`、`backdrop` 关键词
- 预留文字区域：`negative space in center for text overlay`
- 使用抽象、渐变、几何元素
- 低对比细节：`subtle`、`soft`、`muted`
- 负面提示词：`text, letters, watermark, faces, busy patterns`

#### 实景照片
- 强调真实感：`photography`、`photorealistic`
- 光影效果：`natural lighting`、`soft shadows`
- 背景处理：`white background` 或 `blurred background`
- 负面提示词：`watermark, text overlay, artificial, CGI, illustration`

#### 插画配图
- 明确风格：`flat design`、`isometric`、`vector style`
- 简化细节：`simplified`、`clean lines`
- 严格使用设计规范配色
- 负面提示词：`realistic, photography, 3D render, complex textures`

#### 图表/架构图
- 清晰结构：`clear structure`、`organized layout`
- 连接表示：`arrows indicating flow`
- 浅色背景：`white background`
- 负面提示词：`cluttered, messy, overlapping elements`

#### 装饰图案
- 可重复性：`seamless`、`tileable`（如需要）
- 低调辅助：`subtle`、`understated`
- 透明友好：`transparent background`
- 负面提示词：`busy, cluttered, high contrast`

### Step 3: 生成提示词文档

> **强制要求**：必须使用文件写入工具将提示词保存为 `.md` 文件，不能仅在对话中输出。

为每张图片创建标准提示词，保存到 `$PPT_DIR/images/image_prompts.md`：

```markdown
# 图片生成提示词

> 项目: {项目名称}
> 生成时间: {日期}
> 配色方案: 主导色 {#HEX} | 辅助色 {#HEX} | 强调色 {#HEX}

---

## 图片清单总览

| # | 文件名 | 类型 | 尺寸 | 状态 |
|---|--------|------|------|------|
| 1 | cover_bg.png | 背景图 | 1920x1080 | 待生成 |
| 2 | product.png | 实景照片 | 600x400 | 待生成 |

---

## 详细提示词

### 图片 1: cover_bg.png

| 属性 | 值 |
|------|-----|
| 用途 | 封面背景 |
| 类型 | 背景图 |
| 尺寸 | 1920x1080 (16:9) |
| 原始描述 | 现代科技感抽象背景，深蓝渐变 |

**提示词 (Prompt)**:

```
Abstract futuristic background with flowing digital waves and particles,
modern tech aesthetic, deep navy blue (#1E3A5F) to bright cyan (#22D3EE) gradient,
soft glowing light effects, geometric patterns,
16:9 aspect ratio, clean negative space in center for text overlay,
high quality 4K, professional presentation background
```

**负面提示词 (Negative Prompt)**:
```
text, letters, watermark, faces, busy patterns, high contrast details
```

**图片描述 (Alt Text)**:
> 现代科技感抽象背景，深蓝色渐变配合数字波浪和粒子效果

---
```

### Step 4: 配色整合到提示词

从设计规范提取配色，转换为提示词色彩指令：

```
设计规范配色 → 提示词色彩指令

主导色: #1E3A5F (深海蓝)   → "deep navy blue (#1E3A5F)"
辅助色: #F8F9FA (浅灰)     → "light gray (#F8F9FA)"
强调色: #D4AF37 (金)       → "gold accent (#D4AF37)"

完整指令: "color palette: deep navy blue (#1E3A5F), light gray (#F8F9FA), gold accent (#D4AF37)"
```

### Step 5: AI 图片生成

根据设计规范中确认的画布格式确定宽高比：

| 画布格式 | 背景图宽高比 | 建议分辨率 |
|----------|-------------|-----------|
| PPT 16:9 | 16:9 | 1920x1080 |
| PPT 4:3 | 4:3 | 1600x1200 |
| 小红书 | 3:4 | 1242x1660 |
| 朋友圈 | 1:1 | 1080x1080 |
| Story | 9:16 | 1080x1920 |

> **Nano Banana 工具支持的宽高比**：`1:1`, `2:3`, `3:2`, `3:4`, `4:3`, `4:5`, `5:4`, `9:16`, `16:9`, `21:9`

#### 方式一：用户自行生成

提示用户使用 `image_prompts.md` 中的提示词，到以下平台生成：
- Midjourney / DALL-E 3 / Gemini / Stable Diffusion
- 将生成后的图片放入 `$PPT_DIR/images/` 目录

#### 方式二：等待用户提供

若用户暂时无法生成图片，可选择：
- 在 SVG 中使用占位符（虚线框），后期替换
- 先生成不含图片的版本

### Step 6: 验证图片就绪

确认所有图片已保存到 `images/` 目录：

```bash
# 列出 images/ 目录下所有图片文件
ls -la $PPT_DIR/images/
```

**验证清单**：
- 文件名与清单一致
- 图片尺寸符合要求
- 图片格式正确（PNG/JPG）
- 背景图预留了足够的文字区域

## 常见问题

### Q: 用户没有提供「生成描述」怎么办？

根据图片用途和页面内容推断，主动生成合理的提示词：

| 用途 | 默认推断 |
|------|----------|
| 封面背景 | 抽象渐变背景，预留中央文字区域 |
| 章节页背景 | 简洁几何图案，侧重单色调 |
| 团队介绍页 | 团队协作场景插图（扁平风格） |
| 数据展示页 | 简洁几何图案或纯色背景 |

### Q: 生成的图片不满意怎么办？

提供提示词变体，让用户选择或调整。可调整的关键维度：
- 更抽象 vs 更具象
- 不同色调（暖色 vs 冷色）
- 不同风格（扁平 vs 立体 vs 水彩）

### Q: 图片与 PPT 内容不协调？

确保提示词中包含设计规范的配色方案，维持视觉一致性。
