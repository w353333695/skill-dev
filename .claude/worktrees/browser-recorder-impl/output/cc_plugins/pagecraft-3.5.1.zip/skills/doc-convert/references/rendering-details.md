## 主题系统

两个内置主题，通过 `--theme` 切换：

| 主题 | 风格 | 页边距 | 字体 |
|------|------|--------|------|
| `default` | 衬线正文 + 无衬线标题 | 2.5cm | Noto Serif SC Bundled / Noto Sans SC Bundled |
| `minimal` | 全无衬线 | 1.8cm | Noto Sans SC Bundled |

## 中文排版

使用捆绑的 Noto CJK TrueType 字体，确保 Apple Preview / Chrome 均正常渲染。

字体回退链（CSS 中已声明）：
- 正文: `Noto Serif SC Bundled` → `Noto Serif CJK SC` → `serif`
- 标题: `Noto Sans SC Bundled` → `Noto Sans CJK SC` → `sans-serif`
- 代码: `Noto Sans SC Bundled` → `Noto Sans Mono CJK SC` → `monospace`

若环境无系统 CJK 字体（中文显示为 tofu），安装：
```bash
apt-get install fonts-noto-cjk fonts-noto-cjk-extra
```

## ASCII art 保护

Markdown 中的 Box Drawing 字符（线框图、流程图等）自动检测并注入 `.ascii-art` CSS class，禁止折行、保持对齐。

## 转换管线（内部）

```
Markdown → markdown-it (md2html.mjs) → HTML 片段
  → CSS 主题注入 + BeautifulSoup 后处理 → WeasyPrint (html2pdf.py)
  → PDF
```

图片路径自动转换为 `file://` URL（相对于源文件目录）。

## 依赖清单

| 组件 | 捆绑位置 | 说明 |
|------|----------|------|
| markdown-it + highlight.js + katex | `node_modules/` | Node.js 渲染管线 |
| WeasyPrint + beautifulsoup4 等 | `lib/pypkgs/` | Python PDF 生成 |
| Noto CJK TrueType 字体 | `themes/shared/fonts/` | 中英文混排 |
| KaTeX 数学字体 | `node_modules/katex/dist/fonts/` | 数学公式渲染 |

仅需系统预装 cairo/pango/fontconfig（绝大多数 Linux 已自带）。
