#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# lib/md2pdf.sh — MD → PDF (markdown-it + WeasyPrint)
#
# 用法:
#   bash lib/md2pdf.sh input.md -o output.pdf
#   bash lib/md2pdf.sh input.md -o output.pdf --theme default
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# ── 路径解析 ────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
# 注：NODE_PATH 对 ESM (.mjs) 的 bare import 无效，故不再设置。
# Node 依赖由 _bootstrap-deps.sh 装到用户家目录缓存，.mjs 用 createRequire 解析。
# Python (WeasyPrint) 不再捆绑 lib/pypkgs，改由 _bootstrap-deps.sh 的
# _ensure_python_weasyprint 自动建缓存 venv 安装（或复用系统 weasyprint）。
THEME="${THEME:-default}"
THEME_DIR="$SKILL_DIR/themes/$THEME"
CSS_FILE="$THEME_DIR/theme.css"

# ── 颜色输出 ────────────────────────────────────────────────────────────────
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }

# ── 参数解析 ────────────────────────────────────────────────────────────────
INPUT=""
OUTPUT=""
while [[ $# -gt 0 ]]; do
  case $1 in
    -o|--output)
      OUTPUT="$2"; shift 2 ;;
    --theme)
      THEME="$2"
      THEME_DIR="$SKILL_DIR/themes/$THEME"
      CSS_FILE="$THEME_DIR/theme.css"
      shift 2 ;;
    -*)
      echo "Unknown option: $1"
      echo "Usage: md2pdf.sh input.md -o output.pdf [--theme default]"
      exit 1 ;;
    *)
      INPUT="$1"; shift ;;
  esac
done

# ── 参数校验 ────────────────────────────────────────────────────────────────
if [[ -z "$INPUT" || -z "$OUTPUT" ]]; then
  echo "Usage: md2pdf.sh input.md -o output.pdf [--theme default]"
  exit 1
fi

if [[ ! -f "$INPUT" ]]; then
  error "Input file not found: $INPUT"
  exit 1
fi

OUTPUT_DIR="$(dirname "$OUTPUT")"
if [[ ! -d "$OUTPUT_DIR" ]]; then
  error "输出目录不存在: $OUTPUT_DIR"
  exit 1
fi
if [[ ! -w "$OUTPUT_DIR" ]]; then
  error "输出目录不可写: $OUTPUT_DIR"
  exit 1
fi

FILE_SIZE=$(stat -f%z "$INPUT" 2>/dev/null || stat -c%s "$INPUT" 2>/dev/null)
if [[ "$FILE_SIZE" -gt 50000000 ]]; then
  warn "文件较大 (${FILE_SIZE} bytes)，转换可能需要较长时间，建议耐心等待。"
fi

# ── 环境依赖检查 ────────────────────────────────────────────────────────────
info "检查环境依赖..."

# Node.js
if ! command -v node &>/dev/null; then
  error "Node.js 未安装"
  echo "  安装指引: apt-get install nodejs 或访问 https://nodejs.org/" >&2
  exit 2
fi

# Node 依赖自举：装到用户家目录缓存，.mjs 用 createRequire 解析。
# skill 目录只读、无 node_modules 也能跑。
source "$SCRIPT_DIR/_bootstrap-deps.sh"
_ensure_node_cache "$SKILL_DIR" || exit 2
_ensure_mermaid_engine "$INPUT"   # 持久引擎：含 Mermaid 时自动装/迁移，失败静默降级

# Python 3 + WeasyPrint 自举：复用系统 weasyprint，否则在缓存建 venv 安装。
# 不再依赖 lib/pypkgs（分发包不带），由 _ensure_python_weasyprint 处理，
# 并设置全局 PYTHON 变量供下游使用。
_ensure_python_weasyprint || exit 3

# ── 主流程 ───────────────────────────────────────────────────────────────────
if [[ ! -f "$CSS_FILE" ]]; then
  error "CSS theme not found: $CSS_FILE"
  exit 1
fi

info "使用 WeasyPrint 引擎"

TEMP_HTML=$(mktemp /tmp/md2pdf-XXXXX.html)
trap 'rm -f "$TEMP_HTML"' EXIT

info "Step 1/2: Markdown → HTML (markdown-it)..."
node "$SCRIPT_DIR/md2html.mjs" "$INPUT" > "$TEMP_HTML"

info "Step 2/2: HTML + CSS → PDF (WeasyPrint)..."
INPUT_DIR="$("$PYTHON" -c "import os; print(os.path.dirname(os.path.realpath('$INPUT')))")"
"$PYTHON" "$SCRIPT_DIR/html2pdf.py" \
  --html "$TEMP_HTML" \
  --css "$CSS_FILE" \
  --base-url "$INPUT_DIR" \
  -o "$OUTPUT"

info "PDF generated: $OUTPUT"
