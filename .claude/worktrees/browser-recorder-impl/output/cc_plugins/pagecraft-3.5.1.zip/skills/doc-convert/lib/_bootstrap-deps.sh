#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# lib/_bootstrap-deps.sh — doc-convert 的 Node 依赖自举（被 md2docx.sh / md2pdf.sh source）
#
# 解决「skill 目录只读、无 node_modules」环境下 ESM 依赖解析问题：
#   1. 把 doc-convert 的 package.json + lock 复制到用户家目录缓存
#      （${DOC_CONVERT_NODE_CACHE:-~/.cache/doc-convert}，家目录永远可写）
#   2. 在缓存目录 npm install（一次安装，永久复用；stamp 变化才重装）
#   3. export DOC_CONVERT_NODE_CACHE，供 .mjs 里的 _resolve.mjs（createRequire）
#      锚定解析到 <缓存>/node_modules
#
# 为什么不用 NODE_PATH：ESM bare import 不认 NODE_PATH，只从脚本所在目录链回溯。
# 为什么不用 npm ci：会清掉用户已 opt-in 的 optional 重依赖（puppeteer 等），改用
#   npm install（additive）。
#
# 用法（在被 source 的脚本里，颜色函数定义之后）：
#   source "$SCRIPT_DIR/_bootstrap-deps.sh"
#   _ensure_node_cache "$SKILL_DIR"
# ─────────────────────────────────────────────────────────────────────────────

# 颜色输出 fallback：若调用方已定义 info/warn/error 则沿用，否则自带一份。
if ! command -v info &>/dev/null; then
  _BC_GREEN='\033[0;32m'; _BC_YELLOW='\033[1;33m'; _BC_RED='\033[0;31m'; _BC_NC='\033[0m'
  info()  { echo -e "${_BC_GREEN}[INFO]${_BC_NC} $*"; }
  warn()  { echo -e "${_BC_YELLOW}[WARN]${_BC_NC} $*" >&2; }
  error() { echo -e "${_BC_RED}[ERROR]${_BC_NC} $*" >&2; }
fi

# 缓存目录：默认 ~/.cache/doc-convert，可被环境变量覆盖。
# 只放「轻量、可秒级自举」的库依赖（markdown-it 等）与 WeasyPrint venv——
# XDG 规范定义 ~/.cache 为「可随时丢失」，故这里**不放** Mermaid 引擎。
: "${DOC_CONVERT_NODE_CACHE:=$HOME/.cache/doc-convert}"
export DOC_CONVERT_NODE_CACHE

# Mermaid 引擎安装根：默认 ~/.local/share/doc-convert（XDG 持久数据目录，
# 不被平台当缓存清理）。Mermaid 引擎重（Chromium ~300MB）、需用户同意才装、
# 应一次同意持久可用——这些属性要求它落在「不会被清理」的位置，与上面的
# 可清理缓存严格区分。可被环境变量 DOC_CONVERT_MERMAID_DIR 覆盖。
: "${DOC_CONVERT_MERMAID_DIR:=$HOME/.local/share/doc-convert}"
export DOC_CONVERT_MERMAID_DIR

# 算 stamp：skill 的 package.json + package-lock.json 内容 + node 大版本。
# 任一变化（依赖升级、换 Node 大版本）都触发重装。
_bootstrap_stamp() {
  local skill_dir="$1"
  local lock="$skill_dir/package-lock.json"
  {
    cat "$skill_dir/package.json" 2>/dev/null
    cat "$lock" 2>/dev/null
    node -v 2>/dev/null
  } | shasum -a 256 2>/dev/null | awk '{print $1}' \
    || md5sum 2>/dev/null | awk '{print $1}' \
    || echo "unstamped-$$"
}

# 主入口：确保缓存目录有可用 node_modules，否则安装。
# 参数：$1 = skill 根目录（含 package.json）。
_ensure_node_cache() {
  local skill_dir="$1"
  local cache="$DOC_CONVERT_NODE_CACHE"
  local marker="$cache/node_modules/markdown-it"   # 用一个核心依赖存在性作「装好」标志

  mkdir -p "$cache"

  # 快速命中：依赖已装且 stamp 未变 → 直接返回（秒过）。
  local stamp
  stamp="$(_bootstrap_stamp "$skill_dir")"
  if [[ -d "$marker" && -f "$cache/.stamp" && "$(cat "$cache/.stamp" 2>/dev/null)" == "$stamp" ]]; then
    return 0
  fi

  if ! command -v npm &>/dev/null; then
    error "npm 未安装（doc-convert 的 Node 依赖需要它）"
    echo "  安装指引: apt-get install nodejs npm 或访问 https://nodejs.org/" >&2
    return 2
  fi

  info "准备 Node 依赖到缓存目录: $cache"
  # 复制清单到缓存（缓存是「安装根」，npm 在此读 package.json）。
  cp -f "$skill_dir/package.json" "$cache/package.json" 2>/dev/null || true
  [[ -f "$skill_dir/package-lock.json" ]] && cp -f "$skill_dir/package-lock.json" "$cache/package-lock.json" 2>/dev/null || true

  info "npm install（首次较慢，约数十秒；后续命中缓存秒过）..."
  # --omit=optional：跳过 mermaid-cli/puppeteer 等重依赖（首次用按约定问用户后选装）。
  # 用 npmmirror 镜像加速国内环境；失败时不立即退出，由后续 marker 检查兜底。
  if ! (cd "$cache" && npm install --omit=optional --registry=https://registry.npmmirror.com --no-audit --no-fund) >/tmp/doc-convert-npm-$$.log 2>&1; then
    # 镜像失败时回退默认源重试一次。
    warn "npm install（镜像源）失败，回退默认 npm 源重试..."
    if ! (cd "$cache" && npm install --omit=optional --no-audit --no-fund) >>/tmp/doc-convert-npm-$$.log 2>&1; then
      error "Node 依赖安装失败。日志: /tmp/doc-convert-npm-$$.log"
      echo "  可手动安装: npm install --prefix \"$cache\"" >&2
      return 2
    fi
  fi
  rm -f "/tmp/doc-convert-npm-$$.log"

  if [[ ! -d "$marker" ]]; then
    error "依赖安装后仍找不到核心包 markdown-it（缓存: $cache）"
    return 2
  fi

  echo "$stamp" > "$cache/.stamp"
  info "依赖就绪（缓存已就绪，后续转换将复用）"
}

# ── Python (WeasyPrint) 自举 ─────────────────────────────────────────────────
# PDF 路径依赖 WeasyPrint。分发包不再捆绑 lib/pypkgs（已移除），改为：
#   1. 若系统 python3 能 import weasyprint → 直接用系统（最快，无额外安装）
#   2. 否则在缓存目录建 venv，pip install weasyprint beautifulsoup4
# 优先级：系统 weasyprint → 缓存 venv。命中 stamp 则跳过安装。
# 设置全局变量 PYTHON（可执行解释器路径）供调用方使用；返回 0 成功 / 2 失败。
DOC_CONVERT_VENV="${DOC_CONVERT_NODE_CACHE}/.venv"
export DOC_CONVERT_VENV

_ensure_python_weasyprint() {
  # 1. 系统 python3 已有 weasyprint → 直接用，最省事。
  if command -v python3 &>/dev/null && python3 -c "import weasyprint" 2>/dev/null; then
    PYTHON="python3"
    export PYTHON
    return 0
  fi

  if ! command -v python3 &>/dev/null; then
    error "python3 未安装（PDF 转换的 WeasyPrint 需要）"
    echo "  安装指引: apt-get install python3 python3-pip 或访问 https://www.python.org/" >&2
    return 2
  fi

  # 2. 缓存 venv：用 weasyprint 版本 + python 版本作 stamp，命中则跳过重装。
  local cache="$DOC_CONVERT_NODE_CACHE"
  local venv="$DOC_CONVERT_VENV"
  local marker="$venv/bin/python"
  local want_req="weasyprint,beautifulsoup4"
  local pystamp
  pystamp="$({ printf '%s\n' "$want_req"; python3 --version 2>&1; } \
    | shasum -a 256 2>/dev/null | awk '{print $1}' \
    || echo "unstamped-$$")"

  if [[ -x "$marker" && -f "$cache/.pystamp" && "$(cat "$cache/.pystamp" 2>/dev/null)" == "$pystamp" ]] \
     && "$marker" -c "import weasyprint, bs4" 2>/dev/null; then
    PYTHON="$marker"
    export PYTHON
    return 0
  fi

  info "WeasyPrint 未就绪，准备在缓存 venv 安装: $venv"
  if ! python3 -m venv "$venv" >/tmp/doc-convert-venv-$$.log 2>&1; then
    error "创建 venv 失败（$venv）。日志: /tmp/doc-convert-venv-$$.log"
    echo "  可手动: python3 -m venv \"$venv\" && \"$venv/bin/pip\" install weasyprint beautifulsoup4" >&2
    return 2
  fi

  info "pip install weasyprint beautifulsoup4（首次较慢，约数十秒）..."
  if ! "$venv/bin/pip" install --quiet --index-url https://pypi.tuna.tsinghua.edu.cn/simple \
        weasyprint beautifulsoup4 >>/tmp/doc-convert-venv-$$.log 2>&1; then
    # 清华镜像失败回退官方 PyPI。
    warn "pip install（清华镜像）失败，回退官方 PyPI 重试..."
    if ! "$venv/bin/pip" install --quiet weasyprint beautifulsoup4 >>/tmp/doc-convert-venv-$$.log 2>&1; then
      error "WeasyPrint 安装失败。日志: /tmp/doc-convert-venv-$$.log"
      echo "  可手动: \"$venv/bin/pip\" install weasyprint beautifulsoup4" >&2
      return 2
    fi
  fi
  rm -f "/tmp/doc-convert-venv-$$.log"

  if ! "$venv/bin/python" -c "import weasyprint, bs4" 2>/dev/null; then
    error "WeasyPrint 安装后仍无法 import（venv: $venv）"
    return 2
  fi

  echo "$pystamp" > "$cache/.pystamp"
  PYTHON="$venv/bin/python"
  export PYTHON
  info "WeasyPrint 就绪（缓存 venv 已就绪，后续转换将复用）"
}

# ── Mermaid 引擎自举（持久、高频无感知）──────────────────────────────────────
# 含 Mermaid 图的文档需要 mermaid-cli (mmdc) + Chromium 才能渲染，否则降级为代码块。
# 设计（v3.5.1 起）：mermaid-cli + puppeteer 视为「高频且无感知」依赖——
#   - 装到 $DOC_CONVERT_MERMAID_DIR（~/.local/share/doc-convert，持久，bootstrap 永不触碰）。
#   - 检测到文档含 Mermaid 代码块且持久目录无 mmdc 时自动 npm install（不无条件拉、不每次问用户）。
#   - 旧位置的 mermaid-cli（轻量库缓存 / skill 本地 node_modules）不经迁移直接复用——
#     findMmdc 的 fallback 链会命中它（迁移整棵依赖树太脆弱，不如就地复用 + 缺失才重装）。
#   - 安装失败不阻塞：静默降级为代码块 + 打印手动安装提示（保持「不影响其余内容」）。
#   - Chromium 优先复用环境里任何已存在的（含 puppeteer v24 的 chrome-headless-shell）。
#
# 参数：$1 = 输入 md 文件路径（用于判断是否含 Mermaid；缺省则视为「需要」保守处理）。
# 返回值恒为 0（缺引擎/装失败都不阻塞主流程）。

# 检测文档是否含 Mermaid 代码块（```mermaid）。轻量 grep，避免读大文件全文。
_doc_has_mermaid() {
  local input="$1"
  [[ -z "$input" || ! -f "$input" ]] && return 1
  grep -qE '^[[:space:]]*```[[:space:]]*mermaid[[:space:]]*$' "$input" 2>/dev/null
}

# mmdc 是否在「任何」已知位置可用（持久目录 / 轻量库缓存 / skill 本地 / cwd / npx / 全局）。
# 复用 mermaid.mjs findMmdc 的判定，避免与本逻辑两套实现。
_mmdc_available_anywhere() {
  local skill_dir="${SKILL_DIR:-$(dirname "$(dirname "${BASH_SOURCE[0]}")")}"
  for cand in \
    "$DOC_CONVERT_MERMAID_DIR/node_modules/.bin/mmdc" \
    "$DOC_CONVERT_NODE_CACHE/node_modules/.bin/mmdc" \
    "$skill_dir/node_modules/.bin/mmdc" \
    "$(pwd)/node_modules/.bin/mmdc" ; do
    [[ -x "$cand" ]] && return 0
  done
  command -v mmdc &>/dev/null && return 0
  command -v npx &>/dev/null && npx --no-install mmdc --version >/dev/null 2>&1 && return 0
  return 1
}

_ensure_mermaid_engine() {
  local input="${1:-}"
  local mdir="$DOC_CONVERT_MERMAID_DIR"

  # 1. 任何位置已有 mmdc（持久目录 / 旧位置 / 全局 / npx）→ 直接复用，不装。
  if _mmdc_available_anywhere; then
    return 0
  fi

  # 2. 文档不含 Mermaid → 根本不需要引擎，静默返回（不装、不提示）。
  if ! _doc_has_mermaid "$input"; then
    return 0
  fi

  # 3. 文档含 Mermaid 但任何位置都没 mmdc → 自动安装到持久目录。
  if ! command -v npm &>/dev/null; then
    info "检测到 Mermaid 图表但无 npm，图表将降级为代码块（不影响其余内容）。"
    return 0
  fi

  info "检测到 Mermaid 图表，自动安装渲染引擎到持久目录: $mdir"
  info "  （mermaid-cli + puppeteer，约数十 MB；首次较慢，后续复用）"
  mkdir -p "$mdir"
  # 版本与 package.json optionalDependencies 对齐，避免漂移。
  if ! (cd "$mdir" && npm install --registry=https://registry.npmmirror.com --no-audit --no-fund \
        @mermaid-js/mermaid-cli@^11.15.0 puppeteer@^24.0.0) >/tmp/doc-convert-mermaid-$$.log 2>&1; then
    warn "npm install（镜像源）失败，回退默认 npm 源重试..."
    if ! (cd "$mdir" && npm install --no-audit --no-fund \
          @mermaid-js/mermaid-cli@^11.15.0 puppeteer@^24.0.0) >>/tmp/doc-convert-mermaid-$$.log 2>&1; then
      rm -f "/tmp/doc-convert-mermaid-$$.log"
      info "Mermaid 引擎安装失败，图表将降级为代码块（不影响其余内容）。"
      info "  可手动安装: npm install --prefix \"$mdir\" @mermaid-js/mermaid-cli puppeteer"
      return 0   # 静默降级，不阻塞
    fi
  fi
  rm -f "/tmp/doc-convert-mermaid-$$.log"

  if [[ -x "$mdir/node_modules/.bin/mmdc" ]]; then
    info "Mermaid 引擎就绪（持久目录已就绪，后续转换将复用）。"
  else
    info "Mermaid 引擎安装后 mmdc 仍不可用，图表将降级为代码块。"
    info "  可手动安装: npm install --prefix \"$mdir\" @mermaid-js/mermaid-cli puppeteer"
  fi
  return 0
}
