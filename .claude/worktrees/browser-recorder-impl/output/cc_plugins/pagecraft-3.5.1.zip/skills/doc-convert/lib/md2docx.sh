#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# lib/md2docx.sh — MD → DOCX (markdown-it + @turbodocx/html-to-docx)
#
# 与 md2pdf.sh 对称：复用 md2html.mjs 上游，把 HTML 片段交给 html2docx.mjs。
# 纯 Node 管线，无需 Python / WeasyPrint。
#
# 用法:
#   bash lib/md2docx.sh input.md -o output.docx
#   bash lib/md2docx.sh input.md -o output.docx --theme minimal
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# ── 路径解析 ────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
# 注：NODE_PATH 对 ESM (.mjs) 的 bare import 无效，故不再设置。
# 依赖由 _bootstrap-deps.sh 装到用户家目录缓存，.mjs 内用 createRequire 锚定解析。
THEME="${THEME:-default}"

# ── 颜色输出 ────────────────────────────────────────────────────────────────
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }

# ── 参数解析 ────────────────────────────────────────────────────────────────
INPUT=""
OUTPUT=""
while [[ $# -gt 0 ]]; do
  case $1 in
    -o|--output)
      OUTPUT="$2"; shift 2 ;;
    --theme)
      THEME="$2"; shift 2 ;;
    -*)
      echo "Unknown option: $1"
      echo "Usage: md2docx.sh input.md -o output.docx [--theme default|minimal]"
      exit 1 ;;
    *)
      INPUT="$1"; shift ;;
  esac
done

# ── 参数校验 ────────────────────────────────────────────────────────────────
if [[ -z "$INPUT" || -z "$OUTPUT" ]]; then
  echo "Usage: md2docx.sh input.md -o output.docx [--theme default|minimal]"
  exit 1
fi

if [[ ! -f "$INPUT" ]]; then
  error "Input file not found: $INPUT"
  exit 1
fi

OUTPUT_DIR="$(dirname "$OUTPUT")"
if [[ ! -d "$OUTPUT_DIR" ]]; then
  error "输出目录不存在: $OUTPUT_DIR"
  exit 1
fi
if [[ ! -w "$OUTPUT_DIR" ]]; then
  error "输出目录不可写: $OUTPUT_DIR"
  exit 1
fi

FILE_SIZE=$(stat -f%z "$INPUT" 2>/dev/null || stat -c%s "$INPUT" 2>/dev/null)
if [[ "$FILE_SIZE" -gt 50000000 ]]; then
  warn "文件较大 (${FILE_SIZE} bytes)，转换可能需要较长时间，建议耐心等待。"
fi

# ── 环境依赖检查 ────────────────────────────────────────────────────────────
info "检查环境依赖..."

if ! command -v node &>/dev/null; then
  error "Node.js 未安装"
  echo "  安装指引: apt-get install nodejs 或访问 https://nodejs.org/" >&2
  exit 2
fi

# Node 依赖自举：装到用户家目录缓存（~/.cache/doc-convert），.mjs 用 createRequire 解析。
# 这样 skill 目录只读、无 node_modules 也能跑——agent 无需手动复制目录或装依赖。
source "$SCRIPT_DIR/_bootstrap-deps.sh"
_ensure_node_cache "$SKILL_DIR" || exit 2
_ensure_mermaid_engine "$INPUT"   # 持久引擎：含 Mermaid 时自动装/迁移，失败静默降级

# ── 主流程 ───────────────────────────────────────────────────────────────────
info "使用 @turbodocx/html-to-docx 引擎 (theme=${THEME})"

TEMP_HTML=$(mktemp /tmp/md2docx-XXXXX.html)
trap 'rm -f "$TEMP_HTML"' EXIT

info "Step 1/2: Markdown → HTML (markdown-it)..."
node "$SCRIPT_DIR/md2html.mjs" "$INPUT" > "$TEMP_HTML"

info "Step 2/2: HTML → DOCX (html-to-docx)..."
node "$SCRIPT_DIR/html2docx.mjs" "$TEMP_HTML" --theme "$THEME" -o "$OUTPUT"

info "DOCX generated: $OUTPUT"
