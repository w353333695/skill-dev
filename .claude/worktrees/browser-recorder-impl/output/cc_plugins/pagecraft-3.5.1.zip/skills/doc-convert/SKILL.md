---
name: doc-convert
description: 把 Markdown 文件转换/导出/生成/转成 PDF 或 Word(DOCX) 文档。用于文档交付、技术报告产出、方案/设计文档定稿、会议纪要/周报/笔记导出、README 或 wiki 转可分发格式、把 md 转成可打印/可分享的 pdf 或 word 文件。当用户说"导出/转换/生成/转成 PDF/Word/docx"、"把这个 md 转成文档"、"生成一份可打印版本"、"导出成可分享的文件"、"转成 word 发给客户"、"出个 PDF 版"、"把笔记/文档导出来"时使用。只要上下文有 .md/.markdown 文件且意图是产出 PDF 或 Word 文档，就应该触发。
---

# doc-convert — Markdown → PDF / DOCX 转换

## 执行流程

1. **读取源文件**，验证扩展名为 `.md` / `.markdown`，否则报错"仅支持 Markdown 文件"。
2. **确定输出格式与路径**：
   - PDF（默认）→ `.pdf`；Word / DOCX → `.docx`
   - 用户指定路径 → 直接用；未指定 → 源文件名 + 对应扩展名
3. **执行转换**（按格式分叉）：
   ```bash
   SKILL_DIR="${SKILL_DIR:-$(dirname "$(dirname "$0")")}"
   bash "$SKILL_DIR/lib/md2pdf.sh"  "input.md" -o "output.pdf"  --theme default
   bash "$SKILL_DIR/lib/md2docx.sh" "input.md" -o "output.docx" --theme default
   ```
   `--theme`: `default`（衬线，2.5cm 边距）| `minimal`（无衬线，1.8cm 紧凑）
4. **验证输出**存在且非空，报告路径与大小。

不要手动 `npm install`、不要复制 skill 目录、不要自建 venv——脚本会自动处理依赖。

## 依赖（脚本自动管理，agent 无需介入）

分发包不含任何依赖。依赖分两类目录管理：

- **轻量库依赖** → `~/.cache/doc-convert`（XDG 缓存，可被清理，但秒级自举重建，无需用户介入）：
  - **Node**（markdown-it / html-to-docx / cheerio 等）：自动 `npm install` 到缓存；`.mjs` 用 `createRequire` 解析。仅需 `node` + `npm`。
  - **Python/WeasyPrint**（PDF）：复用系统 weasyprint，否则在缓存自动建 venv 装。仅需 `python3` + `pip`。
- **Mermaid 渲染引擎**（重依赖）→ `~/.local/share/doc-convert`（XDG 持久数据目录，**不**放 `~/.cache`，避免被平台缓存清理导致反复重装）。见下。
- **CJK 字体**：依赖运行环境系统已装（Noto CJK SC / PingFang）。**不自动装**（需系统权限）。

## Mermaid 图表

含 Mermaid 图的文档需要 mermaid-cli (mmdc) + Chromium 渲染，否则降级为代码块。

**自动安装（高频无感知）**：mermaid-cli + puppeteer 视为常规依赖——脚本**检测到文档含 Mermaid 代码块且环境里任何位置都没有 mmdc 时**，自动装到持久目录 `~/.local/share/doc-convert`（一次安装、跨会话复用、bootstrap 永不触碰）。**已有 mmdc 直接复用**（持久目录 / 旧缓存目录 / skill 本地 / 全局 / npx 任一命中即可），不重复装。**安装失败不阻塞**：静默降级为代码块 + 打印手动安装提示（不影响其余内容）。无 Mermaid 图的文档不触发安装。

**Chromium 优先复用**：脚本会扫描环境里任何已装的 Chromium，命中即复用，不重复下载。搜索顺序：puppeteer v24 的 **`chrome-headless-shell`**（mermaid-cli 依赖 puppeteer v24，其启动器只认这个独立二进制，不认普通 chrome）→ 普通 chrome（`PUPPETEER_EXECUTABLE_PATH` → puppeteer 缓存 → Playwright 缓存 → macOS Chrome.app → Linux 包路径 → 系统 PATH）。仅当全部缺失时，安装 puppeteer 时自带的 `browsers install` 会把 `chrome-headless-shell` 拉到 `~/.cache/puppeteer`。

手动安装（自动装失败时兜底）：
```bash
npm install --prefix ~/.local/share/doc-convert @mermaid-js/mermaid-cli puppeteer
# 仅当环境里没有任何 chrome-headless-shell / chrome 时才需要：
npx puppeteer browsers install chrome
```

## 错误处理

| 场景 | 处理 |
|------|------|
| WeasyPrint 未装（PDF） | 脚本自动建缓存 venv 装；失败则提示 `~/.cache/doc-convert/.venv/bin/pip install weasyprint beautifulsoup4` |
| Node 依赖未装 | 脚本自动 `npm install` 到缓存；失败提示 `npm install --prefix ~/.cache/doc-convert` |
| Mermaid 引擎未装（含 Mermaid 文档） | 任何位置都无 mmdc 时自动装到 `~/.local/share/doc-convert`；已有则复用；失败静默降级为代码块 |
| npm/pip/node/python3 未装 | 报错，提示安装对应工具 |
| 中文 tofu（字体缺失） | 提示用户装系统 CJK 字体后重试：Linux `apt-get install fonts-noto-cjk`；macOS 自带 PingFang |
| 本地图片文件不存在（DOCX） | 自动占位 + alt `[图片缺失: 文件名]`，不中断 |
| 源文件非 Markdown / 不存在 | 报错，要求确认路径 |
| 输出目录不存在/不可写 | 提示检查输出路径 |
| 大文件 (>50MB) | 给时间预估，问是否继续 |

## 工具权限

Bash（node / python3）、Read、Write
