#!/usr/bin/env python3
"""
lib/html2pdf.py — HTML 后处理器 + WeasyPrint PDF 生成器

职责:
  1. 读取 markdown-it 输出的 HTML 片段
  2. 读取 CSS 主题文件内容
  3. 用 BeautifulSoup 做后处理（ASCII art 检测、长 URL 折行、Mermaid 渲染）
  4. 组装完整 HTML 页面
  5. 调用 WeasyPrint 生成 PDF

用法:
  python3 lib/html2pdf.py --html fragment.html --css themes/default/theme.css -o output.pdf
  python3 lib/html2pdf.py --html fragment.html --css themes/default/theme.css --base-url /path/to/workspace/ -o output.pdf
"""

import argparse
import base64
import os
import re
import sys
from pathlib import Path
from typing import Optional

from bs4 import BeautifulSoup
# WeasyPrint is imported lazily in generate_pdf() to give a friendly error
# message when it's not installed, rather than crashing at import time.

# Box Drawing 字符集 — 用于 ASCII art 检测
BOX_DRAWING_CHARS = set(
    "─│┌┐└┘├┤┬┴┼"
    "═║╔╗╚╝╠╣╦╩╬"
    "━┃"
)

# ── Mermaid 渲染配置 ────────────────────────────────────────────────────────


def is_ascii_art(text: str, threshold: int = 5) -> bool:
    """检测文本是否包含大量 Box Drawing 字符（ASCII art）"""
    count = sum(1 for c in text if c in BOX_DRAWING_CHARS)
    return count > threshold


# ── Mermaid 图表渲染（二级降级：本地 Chromium → 代码块）───────


def _find_chromium() -> Optional[str]:
    """
    查找 Chromium 浏览器可执行文件（优先复用环境里任何已装的）。

    搜索顺序（命中即返回，避免重复下载 ~300MB）:
      0. PUPPETEER_EXECUTABLE_PATH 环境变量（用户/平台显式指定）
      1. 旧自定义路径 ~/.chromium（兼容已装用户）
      2. puppeteer 默认缓存（Linux ~/.cache/puppeteer / macOS ~/Library/Caches/Puppeteer）
      3. Playwright 缓存（Linux ~/.cache/ms-playwright / macOS ~/Library/Caches/ms-playwright）
      4. macOS 系统 Chrome.app 根级（/Applications）
      5. Linux 包固定路径（/usr/bin、/snap/bin）
      6. 系统 PATH
    """
    import shutil
    import glob as glob_mod

    home = Path.home()

    # 0. 显式指定（最高优先）。
    env_path = os.environ.get('PUPPETEER_EXECUTABLE_PATH')
    if env_path and Path(env_path).exists():
        return env_path

    # 各候选根目录子树里 Chromium 主程序的命名差异。
    # chrome-headless-shell 排最前：puppeteer v24+ 把 headless 拆成独立二进制，
    # mermaid-cli (依赖 puppeteer v24) 的启动器只认 chrome-headless-shell，
    # 不认普通 chrome——即使设了 PUPPETEER_EXECUTABLE_PATH 指向普通 chrome 也不行。
    # macOS 必须锚定 *.app/Contents/MacOS/，避免误匹配同名 Helper/Framework 二进制
    # （*.framework/.../Helpers/*.app/Contents/MacOS/ 下的同名二进制）。
    glob_patterns = [
        # puppeteer v24+ headless 专用二进制（跨平台：linux64 / mac-arm / mac-x64 / win64）
        "**/chrome-headless-shell-*/chrome-headless-shell",
        "**/chrome-headless-shell",
        "**/chrome-linux*/chrome",
        "**/chrome-mac*/Google Chrome for Testing",
        "**/*.app/Contents/MacOS/Google Chrome for Testing",
        "**/*.app/Contents/MacOS/Google Chrome",
        "**/*.app/Contents/MacOS/Chromium",
        "**/chrome-win*/chrome.exe",
    ]

    # 1-4. 各候选根目录子树扫描。
    roots = [
        home / ".chromium",
        home / ".cache" / "puppeteer",
        home / "Library" / "Caches" / "Puppeteer",
        home / ".cache" / "ms-playwright",
        home / "Library" / "Caches" / "ms-playwright",
        Path("/Applications"),
    ]
    for root in roots:
        if root.exists():
            for pattern in glob_patterns:
                for p in root.glob(pattern):
                    if p.is_file():
                        return str(p)

    # 5. Linux 包固定路径。
    for p in ["/usr/bin/google-chrome", "/usr/bin/google-chrome-stable",
              "/usr/bin/chromium", "/usr/bin/chromium-browser", "/snap/bin/chromium"]:
        if Path(p).exists():
            return p

    # 6. 系统 PATH。
    return (shutil.which("google-chrome")
            or shutil.which("google-chrome-stable")
            or shutil.which("chromium-browser")
            or shutil.which("chromium"))


def _find_mmdc() -> Optional[str]:
    """查找 mmdc (mermaid-cli) 可执行文件路径，找不到返回 None。"""
    import shutil
    import subprocess

    # 搜索路径：直接检查已知位置
    # 优先 Mermaid 引擎目录（mermaid-cli 装在 ~/.local/share/doc-convert，见 _bootstrap-deps.sh）；
    # 兼容旧安装：曾装在轻量库缓存 ~/.cache/doc-convert。
    search_paths = []
    mermaid_dir = os.environ.get('DOC_CONVERT_MERMAID_DIR')
    if mermaid_dir:
        search_paths.append(Path(mermaid_dir) / 'node_modules' / '.bin' / 'mmdc')
    cache_dir = os.environ.get('DOC_CONVERT_NODE_CACHE')
    if cache_dir:
        search_paths.append(Path(cache_dir) / 'node_modules' / '.bin' / 'mmdc')
    search_paths.extend([
        # 技能本地 node_modules
        Path(__file__).resolve().parent.parent / 'node_modules' / '.bin' / 'mmdc',
        # 当前工作目录
        Path.cwd() / 'node_modules' / '.bin' / 'mmdc',
    ])
    for p in search_paths:
        if p.exists():
            return str(p)

    # 通过 npx 查找
    npx = shutil.which('npx')
    if npx:
        try:
            r = subprocess.run(
                ['npx', 'mmdc', '--version'],
                capture_output=True, timeout=15
            )
            if r.returncode == 0:
                return 'npx mmdc'
        except Exception:
            pass

    # 全局安装
    mmdc = shutil.which('mmdc')
    if mmdc:
        return mmdc

    return None


def _render_mermaid_local(src: str, mmdc_cmd: str) -> Optional[str]:
    """
    使用本地 mmdc (mermaid-cli + Chromium) 渲染单个 Mermaid 图表。

    返回 PNG data URI，失败返回 None。

    为何用 PNG 而非 SVG：Mermaid v11 的 flowchart 节点标签一律用
    <foreignObject><div> 渲染（flowchart.htmlLabels 开关已无效），而
    WeasyPrint 不支持 SVG 内的 <foreignObject>，会丢弃其中所有文字，
    导致流程图只剩空框。sequenceDiagram 用原生 <text> 不受影响，但为
    统一与稳健，所有图都走 PNG（文字烘焙进像素）。与 DOCX 路径
    (lib/mermaid.mjs) 行为一致。
    """
    import subprocess
    import tempfile

    mmd_path = None
    png_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode='w', suffix='.mmd', delete=False, encoding='utf-8'
        ) as f:
            f.write(src)
            mmd_path = f.name

        png_path = mmd_path + '.png'

        puppeteer_config = (
            Path(__file__).resolve().parent / 'puppeteer-config.json'
        )

        # 设置插件本地 Chromium 路径（持久化，避免每次会话重新下载）
        env = os.environ.copy()
        chromium = _find_chromium()
        if chromium:
            env["PUPPETEER_EXECUTABLE_PATH"] = chromium

        if mmdc_cmd == 'npx mmdc':
            cmd = ['npx', 'mmdc', '-i', mmd_path, '-o', png_path,
                   '-b', 'transparent', '-s', '2',
                   '-p', str(puppeteer_config)]
        else:
            cmd = [mmdc_cmd, '-i', mmd_path, '-o', png_path,
                   '-b', 'transparent', '-s', '2',
                   '-p', str(puppeteer_config)]

        subprocess.run(cmd, capture_output=True, timeout=30, check=True, env=env)

        # PNG 自带像素尺寸，无需 SVG 那套 viewBox 尺寸修正
        png_bytes = Path(png_path).read_bytes()
        encoded = base64.b64encode(png_bytes).decode('utf-8')
        return f'data:image/png;base64,{encoded}'
    except Exception:
        return None
    finally:
        if mmd_path:
            Path(mmd_path).unlink(missing_ok=True)
        if png_path:
            Path(png_path).unlink(missing_ok=True)


def _render_mermaid_blocks(html: str) -> tuple[str, Optional[str]]:
    """
    将 HTML 中的 Mermaid 代码块渲染为图片。

    降级顺序:
      1. 本地 mmdc + Chromium（需系统已安装 @mermaid-js/mermaid-cli）
      2. 保留代码块（最终降级，不影响其余内容）

    返回:
      (处理后的 HTML, 警告信息或 None)
    """
    soup = BeautifulSoup(html, "html.parser")

    mermaid_blocks = []
    for pre in soup.find_all("pre"):
        code = pre.find("code")
        if not code:
            continue
        classes = code.get("class", [])
        if isinstance(classes, str):
            classes = [classes]
        if any("language-mermaid" in c for c in classes):
            mermaid_blocks.append((pre, code.get_text()))

    if not mermaid_blocks:
        return html, None

    count = len(mermaid_blocks)

    # ── Tier 1: 本地 mmdc + Chromium ─────────────────────────────────────
    mmdc = _find_mmdc()
    if mmdc:
        success = 0
        for pre, src in mermaid_blocks:
            data_uri = _render_mermaid_local(src, mmdc)
            if data_uri:
                img = soup.new_tag('img', src=data_uri, alt="Mermaid diagram")
                # 同时约束宽高：纵向流程图（如 graph TD，aspect 可达 1:3+）若只限
                # max-width 会被撑到超过一页、文字压成细线；横向图（sequence）若
                # 不限高度也会铺满整页。max-height 兜底让图按页面高度等比缩小，
                # 文字仍可读（PNG 为 2x 渲染，缩放后仍清晰）。A4 2.2cm 边距 → 可
                # 打印高约 257mm，取 160mm 让大图约占半页、不喧宾夺主。
                img['style'] = (
                    'max-width:100%;max-height:160mm;'
                    'height:auto;width:auto;'
                    'object-fit:contain;display:block;margin:0.5em auto;'
                )
                pre.replace_with(img)
                success += 1
        if success == count:
            return str(soup), None
        elif success > 0:
            return str(soup), (
                f"⚠ Mermaid 图表：{success}/{count} 个由本地 Chromium 渲染成功，"
                f"其余保留为代码块。"
            )

    # ── Tier 2: 最终降级 ─────────────────────────────────────────────────
    chromium_hint = ""
    if not _find_chromium():
        chromium_hint = (
            "\n    npx puppeteer browsers install chrome"
            "（检测到环境无可用 Chromium，需下载；若已有 Chrome/Chromium 请设"
            " PUPPETEER_EXECUTABLE_PATH）"
        )
    return html, (
        f"⚠ Mermaid 图表未渲染（共 {count} 个）：\n"
        "  · 本地 mermaid-cli 未安装或 Chromium 不可用\n"
        "  图表已保留为代码块形式，不影响其余内容。\n"
        "  安装本地渲染引擎到持久目录（一次安装、跨会话复用）：\n"
        "    npm install --prefix ~/.local/share/doc-convert"
        " @mermaid-js/mermaid-cli puppeteer"
        " --registry=https://registry.npmmirror.com"
        + chromium_hint
    )


def postprocess(html_content: str) -> str:
    """
    扫描 HTML，为特殊内容注入 CSS class:
      - ASCII art 代码块 → 添加 .ascii-art class（禁止折行，使用 Liberation Mono 字体）
      - 长 URL → 注入 <wbr> 允许折行
      - 长内容表格单元格 → 标记 .long-content class

    注：Mermaid 图表由 _render_mermaid_blocks() 单独渲染为 PNG 图片（见 main()）。

    ASCII art 的 Box Drawing 字符对齐通过 CSS font-family (Liberation Mono)
    实现，无需 HTML 层面的 span 注入。
    """
    soup = BeautifulSoup(html_content, "html.parser")

    # 1. ASCII art 检测与处理
    for pre in soup.find_all("pre"):
        text = pre.get_text()
        if not is_ascii_art(text):
            continue

        # 添加 .ascii-art class
        existing = pre.get("class", [])
        if isinstance(existing, str):
            existing = [existing]
        pre["class"] = existing + ["ascii-art"]

    # 2. 长 URL 折行处理
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if len(href) > 50:
            a["href"] = re.sub(r"([/?&;=#])", r"\1​", href)

    # 3. 长内容表格单元格标记
    for td in soup.find_all("td"):
        if len(td.get_text()) > 80:
            existing = td.get("class", [])
            if isinstance(existing, str):
                existing = [existing]
            td["class"] = existing + ["long-content"]

    return str(soup)


def build_page(html_fragment: str, css_content: str) -> str:
    """组装完整 HTML 页面。字体由 CSS @font-face 管理，路径由 _resolve_font_url() 处理。"""
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<style>
{css_content}
</style>
</head>
<body>
<div class="markdown-body">
{html_fragment}
</div>
</body>
</html>"""


def generate_pdf(html_content: str, output_path: str, base_url: Optional[str] = None):
    """调用 WeasyPrint 生成 PDF"""
    try:
        from weasyprint import HTML as WeasyHTML
    except ImportError:
        raise ImportError(
            "WeasyPrint 未安装。请运行: pip install weasyprint\n"
            "或使用 Pandoc 回退: pandoc input.md -o output.pdf --pdf-engine=xelatex"
        )
    kwargs: dict = {"string": html_content}
    if base_url:
        kwargs["base_url"] = base_url
    WeasyHTML(**kwargs).write_pdf(output_path)


def main():
    parser = argparse.ArgumentParser(
        description="HTML + CSS → PDF (via WeasyPrint)"
    )
    parser.add_argument(
        "--html", required=True, help="HTML fragment file (from markdown-it)"
    )
    parser.add_argument(
        "--css", required=True, help="CSS theme entry file (e.g. themes/default/theme.css)"
    )
    parser.add_argument(
        "-o", "--output", required=True, help="Output PDF path"
    )
    parser.add_argument(
        "--base-url",
        default=None,
        help="Base URL for resolving relative resources (e.g. images)",
    )
    args = parser.parse_args()

    # 读取输入文件
    html_fragment = Path(args.html).read_text(encoding="utf-8")

    # 读取 CSS 主题 — 需要递归展开 @import
    css_content = _resolve_css(args.css)

    # 后处理（ASCII art、URL 折行、表格标记）
    html_fragment = postprocess(html_fragment)

    # Mermaid 图表渲染为 PNG（本地 mmdc + Chromium，不可用则降级为代码块）
    html_fragment, mermaid_warning = _render_mermaid_blocks(html_fragment)

    # 组装完整 HTML 页面
    full_html = build_page(html_fragment, css_content)

    # 输出目录校验
    output_path = Path(args.output).resolve()
    if not output_path.parent.exists():
        print(f"错误：输出目录不存在: {output_path.parent}", file=sys.stderr)
        sys.exit(1)
    if not os.access(output_path.parent, os.W_OK):
        print(f"错误：输出目录不可写: {output_path.parent}", file=sys.stderr)
        sys.exit(1)

    # 生成 PDF
    generate_pdf(full_html, str(output_path), args.base_url)

    if mermaid_warning:
        print(mermaid_warning, file=sys.stderr)

    print(f"PDF generated: {output_path}")


def _resolve_css(entry_path: str) -> str:
    """
    读取 CSS 入口文件，递归展开 @import 规则。
    WeasyPrint 的 @import 在处理相对路径时可能出问题，
    这里手动内联所有 CSS 内容。
    """
    entry = Path(entry_path)
    base_dir = entry.parent
    resolved = []
    _resolve_imports(entry, base_dir, resolved, set())
    return "\n".join(resolved)


def _resolve_imports(
    css_file: Path, base_dir: Path, output: list[str], visited: set[str]
):
    """递归展开 CSS @import"""
    abs_path = str(css_file.resolve())
    if abs_path in visited:
        return
    visited.add(abs_path)

    content = css_file.read_text(encoding="utf-8")
    # 将 @font-face 中的相对 url() 转为绝对 file:// URL
    content = _resolve_font_url(content, css_file.parent)
    lines = content.split("\n")

    for line in lines:
        stripped = line.strip()
        # 匹配 @import "file.css" 或 @import url("file.css")
        # 支持带 media query 的 @import（如 @import "file.css" screen;）
        m = re.match(
            r'@import\s+(?:url\(["\']?)?["\']([^"\')\s]+)["\'](?:\))?[^;]*;',
            stripped,
        )
        if m:
            imported = m.group(1)
            imported_path = base_dir / imported
            if imported_path.exists():
                _resolve_imports(imported_path, imported_path.parent, output, visited)
            else:
                # 保留原始 @import 给 WeasyPrint 处理
                output.append(stripped)
        else:
            output.append(line.rstrip())


# ── CSS 路径修正 ───────────────────────────────────────────────────────────

def _resolve_font_url(css_content: str, base_dir: Path) -> str:
    """
    将 @font-face 块中的相对 url() 转为绝对 file:// URL。

    WeasyPrint 内联 CSS 时，url() 按 HTML 页面的 base_url（即 Markdown 源文件目录）
    解析而非按 CSS 文件目录，导致捆绑字体路径错误。此函数提前将相对 url()
    转换为 file:// 绝对路径。
    """
    import re

    def _replace_url(match):
        prefix = match.group(1)  # url(
        font_file = match.group(2)  # fonts/FontName.ttf 或 ../shared/fonts/FontName.ttf
        suffix = match.group(3)  # ) format(...)
        resolved = (base_dir / font_file).resolve()
        if resolved.exists():
            return f'{prefix}"file://{resolved}"{suffix}'
        return match.group(0)  # 文件不存在则保持原样

    # 匹配 @font-face 块内的 src: url("relative/path") 模式
    css_content = re.sub(
        r'(url\()["\']?([^"\')\s]+\.(?:ttf|otf|woff2?))["\']?(\))',
        _replace_url,
        css_content,
        flags=re.IGNORECASE,
    )
    return css_content


if __name__ == "__main__":
    main()
