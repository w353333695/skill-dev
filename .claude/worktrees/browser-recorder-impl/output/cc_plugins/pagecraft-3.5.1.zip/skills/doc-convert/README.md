# doc-convert — Markdown → PDF 转换插件

将 Markdown 文件通过 markdown-it + WeasyPrint 转换为高质量 PDF。

## 特性

- **精确排版**：CSS @page 分页控制、代码块折行、分页保护
- **语法高亮**：190+ 语言 highlight.js CSS class 着色
- **Mermaid 图表**：Mermaid 流程图自动渲染为矢量图
- **ASCII art 保护**：Box Drawing 字符自动检测，禁止折行
- **中英混排**：Noto CJK 字体族（衬线正文 + 无衬线标题 + 等宽代码）
- **自包含**：Node.js 依赖 + WeasyPrint 均已捆绑，跨环境开箱即用

## 使用

### 显式命令

```text
/md2pdf source.md
/md2pdf source.md -o output.pdf
```

### 自然语言

```text
"把这个 Markdown 转成 PDF"
"帮我把这个 .md 文件导出为 PDF"
```

## 转换管线

```
Markdown → markdown-it (Node.js) → HTML 片段 → CSS 主题注入 → WeasyPrint (Python) → PDF
```

## 依赖

- **Node.js** ≥ 18 + 本地 node_modules（已捆绑）
- **Python 3** ≥ 3.8 + WeasyPrint（已捆绑在 lib/pypkgs/）
- **字体**: Noto CJK 字体族（推荐）
- **系统库**: cairo/pango/fontconfig（Linux 默认已安装）

## 版本

1.0.0 — 单引擎 WeasyPrint，全依赖捆绑
