#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
"""IBM SVC / Spectrum Virtualize 监控采集脚本

双通道架构：
- v8.1.3+ 优先 REST API（HTTPS JSON）
- v7.x / 早期 v8 回退 SSH CLI（CSV 解析）

兼容 Python 2.7.18
"""
import os
import re
import ssl
import json
import time
import csv
import paramiko
from StringIO import StringIO
from collections import OrderedDict

# ============================================================================
# 调试参数（环境变量未设置时使用默认值）
# ============================================================================
ip = os.environ.get("EASYOPS_COLLECTOR_ip")
username = os.environ.get("EASYOPS_COLLECTOR_username")
password = os.environ.get("EASYOPS_COLLECTOR_password")
ssh_port = os.environ.get("EASYOPS_COLLECTOR_ssh_port")
api_port = os.environ.get("EASYOPS_COLLECTOR_api_port")

# ============================================================================
# 通用工具
# ============================================================================

# 容量/速率单位 → 换算到基准单位（容量统一到 MB，速率统一到 Gb）
# SVC CLI 输出常见单位：容量 TB/GB/MB/KB，端口速率 Gb
_UNIT_FACTORS = {
    'TB': 1024.0 * 1024.0,   # → MB
    'GB': 1024.0,            # → MB
    'MB': 1.0,               # → MB
    'KB': 1.0 / 1024.0,      # → MB
    'Gb': 1.0,               # → Gb（端口速率，原值即 Gb）
}


def safe_float(value, default=None):
    """安全转换为 float，自动剥离容量/速率单位（如 '36.3TB' → 36.3 * 因子）

    - 容量类（TB/GB/MB/KB）换算到 MB 后返回数值
    - 端口速率（Gb）返回原数值
    - 无单位或纯数字直接转 float
    """
    if value is None or value == '':
        return default
    try:
        if isinstance(value, (int, float)):
            return float(value)
        s = str(value).strip()
        # 匹配 数字 + 可选单位（单位大小写敏感：TB/GB/MB/KB vs Gb）
        m = re.match(r'^([0-9]*\.?[0-9]+)\s*(TB|GB|MB|KB|Gb|gb)?\s*$', s)
        if not m:
            return default
        num = float(m.group(1))
        unit = m.group(2)
        if unit and unit in _UNIT_FACTORS:
            return num * _UNIT_FACTORS[unit]
        return num
    except (ValueError, TypeError):
        return default


def safe_int(value, default=None):
    """安全转换为 int"""
    if value is None or value == '':
        return default
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


# ============================================================================
# SSH CLI 采集器（v7 / v8 通用）
# ============================================================================

class SshCollector(object):
    """通过 paramiko 执行 SSH CLI 命令，解析 CSV 输出

    替代原 sshpass + ssh 本地命令方案，复用单条 SSH 连接以减少建连开销，
    连接断开时自动重连。行为对齐原实现：
      - StrictHostKeyChecking=no / UserKnownHostsFile=/dev/null → AutoAddPolicy，不加载系统已知主机
      - ConnectTimeout=15 → connect(timeout=15)
      - ServerAliveInterval=10 → transport.set_keepalive(10)
      - 不分配 PTY（与原 ssh 不带 -tt 一致）
    """

    def __init__(self, ip_addr, user, pwd, port='22'):
        self.ip = ip_addr
        self.user = user
        self.pwd = pwd
        try:
            self.port = int(port)
        except (ValueError, TypeError):
            self.port = 22
        self._client = None

    def _connect(self):
        """建立新 SSH 连接（带重试 + 指数退避）

        SVC 在并发建连或网络抖动时偶发 'Error reading SSH protocol banner'，
        单次失败重试 3 次、退避 0.5/1/2 秒，提升首轮采集成功率。
        """
        last_err = None
        for attempt in range(3):
            try:
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(
                    self.ip,
                    port=self.port,
                    username=self.user,
                    password=self.pwd,
                    timeout=15,
                    allow_agent=False,
                    look_for_keys=False,
                    banner_timeout=30,
                )
                transport = client.get_transport()
                if transport is not None:
                    transport.set_keepalive(10)
                return client
            except Exception as e:
                last_err = e
                # 最后一次不再 sleep
                if attempt < 2:
                    time.sleep(0.5 * (2 ** attempt))
        raise last_err

    def _get_client(self):
        """返回可用连接，失效则重连"""
        if self._client is not None:
            transport = self._client.get_transport()
            if transport is not None and transport.is_active():
                return self._client
        self._client = self._connect()
        return self._client

    def close(self):
        """关闭连接"""
        if self._client is not None:
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None

    def execute(self, command, timeout=60):
        """执行 SSH 命令，返回 (stdout, err)；err 为 None 表示成功"""
        try:
            client = self._get_client()
        except Exception as e:
            return None, 'SSH connect failed: {}'.format(e)

        try:
            stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
            out = stdout.read()
            err = stderr.read()
            exit_code = stdout.channel.recv_exit_status()

            if isinstance(out, bytes):
                out = out.decode('utf-8', 'replace')
            if isinstance(err, bytes):
                err = err.decode('utf-8', 'replace')

            err = err.strip() if err else ''
            out = out.strip() if out else ''

            if exit_code != 0:
                err_lines = [l for l in err.split('\n') if l.strip()]
                if err_lines:
                    return None, '\n'.join(err_lines)
                return out, None
            return out, None
        except Exception as e:
            # 连接可能已失效，清空以便下次重连
            self._client = None
            return None, 'SSH exec failed: {}'.format(e)

    def query_csv(self, command, timeout=60):
        """执行 CLI 命令并按 SVC 三种输出格式自动解析，返回 list[dict]

        SVC CLI（-delim ,）有三种输出格式，需分别处理（误用 DictReader 会字段错位）：

        1. 键值对纵向格式（lssystem）：每行 `key,value`，首行不是表头。
           解析：按行 split 建 dict，返回单元素 list。

        2. 长表格式（lsnodestats/lssystemstats）：表头含 `stat_name`，
           每个指标占一行。解析：按分组键（node_id 或无）pivot 成宽表，
           `stat_name` → key、`stat_current` → value。

        3. 真表格式（lsmdiskgrp/lsvdisk/lsportfc）：标准表头 + 多数据行。
           解析：标准 DictReader。
        """
        stdout, err = self.execute(command + ' -delim ,', timeout)
        if err or not stdout:
            return [], err
        try:
            lines = [ln for ln in stdout.split('\n') if ln.strip()]
            if not lines:
                return [], None
            header = lines[0]
            cols = [c.strip() for c in header.split(',')]

            # 格式2：长表（含 stat_name 列）→ pivot
            if 'stat_name' in cols:
                return self._parse_long_table(lines, cols), None

            # 格式1：键值对纵向（首列是已知系统属性名，且无典型表头特征）
            # 判据：首列值在 SVC lssystem 已知 key 集合内，或行数 >1 且首列重复出现
            if self._is_kv_vertical(lines):
                return self._parse_kv_vertical(lines), None

            # 格式3：真表 → DictReader
            reader = csv.DictReader(StringIO(stdout))
            return [self._clean_row(row) for row in reader], None
        except Exception as e:
            return [], 'CSV parse error: {}'.format(str(e))

    @staticmethod
    def _is_kv_vertical(lines):
        """判别键值对纵向格式：首行仅 2 列，且首列值不像表头（表头通常含 _id/name 等）

        SVC lssystem 输出形如 `id,0000...\nname,SVC...\nstatus,online`，
        首列是 id/name/status/xxx_capacity 等属性名，而非 io_group_name 这类表头。
        """
        if len(lines) < 2:
            return False
        first = lines[0].split(',')
        if len(first) != 2:
            return False
        # 长表/真表表头通常 >2 列或含典型表头词；键值对首列是属性名（含字母/下划线，值不含）
        # 进一步判据：首行第二段（值）不是已知表头词，且后续行首列也是属性名风格
        key0 = first[0].strip().strip('"')
        val0 = first[1].strip().strip('"')
        # 值里若出现逗号分隔的多词或全大写典型表头，判为非 kv
        if key0 == '' or val0 == '':
            return False
        # 真表表头第一列常见值如 id/name/node_id；但真表表头行只有一行，kv 有多行 key
        # 关键区分：kv 格式从第 2 行起，首列都是新 key（不重复 id），且值是单值
        # 统计前 5 行首列，若彼此不同且每行恰好 2 列，判为 kv
        sample = lines[:min(6, len(lines))]
        if any(len(ln.split(',')) != 2 for ln in sample):
            return False
        keys = [ln.split(',')[0].strip().strip('"') for ln in sample]
        return len(set(keys)) == len(keys)  # 每行 key 不同 → kv 纵向

    @staticmethod
    def _parse_kv_vertical(lines):
        """解析键值对纵向格式：每行 `key,value` → 单个 dict，返回 [dict]"""
        d = {}
        for ln in lines:
            parts = ln.split(',')
            if len(parts) >= 2:
                k = parts[0].strip().strip('"')
                v = parts[1].strip().strip('"')
                if k:
                    d[k] = v
            elif len(parts) == 1:
                k = parts[0].strip().strip('"')
                if k:
                    d.setdefault(k, '')
        return [d] if d else []

    @staticmethod
    def _parse_long_table(lines, cols):
        """解析长表格式：按分组键 pivot stat_name→key、stat_current→value

        - lsnodestats：分组键 node_id（+node_name），每个节点一组宽表 dict
        - lssystemstats：无 node_id，全系统一组
        """
        idx = {c: i for i, c in enumerate(cols)}
        stat_name_i = idx.get('stat_name')
        stat_cur_i = idx.get('stat_current') if 'stat_current' in idx else idx.get('stat_peak')
        if stat_name_i is None or stat_cur_i is None:
            # 退化：按普通表返回
            reader = csv.DictReader(StringIO('\n'.join(lines)))
            return [SshCollector._clean_row(r) for r in reader]

        node_i = idx.get('node_id')
        node_name_i = idx.get('node_name')

        groups = OrderedDict()
        for ln in lines[1:]:
            parts = [p.strip().strip('"') for p in ln.split(',')]
            if len(parts) < len(cols):
                continue
            sname = parts[stat_name_i]
            sval = parts[stat_cur_i]
            # 跳过表头残留行（命令重跑/SVC 输出带重复表头时 sname='stat_name'）
            if sname == 'stat_name':
                continue
            if node_i is not None:
                gkey = parts[node_i]
                gname = parts[node_name_i] if node_name_i is not None else ''
                # 跳过 node_id 列名残留行
                if gkey == 'node_id':
                    continue
            else:
                gkey = '_system'
                gname = ''
            if gkey not in groups:
                groups[gkey] = {'_node_id': gkey, '_node_name': gname}
            groups[gkey][sname] = sval
        return list(groups.values())

    @staticmethod
    def _clean_row(row):
        """清理 CSV 行：去掉字段名前后空格，值去引号"""
        return {k.strip(): v.strip().strip('"') for k, v in row.items() if k}


# ============================================================================
# REST API 采集器（v8.1.3+）
# ============================================================================

class RestCollector(object):
    """通过 HTTPS REST API 采集，返回 JSON"""

    def __init__(self, ip_addr, user, pwd, port='7443'):
        self.base = 'https://{0}:{1}/rest'.format(ip_addr, port)
        self.user = user
        self.pwd = pwd
        self.token = None
        self._ctx = ssl._create_unverified_context()
        # 速率控制
        self._last_req = 0

    def _rate_limit(self):
        """简单速率限制：每秒最多 8 次请求"""
        elapsed = time.time() - self._last_req
        if elapsed < 0.125:
            time.sleep(0.125 - elapsed)
        self._last_req = time.time()

    def _request(self, path, data=None, method='POST'):
        """发送 HTTPS 请求，返回 JSON 响应"""
        import urllib2
        self._rate_limit()
        url = self.base + path
        body = json.dumps(data) if data else None
        req = urllib2.Request(url, data=body,
                              headers={'Content-Type': 'application/json'})
        if method != 'POST':
            req.get_method = lambda: method
        if self.token:
            req.add_header('X-Auth-Token', self.token)
        try:
            resp = urllib2.urlopen(req, context=self._ctx, timeout=30)
            return json.loads(resp.read())
        except urllib2.HTTPError as e:
            return {'error': 'HTTP {} {}'.format(e.code, e.reason)}
        except Exception as e:
            return {'error': str(e)}

    def authenticate(self):
        """认证获取 token"""
        resp = self._request('/auth')
        if resp.get('error'):
            return resp.get('error')
        self.token = resp.get('token')
        return None if self.token else 'No token in response'

    def post(self, command, params=None):
        """POST /rest/<command>，返回 result 列表"""
        resp = self._request('/' + command, data=params)
        if resp.get('error'):
            return [], resp.get('error')
        return resp.get('result', []), None


# ============================================================================
# SVC 采集器（统一入口）
# ============================================================================

class SvcMonitor(object):
    """SVC 监控采集器：自动探测版本，选择 REST 或 SSH 通道"""

    def __init__(self, ip_addr, user, pwd, ssh_p='22', api_p='7443'):
        self.ip = ip_addr
        self.ssh = SshCollector(ip_addr, user, pwd, ssh_p)
        self.api = None  # 延迟初始化
        self.api_user = user
        self.api_pwd = pwd
        self.api_port = api_p
        self.use_api = False
        self.code_level = ''
        self._detected = False

    def detect(self):
        """探测版本，选择采集通道：REST API 优先，SSH 兜底

        两条通道各自独立可用，互不前置依赖：
          - 先试 REST API（v8.1.3+）：认证 + API lssystem 取 code_level
          - API 不可用再试 SSH：SSH lssystem 取 code_level
          - 两者都失败才视为不可达
        """
        if self._detected:
            return

        # 1) REST API 优先：以「认证 + lssystem 有数据」作为通道可用判据
        api = RestCollector(self.ip, self.api_user, self.api_pwd, self.api_port)
        auth_err = api.authenticate()
        if auth_err is None:
            rows, _ = api.post('lssystem')
            if rows:
                self.api = api
                self.code_level = rows[0].get('code_level', '')
                self.use_api = True
                self._detected = True
                return
            # 认证通过但 lssystem 无数据，通道实际不可用，落回 SSH

        # 2) API 失败，回退 SSH（独立通道，不依赖 API）
        self.api = None  # API 通道未启用，保持 None
        stdout, err = self.ssh.execute('lssystem -delim ,', timeout=30)
        if err or not stdout:
            self._detected = True
            return  # SSH 也连不上，无法采集

        rows, _ = self.ssh.query_csv('lssystem')
        if rows and len(rows) > 0:
            self.code_level = rows[0].get('code_level', '')

        self.use_api = False
        self._detected = True

    # ------------------------------------------------------------------
    # 统一查询接口
    # ------------------------------------------------------------------

    def query(self, command, params=None):
        """统一查询：API 优先，失败回退 SSH"""
        if self.use_api and self.api:
            rows, err = self.api.post(command, params)
            if err is None and rows:
                return rows, None
        # 回退 SSH
        return self.ssh.query_csv(command)

    # ------------------------------------------------------------------
    # 系统概况
    # ------------------------------------------------------------------

    def collect_system(self):
        """采集系统级指标"""
        rows, _ = self.query('lssystem')
        if not rows or len(rows) == 0:
            return []

        r = rows[0]
        vals = {}

        # 运行状态: lssystem 无 status 字段，用 statistics_status=on 或能取到数据判 online
        # SVC 系统状态字段：statistics_status(on/off)；能正常采集即视为在线
        stat = str(r.get('statistics_status', '')).lower()
        vals['m_svc_status'] = 1 if (stat == 'on' or r.get('name')) else 0

        # 容量 (TB/GB → safe_float 统一到 MB → /1024 转 GB)
        # 字段名对齐 SVC 实际输出：used_volume 用 total_vdiskcopy_capacity
        for src, dst in [
            ('total_mdisk_capacity', 'm_svc_total_capacity'),
            ('total_used_capacity', 'm_svc_used_capacity'),
            ('total_free_space', 'm_svc_free_capacity'),
            ('total_vdisk_capacity', 'm_svc_volume_capacity'),
            ('total_vdiskcopy_capacity', 'm_svc_used_volume_capacity'),
        ]:
            v = safe_float(r.get(src, 0))
            if v:
                vals[dst] = round(v / 1024.0, 2)  # MB → GB

        results = []
        if vals:
            results.append({
                "dims": {"ip": self.ip},
                "vals": vals
            })

        # 系统性能指标（字段名对齐 lssystemstats 实际输出）
        perf_rows, _ = self.query('lssystemstats')
        if perf_rows and len(perf_rows) > 0:
            pr = perf_rows[0]
            pvals = {}
            for src, dst in [
                ('cpu_pc', 'm_svc_cpu_pct'),
                ('total_cache_pc', 'm_svc_cache_hit_pct'),
                ('vdisk_io', 'm_svc_total_iops'),
                ('vdisk_r_io', 'm_svc_read_iops'),
                ('vdisk_w_io', 'm_svc_write_iops'),
                ('vdisk_r_mb', 'm_svc_read_throughput'),
                ('vdisk_w_mb', 'm_svc_write_throughput'),
                ('vdisk_r_ms', 'm_svc_read_latency'),
                ('vdisk_w_ms', 'm_svc_write_latency'),
            ]:
                v = safe_float(pr.get(src))
                if v is not None:
                    pvals[dst] = round(v, 2)
            if pvals:
                results.append({
                    "dims": {"ip": self.ip},
                    "vals": pvals
                })

        return results

    # ------------------------------------------------------------------
    # 节点
    # ------------------------------------------------------------------

    def collect_nodes(self):
        """采集节点指标

        lsnodestats 经 pivot 后每节点一个 dict，字段名为原始 stat_name（cpu_pc/total_io 等），
        节点标识在 `_node_id`/`_node_name`。lsnodecanister 在旧版 SVC 不存在（exit 127），
        回退 lsnode 取节点状态与映射。
        """
        rows, _ = self.query('lsnodestats')
        # lsnodecanister 旧版 SVC 不存在，回退 lsnode（字段与 lsnodecanister 类似：id/name/status）
        nodes, err = self.query('lsnodecanister')
        if err or not nodes:
            nodes, _ = self.query('lsnode')
        node_map = {}
        node_status = {}
        if nodes:
            for n in nodes:
                nid = n.get('id', '')
                node_map[nid] = n.get('name', '')
                node_status[nid] = str(n.get('status', '')).lower()

        results = []
        for r in rows:
            # pivot 后节点 id 在 _node_id，兼容未 pivot 的 node_id/id
            node_id = r.get('_node_id', r.get('node_id', r.get('id', '')))
            node_name = r.get('_node_name') or node_map.get(node_id, 'node_' + str(node_id))
            vals = {}
            # 字段名对齐 lsnodestats 实际输出：total_io→vdisk_io，total_cache_mb→vdisk_mb
            for src, dst in [
                ('cpu_pc', 'm_svc_node_cpu_pct'),
                ('vdisk_io', 'm_svc_node_iops'),
                ('vdisk_mb', 'm_svc_node_throughput'),
            ]:
                v = safe_float(r.get(src))
                if v is not None:
                    vals[dst] = round(v, 2)

            # 节点状态：lsnodestats 无 status，取 lsnodecanister/lsnode 的状态
            status = node_status.get(node_id, str(r.get('status', '')).lower())
            vals['m_svc_node_status'] = 1 if status == 'online' or status == 'active' else 0

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "node_name": node_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # 存储池
    # ------------------------------------------------------------------

    def collect_pools(self):
        """采集存储池容量"""
        rows, _ = self.query('lsmdiskgrp')
        results = []
        for r in rows:
            pool_name = r.get('name', '').strip() or 'pool_' + str(r.get('id', 'unknown'))
            vals = {}
            # 容量字段（TB/GB → safe_float 统一到 MB → /1024 转 GB）
            for src, dst in [
                ('capacity', 'm_svc_pool_capacity'),
                ('free_capacity', 'm_svc_pool_free'),
                ('used_capacity', 'm_svc_pool_used'),
                ('real_capacity', 'm_svc_pool_real_capacity'),
            ]:
                v = safe_float(r.get(src, 0))
                if v:
                    vals[dst] = round(v / 1024.0, 2)  # MB → GB

            # overallocation 是百分比（96 = 96%），不除 1024
            overalloc = safe_float(r.get('overallocation', 0))
            if overalloc is not None:
                vals['m_svc_pool_overalloc'] = round(overalloc, 2)

            status = str(r.get('status', '')).lower()
            vals['m_svc_pool_status'] = 1 if status == 'online' else 0

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "pool_name": pool_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # 卷
    # ------------------------------------------------------------------

    def collect_volumes(self):
        """采集卷状态与用量"""
        rows, _ = self.query('lsvdisk')
        results = []
        for r in rows:
            vol_name = r.get('name', '').strip() or 'vdisk_' + str(r.get('id', 'unknown'))
            vals = {}

            for src, dst in [
                ('capacity', 'm_svc_vol_capacity'),
                ('used_capacity', 'm_svc_vol_used'),
                ('real_capacity', 'm_svc_vol_real_capacity'),
                ('se_used_capacity', 'm_svc_vol_se_used'),
            ]:
                v = safe_float(r.get(src, 0))
                if v:
                    vals[dst] = round(v / 1024.0, 2)  # MB → GB

            status = str(r.get('status', '')).lower()
            vals['m_svc_vol_status'] = 1 if status == 'online' else 0

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "vol_name": vol_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # 控制器
    # ------------------------------------------------------------------

    def collect_canisters(self):
        """采集控制器状态与温度"""
        rows, _ = self.query('lsenclosurecanister')
        results = []
        for r in rows:
            can_id = str(r.get('id', '')).strip()
            enc_id = str(r.get('enclosure_id', '')).strip()
            can_name = 'encl{0}_canister{1}'.format(enc_id, can_id) if enc_id else 'canister_' + can_id

            vals = {}
            status = str(r.get('status', '')).lower()
            vals['m_svc_canister_status'] = 1 if status == 'online' else 0

            temp = safe_float(r.get('temp_c', r.get('temperature')))
            if temp is not None:
                vals['m_svc_canister_temp'] = temp

            fault = str(r.get('fault', '')).lower()
            vals['m_svc_canister_fault'] = 1 if fault in ('yes', 'true', '1') else 0

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "canister_name": can_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # 电源
    # ------------------------------------------------------------------

    def collect_psus(self):
        """采集电源模块状态"""
        rows, _ = self.query('lsenclosurepsu')
        results = []
        for r in rows:
            psu_id = str(r.get('id', '')).strip()
            enc_id = str(r.get('enclosure_id', '')).strip()
            psu_name = 'encl{0}_psu{1}'.format(enc_id, psu_id) if enc_id else 'psu_' + psu_id

            vals = {}
            status = str(r.get('status', '')).lower()
            vals['m_svc_psu_status'] = 1 if status == 'online' else 0

            fault = str(r.get('fault', '')).lower()
            vals['m_svc_psu_fault'] = 1 if fault in ('yes', 'true', '1') else 0

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "psu_name": psu_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # 电池
    # ------------------------------------------------------------------

    def collect_batteries(self):
        """采集电池状态"""
        rows, _ = self.query('lsenclosurebattery')
        results = []
        for r in rows:
            bat_id = str(r.get('id', '')).strip()
            enc_id = str(r.get('enclosure_id', '')).strip()
            bat_name = 'encl{0}_bat{1}'.format(enc_id, bat_id) if enc_id else 'battery_' + bat_id

            vals = {}
            status = str(r.get('status', '')).lower()
            vals['m_svc_battery_status'] = 1 if status == 'online' else 0

            charging = str(r.get('charging_status', '')).lower()
            vals['m_svc_battery_charging'] = 1 if charging in ('charging', 'yes', '1') else 0

            eol = str(r.get('end_of_life', '')).lower()
            vals['m_svc_battery_eol'] = 1 if eol in ('yes', 'true', '1') else 0

            fault = str(r.get('fault', '')).lower()
            vals['m_svc_battery_fault'] = 1 if fault in ('yes', 'true', '1') else 0

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "battery_name": bat_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # 物理磁盘
    # ------------------------------------------------------------------

    def collect_drives(self):
        """采集物理磁盘状态"""
        rows, _ = self.query('lsdrive')
        results = []
        for r in rows:
            drive_name = r.get('name', '').strip() or 'drive_' + str(r.get('id', 'unknown'))

            vals = {}
            status = str(r.get('status', '')).lower()
            vals['m_svc_drive_status'] = 1 if status == 'online' else 0

            cap = safe_float(r.get('capacity', 0))
            if cap:
                vals['m_svc_drive_capacity'] = round(cap / 1024.0, 2)  # MB → GB

            fault = str(r.get('fault', '')).lower()
            vals['m_svc_drive_fault'] = 1 if fault in ('yes', 'true', '1') else 0

            tech = r.get('tech_type', '')
            use = r.get('use', '')

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "drive_name": drive_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # FC 端口
    # ------------------------------------------------------------------

    def collect_fc_ports(self):
        """采集 FC 端口状态"""
        rows, _ = self.query('lsportfc')
        results = []
        for r in rows:
            port_id = str(r.get('id', '')).strip()
            port_name = 'fc_' + port_id

            vals = {}
            status = str(r.get('port_status', r.get('status', ''))).lower()
            vals['m_svc_fc_port_status'] = 1 if status == 'active' or status == 'online' else 0

            # lsportfc 速率字段为 port_speed（值如 '8Gb'），safe_float 自动剥离 Gb 单位
            speed = safe_float(r.get('port_speed', r.get('speed')))
            if speed is not None:
                vals['m_svc_fc_port_speed'] = speed

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "port_name": port_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # IP 端口
    # ------------------------------------------------------------------

    def collect_ip_ports(self):
        """采集 IP 端口状态"""
        rows, _ = self.query('lsportip')
        results = []
        for r in rows:
            port_id = str(r.get('id', '')).strip()
            port_name = 'ip_' + port_id

            vals = {}
            state = str(r.get('state', r.get('status', ''))).lower()
            vals['m_svc_ip_port_status'] = 1 if state == 'configured' or state == 'online' else 0

            if vals:
                results.append({
                    "dims": {"ip": self.ip, "port_name": port_name},
                    "vals": vals
                })
        return results

    # ------------------------------------------------------------------
    # 事件日志
    # ------------------------------------------------------------------

    def collect_events(self):
        """采集未处理告警事件数

        优先 lsalert (v8.3+)，回退 lseventlog。
        SSH 通道 query_csv 不透传 params，故 lseventlog 回退时直接拼
        `-filtervalue status=active -delim ,` 让 SVC 端过滤，避免拉全量历史事件
        导致 info 虚高；解析后再按 fixed/by_exception 状态兜底过滤。
        """
        # 优先 lsalert (v8.3+)
        alerts, alert_err = self.query('lsalert')
        if alerts:
            crit = sum(1 for a in alerts
                       if str(a.get('severity', '')).lower() in ('critical', 'error'))
            warn = sum(1 for a in alerts
                       if str(a.get('severity', '')).lower() in ('warning', 'warn'))
            info = len(alerts) - crit - warn
        else:
            # lsalert 不可用（旧版/受限 shell），回退 lseventlog，服务端过滤 active
            events, _ = self.query('lseventlog -filtervalue status=active')
            crit = 0
            warn = 0
            info = 0
            for e in events:
                sev = str(e.get('severity', '')).lower()
                # 兜底：仅统计未处理事件（fixed/by_exception 的事件已处理，跳过）
                estatus = str(e.get('status', '')).lower()
                if estatus and estatus not in ('active', 'open', ''):
                    continue
                if sev in ('critical', 'error'):
                    crit += 1
                elif sev in ('warning', 'warn'):
                    warn += 1
                else:
                    info += 1

        return [{
            "dims": {"ip": self.ip},
            "vals": {
                "m_svc_alerts_critical": crit,
                "m_svc_alerts_warning": warn,
                "m_svc_alerts_info": info,
            }
        }]

    # ------------------------------------------------------------------
    # 总入口
    # ------------------------------------------------------------------

    def collect_all(self):
        """执行全部采集"""
        self.detect()
        info = []

        # 系统概况
        try:
            info.extend(self.collect_system())
        except Exception as e:
            pass

        # 节点
        try:
            info.extend(self.collect_nodes())
        except Exception as e:
            pass

        # 存储池
        try:
            info.extend(self.collect_pools())
        except Exception as e:
            pass

        # FC 端口
        try:
            info.extend(self.collect_fc_ports())
        except Exception as e:
            pass

        # 告警
        try:
            info.extend(self.collect_events())
        except Exception as e:
            pass

        return info


# ============================================================================
# 主入口
# ============================================================================

if __name__ == '__main__':
    monitor = SvcMonitor(ip, username, password, ssh_port, api_port)
    info = monitor.collect_all()
    print(json.dumps(info, ensure_ascii=False))
