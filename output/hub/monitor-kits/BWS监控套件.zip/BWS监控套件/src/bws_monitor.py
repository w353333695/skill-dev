#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
"""
宝兰德BES WEB SERVER (BWS) 监控采集脚本
通过 HTTP 状态接口采集 BWS 运行状态

支持两种状态接口:
1. /vhost_status - JSON格式，提供连接、共享内存、虚拟主机、上游服务详细指标
2. /bws_status - 文本格式，提供基本连接指标（降级模式）
"""
import os
import json
import re
import requests

# 从环境变量获取参数
ip = os.environ.get("EASYOPS_COLLECTOR_ip", "127.0.0.1")
port = os.environ.get("EASYOPS_COLLECTOR_port", "80")
status_url = os.environ.get("EASYOPS_COLLECTOR_status_url", "/vhost_status")
install_path = os.environ.get("EASYOPS_COLLECTOR_installPath", "")

# 禁用 InsecureRequestWarning（内网监控场景）
requests.packages.urllib3.disable_warnings(
    requests.packages.urllib3.exceptions.InsecureRequestWarning
)


def fetch_url(url):
    """请求URL并返回响应内容"""
    try:
        resp = requests.get(url, timeout=30, verify=False)
        return True, resp.text, resp.status_code
    except Exception as e:
        return False, str(e), -1


def parse_vhost_status(data):
    """解析 /vhost_status JSON响应，返回完整指标"""
    info = []
    dims_base = {"ip": ip, "installPath": install_path}

    # 连接指标
    conn = data.get("connections", {})
    conn_vals = {
        "mon_active_connections": conn.get("active", 0),
        "mon_reading_connections": conn.get("reading", 0),
        "mon_writing_connections": conn.get("writing", 0),
        "mon_waiting_connections": conn.get("waiting", 0),
        "mon_accepted_connections": conn.get("accepted", 0),
        "mon_handled_connections": conn.get("handled", 0),
        "mon_total_requests": conn.get("requests", 0),
        "mon_status": 1
    }
    info.append({"dims": dict(dims_base), "vals": conn_vals})

    # 共享内存指标
    sz = data.get("sharedZones", {})
    if sz:
        sz_vals = {
            "mon_shared_zone_max_size": sz.get("maxSize", 0),
            "mon_shared_zone_used_size": sz.get("usedSize", 0),
            "mon_shared_zone_used_node": sz.get("usedNode", 0)
        }
        info.append({"dims": dict(dims_base), "vals": sz_vals})

    # 虚拟主机指标
    server_zones = data.get("serverZones", {})
    for zone_name, zone_data in server_zones.items():
        sz_dims = dict(dims_base)
        sz_dims["server_zone"] = zone_name
        responses = zone_data.get("responses", {})
        sz_vals = {
            "mon_server_requests": zone_data.get("requestCounter", 0),
            "mon_server_in_bytes": zone_data.get("inBytes", 0),
            "mon_server_out_bytes": zone_data.get("outBytes", 0),
            "mon_server_response_1xx": responses.get("1xx", 0),
            "mon_server_response_2xx": responses.get("2xx", 0),
            "mon_server_response_3xx": responses.get("3xx", 0),
            "mon_server_response_4xx": responses.get("4xx", 0),
            "mon_server_response_5xx": responses.get("5xx", 0),
            "mon_server_request_msec": zone_data.get("requestMsec", 0)
        }
        info.append({"dims": sz_dims, "vals": sz_vals})

    # 上游服务指标
    upstream_zones = data.get("upstreamZones", {})
    for group_name, servers in upstream_zones.items():
        for server_data in servers:
            us_dims = dict(dims_base)
            us_dims["upstream_group"] = group_name
            us_dims["upstream_server"] = server_data.get("server", "unknown")
            responses = server_data.get("responses", {})
            us_vals = {
                "mon_upstream_requests": server_data.get("requestCounter", 0),
                "mon_upstream_in_bytes": server_data.get("inBytes", 0),
                "mon_upstream_out_bytes": server_data.get("outBytes", 0),
                "mon_upstream_response_1xx": responses.get("1xx", 0),
                "mon_upstream_response_2xx": responses.get("2xx", 0),
                "mon_upstream_response_3xx": responses.get("3xx", 0),
                "mon_upstream_response_4xx": responses.get("4xx", 0),
                "mon_upstream_response_5xx": responses.get("5xx", 0),
                "mon_upstream_request_msec": server_data.get("requestMsec", 0),
                "mon_upstream_response_msec": server_data.get("responseMsec", 0)
            }
            info.append({"dims": us_dims, "vals": us_vals})

    return info


def parse_bws_status(content):
    """解析 /bws_status 文本响应（降级模式），仅返回基本连接指标"""
    info = []
    dims_base = {"ip": ip, "installPath": install_path}

    vals = {"mon_status": 1}

    active_match = re.search(r'Active connections:\s*(\d+)', content)
    if active_match:
        vals["mon_active_connections"] = int(active_match.group(1))

    stats_match = re.search(
        r'server accepts handled requests\s*\n\s*(\d+)\s+(\d+)\s+(\d+)', content
    )
    if stats_match:
        vals["mon_accepted_connections"] = int(stats_match.group(1))
        vals["mon_handled_connections"] = int(stats_match.group(2))
        vals["mon_total_requests"] = int(stats_match.group(3))

    rww_match = re.search(
        r'Reading:\s*(\d+)\s+Writing:\s*(\d+)\s+Waiting:\s*(\d+)', content
    )
    if rww_match:
        vals["mon_reading_connections"] = int(rww_match.group(1))
        vals["mon_writing_connections"] = int(rww_match.group(2))
        vals["mon_waiting_connections"] = int(rww_match.group(3))

    info.append({"dims": dims_base, "vals": vals})
    return info


if __name__ == "__main__":
    info = []

    # 先尝试 HTTPS，失败则回退 HTTP
    for protocol in ["https", "http"]:
        base_url = "{0}://{1}:{2}".format(protocol, ip, port)

        # 先尝试配置的状态接口（完整指标）
        vhost_url = base_url + status_url
        success, content, code = fetch_url(vhost_url)

        if success:
            try:
                data = json.loads(content)
                info = parse_vhost_status(data)
                break
            except (ValueError, KeyError):
                info = []

            # 如果状态接口解析失败，尝试 /bws_status（基本指标）
            if not info:
                bws_url = base_url + "/bws_status"
                success2, content2, code2 = fetch_url(bws_url)

                if success2:
                    info = parse_bws_status(content2)
                    break

    # 两种协议均失败
    if not info:
        dims = {"ip": ip, "installPath": install_path}
        info.append({
            "dims": dims,
            "vals": {
                "mon_status": 0,
                "mon_error_msg": "HTTPS/HTTP requests to {0}:{1} all failed".format(ip, port)
            }
        })

    print(json.dumps(info, ensure_ascii=False))
