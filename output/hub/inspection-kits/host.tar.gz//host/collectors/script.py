instanceid: 64d480c8052d1
collectorid: 5d4d390f59b8ce514171443d
pluginid: host
name: script
content: "#!/usr/local/easyops/python/bin/python\n# -*- coding: utf-8 -*-\n\n# stdlib\nimport
  os\nimport time\nimport socket\nimport platform\nimport re\nimport copy\nimport
  sys\nimport json\nimport subprocess\nimport getpass\n\n# 3p\nif platform.system().lower()
  == 'windows':\n    import wmi\n    \n    msplatform = True\nelse:\n    msplatform
  = False\n# is linux\nif platform.system().lower() == 'linux':\n    linuxplatform
  = True\nelse:\n    linuxplatform = False\n# is aix\nif platform.system().lower()
  == 'aix':\n    aixplatform = True\nelse:\n    aixplatform = False\n\ntry:\n    import
  psutil\n\n    HAS_PSUTIL = True\nexcept ImportError:\n    HAS_PSUTIL = False\ntry:\n
  \   from cpuinfo import cpuinfo\nexcept Exception:\n    pass\n\n\n# 巡检基类型\nclass
  BaseInspection():\n\n    def __init__(self):\n        pass\n\n    def single_command(self,
  command, stderr=subprocess.STDOUT, shell=True):\n        try:\n            user
  = getpass.getuser()\n            if user != 'root' and not re.match('\\.|source|export',
  command):\n                command = 'sudo ' + command\n            result = subprocess.check_output(command,
  stderr=stderr, shell=shell)\n            return True, result.rstrip(os.linesep)\n
  \       except subprocess.CalledProcessError, e:\n            result = '%s: %s'
  % (e, e.output)\n            return False, result.rstrip(os.linesep)\n\n    # 获取前10cpu使用\n
  \   def get_top_process_cpu(self, metric_group_id='cpu_top_process', dims_id='process_pid'):\n
  \       # 如果是linux或者aix，就执行下边的步骤\n        cmd = \" ps -eo user,pid,pcpu,args | sed
  '1d' | sort -n -k3 | tail -10 | sort -nr -k3 \"\n        success, cmd_ret = self.single_command(cmd)\n
  \       ret = []\n        if success:\n            processes = cmd_ret.split('\\n')\n
  \           for process in processes:\n                process = process.strip()\n
  \               process_info = re.split(r'\\s*', process, 3)\n                user
  = process_info[0]\n                pid = process_info[1]\n                cpu =
  process_info[2]\n                process_name = process_info[3]\n                #process_name
  = re.findall(r'\\d*:\\d*\\s(.*)', process)[0]\n                data = {\n                    \"vals\":
  [\n                        {\"id\": \"user\", \"value\": user},\n                        {\"id\":
  \"process_cpu_percent\", \"value\": round(float(cpu), 1)},\n                        {\"id\":
  \"process_name\", \"value\": process_name},\n                    ],\n                    \"dims\":
  [{\"id\": dims_id, \"value\": pid}],\n                    \"id\": metric_group_id,\n
  \               }\n                ret.append(data)\n            return ret\n\n\n
  \   # 获取前10内存使用\n    def get_top_process_mem(self, metric_group_id='mem_top_process',
  dims_id='process_pid'):\n        cmd = \"  ps -eo user,pid,pmem,args | sed '1d'
  | sort -n -k3 | tail -10 | sort -nr -k3 \"\n        success, cmd_ret = self.single_command(cmd)\n
  \       ret = []\n        if success:\n            processes = cmd_ret.split('\\n')\n
  \           for process in processes:\n                process = process.strip()\n
  \               process_info = re.split(r'\\s*', process, 3)\n                user
  = process_info[0]\n                pid = process_info[1]\n                mem =
  process_info[2]\n                process_name = process_info[3]\n                #process_name
  = re.findall(r'\\d*:\\d*\\s(.*)', process)[0]\n                data = {\n                    \"vals\":
  [\n                        {\"id\": \"user\", \"value\": user},\n                        {\"id\":
  \"process_mem_percent\", \"value\": round(float(mem),1)},\n                        {\"id\":
  \"process_name\", \"value\": process_name},\n                    ],\n                    \"dims\":
  [{\"id\": dims_id, \"value\": pid}],\n                    \"id\": metric_group_id,\n
  \               }\n                ret.append(data)\n            # print 'get_top_process_cpu:',
  json.dumps(ret)\n            return ret\n\n\nclass InspectionLinuxWin(BaseInspection):\n
  \   def __init__(self):\n        pass\n\n    def linux_get_cpu_num(self):\n        cmd
  = 'cat /proc/cpuinfo | grep -i \"processor\" | wc -l'\n        success, com_ret
  = self.single_command(cmd)\n        if success:\n            return com_ret\n        else:\n
  \           return None\n\n    def linux_get_disk_type(self):\n        cmd = 'df
  -Th | grep \"^/dev\" | awk \\'{print $2}\\''\n        success, com_ret = self.single_command(cmd)\n
  \       if success:\n            return \",\".join(list(set(com_ret.splitlines())))\n
  \       else:\n            return None\n\n    def linux_get_user_sys_cpu(self):\n
  \       cmd = 'top -bi -n 1 | grep \"us,\"'\n        success, com_ret = self.single_command(cmd)\n
  \       if success:\n            com_ret = com_ret.split(\"pu(s):\")[1]\n            us_cpu
  = com_ret.split(\"us,\")[0].strip(\"% \")\n            sys_cpu = com_ret.split(\"sy,\")[0].split(\"us,\")[1].strip(\"%
  \")\n            return [us_cpu, sys_cpu]\n        else:\n            return None\n\n
  \   # 获取系统基本信息\n    def get_os_basic_info(self, metric_group_id='basic_info', dims_id=None):\n
  \       # win, linux\n        hostname = socket.gethostname()\n        os_version
  = platform.platform() + \" \" + platform.architecture()[0]\n        info = cpuinfo.get_cpu_info()\n
  \       if not msplatform:\n            cpu_num = self.linux_get_cpu_num()\n        else:\n
  \           import wmi\n            wmi_inst = wmi.WMI()\n            cpu_num =
  wmi_inst.Win32_ComputerSystem()[0].NumberOfLogicalProcessors\n        cpu_type =
  info['brand']\n\n        now = time.time()\n        os_uptime = int(now - psutil.boot_time())
  / 3600 / 24\n        if msplatform:\n            wmi_inst = wmi.WMI()\n            disk_fstype
  = \",\".join(set([p.FileSystem for p in wmi_inst.Win32_LogicalDisk(DriveType=3)]))\n
  \       else:\n            disk_fstype = self.linux_get_disk_type()\n        _,
  disk_info = self.get_disk_info()\n        # 硬盘除以 1024\n        disk_total = int(disk_info[0])\n
  \       disk_percent = disk_info[1]\n        mem = psutil.virtual_memory()\n        #
  内存必须除以 1000，不能位移\n        mem_total = int(getattr(mem, 'total', 0)) / 1000 / 1000
  / 1000\n        mem_percent = getattr(mem, 'percent', 0)\n        cpu_percent =
  float(psutil.cpu_percent(interval=2))\n        data = {\n            \"vals\": [\n
  \               {'id': 'hostname', 'value': hostname},\n                {'id': 'os_version',
  'value': os_version},\n                {'id': 'os_uptime', 'value': os_uptime},\n
  \               {'id': 'fs_type', 'value': disk_fstype},\n                {'id':
  'disk_total', 'value': disk_total},\n                {'id': 'memory', 'value': mem_total},\n
  \               {'id': 'cpu_num', 'value': str(cpu_num)},\n                {'id':
  'cpu_type', 'value': cpu_type},\n                {'id': 'cpu_percent', 'value':
  cpu_percent},\n                {'id': 'disk_percent', 'value': disk_percent},\n
  \               {'id': 'mem_percent', 'value': mem_percent},\n            ],\n            \"dims\":
  [],\n            \"id\": metric_group_id\n        }\n        if linuxplatform:\n
  \           os_log_error = self.check_sys_log_error()\n            data['vals'].append({\"id\":
  \"os_log_error\", \"value\": str(os_log_error)})\n            core_error = self.check_os_core_error()\n
  \           data['vals'].append({\"id\": \"core_error\", \"value\": str(core_error)})\n
  \           user_sys_cpu = self.linux_get_user_sys_cpu()\n            data['vals'].append({\"id\":
  \"us_cpu\", \"value\": float(user_sys_cpu[0])})\n            data['vals'].append({\"id\":
  \"sys_cpu\", \"value\": float(user_sys_cpu[1])})\n        ret = [data]\n        return
  ret\n\n    # 获取内核参数\n    def get_os_core(self, metric_group_id='os_core', dims_id=None,
  file_path=\"/etc/sysctl.conf\"):\n        check_args = {\n            \"net.ipv4.ip_forward\":
  \"\",\n            \"net.ipv4.conf.default.rp_filter\": \"\",\n            \"net.ipv4.conf.default.accept_source_route\":
  \"\",\n            \"kernel.sysrq\": \"\",\n            \"net.ipv4.tcp_syncookies\":
  \"\",\n            \"net.ipv4.tcp_tw_recycle\": \"\",\n            \"net.ipv4.tcp_tw_reuse\":
  \"\",\n            \"kernel.msgmnb\": \"\",\n            \"kernel.msgmax\": \"\",\n
  \           \"kernel.shmmax\": \"\",\n            \"kernel.shmall\": \"\",\n        }\n
  \       if msplatform or aixplatform:\n            data = check_args\n        else:\n
  \           if not os.path.isfile(file_path):\n                return metric_group_id,
  dims_id, {0: check_args}\n            with open(file_path, \"rb\") as f:\n                content
  = f.readlines()\n            for line in content:\n                if not line.startswith(\"#\"):\n
  \                   for c_a in check_args:\n                        re_ret = re.search(r\"{}\\s+=(.*)\".format(c_a),
  line, re.IGNORECASE)\n                        if re_ret:\n                            check_args[c_a]
  = re_ret.group(1).strip()\n            data = check_args\n\n        # 构造指定格式的 data\n
  \       fake_dims_id = 0\n        data_fake_dims_id = {fake_dims_id: data}\n        return
  metric_group_id, dims_id, data_fake_dims_id\n\n    # 获取磁盘信息\n    def get_disk_info(self,
  metric_group_id='partition_info', dims_id='fsmountpoint'):\n        data, ret =
  {}, []\n        if not HAS_PSUTIL:\n            raise Exception(\"host easyops python
  has no psutil lib.\")\n        partitions = psutil.disk_partitions()\n        host_total_usedspace,
  host_total_diskspace, host_total_used_percent = 0, 0, 0\n        if partitions:\n
  \           for partition in partitions:\n                if 'cdrom' in partition.opts.lower():\n
  \                   continue\n                if 'removable' in partition.opts.lower():\n
  \                   continue\n                # 光盘\n                if partition.fstype.lower()
  in ['hsf', 'iso9660', 'iso13490', 'udf']:\n                    continue\n                #
  虚拟分区\n                if partition.fstype.lower() in ['configfs', 'devfs', 'debugfs',
  'kernfs', 'procfs', 'specfs', 'sysfs',\n                                                'tmpfs',
  'winfs']:\n                    continue\n                # custom\n                if
  partition.fstype.lower() in ['proc', 'binfmt_misc', 'devpts']:\n                    continue\n\n
  \               # df -h 第一列是 fsname\n                fsname = partition.device\n
  \               mountpoint = partition.mountpoint\n                fstype = partition.fstype\n
  \               usage = psutil.disk_usage(mountpoint)\n                total = usage.total
  >> 30\n                used = usage.used >> 30\n                temp = dict(\n                    vals=[\n
  \                       {\"id\": \"fstype\", \"value\": fstype},\n                        {\"id\":
  \"fstotal\", \"value\": int(total)},\n                        {\"id\": \"fsused\",
  \"value\": int(used)},\n                        {\"id\": \"fsfree\", \"value\":
  int(usage.free) >> 30},\n                        {\"id\": \"fspercent\", \"value\":
  float(usage.percent)},\n                    ],\n                    dims=[\n                        {\"id\":
  \"fsmountpoint\", \"value\": mountpoint},\n                        {\"id\": \"fsname\",
  \"value\": fsname},\n                    ],\n                    id=metric_group_id,\n
  \               )\n                host_total_usedspace += used\n                host_total_diskspace
  += total\n                if host_total_diskspace:\n                    host_total_used_percent
  = float(host_total_usedspace * 100 / host_total_diskspace)\n                ret.append(temp)\n
  \           # print 'disk', ret\n        else:\n            if not msplatform:\n
  \               linux_disk = subprocess.check_output(\"df -Tk\", stderr=subprocess.STDOUT,
  shell=True)\n                adisk_state = linux_disk.split('\\n')\n                for
  index in range(1, len(adisk_state)):\n                    row = adisk_state[index]\n
  \                   if not row:\n                        continue\n                    states
  = row.split()\n                    if states[1] == '-':\n                        continue\n
  \                   if len(states) < 6:\n                        continue\n                    fsname
  = states[0]\n                    total = int(states[2]) >> 20\n                    used
  = int(states[3]) >> 20\n                    temp = dict(\n                        vals=[\n
  \                           {\"id\": \"fstype\", \"value\": states[1]},\n                            {\"id\":
  \"fstotal\", \"value\": total},\n                            {\"id\": \"fsused\",
  \"value\": used},\n                            {\"id\": \"fsfree\", \"value\": int(states[4])
  >> 20},\n                            {\"id\": \"fspercent\", \"value\": float(states[5].split(\"%\")[0])
  / 100},\n                        ],\n                        dims=[\n                            {\"id\":
  dims_id, \"value\": states[6]},\n                            {\"id\": \"fsname\",
  \"value\": fsname},\n                        ],\n                        id=metric_group_id,\n
  \                   )\n                    host_total_usedspace += used\n                    host_total_diskspace
  += total\n                    if host_total_diskspace:\n                        host_total_used_percent
  = float(host_total_usedspace * 100 / host_total_diskspace)\n                    ret.append(temp)\n
  \           else:\n                wmi_inst = wmi.WMI()\n                # DriveType:
  3, means local disk\n                for win_disk in wmi_inst.Win32_LogicalDisk(DriveType=3):\n
  \                   free = int(win_disk.FreeSpace) >> 30\n                    total
  = int(win_disk.Size) >> 30\n                    used = total - free\n                    used_percent
  = 0\n                    if total:\n                        used_percent = float(round(used
  * 100.0 / total))\n                    temp = dict(\n                        vals=[\n
  \                           {\"id\": \"fstype\", \"value\": win_disk.FileSystem},\n
  \                           {\"id\": \"fstotal\", \"value\": total},\n                            {\"id\":
  \"fsused\", \"value\": used},\n                            {\"id\": \"fsfree\",
  \"value\": free},\n                            {\"id\": \"fspercent\", \"value\":
  used_percent},\n                        ],\n                        dims=[\n                            {\"id\":
  dims_id, \"value\": win_disk.DeviceId},\n                            {\"id\": \"fsname\",
  \"value\": win_disk.Name},\n                        ],\n                        id=metric_group_id,\n
  \                   )\n                    host_total_usedspace += used\n                    host_total_diskspace
  += total\n                    if host_total_diskspace:\n                        host_total_used_percent
  = float(host_total_usedspace * 100 / host_total_diskspace)\n                    ret.append(temp)\n
  \       host_total = (host_total_diskspace, host_total_used_percent)\n        return
  ret, host_total\n\n    def get_inode_info(self, metric_group_id='inode_info', dims_id='fsmountpoint'):\n
  \       if msplatform:\n            return [{\n                \"vals\": [\n                    {\"id\":
  \"fstotal\", \"value\": None},\n                    {\"id\": \"fsused\", \"value\":
  None},\n                    {\"id\": \"fsfree\", \"value\": None},\n                    {\"id\":
  \"fspercent\", \"value\": None},\n                ],\n                \"dims\":
  [\n                    {\"id\": dims_id, \"value\": None},\n                    {\"id\":
  \"fsname\", \"value\": None},\n                ],\n                \"id\": metric_group_id\n
  \           }]\n        ret = []\n        success, com_result = self.single_command(\"df
  -i\")\n        if success:\n            inode_total, inode_free, inode_used, inode_per
  = 0, 0, 0, 0\n            inode_state = com_result.split('\\n')\n            for
  index in range(1, len(inode_state)):\n                row = inode_state[index]\n
  \               if not row:\n                    continue\n                states
  = row.split()\n                if len(states) < 6:\n                    continue\n
  \               # 兼容 suse 的 inode udev\n                if '-' in states[4]:\n                    continue\n
  \               inode_fsname = states[0]\n                inode_total = int(states[1])\n
  \               inode_used = int(states[2])\n                inode_free = int(states[3])\n
  \               inode_per = float(states[4][:-1])\n                temp = dict(\n
  \                   vals=[\n                        {\"id\": \"fstotal\", \"value\":
  inode_total},\n                        {\"id\": \"fsused\", \"value\": inode_used},\n
  \                       {\"id\": \"fsfree\", \"value\": inode_free},\n                        {\"id\":
  \"fspercent\", \"value\": inode_per},\n                    ],\n                    dims=[\n
  \                       {\"id\": dims_id, \"value\": states[5]},\n                        {\"id\":
  \"fsname\", \"value\": inode_fsname},\n                    ],\n                    id=metric_group_id,\n
  \               )\n                ret.append(temp)\n        return ret\n\n    def
  check_sys_log_error(self):\n        # 检查今天的系统日志是否有错误\n        # cmd 运行结果：没有错误，则返回0。\n
  \       cmd = 'v_time=`date | cut -c5-10`;cat /var/log/messages |grep \"$v_time\"
  |grep -iE \"crit|error\" --color'\n        success, cmd_ret = self.single_command(cmd)\n
  \       if success:\n            if not cmd_ret:\n                return \"0\"\n
  \           else:\n                return \"1\"\n        else:\n            if 'exit
  status 1' in cmd_ret:\n                return \"0\"\n            else:\n                return
  \"2\"\n\n    def check_os_core_error(self):\n        # 0 表示正常，无错误\n        cmd =
  'dmesg | grep -i error'\n        success, cmd_ret = self.single_command(cmd)\n        if
  success:\n            if not cmd_ret:\n                return \"0\"\n            else:\n
  \               return \"1\"\n        else:\n            if 'exit status 1' in cmd_ret:\n
  \               return \"0\"\n            else:\n                return \"2\"\n\n
  \   # 检查僵尸进程\n    def check_zom_process(self, metric_group_id='zom_process', dims_id='process_pid'):\n
  \       ret = []\n        # 通过 psutil 获取内存、僵尸的进程id\n        procs_mem_pids, procs_zom_pids
  = set(), set()\n        for pro in psutil.process_iter():\n            try:\n                if
  pro.status() == psutil.STATUS_ZOMBIE:\n                    procs_zom_pids.add(pro.pid)\n
  \           except (psutil.NoSuchProcess, psutil.AccessDenied) as e:\n                continue\n\n
  \       if procs_zom_pids:\n            for pid in procs_zom_pids:\n                try:\n
  \                   _p = psutil.Process(int(pid))\n                    _create_time
  = time.strftime(\"%Y-%m-%d %H:%M:%S\", time.localtime(_p.create_time()))\n                    data
  = {\n                        \"vals\": [\n                            {\"id\": \"process_name\",
  \"value\": _p.name()},\n                            {\"id\": \"process_user\", \"value\":
  _p.username()},\n                            {\"id\": \"process_mem_percent\", \"value\":
  float(_p.memory_percent())},\n                            {\"id\": \"is_zombie\",
  \"value\": \"yes\" if pid in procs_zom_pids else \"no\"},\n                            {\"id\":
  \"process_cmd\", \"value\": _p.exe()},\n                            {\"id\": \"create_time\",
  \"value\": _create_time},\n                        ],\n                        \"dims\":
  [{\"id\": dims_id, \"value\": str(_p.pid)}],\n                        \"id\": metric_group_id,\n
  \                   }\n                    ret.append(data)\n                except
  (psutil.NoSuchProcess, psutil.AccessDenied) as e:\n                    continue\n
  \       return ret\n\n    # 获取 load_avg\n    def get_cpu_load(self, metric_group_id='load_avgs',
  dims_id='load_time'):\n        if msplatform is False:\n            load = os.getloadavg()\n
  \           ret = {\n                'load_1': {'load_value': load[0]},\n                'load_5':
  {'load_value': load[1]},\n                'load_15': {'load_value': load[2]},\n
  \           }\n        else:\n            ret = {\n                'load_1': {'load_value':
  None},\n                'load_5': {'load_value': None},\n                'load_15':
  {'load_value': None},\n            }\n        return metric_group_id, dims_id, ret\n\n
  \   # 获取内存信息, 范例\n    def get_memory_info(self, metric_group_id='mem_info', dims_id='mems_type'):\n
  \       virtual_memory = psutil.virtual_memory()\n        swap_memory = psutil.swap_memory()\n
  \       # 在lxc机器，psutil<5.0版本，内存得到的是母机的\n        free = getattr(virtual_memory,
  'free', 0)\n        used = getattr(virtual_memory, 'used', 0)\n        total = getattr(virtual_memory,
  'total', 1)\n\n        ret = []\n        data_element_1 = {\n            \"vals\":
  [\n                {\"id\": \"mems_total\", \"value\": getattr(swap_memory, 'total',
  0) / 1024 / 1024},\n                {\"id\": \"mems_used\", \"value\": getattr(swap_memory,
  'used', 0) / 1024 / 1024},\n                {\"id\": \"mems_free\", \"value\": getattr(swap_memory,
  'free', 0) / 1024 / 1024},\n                {\"id\": \"mems_percent\", \"value\":
  getattr(swap_memory, 'percent', 0)},\n            ],\n            \"dims\": [{\"id\":
  dims_id, \"value\": \"swap\"}],\n            \"id\": metric_group_id,\n        }\n
  \       ret.append(data_element_1)\n        data_element_2 = {\n            \"vals\":
  [\n                {\"id\": \"mems_total\", \"value\": total / 1024 / 1024},\n                {\"id\":
  \"mems_used\", \"value\": used / 1024 / 1024},\n                {\"id\": \"mems_free\",
  \"value\": free / 1024 / 1024},\n                {\"id\": \"mems_percent\", \"value\":
  getattr(virtual_memory, 'percent', 0)},\n            ],\n            \"dims\": [{\"id\":
  dims_id, \"value\": \"physical\"}],\n            \"id\": metric_group_id,\n        }\n
  \       ret.append(data_element_2)\n        return ret\n\n    # 获取网卡信息\n    def
  get_eth_info(self, metric_group_id='network_info', dims_id=\"name\"):\n        ret,
  data = [], []\n        addrs = psutil.net_if_addrs()\n        stats = psutil.net_if_stats()\n
  \       for name, entries in addrs.iteritems():\n            eth = {\n                'name':
  name,\n                'mac': '00:00:00:00:00:00',\n                'ip': '',\n
  \               'mask': '',\n                'broadcast': '',\n                'status':
  'Unknown',\n                'speed': '0'\n            }\n            try:  # windows下中文\n
  \               eth['name'] = name.decode('gbk')\n            except Exception:\n
  \               eth['name'] = name\n            if name in stats:\n                eth['status']
  = 'Active' if int(stats[name].isup) else 'Inactive'\n                eth['speed']
  = str(stats[name].speed) if stats[name].isup else '0'\n\n            # 先获取这块网卡的mac地址(因为一个网卡可能有多个IP地址，
  下面有deepcopy逻辑， 所以提前填写mac地址)\n            for entry in entries:\n                if
  entry.family == psutil.AF_LINK:\n                    eth['mac'] = entry.address.upper()\n\n
  \           # 获取这块网卡的IP地址（可能有多个）\n            for entry in entries:\n                if
  entry.family == socket.AF_INET:\n                    if eth['ip']:  # 一个网卡多个ip，注意，这里不是虚拟网卡\n
  \                       data.append(copy.deepcopy(eth))\n                    eth['ip']
  = entry.address if entry.address else \"\"\n                    eth['mask'] = entry.netmask
  if entry.netmask else \"\"\n                    eth['broadcast'] = entry.broadcast
  if entry.broadcast else \"\"\n                else:  # 暂不采集IPV6\n                    continue\n
  \           data.append(eth)\n        # 如果虚拟网卡，则取其实际网卡的mac，避免都是00:00:00:00:00:00，常见虚拟网卡名称都带有\":\"\n
  \       for item in data:\n            # 是否虚拟网卡\n            if ':' not in item['name']:\n
  \               continue\n            # 已经有mac，一般不会进入到这个逻辑，网卡名本身就带有\":\"的情况。\n            if
  item['mac'] != '00:00:00:00:00:00':\n                continue\n            name
  = item['name'].rsplit(':', 1)[0]\n            for iitem in data:\n                if
  name == iitem['name']:\n                    item['mac'] = iitem['mac']\n                    break\n
  \       data.sort(key=lambda x: x['name'])\n        # 构造输出\n        for i_mac in
  data:\n            ret.append({\n                \"vals\": [\n                    {\"id\":
  \"ip\", \"value\": i_mac.get('ip',\"\")},\n                    {\"id\": \"broadcast\",
  \"value\": i_mac.get('broadcast', \"\")},\n                    {\"id\": \"mac\",
  \"value\": i_mac.get('mac', \"\")},\n                    {\"id\": \"mask\", \"value\":
  i_mac.get('mask',\"\")},\n                    {\"id\": \"status\", \"value\": i_mac.get('status',\"\")},\n
  \                   {\"id\": \"speed\", \"value\": str(i_mac.get('speed',\"\"))},\n
  \               ],\n                \"dims\": [\n                    {\"id\": dims_id,
  \"value\": i_mac['name']}\n                ],\n                \"id\": metric_group_id,\n
  \           })\n        return ret\n\n    # 构造输出\n    def create_output_old(self,
  metric_group_id, dims_id=None, data={}):\n        # 仅适用没有 dims 的 metricGroup。通过伪造一个
  fake_dims_id 来标准化输出\n        # dims.value: { vals }\n        ret = []\n        for
  d_value, vals in data.iteritems():\n            temp = {}\n            temp[\"id\"]
  = metric_group_id\n            temp['vals'] = [{\"id\": k, \"value\": v} for k,
  v in vals.iteritems()]\n            if dims_id:\n                temp[\"dims\"]
  = [{\"id\": dims_id, \"value\": str(d_value)}]\n            else:\n                temp[\"dims\"]
  = []\n            ret.append(temp)\n        return ret\n\n\nclass InspectionAIX(BaseInspection):\n
  \   def __init__(self):\n        pass\n\n    # 获取系统基本信息\n    def get_os_basic_info(self,
  metric_group_id='basic_info', dims_id=None):\n        hostname = socket.gethostname()\n
  \       os_version = platform.platform() + \" \" + platform.architecture()[0]\n
  \       cpu_num = self.get_cpu_num()\n\n        disk_data,_ = self.get_disk_info()\n
  \       # 磁盘空间\n        disk_total = int(disk_data.get('host_total_diskspace',0))\n
  \       disk_percent = round(float(disk_data.get('host_total_used_percent',0)),1)\n
  \       # 文件系统格式\n        disk_fstype_dict = self.get_disk_fstype()\n        disk_fstype
  = \" \".join(list(set(disk_fstype_dict.itervalues())))\n\n        # 内存\n        mem_data,_
  = self.get_memory_info()\n        mem_total = round(float(mem_data.get('mems_total',0)/1024),1)\n
  \       mem_percent = round(float(mem_data.get('mems_percent',0)),1)\n\n        #cpu\n
  \       us_cpu, sys_cpu = self.get_user_sys_cpu()\n        cpu_percent = us_cpu
  + sys_cpu\n        cmd = 'prtconf| grep -i \"processor type\"'\n        success,
  com_result = self.single_command(cmd)\n        if success:\n            cpu_type
  = com_result.split(\":\")[1].strip()\n        else:\n            cpu_type = \"\"\n\n
  \       #uptime\n        uptime = self.get_uptime()\n        data = {\n            \"vals\":
  [\n                {'id': 'hostname', 'value': hostname},\n                {'id':
  'os_version', 'value': os_version},\n                {'id': 'os_uptime', 'value':
  uptime*24 if uptime else None},\n                {'id': 'fs_type', 'value': disk_fstype},\n
  \               {'id': 'disk_total', 'value': disk_total},\n                {'id':
  'memory', 'value': mem_total},\n                {'id': 'cpu_num', 'value': str(cpu_num)},\n
  \               {'id': 'cpu_type', 'value': cpu_type},\n                {'id': 'cpu_percent',
  'value': cpu_percent},\n                {'id': 'disk_percent', 'value': disk_percent},\n
  \               {'id': 'mem_percent', 'value': mem_percent},\n                {\"id\":
  \"us_cpu\", \"value\": us_cpu},\n                {\"id\": \"sys_cpu\", \"value\":
  sys_cpu},\n            ],\n            \"dims\": [],\n            \"id\": metric_group_id\n
  \       }\n        ret = [data]\n        return ret\n\n    def get_disk_fstype(self):\n
  \       # lsfs | sed '1d' | awk '{print $1 \":\"$4}'\n        aix_vfs_cmd = \"lsfs
  | sed '1d' | awk '{print $1 \\\":\\\"$4}'\"\n        success, com_result = self.single_command(aix_vfs_cmd)\n
  \       if success:\n            disk_fstype_dict = {i.split(\":\")[0].strip():
  i.split(\":\")[1].strip() for i in com_result.splitlines()}\n            return
  disk_fstype_dict\n        return {}\n\n    # 获取内存信息, swap分区信息\n    def get_memory_info(self,
  metric_group_id='mem_info', dims_id='mems_type'):\n        data = {}\n        ret
  = []\n        # get host mem\n        cmd = 'vmstat -v'\n        success, cmd_ret
  = self.single_command(cmd)\n        mem_metrics = cmd_ret.split('\\n')\n        if
  success:\n            mem_total = int(mem_metrics[0].split()[0] if len(mem_metrics[0].split())
  > 1 else 0)\n            mem_free = int(mem_metrics[2].split()[0] if len(mem_metrics[2].split())
  > 1 else 0)\n            mem_cache = int(mem_metrics[9].split()[0] if len(mem_metrics[9].split())
  > 1 else 0)\n            mem_used = mem_total - mem_free - mem_cache\n            mem_percent
  = round(float(mem_used) / float(mem_total) * 100, 1)\n            mem_total = mem_total
  * 4 / 1024\n            mem_free = mem_free * 4 / 1024\n            mem_used = mem_used
  * 4 / 1024\n            # 主机基本信息\n            data = {\n                \"mems_total\":
  mem_total,\n                \"mems_used\": mem_used,\n                \"mems_free\":
  mem_free,\n                \"mems_percent\": mem_percent\n            }\n            data_phyics
  = {\n                \"vals\": [\n                    {\"id\": \"mems_total\", \"value\":
  mem_total},\n                    {\"id\": \"mems_used\", \"value\": mem_used},\n
  \                   {\"id\": \"mems_free\", \"value\": mem_free},\n                    {\"id\":
  \"mems_percent\", \"value\": mem_percent},\n                ],\n                \"dims\":
  [{\"id\": dims_id, \"value\": \"physical\"}],\n                \"id\": metric_group_id,\n
  \           }\n            ret.append(data_phyics)\n\n        # get swap mem\n        cmd
  = 'lsps -s|grep -iv \"Total Paging Space\"'\n        success, cmd_ret = self.single_command(cmd)\n
  \       if success:\n            cmd_ret = cmd_ret.strip().split()\n            swap_total
  = int(cmd_ret[0].strip('MB') if 'MB' in cmd_ret[0] else cmd_ret[0])\n            swap_percent
  = float(cmd_ret[1].split('%')[0])\n            # print swap_total,swap_percent\n
  \           swap_used = round(swap_total * swap_percent / 100.0, 1)\n            swap_free
  = round(swap_total - swap_used, 1)\n            data_swap = {\n                \"vals\":
  [\n                    {\"id\": \"mems_total\", \"value\": swap_total},\n                    {\"id\":
  \"mems_used\", \"value\": swap_used},\n                    {\"id\": \"mems_free\",
  \"value\": swap_free},\n                    {\"id\": \"mems_percent\", \"value\":
  swap_percent},\n                ],\n                \"dims\": [{\"id\": dims_id,
  \"value\": \"swap\"}],\n                \"id\": metric_group_id,\n            }\n
  \           ret.append(data_swap)\n        return data, ret\n\n    def get_user_sys_cpu(self):\n
  \       cmd = 'iostat -t | grep -iv \"avg-cpu:\" | grep -iv \"System configuration\"
  '\n        success, com_ret = self.single_command(cmd)\n        if success:\n            us_cpu
  = round(float(com_ret.strip().split()[2]),1)\n            sys_cpu = round(float(com_ret.strip().split()[3]),1)\n
  \           return us_cpu, sys_cpu\n        else:\n            return None, None\n\n
  \   def get_cpu_num(self):\n        cmd = 'prtconf|grep -i \"Processors\"'\n        success,
  com_ret = self.single_command(cmd)\n        if success:\n            cpu_num = com_ret.strip().split(':')[1]\n
  \           return cpu_num\n        else:\n            return None\n\n    def get_host_name(self):\n
  \       cmd = 'prtconf|grep -i \"Host Name\"'\n        success, com_ret = self.single_command(cmd)\n
  \       if success:\n            com_ret = com_ret.strip().split(':')\n            hostname
  = int(com_ret.strip().split()[1])\n            #print 'hostname:', hostname\n            return
  hostname\n        else:\n            return None\n\n    def get_uptime(self):\n
  \       cmd = 'uptime'\n        success, com_ret = self.single_command(cmd)\n        if
  success:\n            ret = re.findall(r'up\\s+(\\d+)\\s+day',com_ret,re.IGNORECASE)\n
  \           days = ret[0] if ret else 0\n            return int(days)\n        else:\n
  \           return None\n\n    # 获取磁盘信息\n    def get_disk_info(self, metric_group_id='partition_info',
  dims_id='fsmountpoint'):\n        data, ret = {}, []\n        host_total_usedspace,
  host_total_diskspace, host_total_used_percent = 0, 0, 0\n        cmd = 'df -g|grep
  -iv \"hsf|iso9660|iso13490|udf|configfs|devfs|debugfs|kernfs|procfs|specfs|sysfs|tmpfs|winfs|proc|binfmt_misc|devpts]\"|grep
  -iv \"Filesystem\"'\n        success, com_ret = self.single_command(cmd)\n        if
  not success:\n            return data, ret\n        disk_type_dict = self.get_disk_fstype()\n\n
  \       com_ret = com_ret.strip().split('\\n')\n        for row in com_ret:\n            if
  row.split()[0] in (\"/proc\", ):\n                continue\n            info = row.strip().split()\n
  \           fsname = info[0].strip()\n            fstype = disk_type_dict.get(fsname,
  '') if disk_type_dict else ''\n            total = round(float(info[1]),1)\n            free
  = round(float(info[2]),1)\n            used = round(total - free,1)\n            percent
  = round(float(info[3].strip('%')),1)\n            mountpoint = info[6]\n            temp
  = dict(\n                vals=[\n                    {\"id\": \"fstype\", \"value\":
  fstype},\n                    {\"id\": \"fstotal\", \"value\": total},\n                    {\"id\":
  \"fsused\", \"value\": used},\n                    {\"id\": \"fsfree\", \"value\":
  free},\n                    {\"id\": \"fspercent\", \"value\": percent},\n                ],\n
  \               dims=[\n                    {\"id\": dims_id, \"value\": mountpoint},\n
  \                   {\"id\": \"fsname\", \"value\": fsname},\n                ],\n
  \               id=metric_group_id,\n            )\n            ret.append(temp)\n
  \           host_total_usedspace += used\n            host_total_diskspace += total\n
  \       if host_total_diskspace:\n            host_total_used_percent = round(float(host_total_usedspace
  * 100 / host_total_diskspace),1)\n        host_total = (host_total_diskspace, host_total_used_percent)\n
  \       data = {\n            'host_total_diskspace': host_total_diskspace,\n            'host_total_usedspace':
  host_total_usedspace,\n            'host_total_used_percent': host_total_used_percent\n
  \       }\n        return data, ret\n\n    def get_errpt_info(self, metric_group_id='errptinfo',
  dims_id='fsmountpoint'):\n        data, ret = {}, []\n        success, com_result
  = self.single_command(\"errpt |grep -v IDENTIFIER\")\n        for get_errptinfos
  in com_result.split('\\n'):\n            if get_errptinfos.split()[1][:4] == time.strftime(\"%m%d\",
  time.localtime()):\n                temp = dict(\n                    vals=[\n                        {\"id\":
  \"errptid\", \"value\": get_errptinfos.split()[0]},\n                        {\"id\":
  \"errptdate\", \"value\": get_errptinfos.split()[1]},\n                        {\"id\":
  \"errpttype\", \"value\": get_errptinfos.split()[2]},\n                        {\"id\":
  \"errptclass\", \"value\": get_errptinfos.split()[3]},\n                    ],\n
  \                   dims=[\n                        {\"id\": dims_id, \"value\":
  get_errptinfos.split()[0]},\n                        {\"id\": \"errptdate\", \"value\":
  get_errptinfos.split()[1]},\n                    ],\n                    id=metric_group_id,\n
  \               )\n                ret.append(temp)\n        return ret\n\n    def
  get_diskgroup_info(self, metric_group_id='lvstatus', dims_id='fsmountpoint'):\n
  \       data, ret = {}, []\n        success, com_result = self.single_command(\"lsvg
  -l rootvg|grep -E \\\"jfs|jfs2|raw\\\"|grep -v 'N/A'\")\n        for get_lvinfos
  in com_result.split('\\n'):\n            cmd = 'lslv ' + get_lvinfos.split()[0]
  + '| grep \\\"LV STATE\\\"|awk -F \\\":\\\" \\'{print $3}\\''\n            success,
  getlv_status = self.single_command(cmd)\n            if success:\n                temp
  = dict(\n                    vals=[\n                        {\"id\": \"lvstatus\",
  \"value\": getlv_status.split()[0]},\n                    ],\n                    dims=[\n
  \                       {\"id\": dims_id, \"value\": get_lvinfos.split()[6]},\n
  \                       {\"id\": \"lvname\", \"value\": get_lvinfos.split()[0]},\n
  \                   ],\n                    id=metric_group_id,\n                )\n
  \               ret.append(temp)\n        return ret\n\n    def get_diskstatus_info(self,
  metric_group_id='diskstatus', dims_id='fsmountpoint'):\n        data, ret = {},
  []\n        success, com_result = self.single_command(\"lsdev -Cc disk\")\n        if
  not success:\n            return ret\n        for get_diskstautsinfos in com_result.split('\\n'):\n
  \           temp = dict(\n                vals=[\n                    {\"id\": \"diskstatus\",
  \"value\": get_diskstautsinfos.split()[1]},\n                ],\n                dims=[\n
  \                   {\"id\": dims_id, \"value\": get_diskstautsinfos.split()[1]},\n
  \                   {\"id\": \"diskname\", \"value\": get_diskstautsinfos.split()[0]},\n
  \               ],\n                id=metric_group_id,\n            )\n            ret.append(temp)\n
  \       return ret\n\n    def get_inode_info(self, metric_group_id='inode_info',
  dims_id='fsmountpoint'):\n        ret = []\n        success, com_result = self.single_command(\"df
  -i|sed '1d'\")\n        if not success:\n            return ret\n        inode_state
  = com_result.split('\\n')\n        for info in inode_state:\n            states
  = info.strip().split()\n            if '-' in states[4]:\n                continue\n
  \           if len(states) < 7:\n                continue\n            inode_fsname
  = states[0]\n            inode_used = int(states[4])\n            inode_per = int(states[5].strip('%'))\n
  \           inode_total = 100 * inode_used / inode_per\n            inode_free =
  inode_total - inode_used\n            temp = dict(\n                vals=[\n                    {\"id\":
  \"fstotal\", \"value\": inode_total},\n                    {\"id\": \"fsused\",
  \"value\": inode_used},\n                    {\"id\": \"fsfree\", \"value\": inode_free},\n
  \                   {\"id\": \"fspercent\", \"value\": inode_per},\n                ],\n
  \               dims=[\n                    {\"id\": dims_id, \"value\": states[6]},\n
  \                   {\"id\": \"fsname\", \"value\": inode_fsname},\n                ],\n
  \               id=metric_group_id,\n            )\n            ret.append(temp)\n
  \       return ret\n\n\nif __name__ == '__main__':\n    ret = []\n    if not aixplatform:\n
  \       InspectionLinuxWin = InspectionLinuxWin()\n        os_basic_data = InspectionLinuxWin.get_os_basic_info()\n
  \       ret.extend(os_basic_data)\n\n        process_info = InspectionLinuxWin.check_zom_process()\n
  \       ret.extend(process_info)\n\n        mem_data = InspectionLinuxWin.get_memory_info()\n
  \       ret.extend(mem_data)\n\n        network_data = InspectionLinuxWin.get_eth_info()\n
  \       ret.extend(network_data)\n\n        disk_data, _ = InspectionLinuxWin.get_disk_info()\n
  \       ret.extend(disk_data)\n\n        # linux\n        if not msplatform:\n            inode_data
  = InspectionLinuxWin.get_inode_info()\n            ret.extend(inode_data)\n\n            top_cpu_process
  = InspectionLinuxWin.get_top_process_cpu()\n            ret.extend(top_cpu_process)\n\n
  \           top_mem_process = InspectionLinuxWin.get_top_process_mem()\n            ret.extend(top_mem_process)\n\n
  \           os_core_mg_id, os_core_dims, os_core_data = InspectionLinuxWin.get_os_core()\n
  \           os_core = InspectionLinuxWin.create_output_old(os_core_mg_id, os_core_dims,
  os_core_data)\n            ret.extend(os_core)\n        print \"调试信息,-start-和-end-中间为输出结果\"\n
  \       print \"------start-------\"\n        print json.dumps(ret)\n        print
  \"-------end--------\"\n        print \"调试信息\"\n\n    else:\n        InspectionAIX
  = InspectionAIX()\n        basic_info = InspectionAIX.get_os_basic_info()\n        ret.extend(basic_info)\n\n
  \       _, mem_data = InspectionAIX.get_memory_info()\n        ret.extend(mem_data)\n\n
  \       top_cpu_process = InspectionAIX.get_top_process_cpu()\n        ret.extend(top_cpu_process)\n\n
  \       top_mem_process = InspectionAIX.get_top_process_mem()\n        ret.extend(top_mem_process)\n\n
  \       _, disk_data = InspectionAIX.get_disk_info()\n        ret.extend(disk_data)\n\n
  \       inode_data = InspectionAIX.get_inode_info()\n        ret.extend(inode_data)\n\n
  \       print \"调试信息,-start-和-end-中间为输出结果\"\n        print \"------start-------\"\n
  \       print json.dumps(ret)\n        print \"-------end--------\"\n        print
  \"调试信息\""
args: []
script: python
