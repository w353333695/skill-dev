# coding: utf-8
"""
IBM SVC (SAN Volume Controller / Spectrum Virtualize) CMDB 采集脚本
覆盖 10 个存储模型，通过 REST API 或 SSH CLI 采集完整配置信息
REST API 优先，不可用时自动降级到 SSH CLI
"""
import os
import sys
import json
import re
import warnings
import traceback

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

try:
    reload(sys)
    sys.setdefaultencoding("utf-8")
except NameError:
    pass  # Python 3
warnings.filterwarnings("ignore")
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

try:
    import paramiko
    HAS_PARAMIKO = True
except ImportError:
    HAS_PARAMIKO = False

# ---------- 采集参数 ----------
instance_id = os.environ.get("EASYOPS_COLLECTOR_instanceId", "")
ip          = os.environ.get("EASYOPS_COLLECTOR_ip", "")
port        = os.environ.get("EASYOPS_COLLECTOR_port", "7443")
user        = os.environ.get("EASYOPS_COLLECTOR_user", "")
password    = os.environ.get("EASYOPS_COLLECTOR_password", "")
ssh_port    = os.environ.get("EASYOPS_COLLECTOR_ssh_port", "22")

# ---------- 日志 ----------
current_dir = os.path.dirname(os.path.abspath(__file__))
_SAMPLER_SCRIPTS = os.path.normpath(
    os.path.join(current_dir, '..', '..', '..', 'easy_process_sampler', 'scripts'))
if _SAMPLER_SCRIPTS not in sys.path:
    sys.path.insert(0, _SAMPLER_SCRIPTS)
try:
    from lib import task_logger
    logger = task_logger.get_logger()
    if logger is None:
        raise ValueError("get_logger returned None")
except Exception:
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format='[%(asctime)s %(funcName)s %(levelname)s] %(message)s')
    logger = logging.getLogger("svc_cmdb")

# ---------- CMDB 模型常量 ----------
STORAGE_OBJ            = "STORAGE@ONEMODEL"
CLUSTER_OBJ            = "STORAGE_CLUSTER@ONEMODEL"
CONTROLLER_OBJ         = "STORAGE_CONTROLLER@ONEMODEL"
DISK_OBJ               = "STORAGE_DISK@ONEMODEL"
GROUP_OBJ              = "STORAGE_GROUP@ONEMODEL"
LUN_OBJ                = "STORAGE_LUN@ONEMODEL"
POOL_OBJ               = "STORAGE_POOL@ONEMODEL"
FCSWITCH_OBJ            = "FIBERCHANNEL_SWITCH_PORT@ONEMODEL"
NETDPORT_OBJ            = "NETDPORT@ONEMODEL"
VOLUME_OBJ              = "STORAGE_VOLUME@ONEMODEL"

BRAND = "IBM"

TECH_TYPE_MAP = {
    "tier0_flash":     "NVMe",
    "tier1_flash":     "SSD",
    "tier_enterprise": "SAS",
    "tier_nearline":   "SATA",
    "tier_scm":        "SCM",
}

STATUS_MAP = {
    "online":  "在线",
    "offline": "离线",
    "degraded": "降级",
    "excluded": "已排除",
}


def parse_capacity_to_bytes(value_str):
    """将 IBM API 容量字符串转为字节数。
    '133.05TB' -> 142118415683584, '500GB' -> 536870912000
    返回整数，解析失败返回 0。
    """
    matched = re.match(r"([\d.]+)\s*(TB|GB|MB|PB)", str(value_str), re.IGNORECASE)
    if not matched:
        return 0
    num = float(matched.group(1))
    unit = matched.group(2).upper()
    multipliers = {"MB": 1048576, "GB": 1073741824, "TB": 1099511627776, "PB": 1125899906842624}
    return int(num * multipliers.get(unit, 0))


def parse_capacity_to_gb(value_str):
    """将容量字符串转为 GB 整数。"""
    return parse_capacity_to_bytes(value_str) // 1073741824


def normalize_wwpn(value):
    """将 WWPN 规范化为小写 MAC 形式。"""
    if value is None:
        return ""
    text = str(value).strip()
    if not text:
        return ""
    if text.lower().startswith("0x"):
        text = text[2:]
    hex_text = re.sub(r"[^0-9A-Fa-f]", "", text).lower()
    if len(hex_text) != 16:
        return text.lower()
    return ":".join(hex_text[i:i + 2] for i in range(0, 16, 2))


# ============================================================
#  REST API 客户端
# ============================================================

class SVCRestClient(object):
    """IBM SVC / Spectrum Virtualize REST API 客户端"""

    def __init__(self, host, port, username, password):
        self._base_v1 = "https://{}:{}/rest/v1".format(host, port)
        self._base_legacy = "https://{}:{}/rest".format(host, port)
        self.base_url = self._base_v1
        self.username = username
        self.password = password
        self.token = None

    def auth(self):
        """认证获取 JWT Token，优先 v1 API，失败降级到 legacy。"""
        auth_headers = {
            "X-Auth-Username": self.username,
            "X-Auth-Password": self.password,
            "Accept": "application/json",
            "Content-Length": "0",
        }
        candidates = [
            (self._base_v1, "{}/auth".format(self._base_v1)),
            (self._base_legacy, "{}/auth".format(self._base_legacy)),
        ]
        last_err = None
        for base, url in candidates:
            try:
                resp = requests.post(url, headers=auth_headers, verify=False, timeout=30)
                if resp.status_code == 403:
                    last_err = "HTTP 403 from {}".format(url)
                    continue
                resp.raise_for_status()
                token = resp.json().get("token")
                if not token:
                    last_err = "no token in response from {}".format(url)
                    continue
                self.token = token
                self.base_url = base
                logger.info("SVC auth OK, api_base=%s" % base)
                return
            except Exception as e:
                last_err = str(e)
                continue
        raise Exception("SVC auth failed: %s" % last_err)

    def post(self, command, body=None, retries=1):
        """执行 REST API POST 请求，支持重试。"""
        if body is None:
            body = {}
        url = "{}/{}".format(self.base_url, command)
        headers = {"X-Auth-Token": self.token, "Content-Type": "application/json"}
        last_err = None
        for attempt in range(retries + 1):
            try:
                resp = requests.post(url, json=body, headers=headers, verify=False, timeout=60)
                resp.raise_for_status()
                return resp.json()
            except requests.exceptions.HTTPError as e:
                last_err = "HTTP {} for {}".format(e.response.status_code if e.response is not None else "?", command)
                if e.response is not None and e.response.status_code >= 500 and attempt < retries:
                    logger.warning("%s, retry %d/%d" % (last_err, attempt + 1, retries))
                    import time; time.sleep(2)
                    continue
                raise
            except Exception as e:
                last_err = str(e)
                raise

    def logout(self):
        """注销 Token。"""
        try:
            self.post("auth/end")
        except Exception:
            pass


# ============================================================
#  SSH CLI 客户端（REST API 不可用时的降级方案）
# ============================================================

class SVCSSHClient(object):
    """通过 SSH 执行 SVC CLI 命令采集 CMDB 数据，作为 REST API 的降级方案"""

    CLI_COMMAND_MAP = {
        "lssystem":       "lssystem -delim :",
        "lsenclosure":    "lsenclosure -delim :",
        "lsiogrp":        "lsiogrp -delim :",
        "lsnode":         "lsnode -delim :",
        "lsmdiskgrp":     "lsmdiskgrp -bytes -delim :",
        "lsdrive":        "lsdrive -bytes -delim :",
        "lsmdisk":        "lsmdisk -delim :",
        "lsvdisk":        "lsvdisk -bytes -delim :",
        "lshost":         "lshost -delim :",
        "lsvolumegroup":  "lsvolumegroup -delim :",
        "lsportfc":       "lsportfc -delim :",
        "lsportip":       "lsportip -delim :",
    }

    def __init__(self, host, ssh_port, username, password):
        self.host = host
        self.ssh_port = ssh_port
        self.username = username
        self.password = password
        self._ssh = None

    def auth(self):
        if not HAS_PARAMIKO:
            raise Exception("paramiko library not available, cannot use SSH")
        self._ssh = paramiko.SSHClient()
        self._ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self._ssh.connect(
            self.host, port=self.ssh_port,
            username=self.username, password=self.password,
            timeout=30, look_for_keys=False, allow_agent=False,
        )
        logger.info("SSH connected to %s:%s" % (self.host, self.ssh_port))

    def _exec_and_parse(self, cmd):
        """执行 CLI 命令并解析冒号分隔的输出为 dict 列表"""
        stdin, stdout, stderr = self._ssh.exec_command(cmd, timeout=60)
        output = stdout.read().decode("utf-8", errors="replace").strip()
        err = stderr.read().decode("utf-8", errors="replace").strip()
        if not output and err:
            raise Exception("CLI error: %s" % err[:300])
        if not output:
            return []
        lines = output.split("\n")
        if len(lines) < 1:
            return []
        headers = [h.strip() for h in lines[0].split(":")]
        result = []
        for line in lines[1:]:
            line = line.strip()
            if not line:
                continue
            values = line.split(":")
            entry = {}
            for i, h in enumerate(headers):
                entry[h] = values[i].strip() if i < len(values) else ""
            result.append(entry)
        return result

    def post(self, command, body=None, retries=0):
        """模拟 REST API post()，通过 SSH 执行对应 CLI 命令"""
        # 处理路径参数，如 "lshostvdiskmap/5" → "lshostvdiskmap 5 -delim :"
        if "/" in command:
            base_cmd, param = command.split("/", 1)
            cmd = "%s %s -delim :" % (base_cmd, param)
        else:
            cmd = self.CLI_COMMAND_MAP.get(command, "%s -delim :" % command)
            # body 中的 bytes 参数映射到 CLI -bytes 标志
            if body and isinstance(body, dict) and body.get("bytes") and "-bytes" not in cmd:
                cmd = cmd.replace("-delim :", "-bytes -delim :")
        return self._exec_and_parse(cmd)

    def logout(self):
        if self._ssh:
            try:
                self._ssh.close()
            except Exception:
                pass


# ============================================================
#  采集器（与客户端类型无关，REST 和 SSH 共用）
# ============================================================

class SVCCollector(object):
    """IBM SVC CMDB 数据采集器"""

    def __init__(self, client, instance_id):
        self.client = client
        self.instance_id = instance_id
        self.system_info = {}
        self.serial_number = ""
        self.product_name = ""

    def _make_record(self, vals, object_id, pks):
        """构造标准采集记录。"""
        return {
            "vals": vals,
            "dims": {
                "pks": pks,
                "object_id": object_id,
                "objectId": object_id,
                "upsert": True,
            }
        }

    def _storage_ref(self):
        """返回对 STORAGE 的关系引用。"""
        return [{"instanceId": self.instance_id}]

    # ===== 1. STORAGE =====
    def collect_system(self):
        try:
            data = self.client.post("lssystem", retries=1)
        except Exception as e:
            logger.error("lssystem failed: %s, creating minimal STORAGE record" % e)
            vals = {
                "instanceId":    self.instance_id,
                "name":          "",
                "brand":         BRAND,
                "mdl":           "",
                "sn":            "",
                "version":       "",
                "capacity":      0,
                "freeCapacity":  0,
                "totalMdCapacity": 0,
                "totalVdCapacity": 0,
                "totalUsedCapacity": 0,
                "location":      "",
                "contact":       "",
                "consoleIp":     "{}:{}".format(ip, port),
            }
            return [self._make_record(vals, STORAGE_OBJ, ["instanceId"])]

        self.system_info = data
        self.serial_number = data.get("id", "")
        self.product_name = data.get("product_name", "")

        # 优先从 lsenclosure 获取产品序列号
        try:
            enclosures = self.client.post("lsenclosure")
            if enclosures and isinstance(enclosures, list) and len(enclosures) > 0:
                enc_serial = enclosures[0].get("serial_number", "")
                if enc_serial:
                    self.serial_number = enc_serial
                    logger.info("serial from lsenclosure: %s" % enc_serial)
        except Exception as e:
            logger.warning("lsenclosure failed, fallback to lssystem.id: %s" % e)

        vals = {
            "instanceId":    self.instance_id,
            "name":          data.get("name", ""),
            "brand":         BRAND,
            "mdl":           self.product_name,
            "sn":            self.serial_number,
            "version":       data.get("code_level", ""),
            "capacity":      parse_capacity_to_gb(data.get("physical_capacity", "0")),
            "freeCapacity":  parse_capacity_to_gb(data.get("physical_free_capacity", "0")),
            "totalMdCapacity": parse_capacity_to_gb(data.get("total_mdisk_capacity", "0")),
            "totalVdCapacity": parse_capacity_to_gb(data.get("total_vdisk_capacity", "0")),
            "totalUsedCapacity": parse_capacity_to_gb(data.get("total_used_capacity", "0")),
            "location":      data.get("location", ""),
            "contact":       data.get("contact", ""),
            "consoleIp":     data.get("console_IP", ""),
        }
        logger.info("STORAGE: name=%s sn=%s capacity=%dGB" % (vals["name"], vals["sn"], vals["capacity"]))
        return [self._make_record(vals, STORAGE_OBJ, ["instanceId"])]

    # ===== 2. STORAGE_CLUSTER (I/O Groups) =====
    def collect_clusters(self):
        try:
            iogrps = self.client.post("lsiogrp")
        except Exception as e:
            logger.warning("lsiogrp failed: %s" % e)
            return []

        if not isinstance(iogrps, list):
            iogrps = [iogrps]

        records = []
        for iogrp in iogrps:
            composed_name = "{}_iogrp_{}".format(self.instance_id, iogrp.get("id", ""))
            vals = {
                "name":            composed_name,
                "clusterName":     iogrp.get("name", ""),
                "clusterId":       str(iogrp.get("id", "")),
                "nodeCount":       int(iogrp.get("node_count", 0)),
                "vdiskCount":      int(iogrp.get("vdisk_count", 0)),
                "hostCount":       int(iogrp.get("host_count", 0)),
                "status":          "online",
                "storageSn":       self.serial_number,
                "storageModel":    self.product_name,
                "BASE_STORAGE_ASSET": self._storage_ref(),
            }
            records.append(self._make_record(vals, CLUSTER_OBJ, ["name"]))
        logger.info("STORAGE_CLUSTER: %d I/O groups" % len(records))
        return records

    # ===== 3. STORAGE_CONTROLLER (Nodes) =====
    def collect_controllers(self):
        try:
            nodes = self.client.post("lsnode")
        except Exception as e:
            logger.warning("lsnode failed: %s" % e)
            return []

        if not isinstance(nodes, list):
            nodes = [nodes]

        # 构建 I/O group id -> name 映射
        iogrp_map = {}
        try:
            iogrps = self.client.post("lsiogrp")
            if isinstance(iogrps, list):
                for ig in iogrps:
                    iogrp_map[str(ig.get("id", ""))] = ig.get("name", "")
        except Exception:
            pass

        records = []
        for node in nodes:
            iogrp_id = str(node.get("IO_group_id", ""))
            vals = {
                "sp":              str(node.get("id", "")),
                "name":            node.get("name", ""),
                "status":          STATUS_MAP.get(node.get("status", ""), node.get("status", "")),
                "storageSn":       self.serial_number,
                "storageModel":    self.product_name,
                "ioGroupId":       iogrp_id,
                "ioGroupName":     iogrp_map.get(iogrp_id, ""),
                " UPS_serial":     node.get("UPS_serial_number_1", ""),
                "hardware":        node.get("hardware", ""),
                "iscsiName":       node.get("iscsi_name", ""),
                "BASE_STORAGE_ASSET": self._storage_ref(),
            }
            if iogrp_id:
                cluster_name = "{}_iogrp_{}".format(self.instance_id, iogrp_id)
                vals["STORAGE_CLUSTER"] = [{"name": cluster_name}]
            records.append(self._make_record(vals, CONTROLLER_OBJ, ["sp", "storageSn"]))
        logger.info("STORAGE_CONTROLLER: %d nodes" % len(records))
        return records

    # ===== 4. STORAGE_POOL =====
    def collect_pools(self):
        try:
            pools = self.client.post("lsmdiskgrp", {"bytes": True})
        except Exception as e:
            logger.warning("lsmdiskgrp failed: %s" % e)
            return []

        if not isinstance(pools, list):
            pools = [pools]

        records = []
        for pool in pools:
            composed_name = "{}_{}".format(self.instance_id, pool.get("name", ""))
            total_cap = int(pool.get("capacity", 0))
            free_cap = int(pool.get("free_capacity", 0))
            used_cap = int(pool.get("used_capacity", 0))
            vals = {
                "name":          composed_name,
                "poolName":      pool.get("name", ""),
                "poolId":        str(pool.get("id", "")),
                "totalCapacity": str(total_cap // 1073741824),
                "freeCapacity":  str(free_cap // 1073741824),
                "usedCapacity":  str(used_cap // 1073741824),
                "mdiskCount":    int(pool.get("mdisk_count", 0)),
                "vdiskCount":    int(pool.get("vdisk_count", 0)),
                "type":          pool.get("type", ""),
                "status":        STATUS_MAP.get(pool.get("status", ""), pool.get("status", "")),
                "encrypt":       pool.get("encrypt", ""),
                "compression":   pool.get("compression_active", ""),
                "storageSn":     self.serial_number,
                "storageModel":  self.product_name,
                "BASE_STORAGE_ASSET": self._storage_ref(),
            }
            records.append(self._make_record(vals, POOL_OBJ, ["name"]))
        logger.info("STORAGE_POOL: %d pools" % len(records))
        return records

    # ===== 5. STORAGE_DISK (Physical Drives) =====
    def collect_disks(self):
        try:
            drives = self.client.post("lsdrive", {"bytes": True})
        except Exception as e:
            logger.warning("lsdrive failed: %s" % e)
            return []

        if not isinstance(drives, list):
            drives = [drives]

        # MDisk -> Pool 映射
        mdisk_to_pool = {}
        try:
            mdisks = self.client.post("lsmdisk")
            if isinstance(mdisks, list):
                for mdisk in mdisks:
                    pool_name = mdisk.get("mdisk_grp_name", "")
                    if pool_name:
                        mdisk_to_pool[mdisk.get("name", "")] = "{}_{}".format(self.instance_id, pool_name)
        except Exception as e:
            logger.warning("lsmdisk failed for disk pool mapping: %s" % e)

        records = []
        for drive in drives:
            tech_type = drive.get("tech_type", "")
            try:
                slot_id = int(drive.get("slot_id", "0"))
            except (ValueError, TypeError):
                slot_id = 0
            mdisk_name = drive.get("mdisk_name", "")
            capacity_bytes = int(drive.get("capacity", 0))

            vals = {
                "name":          "{}_drive_{}".format(self.instance_id, drive.get("id", "")),
                "diskType":      TECH_TYPE_MAP.get(tech_type, tech_type),
                "status":        STATUS_MAP.get(drive.get("status", ""), drive.get("status", "")),
                "slotId":        slot_id,
                "capacity":      str(capacity_bytes // 1073741824),
                "mdiskName":     mdisk_name,
                "driveId":       str(drive.get("id", "")),
                "enclosureId":   str(drive.get("enclosure_id", "")),
                "member":        drive.get("member", ""),
                "use":           drive.get("use", ""),
                "storageSn":     self.serial_number,
                "storageModel":  self.product_name,
                "BASE_STORAGE_ASSET": self._storage_ref(),
            }
            if mdisk_name and mdisk_name in mdisk_to_pool:
                vals["base_storage_pools"] = [{"name": mdisk_to_pool[mdisk_name]}]
            records.append(self._make_record(vals, DISK_OBJ, ["name"]))
        logger.info("STORAGE_DISK: %d drives" % len(records))
        return records

    # ===== 6. STORAGE_VOLUME (Virtual Disks) =====
    def collect_volumes(self):
        try:
            vdisks = self.client.post("lsvdisk", {"bytes": True})
        except Exception as e:
            logger.warning("lsvdisk failed: %s" % e)
            return []

        if not isinstance(vdisks, list):
            vdisks = [vdisks]

        records = []
        for vdisk in vdisks:
            original_name = vdisk.get("name", "")
            pool_name = vdisk.get("mdisk_grp_name", "")
            capacity_bytes = int(vdisk.get("capacity", 0))

            vals = {
                "name":           "{}_{}".format(self.instance_id, original_name),
                "volumeName":     original_name,
                "volumeId":       str(vdisk.get("id", "")),
                "wwn":            vdisk.get("vdisk_UID", ""),
                "status":         STATUS_MAP.get(vdisk.get("status", ""), vdisk.get("status", "")),
                "capacity":       str(capacity_bytes // 1073741824),
                "type":           vdisk.get("type", ""),
                "format":         vdisk.get("format", ""),
                "ioGroupId":      str(vdisk.get("IO_group_id", "")),
                "copyCount":      int(vdisk.get("copy_count", 0)),
                "seCopyCount":    int(vdisk.get("se_copy_count", 0)),
                "compressedCopyCount": int(vdisk.get("compressed_copy_count", 0)),
                "deduplicatedCopyCount": int(vdisk.get("deduplicated_copy_count", 0)),
                "encrypt":        vdisk.get("encrypt", ""),
                "storageSn":      self.serial_number,
                "storageModel":   self.product_name,
                "BASE_STORAGE_ASSET": self._storage_ref(),
            }
            if pool_name:
                vals["base_storage_pools"] = [{"name": "{}_{}".format(self.instance_id, pool_name)}]
            records.append(self._make_record(vals, VOLUME_OBJ, ["name"]))
        logger.info("STORAGE_VOLUME: %d volumes" % len(records))
        return records

    # ===== 7. STORAGE_LUN (Host-Volume Mappings) =====
    def collect_luns(self):
        """采集 Volume<->Host 映射，以 LUN 视角呈现。"""
        try:
            hosts = self.client.post("lshost")
        except Exception as e:
            logger.warning("lshost failed: %s" % e)
            return []

        if not isinstance(hosts, list):
            hosts = [hosts]

        # 构建 volume id -> volume name 映射
        vdisk_map = {}
        try:
            vdisks = self.client.post("lsvdisk")
            if isinstance(vdisks, list):
                for vd in vdisks:
                    vdisk_map[str(vd.get("id", ""))] = vd.get("name", "")
        except Exception:
            pass

        records = []
        for host in hosts:
            host_id = str(host.get("id", ""))
            host_name = host.get("name", "")
            try:
                mappings = self.client.post("lshostvdiskmap/{}".format(host_id))
                if not isinstance(mappings, list):
                    mappings = [mappings] if mappings else []
            except Exception:
                continue

            for mapping in mappings:
                vdisk_id = str(mapping.get("vdisk_id", ""))
                vdisk_name = vdisk_map.get(vdisk_id, mapping.get("vdisk_name", ""))
                vdisk_uid = mapping.get("vdisk_UID", "")
                lun_id = mapping.get("SCSI_id", "")
                composed_name = "{}_{}_{}".format(self.instance_id, host_name, vdisk_name)

                vals = {
                    "name":           composed_name,
                    "lunName":        vdisk_name,
                    "hostName":       host_name,
                    "hostId":         host_id,
                    "lunId":          lun_id,
                    "wwn":            vdisk_uid,
                    "volumeName":     vdisk_name,
                    "type":           mapping.get("type", ""),
                    "storageSn":      self.serial_number,
                    "storageModel":   self.product_name,
                    "BASE_STORAGE_ASSET": self._storage_ref(),
                }
                volume_composed = "{}_{}".format(self.instance_id, vdisk_name)
                vals["base_storage_volumes"] = [{"name": volume_composed}]
                records.append(self._make_record(vals, LUN_OBJ, ["name"]))
        logger.info("STORAGE_LUN: %d mappings" % len(records))
        return records

    # ===== 8. STORAGE_GROUP (Volume Groups) =====
    def collect_groups(self):
        try:
            vgroups = self.client.post("lsvolumegroup")
        except Exception as e:
            logger.warning("lsvolumegroup failed: %s" % e)
            return []

        if not isinstance(vgroups, list):
            vgroups = [vgroups]

        records = []
        for vg in vgroups:
            composed_name = "{}_vg_{}".format(self.instance_id, vg.get("id", ""))
            vals = {
                "name":           composed_name,
                "groupName":      vg.get("name", ""),
                "groupId":        str(vg.get("id", "")),
                "type":           vg.get("type", ""),
                "vdiskCount":     int(vg.get("vdisk_count", 0)),
                "storageSn":      self.serial_number,
                "storageModel":   self.product_name,
                "BASE_STORAGE_ASSET": self._storage_ref(),
            }
            try:
                vdisks_in_group = vg.get("vdisks", [])
                if isinstance(vdisks_in_group, list):
                    vol_refs = []
                    for vd_name in vdisks_in_group:
                        vol_refs.append({"name": "{}_{}".format(self.instance_id, vd_name)})
                    if vol_refs:
                        vals["base_storage_volumes"] = vol_refs
            except Exception:
                pass
            records.append(self._make_record(vals, GROUP_OBJ, ["name"]))
        logger.info("STORAGE_GROUP: %d volume groups" % len(records))
        return records

    # ===== 9. FIBERCHANNEL_SWITCH_PORT (FC 端口) =====
    def collect_fc_switch_ports(self):
        try:
            fc_ports = self.client.post("lsportfc")
        except Exception as e:
            logger.warning("lsportfc failed: %s" % e)
            return []

        if not isinstance(fc_ports, list):
            fc_ports = [fc_ports]

        records = []
        for port in fc_ports:
            speed_raw = port.get("port_speed", "N/A")
            speed_m = re.match(r"(\d+)", str(speed_raw))
            max_speed = int(speed_m.group(1)) if speed_m else 0
            node_id = str(port.get("node_id", ""))
            port_id = port.get("id", "")
            composed_name = "{}_fc_{}_n{}".format(self.instance_id, port_id, node_id)

            vals = {
                "name":          composed_name,
                "wwpn":          normalize_wwpn(port.get("WWPN", "")),
                "portIndex":     port_id,
                "portName":      "Node {} {}".format(
                                    port.get("node_name", node_id),
                                    "{}_{}".format(
                                        port.get("adapter_location", ""),
                                        port.get("adapter_port_id", ""))),
                "portState":     port.get("port_status", ""),
                "portType":      "FC",
                "protocol":      "FC",
                "portSpeed":     max_speed,
                "BASE_STORAGE_ASSET": self._storage_ref(),
            }
            records.append(self._make_record(vals, FCSWITCH_OBJ, ["name"]))
        logger.info("FIBERCHANNEL_SWITCH_PORT: %d FC ports" % len(records))
        return records

    # ===== 10. NETDPORT (IP 端口) =====
    def collect_ip_netdports(self):
        try:
            ip_ports = self.client.post("lsportip")
        except Exception as e:
            logger.warning("lsportip failed: %s" % e)
            return []

        if not isinstance(ip_ports, list):
            ip_ports = [ip_ports]

        seen_ip = set()
        records = []
        for port in ip_ports:
            node_id = str(port.get("node_id", ""))
            port_id = port.get("id", "")
            dedup_key = (node_id, port_id)
            if dedup_key in seen_ip:
                continue
            seen_ip.add(dedup_key)

            composed_name = "{}_ip_{}_n{}".format(self.instance_id, port_id, node_id)
            vals = {
                "name":          composed_name,
                "ifName":        "IP_{}".format(port_id),
                "ifIndex":       port_id,
                "type":          "IP",
                "ip":            port.get("IP_address", ""),
                "physAddress":   port.get("mac", ""),
                "operStatus":    port.get("state", ""),
                "sysName":       "node_{}".format(node_id),
            }
            records.append(self._make_record(vals, NETDPORT_OBJ, ["name"]))
        logger.info("NETDPORT: %d IP ports" % len(records))
        return records


# ============================================================
#  主流程
# ============================================================

def _try_create_ssh_client():
    """尝试创建 SSH 客户端"""
    if not HAS_PARAMIKO:
        logger.warning("paramiko not available, SSH fallback disabled")
        return None
    try:
        ssh = SVCSSHClient(ip, int(ssh_port), user, password)
        ssh.auth()
        logger.info("SSH fallback connected to %s:%s" % (ip, ssh_port))
        return ssh
    except Exception as e:
        logger.warning("SSH fallback failed: %s" % e)
        return None


# 采集步骤名 → 采集方法名 的映射
_STEP_METHOD_MAP = {
    "STORAGE":            "collect_system",
    "STORAGE_CLUSTER":    "collect_clusters",
    "STORAGE_CONTROLLER": "collect_controllers",
    "STORAGE_POOL":       "collect_pools",
    "STORAGE_DISK":       "collect_disks",
    "STORAGE_VOLUME":     "collect_volumes",
    "STORAGE_LUN":        "collect_luns",
    "STORAGE_GROUP":      "collect_groups",
    "FIBERCHANNEL_SWITCH": "collect_fc_switch_ports",
    "NETDPORT":           "collect_ip_netdports",
}


def main():
    logger.info("SVC CMDB collection started, instanceId=%s ip=%s" % (instance_id, ip))

    all_data = []
    client = None
    using_ssh = False

    # ---- 阶段 1: 尝试 REST API ----
    try:
        client = SVCRestClient(ip, port, user, password)
        client.auth()
        logger.info("REST API auth succeeded (ip=%s:%s)" % (ip, port))
    except Exception as e:
        logger.warning("REST API auth failed: %s" % e)
        client = None

    # ---- 阶段 2: REST 失败则降级到 SSH ----
    if client is None:
        client = _try_create_ssh_client()
        if client is None:
            logger.error("Both REST API and SSH failed, aborting")
            sys.exit(1)
        using_ssh = True

    # ---- 阶段 3: 采集数据 ----
    try:
        collector = SVCCollector(client, instance_id)

        collect_steps = [
            ("STORAGE",           collector.collect_system),
            ("STORAGE_CLUSTER",   collector.collect_clusters),
            ("STORAGE_CONTROLLER", collector.collect_controllers),
            ("STORAGE_POOL",      collector.collect_pools),
            ("STORAGE_DISK",      collector.collect_disks),
            ("STORAGE_VOLUME",    collector.collect_volumes),
            ("STORAGE_LUN",       collector.collect_luns),
            ("STORAGE_GROUP",     collector.collect_groups),
            ("FIBERCHANNEL_SWITCH", collector.collect_fc_switch_ports),
            ("NETDPORT",         collector.collect_ip_netdports),
        ]

        step_results = {}
        for step_name, step_fn in collect_steps:
            try:
                records = step_fn()
                all_data.extend(records)
                step_results[step_name] = len(records)
            except Exception as e:
                logger.error("Step %s failed: %s" % (step_name, str(e)))
                logger.error(traceback.format_exc())
                step_results[step_name] = -1

        # ---- 阶段 4: REST API 部分步骤失败或无数据时，尝试 SSH 补采 ----
        if not using_ssh:
            missing = [name for name, count in step_results.items() if count <= 0]
            if missing:
                logger.warning("REST API missing data for: %s, trying SSH for those" % ", ".join(missing))
                ssh = _try_create_ssh_client()
                if ssh:
                    try:
                        ssh_collector = SVCCollector(ssh, instance_id)
                        # 继承已有系统信息
                        ssh_collector.system_info = collector.system_info
                        ssh_collector.serial_number = collector.serial_number
                        ssh_collector.product_name = collector.product_name

                        # STORAGE 步骤需要先执行以获取系统信息
                        if "STORAGE" in missing:
                            try:
                                records = ssh_collector.collect_system()
                                all_data.extend(records)
                            except Exception as e:
                                logger.warning("SSH fallback for STORAGE failed: %s" % e)

                        # 补采其他缺失步骤
                        for step_name in missing:
                            if step_name == "STORAGE":
                                continue
                            method_name = _STEP_METHOD_MAP.get(step_name)
                            if method_name:
                                try:
                                    records = getattr(ssh_collector, method_name)()
                                    all_data.extend(records)
                                    logger.info("SSH fallback for %s: %d records" % (step_name, len(records)))
                                except Exception as e:
                                    logger.warning("SSH fallback for %s failed: %s" % (step_name, e))
                    finally:
                        ssh.logout()

        logger.info("Collection complete, total records=%d" % len(all_data))
    finally:
        if client:
            client.logout()

    print("-----BEGIN GATHERING DATA-----")
    print(json.dumps(all_data, ensure_ascii=False))
    print("-----END GATHERING DATA-----")


if __name__ == "__main__":
    main()
