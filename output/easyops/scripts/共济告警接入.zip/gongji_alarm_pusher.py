#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
共济基础设施监控系统 → EasyOps 告警接入脚本（Pull 模式）

数据源：共济 EMS 北向接口协议（V2.23，version=20211214）
- 协议：HTTP POST + JSON；token 放在 HTTP 头部自定义字段 `token` 中。
- 模式：Pull（一次性执行）。登录 → 查询历史告警 → 转换 → 推送 EasyOps webhook → 登出。
- 不使用 while 循环，符合 alarm-access skill「一次性执行」规范。

如需 Push（实时）模式：登录后订阅 /north/online_alarm_subscribe，并在本机起 HTTP 服务
接收 /north/online_alarm_push 回调 + 维持心跳（详见文件末尾「Push 实时模式说明」）。

依赖：requests
运行：python gongji_alarm_pusher.py
"""

import json
import time
import logging
import hashlib
from functools import wraps
from typing import List, Dict, Optional

import requests

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("gongji-alarm-access")


# ============ 配置区域 - 根据实际情况修改 ============
# --- 共济 EMS 北向服务配置 ---
EMS_HOST = "10.0.240.74"          # 共济 EMS 地址
EMS_PORT = 8000                   # 北向服务端口（默认 8000）
EMS_VERSION = "20211214"          # 协议版本号（对应文档版本）
EMS_USERNAME = "admin"            # 登录用户名
EMS_PASSWORD = "123456"           # 登录密码
# login 时需上报「接收推送数据的回调 IP/端口」(push 模式才真正用到)。
# 纯 Pull 模式下填本机占位即可；若启用 push 模式则需为可被 EMS 访问的真实地址。
CALLBACK_IP = "127.0.0.1"
CALLBACK_PORT = "3000"

# --- 历史告警查询（offline_alarm）参数 ---
LOOKBACK_HOURS = 24               # 查询最近 N 小时的告警
IS_RECOVER_FILTER = [0]           # 恢复状态过滤：[0]=只拉未恢复(活动告警)，[0,1]=全部，None/[]不过滤
EVENT_LEVEL_FILTER = []           # 告警等级过滤(1紧急/2严重/3重要/4次要/5预警)，空=不过滤
EVENT_TYPE_FILTER = []            # 告警类型过滤(0/2/3/4/5/7/21/30)，空=不过滤
RESOURCE_ID_FILTER = []           # 限定对象 id（设备/测点/空间），空=全部
MAX_PUSH = 0                      # 单次最多推送条数，0=不限制

# --- EasyOps webhook 配置 ---
EASYOPS_HOST = "127.0.0.1"      # EasyOps 服务器地址（按实际填写）
EASYOPS_ORG = "102531"              # EasyOps 组织 ID
EASYOPS_ACCESS_ID = "a8c5759b269860f6d8563df497bb14551bff2c3e"      # EasyOps 事件接入 ID（控制台 > 事件中心 > 事件接入 创建）
SOURCE = "gongji"             # 告警源标识

# --- 通用 ---
REQUEST_TIMEOUT = 30              # 请求超时(秒)
RETRY_TIMES = 3                   # 失败重试次数
RETRY_DELAY = 1                   # 重试初始间隔(秒)
# ====================================================


# --- 共济告警类型 → 文本 ---
EVENT_TYPE_MAP = {
    0: "通信中断", 1: "告警恢复", 2: "过高报警", 3: "不正常值",
    4: "过低报警", 5: "错误数据", 6: "确认事件", 7: "事件",
    21: "故障", 30: "停止采集",
}

# --- 共济告警等级(1-5) → EasyOps 严重度 ---
LEVEL_MAP = {
    "1": "critical",  # 紧急
    "2": "critical",  # 严重
    "3": "critical",     # 重要
    "4": "warning",   # 次要
    "5": "info",      # 预警
}


def retry(times: int = RETRY_TIMES, delay: float = RETRY_DELAY, backoff: float = 2.0):
    """重试装饰器：指数退避"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempt, current_delay = 0, delay
            while attempt < times:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    attempt += 1
                    if attempt >= times:
                        logger.error("重试 %d 次后仍失败: %s", times, e)
                        raise
                    logger.warning("第 %d 次失败，%.1fs 后重试: %s", attempt, current_delay, e)
                    time.sleep(current_delay)
                    current_delay *= backoff
        return wrapper
    return decorator


class GongjiClient:
    """共济 EMS 北向接口客户端"""

    def __init__(self, host: str, port: int, version: str,
                 username: str, password: str,
                 callback_ip: str, callback_port: str,
                 timeout: int = REQUEST_TIMEOUT):
        self.base_url = f"http://{host}:{port}/north"
        self.version = version
        self.username = username
        self.password = password
        self.callback_ip = callback_ip
        self.callback_port = callback_port
        self.timeout = timeout
        self.token: Optional[str] = None

    def _headers(self) -> Dict[str, str]:
        """构造请求头，携带 token"""
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["token"] = self.token
        return headers

    def _envelope(self, data: dict) -> dict:
        """构造统一请求包: {"version": ..., "data": ...}"""
        return {"version": self.version, "data": data}

    @retry()
    def _post(self, path: str, data: dict, with_token: bool = True) -> dict:
        """统一 POST 请求"""
        url = f"{self.base_url}{path}"
        headers = self._headers() if with_token else {"Content-Type": "application/json"}
        resp = requests.post(url, headers=headers, data=json.dumps(self._envelope(data)),
                             timeout=self.timeout)
        resp.raise_for_status()
        result = resp.json()
        # 共济协议：error_code 非 0 视为业务错误
        if result.get("error_code", -1) != 0:
            raise RuntimeError(f"{path} 业务错误: code={result.get('error_code')}, "
                               f"msg={result.get('error_msg')}")
        return result.get("data", {})

    def login(self) -> str:
        """建立连接，获取 token"""
        data = self._post(
            "/login",
            {
                "ip": self.callback_ip,
                "port": self.callback_port,
                "username": self.username,
                "password": self.password,
            },
            with_token=False,
        )
        self.token = data.get("token")
        if not self.token:
            raise RuntimeError("登录未返回 token")
        logger.info("登录成功，已获取 token")
        return self.token

    def logout(self) -> None:
        """释放连接"""
        try:
            self._post("/logout", {})
            logger.info("已登出")
        except Exception as e:
            logger.warning("登出失败（可忽略）: %s", e)

    def heart(self) -> None:
        """心跳检测（Push 实时模式才需要周期调用）"""
        self._post("/heart", {})

    def fetch_offline_alarms(self, begin_time: int, end_time: int,
                             is_recover: Optional[List[int]] = IS_RECOVER_FILTER,
                             event_level: Optional[List[int]] = None,
                             event_type: Optional[List[int]] = None,
                             resource_ids: Optional[List[str]] = None) -> List[Dict]:
        """查询历史告警（Pull 模式核心）"""
        data = {
            "begin_time": begin_time,
            "end_time": end_time,
            "resource_id": resource_ids or [],
            "event_level": event_level or [],
            "event_type": event_type or [],
            "is_recover": is_recover or [],
            "confirm_type": [],
            "is_accept": [],
            "masked": [],
            "cep_processed": [],
        }
        result = self._post("/offline_alarm", data)
        alarms = result.get("alarm", []) or result.get("alarms", [])
        logger.info("查询到 %d 条历史告警（时间窗口 %d~%d）", len(alarms), begin_time, end_time)
        return alarms

    @staticmethod
    def transform(alert: Dict, source: str = SOURCE) -> Dict:
        """
        共济告警 → EasyOps webhook 字段映射

        映射说明:
          guid           → alertId       唯一标识，保证触发/恢复同 ID
          event_source   → subject(标题)  路径中文描述 + 类型，便于辨识
          详细拼接        → content       告警正文
          event_time     → time          产生时间（恢复时取 recover_time）
          is_recover     → isRecover     是否恢复（按 recover 状态判定）
          resource_id 等 → alertDims     维度，用于分组/资源关联
          event_level    → extInfo       原始级别 + 映射后严重度（供重定级）
          event_type     → extInfo       原始告警类型
          整条记录        → originInfo    原始数据留存
        """
        guid = alert.get("guid") or ""
        event_source = alert.get("event_source") or "共济告警"
        content = alert.get("content") or ""
        event_level = str(alert.get("event_level", "") or "")
        event_snapshot = alert.get("event_snapshot") or ""

        # 是否恢复：有 recover_time 或 content 含「恢复」即视为恢复
        recover_time = alert.get("recover_time")
        is_recover = bool(recover_time) or "恢复" in content

        # 时间：优先 event_time，恢复时取 recover_time，兜底当前时间
        if is_recover and recover_time:
            alert_time = int(recover_time)
        else:
            alert_time = int(alert.get("event_time") or time.time())

        # 标题：中文路径 + 触发值
        subject_parts = [event_source]
        if event_snapshot:
            subject_parts.append(f"触发值={event_snapshot}")
        if not is_recover and content:
            subject_parts.append(content)
        subject = " | ".join(subject_parts)[:200]

        # 正文：完整可读描述
        level_text = {"1": "紧急", "2": "严重", "3": "重要", "4": "次要", "5": "预警"}.get(event_level, "")
        content_lines = [
            f"告警内容: {content}",
            f"告警路径: {alert.get('event_location', '')} ({event_source})",
            f"告警级别: {level_text or event_level}",
        ]
        if event_snapshot:
            content_lines.append(f"触发值: {event_snapshot}")
        if alert.get("event_suggest"):
            content_lines.append(f"处理建议: {alert.get('event_suggest')}")
        if is_recover:
            content_lines.append(f"恢复时间: {recover_time}")
            if alert.get("recover_des"):
                content_lines.append(f"恢复描述: {alert.get('recover_des')}")
        content_text = "\n".join(content_lines)

        severity = LEVEL_MAP.get(event_level, "warning")

        return {
            # alertId 用 guid 直接作为稳定标识；为避免与其他源冲突加前缀哈希
            "alertId": guid or hashlib.md5(
                f"{source}:{alert.get('resource_id', '')}:{alert_time}".encode()
            ).hexdigest(),
            "alertDims": {
                "resource_id": alert.get("resource_id", ""),
                "event_location": alert.get("event_location", ""),
                "event_source": event_source,
            },
            "metricName": "gongji_alarm",
            "value": event_snapshot,
            "subject": subject,
            "content": content_text,
            "time": alert_time,
            "isRecover": is_recover,
            "level": severity,
            "extInfo": {
                "severity": severity,
                "alertInfo": {
                    "labels": {
                        "source_system": source,
                        "event_level": event_level,
                        "masked": alert.get("masked", 0),
                    }
                },
            },
            "originInfo": alert,
            "source": source,
        }


class EasyOpsWebhookClient:
    """EasyOps 告警 webhook 客户端"""

    def __init__(self, host: str, org: str, access_id: str, timeout: int = REQUEST_TIMEOUT):
        self.url = (f"http://{host}/api/gateway/alert_portal.webhook/"
                    f"api/v1/alert/common/{org}/{access_id}")
        self.timeout = timeout

    @retry()
    def push(self, alert: Dict) -> bool:
        """推送单条告警，返回是否成功"""
        logger.info("推送告警: %s", alert)
        resp = requests.post(self.url,
                             headers={"Content-Type": "application/json"},
                             data=json.dumps(alert, ensure_ascii=False).encode("utf-8"),
                             timeout=self.timeout)
        # resp.raise_for_status()
        result = resp.json()
        if result.get("code") != 0:
            logger.error("EasyOps 推送失败: %s", result.get("message"))
            return False
        logger.info("EasyOps 推送成功: {}".format(resp.text))
        
        return True


def main():
    """主流程：登录 → 查询告警 → 转换推送 → 登出"""
    now = int(time.time())
    begin_time = now - LOOKBACK_HOURS * 3600

    ems = GongjiClient(EMS_HOST, EMS_PORT, EMS_VERSION,
                       EMS_USERNAME, EMS_PASSWORD, CALLBACK_IP, CALLBACK_PORT)
    webhook = EasyOpsWebhookClient(EASYOPS_HOST, EASYOPS_ORG, EASYOPS_ACCESS_ID)

    # 1. 登录
    ems.login()

    success, failed = 0, 0
    try:
        # 2. 查询历史告警
        alarms = ems.fetch_offline_alarms(
            begin_time=begin_time,
            end_time=now,
            is_recover=IS_RECOVER_FILTER or None,
            event_level=EVENT_LEVEL_FILTER or None,
            event_type=EVENT_TYPE_FILTER or None,
            resource_ids=RESOURCE_ID_FILTER or None,
        )

        if MAX_PUSH > 0:
            alarms = alarms[:MAX_PUSH]

        # 3. 转换并推送
        for alarm in alarms:
            try:
                payload = GongjiClient.transform(alarm, SOURCE)
                if webhook.push(payload):
                    success += 1
                    logger.debug("推送成功: guid=%s isRecover=%s", payload["alertId"], payload["isRecover"])
                else:
                    failed += 1
            except Exception as e:
                failed += 1
                logger.error("处理告警失败(guid=%s): %s", alarm.get("guid"), e)
    finally:
        # 4. 登出
        ems.logout()

    logger.info("接入完成: 成功 %d, 失败 %d（共 %d 条）", success, failed, success + failed)
    return {"success": success, "failed": failed}


if __name__ == "__main__":
    # ============ 使用示例 ============
    # 1) 按需修改上方「配置区域」的参数（共济地址/账号、EasyOps host/org/accessId）
    # 2) 安装依赖: pip install requests
    # 3) 直接运行（一次性拉取最近 LOOKBACK_HOURS 小时的活动告警并推送）:
    #
    #        python gongji_alarm_pusher.py
    #
    # 4) 如只接入特定对象/级别，调整 RESOURCE_ID_FILTER / EVENT_LEVEL_FILTER 后再运行。
    #
    # ----------------------------------------------------------------
    # Push 实时模式（可选，需常驻服务，违反一次性规范故不在此默认实现）:
    #   - login 后调用 ems.fetch 方式订阅: POST /north/online_alarm_subscribe {subscribe:true}
    #   - 在 CALLBACK_IP:CALLBACK_PORT 起一个 HTTP 服务，接收 EMS 推送的
    #     POST /north/online_alarm_push（data 结构见 apis/gongji-ems-api.yaml 的 PushAlarmData）
    #   - 按 msg_type 取 event_alarm(产生)/event_recover(恢复)/event_accept/event_confirm，
    #     调用 GongjiClient.transform 推送到 EasyOps
    #   - 另起线程每 20s 调用 ems.heart() 维持 token，否则 30s 后 token 失效需重新登录
    # ----------------------------------------------------------------
    result = main()
    print(f"接入结果: {result}")
