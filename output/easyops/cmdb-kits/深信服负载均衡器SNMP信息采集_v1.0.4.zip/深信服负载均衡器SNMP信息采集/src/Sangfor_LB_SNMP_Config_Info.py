#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
# tool_name: 深信服负载均衡器SNMP信息采集
from __future__ import print_function

import os
import sys
import json
import logging
import warnings
import subprocess

warnings.filterwarnings("ignore")
reload(sys)
sys.setdefaultencoding('utf8')

# =====================================================================
# 参数定义（.py 运行时：从环境变量获取，无默认值）
# =====================================================================
instance_id = os.environ.get("EASYOPS_COLLECTOR_instanceId")
ip = os.environ.get("EASYOPS_COLLECTOR_ip")
snmp_port = os.environ.get("EASYOPS_COLLECTOR_snmpPort")
auth_raw = os.environ.get("EASYOPS_COLLECTOR_auth")
# snmpwalk/snmpget 命令路径：直接使用系统 PATH（套件已移除 installPath 模型属性入参）
install_path = None

# 日志初始化
current_dir = os.path.dirname(os.path.abspath(__file__))
_SAMPLER_SCRIPTS = os.path.normpath(os.path.join(current_dir, '..', '..', '..', 'easy_process_sampler', 'scripts'))
if _SAMPLER_SCRIPTS not in sys.path:
    sys.path.insert(0, _SAMPLER_SCRIPTS)

FORMAT = '[%(asctime)s (line:%(lineno)d) %(levelname)s] %(message)s'
logging.basicConfig(level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S', format=FORMAT)
logger = logging.getLogger(__name__)


# =====================================================================
# 常量：模型 ID / 关系字段 / OID 表
# =====================================================================
MODEL_LB = "LOADBALANCER@ONEMODEL"
MODEL_NETDPORT = "NETDPORT@ONEMODEL"

# NETDPORT 指向所属网络设备(LOADBALANCER 继承 BASE_NETWARE)的关系字段
# 见 NETDPORT relation_list: left_id=base_netware -> BASE_NETWARE@ONEMODEL
REL_NETDPORT_TO_LB = "base_netware"

# 人工维护字段（无 c 前缀），采集不写
HUMAN_MANAGED_FIELDS = {"brand", "mdl", "sn", "assetsSn"}

# SANGFOR-GENERAL-MIB / RFC1213-MIB OID 表（深信服 AD 负载均衡器）
OID = {
    # ---- 系统/硬件（LOADBALANCER 主体）----
    "sysDescr": ".1.3.6.1.2.1.1.1.0",
    "sysObjectID": ".1.3.6.1.2.1.1.2.0",
    "sysUpTime": ".1.3.6.1.2.1.1.3.0",
    "sysName": ".1.3.6.1.2.1.1.5.0",
    "sfDeviceDescr": ".1.3.6.1.4.1.35047.1.1.0",       # 平台类型(硬件型号)
    "adEquipType": ".1.3.6.1.4.1.35047.2.2.26.0",     # AD设备类型
    "adSysName": ".1.3.6.1.4.1.35047.2.2.31.0",       # 设备主机名称
    "adSerialNumber": ".1.3.6.1.4.1.35047.2.2.95.0",  # 设备序列号
    "adVersion": ".1.3.6.1.4.1.35047.2.2.40.0",       # AD当前版本
    "adAppVersion": ".1.3.6.1.4.1.35047.2.2.27.0",    # 版本名称
    "adCpuNum": ".1.3.6.1.4.1.35047.2.2.16.0",        # CPU个数
    "adCoresPerCpu": ".1.3.6.1.4.1.35047.2.2.17.0",   # 每CPU核心数
    "adInterfaceNumber": ".1.3.6.1.4.1.35047.2.2.44.0",  # 网口数量
    "adDevicePattern": ".1.3.6.1.4.1.35047.2.2.47.0",   # 运行模式
    "adClusterStatus": ".1.3.6.1.4.1.35047.2.2.18.0",   # 集群状态
    "adVsNumber": ".1.3.6.1.4.1.35047.2.2.22.0",        # 虚拟服务数量
    "adPoolNumber": ".1.3.6.1.4.1.35047.2.2.23.0",      # 节点池数量
    "adNodeNumber": ".1.3.6.1.4.1.35047.2.2.24.0",      # 节点数量
    "adUptime": ".1.3.6.1.4.1.35047.2.2.46.0",          # 运行时长(秒)
    # ---- 虚拟服务 Table (adVsXxx.x) ----
    "vs_name": ".1.3.6.1.4.1.35047.2.2.11.1.2",
    "vs_status": ".1.3.6.1.4.1.35047.2.2.11.1.3",
    "vs_ip": ".1.3.6.1.4.1.35047.2.2.11.1.16",
    "vs_port": ".1.3.6.1.4.1.35047.2.2.11.1.19",
    "vs_health": ".1.3.6.1.4.1.35047.2.2.11.1.17",
    "vs_health_cnt": ".1.3.6.1.4.1.35047.2.2.11.1.18",
    "vs_conn_cur": ".1.3.6.1.4.1.35047.2.2.11.1.9",
    "vs_def_pool": ".1.3.6.1.4.1.35047.2.2.11.1.25",
    # ---- 网口 RFC1213 ifTable ----
    "ifIndex": ".1.3.6.1.2.1.2.2.1.1",
    "ifDescr": ".1.3.6.1.2.1.2.2.1.2",
    "ifType": ".1.3.6.1.2.1.2.2.1.3",
    "ifMtu": ".1.3.6.1.2.1.2.2.1.4",
    "ifSpeed": ".1.3.6.1.2.1.2.2.1.5",
    "ifPhysAddress": ".1.3.6.1.2.1.2.2.1.6",
    "ifAdminStatus": ".1.3.6.1.2.1.2.2.1.7",
    "ifOperStatus": ".1.3.6.1.2.1.2.2.1.8",
    # ---- ARP / 路由 ----
    "arp_ip": ".1.3.6.1.2.1.4.22.1.1",
    "arp_mac": ".1.3.6.1.2.1.4.22.1.2",
    "route_dest": ".1.3.6.1.2.1.4.21.1.1",
    "route_next": ".1.3.6.1.2.1.4.21.1.7",
    "route_proto": ".1.3.6.1.2.1.4.21.1.9",
    # ---- 硬件实体 ENTITY-MIB (entPhysicalTable) ----
    # 通用标准 MIB（1.3.6.1.2.1.47），枚举物理组件：风扇/电源/端口模块/传感器
    "entPhysicalClass": ".1.3.6.1.2.1.47.1.1.1.1.5",     # 实体类别(枚举: 6=电源 7=风扇 5=端口 8=传感器)
    "entPhysicalDescr": ".1.3.6.1.2.1.47.1.1.1.1.2",     # 实体描述(可解析型号)
    "entPhysicalName": ".1.3.6.1.2.1.47.1.1.1.1.7",      # 实体名称
    "entPhysicalMfgName": ".1.3.6.1.2.1.47.1.1.1.1.12",  # 厂商
    "entPhysicalModelName": ".1.3.6.1.2.1.47.1.1.1.1.13", # 型号名称
    "entPhysicalSerialNum": ".1.3.6.1.2.1.47.1.1.1.1.11", # 序列号
}

# ifType 常见值 -> 简称
IF_TYPE_MAP = {
    "6": "ethernetCsmacd",
    "24": "softwareLoopback",
    "1": "other",
    "135": "l2vlan",
    "161": "tunnel",
    "53": "propVirtual",
}


# =====================================================================
# SNMP 客户端：通过 snmpwalk/snmpget 命令，支持 v1/v2c/v3（auth 结构体）
# =====================================================================
def _resolve_cmd(name):
    """拼接命令路径：installPath 存在且可执行则用绝对路径，否则回退到 PATH。"""
    if install_path:
        candidate = os.path.join(install_path, "bin", name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
        candidate2 = os.path.join(install_path, name)
        if os.path.isfile(candidate2) and os.access(candidate2, os.X_OK):
            return candidate2
    return name


def _parse_auth(auth_raw):
    """解析 auth 结构体（平台传入 JSON 字符串），返回 SNMP 版本相关参数。

    :param auth_raw: auth JSON 字符串
    :return: dict，含 version/community 或 v3 各字段
    """
    try:
        auth = json.loads(auth_raw) if auth_raw else {}
    except (ValueError, TypeError):
        auth = {}
    if not isinstance(auth, dict):
        auth = {}
    version = str(auth.get("snmpVersion") or auth.get("snmp_version") or "2c").lower()
    if version in ("2", "v2"):
        version = "2c"
    if version in ("1", "v1"):
        version = "1"
    info = {"version": version}
    info["community"] = auth.get("community") or auth.get("communityString") or "public"
    info["securityLevel"] = str(auth.get("securityLevel") or auth.get("security_level") or "")
    info["securityName"] = auth.get("securityName") or auth.get("security_name") or ""
    info["authProtocol"] = str(auth.get("authProtocol") or auth.get("auth_protocol") or "").upper()
    info["authKey"] = auth.get("authKey") or auth.get("auth_key") or ""
    info["privProtocol"] = str(auth.get("privProtocol") or auth.get("priv_protocol") or "").upper()
    info["privKey"] = auth.get("privKey") or auth.get("priv_key") or ""
    info["contextName"] = auth.get("contextName") or auth.get("context_name") or ""
    return info


def _build_common_args(auth_info):
    """构建 snmp 命令的公共参数（版本与认证）。"""
    args = ["-On"]  # 数字 OID 输出，便于解析
    ver = auth_info["version"]
    args += ["-v", ver]
    if ver in ("1", "2c"):
        args += ["-c", auth_info["community"]]
    else:
        # v3
        args += ["-l", auth_info["securityLevel"] or "noAuthNoPriv"]
        if auth_info["securityName"]:
            args += ["-u", auth_info["securityName"]]
        if auth_info["authProtocol"]:
            args += ["-a", auth_info["authProtocol"]]
            if auth_info["authKey"]:
                args += ["-A", auth_info["authKey"]]
        if auth_info["privProtocol"]:
            args += ["-x", auth_info["privProtocol"]]
            if auth_info["privKey"]:
                args += ["-X", auth_info["privKey"]]
        if auth_info["contextName"]:
            args += ["-n", auth_info["contextName"]]
    return args


def _run_snmp(cmd):
    """执行 snmp 命令，返回 stdout 文本（失败返回空串）。"""
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = proc.communicate()
        if proc.returncode != 0:
            err = ""
            if stderr:
                err = stderr.decode('utf-8', errors='ignore') if isinstance(stderr, bytes) else stderr
            logger.warning("SNMP 命令返回非0: %s, err=%s", " ".join(cmd[:6]), err.strip()[:200])
            return ""
        if stdout:
            return stdout.decode('utf-8', errors='ignore') if isinstance(stdout, bytes) else stdout
        return ""
    except OSError as e:
        logger.error("SNMP 命令执行失败(命令可能未安装): %s", str(e))
        return ""


def _parse_snmp_line(line):
    """解析一行 snmp 输出，返回 (oid_full, value, type_tag)。

    格式如: .1.3.6.1.2.1.1.5.0 = STRING: "localhost"
            .1.3.6.1.2.1.2.2.1.5.2 = Gauge32: 1000000000
    """
    if '=' not in line:
        return None, None, None
    left, right = line.split('=', 1)
    oid_full = left.strip()
    right = right.strip()
    type_tag = ""
    value = right
    if ':' in right:
        type_tag, _, value = right.partition(':')
        type_tag = type_tag.strip()
        value = value.strip()
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        value = value[1:-1]
    return oid_full, value, type_tag


def _value_clean(value, type_tag):
    """根据类型清洗值。"""
    if value is None:
        return ""
    if type_tag in ("INTEGER", "Integer32", "Gauge32", "Counter32", "Counter64", "Timeticks"):
        v = value
        if v.startswith("("):
            v = v[1:].split(")")[0]
        try:
            return str(int(v))
        except (ValueError, TypeError):
            return value
    return value


def _hex_to_mac(value):
    """Hex-STRING 'AA BB CC DD EE FF' -> 'AA:BB:CC:DD:EE:FF'。"""
    if not value:
        return ""
    parts = value.strip().split()
    if len(parts) == 6 and all(len(p) == 2 for p in parts):
        return ":".join(parts).upper()
    return value


class SNMPClient(object):
    """SNMP 客户端，封装 get/walk，按 auth 结构体构造命令。"""

    def __init__(self, target_ip, target_port, auth_info):
        self.endpoint = "{}:{}".format(target_ip, target_port)
        self.auth_info = auth_info

    def get(self, oid):
        """SNMP GET 单值，返回清洗后的字符串。"""
        cmd = [_resolve_cmd("snmpget")] + _build_common_args(self.auth_info) + [self.endpoint, oid]
        out = _run_snmp(cmd)
        if not out:
            return ""
        for line in out.splitlines():
            _, value, type_tag = _parse_snmp_line(line)
            if value is not None:
                return _value_clean(value, type_tag)
        return ""

    def walk_table(self, oid):
        """SNMP WALK 一个 table OID，返回 [(oid_full, value, type_tag), ...]。"""
        cmd = [_resolve_cmd("snmpwalk")] + _build_common_args(self.auth_info) + [self.endpoint, oid]
        out = _run_snmp(cmd)
        results = []
        if not out:
            return results
        for line in out.splitlines():
            oid_full, value, type_tag = _parse_snmp_line(line)
            if oid_full is None:
                continue
            results.append((oid_full, _value_clean(value, type_tag), type_tag))
        return results


def _index_from_oid(oid_full, base_oid):
    """从 OID 全路径提取 table 索引。

    如 base=.1.3.6.1.2.1.2.2.1.2, oid_full=.1.3.6.1.2.1.2.2.1.2.3 -> "3"
    """
    if oid_full.startswith(base_oid):
        return oid_full[len(base_oid):].lstrip(".")
    return oid_full.rsplit(".", 1)[-1]


def _safe_put(d, key, value):
    """非空才写入。"""
    if value not in ("", None):
        d[key] = value


# =====================================================================
# 采集逻辑
# =====================================================================
# entPhysicalClass 枚举（ENTITY-MIB 标准定义）
# =====================================================================
PHYS_CLASS_PORT = 5         # 端口/网口模块
PHYS_CLASS_POWER = 6        # 电源
PHYS_CLASS_FAN = 7          # 风扇
PHYS_CLASS_SENSOR = 8       # 传感器（多为温度/电压）


def _entity_table_map(client, base_oid):
    """walk 一个 ENTITY-MIB 表字段，返回 {entityIndex: 字符串值}。"""
    out = {}
    for oid_full, value, _type in client.walk_table(base_oid):
        idx = _index_from_oid(oid_full, base_oid)
        if value is None:
            continue
        val = str(value).strip().strip('"')
        if val != "":
            out[idx] = val
    return out


def _entity_class_map(client):
    """walk entPhysicalClass，返回 {entityIndex: class整数}。"""
    out = {}
    for oid_full, value, _type in client.walk_table(OID["entPhysicalClass"]):
        idx = _index_from_oid(oid_full, OID["entPhysicalClass"])
        try:
            out[idx] = int(str(value).strip())
        except (ValueError, TypeError):
            continue
    return out


def collect_hardware_entities(client):
    """通过通用 ENTITY-MIB 采集风扇/电源/网卡物理实体信息。

    返回 dict，可能含：
        fanInfo    - [{name, model, sn, brand, type, currentReading}]
        powersInfo - [{name, sn, brand, model, type}]
        networkInfo- [{name, brand, model, sn, type}]
    任一类别无数据则该 key 不出现（不覆盖已有值）。

    说明：fanInfo.currentReading（风扇转速/传感器读数）需 ENTITY-SENSOR-MIB(99)，
    本函数基于 ENTITY-MIB(47) 仅采集实体属性（名称/型号/序列号/厂商），读数留空。
    """
    cls_map = _entity_class_map(client)
    if not cls_map:
        logger.info("ENTITY-MIB entPhysicalClass 无数据，跳过硬件实体采集")
        return {}

    name_map = _entity_table_map(client, OID["entPhysicalName"])
    descr_map = _entity_table_map(client, OID["entPhysicalDescr"])
    mfg_map = _entity_table_map(client, OID["entPhysicalMfgName"])
    model_map = _entity_table_map(client, OID["entPhysicalModelName"])
    sn_map = _entity_table_map(client, OID["entPhysicalSerialNum"])

    fan_info, power_info, network_info = [], [], []

    for idx, cls in cls_map.items():
        name = name_map.get(idx, "")
        # 名称作为类别判断的补充依据（部分设备 class 不规范）
        nm_up = name.upper()

        def _base_entity():
            """组装实体公共字段。"""
            model = model_map.get(idx, "") or descr_map.get(idx, "")
            return {
                "name": name,
                "brand": mfg_map.get(idx, ""),
                "model": model,
                "sn": sn_map.get(idx, ""),
                "type": name or descr_map.get(idx, ""),
            }

        # 风扇：class=7 或名称含 FAN/风扇
        if cls == PHYS_CLASS_FAN or "FAN" in nm_up or "风扇" in name:
            ent = _base_entity()
            ent["currentReading"] = ""  # 读数需 SENSOR-MIB，暂留空
            fan_info.append(ent)
        # 电源：class=6 或名称含 PSU/POWER/电源
        elif cls == PHYS_CLASS_POWER or _match_power_name(name):
            ent = _base_entity()
            power_info.append(ent)
        # 网卡/端口模块：class=5（端口）通常量很大，只采有型号/序列号的实体模块
        # （避免把每个物理端口都当网卡，过滤掉无 hw 信息的纯逻辑端口）
        elif cls == PHYS_CLASS_PORT and (model_map.get(idx) or sn_map.get(idx)):
            ent = _base_entity()
            network_info.append(ent)

    result = {}
    if fan_info:
        result["fanInfo"] = fan_info
    if power_info:
        result["powersInfo"] = power_info
    if network_info:
        result["networkInfo"] = network_info
    logger.info("硬件实体采集: 风扇=%d 电源=%d 网卡模块=%d",
                len(fan_info), len(power_info), len(network_info))
    return result


def _match_power_name(name):
    """名称是否像电源（class 不规范时辅助判断）。"""
    if not name:
        return False
    up = name.upper()
    return "PSU" in up or "POWER" in up or "PWR" in up or "电源" in name


# =====================================================================
def collect_lb_main(client):
    """采集 LOADBALANCER 主体字段。"""
    vals = {}
    sys_descr = client.get(OID["sysDescr"])
    sys_name = client.get(OID["sysName"])
    ad_sys_name = client.get(OID["adSysName"])
    sf_dev = client.get(OID["sfDeviceDescr"])
    ad_equip = client.get(OID["adEquipType"])
    ad_sn = client.get(OID["adSerialNumber"])
    sys_obj = client.get(OID["sysObjectID"])

    # 厂商：sysObjectID 含 enterprises.35047 = 深信服
    brand = "深信服(SANGFOR)"
    if sys_obj and "35047" not in sys_obj:
        brand = sys_obj

    name = ad_sys_name or sys_name or ""
    # 采集字段（c 前缀）
    vals["cSysName"] = name
    vals["cSysDescr"] = sys_descr
    vals["cUpTime"] = client.get(OID["adUptime"]) or client.get(OID["sysUpTime"])
    vals["cMdl"] = sf_dev or ad_equip
    vals["cSn"] = ad_sn
    vals["cBrand"] = brand
    # 通用业务字段（继承）
    if name:
        vals["deviceName"] = name
    vals["sysVersion"] = client.get(OID["adVersion"]) or client.get(OID["adAppVersion"])
    vals["sysObjectId"] = sys_obj

    # 扩展采集字段（模型已有则直接写，无则可后续补建）
    _safe_put(vals, "cCpuNum", client.get(OID["adCpuNum"]))
    _safe_put(vals, "cCoresPerCpu", client.get(OID["adCoresPerCpu"]))
    _safe_put(vals, "cIfNumber", client.get(OID["adInterfaceNumber"]))
    _safe_put(vals, "cDevicePattern", client.get(OID["adDevicePattern"]))
    _safe_put(vals, "cClusterStatus", client.get(OID["adClusterStatus"]))
    _safe_put(vals, "cVsNumber", client.get(OID["adVsNumber"]))
    _safe_put(vals, "cPoolNumber", client.get(OID["adPoolNumber"]))
    _safe_put(vals, "cNodeNumber", client.get(OID["adNodeNumber"]))

    # 过滤人工维护字段
    vals = {k: v for k, v in vals.items() if k not in HUMAN_MANAGED_FIELDS and v not in ("", None)}
    return vals


def collect_virtual_services(client):
    """采集虚拟服务，按 table 索引对齐，返回 struct 数组。"""
    def _table_map(base_oid):
        out = {}
        for oid_full, value, _ in client.walk_table(base_oid):
            idx = _index_from_oid(oid_full, base_oid)
            out[idx] = value
        return out

    names = _table_map(OID["vs_name"])
    if not names:
        return []
    ips = _table_map(OID["vs_ip"])
    ports = _table_map(OID["vs_port"])
    status = _table_map(OID["vs_status"])
    health = _table_map(OID["vs_health"])
    health_cnt = _table_map(OID["vs_health_cnt"])
    conn_cur = _table_map(OID["vs_conn_cur"])
    def_pool = _table_map(OID["vs_def_pool"])

    result = []
    for idx, name in names.items():
        item = {
            "name": name,
            "ip": ips.get(idx, ""),
            "port": ports.get(idx, ""),
            "status": status.get(idx, ""),
            "healthStatus": health.get(idx, ""),
            "healthNodeCount": health_cnt.get(idx, ""),
            "connsCur": conn_cur.get(idx, ""),
            "defNodePool": def_pool.get(idx, ""),
        }
        item = {k: v for k, v in item.items() if v not in ("", None)}
        if item.get("name") or item.get("ip"):
            result.append(item)
    return result


def _collect_arp(client):
    """采集 ARP 表 -> structs [{ip, mac}]。"""
    macs = {}
    for oid_full, value, type_tag in client.walk_table(OID["arp_mac"]):
        idx = _index_from_oid(oid_full, OID["arp_mac"])
        if type_tag == "Hex-STRING":
            value = _hex_to_mac(value)
        macs[idx] = value
    ips = {}
    for oid_full, value, _ in client.walk_table(OID["arp_ip"]):
        idx = _index_from_oid(oid_full, OID["arp_ip"])
        ips[idx] = value
    result = []
    seen = set()
    for idx, mac in macs.items():
        ip_addr = ips.get(idx, "")
        key = (ip_addr, mac)
        if key in seen:
            continue
        seen.add(key)
        result.append({"ip": ip_addr, "mac": mac})
    return result[:500]


def _collect_routes(client):
    """采集路由表 -> structs [{target, next_ip, type}]。"""
    dests = {}
    for oid_full, value, _ in client.walk_table(OID["route_dest"]):
        idx = _index_from_oid(oid_full, OID["route_dest"])
        dests[idx] = value
    nexts = {}
    for oid_full, value, _ in client.walk_table(OID["route_next"]):
        idx = _index_from_oid(oid_full, OID["route_next"])
        nexts[idx] = value
    protos = {}
    for oid_full, value, _ in client.walk_table(OID["route_proto"]):
        idx = _index_from_oid(oid_full, OID["route_proto"])
        protos[idx] = value
    proto_map = {"1": "other", "2": "local", "3": "netmgmt", "4": "icmp", "5": "egp",
                 "8": "rip", "13": "ospf", "14": "bgp"}
    result = []
    for idx, dest in dests.items():
        result.append({
            "target": dest,
            "next_ip": nexts.get(idx, ""),
            "type": proto_map.get(str(protos.get(idx, "")).strip(), protos.get(idx, "")),
        })
    return result[:500]


def collect_netdports(client, lb_ip, lb_instance_id):
    """采集网口 NETDPORT 列表，返回 data 记录数组（含关系到 LB）。"""
    def _table_map(base_oid, hex_mac=False):
        out = {}
        for oid_full, value, type_tag in client.walk_table(base_oid):
            idx = _index_from_oid(oid_full, base_oid)
            if hex_mac and type_tag == "Hex-STRING":
                value = _hex_to_mac(value)
            out[idx] = value
        return out

    descr = _table_map(OID["ifDescr"])
    if not descr:
        return []
    types = _table_map(OID["ifType"])
    mtus = _table_map(OID["ifMtu"])
    speeds = _table_map(OID["ifSpeed"])
    macs = _table_map(OID["ifPhysAddress"], hex_mac=True)
    admin = _table_map(OID["ifAdminStatus"])
    oper = _table_map(OID["ifOperStatus"])

    arp_table = _collect_arp(client)
    route_table = _collect_routes(client)

    records = []
    for ifidx, descr_val in descr.items():
        if_name = descr_val  # AD 用 ifDescr 作为接口名
        port_name = "{}:{}".format(lb_ip, if_name)
        vals = {
            "name": port_name,
            "ifName": if_name,
            "ifDescr": descr_val,
            "ifIndex": ifidx,
            "type": IF_TYPE_MAP.get(str(types.get(ifidx, "")), types.get(ifidx, "")),
            "mtu": mtus.get(ifidx, ""),
            "speed": _speed_to_mbps(speeds.get(ifidx, "")),
            "physAddress": macs.get(ifidx, ""),
            "adminStatus": _if_status_text(admin.get(ifidx, "")),
            "operStatus": _if_status_text(oper.get(ifidx, "")),
            "sysName": lb_ip,
            "source": "自动采集",
            # 不写 deviceType：NETDPORT 的 deviceType 枚举仅含 交换机/路由器/防火墙/
            # 网络安全设备/无线控制器，无"负载均衡器"，写入会报「属性值不符合定义」。
            # 网口归属已通过下方 base_netware 关系指向 LOADBALANCER 实例。
            # 关系：所属网络设备 = 当前 LB 实例（LOADBALANCER 继承 BASE_NETWARE）
            REL_NETDPORT_TO_LB: [{"_object_id": MODEL_LB, "instanceId": lb_instance_id}],
        }
        vals = {k: v for k, v in vals.items() if v not in ("", None)}
        records.append({
            "dims": {"object_id": MODEL_NETDPORT, "pks": ["name"], "upsert": True},
            "vals": vals,
        })

    # ARP / 路由作为全局表，挂到第一个网口（避免逐口重复膨胀）
    if records and (arp_table or route_table):
        first = records[0]["vals"]
        if arp_table:
            first["arp"] = arp_table
        if route_table:
            first["route"] = route_table

    return records


def _speed_to_mbps(speed):
    """ifSpeed(bps) -> Mbps（整型）。"""
    try:
        bps = int(speed)
        if bps <= 0:
            return ""
        return str(bps // 1000000)
    except (ValueError, TypeError):
        return speed


def _if_status_text(code):
    """ifAdminStatus/ifOperStatus: 1=up 2=down 3=testing。"""
    mapping = {"1": "up", "2": "down", "3": "testing"}
    return mapping.get(str(code).strip(), str(code))


# =====================================================================
# 入口
# =====================================================================
def main():
    if not instance_id:
        logger.error("instanceId 为空，采集中止（资源采集主模型必须通过 instanceId 定位实例）")
        _emit([])
        return
    if not ip:
        logger.error("ip 为空，采集中止")
        _emit([])
        return

    auth_info = _parse_auth(auth_raw)
    port = snmp_port or "161"
    logger.info("开始采集 LB ip=%s port=%s version=%s", ip, port, auth_info["version"])

    client = SNMPClient(ip, port, auth_info)

    data = []

    # 1) LOADBALANCER 主体（采集对象，pks=instanceId）
    main_vals = collect_lb_main(client)
    vs_list = collect_virtual_services(client)
    if vs_list:
        main_vals["virtualServices"] = vs_list
    # 硬件实体信息（风扇/电源/网卡模块），通过通用 ENTITY-MIB 采集，
    # 写入 fanInfo / powersInfo / networkInfo 结构体字段（无数据则不覆盖）
    hw_info = collect_hardware_entities(client)
    main_vals.update(hw_info)
    # dims 指定 pks=["instanceId"]，vals 必须显式带上 instanceId（取自入参），
    # 否则平台校验唯一键时找不到 instanceId，报「上报唯一键字段instanceId值不存在或为空」
    main_vals["instanceId"] = instance_id
    data.append({
        "dims": {"object_id": MODEL_LB, "pks": ["instanceId"], "upsert": True},
        "vals": main_vals,
    })

    # 2) NETDPORT 网口（关联模型，pks=name，关系 base_netware -> LB）
    netdports = collect_netdports(client, ip, instance_id)
    data.extend(netdports)

    logger.info("采集完成: LB 字段数=%d, 虚拟服务=%d, 网口=%d",
                len(main_vals), len(vs_list), len(netdports))

    _emit(data)


def _emit(data):
    """输出采集结果（GATHERING DATA 标记包裹）。"""
    print("-----BEGIN GATHERING DATA-----")
    print(json.dumps(data, indent=4, ensure_ascii=False))
    print("-----END GATHERING DATA-----")


if __name__ == "__main__":
    main()
