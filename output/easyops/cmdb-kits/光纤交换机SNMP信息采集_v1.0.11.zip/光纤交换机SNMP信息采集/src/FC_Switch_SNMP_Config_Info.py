#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
# tool_name: 光纤交换机SNMP信息采集
"""光纤交换机 SNMP 信息采集脚本。

采集流程：
1. 从实例 auth 字段解析 SNMP 认证信息（v1/v2c/v3 完整支持）。
2. 通过 sysObjectID 和 sysDescr 探测品牌（Brocade / Huawei / Other）。
3. 选择对应的品牌采集器（BaseCollector + 品牌覆盖）。
4. 采集主模型字段（FIBERCHANNEL_SWITCH）：系统、端口统计、风扇、电源。
5. 采集 FC 端口（FIBERCHANNEL_SWITCH_PORT，含连接设备信息）、
   网络端口（NETDPORT）、Zone 配置（FIBERCHANNEL_CFG）。
6. 主模型以 instanceId 作为写入唯一键，确保更新到当前采集实例。

扩展新品牌：继承 BaseCollector 实现品牌特有方法，并在 CollectorFactory 中注册。
"""
from __future__ import print_function

import os
import sys
import json
import logging
import warnings
import subprocess
import re

warnings.filterwarnings("ignore")
reload(sys)
sys.setdefaultencoding('utf8')

# ---------------- 参数获取 ----------------
# .orig 保留默认值便于本地调试；.py 由 scaffold 去掉默认值。
instanceId = os.environ.get("EASYOPS_COLLECTOR_instanceId")
ip = os.environ.get("EASYOPS_COLLECTOR_ip")
snmpPort = os.environ.get("EASYOPS_COLLECTOR_snmpPort")
_auth_raw = os.environ.get("EASYOPS_COLLECTOR_auth") or "{}"
try:
    auth = json.loads(_auth_raw) if isinstance(_auth_raw, str) else (_auth_raw or {})
except (ValueError, TypeError):
    auth = {}

# 日志初始化
current_dir = os.path.dirname(os.path.abspath(__file__))
_SAMPLER_SCRIPTS = os.path.normpath(os.path.join(current_dir, '..', '..', '..', 'easy_process_sampler', 'scripts'))
if _SAMPLER_SCRIPTS not in sys.path:
    sys.path.insert(0, _SAMPLER_SCRIPTS)

FORMAT = '[%(asctime)s (line:%(lineno)d) %(levelname)s] %(message)s'
logging.basicConfig(level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S', format=FORMAT)
log = logging.getLogger(__name__)

# ---------------- OID 常量 ----------------
# SNMPv2-MIB
OID_SYS_DESCR = "1.3.6.1.2.1.1.1.0"
OID_SYS_OBJECT_ID = "1.3.6.1.2.1.1.2.0"
OID_SYS_UPTIME = "1.3.6.1.2.1.1.3.0"
OID_SYS_NAME = "1.3.6.1.2.1.1.5.0"

# FCMGMT-MIB connUnitTable
OID_CU_WWN = "1.3.6.1.3.94.1.6.1.2"
OID_CU_NUM_PORT = "1.3.6.1.3.94.1.6.1.4"
OID_CU_PRODUCT = "1.3.6.1.3.94.1.6.1.7"
OID_CU_SERIAL = "1.3.6.1.3.94.1.6.1.8"
OID_CU_DOMAIN = "1.3.6.1.3.94.1.6.1.11"
OID_CU_NUM_ZONES = "1.3.6.1.3.94.1.6.1.18"
OID_CU_NAME = "1.3.6.1.3.94.1.6.1.20"
OID_CU_VENDOR = "1.3.6.1.3.94.1.6.1.31"

# FCMGMT-MIB connUnitPortTable
OID_PORT_INDEX = "1.3.6.1.3.94.1.10.1.2"
OID_PORT_TYPE = "1.3.6.1.3.94.1.10.1.3"
OID_PORT_STATE = "1.3.6.1.3.94.1.10.1.4"
OID_PORT_OPER_STATUS = "1.3.6.1.3.94.1.10.1.7"
OID_PORT_WWN = "1.3.6.1.3.94.1.10.1.10"
OID_PORT_FCID = "1.3.6.1.3.94.1.10.1.11"
OID_PORT_SPEED = "1.3.6.1.3.94.1.10.1.15"
OID_PORT_NAME = "1.3.6.1.3.94.1.10.1.17"
OID_PORT_REMOTE_PORT_WWN = "1.3.6.1.3.94.1.10.1.20"
OID_PORT_REMOTE_NODE_WWN = "1.3.6.1.3.94.1.10.1.21"

# FCMGMT-MIB connUnitLinkTable（链路邻接，ISL 场景有用）
OID_LINK_LOCAL_UNIT = "1.3.6.1.3.94.1.12.1.2"
OID_LINK_LOCAL_PORT = "1.3.6.1.3.94.1.12.1.3"
OID_LINK_REMOTE_UNIT = "1.3.6.1.3.94.1.12.1.4"
OID_LINK_REMOTE_PORT = "1.3.6.1.3.94.1.12.1.5"
OID_LINK_REMOTE_NODE_WWN = "1.3.6.1.3.94.1.12.1.6"
OID_LINK_STATUS = "1.3.6.1.3.94.1.12.1.7"
OID_LINK_REMOTE_PORT_WWN = "1.3.6.1.3.94.1.12.1.8"
OID_LINK_REMOTE_ADDR = "1.3.6.1.3.94.1.12.1.9"

# IF-MIB
OID_IF_INDEX = "1.3.6.1.2.1.2.2.1.1"
OID_IF_DESCR = "1.3.6.1.2.1.2.2.1.2"
OID_IF_TYPE = "1.3.6.1.2.1.2.2.1.3"
OID_IF_MTU = "1.3.6.1.2.1.2.2.1.4"
OID_IF_SPEED = "1.3.6.1.2.1.2.2.1.5"
OID_IF_PHYS = "1.3.6.1.2.1.2.2.1.6"
OID_IF_ADMIN = "1.3.6.1.2.1.2.2.1.7"
OID_IF_OPER = "1.3.6.1.2.1.2.2.1.8"
OID_IFX_NAME = "1.3.6.1.2.1.31.1.1.1.1"
OID_IFX_ALIAS = "1.3.6.1.2.1.31.1.1.1.18"
OID_IFX_HIGH_SPEED = "1.3.6.1.2.1.31.1.1.1.15"

# ENTITY-MIB entPhysicalTable（电源/风扇/模块物理实体）
OID_ENT_PHY_DESCR = "1.3.6.1.2.1.47.1.1.1.1.2"
OID_ENT_PHY_CONTAINED_IN = "1.3.6.1.2.1.47.1.1.1.1.4"
OID_ENT_PHY_CLASS = "1.3.6.1.2.1.47.1.1.1.1.5"
OID_ENT_PHY_REL_POS = "1.3.6.1.2.1.47.1.1.1.1.6"
OID_ENT_PHY_NAME = "1.3.6.1.2.1.47.1.1.1.1.7"
OID_ENT_PHY_HWREV = "1.3.6.1.2.1.47.1.1.1.1.8"
OID_ENT_PHY_FWREV = "1.3.6.1.2.1.47.1.1.1.1.9"
OID_ENT_PHY_SERIAL = "1.3.6.1.2.1.47.1.1.1.1.11"
OID_ENT_PHY_MFG = "1.3.6.1.2.1.47.1.1.1.1.12"
OID_ENT_PHY_MODEL = "1.3.6.1.2.1.47.1.1.1.1.13"
OID_ENT_PHY_IS_FRU = "1.3.6.1.2.1.47.1.1.1.1.16"

# ENTITY-SENSOR-MIB entPhySensorTable（风扇转速、温度等传感器读数）
OID_PHY_SENSOR_TYPE = "1.3.6.1.2.1.99.1.1.1.1"   # 1=other 2=unknown 3=voltsAC 4=voltsDC 5=amperes 6=watts 7=hertz 8=celsius 9=percentRH 10=rpm 11=cmm
OID_PHY_SENSOR_SCALE = "1.3.6.1.2.1.99.1.1.1.2"
OID_PHY_SENSOR_VALUE = "1.3.6.1.2.1.99.1.1.1.4"
OID_PHY_SENSOR_STATUS = "1.3.6.1.2.1.99.1.1.1.5"

# Brocade SW-MIB
OID_BRCD_FW_VERSION = "1.3.6.1.4.1.1588.2.1.1.1.1.6.0"
OID_BRCD_OPER_STATUS = "1.3.6.1.4.1.1588.2.1.1.1.1.7.0"
OID_BRCD_ADMIN_STATUS = "1.3.6.1.4.1.1588.2.1.1.1.1.8.0"
OID_BRCD_SERIAL = "1.3.6.1.4.1.1588.2.1.1.1.1.10.0"
OID_BRCD_OVERALL = "1.3.6.1.4.1.1588.2.1.1.1.1.11.0"
OID_BRCD_DOMAIN = "1.3.6.1.4.1.1588.2.1.1.1.2.1.0"
OID_BRCD_PORT_OPER = "1.3.6.1.4.1.1588.2.1.1.1.6.2.1.4"
OID_BRCD_PORT_ADMIN = "1.3.6.1.4.1.1588.2.1.1.1.6.2.1.5"
OID_BRCD_PORT_WWN = "1.3.6.1.4.1.1588.2.1.1.1.6.2.1.34"
OID_BRCD_PORT_SPEED = "1.3.6.1.4.1.1588.2.1.1.1.6.2.1.35"
OID_BRCD_PORT_NAME = "1.3.6.1.4.1.1588.2.1.1.1.6.2.1.36"
OID_BRCD_PORT_TYPE = "1.3.6.1.4.1.1588.2.1.1.1.6.2.1.39"
# Brocade 传感器/风扇/电源私有表（FOS 版本差异较大，使用动态列解析兜底）
OID_BRCD_SENSOR_TABLE = "1.3.6.1.4.1.1588.2.1.1.1.1.22.1"

# Huawei
OID_HUAWEI_ROOT = "1.3.6.1.4.1.2011"
OID_BROCADE_ROOT = "1.3.6.1.4.1.1588"

# OS 平台标识（决定使用哪个 Collector）
OS_PLATFORM_BROCADE_FOS = "BrocadeFOS"   # 标准 Brocade Fabric OS（含 OEM）
OS_PLATFORM_HUAWEI = "HuaweiOceanStor"   # 华为自研 OS
OS_PLATFORM_GENERIC = "Generic"

# OEM 硬件品牌关键词识别表
OEM_BRAND_KEYWORDS = [
    ("Lenovo",   ["LENOVO"]),
    ("IBM",      ["IBM", "INTERNATIONAL BUSINESS MACHINES"]),
    ("Dell",     ["DELL"]),
    ("EMC",      ["EMC", "DELL EMC"]),
    ("NetApp",   ["NETAPP"]),
    ("Hitachi",  ["HITACHI", "HDS"]),
    ("Fujitsu",  ["FUJITSU"]),
    ("HPE",      ["HPE", "HEWLETT PACKARD", "HEWLETT-PACKARD"]),
    ("Cisco",    ["CISCO"]),
    ("H3C",      ["H3C", "NEW H3C"]),
    ("Inspur",   ["INSPUR", "浪潮"]),
    ("Sugon",    ["SUGON", "曙光"]),
    ("Huawei",   ["HUAWEI", "华为"]),
    ("Brocade",  ["BROCADE"]),
]

# 端口状态枚举映射
FCMGMT_PORT_STATE = {
    "1": "unknown", "2": "online", "3": "offline",
    "4": "bypassed", "5": "diagnostics",
}
FCMGMT_PORT_OPER = {
    "1": "unknown", "2": "unused", "3": "ready",
    "4": "warning", "5": "failure", "6": "notparticipating",
    "7": "initializing", "8": "bypass", "9": "ols",
}
FCMGMT_PORT_TYPE = {
    "1": "unknown", "2": "other", "3": "not-present",
    "4": "hub-port", "5": "n-port", "6": "nl-port",
    "7": "fl-port", "8": "f-port", "9": "e-port",
    "10": "g-port", "11": "domain-ctlr",
}

# Brocade SW-MIB swPortOperState 映射
BRCD_PORT_OPER_STATUS = {
    "1": "online", "2": "offline", "3": "testing", "4": "faulty",
    "5": "lid", "6": "lid", "7": "onlineEPort", "8": "onlineFPort",
    "9": "incompatible", "10": "incompatibleAccessDomain",
    "11": "unrecognized", "12": "initializing", "13": "lockedOffline",
}

IF_ADMIN_STATUS = {"1": "up", "2": "down", "3": "testing"}
IF_OPER_STATUS = {
    "1": "up", "2": "down", "3": "testing",
    "4": "unknown", "5": "dormant", "6": "notPresent",
    "7": "lowerLayerDown",
}

# IF-MIB ifType 中需要从 NETDPORT 过滤的类型（FC 光口已在 FIBERCHANNEL_SWITCH_PORT 中采集）
NETDPORT_EXCLUDE_IF_TYPES = {"56"}  # 56 = fibreChannel

# 在线使用的端口状态集合（用于 usedPortNum 计算）
ONLINE_PORT_STATES = {"online", "onlineeport", "onlinefport"}

# entPhysicalClass 枚举
ENT_CLASS_OTHER = "1"
ENT_CLASS_UNKNOWN = "2"
ENT_CLASS_CHASSIS = "3"
ENT_CLASS_BACKPLANE = "4"
ENT_CLASS_CONTAINER = "5"
ENT_CLASS_POWERSUPPLY = "6"
ENT_CLASS_FAN = "7"
ENT_CLASS_SENSOR = "8"
ENT_CLASS_MODULE = "9"
ENT_CLASS_PORT = "10"

# entPhySensorType 枚举（用于识别风扇转速类传感器）
PHY_SENSOR_RPM = "10"


# ---------------- SNMP 客户端 ----------------
class SNMPClient(object):
    """SNMP 客户端封装 net-snmp 命令行工具。

    支持从实例的 auth 结构体构造，覆盖 SNMPv1/v2c/v3 完整认证模式。
    """

    def __init__(self, host, port="161", version="2c",
                 community="public", security_level="", security_name="",
                 auth_protocol="", auth_key="",
                 priv_protocol="", priv_key="",
                 context_name="", timeout=10, retries=2):
        self.host = host
        self.port = str(port or "161")
        self.version = str(version or "2c")
        self.community = community or "public"
        self.security_level = (security_level or "").strip()
        self.security_name = security_name or ""
        self.auth_protocol = (auth_protocol or "").strip()
        self.auth_key = auth_key or ""
        self.priv_protocol = (priv_protocol or "").strip()
        self.priv_key = priv_key or ""
        self.context_name = context_name or ""
        self.timeout = timeout
        self.retries = retries

    @classmethod
    def from_auth(cls, host, port, auth_struct):
        """从实例 auth 结构体构造客户端。

        auth 结构体字段（来自 BASE_NETWARE.auth）：
        snmpVersion / community / securityLevel / securityName /
        authProtocol / authKey / privProtocol / privKey / contextName
        """
        a = auth_struct or {}
        version = str(a.get("snmpVersion") or "2c")
        return cls(
            host=host, port=port, version=version,
            community=a.get("community") or "",
            security_level=a.get("securityLevel") or "",
            security_name=a.get("securityName") or "",
            auth_protocol=a.get("authProtocol") or "",
            auth_key=a.get("authKey") or "",
            priv_protocol=a.get("privProtocol") or "",
            priv_key=a.get("privKey") or "",
            context_name=a.get("contextName") or "",
        )

    def _build_auth_args(self):
        """构造认证相关命令行参数（覆盖 SNMPv3 三种安全级别）。"""
        args = ["-v", self.version, "-t", str(self.timeout), "-r", str(self.retries)]
        if self.version in ("1", "2c"):
            args.extend(["-c", self.community])
            return args
        if self.version != "3":
            # 兜底：未知版本按 2c 处理
            args.extend(["-c", self.community])
            return args

        # SNMPv3
        args.extend(["-u", self.security_name or ""])
        level = self.security_level.lower() if self.security_level else ""
        if level == "noauthnopriv":
            args.extend(["-l", "noAuthNoPriv"])
        elif level == "authnopriv":
            args.extend(["-l", "authNoPriv"])
            self._append_auth(args)
        elif level == "authpriv":
            args.extend(["-l", "authPriv"])
            self._append_auth(args)
            self._append_priv(args)
        else:
            # 未指定 securityLevel，按提供的凭据推断
            if self.priv_key:
                args.extend(["-l", "authPriv"])
                self._append_auth(args)
                self._append_priv(args)
            elif self.auth_key:
                args.extend(["-l", "authNoPriv"])
                self._append_auth(args)
            else:
                args.extend(["-l", "noAuthNoPriv"])
        if self.context_name:
            args.extend(["-n", self.context_name])
        return args

    def _append_auth(self, args):
        proto = self.auth_protocol or "MD5"
        args.extend(["-a", proto, "-A", self.auth_key])

    def _append_priv(self, args):
        proto = self.priv_protocol or "DES"
        args.extend(["-x", proto, "-X", self.priv_key])

    def _run(self, cmd_name, oid):
        """执行 net-snmp 命令并返回标准输出。"""
        cmd = [cmd_name, "-On", "-Oqv" if cmd_name == "snmpget" else "-Oqn"]
        cmd.extend(self._build_auth_args())
        cmd.append("{}:{}".format(self.host, self.port))
        cmd.append(oid)
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = proc.communicate()
            if proc.returncode != 0:
                err = (stderr or b"").decode("utf-8", errors="ignore").strip()
                log.warning("SNMP %s %s failed: %s", cmd_name, oid, err)
                return None
            return (stdout or b"").decode("utf-8", errors="ignore")
        except Exception as e:
            log.error("SNMP %s %s exception: %s", cmd_name, oid, str(e))
            return None

    def get(self, oid):
        """SNMP GET：返回字符串值。"""
        out = self._run("snmpget", oid)
        if out is None:
            return None
        out = out.strip()
        if not out or "No Such" in out:
            return None
        return out.strip().strip('"')

    def walk(self, oid):
        """SNMP WALK：返回 {sub_index: value} 字典。"""
        out = self._run("snmpwalk", oid)
        if out is None:
            return {}
        result = {}
        base = oid.lstrip(".")
        for line in out.splitlines():
            line = line.strip()
            if not line or "No Such" in line:
                continue
            parts = line.split(None, 1)
            if len(parts) < 2:
                continue
            full_oid = parts[0].lstrip(".")
            value = parts[1].strip().strip('"')
            if full_oid.startswith(base + "."):
                sub_index = full_oid[len(base) + 1:]
            else:
                sub_index = full_oid
            result[sub_index] = value
        return result


# ---------------- 工具函数 ----------------
def normalize_wwn(raw):
    """规范化 WWN：转为小写冒号分隔格式。支持 8 字节和 16 字节 WWN。

    非标准长度（如 2-3 字节的 FCID）将被过滤，返回空字符串。
    """
    if not raw:
        return ""
    s = str(raw).strip()
    if not s:
        return ""
    s = s.replace("Hex-STRING:", "").replace("STRING:", "").strip()
    s = s.replace(" ", "").replace("-", "")
    if not s:
        return ""
    # 16 字节 WWN (32 hex chars)：前 8 字节有效，后 8 字节通常为零填充
    if len(s) == 32:
        tail = s[16:]
        if all(c == '0' for c in tail):
            s = s[:16]
        else:
            return ":".join(s[i:i + 2] for i in range(0, 32, 2)).lower()
    # 8 字节 WWN (16 hex chars)：格式化为冒号分隔
    if ":" not in s and len(s) == 16:
        s = ":".join(s[i:i + 2] for i in range(0, 16, 2))
    # 校验：必须是标准 8 字节 WWN 格式 (xx:xx:xx:xx:xx:xx:xx:xx)
    if ":" not in s or len(s) != 23:
        return ""
    return s.lower()


def safe_int(v, default=0):
    """安全转换为 int。"""
    try:
        if v is None or v == "":
            return default
        return int(str(v).strip())
    except (ValueError, TypeError):
        return default


def speed_to_gbps(raw):
    """端口速率（bps/Mbps）转 Gbps 整数。

    FCMGMT-MIB connUnitPortSpeed 单位是 Mbits/sec。
    """
    n = safe_int(raw, 0)
    if n <= 0:
        return 0
    if n >= 1000:
        return int(n / 1000)
    return n


def parse_snmp_int(raw):
    """解析 SNMP 返回值为整数，支持纯数字和 Hex-STRING 格式。

    Brocade 等设备的端口状态可能以 Hex-STRING 返回（如 "00 0D" → 13），
    此函数统一处理纯数字和十六进制空格分隔两种格式。
    """
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    # 去除 SNMP 类型前缀
    for prefix in ("Hex-STRING:", "STRING:", "OID:"):
        if s.startswith(prefix):
            s = s[len(prefix):].strip()
    # 尝试直接解析为十进制整数
    try:
        return int(s)
    except (ValueError, TypeError):
        pass
    # 尝试解析为十六进制空格分隔字节（如 "00 0D" → 0x0D → 13）
    hex_clean = s.replace(" ", "").replace(":", "")
    if hex_clean:
        try:
            return int(hex_clean, 16)
        except (ValueError, TypeError):
            pass
    return None


def map_port_status(raw, mapping):
    """映射端口状态值，支持纯数字和 Hex-STRING 格式。

    先尝试原始字符串匹配，再尝试解析十六进制后匹配。
    """
    if not raw:
        return ""
    s = str(raw).strip()
    if s in mapping:
        return mapping[s]
    int_val = parse_snmp_int(raw)
    if int_val is not None and str(int_val) in mapping:
        return mapping[str(int_val)]
    return s


# ---------------- 品牌探测 ----------------
class BrandDetector(object):
    """识别交换机的 **OS 平台** 与 **硬件 OEM 品牌**。"""

    def __init__(self, snmp_client):
        self.client = snmp_client

    def detect(self):
        sys_oid = self.client.get(OID_SYS_OBJECT_ID) or ""
        sys_descr = self.client.get(OID_SYS_DESCR) or ""
        oid_str = sys_oid.replace("OID:", "").strip().lstrip(".")

        os_platform = self._detect_os_platform(oid_str, sys_descr)
        oem_brand = self._detect_oem_brand(os_platform, sys_descr)

        log.info("品牌识别: os_platform=%s, oem_brand=%s", os_platform, oem_brand)
        return os_platform, oem_brand, oid_str, sys_descr

    def _detect_os_platform(self, oid_str, sys_descr):
        descr_upper = (sys_descr or "").upper()
        if oid_str.startswith(OID_HUAWEI_ROOT):
            return OS_PLATFORM_HUAWEI
        if oid_str.startswith(OID_BROCADE_ROOT):
            return OS_PLATFORM_BROCADE_FOS
        if "FABRIC OS" in descr_upper or "BROCADE" in descr_upper:
            return OS_PLATFORM_BROCADE_FOS
        if "HUAWEI" in descr_upper or "OCEANSTOR" in descr_upper:
            return OS_PLATFORM_HUAWEI
        if self.client.get(OID_BRCD_FW_VERSION):
            return OS_PLATFORM_BROCADE_FOS
        return OS_PLATFORM_GENERIC

    def _detect_oem_brand(self, os_platform, sys_descr):
        candidates = []
        vendor = _first_value(self.client.walk(OID_CU_VENDOR))
        if vendor:
            candidates.append(vendor)

        ent_class = self.client.walk(OID_ENT_PHY_CLASS)
        ent_mfg = self.client.walk(OID_ENT_PHY_MFG)
        ent_descr = self.client.walk(OID_ENT_PHY_DESCR)
        ent_model = self.client.walk(OID_ENT_PHY_MODEL)
        chassis_idx = None
        for idx, cls in ent_class.items():
            if str(cls).strip() == ENT_CLASS_CHASSIS:
                chassis_idx = idx
                break
        if chassis_idx:
            if ent_mfg.get(chassis_idx):
                candidates.append(ent_mfg[chassis_idx])
            if ent_descr.get(chassis_idx):
                candidates.append(ent_descr[chassis_idx])
            if ent_model.get(chassis_idx):
                candidates.append(ent_model[chassis_idx])

        product = _first_value(self.client.walk(OID_CU_PRODUCT))
        if product:
            candidates.append(product)

        if sys_descr:
            candidates.append(sys_descr)

        for text in candidates:
            brand = self._match_keyword(text)
            if brand:
                return brand

        return {
            OS_PLATFORM_BROCADE_FOS: "Brocade",
            OS_PLATFORM_HUAWEI: "Huawei",
        }.get(os_platform, "Other")

    @staticmethod
    def _match_keyword(text):
        if not text:
            return ""
        upper = str(text).upper()
        for brand, keywords in OEM_BRAND_KEYWORDS:
            for kw in keywords:
                if kw.upper() in upper:
                    return brand
        return ""


# ---------------- 采集器基类 ----------------
# 人工维护字段：采集脚本不应覆盖这些属性，避免覆盖人工录入的资产数据
HUMAN_MANAGED_FIELDS = {"brand", "mdl", "sn", "name"}


class BaseCollector(object):
    """通用光纤交换机采集器。

    子类可覆盖：
    - collect_system_info(): 主模型字段
    - collect_fc_ports(): FC 端口（含连接设备）
    - collect_zone_cfgs(): Zone 配置
    - collect_fans(): 风扇信息
    - collect_powers(): 电源信息
    """
    OS_PLATFORM = OS_PLATFORM_GENERIC

    def __init__(self, snmp_client, ip_addr, instance_id):
        self.client = snmp_client
        self.ip = ip_addr
        self.instance_id = instance_id
        self.sys_object_id = ""
        self.sys_descr = ""
        self.oem_brand = ""

    def set_sys_info(self, sys_object_id, sys_descr, oem_brand=""):
        self.sys_object_id = sys_object_id
        self.sys_descr = sys_descr
        self.oem_brand = oem_brand

    # ---------- 主模型采集 ----------
    def collect_system_info(self):
        """采集 FIBERCHANNEL_SWITCH 主模型字段。

        c* 前缀字段是采集自动同步字段，可写；brand/mdl/sn 是人工字段，
        由主流程 strip_human_managed_fields() 去除。
        """
        sys_name = self.client.get(OID_SYS_NAME) or ""
        sys_uptime = self.client.get(OID_SYS_UPTIME) or ""

        wwn_map = self.client.walk(OID_CU_WWN)
        port_num_map = self.client.walk(OID_CU_NUM_PORT)
        product_map = self.client.walk(OID_CU_PRODUCT)
        serial_map = self.client.walk(OID_CU_SERIAL)
        domain_map = self.client.walk(OID_CU_DOMAIN)
        zone_num_map = self.client.walk(OID_CU_NUM_ZONES)
        unit_name_map = self.client.walk(OID_CU_NAME)

        wwn = normalize_wwn(_first_value(wwn_map))
        product = _first_value(product_map)
        serial = _first_value(serial_map)
        domain = _first_value(domain_map)
        port_num = safe_int(_first_value(port_num_map))
        unit_name = _first_value(unit_name_map)

        info = {
            "wwn": wwn,
            "cSn": serial,
            "cMdl": product,
            "cBrand": self.oem_brand,
            "cSysName": sys_name,
            "cSysDescr": self.sys_descr,
            "cUpTime": sys_uptime,
            "sysObjectId": self.sys_object_id,
            "deviceName": sys_name,
            "snmpIp": self.ip,
            "ip": self.ip,
            "domain": str(domain) if domain else "",
            "portNum": port_num,
        }
        info["name"] = unit_name or sys_name or self.ip
        return info, zone_num_map

    # ---------- FC 端口表采集（FCMGMT-MIB） ----------
    def _collect_link_data(self):
        """从 connUnitLinkTable 采集链路邻接信息，获取光口对端设备数据。

        通过 connUnitLinkRemoteUnitId（列 .4）关联到 FC 端口的 connUnitPortIndex，
        从列 .6（远端 Node WWN）、列 .8（远端 Port WWN）获取对端设备标识。
        同一端口可能有多条 link 记录（多设备连接），会合并到同一列表。
        返回 {port_index_str: [connected_device_dict, ...]}
        """
        link_remote_unit = self.client.walk(OID_LINK_REMOTE_UNIT)
        link_remote_node = self.client.walk(OID_LINK_REMOTE_NODE_WWN)
        link_remote_port = self.client.walk(OID_LINK_REMOTE_PORT_WWN)

        if not link_remote_unit:
            return {}

        link_map = {}
        for sub_idx, port_num in link_remote_unit.items():
            pn = str(port_num).strip()
            if not pn:
                continue
            remote_node_wwn = normalize_wwn(link_remote_node.get(sub_idx, ""))
            remote_port_wwn = normalize_wwn(link_remote_port.get(sub_idx, ""))

            # 合并为一条对端设备记录，wwn=Node WWN, portWwpn=Port WWN
            dev = {}
            if remote_node_wwn:
                dev["wwn"] = remote_node_wwn
            if remote_port_wwn:
                dev["portWwpn"] = remote_port_wwn
            dev["alias"] = ""

            if dev.get("wwn") or dev.get("portWwpn"):
                link_map.setdefault(pn, []).append(dev)

        return link_map

    def collect_fc_ports(self):
        """采集 FIBERCHANNEL_SWITCH_PORT 列表，含连接设备信息。

        连接设备信息来源：connUnitLinkTable（.6 远端 Node WWN、.8 远端 Port WWN），
        每条对端设备记录包含 wwn(Node WWN) 和 portWwpn(Port WWN)。
        """
        index_map = self.client.walk(OID_PORT_INDEX)
        type_map = self.client.walk(OID_PORT_TYPE)
        state_map = self.client.walk(OID_PORT_STATE)
        oper_map = self.client.walk(OID_PORT_OPER_STATUS)
        wwn_map = self.client.walk(OID_PORT_WWN)
        speed_map = self.client.walk(OID_PORT_SPEED)
        name_map = self.client.walk(OID_PORT_NAME)

        # 从 connUnitLinkTable 获取对端设备信息
        link_data = self._collect_link_data()

        ports = []
        for sub_idx, raw_idx in sorted(index_map.items()):
            wwpn = normalize_wwn(wwn_map.get(sub_idx, ""))
            if not wwpn:
                continue
            port_idx = safe_int(raw_idx)

            # 对端设备信息直接从 connUnitLinkTable 获取
            connected = link_data.get(str(port_idx), [])

            ports.append({
                "wwpn": wwpn,
                "name": "{}:port{}".format(self.ip, port_idx),
                "id": str(port_idx),
                "portIndex": str(port_idx),
                "portName": name_map.get(sub_idx, ""),
                "portState": map_port_status(state_map.get(sub_idx, ""), FCMGMT_PORT_STATE),
                "portType": FCMGMT_PORT_TYPE.get(type_map.get(sub_idx, ""),
                                                 type_map.get(sub_idx, "")),
                "protocol": "FC",
                "portSpeed": speed_to_gbps(speed_map.get(sub_idx, "")),
                "operStatus": map_port_status(oper_map.get(sub_idx, ""), FCMGMT_PORT_OPER),
                "connectedDevices": connected,
                "connectedInfo": connected,
            })
        return ports

    # ---------- 网络端口（IF-MIB） ----------
    def collect_netd_ports(self, switch_name):
        """采集 NETDPORT 列表（管理口/物理网口），过滤 FC 光口端口。"""
        if_index = self.client.walk(OID_IF_INDEX)
        if_descr = self.client.walk(OID_IF_DESCR)
        if_type = self.client.walk(OID_IF_TYPE)
        if_mtu = self.client.walk(OID_IF_MTU)
        if_phys = self.client.walk(OID_IF_PHYS)
        if_admin = self.client.walk(OID_IF_ADMIN)
        if_oper = self.client.walk(OID_IF_OPER)
        ifx_name = self.client.walk(OID_IFX_NAME)
        ifx_alias = self.client.walk(OID_IFX_ALIAS)
        ifx_hspeed = self.client.walk(OID_IFX_HIGH_SPEED)

        ports = []
        for sub_idx in sorted(if_index.keys(), key=lambda x: safe_int(x)):
            # 过滤 FC 光口端口（已在 FIBERCHANNEL_SWITCH_PORT 模型中采集）
            if_type_val = str(if_type.get(sub_idx, "")).strip()
            if if_type_val in NETDPORT_EXCLUDE_IF_TYPES:
                log.debug("跳过 FC 光口 ifIndex=%s, ifType=%s", sub_idx, if_type_val)
                continue
            name_short = ifx_name.get(sub_idx) or if_descr.get(sub_idx) or "if{}".format(sub_idx)
            unique_name = "{}:{}".format(self.ip, name_short)
            speed = ifx_hspeed.get(sub_idx, "")
            ports.append({
                "name": unique_name,
                "ifIndex": sub_idx,
                "ifName": name_short,
                "ifDescr": if_descr.get(sub_idx, ""),
                "ifAlias": ifx_alias.get(sub_idx, ""),
                "mtu": if_mtu.get(sub_idx, ""),
                "speed": str(speed) if speed else "",
                "physAddress": if_phys.get(sub_idx, ""),
                "adminStatus": IF_ADMIN_STATUS.get(if_admin.get(sub_idx, ""),
                                                    if_admin.get(sub_idx, "")),
                "operStatus": IF_OPER_STATUS.get(if_oper.get(sub_idx, ""),
                                                  if_oper.get(sub_idx, "")),
                "snmpIp": self.ip,
                "sysName": "{}:{}".format(switch_name, name_short),
                "deviceType": "交换机",
            })
        return ports

    # ---------- Zone 配置 ----------
    def collect_zone_cfgs(self):
        """通用 FCMGMT-MIB 对 Zone 支持有限，基类返回空列表。"""
        return []

    # ---------- 风扇信息（ENTITY-MIB class=7 + 传感器读数） ----------
    def collect_fans(self):
        """采集风扇信息，写入主模型 fanInfo 字段。

        数据源：
        - ENTITY-MIB entPhysicalTable 中 entPhysicalClass=7（fan）
        - ENTITY-SENSOR-MIB 中类型=rpm 的传感器读数（currentReading）
        """
        ent_class = self.client.walk(OID_ENT_PHY_CLASS)
        ent_name = self.client.walk(OID_ENT_PHY_NAME)
        ent_descr = self.client.walk(OID_ENT_PHY_DESCR)
        ent_serial = self.client.walk(OID_ENT_PHY_SERIAL)
        ent_mfg = self.client.walk(OID_ENT_PHY_MFG)
        ent_model = self.client.walk(OID_ENT_PHY_MODEL)
        ent_rel_pos = self.client.walk(OID_ENT_PHY_REL_POS)

        # 传感器读数（按物理实体索引关联）
        sensor_type = self.client.walk(OID_PHY_SENSOR_TYPE)
        sensor_value = self.client.walk(OID_PHY_SENSOR_VALUE)
        sensor_status = self.client.walk(OID_PHY_SENSOR_STATUS)

        fans = []
        for idx, cls in ent_class.items():
            if str(cls).strip() != ENT_CLASS_FAN:
                continue
            name = ent_name.get(idx, "") or ent_descr.get(idx, "") or "Fan-{}".format(ent_rel_pos.get(idx, idx))
            # 尝试匹配同 idx 的转速传感器；找不到则按名称模糊匹配
            reading = ""
            if sensor_type.get(idx) == PHY_SENSOR_RPM and sensor_value.get(idx, ""):
                reading = "{} rpm".format(sensor_value.get(idx))
            else:
                reading = self._lookup_fan_speed(idx, name, sensor_type, sensor_value)

            fans.append({
                "name": name,
                "currentReading": reading,
                "brand": ent_mfg.get(idx, "") or self.oem_brand,
                "model": ent_model.get(idx, ""),
                "sn": ent_serial.get(idx, ""),
                "type": "fan",
            })
        return fans

    @staticmethod
    def _lookup_fan_speed(fan_idx, fan_name, sensor_type, sensor_value):
        """根据风扇名称/位置查找关联的 rpm 传感器读数（容错）。"""
        fan_name_lower = (fan_name or "").lower()
        for sidx, stype in sensor_type.items():
            if stype != PHY_SENSOR_RPM:
                continue
            sval = sensor_value.get(sidx, "")
            if not sval:
                continue
            # 1. 同索引直接命中
            if sidx == fan_idx:
                return "{} rpm".format(sval)
            # 2. 索引前缀匹配（部分厂商传感器索引 = 风扇索引 + 偏移）
            if sidx.startswith(str(fan_idx) + ".") or sidx.startswith(str(fan_idx)):
                return "{} rpm".format(sval)
        # 3. 名称包含 fan / fan 关键字匹配（最后兜底）
        for sidx, stype in sensor_type.items():
            if stype != PHY_SENSOR_RPM:
                continue
            sval = sensor_value.get(sidx, "")
            if not sval:
                continue
            if fan_name_lower and ("fan" in fan_name_lower):
                return "{} rpm".format(sval)
        return ""

    # ---------- 电源信息（ENTITY-MIB class=6） ----------
    def collect_powers(self):
        """采集电源信息，写入主模型 powersInfo 字段。"""
        ent_class = self.client.walk(OID_ENT_PHY_CLASS)
        ent_name = self.client.walk(OID_ENT_PHY_NAME)
        ent_descr = self.client.walk(OID_ENT_PHY_DESCR)
        ent_serial = self.client.walk(OID_ENT_PHY_SERIAL)
        ent_mfg = self.client.walk(OID_ENT_PHY_MFG)
        ent_model = self.client.walk(OID_ENT_PHY_MODEL)
        ent_rel_pos = self.client.walk(OID_ENT_PHY_REL_POS)

        powers = []
        for idx, cls in ent_class.items():
            if str(cls).strip() != ENT_CLASS_POWERSUPPLY:
                continue
            name = ent_name.get(idx, "") or ent_descr.get(idx, "") or "Power-{}".format(ent_rel_pos.get(idx, idx))
            powers.append({
                "name": name,
                "sn": ent_serial.get(idx, ""),
                "brand": ent_mfg.get(idx, "") or self.oem_brand,
                "model": ent_model.get(idx, ""),
                "type": "powerSupply",
            })
        return powers


# ---------------- Brocade 采集器 ----------------
class BrocadeCollector(BaseCollector):
    """Brocade Fabric OS 平台采集器（含各类 OEM）。

    硬件品牌由 BrandDetector 判定；本类只负责用 Brocade 私有 OID 采集。
    """
    OS_PLATFORM = OS_PLATFORM_BROCADE_FOS

    def collect_system_info(self):
        info, zone_num_map = super(BrocadeCollector, self).collect_system_info()

        fw = self.client.get(OID_BRCD_FW_VERSION)
        if fw:
            info["sysVersion"] = fw
            info["microcode"] = fw
            info["kernel"] = fw
        serial = self.client.get(OID_BRCD_SERIAL)
        if serial:
            info["cSn"] = serial
        domain = self.client.get(OID_BRCD_DOMAIN)
        if domain:
            info["domain"] = str(domain)
        oper = self.client.get(OID_BRCD_OPER_STATUS)
        if oper:
            info["state"] = self._brcd_oper_status(oper)
        return info, zone_num_map

    def collect_fc_ports(self):
        ports = super(BrocadeCollector, self).collect_fc_ports()
        if ports:
            return ports
        return self._collect_fc_ports_brocade()

    def _collect_fc_ports_brocade(self):
        index_map = self.client.walk(OID_BRCD_PORT_OPER)
        admin_map = self.client.walk(OID_BRCD_PORT_ADMIN)
        wwn_map = self.client.walk(OID_BRCD_PORT_WWN)
        speed_map = self.client.walk(OID_BRCD_PORT_SPEED)
        name_map = self.client.walk(OID_BRCD_PORT_NAME)
        type_map = self.client.walk(OID_BRCD_PORT_TYPE)

        ports = []
        for sub_idx in sorted(index_map.keys(), key=lambda x: safe_int(x)):
            wwpn = normalize_wwn(wwn_map.get(sub_idx, ""))
            if not wwpn:
                continue
            port_idx = safe_int(sub_idx)
            ports.append({
                "wwpn": wwpn,
                "name": "{}:port{}".format(self.ip, port_idx),
                "id": str(port_idx),
                "portIndex": str(port_idx),
                "portName": name_map.get(sub_idx, ""),
                "portState": map_port_status(index_map.get(sub_idx, ""), BRCD_PORT_OPER_STATUS),
                "portType": type_map.get(sub_idx, ""),
                "protocol": "FC",
                "portSpeed": speed_to_gbps(speed_map.get(sub_idx, "")),
                "operStatus": map_port_status(index_map.get(sub_idx, ""), BRCD_PORT_OPER_STATUS),
                "connectedDevices": [],
                "connectedInfo": [],
            })
        return ports

    def collect_fans(self):
        """Brocade 风扇：优先用 SW-MIB 私有传感器表，回退到标准 ENTITY-MIB。"""
        brcd_fans = self._collect_brcad_sensor_fans()
        if brcd_fans:
            return brcd_fans
        return super(BrocadeCollector, self).collect_fans()

    def _collect_brcad_sensor_fans(self):
        """解析 Brocade SW-MIB 传感器表（1.3.6.1.4.1.1588.2.1.1.1.1.22.1）。

        列定义随 FOS 版本变化，这里做容错解析：
        - 第 2 列通常是传感器名称/描述
        - 第 3 列通常是传感器类型（字符串，含 "Fan"/"Temperature"/"Power"）
        - 第 4 或 5 列通常是读数
        仅提取类型含 "Fan" 的行。
        """
        table = self.client.walk(OID_BRCD_SENSOR_TABLE)
        if not table:
            return []
        # 按 row（第一段子 OID）分组
        rows = {}
        for full_idx, val in table.items():
            parts = full_idx.split(".")
            if len(parts) < 2:
                continue
            row_id, col_id = parts[0], parts[1]
            rows.setdefault(row_id, {})[col_id] = val

        fans = []
        for row_id, cols in rows.items():
            # 合并所有列值用于关键字识别
            joined = " ".join(cols.values()).lower()
            if "fan" not in joined and "风扇" not in joined:
                continue
            name = cols.get("2", "") or cols.get("1", "") or "Fan-{}".format(row_id)
            reading = ""
            for value_col in ("4", "5", "6", "7"):
                v = cols.get(value_col, "")
                if v and str(v).isdigit():
                    reading = "{} rpm".format(v)
                    break
            fans.append({
                "name": name,
                "currentReading": reading,
                "brand": self.oem_brand,
                "model": "",
                "sn": "",
                "type": "fan",
            })
        return fans

    @staticmethod
    def _brcd_oper_status(v):
        return {"1": "online", "2": "offline", "3": "testing", "4": "faulty"}.get(str(v), str(v))


# ---------------- Huawei 采集器 ----------------
class HuaweiCollector(BaseCollector):
    """华为 OceanStor SNS 系列等专用采集器（部分型号为 Brocade OEM）。"""
    OS_PLATFORM = OS_PLATFORM_HUAWEI

    def collect_system_info(self):
        info, zone_num_map = super(HuaweiCollector, self).collect_system_info()

        fw = self.client.get(OID_BRCD_FW_VERSION)
        if fw:
            info["sysVersion"] = fw
            info["microcode"] = fw
            info["kernel"] = fw
        if not info.get("sysVersion"):
            info["sysVersion"] = self._extract_version(self.sys_descr)
        return info, zone_num_map

    def collect_fc_ports(self):
        ports = super(HuaweiCollector, self).collect_fc_ports()
        if ports:
            return ports
        return BrocadeCollector(self.client, self.ip, self.instance_id)._collect_fc_ports_brocade()

    @staticmethod
    def _extract_version(descr):
        if not descr:
            return ""
        m = re.search(r'V\d+R\d+\w*', descr, re.IGNORECASE)
        if m:
            return m.group(0)
        m = re.search(r'\bV?\d+\.\d+(\.\d+)?\b', descr)
        return m.group(0) if m else ""


# ---------------- 工厂方法（扩展点）----------------
class CollectorFactory(object):
    """根据 OS 平台返回对应采集器实例。"""
    _registry = {
        OS_PLATFORM_BROCADE_FOS: BrocadeCollector,
        OS_PLATFORM_HUAWEI: HuaweiCollector,
    }

    @classmethod
    def create(cls, os_platform, snmp_client, ip_addr, instance_id):
        klass = cls._registry.get(os_platform, BaseCollector)
        return klass(snmp_client, ip_addr, instance_id)


# ---------------- 工具：取首个值 ----------------
def _first_value(d):
    if not d:
        return ""
    for _, v in sorted(d.items()):
        if v:
            return v
    return ""


# ---------------- 主入口 ----------------
def strip_human_managed_fields(vals):
    """移除人工维护字段，避免采集覆盖 CMDB 中人工录入的资产数据。"""
    return {k: v for k, v in vals.items() if k not in HUMAN_MANAGED_FIELDS}


def collect():
    """主采集流程。"""
    if not ip:
        log.error("ip 参数为空，无法采集")
        return []
    if not instanceId:
        log.error("instanceId 参数为空，采集对象必须通过资源发现绑定实例")
        return []

    # 1. 从 auth 构造 SNMP 客户端
    client = SNMPClient.from_auth(host=ip, port=snmpPort, auth_struct=auth)
    log.info("SNMP 版本=%s，安全级别=%s", client.version, client.security_level or "(推断)")

    # 2. 探测 OS 平台 + OEM 品牌
    detector = BrandDetector(client)
    os_platform, oem_brand, sys_oid, sys_descr = detector.detect()
    log.info("OS=%s, OEM品牌=%s, sysObjectID=%s", os_platform, oem_brand, sys_oid)

    # 3. 创建采集器
    collector = CollectorFactory.create(os_platform, client, ip, instanceId)
    collector.set_sys_info(sys_oid, sys_descr, oem_brand)

    # 4. 采集主模型
    sw_info, _ = collector.collect_system_info()
    switch_name = sw_info.get("name", "") or sw_info.get("cSysName", "") or ip
    if not sw_info.get("wwn") and not sw_info.get("cSysName"):
        log.warning("无法获取交换机标识（wwn 和 cSysName 均为空），继续采集")

    # 5. 采集端口、Zone、风扇、电源
    fc_ports = collector.collect_fc_ports()
    netd_ports = collector.collect_netd_ports(switch_name)
    zone_cfgs = collector.collect_zone_cfgs()
    fans = collector.collect_fans()
    powers = collector.collect_powers()

    log.info("采集到 FC 端口 %d 个, 网络端口 %d 个, Zone 配置 %d 个, 风扇 %d 个, 电源 %d 个",
             len(fc_ports), len(netd_ports), len(zone_cfgs), len(fans), len(powers))

    # 6. 组装主模型 vals
    main_vals = dict(sw_info)
    if fc_ports:
        used = sum(1 for p in fc_ports if str(p.get("portState", "")).lower() in ONLINE_PORT_STATES)
        main_vals["portNum"] = max(safe_int(main_vals.get("portNum")), len(fc_ports))
        main_vals["usedPortNum"] = used
        main_vals["freePortNum"] = max(0, main_vals["portNum"] - used)

    # structs 字段直接使用 list[dict]，不 dump 成 JSON
    if fans:
        main_vals["fanInfo"] = fans
    if powers:
        main_vals["powersInfo"] = powers

    # 写入 instanceId 作为唯一键，确保 upsert 正确定位实例
    main_vals["instanceId"] = instanceId

    main_vals = strip_human_managed_fields(main_vals)

    # 关系：子模型 vals 中以 [{"_object_id": "MODEL_ID", "instanceId": "..."}] 格式声明
    parent_ref = [{"_object_id": "FIBERCHANNEL_SWITCH@ONEMODEL", "instanceId": instanceId}] if instanceId else []

    data = []
    # 主模型 —— 采集对象使用 instanceId 作为写入唯一键
    data.append({
        "dims": {
            "object_id": "FIBERCHANNEL_SWITCH@ONEMODEL",
            "pks": ["instanceId"],
            "upsert": True,
        },
        "vals": main_vals,
    })

    # 关联：FC 端口
    for port in fc_ports:
        port_vals = dict(port)
        if parent_ref:
            port_vals["fiber_channel_switch"] = parent_ref
        data.append({
            "dims": {
                "object_id": "FIBERCHANNEL_SWITCH_PORT@ONEMODEL",
                "pks": ["wwpn"],
                "upsert": True,
            },
            "vals": port_vals,
        })

    # 关联：NETDPORT
    for port in netd_ports:
        port_vals = dict(port)
        if parent_ref:
            port_vals["base_netware"] = parent_ref
        data.append({
            "dims": {
                "object_id": "NETDPORT@ONEMODEL",
                "pks": ["name"],
                "upsert": True,
            },
            "vals": port_vals,
        })

    # 关联：Zone 配置
    for cfg in zone_cfgs:
        cfg_vals = dict(cfg)
        if parent_ref:
            cfg_vals["switchs"] = parent_ref
        data.append({
            "dims": {
                "object_id": "FIBERCHANNEL_CFG@ONEMODEL",
                "pks": ["name"],
                "upsert": True,
            },
            "vals": cfg_vals,
        })

    return data


if __name__ == "__main__":
    try:
        result = collect()
    except Exception as exc:
        log.exception("采集异常: %s", exc)
        result = []

    print("-----BEGIN GATHERING DATA-----")
    print(json.dumps(result, indent=4, ensure_ascii=False))
    print("-----END GATHERING DATA-----")
