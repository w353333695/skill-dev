instanceid: 652c43dc8aec5
collectorid: 5a5e2b88db442a14dd828a30
pluginid: inspector_redis
name: Redis配置基线巡检
content: |-
  #!/usr/local/easyops/python/bin/python
  # coding:utf-8
  import json
  import subprocess
  import re
  import os


  def exec_cmd(command):
      """执行shell命令并返回结果"""
      process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
      output, error = process.communicate()
      return process.returncode, output, error


  class RedisInspector:
      def __init__(self, redis_cli, host, port, password):
          self.redis_cli = redis_cli
          self.host = host
          self.port = str(port)
          self.password = password
          self.result = []
          self.info = {}

      def test_connection(self):
          """测试Redis连接是否可用"""
          command = self.redis_cli
          if self.password:
              command += " -a " + self.password
          command += " -h " + self.host + " -p " + self.port + " PING"
          code, output, err = exec_cmd(command)
          if code == 0 and output and "PONG" in output:
              return True
          return False

      def _run_redis_cmd(self, cmd):
          """执行redis-cli命令"""
          command = self.redis_cli
          if self.password:
              command += " -a " + self.password
          command += " -h " + self.host + " -p " + self.port + " " + cmd
          code, output, err = exec_cmd(command)
          return code, output, err

      def _get_info(self, section=None):
          """获取Redis INFO信息"""
          cmd = "INFO"
          if section:
              cmd = "INFO " + section
          code, output, err = self._run_redis_cmd(cmd)
          if code != 0:
              return {}
          info = {}
          for line in output.split("\n"):
              line = line.strip()
              if ":" in line and not line.startswith("#"):
                  parts = line.split(":", 1)
                  info[parts[0].strip()] = parts[1].strip()
          return info

      def find_redis_cli(self, install_path):
          """查找redis-cli路径"""
          if install_path:
              cli_path = install_path + "/bin/redis-cli"
              if os.path.exists(cli_path):
                  return cli_path
          for path in ["/usr/local/bin/redis-cli", "/usr/bin/redis-cli",
                       "/opt/redis/bin/redis-cli", "/data/redis/bin/redis-cli"]:
              if os.path.exists(path):
                  return path
          return "redis-cli"

      def safe_int(self, val, default=0):
          """安全转换为整数"""
          try:
              return int(val)
          except (ValueError, TypeError):
              return default

      def safe_float(self, val, default=0.0):
          """安全转换为浮点数"""
          try:
              return float(val)
          except (ValueError, TypeError):
              return default

      def collect_basic(self):
          """采集基本信息：版本、模式、端口、配置文件"""
          info = self._get_info()
          self.info = info
          version = info.get("redis_version", "")
          mode = info.get("redis_mode", "")
          tcp_port = info.get("tcp_port", self.port)
          config_file = info.get("config_file", "")
          self.result.append({
              "id": "basic",
              "dims": [],
              "vals": [
                  {"id": "version", "value": version},
                  {"id": "mode", "value": mode},
                  {"id": "tcp_port", "value": tcp_port},
                  {"id": "config_file", "value": config_file}
              ]
          })

      def collect_server_status(self):
          """采集服务运行状态和运行天数"""
          info = self.info
          status = "stopped"
          uptime_days = 0
          if info:
              status = "running"
              uptime_seconds = self.safe_int(info.get("uptime_in_seconds", 0))
              uptime_days = round(uptime_seconds / 86400.0, 1)
          self.result.append({
              "id": "server_status",
              "dims": [],
              "vals": [
                  {"id": "status", "value": status},
                  {"id": "uptime_days", "value": uptime_days}
              ]
          })

      def collect_memory(self):
          """采集内存使用信息"""
          info = self.info
          used_memory_mb = 0
          peak_memory_mb = 0
          mem_frag_ratio = 0
          maxmemory_policy = ""
          if info:
              used_memory_mb = round(self.safe_int(info.get("used_memory", 0)) / 1024.0 / 1024.0, 2)
              peak_memory_mb = round(self.safe_int(info.get("used_memory_peak", 0)) / 1024.0 / 1024.0, 2)
              mem_frag_ratio = self.safe_float(info.get("mem_fragmentation_ratio", 0))
              maxmemory_policy = info.get("maxmemory_policy", "")
          self.result.append({
              "id": "memory_info",
              "dims": [],
              "vals": [
                  {"id": "used_memory_mb", "value": used_memory_mb},
                  {"id": "peak_memory_mb", "value": peak_memory_mb},
                  {"id": "mem_fragmentation_ratio", "value": mem_frag_ratio},
                  {"id": "maxmemory_policy", "value": maxmemory_policy}
              ]
          })

      def collect_connections(self):
          """采集连接信息"""
          info = self.info
          connected_clients = 0
          max_clients = 0
          rejected_connections = 0
          if info:
              connected_clients = self.safe_int(info.get("connected_clients", 0))
              max_clients = self.safe_int(info.get("maxclients", 0))
              rejected_connections = self.safe_int(info.get("rejected_connections", 0))
          self.result.append({
              "id": "connection_info",
              "dims": [],
              "vals": [
                  {"id": "connected_clients", "value": connected_clients},
                  {"id": "max_clients", "value": max_clients},
                  {"id": "rejected_connections", "value": rejected_connections}
              ]
          })

      def collect_performance(self):
          """采集性能指标：QPS、命中率"""
          info = self.info
          qps = 0
          hit_rate = 0
          keyspace_hits = 0
          keyspace_misses = 0
          if info:
              qps = self.safe_int(info.get("instantaneous_ops_per_sec", 0))
              keyspace_hits = self.safe_int(info.get("keyspace_hits", 0))
              keyspace_misses = self.safe_int(info.get("keyspace_misses", 0))
              total = keyspace_hits + keyspace_misses
              if total > 0:
                  hit_rate = round(float(keyspace_hits) / total * 100, 2)
          self.result.append({
              "id": "performance",
              "dims": [],
              "vals": [
                  {"id": "qps", "value": qps},
                  {"id": "hit_rate", "value": hit_rate},
                  {"id": "keyspace_hits", "value": keyspace_hits},
                  {"id": "keyspace_misses", "value": keyspace_misses}
              ]
          })

      def collect_persistence(self):
          """采集持久化状态：RDB和AOF"""
          info = self.info
          rdb_status = "off"
          rdb_last_save = ""
          aof_enabled = "no"
          aof_last_rewrite = ""
          if info:
              if info.get("rdb_last_bgsave_status", "") == "ok":
                  rdb_status = "ok"
              else:
                  rdb_status = info.get("rdb_last_bgsave_status", "off")
              last_save_ts = self.safe_int(info.get("rdb_last_save_time", 0))
              if last_save_ts > 0:
                  rdb_last_save = str(last_save_ts)
              aof_enabled = "yes" if info.get("aof_enabled", "0") == "1" else "no"
              aof_last_rewrite = info.get("aof_last_bgrewrite_status", "")
          self.result.append({
              "id": "persistence",
              "dims": [],
              "vals": [
                  {"id": "rdb_status", "value": rdb_status},
                  {"id": "rdb_last_save_time", "value": rdb_last_save},
                  {"id": "aof_enabled", "value": aof_enabled},
                  {"id": "aof_last_rewrite_status", "value": aof_last_rewrite}
              ]
          })

      def collect_slowlog(self):
          """采集慢查询数量"""
          code, output, err = self._run_redis_cmd("SLOWLOG LEN")
          count = 0
          if code == 0 and output:
              match = re.search(r'\d+', output.strip())
              if match:
                  count = int(match.group())
          self.result.append({
              "id": "slowlog",
              "dims": [],
              "vals": [{"id": "slowlog_count", "value": count}]
          })

      def collect_keyspace(self):
          """采集各数据库键空间信息"""
          code, output, err = self._run_redis_cmd("INFO keyspace")
          if code != 0:
              return
          for line in output.strip().split("\n"):
              line = line.strip()
              if line.startswith("db"):
                  match = re.match(r'(db\d+):keys=(\d+),expires=(\d+)', line)
                  if match:
                      db_name = match.group(1)
                      keys = int(match.group(2))
                      expires = int(match.group(3))
                      self.result.append({
                          "id": "keyspace",
                          "dims": [{"id": "db", "value": db_name}],
                          "vals": [
                              {"id": "keys", "value": keys},
                              {"id": "expires", "value": expires}
                          ]
                      })

      def print_result(self):
          print "-------start-------"
          print json.dumps(self.result)
          print "-------end-------"


  def find_working_connection(redis_cli, cmdb_ip, ports, password):
      """循环端口测试连接，IP不通则回退127.0.0.1"""
      hosts = []
      if cmdb_ip:
          hosts.append(cmdb_ip)
      hosts.append("127.0.0.1")

      for host in hosts:
          for port in ports:
              inspector = RedisInspector(redis_cli, host, port, password)
              if inspector.test_connection():
                  return host, port
      return None, None


  if __name__ == "__main__":
      # source=attr_id: CMDB属性用 EASYOPS_argname 引用
      # source=custom: 直接按key名引用
      cmdb_ip = EASYOPS_ip if EASYOPS_ip else "127.0.0.1"
      ports = EASYOPS_ports if EASYOPS_ports else [6379]
      redis_password = redis_password
      install_path = EASYOPS_installPath

      redis_cli = RedisInspector("", "", 0, "").find_redis_cli(install_path)

      host, port = find_working_connection(redis_cli, cmdb_ip, ports, redis_password)
      if host is None:
          result = [{"id": "basic", "dims": [], "vals": [
              {"id": "version", "value": ""},
              {"id": "mode", "value": ""},
              {"id": "tcp_port", "value": ""},
              {"id": "config_file", "value": ""}
          ]}, {"id": "server_status", "dims": [], "vals": [
              {"id": "status", "value": "stopped"},
              {"id": "uptime_days", "value": 0}
          ]}]
          print "-------start-------"
          print json.dumps(result)
          print "-------end-------"
      else:
          inspector = RedisInspector(redis_cli, host, port, redis_password)
          inspector.collect_basic()
          inspector.collect_server_status()
          inspector.collect_memory()
          inspector.collect_connections()
          inspector.collect_performance()
          inspector.collect_persistence()
          inspector.collect_slowlog()
          inspector.collect_keyspace()
          inspector.print_result()
args:
- key: redis_password
  alias: Redis密码
  type: password
  require: false
  source: custom
  default: ""
  memo: Redis认证密码，无密码可留空
- key: ip
  alias: 主机IP
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
- key: ports
  alias: 监听端口
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
- key: installPath
  alias: 安装路径
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
script: python
