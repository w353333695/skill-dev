instanceid: 652c43d754929
collectorid: 999e31f9ed6b69151ae77a42
pluginid: inspector_mysql
name: MySQL配置基线巡检
content: |-
  #!/usr/local/easyops/python/bin/python
  # coding:utf-8
  import json
  import subprocess
  import re
  import os

  # source=custom 参数直接按key名引用
  mysql_user = mysql_user
  mysql_password = mysql_password
  mysql_port = mysql_port
  # source=attr_id 的CMDB属性用 EASYOPS_argname 引用
  install_path = EASYOPS_installPath

  mysql_bin = install_path + '/bin/mysql' if install_path else 'mysql'

  def exec_cmd(command):
      process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
      output, error = process.communicate()
      return process.returncode, output, error

  def exec_mysql(sql):
      if mysql_password:
          cmd = '%s -u%s -p%s -h127.0.0.1 -P%s -e "%s" -N 2>/dev/null' % (mysql_bin, mysql_user, mysql_password, mysql_port, sql.replace('"', '\\"'))
      else:
          cmd = '%s -u%s -h127.0.0.1 -P%s -e "%s" -N 2>/dev/null' % (mysql_bin, mysql_user, mysql_port, sql.replace('"', '\\"'))
      return exec_cmd(cmd)

  def safe_int(val, default=0):
      try:
          return int(val)
      except (ValueError, TypeError):
          return default

  def safe_float(val, default=0.0):
      try:
          return float(val)
      except (ValueError, TypeError):
          return default

  class MySQLInspector:
      def __init__(self):
          self.result = []

      def collect_basic(self):
          code, output, err = exec_mysql("SELECT VERSION(), @@port, @@datadir, @@basedir")
          version, port, datadir, basedir = "", "", "", ""
          if code == 0 and output.strip():
              parts = output.strip().split("\t")
              if len(parts) >= 4:
                  version = parts[0].strip()
                  port = parts[1].strip()
                  datadir = parts[2].strip()
                  basedir = parts[3].strip()
          status = "running" if version else "stopped"

          uptime = 0
          code2, out2, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Uptime'")
          if code2 == 0 and out2.strip():
              ps = out2.strip().split("\t")
              if len(ps) >= 2:
                  uptime = safe_int(ps[1].strip())

          self.result.append({
              "id": "basic",
              "dims": [],
              "vals": [
                  {"id": "version", "value": version},
                  {"id": "port", "value": port},
                  {"id": "datadir", "value": datadir},
                  {"id": "basedir", "value": basedir},
                  {"id": "uptime", "value": uptime},
                  {"id": "status", "value": status}
              ]
          })

      def collect_connection(self):
          max_conn = 0
          code, output, _ = exec_mysql("SHOW GLOBAL VARIABLES LIKE 'max_connections'")
          if code == 0 and output.strip():
              ps = output.strip().split("\t")
              if len(ps) >= 2:
                  max_conn = safe_int(ps[1].strip())

          active_conn, threads_running, threads_cached = 0, 0, 0
          code2, out2, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Threads%'")
          if code2 == 0 and out2.strip():
              for line in out2.strip().split("\n"):
                  ps2 = line.strip().split("\t")
                  if len(ps2) >= 2:
                      key, val = ps2[0].strip(), ps2[1].strip()
                      if key == "Threads_connected":
                          active_conn = safe_int(val)
                      elif key == "Threads_running":
                          threads_running = safe_int(val)
                      elif key == "Threads_cached":
                          threads_cached = safe_int(val)

          conn_usage = round(float(active_conn) / float(max_conn) * 100, 2) if max_conn > 0 else 0

          self.result.append({
              "id": "connection_status",
              "dims": [],
              "vals": [
                  {"id": "max_connections", "value": max_conn},
                  {"id": "active_connections", "value": active_conn},
                  {"id": "connection_usage", "value": conn_usage},
                  {"id": "threads_running", "value": threads_running},
                  {"id": "threads_cached", "value": threads_cached}
              ]
          })

      def collect_slow_query(self):
          slow_queries = 0
          code, output, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Slow_queries'")
          if code == 0 and output.strip():
              ps = output.strip().split("\t")
              if len(ps) >= 2:
                  slow_queries = safe_int(ps[1].strip())

          long_query_time = 0.0
          code2, out2, _ = exec_mysql("SHOW GLOBAL VARIABLES LIKE 'long_query_time'")
          if code2 == 0 and out2.strip():
              ps2 = out2.strip().split("\t")
              if len(ps2) >= 2:
                  long_query_time = safe_float(ps2[1].strip())

          qps = 0.0
          code3, out3, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Queries'")
          if code3 == 0 and out3.strip():
              ps3 = out3.strip().split("\t")
              if len(ps3) >= 2:
                  total_q = safe_int(ps3[1].strip())
                  code4, out4, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Uptime'")
                  if code4 == 0 and out4.strip():
                      ps4 = out4.strip().split("\t")
                      if len(ps4) >= 2:
                          ut = safe_int(ps4[1].strip(), 1)
                          qps = round(float(total_q) / float(ut), 2) if ut > 0 else 0

          self.result.append({
              "id": "slow_query",
              "dims": [],
              "vals": [
                  {"id": "slow_queries", "value": slow_queries},
                  {"id": "long_query_time", "value": long_query_time},
                  {"id": "qps", "value": qps}
              ]
          })

      def collect_innodb(self):
          total_pages, data_pages = 0, 0
          code, output, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Innodb_buffer_pool_pages%'")
          if code == 0 and output.strip():
              for line in output.strip().split("\n"):
                  ps = line.strip().split("\t")
                  if len(ps) >= 2:
                      key, val = ps[0].strip(), ps[1].strip()
                      if key == "Innodb_buffer_pool_pages_total":
                          total_pages = safe_int(val)
                      elif key == "Innodb_buffer_pool_pages_data":
                          data_pages = safe_int(val)

          usage = round(float(data_pages) / float(total_pages) * 100, 2) if total_pages > 0 else 0

          read_requests, read_misses = 0, 0
          code2, out2, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Innodb_buffer_pool_read%'")
          if code2 == 0 and out2.strip():
              for line in out2.strip().split("\n"):
                  ps2 = line.strip().split("\t")
                  if len(ps2) >= 2:
                      key, val = ps2[0].strip(), ps2[1].strip()
                      if key == "Innodb_buffer_pool_read_requests":
                          read_requests = safe_int(val)
                      elif key == "Innodb_buffer_pool_reads":
                          read_misses = safe_int(val)

          hit_rate = round((1 - float(read_misses) / float(read_requests)) * 100, 2) if read_requests > 0 else 100.0

          lock_waits = 0
          code3, out3, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Innodb_row_lock_waits'")
          if code3 == 0 and out3.strip():
              ps3 = out3.strip().split("\t")
              if len(ps3) >= 2:
                  lock_waits = safe_int(ps3[1].strip())

          deadlocks = 0
          code4, out4, _ = exec_mysql("SHOW GLOBAL STATUS LIKE 'Innodb_deadlocks'")
          if code4 == 0 and out4.strip():
              ps4 = out4.strip().split("\t")
              if len(ps4) >= 2:
                  deadlocks = safe_int(ps4[1].strip())

          self.result.append({
              "id": "innodb_status",
              "dims": [],
              "vals": [
                  {"id": "buffer_pool_usage", "value": usage},
                  {"id": "buffer_pool_hit_rate", "value": hit_rate},
                  {"id": "innodb_row_lock_waits", "value": lock_waits},
                  {"id": "innodb_deadlocks", "value": deadlocks}
              ]
          })

      def collect_replication(self):
          code, output, _ = exec_mysql("SHOW SLAVE STATUS\\G")
          if code != 0 or not output.strip():
              return

          data = {}
          for line in output.strip().split("\n"):
              if ":" in line:
                  key, val = line.split(":", 1)
                  data[key.strip()] = val.strip()

          io_running = data.get("Slave_IO_Running", "No")
          sql_running = data.get("Slave_SQL_Running", "No")
          sbm = data.get("Seconds_Behind_Master", "NULL")
          last_err = data.get("Last_Error", "")
          channel = data.get("Channel_Name", "") or "default"

          seconds_val = 0
          if sbm and sbm != "NULL":
              seconds_val = safe_int(sbm, -1)

          self.result.append({
              "id": "replication_status",
              "dims": [{"id": "channel_name", "value": channel}],
              "vals": [
                  {"id": "slave_io_running", "value": io_running},
                  {"id": "slave_sql_running", "value": sql_running},
                  {"id": "seconds_behind_master", "value": seconds_val},
                  {"id": "last_error", "value": last_err}
              ]
          })

      def collect_database_size(self):
          sql = "SELECT table_schema, ROUND(SUM(data_length)/1024/1024, 2), ROUND(SUM(index_length)/1024/1024, 2), ROUND(SUM(data_length+index_length)/1024/1024, 2) FROM information_schema.tables WHERE table_schema NOT IN ('information_schema','mysql','performance_schema','sys') GROUP BY table_schema"
          code, output, _ = exec_mysql(sql)
          if code != 0 or not output.strip():
              return

          for line in output.strip().split("\n"):
              ps = line.strip().split("\t")
              if len(ps) >= 4:
                  self.result.append({
                      "id": "database_size",
                      "dims": [{"id": "database_name", "value": ps[0].strip()}],
                      "vals": [
                          {"id": "data_size", "value": safe_float(ps[1].strip())},
                          {"id": "index_size", "value": safe_float(ps[2].strip())},
                          {"id": "total_size", "value": safe_float(ps[3].strip())}
                      ]
                  })

      def print_result(self):
          print "-------start-------"
          print json.dumps(self.result)
          print "-------end-------"

  if __name__ == "__main__":
      inspector = MySQLInspector()
      inspector.collect_basic()
      inspector.collect_connection()
      inspector.collect_slow_query()
      inspector.collect_innodb()
      inspector.collect_replication()
      inspector.collect_database_size()
      inspector.print_result()
args:
- key: mysql_user
  alias: MySQL用户名
  type: text
  require: true
  source: custom
  default: root
  memo: MySQL数据库连接用户名
- key: mysql_password
  alias: MySQL密码
  type: password
  require: true
  source: custom
  default: ""
  memo: MySQL数据库连接密码
- key: mysql_port
  alias: MySQL端口
  type: text
  require: false
  source: custom
  default: "3306"
  memo: MySQL数据库连接端口
- key: installPath
  alias: 安装路径
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
script: python
