instanceid: 652dcfcebbf7d
collectorid: 70f6675276fc2db2f53f3086
pluginid: inspector_bes_cache
name: 宝兰德BCS配置基线巡检
content: |-
  #!/usr/local/easyops/python/bin/python
  # coding:utf-8
  """宝兰德BCS缓存服务巡检采集脚本"""
  import json
  import re
  import subprocess
  import os


  def exec_cmd(command):
      """执行命令并返回结果"""
      process = subprocess.Popen(
          command, shell=True,
          stdout=subprocess.PIPE, stderr=subprocess.PIPE
      )
      output, error = process.communicate()
      return process.returncode, output, error


  def parse_info(output):
      """解析 BCS INFO 命令输出为字典"""
      info = {}
      for line in output.split('\n'):
          line = line.strip()
          if ':' in line and not line.startswith('#'):
              key, value = line.split(':', 1)
              info[key.strip()] = value.strip()
      return info


  def parse_keyspace(info):
      """解析键空间信息"""
      results = []
      for key, value in info.items():
          if key.startswith('db') and '=' in value:
              db_name = key
              parts = {}
              for part in value.split(','):
                  if '=' in part:
                      k, v = part.split('=', 1)
                      parts[k.strip()] = v.strip()
              results.append({
                  'db': db_name,
                  'keys': int(parts.get('keys', 0)),
                  'expires': int(parts.get('expires', 0)),
                  'avg_ttl': int(parts.get('avg_ttl', 0))
              })
      return results


  class BCSInspector:
      def __init__(self, cli_path, host, port, password, username=''):
          self.cli_path = cli_path
          self.host = host
          self.port = str(port)
          self.password = password
          self.username = username
          self.result = []
          self.info = {}

      def build_cmd(self, sub_cmd):
          """构建 bes-cache-cli 命令"""
          cmd = self.cli_path
          if self.host:
              cmd += ' -h ' + self.host
          cmd += ' -p ' + self.port
          if self.username:
              cmd += ' --user ' + self.username
          cmd += ' -a ' + self.password
          cmd += ' ' + sub_cmd
          return cmd

      def safe_int(self, key, default=0):
          val = self.info.get(key, str(default))
          try:
              return int(val)
          except (ValueError, TypeError):
              return default

      def safe_float(self, key, default=0.0):
          val = self.info.get(key, str(default))
          try:
              return float(val)
          except (ValueError, TypeError):
              return default

      def collect_all(self):
          """执行 INFO 命令采集全部数据"""
          cmd = self.build_cmd('INFO')
          code, output, err = exec_cmd(cmd)
          if code != 0:
              return
          lines = []
          for line in output.split('\n'):
              if not line.startswith('Warning:'):
                  lines.append(line)
          clean_output = '\n'.join(lines)
          self.info = parse_info(clean_output)
          if not self.info:
              return
          self.collect_basic()
          self.collect_clients()
          self.collect_memory()
          self.collect_stats()
          self.collect_persistence()
          self.collect_keyspace()
          self.collect_replication()

      def collect_basic(self):
          self.result.append({
              "id": "basic",
              "dims": [],
              "vals": [
                  {"id": "bcs_version", "value": self.info.get("bcs_version", "")},
                  {"id": "bcs_build", "value": self.info.get("bcs_build", "")},
                  {"id": "bcs_mode", "value": self.info.get("bcs_mode", "")},
                  {"id": "bcs_name", "value": self.info.get("bcs_name", "")},
                  {"id": "uptime_in_days", "value": self.safe_int("uptime_in_days")},
                  {"id": "tcp_port", "value": self.safe_int("tcp_port")},
                  {"id": "os", "value": self.info.get("os", "")},
                  {"id": "process_id", "value": self.safe_int("process_id")}
              ]
          })

      def collect_clients(self):
          self.result.append({
              "id": "clients",
              "dims": [],
              "vals": [
                  {"id": "connected_clients", "value": self.safe_int("connected_clients")},
                  {"id": "blocked_clients", "value": self.safe_int("blocked_clients")},
                  {"id": "maxclients", "value": self.safe_int("maxclients")}
              ]
          })

      def collect_memory(self):
          self.result.append({
              "id": "memory",
              "dims": [],
              "vals": [
                  {"id": "used_memory", "value": self.safe_int("used_memory")},
                  {"id": "used_memory_peak", "value": self.safe_int("used_memory_peak")},
                  {"id": "used_memory_rss", "value": self.safe_int("used_memory_rss")},
                  {"id": "maxmemory", "value": self.safe_int("maxmemory")},
                  {"id": "mem_fragmentation_ratio", "value": self.safe_float("mem_fragmentation_ratio")},
                  {"id": "maxmemory_policy", "value": self.info.get("maxmemory_policy", "")}
              ]
          })

      def collect_stats(self):
          self.result.append({
              "id": "stats",
              "dims": [],
              "vals": [
                  {"id": "instantaneous_ops_per_sec", "value": self.safe_int("instantaneous_ops_per_sec")},
                  {"id": "total_commands_processed", "value": self.safe_int("total_commands_processed")},
                  {"id": "keyspace_hits", "value": self.safe_int("keyspace_hits")},
                  {"id": "keyspace_misses", "value": self.safe_int("keyspace_misses")},
                  {"id": "expired_keys", "value": self.safe_int("expired_keys")},
                  {"id": "evicted_keys", "value": self.safe_int("evicted_keys")},
                  {"id": "total_error_replies", "value": self.safe_int("total_error_replies")}
              ]
          })

      def collect_persistence(self):
          self.result.append({
              "id": "persistence",
              "dims": [],
              "vals": [
                  {"id": "rdb_last_bgsave_status", "value": self.info.get("rdb_last_bgsave_status", "")},
                  {"id": "rdb_changes_since_last_save", "value": self.safe_int("rdb_changes_since_last_save")},
                  {"id": "aof_enabled", "value": self.info.get("aof_enabled", "0")},
                  {"id": "rdb_bgsave_in_progress", "value": self.info.get("rdb_bgsave_in_progress", "0")},
                  {"id": "aof_last_write_status", "value": self.info.get("aof_last_write_status", "")}
              ]
          })

      def collect_keyspace(self):
          ks_data = parse_keyspace(self.info)
          for item in ks_data:
              self.result.append({
                  "id": "keyspace",
                  "dims": [{"id": "db", "value": item["db"]}],
                  "vals": [
                      {"id": "keys", "value": item["keys"]},
                      {"id": "expires", "value": item["expires"]},
                      {"id": "avg_ttl", "value": item["avg_ttl"]}
                  ]
              })

      def collect_replication(self):
          self.result.append({
              "id": "replication",
              "dims": [],
              "vals": [
                  {"id": "role", "value": self.info.get("role", "")},
                  {"id": "connected_slaves", "value": self.safe_int("connected_slaves")}
              ]
          })

      def print_result(self):
          print "-------start-------"
          print json.dumps(self.result)
          print "-------end-------"


  if __name__ == '__main__':
      # 从CMDB属性获取主机和端口
      host = EASYOPS_ip
      port = EASYOPS_ports[0]
      install_path = EASYOPS_installPath
      # 自定义参数
      password = password
      username = username
      # 推导CLI路径：从installPath推导或使用自定义路径
      cli_path = os.environ.get("cli_path", "")
      if not cli_path and install_path:
          cli_path = install_path.rstrip('/') + '/modules/bcs/bin/bes-cache-cli'
      if not cli_path:
          cli_path = 'bes-cache-cli'

      inspector = BCSInspector(cli_path, host, port, password, username)
      inspector.collect_all()
      inspector.print_result()
args:
- key: ip
  alias: 实例IP
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
- key: ports
  alias: 实例端口
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
- key: installPath
  alias: 安装路径
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
- key: cli_path
  alias: CLI路径
  type: text
  require: false
  source: custom
  default: ""
  memo: bes-cache-cli完整路径，不填则从installPath推导
- key: password
  alias: 连接密码
  type: password
  require: false
  source: custom
  default: ""
  memo: BCS连接密码
- key: username
  alias: 连接用户名
  type: text
  require: false
  source: custom
  default: ""
  memo: 高版本BCS需要用户名认证
script: python
