#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
"""深信服(SANGFOR)AD 负载均衡器 SNMP 监控采集脚本。

基于 SANGFOR-GENERAL-MIB / RFC1213-MIB，通过 SNMP 采集负载均衡器的：
- 设备基础指标（CPU/内存/磁盘/连接/吞吐/运行时长/设备状态）
- 虚拟服务指标（状态/健康/连接/流量/吞吐/请求速率）
- 节点池指标（健康/连接/流量）
- 节点指标（健康/连接/流量）
- 链路指标（状态/流量）
- 网口指标（状态/错误包/丢弃包）

运行环境：Python 2.7.18，依赖系统 snmpget/snmpwalk 命令。
认证参数从 CMDB 实例的 auth 结构体解析（snmpVersion/community 及 v3 全套字段）。
"""
import os
import subprocess
import json
import platform
from collections import OrderedDict

# ============================================================================
# 调试参数（环境变量未设置时使用默认值，便于本地调试）
# ============================================================================
ip=os.environ.get("EASYOPS_COLLECTOR_ip")
port=os.environ.get("EASYOPS_COLLECTOR_port")
version=os.environ.get("EASYOPS_COLLECTOR_version")
community=os.environ.get("EASYOPS_COLLECTOR_community")
username=os.environ.get("EASYOPS_COLLECTOR_username")
auth_key=os.environ.get("EASYOPS_COLLECTOR_auth_key")
auth_protocol=os.environ.get("EASYOPS_COLLECTOR_auth_protocol")
priv_key=os.environ.get("EASYOPS_COLLECTOR_priv_key")
priv_protocol=os.environ.get("EASYOPS_COLLECTOR_priv_protocol")

# ============================================================================
# SNMP 客户端
# ============================================================================
Result = __import__('collections').namedtuple('Result', ['success', 'data', 'error'])


def parse_snmp_value(value_str):
    """解析SNMP返回值，自动转换数据类型。

    支持 INTEGER/COUNTER32/COUNTER64/GAUGE32/TIMETICKS/IPADDRESS/STRING 等类型前缀，
    对 Timeticks 形如 "(3905183420) 451 days, ..." 提取括号内厘秒值。
    """
    value_str = value_str.strip()
    if ':' in value_str:
        parts = value_str.split(':', 1)
        if len(parts) == 2:
            type_part = parts[0].strip().upper()
            value_part = parts[1].strip()
            if type_part in ['INTEGER', 'COUNTER32', 'COUNTER64', 'GAUGE32',
                             'TIMETICKS', 'IPADDRESS', 'COUNTER', 'GAUGE']:
                if type_part == 'TIMETICKS' and '(' in value_part and ')' in value_part:
                    inside = value_part.split('(', 1)[1].split(')', 1)[0]
                    try:
                        return int(inside)
                    except ValueError:
                        pass
                try:
                    return int(value_part)
                except ValueError:
                    return value_part
            if type_part in ['STRING', 'OCTETSTR', 'OPAQUE', 'OBJECT IDENTIFIER', 'OID']:
                return value_part.strip('"')
            try:
                return int(value_part)
            except ValueError:
                try:
                    return float(value_part)
                except ValueError:
                    return value_part.strip('"')
    try:
        return int(value_str)
    except ValueError:
        try:
            return float(value_str)
        except ValueError:
            return value_str


class SNMPClient(object):
    """SNMP客户端，使用系统 snmpget/snmpwalk 命令，支持 v1/v2c/v3。"""

    def __init__(self, ip, port=161, version='2c', community='public',
                 username=None, auth_key=None, auth_protocol='MD5',
                 priv_key=None, priv_protocol='DES', timeout=15, retries=2):
        self.ip = ip
        self.port = int(port)
        self.version = version
        self.community = community
        self.username = username
        self.auth_key = auth_key
        self.auth_protocol = auth_protocol.upper() if auth_protocol else 'MD5'
        self.priv_key = priv_key
        self.priv_protocol = priv_protocol.upper() if priv_protocol else 'DES'
        self.timeout = timeout
        self.retries = retries

    def _build_auth_params(self):
        """构建SNMP认证参数。"""
        if self.version in ['1', '2c']:
            return ['-v', self.version, '-c', self.community]
        elif self.version == '3':
            params = ['-v', '3', '-u', self.username]
            if self.auth_key:
                params.extend(['-A', self.auth_key, '-a', self.auth_protocol])
            if self.priv_key:
                params.extend(['-X', self.priv_key, '-x', self.priv_protocol])
                if self.auth_key:
                    params.extend(['-l', 'authPriv'])
                else:
                    params.extend(['-l', 'noAuthPriv'])
            else:
                if self.auth_key:
                    params.extend(['-l', 'authNoPriv'])
                else:
                    params.extend(['-l', 'noAuthNoPriv'])
            return params
        else:
            return ['-v', '2c', '-c', self.community]

    def _execute(self, command):
        """执行SNMP命令，macOS 不用 timeout 避免 gmon.out 问题。"""
        try:
            is_macos = platform.system().lower() == 'darwin'
            if is_macos:
                proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            else:
                cmd = ['timeout', str(self.timeout)] + command
                proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = proc.communicate()
            stdout = stdout.strip() if stdout else ""
            stderr = stderr.strip() if stderr else ""
            if stderr:
                stderr_lines = stderr.split('\n')
                stderr = '\n'.join(
                    [l for l in stderr_lines if 'gmon.out' not in l and '_mcleanup' not in l]
                ).strip()
            return Result(proc.returncode == 0, stdout, stderr)
        except Exception as e:
            return Result(False, "", str(e))

    def get(self, oid):
        """获取单个OID值，返回 Result(success, value, error)。"""
        auth_params = self._build_auth_params()
        command = ['snmpget', '-On'] + auth_params + \
                  ["{0}:{1}".format(self.ip, self.port), oid]
        result = self._execute(command)
        if result.success and result.data:
            for line in result.data.decode('utf-8', errors='ignore').split('\n'):
                if '=' in line:
                    parts = line.split('=', 1)
                    if len(parts) >= 2:
                        return Result(True, parse_snmp_value(parts[1]), "")
            return Result(False, None, "No data parsed")
        err = result.error.decode('utf-8', errors='ignore') if isinstance(result.error, bytes) else result.error
        return Result(False, None, err)

    def walk(self, oid):
        """遍历OID树，返回 OrderedDict{oid_suffix: value}。

        规范化基准 OID（去前导点），仅保留本子树结果，
        过滤 "No Such Instance"/"End of MIB" 等无效响应。
        """
        auth_params = self._build_auth_params()
        command = ['snmpwalk', '-On'] + auth_params + \
                  ["{0}:{1}".format(self.ip, self.port), oid]
        result = self._execute(command)
        data = OrderedDict()
        base = oid.lstrip('.')
        if result.success and result.data:
            for line in result.data.decode('utf-8', errors='ignore').split('\n'):
                line = line.strip()
                if line and '=' in line:
                    parts = line.split('=', 1)
                    if len(parts) >= 2:
                        oid_part = parts[0].strip().lstrip('.')
                        value_part = parts[1].strip()
                        vlow = value_part.lower()
                        if 'no such' in vlow or 'end of mib' in vlow \
                                or 'no more variables' in vlow:
                            continue
                        if oid_part == base or oid_part.startswith(base + '.'):
                            suffix = oid_part[len(base):]
                            if suffix.startswith('.'):
                                suffix = suffix[1:]
                            if suffix:
                                data[suffix] = parse_snmp_value(value_part)
        return data


def to_float(value):
    """安全转 float，失败返回 None。"""
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


# ============================================================================
# OID 定义（SANGFOR-GENERAL-MIB / RFC1213-MIB）
# ============================================================================
# 设备基础（标量）
OID_SYS = {
    'cpu_usage': '1.3.6.1.4.1.35047.2.2.20.0',      # adCpuCostRate %
    'mem_usage': '1.3.6.1.4.1.35047.2.2.19.0',      # adMemCostRate %
    'disk_usage': '1.3.6.1.4.1.35047.2.2.32.0',     # adDiskCostRate %
    'conns': '1.3.6.1.4.1.35047.2.2.1.0',           # adConns 并发连接
    'new_conns': '1.3.6.1.4.1.35047.2.2.2.0',       # adNewConns 新建连接
    'vs_conns': '1.3.6.1.4.1.35047.2.2.3.0',        # adVsConns 所有VS并发
    'uplink_tput': '1.3.6.1.4.1.35047.2.2.5.0',     # adUplinkThroughput
    'downlink_tput': '1.3.6.1.4.1.35047.2.2.6.0',   # adDownlinkThroughput
    'sys_uptime': '1.3.6.1.4.1.35047.2.2.46.0',     # adUptime 秒
    'device_status': '1.3.6.1.4.1.35047.1.12.0',    # sfDeviceStatus 0=warning 1=normal
}

# 虚拟服务 Table (adVsXxx.x)
VS_TABLE = '1.3.6.1.4.1.35047.2.2.11.1'
VS_COLS = {
    'name': 2,            # adVsName
    'status': 3,          # adVsStatus 0=禁用 1=启用
    'bit_in': 4,          # adVsBitIn
    'bit_out': 5,         # adVsBitOut
    'conn_new': 8,        # adVsConnNew
    'conn_cur': 9,        # adVsConnCur
    'conn_max': 10,       # adVsConnMax
    'req_rate': 13,       # adVsRequestNew
    'health': 17,         # adVsHealthStatus up/down（字符串）
    'health_node': 18,    # adVsHealthNodeCnt
    'up_tput': 20,        # adVsUpThroughput
    'down_tput': 21,      # adVsDownThroughput
}

# 节点池 Table (adPoolXxx.x)
POOL_TABLE = '1.3.6.1.4.1.35047.2.2.12.1'
POOL_COLS = {
    'name': 2,
    'health': 4,          # adPoolHealthStatus 0=离线 1=正常(繁忙)
    'bit_in': 5,
    'bit_out': 6,
    'conn_new': 9,
    'conn_cur': 10,
}

# 节点 Table (adNodeXxx.x)
NODE_TABLE = '1.3.6.1.4.1.35047.2.2.13.1'
NODE_COLS = {
    'name': 2,
    'health': 4,          # adNodeHealthStatus 1=在线 0=离线
    'bit_in': 5,
    'bit_out': 6,
    'conn_new': 9,
    'conn_cur': 10,
}

# 链路 Table (adLinkXxx.x)
LINK_TABLE = '1.3.6.1.4.1.35047.2.2.41.1'
LINK_COLS = {
    'name': 2,
    'status': 5,          # adLinkStatus 0=离线 1=正常 2=繁忙
    'bit_in': 6,
    'bit_out': 7,
}

# 网口 RFC1213 ifTable
IF_TABLE = '1.3.6.1.2.1.2.2.1'
IF_COLS = {
    'name': 2,            # ifDescr
    'oper_status': 8,     # ifOperStatus 1=up 2=down
    'in_discards': 13,    # ifInDiscards
    'in_errors': 14,      # ifInErrors
    'out_discards': 19,   # ifOutDiscards
    'out_errors': 20,     # ifOutErrors
}

# 健康状态枚举：up/down 字符串 -> 数值（up=1, 其他=0），便于告警
HEALTH_UP_VALUES = ('up', '1', '正常', 'normal')


def _health_to_num(raw):
    """将健康状态(up/down 等)归一化为数值：up 类=1，其余=0。"""
    if raw is None:
        return None
    s = str(raw).strip().strip('"').lower()
    if s in ('up', '1', 'normal', '正常'):
        return 1.0
    if s in ('down', '0', 'offline', '离线'):
        return 0.0
    num = to_float(raw)
    return num


def _walk_table(snmp, table_oid, cols):
    """Walk 一个 Table 的多个列，返回 {index: {col_key: value}}。

    :param cols: {col_key: column_number} 字典
    """
    table = OrderedDict()
    for col_key, col_num in cols.items():
        col_oid = table_oid + '.' + str(col_num)
        col_data = snmp.walk(col_oid)
        for idx, val in col_data.items():
            # idx 形如 "1.3.6...11.1.2.1" 的后缀 "1"，或直接 "1"
            # walk 返回的 key 是去掉 base 后的后缀，列号在中间，需取最后一段为行索引
            row_idx = idx.rsplit('.', 1)[-1] if '.' in idx else idx
            table.setdefault(row_idx, OrderedDict())[col_key] = val
    return table


def collect_system(snmp, ip_addr):
    """采集设备基础指标。"""
    vals = {}
    for key, oid in OID_SYS.items():
        result = snmp.get(oid)
        if result.success and result.data is not None:
            v = to_float(result.data)
            if v is not None:
                vals['m_' + key] = v
    if not vals:
        return []
    return [{"dims": {"ip": ip_addr}, "vals": vals}]


def _emit_sub_metrics(table, ip_addr, name_key, dim_name, val_map):
    """把 Table 行转为监控数据点列表。

    :param table: _walk_table 返回的 {row_idx: {col_key: value}}
    :param name_key: 用作维度的列名（如 'name'）
    :param dim_name: 维度 key（如 'vs_name'）
    :param val_map: {col_key: metric_key}（如 {'conn_cur': 'm_vs_conn_cur'}）
    """
    results = []
    for row_idx, row in table.items():
        name = str(row.get(name_key, row_idx)).strip().strip('"')
        if not name:
            name = dim_name + '_' + str(row_idx)
        vals = {}
        for col_key, metric_key in val_map.items():
            if col_key not in row:
                continue
            raw = row[col_key]
            # 健康类字段做归一化
            if col_key == 'health':
                v = _health_to_num(raw)
            else:
                v = to_float(raw)
            if v is not None:
                vals[metric_key] = v
        if vals:
            results.append({
                "dims": {"ip": ip_addr, dim_name: name},
                "vals": vals
            })
    return results


def collect_virtual_services(snmp, ip_addr):
    """采集虚拟服务指标。"""
    table = _walk_table(snmp, VS_TABLE, VS_COLS)
    return _emit_sub_metrics(table, ip_addr, 'name', 'vs_name', {
        'status': 'm_vs_status',
        'health': 'm_vs_health',
        'health_node': 'm_vs_health_node',
        'conn_cur': 'm_vs_conn_cur',
        'conn_new': 'm_vs_conn_new',
        'conn_max': 'm_vs_conn_max',
        'bit_in': 'm_vs_bit_in',
        'bit_out': 'm_vs_bit_out',
        'up_tput': 'm_vs_up_tput',
        'down_tput': 'm_vs_down_tput',
        'req_rate': 'm_vs_req_rate',
    })


def collect_pools(snmp, ip_addr):
    """采集节点池指标。"""
    table = _walk_table(snmp, POOL_TABLE, POOL_COLS)
    return _emit_sub_metrics(table, ip_addr, 'name', 'pool_name', {
        'health': 'm_pool_health',
        'conn_cur': 'm_pool_conn_cur',
        'conn_new': 'm_pool_conn_new',
        'bit_in': 'm_pool_bit_in',
        'bit_out': 'm_pool_bit_out',
    })


def collect_nodes(snmp, ip_addr):
    """采集节点指标。"""
    table = _walk_table(snmp, NODE_TABLE, NODE_COLS)
    return _emit_sub_metrics(table, ip_addr, 'name', 'node_name', {
        'health': 'm_node_health',
        'conn_cur': 'm_node_conn_cur',
        'conn_new': 'm_node_conn_new',
        'bit_in': 'm_node_bit_in',
        'bit_out': 'm_node_bit_out',
    })


def collect_links(snmp, ip_addr):
    """采集链路指标。"""
    table = _walk_table(snmp, LINK_TABLE, LINK_COLS)
    return _emit_sub_metrics(table, ip_addr, 'name', 'link_name', {
        'status': 'm_link_status',
        'bit_in': 'm_link_bit_in',
        'bit_out': 'm_link_bit_out',
    })


def collect_interfaces(snmp, ip_addr):
    """采集网口指标（RFC1213 ifTable）。"""
    table = _walk_table(snmp, IF_TABLE, IF_COLS)
    return _emit_sub_metrics(table, ip_addr, 'name', 'if_name', {
        'oper_status': 'm_if_oper_status',
        'in_errors': 'm_if_in_errors',
        'out_errors': 'm_if_out_errors',
        'in_discards': 'm_if_in_discards',
        'out_discards': 'm_if_out_discards',
    })


def collect_all(snmp, ip_addr):
    """执行全量采集，单项失败不影响其他项。"""
    info = []
    for fn in (collect_system, collect_virtual_services, collect_pools,
               collect_nodes, collect_links, collect_interfaces):
        try:
            info.extend(fn(snmp, ip_addr))
        except Exception:
            continue
    return info


def _to_unicode(obj):
    """递归把 info 中的 str 容错解码为 unicode。

    SNMP 返回的中文字符串（虚拟服务名/节点池名/节点名/链路名/网口名等）可能为
    UTF-8/GBK 编码，或因设备长度限制被截断成不完整的多字节序列。Python2 下
    json.dumps 遇到含非 ASCII 字节的 str 会强制 UTF-8 解码，残缺字节会触发
    UnicodeDecodeError。这里按 utf-8 -> gbk -> gb18030 顺序尝试解码，全部失败
    则用 replace 替换无法解码的字节，确保 json.dumps 不报错。
    """
    if isinstance(obj, dict):
        return dict((_to_unicode(k), _to_unicode(v)) for k, v in obj.items())
    if isinstance(obj, list):
        return [_to_unicode(x) for x in obj]
    if isinstance(obj, str):
        for enc in ("utf-8", "gbk", "gb18030"):
            try:
                return obj.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue
        return obj.decode("utf-8", errors="replace")
    return obj


if __name__ == "__main__":
    snmp_client = SNMPClient(
        ip=ip,
        port=port,
        version=version,
        community=community,
        username=username if username else None,
        auth_key=auth_key if auth_key else None,
        auth_protocol=auth_protocol if auth_protocol else None,
        priv_key=priv_key if priv_key else None,
        priv_protocol=priv_protocol if priv_protocol else None,
    )
    info = collect_all(snmp_client, ip)
    print(json.dumps(_to_unicode(info), ensure_ascii=False))
