#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
"""
宝兰德BCS缓存服务监控采集脚本

通过bes-cache-cli命令行工具采集BCS运行状态信息，
兼容密码认证和ACL用户名+密码认证方式。
"""
import os
import json
import subprocess
import re
import threading

# 从环境变量获取采集参数
ip = os.environ.get("EASYOPS_COLLECTOR_ip", "127.0.0.1")
port = os.environ.get("EASYOPS_COLLECTOR_port", "6379")
password = os.environ.get("EASYOPS_COLLECTOR_password", "")
username = os.environ.get("EASYOPS_COLLECTOR_username", "")
install_path = os.environ.get("EASYOPS_COLLECTOR_installPath", "")
cli_path = install_path + '/modeles/bcs/bin/bes-cache-cli' if install_path else "bes-cache-cli"
COLLECT_TIMEOUT = 30


def build_cli_command(*args):
    """构建bes-cache-cli命令行

    支持两种认证方式：
    - 仅密码：-a <password>
    - 用户名+密码（高版本ACL）：--user <username> -a <password>
    """
    cmd = [cli_path, "-h", ip, "-p", str(port)]
    if username:
        cmd.extend(["--user", username])
    if password:
        cmd.extend(["-a", password])
    cmd.extend(args)
    return cmd


def run_command(*args):
    """执行bes-cache-cli命令并返回输出

    使用 threading.Timer 替代 communicate(timeout=)，
    兼容 Python 2.7（communicate 无 timeout 参数，无 TimeoutExpired）。

    Returns:
        tuple: (returncode, output_string)
    """
    cmd = build_cli_command(*args)
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        timed_out = [False]

        def _kill_proc():
            timed_out[0] = True
            try:
                proc.kill()
            except OSError:
                pass

        timer = threading.Timer(COLLECT_TIMEOUT, _kill_proc)
        timer.start()
        stdout, stderr = proc.communicate()
        timer.cancel()

        if timed_out[0]:
            return -1, "Command timeout"

        output = stdout.decode("utf-8").strip()
        # 过滤Warning行
        lines = [line for line in output.split("\n")
                 if not line.startswith("Warning:")]
        return proc.returncode, "\n".join(lines)
    except Exception as e:
        return -1, str(e)


def parse_info(info_output):
    """解析INFO命令输出

    将 key:value 格式的输出解析为字典，自动转换数值类型。
    """
    result = {}
    for line in info_output.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            key, value = line.split(":", 1)
            try:
                result[key] = int(value)
            except ValueError:
                try:
                    result[key] = float(value)
                except ValueError:
                    result[key] = value
    return result


def parse_keyspace(info_output):
    """解析Keyspace部分，提取各DB的key统计信息"""
    dbs = {}
    in_keyspace = False
    for line in info_output.split("\n"):
        line = line.strip()
        if line == "# Keyspace":
            in_keyspace = True
            continue
        if in_keyspace and line.startswith("db"):
            match = re.match(r"db(\d+):(.+)", line)
            if match:
                db_num = match.group(1)
                attrs = {}
                for pair in match.group(2).split(","):
                    if "=" in pair:
                        k, v = pair.split("=", 1)
                        try:
                            attrs[k] = int(v)
                        except ValueError:
                            attrs[k] = v
                dbs[db_num] = attrs
    return dbs


if __name__ == "__main__":
    info = []
    dims = {"ip": ip, "installPath": install_path}
    vals = {}

    # 执行INFO命令
    returncode, output = run_command("INFO")

    if returncode != 0:
        info.append({
            "dims": dims,
            "vals": {"status": 0, "error_msg": output}
        })
        print(json.dumps(info, ensure_ascii=False))
        exit(0)

    # 解析INFO输出
    data = parse_info(output)
    dbs = parse_keyspace(output)

    vals["status"] = 1

    # --- 客户端指标 ---
    vals["m_connected_clients"] = float(data.get("connected_clients", 0))
    vals["m_blocked_clients"] = float(data.get("blocked_clients", 0))

    # --- 内存指标 ---
    used_memory = data.get("used_memory", 0)
    maxmemory = data.get("maxmemory", 0)

    vals["m_used_memory"] = float(used_memory)
    vals["m_used_memory_rss"] = float(data.get("used_memory_rss", 0))
    vals["m_used_memory_peak"] = float(data.get("used_memory_peak", 0))
    vals["m_maxmemory"] = float(maxmemory)
    vals["m_total_system_memory"] = float(data.get("total_system_memory", 0))
    vals["m_mem_fragmentation_ratio"] = float(data.get("mem_fragmentation_ratio", 0))

    # 内存使用率（仅当配置了maxmemory时计算）
    if maxmemory and int(maxmemory) > 0:
        vals["m_memory_usage_pct"] = round(
            float(used_memory) / float(maxmemory) * 100, 2)
    else:
        vals["m_memory_usage_pct"] = -1

    # --- 性能指标 ---
    vals["m_instantaneous_ops_per_sec"] = float(
        data.get("instantaneous_ops_per_sec", 0))
    vals["m_instantaneous_input_kbps"] = float(
        data.get("instantaneous_input_kbps", 0))
    vals["m_instantaneous_output_kbps"] = float(
        data.get("instantaneous_output_kbps", 0))

    # --- Key统计 ---
    keyspace_hits = data.get("keyspace_hits", 0)
    keyspace_misses = data.get("keyspace_misses", 0)
    total_access = int(keyspace_hits) + int(keyspace_misses)

    vals["m_keyspace_hits"] = float(keyspace_hits)
    vals["m_keyspace_misses"] = float(keyspace_misses)

    if total_access > 0:
        vals["m_hit_rate"] = round(
            float(keyspace_hits) / total_access * 100, 2)
    else:
        vals["m_hit_rate"] = 0

    vals["m_expired_keys"] = float(data.get("expired_keys", 0))
    vals["m_evicted_keys"] = float(data.get("evicted_keys", 0))
    vals["m_rejected_connections"] = float(
        data.get("rejected_connections", 0))

    # Key总数（所有DB之和）
    total_keys = sum(db.get("keys", 0) for db in dbs.values())
    vals["m_total_keys"] = float(total_keys)

    # --- 持久化指标 ---
    vals["m_rdb_bgsave_in_progress"] = float(
        data.get("rdb_bgsave_in_progress", 0))
    vals["m_aof_enabled"] = float(data.get("aof_enabled", 0))

    # --- 复制指标 ---
    vals["m_connected_slaves"] = float(data.get("connected_slaves", 0))

    # --- 运行时间 ---
    vals["m_uptime_in_seconds"] = float(data.get("uptime_in_seconds", 0))

    info.append({"dims": dims, "vals": vals})
    print(json.dumps(info, ensure_ascii=False))
