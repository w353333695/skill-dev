instanceid: 652db3b154591
collectorid: 4ff15d2720e72b8fd3367aa3
pluginid: inspector_dm
name: 达梦数据库巡检
content: |-
  #!/usr/local/easyops/python/bin/python
  # coding:utf-8
  import json
  import re
  import subprocess
  import os


  def exec_cmd(args):
      """执行命令并返回结果，使用列表传参避免shell注入"""
      process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
      output, error = process.communicate()
      # print args,output;exit()
      return process.returncode, output, error


  class DMInspector:
      def __init__(self, dm_user, dm_password, dm_port, dm_home):
          self.dm_user = dm_user
          self.dm_password = dm_password
          self.dm_port = dm_port
          self.dm_home = dm_home
          self.disql = dm_home + '/bin/disql' if dm_home else 'disql'
          self.result = []

      def run_disql(self, sql):
          """执行 disql 命令，密码用双引号包裹处理特殊字符"""
          escaped_pwd = self.dm_password.replace('"', '\\\"')
          conn_str = '{user}/"{password}"@127.0.0.1:{port}'.format(
              user=self.dm_user,
              password=escaped_pwd,
              port=self.dm_port
          )
          cmd_args = [self.disql, conn_str, '-E', sql]
          code, output, err = exec_cmd(cmd_args)
          return code, output, err

      def parse_disql_output(self, output):
          """解析 disql 输出，返回数据行列表（已过滤噪声，跳过表头和分隔线）"""
          if not output:
              return []
          lines = output.strip().split('\n')
          # 检测 SQL 错误，有错误则返回空
          for line in lines:
              if '错误[' in line or 'error' in line.lower():
                  return []
          clean_lines = []
          for line in lines:
              stripped = line.strip()
              if not stripped:
                  continue
              if stripped.startswith('\x1b') or stripped.startswith(']0;'):
                  continue
              if stripped.startswith('服务器'):
                  continue
              if '登录使用时间' in stripped:
                  continue
              if stripped.startswith('SQL>'):
                  continue
              if 'rows got' in stripped or 'row got' in stripped:
                  continue
              if 'time used' in stripped:
                  continue
              clean_lines.append(stripped)
          # 找到分隔线（由横线和空格组成），分隔线之后的是数据行
          data_rows = []
          found_sep = False
          for line in clean_lines:
              sep_check = line.replace('-', '').replace(' ', '')
              if not sep_check and len(line.replace(' ', '')) >= 3:
                  found_sep = True
                  continue
              if found_sep:
                  data_rows.append(line)
          return data_rows

      def collect_basic(self):
          """采集基本信息"""
          version = ""
          instance_name = ""
          db_status = ""
          port = self.dm_port

          code, output, err = self.run_disql("SELECT SVR_VERSION FROM V$INSTANCE;")
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              if rows:
                  version = rows[0].strip()

          code, output, err = self.run_disql("SELECT NAME, STATUS$ FROM V$DATABASE;")
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              if rows:
                  parts = rows[0].split()
                  if len(parts) >= 2:
                      instance_name = parts[0].strip()
                      status_code = parts[1].strip()
                      status_map = {"1": "STARTUP", "2": "AFTER REDO", "3": "MOUNT", "4": "OPEN", "5": "SUSPEND", "6": "CLOSE"}
                      db_status = status_map.get(status_code, status_code)

          self.result.append({
              "id": "basic",
              "dims": [],
              "vals": [
                  {"id": "version", "value": version},
                  {"id": "instance_name", "value": instance_name},
                  {"id": "db_status", "value": db_status},
                  {"id": "port", "value": str(port)},
                  {"id": "dm_home", "value": self.dm_home}
              ]
          })

      def collect_tablespace(self):
          """采集表空间使用率"""
          sql = ("SELECT F.TABLESPACE_NAME AS TS_NAME, "
                 "ROUND(F.TOTAL_BYTES / 1024 / 1024, 2) AS TOTAL_MB, "
                 "ROUND((F.TOTAL_BYTES - D.FREE_BYTES) / 1024 / 1024, 2) AS USED_MB, "
                 "ROUND(D.FREE_BYTES / 1024 / 1024, 2) AS FREE_MB, "
                 "ROUND((F.TOTAL_BYTES - D.FREE_BYTES) / F.TOTAL_BYTES * 100, 2) AS USAGE_PCT "
                 "FROM (SELECT TABLESPACE_NAME, SUM(BYTES) AS TOTAL_BYTES FROM DBA_DATA_FILES GROUP BY TABLESPACE_NAME) F, "
                 "(SELECT TABLESPACE_NAME, SUM(BYTES) AS FREE_BYTES FROM DBA_FREE_SPACE GROUP BY TABLESPACE_NAME) D "
                 "WHERE F.TABLESPACE_NAME = D.TABLESPACE_NAME;")

          code, output, err = self.run_disql(sql)
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              for row in rows:
                  parts = row.split()
                  if len(parts) >= 5:
                      ts_name = parts[0].strip()
                      if ts_name.startswith('-') or ts_name.startswith('TS_NAME'):
                          continue
                      try:
                          total_mb = float(parts[1]) if parts[1] else 0
                          used_mb = float(parts[2]) if parts[2] else 0
                          free_mb = float(parts[3]) if parts[3] else 0
                          usage_pct = float(parts[4]) if parts[4] else 0
                      except ValueError:
                          continue
                      self.result.append({
                          "id": "tablespace_usage",
                          "dims": [{"id": "tablespace_name", "value": ts_name}],
                          "vals": [
                              {"id": "total_size_mb", "value": int(total_mb)},
                              {"id": "used_size_mb", "value": int(used_mb)},
                              {"id": "free_size_mb", "value": int(free_mb)},
                              {"id": "usage_pct", "value": int(usage_pct)}
                          ]
                      })

      def collect_session(self):
          """采集会话信息"""
          total = 0
          active = 0
          max_sess = 0

          code, output, err = self.run_disql("SELECT COUNT(*) FROM V$SESSIONS;")
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              if rows:
                  try:
                      total = int(rows[0].strip())
                  except ValueError:
                      pass

          code, output, err = self.run_disql("SELECT COUNT(*) FROM V$SESSIONS WHERE STATE='ACTIVE';")
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              if rows:
                  try:
                      active = int(rows[0].strip())
                  except ValueError:
                      pass

          code, output, err = self.run_disql("SELECT SF_GET_PARA_VALUE(1, 'MAX_SESSIONS');")
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              if rows:
                  try:
                      max_sess = int(rows[0].strip())
                  except ValueError:
                      pass

          self.result.append({
              "id": "session_info",
              "dims": [],
              "vals": [
                  {"id": "total_sessions", "value": total},
                  {"id": "active_sessions", "value": active},
                  {"id": "max_sessions", "value": max_sess}
              ]
          })

      def collect_lock_wait(self):
          """采集锁等待信息（使用 V$TRXWAIT）"""
          sql = "SELECT WAIT_TRX_ID, HOLD_TRX_ID, WAIT_TIME FROM V$TRXWAIT;"
          code, output, err = self.run_disql(sql)
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              for row in rows:
                  parts = row.split()
                  if len(parts) >= 3:
                      wait_trx = parts[0].strip()
                      if wait_trx.startswith('-') or wait_trx.startswith('WAIT'):
                          continue
                      try:
                          wait_time_val = int(float(parts[2]))
                      except ValueError:
                          wait_time_val = 0
                      self.result.append({
                          "id": "lock_wait",
                          "dims": [{"id": "wait_sess_id", "value": parts[0]}],
                          "vals": [
                              {"id": "wait_sql", "value": ""},
                              {"id": "hold_sess_id", "value": parts[1]},
                              {"id": "wait_time_s", "value": wait_time_val}
                          ]
                      })

      def collect_performance(self):
          """采集性能指标"""
          buffer_hit = 0
          mem_used = 0

          # 缓冲区命中率 - 从 V$BUFFERPOOL 计算
          sql = "SELECT SUM(N_READ), SUM(N_MISS) FROM V$BUFFERPOOL;"
          code, output, err = self.run_disql(sql)
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              if rows:
                  parts = rows[0].split()
                  if len(parts) >= 2:
                      try:
                          n_read = int(float(parts[0]))
                          n_miss = int(float(parts[1]))
                          if n_read > 0:
                              buffer_hit = int(round((1 - float(n_miss) / n_read) * 100))
                      except (ValueError, ZeroDivisionError):
                          pass

          # 内存使用
          sql = "SELECT ROUND(SUM(TOTAL_SIZE)/1024.0/1024.0, 2) FROM V$MEM_POOL;"
          code, output, err = self.run_disql(sql)
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              if rows:
                  try:
                      mem_used = int(float(rows[0].strip()))
                  except ValueError:
                      pass

          self.result.append({
              "id": "performance",
              "dims": [],
              "vals": [
                  {"id": "buffer_hit_ratio", "value": buffer_hit},
                  {"id": "mem_used_mb", "value": mem_used},
                  {"id": "cpu_used_pct", "value": 0}
              ]
          })

      def collect_backup(self):
          """采集备份状态"""
          last_time = ""
          backup_type = ""
          status = ""

          code, output, err = self.run_disql(
              "SELECT TOP 1 BACKUP_TIME FROM V$BACKUPSET ORDER BY BACKUP_TIME DESC;"
          )
          if code == 0 and output:
              rows = self.parse_disql_output(output)
              if rows:
                  last_time = rows[0].strip()
                  backup_type = "未知"
                  status = "有备份"
              else:
                  status = "无备份记录"
          else:
              status = "无备份记录"

          self.result.append({
              "id": "backup_status",
              "dims": [],
              "vals": [
                  {"id": "last_backup_time", "value": last_time},
                  {"id": "backup_type", "value": backup_type},
                  {"id": "backup_status", "value": status}
              ]
          })

      def collect_config(self):
          """采集关键配置检查"""
          configs = [
              ("MAX_SESSIONS", "500", None),
              ("BUFFER", "1000", None),
              ("BUFFER_POOLS", "10", None),
              ("SORT_BUF_SIZE", "20", None),
              ("DICT_BUF_SIZE", "50", None),
              ("ENABLE_MONITOR", "1", None),
              ("MAX_OS_FILE_SIZE", "21474836480", None),
              ("RLOG_POOL_SIZE", "256", None),
          ]

          for param_name, recommend, _ in configs:
              param_value = ""
              code, output, err = self.run_disql(
                  "SELECT SF_GET_PARA_VALUE(1, '{}');".format(param_name)
              )
              if code == 0 and output:
                  rows = self.parse_disql_output(output)
                  if rows:
                      param_value = rows[0].strip()

              check_result = "正常"
              if param_name in ("BUFFER", "BUFFER_POOLS", "SORT_BUF_SIZE", "DICT_BUF_SIZE", "RLOG_POOL_SIZE"):
                  try:
                      if int(param_value) < int(recommend):
                          check_result = "异常"
                  except (ValueError, TypeError):
                      check_result = "异常"

              self.result.append({
                  "id": "config_check",
                  "dims": [{"id": "param_name", "value": param_name}],
                  "vals": [
                      {"id": "param_value", "value": param_value},
                      {"id": "recommend_value", "value": recommend},
                      {"id": "check_result", "value": check_result}
                  ]
              })

      def print_result(self):
          print "-------start-------"
          print json.dumps(self.result)
          print "-------end-------"


  if __name__ == '__main__':
      # source=custom 的参数直接按key名引用
      dm_user = dm_user
      dm_password = dm_password.decode('unicode_escape').encode('utf-8')
      dm_port = int(dm_port) if dm_port else 5236
      # source=attr_id 的CMDB属性用 EASYOPS_argname 引用
      dm_home = EASYOPS_installPath

      if not dm_home:
          dm_home = ""

      inspector = DMInspector(dm_user, dm_password, dm_port, dm_home)
      inspector.collect_basic()
      inspector.collect_tablespace()
      inspector.collect_session()
      inspector.collect_performance()
      inspector.collect_backup()
      inspector.collect_config()
      inspector.print_result()
args:
- key: installPath
  alias: 安装路径
  type: text
  require: false
  source: attr_id
  default: ""
  memo: ""
- key: dm_user
  alias: 数据库用户名
  type: text
  require: true
  source: custom
  default: SYSDBA
  memo: 达梦数据库连接用户名
- key: dm_password
  alias: 数据库密码
  type: password
  require: true
  source: custom
  default: ""
  memo: 达梦数据库连接密码
- key: dm_port
  alias: 数据库端口
  type: text
  require: false
  source: custom
  default: "5236"
  memo: 达梦数据库监听端口
script: python
