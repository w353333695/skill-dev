# MIB 调研与保留说明

## 通用 MIB
- SNMPv2-MIB：sysDescr、sysObjectID，用于连通性和品牌识别。
- IF-MIB：接口名称、管理/运行状态、64位收发字节，网口与光口共享接口表。
- ENTITY-MIB、ENTITY-SENSOR-MIB：实体描述、温度/风扇/电源传感器的标准兜底。
- HOST-RESOURCES-MIB：主机资源标准补充，部分BMC不实现，脚本不将其作为硬依赖。

## 厂商私有 MIB
- 华为：HUAWEI-SERVER-IBMC-MIB（1.3.6.1.4.1.2011.2.235）。
- 戴尔：IDRAC-MIB-SMIv2（1.3.6.1.4.1.674.10892）。
- 联想：LENOVO-XCC-MIB、LENOVO-SMI-MIB（企业树以设备返回的sysObjectID为准）。
- H3C：HH3C-ENTITY-EXT-MIB（1.3.6.1.4.1.25506）。
- 浪潮、百信：不同BMC/固件的私有树差异较大，分别保留候选配置；缺少私有实现时回退标准传感器表。

完整对象、来源摘要和校验信息见 `mib-evidence.json`、`oid-dictionary.json`、`mib-catalog.json`。
