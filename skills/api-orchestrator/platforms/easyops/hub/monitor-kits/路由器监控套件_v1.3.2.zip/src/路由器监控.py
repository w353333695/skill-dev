#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
"""通用路由器SNMP监控采集脚本（品牌自适应）

支持品牌（sysDescr 自动探测，OID 复用自各品牌专属监控套件）：
- Cisco    （CISCO-PROCESS-MIB/CISCO-ENVMON-MIB/CISCO-MEMORY-POOL-MIB）
- H3C      （HH3C-OID-MIB）
- 华为     （HUAWEI-ENTITY-EXTENT-MIB）
- 迈普     （MAIPU-SMI 1.3.6.1.4.1.5651，CPU/内存私有标量；风扇/电源/温度无公开 OID）
- UNIS    （紫光恒越，Comware OEM——复用 H3C OID 体系）
- 其他品牌回退基础系统指标（DISMAN-EVENT + IF-MIB 通用接口指标）

统一指标（v1.1.0 完全复用品牌套件已注册的 netware 指标集，防同模型同义指标重复）：
  snmp.netware.cpu_utilization / memory_utilization / memory_used / memory_free
  fan_status / power_status / temperature_val / temperature_status
  维度：snmp.netware.*_name（cpu_name/memory_name/fan_name/power_name/temperature_name）
"""
import os

ip = os.environ.get("EASYOPS_COLLECTOR_ip")
port = os.environ.get("EASYOPS_COLLECTOR_port")
version = os.environ.get("EASYOPS_COLLECTOR_version")
community = os.environ.get("EASYOPS_COLLECTOR_community")
username = os.environ.get("EASYOPS_COLLECTOR_username")
auth_key = os.environ.get("EASYOPS_COLLECTOR_auth_key")
auth_protocol = os.environ.get("EASYOPS_COLLECTOR_auth_protocol")
priv_key = os.environ.get("EASYOPS_COLLECTOR_priv_key")
priv_protocol = os.environ.get("EASYOPS_COLLECTOR_priv_protocol")

import subprocess
import json
import re
import logging

# 日志级别：默认 ERROR（生产静默）；调试用环境变量 EASYOPS_LOG_LEVEL=DEBUG（或 LOG_LEVEL）
# 打开 DEBUG 后输出：品牌探测依据/SNMP walk-get 明细/各表行数/过滤明细/最终指标——跨环境协同调试用
LOG_LEVEL = (os.environ.get("EASYOPS_LOG_LEVEL") or os.environ.get("LOG_LEVEL") or "ERROR").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.ERROR),
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("router_monitor")
logger.info("log level: %s", LOG_LEVEL)

OID_SYSDESCR = "1.3.6.1.2.1.1.1.0"
OID_SYSUPTIME = "1.3.6.1.2.1.1.3.0"
# IF-MIB 接口标准（全品牌通用）
OID_IF_ADMIN_STATUS = "1.3.6.1.2.1.2.2.1.7"
OID_IF_OPER_STATUS = "1.3.6.1.2.1.2.2.1.8"
OID_IF_IN_ERRORS = "1.3.6.1.2.1.2.2.1.14"
OID_IF_OUT_ERRORS = "1.3.6.1.2.1.2.2.1.20"
OID_IF_IN_DISCARDS = "1.3.6.1.2.1.2.2.1.13"
OID_IF_OUT_DISCARDS = "1.3.6.1.2.1.2.2.1.19"
OID_IF_NAME = "1.3.6.1.2.1.31.1.1.1.1"
OID_IF_IN_OCTETS = "1.3.6.1.2.1.31.1.1.1.6"     # ifHCInOctets（64 位）
OID_IF_OUT_OCTETS = "1.3.6.1.2.1.31.1.1.1.10"    # ifHCOutOctets（64 位）
OID_IF_IN_OCTETS_32 = "1.3.6.1.2.1.2.2.1.10"     # ifInOctets（32 位回退——部分设备无 HC 表）
OID_IF_OUT_OCTETS_32 = "1.3.6.1.2.1.2.2.1.16"    # ifOutOctets（32 位回退）

# 需要过滤的逻辑接口
FILTER_PATTERNS = ["Loopback", "InLoopBack", "NULL", "Vlan", "Management", "Mgmt", "Virtual-Template"]


# ============================================================================
# SNMP 客户端（系统 snmpwalk/snmpget 命令）
# ============================================================================
def _parse_walk_output(out):
    result = {}
    if not out:
        return result
    for line in out.splitlines():
        line = line.strip()
        if not line or "=" not in line:
            continue
        parts = line.split("=", 1)
        oid_key = parts[0].strip().lstrip(".")
        raw = parts[1].strip()
        if oid_key.startswith("iso."):
            oid_key = "1." + oid_key[4:]
        result[oid_key] = raw
    return result


def _parse_value(raw):
    if raw is None:
        return None, ""
    raw = str(raw).strip()
    if not raw:
        return None, ""
    if ":" in raw:
        typ, val = raw.split(":", 1)
        typ, val = typ.strip(), val.strip()
    else:
        typ, val = "", raw
    if typ in ("STRING", "OPAQUE"):
        return None, val.strip('"').strip()
    if typ == "Hex-STRING":
        try:
            return None, "".join(chr(int(x, 16)) for x in val.split()).strip()
        except ValueError:
            return None, val
    m = re.search(r"\((-?\d+(?:\.\d+)?)\)", val)
    if m:
        num = float(m.group(1))
        return (int(num) if num.is_integer() else num), val
    m = re.match(r"(-?\d+(?:\.\d+)?)", val)
    if m:
        num = float(m.group(1))
        return (int(num) if num.is_integer() else num), val
    return None, val


class SnmpClient(object):
    def __init__(self, ip, port, version, community, username=None, auth_key=None,
                 auth_protocol=None, priv_key=None, priv_protocol=None):
        self.host = (ip or "127.0.0.1").strip()
        self.port = str(port or "161").strip()
        self.version = (version or "2c").strip().lower()
        self.community = community or "public"
        self.username = username
        self.auth_key = auth_key
        self.auth_protocol = auth_protocol
        self.priv_key = priv_key
        self.priv_protocol = priv_protocol

    def _base_args(self):
        args = ["-On", "-t", "6", "-r", "2"]
        if self.version == "3":
            args += ["-v", "3"]
            args += ["-u", self.username or "", "-l", "authPriv"]
            if self.auth_protocol:
                args += ["-a", self.auth_protocol, "-A", self.auth_key or ""]
            if self.priv_protocol:
                args += ["-x", self.priv_protocol, "-X", self.priv_key or ""]
        else:
            v = self.version if self.version in ("1", "2c") else "2c"
            args += ["-v", v, "-c", self.community]
        args.append(self.host + ":" + self.port)
        return args

    def _exec(self, binary, args):
        cmd = [binary] + args
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = p.communicate()
            return p.returncode, out or "", err or ""
        except OSError:
            return 127, "", "snmp command not found"

    def walk(self, oid):
        code, out, err = self._exec("snmpwalk", self._base_args() + [oid])
        result = _parse_walk_output(out)
        # 原始输出全量进 debug（跨环境调试：按原始行+解析结果定位；截断仅防超长）
        logger.debug("snmpwalk %s -> rc=%s rows=%s err=%s\nraw output:\n%s",
                     oid, code, len(result), (err or "")[:80], out[:8000] if out else "(empty)")
        if code != 0 and not result:
            logger.error("snmpwalk %s failed rc=%s: %s", oid, code, (err or "")[:200])
        return result

    def get(self, oid):
        code, out, err = self._exec("snmpget", self._base_args() + [oid])
        m = _parse_walk_output(out)
        logger.debug("snmpget %s -> rc=%s\nraw output:\n%s", oid, code, out[:2000] if out else "(empty)")
        for k in m:
            return m[k]
        return ""


def walk_table(client, table_oid):
    """walk 一张表，返回 {index: {suffix: value}}。
    索引=OID 尾部全段（复合索引如华为风扇 '13.1' 不截断——截尾段会跨实体撞键；
    单段索引如温度 '30' 行为不变）。"""
    rows = {}
    for full, raw in client.walk(table_oid).items():
        if full.startswith(table_oid + "."):
            suffix = full[len(table_oid) + 1:]
            rows.setdefault(suffix, {})[suffix] = raw
    return rows


def should_filter(ifname):
    if not ifname:
        return False
    for p in FILTER_PATTERNS:
        if p in ifname:
            return True
    return False


def safe_float(v, default=0.0):
    try:
        return float(v)
    except (ValueError, TypeError):
        return default


# ============================================================================
# 品牌探测
# ============================================================================
VENDOR_CISCO = "cisco"
VENDOR_H3C = "h3c"
VENDOR_HUAWEI = "huawei"
VENDOR_MAIPU = "maipu"
VENDOR_UNIS = "unis"
VENDOR_GENERIC = "generic"


def detect_vendor(client):
    _, sysdescr = _parse_value(client.get(OID_SYSDESCR))
    d = (sysdescr or "").lower()
    logger.debug("sysDescr=%r", sysdescr)
    if "cisco" in d or "ios" in d:
        vendor = VENDOR_CISCO
    elif "huawei" in d or "vrp" in d:
        vendor = VENDOR_HUAWEI
    elif "unis" in d:
        # UNIS（紫光恒越）Comware OEM——须在 h3c/comware 之前判（UNIS sysDescr 含 comware）
        vendor = VENDOR_UNIS
    elif "h3c" in d or "comware" in d:
        vendor = VENDOR_H3C
    elif "maipu" in d or "mypower" in d or "isicos" in d:
        vendor = VENDOR_MAIPU
    else:
        vendor = VENDOR_GENERIC
    logger.info("detect vendor: %s (sysDescr=%r)", vendor, sysdescr)
    return vendor, sysdescr


# ============================================================================
# 品牌采集器
# ============================================================================
# ============================================================================
# 指标上报协议（v1.1.0）：完全复用品牌套件已注册指标（netware 指标集）
# key=snmp.netware.*，维度名=snmp.netware.*_name——防 ROUTER 模型挂多套同义指标
# ============================================================================
K_CPU = "snmp.netware.cpu_utilization"
D_CPU = "snmp.netware.cpu_name"
K_MEM_UTIL = "snmp.netware.memory_utilization"
K_MEM_USED = "snmp.netware.memory_used"
K_MEM_FREE = "snmp.netware.memory_free"
D_MEM = "snmp.netware.memory_name"
K_FAN = "snmp.netware.fan_status"
D_FAN = "snmp.netware.fan_name"
K_PWR = "snmp.netware.power_status"
D_PWR = "snmp.netware.power_name"
# 端口指标（IF-MIB 通用，全品牌一致；easyops 自有族）
K_PORT_ADMIN = "m_port_admin_status"
K_PORT_OPER = "m_port_oper_status"
K_PORT_IN_B = "m_port_in_bytes"
K_PORT_OUT_B = "m_port_out_bytes"
K_PORT_IN_ERR = "m_port_in_errors"
K_PORT_OUT_ERR = "m_port_out_errors"
K_PORT_IN_DSC = "m_port_in_discards"
K_PORT_OUT_DSC = "m_port_out_discards"
D_PORT = "port_name"
D_IP = "ip"
K_TEMP_V = "snmp.netware.temperature_val"
K_TEMP_S = "snmp.netware.temperature_status"
D_TEMP = "snmp.netware.temperature_name"


class BaseMonitor(object):
    """基类：通用回退（无私有 OID 时无设备级指标；接口指标 IF-MIB 通用保留）"""

    def __init__(self, client):
        self.client = client

    def collect_system(self, ip_addr):
        return []

    def collect_fan_power(self, ip_addr):
        return [], [], []

    def collect_interfaces(self, ip_addr):
        results = []
        names = walk_table(self.client, OID_IF_NAME)
        admin = walk_table(self.client, OID_IF_ADMIN_STATUS)
        oper = walk_table(self.client, OID_IF_OPER_STATUS)
        in_oct = walk_table(self.client, OID_IF_IN_OCTETS)
        out_oct = walk_table(self.client, OID_IF_OUT_OCTETS)
        # 流量双轨：HC 表(64位) 空/缺行时回退 32 位 ifIn/ifOutOctets（部分 Comware/老设备无 HC 表）
        if not in_oct:
            in32 = walk_table(self.client, OID_IF_IN_OCTETS_32)
            if in32:
                logger.debug("in-octets fallback 32-bit: %d rows", len(in32))
                in_oct = in32
        if not out_oct:
            out32 = walk_table(self.client, OID_IF_OUT_OCTETS_32)
            if out32:
                logger.debug("out-octets fallback 32-bit: %d rows", len(out32))
                out_oct = out32
        in_err = walk_table(self.client, OID_IF_IN_ERRORS)
        out_err = walk_table(self.client, OID_IF_OUT_ERRORS)
        in_dsc = walk_table(self.client, OID_IF_IN_DISCARDS)
        out_dsc = walk_table(self.client, OID_IF_OUT_DISCARDS)
        tables = [("admin", admin), ("oper", oper), ("inoct", in_oct), ("outoct", out_oct),
                  ("inerr", in_err), ("outerr", out_err), ("indsc", in_dsc), ("outdsc", out_dsc)]
        for idx, cols in names.items():
            _, ifname = _parse_value(list(cols.values())[0])
            if should_filter(ifname):
                logger.debug("filter interface: %s", ifname)
                continue
            vals = {}
            a = admin.get(idx) and _parse_value(list(admin[idx].values())[0])[0]
            o = oper.get(idx) and _parse_value(list(oper[idx].values())[0])[0]
            if a is not None:
                vals[K_PORT_ADMIN] = float(a)
            if o is not None:
                vals[K_PORT_OPER] = float(o)
            for key, tbl in ((K_PORT_IN_B, in_oct), (K_PORT_OUT_B, out_oct),
                             (K_PORT_IN_ERR, in_err), (K_PORT_OUT_ERR, out_err),
                             (K_PORT_IN_DSC, in_dsc), (K_PORT_OUT_DSC, out_dsc)):
                v = tbl.get(idx) and _parse_value(list(tbl[idx].values())[0])[0]
                if v is not None:
                    vals[key] = float(v)
            if vals:
                results.append({"dims": {D_IP: ip_addr, D_PORT: ifname or ("if" + idx)}, "vals": vals})
        return results

class CiscoMonitor(BaseMonitor):
    CPU = "1.3.6.1.4.1.9.9.109.1.1.1.1.8"
    MEM_NAME = "1.3.6.1.4.1.9.9.48.1.1.1.2"
    MEM_FREE = "1.3.6.1.4.1.9.9.48.1.1.1.6"
    MEM_USED = "1.3.6.1.4.1.9.9.48.1.1.1.5"
    TEMP_NAME = "1.3.6.1.4.1.9.9.13.1.3.1.2"
    TEMP_VAL = "1.3.6.1.4.1.9.9.13.1.3.1.3"
    TEMP_STATUS = "1.3.6.1.4.1.9.9.13.1.3.1.6"
    FAN_NAME = "1.3.6.1.4.1.9.9.13.1.4.1.2"
    FAN_STATUS = "1.3.6.1.4.1.9.9.13.1.4.1.3"
    PWR_NAME = "1.3.6.1.4.1.9.9.13.1.5.1.2"
    PWR_STATUS = "1.3.6.1.4.1.9.9.13.1.5.1.3"

    def collect_system(self, ip_addr):
        info = super(CiscoMonitor, self).collect_system(ip_addr)
        cpus = walk_table(self.client, self.CPU)
        for idx, cols in cpus.items():
            v, _ = _parse_value(list(cols.values())[0])
            if v is not None:
                info.append({"dims": {D_CPU: "cpu_%s" % idx}, "vals": {K_CPU: safe_float(v)}})
        # 内存池：每池一行，used/free/utilization 三指标，dim=池名（对齐品牌 memory_name）
        used = walk_table(self.client, self.MEM_USED)
        free = walk_table(self.client, self.MEM_FREE)
        names = walk_table(self.client, self.MEM_NAME)
        for idx, cols in used.items():
            u, _ = _parse_value(list(cols.values())[0])
            f = free.get(idx) and _parse_value(list(free[idx].values())[0])[0]
            nm = names.get(idx) and _parse_value(list(names[idx].values())[0])[1] or ("pool_" + idx)
            vals = {}
            if u is not None:
                vals[K_MEM_USED] = safe_float(u)
            if f is not None:
                vals[K_MEM_FREE] = safe_float(f)
            if u is not None and f is not None and (u + f) > 0:
                vals[K_MEM_UTIL] = round(float(u) / (float(u) + float(f)) * 100.0, 2)
            if vals:
                info.append({"dims": {D_MEM: nm}, "vals": vals})
        return info

    def collect_fan_power(self, ip_addr):
        fans, powers, temps = [], [], []
        fan_st = walk_table(self.client, self.FAN_STATUS)
        fan_nm = walk_table(self.client, self.FAN_NAME)
        for idx, cols in fan_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = fan_nm.get(idx) and _parse_value(list(fan_nm[idx].values())[0])[1] or ("fan_" + idx)
            fans.append({"dims": {D_FAN: nm}, "vals": {K_FAN: float(v) if v is not None else 0}})
        pwr_st = walk_table(self.client, self.PWR_STATUS)
        pwr_nm = walk_table(self.client, self.PWR_NAME)
        for idx, cols in pwr_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = pwr_nm.get(idx) and _parse_value(list(pwr_nm[idx].values())[0])[1] or ("power_" + idx)
            powers.append({"dims": {D_PWR: nm}, "vals": {K_PWR: float(v) if v is not None else 0}})
        tp_st = walk_table(self.client, self.TEMP_STATUS)
        tp_nm = walk_table(self.client, self.TEMP_NAME)
        tp_vl = walk_table(self.client, self.TEMP_VAL)
        for idx, cols in tp_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = tp_nm.get(idx) and _parse_value(list(tp_nm[idx].values())[0])[1] or ("temp_" + idx)
            tv = tp_vl.get(idx) and _parse_value(list(tp_vl[idx].values())[0])[0]
            vals = {K_TEMP_V: float(tv) if tv is not None else 0}
            if v is not None:
                vals[K_TEMP_S] = float(v)
            temps.append({"dims": {D_TEMP: nm}, "vals": vals})
        return fans, powers, temps


# ENTITY-SENSOR-MIB 标准温度表（私有 OID 无数据时兜底——UNIS Uniware 实测私有表 0 行）
OID_ENT_SENSOR_VALUE = "1.3.6.1.2.1.99.1.1.1.4"
OID_SYS_OBJECT_ID = "1.3.6.1.2.1.1.2.0"   # sysObjectID——设备厂商注册树（私有 OID 全空时的诊断锚点）


class EntityBaseMonitor(BaseMonitor):
    """H3C/华为同构：ENTITY-MIB 索引 + 私有 OID 表"""

    CPU = ""
    MEM = ""
    TEMP = ""
    FAN = ""
    FAN_NAME = ""
    PWR = ""
    PWR_NAME = ""
    ENTITY_NAME = "1.3.6.1.2.1.47.1.1.1.1.7"

    def collect_system(self, ip_addr):
        info = super(EntityBaseMonitor, self).collect_system(ip_addr)
        names = walk_table(self.client, self.ENTITY_NAME)
        cpus = walk_table(self.client, self.CPU)
        mems = walk_table(self.client, self.MEM)
        temps = walk_table(self.client, self.TEMP)
        logger.debug("entity names=%d cpus=%d mems=%d temps=%d", len(names), len(cpus), len(mems), len(temps))
        # 温度兜底：私有温度表空时走 ENTITY-SENSOR-MIB 标准表（UNIS Uniware 实测私有表 0 行）
        # 私有 OID 全空 → 企业树探测（sysObjectID 定位厂商注册树 + walk 产品树输出 OID 地图；
        # UNIS=清华紫光 10519 无公开 MIB，实测 hh3c 25506.2.6 与 99 表全 0 行——需实地摸树）
        if not temps and not cpus and not mems:
            sysoid = self.client.get(OID_SYS_OBJECT_ID)
            logger.warning("all private OIDs empty, sysObjectID=%r (vendor tree hint for next-step MIB)", sysoid)
            # sysObjectID 形如 OID: .1.3.6.1.4.1.10519.256.1.2.21 → 企业树=1.3.6.1.4.1.<ent>（10519）
            m = re.match(r"^(?:OID:\s*)?\.?(1\.3\.6\.1\.4\.1\.\d+)", (sysoid or "").strip())
            if m:
                prod_tree = m.group(1)   # 1.3.6.1.4.1.10519（企业整树，产品线自然展开）
                probe = self.client.walk(prod_tree)
                logger.warning("enterprise tree probe %s -> %d oids; sample:\n%s", prod_tree, len(probe),
                               "\n".join("%s = %s" % (k, v) for k, v in sorted(probe.items())[:200]))
                # 疑似性能/温度值过滤视图（排除接口大表；数值 5-95 的标量疑似温度/CPU/内存——跨环境定位 MIB）
                _sus = []
                for k, v in sorted(probe.items()):
                    if any(seg in k for seg in (".119.", "IfTable", "ifTable")):
                        continue
                    try:
                        num = float(str(v).split(":")[-1].strip())
                    except ValueError:
                        continue
                    if 5 <= num <= 95:
                        _sus.append("%s = %s" % (k, v))
                logger.warning("suspect perf/temp values (%d):\n%s", len(_sus), "\n".join(_sus[:100]))
        if not temps:
            sensor_vals = walk_table(self.client, OID_ENT_SENSOR_VALUE)
            for idx, cols in sensor_vals.items():
                v = _parse_value(list(cols.values())[0])[0]
                if v is not None:
                    temps[idx] = {list(cols.keys())[0]: "INTEGER: %s" % str(v)}
            logger.debug("temperature fallback ENTITY-SENSOR-MIB: %d sensors", len(temps))
        # 重名传感器去重：同名加实体 idx 后缀（H3C 多板卡同名 "Temperature Sensor" 实测）
        seen_names = {}
        # 逐实体输出（多主控/板卡各有 CPU/内存/温度）：dim=实体名（entPhysicalName），
        # 温度哨兵：65535=H3C/Comware 无传感器；0=华为/UNIS 无传感器占位（机房设备 0℃ 不现实）
        for idx, cols in names.items():
            nm = _parse_value(list(cols.values())[0])[1] or ("entity_" + idx)
            c = cpus.get(idx) and _parse_value(list(cpus[idx].values())[0])[0]
            m_ = mems.get(idx) and _parse_value(list(mems[idx].values())[0])[0]
            t = temps.get(idx) and _parse_value(list(temps[idx].values())[0])[0]
            if c:
                info.append({"dims": {D_CPU: nm}, "vals": {K_CPU: safe_float(c)}})
            if m_:
                info.append({"dims": {D_MEM: nm}, "vals": {K_MEM_UTIL: safe_float(m_)}})
            if t is not None and t not in (65535, 0):
                uniq = nm if seen_names.get(nm) is None else "%s #%s" % (nm, idx)
                seen_names[nm] = idx
                info.append({"dims": {D_TEMP: uniq}, "vals": {K_TEMP_V: safe_float(t)}})
            logger.debug("entity idx=%s name=%r cpu=%r mem=%r temp=%r", idx, nm, c, m_, t)
        # 99 表兜底的传感器可能不在 ENTITY name 表里——用 sensor idx 补
        known_idx = set(names.keys())
        for idx, cols in temps.items():
            if idx in known_idx:
                continue
            v = _parse_value(list(cols.values())[0])[0]
            if v is not None and v not in (65535, 0):
                info.append({"dims": {D_TEMP: "sensor_%s" % idx}, "vals": {K_TEMP_V: safe_float(v)}})
        return info
    def collect_fan_power(self, ip_addr):
        fans, powers = [], []
        # ENTITY 表真名池（华为 fan/power 名表实测 0 行，但 ENTITY 表有 'FAN slot 13'/'POWER 1'）
        ent_names = {}
        for idx, cols in walk_table(self.client, self.ENTITY_NAME).items():
            nm = _parse_value(list(cols.values())[0])[1]
            if nm:
                ent_names[nm] = idx
        def _resolve_name(kind, idx):
            """风扇/电源名：状态表索引首段=槽位号（华为 fan 13.1/power 1.0 实测）→
            先与 ENTITY 名模糊匹配（含 'FAN slot N'/'POWER N'），匹配不上用槽位格式。"""
            slot = str(idx).split(".")[0]
            for nm in ent_names:
                up = nm.upper()
                if kind == "FAN" and "FAN" in up and slot in nm.split():
                    return nm
                if kind == "PWR" and "POWER" in up and slot in nm.split():
                    return nm
            return "%s slot %s" % ("FAN" if kind == "FAN" else "POWER", slot)
        fan_st = walk_table(self.client, self.FAN)
        fan_nm = walk_table(self.client, self.FAN_NAME) if self.FAN_NAME else {}
        for idx, cols in fan_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = (fan_nm.get(idx) and _parse_value(list(fan_nm[idx].values())[0])[1]) or _resolve_name("FAN", idx)
            fans.append({"dims": {D_FAN: nm}, "vals": {K_FAN: float(v) if v is not None else 0}})
        pwr_st = walk_table(self.client, self.PWR)
        pwr_nm = walk_table(self.client, self.PWR_NAME) if self.PWR_NAME else {}
        for idx, cols in pwr_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = (pwr_nm.get(idx) and _parse_value(list(pwr_nm[idx].values())[0])[1]) or _resolve_name("PWR", idx)
            powers.append({"dims": {D_PWR: nm}, "vals": {K_PWR: float(v) if v is not None else 0}})
        return fans, powers, []


class H3CMonitor(EntityBaseMonitor):
    CPU = "1.3.6.1.4.1.25506.2.6.1.1.1.1.6"
    MEM = "1.3.6.1.4.1.25506.2.6.1.1.1.1.8"
    TEMP = "1.3.6.1.4.1.25506.2.6.1.1.1.1.12"
    FAN = "1.3.6.1.4.1.25506.8.35.9.1.1.1.2"
    PWR = "1.3.6.1.4.1.25506.8.35.9.1.2.1.2"


class HuaweiMonitor(EntityBaseMonitor):
    CPU = "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5"
    MEM = "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.7"
    TEMP = "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.11"
    FAN = "1.3.6.1.4.1.2011.5.25.31.1.1.10.1.7"
    FAN_NAME = "1.3.6.1.4.1.2011.5.25.31.1.1.10.1.8"
    PWR = "1.3.6.1.4.1.2011.5.25.31.1.1.18.1.6"
    PWR_NAME = "1.3.6.1.4.1.2011.5.25.31.1.1.18.1.9"


class MaipuMonitor(BaseMonitor):
    """迈普（Maipu，MyPower OS）——CPU/内存为私有标量 OID（1.3.6.1.4.1.5651）
    风扇/电源/温度无公开 OID（如现场 MIB 有补充走 FAN/PWR 常量即可）；接口指标 IF-MIB 通用。"""

    CPU = "1.3.6.1.4.1.5651.3.20.1.1.3.5.1.10"    # CPU 当前使用率（表单行 .1）
    MEM_UTIL = "1.3.6.1.4.1.5651.3.20.1.1.1.9.0"  # 内存使用率（标量 .0）
    MEM_FREE = "1.3.6.1.4.1.5651.3.20.1.1.1.1.0"  # 空闲内存
    MEM_USED = "1.3.6.1.4.1.5651.3.20.1.1.1.5.0"  # 已用内存
    MEM_TOTAL = "1.3.6.1.4.1.5651.3.20.1.1.1.8.0" # 总内存

    def collect_system(self, ip_addr):
        info = super(MaipuMonitor, self).collect_system(ip_addr)
        # CPU：表形态（.1 结尾索引行），walk 兜底 GET 不到的场景
        cpu_v = None
        cpus = walk_table(self.client, self.CPU.rsplit(".", 1)[0])
        for idx, cols in cpus.items():
            v, _ = _parse_value(list(cols.values())[0])
            if v is not None:
                cpu_v = max(cpu_v or 0, safe_float(v))
        if cpu_v is None:
            v, _ = _parse_value(self.client.get(self.CPU + ".1"))
            if v is not None:
                cpu_v = safe_float(v)
        if cpu_v is not None:
            info.append({"dims": {D_CPU: "cpu"}, "vals": {K_CPU: cpu_v}})
        # 内存：标量 GET；使用率缺失时用 used/total 计算
        mem_v, _ = _parse_value(self.client.get(self.MEM_UTIL))
        if mem_v is None:
            u, _ = _parse_value(self.client.get(self.MEM_USED))
            t, _ = _parse_value(self.client.get(self.MEM_TOTAL))
            if u is not None and t is not None and t > 0:
                mem_v = round(float(u) / float(t) * 100.0, 2)
        if mem_v is not None:
            info.append({"dims": {D_MEM: "memory"}, "vals": {K_MEM_UTIL: mem_v}})
        return info


class UnisMonitor(EntityBaseMonitor):
    """UNIS（清华紫光 10519，Uniware=Comware OEM）——私有树布局假设为 hh3c 镜像
    （25506.2.6.1.1.1.1.x → 10519.256.2.6.1.1.1.1.x，字典序原因探测 sample 未覆盖到 .6 子树，
    待真机验证）+ 备选温度 256.2.13.1.3（实测 Gauge32: 30 疑似温度）。"""

    CPU = "1.3.6.1.4.1.10519.256.2.6.1.1.1.1.6"
    MEM = "1.3.6.1.4.1.10519.256.2.6.1.1.1.1.8"
    TEMP = "1.3.6.1.4.1.10519.256.2.6.1.1.1.1.12"
    TEMP_ALT = "1.3.6.1.4.1.10519.256.2.13.1.3"   # 备选温度（.13.1.3.<实体idx>，实测 .0=30）
    # 风扇/电源：hh3c FAN-MIB 镜像候选（25506.8.35 → 10519.256.8.35，映射规则同 CPU 表 25506.2→10519.256.2）
    FAN = "1.3.6.1.4.1.10519.256.8.35.9.1.1.1.2"
    PWR = "1.3.6.1.4.1.10519.256.8.35.9.1.2.1.2"

    def collect_fan_power(self, ip_addr):
        fans, powers, temps = super(UnisMonitor, self).collect_fan_power(ip_addr)
        if not fans and not powers:
            # 镜像候选全空 → 输出实体扩展表整表列地图（定位风扇/电源真实列，下轮日志定位）
            ext = self.client.walk("1.3.6.1.4.1.10519.256.2.6.1.1.1.1")
            logger.warning("UNIS fan/power mirror empty; entity-ext table map (%d oids):\n%s", len(ext),
                           "\n".join("%s = %s" % (k, v) for k, v in sorted(ext.items())[:60]))
        return fans, powers, temps

    def collect_system(self, ip_addr):
        info = super(UnisMonitor, self).collect_system(ip_addr)
        # 主树无温度时试备选
        if not any(K_TEMP_V in r["vals"] for r in info):
            alt = walk_table(self.client, self.TEMP_ALT)
            for idx, cols in alt.items():
                v, _ = _parse_value(list(cols.values())[0])
                if v is not None and v not in (65535, 0) and 0 < v < 200:
                    info.append({"dims": {D_TEMP: "sensor_%s" % idx}, "vals": {K_TEMP_V: safe_float(v)}})
                    logger.debug("UNIS alt temperature idx=%s val=%s", idx, v)
        return info


VENDOR_MAP = {
    VENDOR_CISCO: CiscoMonitor,
    VENDOR_H3C: H3CMonitor,
    VENDOR_HUAWEI: HuaweiMonitor,
    VENDOR_MAIPU: MaipuMonitor,
    VENDOR_UNIS: UnisMonitor,
    VENDOR_GENERIC: BaseMonitor,
}


def collect_all(client, ip_addr):
    vendor, sysdescr = detect_vendor(client)
    monitor = VENDOR_MAP.get(vendor, BaseMonitor)(client)
    logger.debug("monitor class: %s", type(monitor).__name__)
    info = []
    info.extend(monitor.collect_system(ip_addr))
    logger.debug("system rows=%d", len(info))
    fans, powers, temps = monitor.collect_fan_power(ip_addr)
    logger.debug("fan=%d power=%d temp=%d rows", len(fans), len(powers), len(temps))
    info.extend(fans)
    info.extend(powers)
    info.extend(temps)
    # 端口指标（IF-MIB 通用，m_port_* 自有族，已注册 origin/alias）
    interfaces = monitor.collect_interfaces(ip_addr)
    logger.debug("interface rows=%d", len(interfaces))
    info.extend(interfaces)
    logger.debug("collect_all total=%d rows: %s", len(info), json.dumps(info, ensure_ascii=False))
    return info


if __name__ == "__main__":
    snmp_client = SnmpClient(
        ip=ip, port=int(port or 161), version=version, community=community,
        username=username if username else None, auth_key=auth_key if auth_key else None,
        auth_protocol=auth_protocol if auth_protocol else None,
        priv_key=priv_key if priv_key else None, priv_protocol=priv_protocol if priv_protocol else None,
    )
    info = collect_all(snmp_client, ip)
    print(json.dumps(info, ensure_ascii=False))
