#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
ip = os.environ.get("EASYOPS_COLLECTOR_ip")
port = os.environ.get("EASYOPS_COLLECTOR_port")
version = os.environ.get("EASYOPS_COLLECTOR_version")
community = os.environ.get("EASYOPS_COLLECTOR_community")
username = os.environ.get("EASYOPS_COLLECTOR_username")
auth_key = os.environ.get("EASYOPS_COLLECTOR_auth_key")
auth_protocol = os.environ.get("EASYOPS_COLLECTOR_auth_protocol")
priv_key = os.environ.get("EASYOPS_COLLECTOR_priv_key")
priv_protocol = os.environ.get("EASYOPS_COLLECTOR_priv_protocol")
log_level = os.environ.get("EASYOPS_COLLECTOR_log_level")

"""物理服务器 SNMP 监控：连通性/品牌识别、标准及私有 MIB 采集、统一指标输出。"""
import os, re, json, subprocess, logging, sys, traceback, time, uuid

def parameter_value(raw):
 if raw is None: return None
 normalized = str(raw).strip()
 if normalized.lower() in ("", "null", "none", "undefined") or normalized.startswith("$."): return None
 return normalized

port = parameter_value(port) or parameter_value(os.environ.get("EASYOPS_COLLECTOR_snmpPort")) or "161"
version = version or os.environ.get("EASYOPS_COLLECTOR_snmpVersion") or "2c"
community = community or "public"
username = username or os.environ.get("EASYOPS_COLLECTOR_securityName")
auth_key = auth_key or os.environ.get("EASYOPS_COLLECTOR_authKey")
auth_protocol = auth_protocol or os.environ.get("EASYOPS_COLLECTOR_authProtocol")
priv_key = priv_key or os.environ.get("EASYOPS_COLLECTOR_privKey")
priv_protocol = priv_protocol or os.environ.get("EASYOPS_COLLECTOR_privProtocol")
LOG_LEVEL=(parameter_value(globals().get("log_level")) or parameter_value(os.environ.get("EASYOPS_LOG_LEVEL")) or parameter_value(os.environ.get("LOG_LEVEL")) or "ERROR").upper()
RUN_ID = uuid.uuid4().hex[:12]
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.ERROR), format="%(asctime)s [%(levelname)s] [run="+RUN_ID+"] %(message)s")
LOG=logging.getLogger("physical_server_monitor")
LOG.setLevel(getattr(logging, LOG_LEVEL, logging.ERROR))

def safe_log(raw):
 if isinstance(raw, bytes): raw = raw.decode("utf-8", "replace")
 text_type = type(u"")
 message = text_type(raw)
 for secret in (community, auth_key, priv_key):
  if not secret: continue
  token = text_type(secret)
  for representation in (token, json.dumps(token)[1:-1], repr(token)[1:-1]):
   if representation: message = message.replace(representation, "<redacted>")
 return message

def command_for_log(command):
 sanitized = list(command)
 for position, argument in enumerate(sanitized):
  if position > 0 and command[position-1] in ("-c", "-A", "-X"):
   sanitized[position] = "<redacted>"
 return safe_log(json.dumps(sanitized, ensure_ascii=False))

# 配置以 Python 内置 dict/list 保存，便于同一品牌增加多套 MIB 候选。
PROFILES = {
 "huawei": {"roots":["1.3.6.1.4.1.2011.2.235"], "mibs":["HUAWEI-SERVER-IBMC-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.2011.2.235.1.1.5.1.6","1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5"], "mem":["1.3.6.1.4.1.2011.2.235.1.1.7.1.6","1.3.6.1.4.1.2011.5.25.31.1.1.1.1.7"], "temp":["1.3.6.1.4.1.2011.2.235.1.1.20.1.5","1.3.6.1.2.1.99.1.1.1.4"], "fan":["1.3.6.1.4.1.2011.2.235.1.1.21.1.5"], "power":["1.3.6.1.4.1.2011.2.235.1.1.22.1.5"]},
 "dell": {"roots":["1.3.6.1.4.1.674.10892"], "mibs":["IDRAC-MIB-SMIv2","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.674.10892.5.4.1100.30.1.6"], "mem":["1.3.6.1.4.1.674.10892.5.4.1300.30.1.6"], "temp":["1.3.6.1.4.1.674.10892.5.4.700.30.1.6","1.3.6.1.2.1.99.1.1.1.4"], "fan":["1.3.6.1.4.1.674.10892.5.4.600.30.1.6"], "power":["1.3.6.1.4.1.674.10892.5.4.1000.30.1.5"]},
 "lenovo": {"roots":["1.3.6.1.4.1.19046","1.3.6.1.4.1.19046.11"], "mibs":["LENOVO-XCC-MIB","LENOVO-SMI-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.19046.11.1.1.1.1.6"], "mem":["1.3.6.1.4.1.19046.11.1.2.1.1.6"], "temp":["1.3.6.1.2.1.99.1.1.1.4"], "fan":[], "power":[]},
 "inspur": {"roots":["1.3.6.1.4.1.9603"], "mibs":["INSPUR-SERVER-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.9603.1.1.1.1.5"], "mem":["1.3.6.1.4.1.9603.1.1.2.1.5"], "temp":["1.3.6.1.2.1.99.1.1.1.4"], "fan":[], "power":[]},
 "h3c": {"roots":["1.3.6.1.4.1.25506"], "mibs":["HH3C-ENTITY-EXT-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.25506.2.6.1.1.1.1.6"], "mem":["1.3.6.1.4.1.25506.2.6.1.1.1.1.8"], "temp":["1.3.6.1.4.1.25506.8.35.9.1.3.1.2","1.3.6.1.2.1.99.1.1.1.4"], "fan":["1.3.6.1.4.1.25506.8.35.9.1.1.1.2"], "power":["1.3.6.1.4.1.25506.8.35.9.1.2.1.2"]},
 "baixin": {"roots":["1.3.6.1.4.1.3902"], "mibs":["BAIXIN-SERVER-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":[], "mem":[], "temp":["1.3.6.1.2.1.99.1.1.1.4"], "fan":[], "power":[]},
 "generic": {"roots":[], "mibs":["SNMPv2-MIB","IF-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":[], "mem":[], "temp":["1.3.6.1.2.1.99.1.1.1.4"], "fan":[], "power":[]}
}
OID={"sysDescr":"1.3.6.1.2.1.1.1.0","sysObjectID":"1.3.6.1.2.1.1.2.0","sysName":"1.3.6.1.2.1.1.5.0","sysUptime":"1.3.6.1.2.1.1.3.0","ifName":"1.3.6.1.2.1.31.1.1.1.1","ifOper":"1.3.6.1.2.1.2.2.1.8","ifAdmin":"1.3.6.1.2.1.2.2.1.7","ifIn":"1.3.6.1.2.1.31.1.1.1.6","ifOut":"1.3.6.1.2.1.31.1.1.1.10","ifSpeed":"1.3.6.1.2.1.31.1.1.1.15","ifInErrors":"1.3.6.1.2.1.2.2.1.14","ifOutErrors":"1.3.6.1.2.1.2.2.1.20","sensorValue":"1.3.6.1.2.1.99.1.1.1.4","sensorName":"1.3.6.1.2.1.99.1.1.1.2","sensorStatus":"1.3.6.1.2.1.99.1.1.1.5","hrSize":"1.3.6.1.2.1.25.2.3.1.5","hrUsed":"1.3.6.1.2.1.25.2.3.1.6","entDescr":"1.3.6.1.2.1.47.1.1.1.1.2"}
# 模板导出中确认的服务器 BMC OID；同一品牌可按设备固件继续追加候选。
EXTRA_PROFILES = {
 "huawei": {"model":"1.3.6.1.4.1.2011.2.235.1.1.1.6.0", "serial":"1.3.6.1.4.1.2011.2.235.1.1.1.7.0", "health":"1.3.6.1.4.1.2011.2.235.1.1.1.1.0", "power_system":"1.3.6.1.4.1.2011.2.235.1.1.1.12.0", "fan_speed":"1.3.6.1.4.1.2011.2.235.1.1.8.50.1.2", "fan_status":"1.3.6.1.4.1.2011.2.235.1.1.8.50.1.4", "memory_size":"1.3.6.1.4.1.2011.2.235.1.1.16.50.1.4", "memory_status":"1.3.6.1.4.1.2011.2.235.1.1.16.50.1.6", "disk_size":"1.3.6.1.4.1.2011.2.235.1.1.18.50.1.12", "disk_status":"1.3.6.1.4.1.2011.2.235.1.1.18.50.1.3", "temperature":"1.3.6.1.4.1.2011.2.235.1.1.26.50.1.3", "power":"1.3.6.1.4.1.2011.2.235.1.1.6.50.1.7", "processor_status":"1.3.6.1.4.1.2011.2.235.1.1.15.50.1.6"},
 "dell": {"firmware":"1.3.6.1.4.1.674.10892.5.1.1.8.0", "model":"1.3.6.1.4.1.674.10892.5.1.3.12.0", "serial":"1.3.6.1.4.1.674.10892.5.1.3.2.0", "health":"1.3.6.1.4.1.674.10892.5.2.1.0", "power_system":"1.3.6.1.4.1.674.10892.5.1.3.6.0", "fan_speed":"1.3.6.1.4.1.674.10892.5.4.700.12.1.6", "fan_status":"1.3.6.1.4.1.674.10892.5.4.700.12.1.5", "power":"1.3.6.1.4.1.674.10892.5.4.600.12.1.5", "temperature":"1.3.6.1.4.1.674.10892.5.4.700.20.1.6", "disk_status":"1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.24", "disk_size":"1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.11"},
 "lenovo": {"health":"1.3.6.1.4.1.19046.11.1.1.4.1.0", "power_system":"1.3.6.1.4.1.19046.11.1.5.1.1.0", "fan_speed":"1.3.6.1.4.1.19046.11.1.1.3.2.1.3", "fan_status":"1.3.6.1.4.1.19046.11.1.1.3.2.1.10", "power":"1.3.6.1.4.1.19046.11.1.1.11.2.1.6", "temperature":"1.3.6.1.4.1.19046.11.1.1.1.2.1.3", "disk_status":"1.3.6.1.4.1.19046.11.1.1.12.2.1.3"},
 "inspur": {"processor_status":"1.3.6.1.4.1.37945.2.1.2.4.1.1.3", "memory_status":"1.3.6.1.4.1.37945.2.1.2.5.1.1.3", "memory_size":"1.3.6.1.4.1.37945.2.1.1.2.1.1.9", "fan_speed":"1.3.6.1.4.1.37945.2.1.2.3.1.1.4", "fan_status":"1.3.6.1.4.1.37945.2.1.2.3.1.1.3", "power":"1.3.6.1.4.1.37945.2.1.2.7.1.1.3", "temperature":"1.3.6.1.4.1.37945.2.1.2.1.1.1.4", "disk_status":"1.3.6.1.4.1.37945.2.1.6.2.1.1.3"},
 "h3c": {"fan_speed":"1.3.6.1.4.1.25506.13.1.2.1.2.1.1.1.6", "fan_status":"1.3.6.1.4.1.25506.13.1.2.1.2.1.1.1.5", "power":"1.3.6.1.4.1.25506.13.1.2.1.1.7.1.1.1.8", "disk_status":"1.3.6.1.4.1.25506.13.1.2.1.1.9.1.1.4", "processor_status":"1.3.6.1.4.1.25506.13.1.2.1.1.1.1.1.6", "memory_status":"1.3.6.1.4.1.25506.13.1.2.1.1.2.2.1.5"},
 "ibm": {"model":"1.3.6.1.4.1.2.3.51.3.1.5.2.1.5.0", "serial":"1.3.6.1.4.1.2.3.51.3.1.5.2.1.3.0", "health":"1.3.6.1.4.1.2.3.51.3.1.4.1.0", "fan_speed":"1.3.6.1.4.1.2.3.51.3.1.3.2.1.3", "fan_status":"1.3.6.1.4.1.2.3.51.3.1.3.2.1.10", "power":"1.3.6.1.4.1.2.3.51.3.1.11.2.1.6", "temperature":"1.3.6.1.4.1.2.3.51.3.1.1.2.1.3", "disk_status":"1.3.6.1.4.1.2.3.51.3.1.12.2.1.3"}
}


def parse(out):
 d={}
 for line in (out or "").splitlines():
  if "=" not in line:
   LOG.debug("[parse] skipped_line=%s",safe_log(line))
   continue
  k,v=line.split("=",1); k=k.strip().lstrip("."); v=v.strip()
  if k.startswith("iso."): k="1."+k[4:]
  d[k]=v
  LOG.debug("[parse] oid=%s raw_value=%s",k,safe_log(v))
 LOG.debug("[parse] parsed=%s",safe_log(json.dumps(d,ensure_ascii=False)))
 return d

def value(raw):
 if raw is None:
  LOG.debug("[value] input=None output=None")
  return None
 s=str(raw).strip(); s=s.split(":",1)[-1].strip() if ":" in s else s
 if not s or s.lower().startswith(("no such","timeout","unknown")):
  LOG.debug("[value] input=%s output=None reason=unavailable",safe_log(raw))
  return None
 m=re.search(r"\((-?\d+(?:\.\d+)?)\)",s) or re.match(r"(-?\d+(?:\.\d+)?)",s)
 if m:
  n=float(m.group(1)); converted = int(n) if n.is_integer() else n
 else: converted = s.strip('"')
 LOG.debug("[value] input=%s output=%s type=%s",safe_log(raw),safe_log(converted),type(converted).__name__)
 return converted
class SNMP(object):
 def __init__(self): self.base=["-On","-t","5","-r","1"]; self.sequence=0
 def args(self):
  v=version.lower(); a=list(self.base)+["-v",v]
  if v=="3":
   a += ["-u",username or "","-l","authPriv"]
   if auth_protocol: a += ["-a",auth_protocol,"-A",auth_key or ""]
   if priv_protocol: a += ["-x",priv_protocol,"-X",priv_key or ""]
  else: a += ["-c",community]
  a += [str(ip)+":"+str(port)]; return a
 def run(self,cmd,oid):
  self.sequence += 1
  sequence = self.sequence
  started = time.time()
  command = [cmd]+self.args()+[oid]
  LOG.debug("[SNMP.run] begin run=%s seq=%s command=%s",RUN_ID,sequence,command_for_log(command))
  try:
   p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   out,err=p.communicate()
  except Exception:
   LOG.error("[SNMP.run] cmd=%s oid=%s error=%s",cmd,oid,safe_log(traceback.format_exc()))
   return {}
  LOG.debug("[SNMP.run] raw_stdout_begin run=%s seq=%s oid=%s\n%s\n[SNMP.run] raw_stdout_end",RUN_ID,sequence,oid,safe_log(out or b""))
  LOG.debug("[SNMP.run] raw_stderr_begin run=%s seq=%s oid=%s\n%s\n[SNMP.run] raw_stderr_end",RUN_ID,sequence,oid,safe_log(err or b""))
  d=parse(out.decode("utf-8","replace") if not isinstance(out,str) else out)
  stderr = safe_log(err or b"")[:500]
  LOG.debug("[SNMP.run] end run=%s seq=%s elapsed_seconds=%.3f rc=%s rows=%s",RUN_ID,sequence,time.time()-started,p.returncode,len(d))
  LOG.debug("[SNMP.run] cmd=%s oid=%s target=%s:%s rc=%s rows=%s stderr=%s",cmd,oid,ip,port,p.returncode,len(d),stderr)
  if p.returncode != 0 or not d:
   LOG.warning("[SNMP.run] request_failed_or_empty cmd=%s oid=%s target=%s:%s rc=%s rows=%s stderr=%s",cmd,oid,ip,port,p.returncode,len(d),stderr)
  return d
 def get(self,oid):
  d=self.run("snmpget",oid)
  parsed = value(next(iter(d.values()))) if d else None
  if parsed is None: LOG.warning("[SNMP.get] no_usable_value oid=%s target=%s:%s",oid,ip,port)
  return parsed
 def walk(self,oid): return self.run("snmpwalk",oid)
def vendor(s):
 so=str(s.get("sysObjectID") or ""); desc=str(s.get("sysDescr") or "").lower()
 checks=[("huawei",["2011","huawei"]),("dell",["674.10892","dell","idrac"]),("lenovo",["19046","lenovo","xcc"]),("inspur",["9603","37945","inspur"]),("ibm",["2.3.51","ibm","imm"]),("h3c",["25506","h3c","comware"]),("baixin",["3902","baixin"])]
 for name, keys in checks:
  if any(k in so.lower() or k in desc for k in keys): return name
 return "generic"
def rows(table, base):
 out=[]
 for k,v in table.items():
  if k.startswith(base+"."): out.append((k[len(base)+1:],value(v)))
 LOG.debug("[rows] root=%s converted=%s",base,safe_log(json.dumps(out,ensure_ascii=False)))
 return out
METRIC_DIMENSIONS = {
    "snmp.server.cpu.utilization": "snmp.server.cpu_name",
    "snmp.server.memory.utilization": "snmp.server.memory_name",
    "snmp.server.temperature.value": "snmp.server.temperature_name",
    "snmp.server.fan.status": "snmp.server.fan_name",
    "snmp.server.power.status": "snmp.server.power_name",
    "snmp.server.interface.oper_status": "snmp.server.interface_name",
    "snmp.server.interface.admin_status": "snmp.server.interface_name",
    "snmp.server.interface.in_octets": "snmp.server.interface_name",
    "snmp.server.interface.out_octets": "snmp.server.interface_name",
    "snmp.server.disk.utilization": "snmp.server.disk_name",
    "snmp.server.optical.oper_status": "snmp.server.optical_name",
    "snmp.server.hardware.model": None, "snmp.server.hardware.serial": None, "snmp.server.hardware.firmware": None,
    "snmp.server.health.status": None, "snmp.server.power.system_status": None, "snmp.server.fan.speed": "snmp.server.fan_name",
    "snmp.server.disk.status": "snmp.server.disk_name", "snmp.server.disk.size": "snmp.server.disk_name",
    "snmp.server.memory.status": "snmp.server.memory_name", "snmp.server.memory.size": "snmp.server.memory_name",
    "snmp.server.processor.status": "snmp.server.processor_name", "snmp.server.uptime": None,
    "snmp.server.interface.speed": "snmp.server.interface_name", "snmp.server.interface.in_errors": "snmp.server.interface_name", "snmp.server.interface.out_errors": "snmp.server.interface_name"
}

def metric(key,val,dim=None):
 if val is None:
  LOG.warning("[metric] missing_value metric=%s component=%s",key,dim)
  return None
 dimension = METRIC_DIMENSIONS.get(key)
 record = {"dims":({dimension:str(dim)} if dimension and dim is not None else {}),"vals":{key:val}}
 LOG.debug("[metric] converted_output=%s",safe_log(json.dumps(record,ensure_ascii=False)))
 return record
def main():
 LOG.info("[main] start target=%s:%s version=%s log_level=%s",ip,port,version,LOG_LEVEL)
 if not parameter_value(ip): raise RuntimeError("缺少有效 EASYOPS_COLLECTOR_ip")
 try:
  parsed_port = int(port)
  if not 1 <= parsed_port <= 65535: raise ValueError("port out of range")
 except (TypeError, ValueError):
  LOG.error("[main] invalid_port=%s error=%s",port,safe_log(traceback.format_exc()))
  raise RuntimeError("SNMP端口必须为1到65535的整数")
 sn=SNMP(); sysd=sn.get(OID["sysDescr"]); syso=sn.get(OID["sysObjectID"])
 if sysd is None and syso is None:
  LOG.error("[main] connectivity_failed target=%s:%s sysDescr/sysObjectID均无响应",ip,port)
  raise RuntimeError("SNMP基础连通性失败：sysDescr/sysObjectID均无响应")
 v=vendor({"sysDescr":sysd,"sysObjectID":syso}); profile=PROFILES[v]; LOG.info("[identify] ip=%s vendor=%s sysObjectID=%s sysDescr=%s",ip,v,syso,sysd)
 LOG.debug("[main] identified_vendor=%s sysDescr=%s sysObjectID=%s profile=%s",v,safe_log(sysd),safe_log(syso),json.dumps(profile,ensure_ascii=False))
 result=[]
 # 身份与整机健康信息：这些 OID 来自本次导出的厂商模板，标量失败只告警并继续。
 common_scalars = [("snmp.server.uptime", OID["sysUptime"], None)] if v in EXTRA_PROFILES or v == "generic" else []
 for key, oid, known in common_scalars:
  current = known if known is not None else sn.get(oid)
  if current is not None and key not in METRIC_DIMENSIONS:
   METRIC_DIMENSIONS[key] = None
  if current is not None: result.append(metric(key, current))
 extras = EXTRA_PROFILES.get(v, {})
 scalar_keys = [("model", "snmp.server.hardware.model"), ("serial", "snmp.server.hardware.serial"), ("firmware", "snmp.server.hardware.firmware"), ("health", "snmp.server.health.status"), ("power_system", "snmp.server.power.system_status")]
 for field, key in scalar_keys:
  oid = extras.get(field)
  if oid:
   raw = sn.get(oid)
   if raw is not None: result.append(metric(key, raw))
   else: LOG.warning("[collect.identity] unavailable field=%s oid=%s vendor=%s", field, oid, v)
 # 逐组件扩展指标：只在 OID 有响应时输出，不把缺失组件当成零。
 for field, key, dim_name in [("fan_speed", "snmp.server.fan.speed", "fan"), ("fan_status", "snmp.server.fan.status", "fan"), ("power", "snmp.server.power.status", "power"), ("temperature", "snmp.server.temperature.value", "temperature"), ("disk_status", "snmp.server.disk.status", "disk"), ("disk_size", "snmp.server.disk.size", "disk"), ("memory_status", "snmp.server.memory.status", "memory"), ("memory_size", "snmp.server.memory.size", "memory"), ("processor_status", "snmp.server.processor.status", "processor")]:
  oid = extras.get(field)
  if not oid: continue
  data = sn.walk(oid); values = [(idx, val) for idx, val in rows(data, oid) if val is not None]
  if values:
   for idx, val in values: result.append(metric(key, val, idx))
   LOG.info("[collect.extra] field=%s oid=%s rows=%s", field, oid, len(values))
  else: LOG.warning("[collect.extra] unavailable field=%s oid=%s vendor=%s", field, oid, v)
 for kind,key in [("cpu","snmp.server.cpu.utilization"),("mem","snmp.server.memory.utilization"),("temp","snmp.server.temperature.value"),("fan","snmp.server.fan.status"),("power","snmp.server.power.status")]:
  found=False
  for oid in profile.get(kind,[]) or []:
   LOG.debug("[main] candidate_begin kind=%s metric=%s oid=%s",kind,key,oid)
   data=sn.walk(oid); vals=rows(data,oid)
   if not vals:
    LOG.debug("[main] walk_empty_try_get metric=%s oid=%s",key,oid)
    x=sn.get(oid); vals=[("0",x)] if x is not None else []
   usable = [(idx,x) for idx,x in vals if x is not None]
   if not usable: LOG.warning("[main] no_usable_rows metric=%s oid=%s vendor=%s",key,oid,v)
   for idx,x in usable:
    result.append(metric(key,x,idx)); found=True
   if found:
    LOG.debug("[main] candidate_selected metric=%s oid=%s rows=%s",key,oid,len(usable))
    break
  LOG.info("[collect.%s] rows=%s",kind,sum(1 for r in result if key in r.get("vals",{})))
 # ENTITY-SENSOR-MIB 通用温度/风扇/电源兜底
 if not any("snmp.server.temperature.value" in r.get("vals",{}) for r in result):
  LOG.debug("[main] temperature_fallback root=%s",OID["sensorValue"])
  vals=rows(sn.walk(OID["sensorValue"]),OID["sensorValue"]); names=dict(rows(sn.walk(OID["sensorName"]),OID["sensorName"]))
  for idx,x in vals:
   if x is not None: result.append(metric("snmp.server.temperature.value",x,value(names.get(idx)) or idx))
 # 磁盘/存储：HOST-RESOURCES-MIB 标准表，按 used/size 计算利用率。
 sizes=dict(rows(sn.walk(OID["hrSize"]),OID["hrSize"])); used=dict(rows(sn.walk(OID["hrUsed"]),OID["hrUsed"]))
 disk_count=0
 for idx,sv in sizes.items():
  try:
   total=float(sv); cur=float(used.get(idx));
   LOG.debug("[main] disk_conversion component=%s size=%s used=%s",idx,total,cur)
   if total > 0 and cur >= 0:
    result.append(metric("snmp.server.disk.utilization",round(cur/total*100.0,2),idx)); disk_count += 1
   else: LOG.warning("[main] invalid_disk_capacity component=%s size=%s used=%s",idx,sv,used.get(idx))
  except (TypeError,ValueError):
   LOG.warning("[main] invalid_disk_value component=%s size=%s used=%s error=%s",idx,sv,used.get(idx),safe_log(traceback.format_exc()))
 LOG.info("[collect.disk] rows=%s",disk_count)
 # IF-MIB：状态、流量，并将 optical 属性以介质名称保留；光口无法识别时仍输出接口状态
 names=dict(rows(sn.walk(OID["ifName"]),OID["ifName"])); ops=dict(rows(sn.walk(OID["ifOper"]),OID["ifOper"])); admins=dict(rows(sn.walk(OID["ifAdmin"]),OID["ifAdmin"])); ins=dict(rows(sn.walk(OID["ifIn"]),OID["ifIn"])); outs=dict(rows(sn.walk(OID["ifOut"]),OID["ifOut"])); speeds=dict(rows(sn.walk(OID["ifSpeed"]),OID["ifSpeed"])); in_errors=dict(rows(sn.walk(OID["ifInErrors"]),OID["ifInErrors"])); out_errors=dict(rows(sn.walk(OID["ifOutErrors"]),OID["ifOutErrors"]))
 for idx,n in names.items():
  dim=value(n) or idx; base=[metric("snmp.server.interface.oper_status",value(ops.get(idx)),dim),metric("snmp.server.interface.admin_status",value(admins.get(idx)),dim),metric("snmp.server.interface.in_octets",value(ins.get(idx)),dim),metric("snmp.server.interface.out_octets",value(outs.get(idx)),dim),metric("snmp.server.interface.speed",value(speeds.get(idx)),dim),metric("snmp.server.interface.in_errors",value(in_errors.get(idx)),dim),metric("snmp.server.interface.out_errors",value(out_errors.get(idx)),dim)]
  if re.search(r"(光|optic|sfp|qsfp|fiber|fc|xe|xge)",str(dim),re.I): base.append(metric("snmp.server.optical.oper_status",value(ops.get(idx)),dim))
  result += [r for r in base if r]
 LOG.info("[collect.interfaces] rows=%s",len(names)); LOG.info("[collect.result] vendor=%s records=%s",v,len(result))
 emitted = {key for record in result for key in record.get("vals",{})}
 for key in sorted(METRIC_DIMENSIONS):
  if key not in emitted:
   LOG.warning("[main] metric_unavailable metric=%s vendor=%s target=%s:%s reason=unsupported_oid_or_empty_or_invalid_value",key,v,ip,port)
 if not result:
  LOG.error("[main] no_metrics target=%s:%s vendor=%s",ip,port,v)
  raise RuntimeError("SNMP响应成功但未解析出监控指标")
 LOG.debug("[main] output_begin run=%s records=%s\n%s\n[main] output_end",RUN_ID,len(result),safe_log(json.dumps(result,ensure_ascii=False)))
 print(json.dumps(result,ensure_ascii=False))
if __name__=="__main__": main()
