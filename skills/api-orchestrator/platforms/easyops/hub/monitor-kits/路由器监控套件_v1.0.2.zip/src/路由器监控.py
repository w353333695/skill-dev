#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
"""通用路由器SNMP监控采集脚本（品牌自适应）

支持品牌（sysDescr 自动探测，OID 复用自各品牌专属监控套件）：
- Cisco    （CISCO-PROCESS-MIB/CISCO-ENVMON-MIB/CISCO-MEMORY-POOL-MIB）
- H3C      （HH3C-OID-MIB）
- 华为     （HUAWEI-ENTITY-EXTENT-MIB）
- 迈普     （MAIPU-SMI 1.3.6.1.4.1.5651，CPU/内存私有标量；风扇/电源/温度无公开 OID）
- 其他品牌回退基础系统指标（DISMAN-EVENT + IF-MIB 通用接口指标）

统一指标名（跨品牌一致）：
  设备级: m_cpu_usage / m_mem_usage / m_uptime / m_fan_status / m_power_status / m_temp
  端口级: m_port_oper_status / m_port_in_bytes / m_port_out_bytes / m_port_in_errors / m_port_out_errors
"""
import os

ip = os.environ.get("EASYOPS_COLLECTOR_ip")
port = os.environ.get("EASYOPS_COLLECTOR_port")
version = os.environ.get("EASYOPS_COLLECTOR_version")
community = os.environ.get("EASYOPS_COLLECTOR_community")
username = os.environ.get("EASYOPS_COLLECTOR_username")
auth_key = os.environ.get("EASYOPS_COLLECTOR_auth_key")
auth_protocol = os.environ.get("EASYOPS_COLLECTOR_auth_protocol")
priv_key = os.environ.get("EASYOPS_COLLECTOR_priv_key")
priv_protocol = os.environ.get("EASYOPS_COLLECTOR_priv_protocol")

import subprocess
import json
import re
import logging

# 日志级别：默认 ERROR（生产静默）；调试用环境变量 EASYOPS_LOG_LEVEL=DEBUG（或 LOG_LEVEL）
# 打开 DEBUG 后输出：品牌探测依据/SNMP walk-get 明细/各表行数/过滤明细/最终指标——跨环境协同调试用
LOG_LEVEL = (os.environ.get("EASYOPS_LOG_LEVEL") or os.environ.get("LOG_LEVEL") or "ERROR").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.ERROR),
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("router_monitor")
logger.info("log level: %s", LOG_LEVEL)

OID_SYSDESCR = "1.3.6.1.2.1.1.1.0"
OID_SYSUPTIME = "1.3.6.1.2.1.1.3.0"
# IF-MIB 接口标准（全品牌通用）
OID_IF_OPER_STATUS = "1.3.6.1.2.1.2.2.1.8"
OID_IF_IN_ERRORS = "1.3.6.1.2.1.2.2.1.14"
OID_IF_OUT_ERRORS = "1.3.6.1.2.1.2.2.1.20"
OID_IF_NAME = "1.3.6.1.2.1.31.1.1.1.1"
OID_IF_IN_OCTETS = "1.3.6.1.2.1.31.1.1.1.6"
OID_IF_OUT_OCTETS = "1.3.6.1.2.1.31.1.1.1.10"

# 需要过滤的逻辑接口
FILTER_PATTERNS = ["Loopback", "InLoopBack", "NULL", "Vlan", "Management", "Mgmt", "Virtual-Template"]


# ============================================================================
# SNMP 客户端（系统 snmpwalk/snmpget 命令）
# ============================================================================
def _parse_walk_output(out):
    result = {}
    if not out:
        return result
    for line in out.splitlines():
        line = line.strip()
        if not line or "=" not in line:
            continue
        parts = line.split("=", 1)
        oid_key = parts[0].strip().lstrip(".")
        raw = parts[1].strip()
        if oid_key.startswith("iso."):
            oid_key = "1." + oid_key[4:]
        result[oid_key] = raw
    return result


def _parse_value(raw):
    if raw is None:
        return None, ""
    raw = str(raw).strip()
    if not raw:
        return None, ""
    if ":" in raw:
        typ, val = raw.split(":", 1)
        typ, val = typ.strip(), val.strip()
    else:
        typ, val = "", raw
    if typ in ("STRING", "OPAQUE"):
        return None, val.strip('"').strip()
    if typ == "Hex-STRING":
        try:
            return None, "".join(chr(int(x, 16)) for x in val.split()).strip()
        except ValueError:
            return None, val
    m = re.search(r"\((-?\d+(?:\.\d+)?)\)", val)
    if m:
        num = float(m.group(1))
        return (int(num) if num.is_integer() else num), val
    m = re.match(r"(-?\d+(?:\.\d+)?)", val)
    if m:
        num = float(m.group(1))
        return (int(num) if num.is_integer() else num), val
    return None, val


class SnmpClient(object):
    def __init__(self, ip, port, version, community, username=None, auth_key=None,
                 auth_protocol=None, priv_key=None, priv_protocol=None):
        self.host = (ip or "127.0.0.1").strip()
        self.port = str(port or "161").strip()
        self.version = (version or "2c").strip().lower()
        self.community = community or "public"
        self.username = username
        self.auth_key = auth_key
        self.auth_protocol = auth_protocol
        self.priv_key = priv_key
        self.priv_protocol = priv_protocol

    def _base_args(self):
        args = ["-On", "-t", "6", "-r", "2"]
        if self.version == "3":
            args += ["-v", "3"]
            args += ["-u", self.username or "", "-l", "authPriv"]
            if self.auth_protocol:
                args += ["-a", self.auth_protocol, "-A", self.auth_key or ""]
            if self.priv_protocol:
                args += ["-x", self.priv_protocol, "-X", self.priv_key or ""]
        else:
            v = self.version if self.version in ("1", "2c") else "2c"
            args += ["-v", v, "-c", self.community]
        args.append(self.host + ":" + self.port)
        return args

    def _exec(self, binary, args):
        cmd = [binary] + args
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = p.communicate()
            return p.returncode, out or "", err or ""
        except OSError:
            return 127, "", "snmp command not found"

    def walk(self, oid):
        code, out, err = self._exec("snmpwalk", self._base_args() + [oid])
        result = _parse_walk_output(out)
        logger.debug("snmpwalk %s -> rc=%s rows=%s err=%s", oid, code, len(result), (err or "")[:80])
        if code != 0 and not result:
            logger.error("snmpwalk %s failed rc=%s: %s", oid, code, (err or "")[:200])
        return result

    def get(self, oid):
        code, out, err = self._exec("snmpget", self._base_args() + [oid])
        m = _parse_walk_output(out)
        logger.debug("snmpget %s -> rc=%s raw=%r", oid, code, out[:120] if out else out)
        for k in m:
            return m[k]
        return ""


def walk_table(client, table_oid):
    """walk 一张表，返回 {index: {suffix: value}}"""
    rows = {}
    for full, raw in client.walk(table_oid).items():
        if full.startswith(table_oid + "."):
            suffix = full[len(table_oid) + 1:]
            parts = suffix.split(".")
            idx = parts[-1]
            rows.setdefault(idx, {})[suffix] = raw
    return rows


def should_filter(ifname):
    if not ifname:
        return False
    for p in FILTER_PATTERNS:
        if p in ifname:
            return True
    return False


def safe_float(v, default=0.0):
    try:
        return float(v)
    except (ValueError, TypeError):
        return default


# ============================================================================
# 品牌探测
# ============================================================================
VENDOR_CISCO = "cisco"
VENDOR_H3C = "h3c"
VENDOR_HUAWEI = "huawei"
VENDOR_MAIPU = "maipu"
VENDOR_GENERIC = "generic"


def detect_vendor(client):
    _, sysdescr = _parse_value(client.get(OID_SYSDESCR))
    d = (sysdescr or "").lower()
    logger.debug("sysDescr=%r", sysdescr)
    if "cisco" in d or "ios" in d:
        vendor = VENDOR_CISCO
    elif "huawei" in d or "vrp" in d:
        vendor = VENDOR_HUAWEI
    elif "h3c" in d or "comware" in d:
        vendor = VENDOR_H3C
    elif "maipu" in d or "mypower" in d or "isicos" in d:
        vendor = VENDOR_MAIPU
    else:
        vendor = VENDOR_GENERIC
    logger.info("detect vendor: %s (sysDescr=%r)", vendor, sysdescr)
    return vendor, sysdescr


# ============================================================================
# 品牌采集器
# ============================================================================
class BaseMonitor(object):
    """基类：通用系统指标 + 标准接口指标（IF-MIB）"""

    def __init__(self, client):
        self.client = client

    def collect_system(self, ip_addr):
        up_num, _ = _parse_value(self.client.get(OID_SYSUPTIME))
        uptime_h = round(safe_float(up_num) / 3600.0 / 100.0, 1) if up_num else 0
        return [{
            "dims": {"ip": ip_addr},
            "vals": {
                "m_uptime": uptime_h,
                "m_cpu_usage": None,
                "m_mem_usage": None,
            },
        }]

    def collect_fan_power(self, ip_addr):
        return [], [], []

    def collect_interfaces(self, ip_addr):
        results = []
        names = walk_table(self.client, OID_IF_NAME)
        oper = walk_table(self.client, OID_IF_OPER_STATUS)
        in_oct = walk_table(self.client, OID_IF_IN_OCTETS)
        out_oct = walk_table(self.client, OID_IF_OUT_OCTETS)
        in_err = walk_table(self.client, OID_IF_IN_ERRORS)
        out_err = walk_table(self.client, OID_IF_OUT_ERRORS)
        for idx, cols in names.items():
            _, ifname = _parse_value(list(cols.values())[0])
            if should_filter(ifname):
                logger.debug("filter interface: %s", ifname)
                continue
            vals = {}
            if oper.get(idx):
                v, _ = _parse_value(list(oper[idx].values())[0])
                if v is not None:
                    vals["m_port_oper_status"] = float(v)
            if in_oct.get(idx):
                v, _ = _parse_value(list(in_oct[idx].values())[0])
                if v is not None:
                    vals["m_port_in_bytes"] = float(v)
            if out_oct.get(idx):
                v, _ = _parse_value(list(out_oct[idx].values())[0])
                if v is not None:
                    vals["m_port_out_bytes"] = float(v)
            if in_err.get(idx):
                v, _ = _parse_value(list(in_err[idx].values())[0])
                if v is not None:
                    vals["m_port_in_errors"] = float(v)
            if out_err.get(idx):
                v, _ = _parse_value(list(out_err[idx].values())[0])
                if v is not None:
                    vals["m_port_out_errors"] = float(v)
            if vals:
                results.append({"dims": {"ip": ip_addr, "port_name": ifname or ("if" + idx)}, "vals": vals})
        return results


class CiscoMonitor(BaseMonitor):
    CPU = "1.3.6.1.4.1.9.9.109.1.1.1.1.8"
    MEM_NAME = "1.3.6.1.4.1.9.9.48.1.1.1.2"
    MEM_FREE = "1.3.6.1.4.1.9.9.48.1.1.1.6"
    MEM_USED = "1.3.6.1.4.1.9.9.48.1.1.1.5"
    TEMP_NAME = "1.3.6.1.4.1.9.9.13.1.3.1.2"
    TEMP_VAL = "1.3.6.1.4.1.9.9.13.1.3.1.3"
    TEMP_STATUS = "1.3.6.1.4.1.9.9.13.1.3.1.6"
    FAN_NAME = "1.3.6.1.4.1.9.9.13.1.4.1.2"
    FAN_STATUS = "1.3.6.1.4.1.9.9.13.1.4.1.3"
    PWR_NAME = "1.3.6.1.4.1.9.9.13.1.5.1.2"
    PWR_STATUS = "1.3.6.1.4.1.9.9.13.1.5.1.3"

    def collect_system(self, ip_addr):
        info = super(CiscoMonitor, self).collect_system(ip_addr)
        cpus = walk_table(self.client, self.CPU)
        cpu_vals = [safe_float(_parse_value(list(c.values())[0])[0]) for c in cpus.values()]
        if cpu_vals:
            info[0]["vals"]["m_cpu_usage"] = round(max(cpu_vals), 2)
        # 内存：used/(used+free) → 利用率
        used = walk_table(self.client, self.MEM_USED)
        free = walk_table(self.client, self.MEM_FREE)
        mem_util = None
        for idx in used:
            u, _ = _parse_value(list(used[idx].values())[0])
            f = free.get(idx) and _parse_value(list(free[idx].values())[0])[0]
            if u is not None and f is not None and (u + f) > 0:
                mem_util = round(float(u) / (float(u) + float(f)) * 100.0, 2)
                break
        info[0]["vals"]["m_mem_usage"] = mem_util
        return info

    def collect_fan_power(self, ip_addr):
        fans, powers, temps = [], [], []
        fan_st = walk_table(self.client, self.FAN_STATUS)
        fan_nm = walk_table(self.client, self.FAN_NAME)
        for idx, cols in fan_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = fan_nm.get(idx) and _parse_value(list(fan_nm[idx].values())[0])[1] or ("fan_" + idx)
            fans.append({"dims": {"ip": ip_addr, "sensor_name": nm}, "vals": {"m_fan_status": float(v) if v is not None else 0}})
        pwr_st = walk_table(self.client, self.PWR_STATUS)
        pwr_nm = walk_table(self.client, self.PWR_NAME)
        for idx, cols in pwr_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = pwr_nm.get(idx) and _parse_value(list(pwr_nm[idx].values())[0])[1] or ("power_" + idx)
            powers.append({"dims": {"ip": ip_addr, "sensor_name": nm}, "vals": {"m_power_status": float(v) if v is not None else 0}})
        tp_st = walk_table(self.client, self.TEMP_STATUS)
        tp_nm = walk_table(self.client, self.TEMP_NAME)
        tp_vl = walk_table(self.client, self.TEMP_VAL)
        for idx, cols in tp_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = tp_nm.get(idx) and _parse_value(list(tp_nm[idx].values())[0])[1] or ("temp_" + idx)
            tv = tp_vl.get(idx) and _parse_value(list(tp_vl[idx].values())[0])[0]
            vals = {"m_temp": float(tv) if tv is not None else 0}
            temps.append({"dims": {"ip": ip_addr, "sensor_name": nm}, "vals": vals})
        return fans, powers, temps


class EntityBaseMonitor(BaseMonitor):
    """H3C/华为同构：ENTITY-MIB 索引 + 私有 OID 表"""

    CPU = ""
    MEM = ""
    TEMP = ""
    FAN = ""
    FAN_NAME = ""
    PWR = ""
    PWR_NAME = ""
    ENTITY_NAME = "1.3.6.1.2.1.47.1.1.1.1.7"

    def collect_system(self, ip_addr):
        info = super(EntityBaseMonitor, self).collect_system(ip_addr)
        names = walk_table(self.client, self.ENTITY_NAME)
        cpus = walk_table(self.client, self.CPU)
        mems = walk_table(self.client, self.MEM)
        temps = walk_table(self.client, self.TEMP)
        cpu_v, mem_v, temp_v = None, None, None
        for idx in names:
            nm = _parse_value(list(names[idx].values())[0])[1] or ""
            c = cpus.get(idx) and _parse_value(list(cpus[idx].values())[0])[0]
            m = mems.get(idx) and _parse_value(list(mems[idx].values())[0])[0]
            t = temps.get(idx) and _parse_value(list(temps[idx].values())[0])[0]
            if c is not None and nm:
                cpu_v = max(cpu_v or 0, safe_float(c))
            if m is not None and nm:
                mem_v = max(mem_v or 0, safe_float(m))
            if t is not None and nm and "temp" in (nm or "").lower() or (t is not None and temp_v is None):
                temp_v = safe_float(t) if t is not None else temp_v
        info[0]["vals"]["m_cpu_usage"] = cpu_v
        info[0]["vals"]["m_mem_usage"] = mem_v
        if temp_v is not None:
            info[0]["vals"]["m_temp"] = temp_v
        return info

    def collect_fan_power(self, ip_addr):
        fans, powers = [], []
        fan_st = walk_table(self.client, self.FAN)
        fan_nm = walk_table(self.client, self.FAN_NAME) if self.FAN_NAME else {}
        for idx, cols in fan_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = fan_nm.get(idx) and _parse_value(list(fan_nm[idx].values())[0])[1] or ("fan_" + idx)
            fans.append({"dims": {"ip": ip_addr, "sensor_name": nm}, "vals": {"m_fan_status": float(v) if v is not None else 0}})
        pwr_st = walk_table(self.client, self.PWR)
        pwr_nm = walk_table(self.client, self.PWR_NAME) if self.PWR_NAME else {}
        for idx, cols in pwr_st.items():
            v, _ = _parse_value(list(cols.values())[0])
            nm = pwr_nm.get(idx) and _parse_value(list(pwr_nm[idx].values())[0])[1] or ("power_" + idx)
            powers.append({"dims": {"ip": ip_addr, "sensor_name": nm}, "vals": {"m_power_status": float(v) if v is not None else 0}})
        return fans, powers, []


class H3CMonitor(EntityBaseMonitor):
    CPU = "1.3.6.1.4.1.25506.2.6.1.1.1.1.6"
    MEM = "1.3.6.1.4.1.25506.2.6.1.1.1.1.8"
    TEMP = "1.3.6.1.4.1.25506.2.6.1.1.1.1.12"
    FAN = "1.3.6.1.4.1.25506.8.35.9.1.1.1.2"
    PWR = "1.3.6.1.4.1.25506.8.35.9.1.2.1.2"


class HuaweiMonitor(EntityBaseMonitor):
    CPU = "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5"
    MEM = "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.7"
    TEMP = "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.11"
    FAN = "1.3.6.1.4.1.2011.5.25.31.1.1.10.1.7"
    FAN_NAME = "1.3.6.1.4.1.2011.5.25.31.1.1.10.1.8"
    PWR = "1.3.6.1.4.1.2011.5.25.31.1.1.18.1.6"
    PWR_NAME = "1.3.6.1.4.1.2011.5.25.31.1.1.18.1.9"


class MaipuMonitor(BaseMonitor):
    """迈普（Maipu，MyPower OS）——CPU/内存为私有标量 OID（1.3.6.1.4.1.5651）
    风扇/电源/温度无公开 OID（如现场 MIB 有补充走 FAN/PWR 常量即可）；接口指标 IF-MIB 通用。"""

    CPU = "1.3.6.1.4.1.5651.3.20.1.1.3.5.1.10"    # CPU 当前使用率（表单行 .1）
    MEM_UTIL = "1.3.6.1.4.1.5651.3.20.1.1.1.9.0"  # 内存使用率（标量 .0）
    MEM_FREE = "1.3.6.1.4.1.5651.3.20.1.1.1.1.0"  # 空闲内存
    MEM_USED = "1.3.6.1.4.1.5651.3.20.1.1.1.5.0"  # 已用内存
    MEM_TOTAL = "1.3.6.1.4.1.5651.3.20.1.1.1.8.0" # 总内存

    def collect_system(self, ip_addr):
        info = super(MaipuMonitor, self).collect_system(ip_addr)
        # CPU：表形态（.1 结尾索引行），walk 兜底 GET 不到的场景
        cpu_v = None
        cpus = walk_table(self.client, self.CPU.rsplit(".", 1)[0])
        for idx, cols in cpus.items():
            v, _ = _parse_value(list(cols.values())[0])
            if v is not None:
                cpu_v = max(cpu_v or 0, safe_float(v))
        if cpu_v is None:
            v, _ = _parse_value(self.client.get(self.CPU + ".1"))
            if v is not None:
                cpu_v = safe_float(v)
        info[0]["vals"]["m_cpu_usage"] = cpu_v
        # 内存：标量 GET；使用率缺失时用 used/total 计算
        mem_v, _ = _parse_value(self.client.get(self.MEM_UTIL))
        if mem_v is None:
            u, _ = _parse_value(self.client.get(self.MEM_USED))
            t, _ = _parse_value(self.client.get(self.MEM_TOTAL))
            if u is not None and t is not None and t > 0:
                mem_v = round(float(u) / float(t) * 100.0, 2)
        info[0]["vals"]["m_mem_usage"] = mem_v if mem_v is not None else None
        return info


VENDOR_MAP = {
    VENDOR_CISCO: CiscoMonitor,
    VENDOR_H3C: H3CMonitor,
    VENDOR_HUAWEI: HuaweiMonitor,
    VENDOR_MAIPU: MaipuMonitor,
    VENDOR_GENERIC: BaseMonitor,
}


def collect_all(client, ip_addr):
    vendor, sysdescr = detect_vendor(client)
    monitor = VENDOR_MAP.get(vendor, BaseMonitor)(client)
    logger.debug("monitor class: %s", type(monitor).__name__)
    info = []
    info.extend(monitor.collect_system(ip_addr))
    logger.debug("system rows=%d", len(info))
    fans, powers, temps = monitor.collect_fan_power(ip_addr)
    logger.debug("fan=%d power=%d temp=%d rows", len(fans), len(powers), len(temps))
    info.extend(fans)
    info.extend(powers)
    info.extend(temps)
    interfaces = monitor.collect_interfaces(ip_addr)
    logger.debug("interface rows=%d", len(interfaces))
    info.extend(interfaces)
    logger.debug("collect_all total=%d rows: %s", len(info), json.dumps(info, ensure_ascii=False))
    return info


if __name__ == "__main__":
    snmp_client = SnmpClient(
        ip=ip, port=int(port or 161), version=version, community=community,
        username=username if username else None, auth_key=auth_key if auth_key else None,
        auth_protocol=auth_protocol if auth_protocol else None,
        priv_key=priv_key if priv_key else None, priv_protocol=priv_protocol if priv_protocol else None,
    )
    info = collect_all(snmp_client, ip)
    print(json.dumps(info, ensure_ascii=False))
