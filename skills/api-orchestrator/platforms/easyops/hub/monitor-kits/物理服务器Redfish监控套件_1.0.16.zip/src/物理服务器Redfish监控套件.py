import os
host = os.environ.get("EASYOPS_COLLECTOR_host")
user = os.environ.get("EASYOPS_COLLECTOR_user")
password = os.environ.get("EASYOPS_COLLECTOR_password")
requestsTime = os.environ.get("EASYOPS_COLLECTOR_requestsTime")

#!/usr/local/easyops/python/bin/python
# -*- coding: UTF-8 -*-

import requests
import json
import os
import sys
import traceback

isdebug = False
requestsTime = globals().get("requestsTime") or 10

try:
    requestsTime = int(requestsTime)
except (ValueError, TypeError):
    requestsTime = 10

requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)


class AuthFile():
    def __init__(self, host):
        self.host = host
        self.auth_file = "/tmp/redfish/" + host
        self.create_directory_and_file()

    def create_directory_and_file(self):
        if not os.path.exists("/tmp/redfish"):
            os.makedirs("/tmp/redfish")
        
        if not os.path.exists(self.auth_file):
            with open(self.auth_file, 'w') as file:
                file.write("")
                self.Token = ""
        else:
            self.Token = self.read().strip()

    def read(self):
        with open(self.auth_file, 'r') as file:
            return file.read()

    def write(self, auth):
        with open(self.auth_file, 'w') as file:
            file.write(auth)

class PHYSICAL():
    def __init__(self, host_ip, username, password):
        self.authFile = AuthFile(host_ip)
        self.host = "https://" + host_ip
        self.redfish = {}
        self.loader = []
        self.session = requests.Session()
        self.auth = (username, password)
        self.session.headers.update({
            "content-Type": "application/json"
        })

    def _warn(self, stage, error):
        sys.stderr.write("[WARN][redfish.%s] %s\n%s\n" % (stage, error, traceback.format_exc()))

    def _collect(self, stage, collector):
        try:
            collector()
        except Exception as error:
            self._warn(stage, error)

    def run(self):
        # 认证和根接口是采集前置条件，失败时由调用方感知本轮不可采集。
        self.createSession()
        self.getData()
        collectors = (
            ("system", self.system),
            ("processors", self.Processors),
            ("memory", self.Memory),
            ("drives", self.Drives),
            ("fans", self.Fans),
            ("power", self.Power),
            ("pcie", self.PCIeDevices),
            ("temperatures", self.Temperatures),
            ("volumes", self.Volumes),
        )
        for stage, collector in collectors:
            self._collect(stage, collector)

    def requestJson(self, response, returnRes=False):
        if response.status_code not in [200, 201]:
            if isdebug:
                print("code error: %s"% response.content)
            return False, response.content
        try:
            data = response.json()
            if "error" in data:
                if isdebug:
                    print("json error: %s"% data)
                return False, data
            else:
                if isdebug:
                    print("url: %s data: %s"%(response.url, json.dumps(data)))
                if returnRes:
                    return True, response
                else:
                    return True, data
        except Exception as e:
            if isdebug:
                print("Exception: %s"% e)
            return False, None

    def getUri(self, uri, returnRes=False):
        try:
            url = self.host + uri
            headers = {
                "Accept": "*/*",  # 避免服务器返回非标准响应
                "Connection": "close"
            }
            ret = self.session.get(url, verify=False, timeout=requestsTime, headers=headers)
            return self.requestJson(ret, returnRes)
        except Exception as e:
            return False, e

    def postUri(self, uri, data=None, returnRes=False):
        try:
            url = self.host + uri
            res = self.session.post(url, verify=False, timeout=requestsTime, json=data)
            return self.requestJson(res, returnRes)
        except Exception as e:
            return False, e

    def checkToken(self, data):
        if isinstance(data, dict):
            for key, value in data.items():
                if isdebug:
                    print("Token key value: %s:%s"%(key, value))
                if key.lower() == "x-auth-token":
                    return value
                if isinstance(value, (dict, list)):
                    return self.checkToken(value)
        elif isinstance(data, list):
            for item in data:
                return self.checkToken(item)

    def fileAuth(self):
        token = self.authFile.Token
        if isdebug:
            print("文件读取Token: %s"%(token))
        if token:
            self.session.headers.update({"X-Auth-Token": token})
            state, _ = self.getUri("/redfish/v1/SessionService")
            return state
        else:
            return False

    def tokenAuth(self):
        # POST请求通过X-Auth-Token头进行请求get key Members
        params = {"UserName": self.auth[0],"Password": self.auth[1]}
        state, res = self.postUri("/redfish/v1/SessionService/Sessions", data=params, returnRes=True)
        if state:
            headersToken = self.checkToken(dict(res.headers))
            dataToken = self.checkToken(res.json())
            if isdebug:
                print(res.headers)
                print("headersToken", headersToken)
                print(res.content)
                print("dataToken", dataToken)
            if headersToken:
                self.session.headers.update({"X-Auth-Token": headersToken})
                self.authFile.write(headersToken)
                return True
            elif dataToken:
                self.session.headers.update({"X-Auth-Token": dataToken})
                self.authFile.write(dataToken)
                return True
            else:
                return False
        else:
            return False

    def baseAuth(self):
        self.session.auth = self.auth
        state, res = self.getUri("/redfish/v1/SessionService/Sessions", returnRes=True)
        if state:
            headersToken = self.checkToken(dict(res.headers))
            dataToken = self.checkToken(res.json())
            if isdebug:
                print("headersToken", headersToken)
                print("dataToken", dataToken)
            if headersToken:
                self.session.headers.update({"X-Auth-Token": headersToken})
                self.authFile.write(headersToken)
                return True
            elif dataToken:
                self.session.headers.update({"X-Auth-Token": dataToken})
                self.authFile.write(dataToken)
                return True
            else:
                return False
        else:
            return False

    def createSession(self):
        if self.fileAuth():
            return
        elif self.tokenAuth():
            return
        elif self.baseAuth():
            return
        else:
            raise Exception("auth fail")

    def _get_resource(self, uri, stage):
        if not uri:
            self._warn(stage, "missing resource URI")
            return None
        state, data = self.getUri(uri)
        if not state or not isinstance(data, dict):
            self._warn(stage, "resource unavailable: %s" % uri)
            return None
        return data

    def _get_collection(self, refs, stage):
        result = []
        if not isinstance(refs, list):
            return result
        for ref in refs:
            if not isinstance(ref, dict) or not ref.get("@odata.id"):
                self._warn(stage, "resource reference missing @odata.id")
                continue
            data = self._get_resource(ref.get("@odata.id"), stage)
            if data is not None:
                result.append(data)
        return result

    def getMembers(self, uri):
        first = self._get_resource(uri, "members")
        if not first:
            return []
        return self._get_collection(first.get("Members"), "members")

    def getData(self):
        state, api = self.getUri("/redfish/v1")
        if not state or not isinstance(api, dict):
            raise Exception("Redfish root API unavailable")

        chassis_ref = api.get("Chassis")
        chassis_members = self.getMembers(chassis_ref.get("@odata.id")) if isinstance(chassis_ref, dict) else []
        if chassis_members:
            chassis = chassis_members[0]
            if isinstance(chassis.get("Links"), dict):
                chassis.update(chassis["Links"])
            self.redfish["Chassis"] = chassis
            thermal_ref = chassis.get("Thermal")
            thermal = self._get_resource(thermal_ref.get("@odata.id"), "thermal") if isinstance(thermal_ref, dict) else None
            if thermal:
                self.redfish["Fans"] = thermal.get("Fans") or []
                self.redfish["Temperatures"] = thermal.get("Temperatures") or []
            power_ref = chassis.get("Power")
            power = self._get_resource(power_ref.get("@odata.id"), "power") if isinstance(power_ref, dict) else None
            if power:
                self.redfish["Power"] = power
            for key in ("PCIeDevices", "Drives"):
                value = chassis.get(key)
                if isinstance(value, list):
                    self.redfish[key] = self._get_collection(value, key.lower())
                elif isinstance(value, dict):
                    self.redfish[key] = self.getMembers(value.get("@odata.id"))
        else:
            self.redfish["Chassis"] = {}
            self._warn("chassis", "Chassis collection unavailable")

        systems_ref = api.get("Systems")
        systems = self.getMembers(systems_ref.get("@odata.id")) if isinstance(systems_ref, dict) else []
        if not systems:
            self.redfish["Systems"] = {}
            self._warn("systems", "Systems collection unavailable")
            return
        system = systems[0]
        if isinstance(system.get("Links"), dict):
            system.update(system["Links"])
        self.redfish["Systems"] = system
        for key in ("Processors", "Memory"):
            value = system.get(key)
            if isinstance(value, list):
                self.redfish[key] = self._get_collection(value, key.lower())
            elif isinstance(value, dict):
                self.redfish[key] = self.getMembers(value.get("@odata.id"))
                if not self.redfish[key] and isinstance(system.get("links"), dict):
                    link = system["links"].get(key)
                    self.redfish[key] = self.getMembers(link.get("href")) if isinstance(link, dict) else []

        storage_ref = system.get("Storages") or system.get("Storage")
        storages = self.getMembers(storage_ref.get("@odata.id")) if isinstance(storage_ref, dict) else []
        for storage in storages:
            if not isinstance(storage, dict):
                continue
            drives = storage.get("Drives")
            self.redfish.setdefault("Drives", []).extend(self._get_collection(drives, "drives"))
            volumes = storage.get("Volumes")
            if isinstance(volumes, list):
                found = self._get_collection(volumes, "volumes")
            elif isinstance(volumes, dict):
                found = self.getMembers(volumes.get("@odata.id"))
            else:
                found = []
            self.redfish.setdefault("Volumes", []).extend(found or [])

    def getHealth(self, Status):
        Health = Status.get("Health", None)
        if not Health:
            return None
        if Health == "OK":
            return 0
        elif Health == "Critical":
            return 1
        elif Health == "Warning":
            return 2
        else:
            return 3

    def getStatus(self, resource, name):
        if not resource:
            return
        Status = resource.get("Status", {})
        if isinstance(Status, list):
            Status = Status[0] if Status else {}
        if not isinstance(Status, dict):
            self._warn("status", "invalid status for %s" % name)
            return
        if Status.get("State", "") == "Absent":
            return
        if resource.get("@odata.id", None):
            device_id = resource.get("@odata.id").split("/")[-1]
        else:
            device_id = resource.get("name")
        self.loader.append({
            "dims": {
                "device_id": device_id,
                "state": Status.get("State", ""),
            },
            "vals": {
                name + "_status": self.getHealth(Status)
            }
        })

    def system(self):
        if self.redfish.get("Systems", None):
            PowerState = self.redfish["Systems"].get("PowerState", None)
            if PowerState and PowerState == "On":
                PowerState = 0
            else:
                PowerState = 1
            self.loader.append({
                "dims": {},
                "vals": {
                    "power_status": PowerState,
                }
            })

    def Processors(self):
        if "Processors" in self.redfish and self.redfish.get("Processors"):
            for cpu in self.redfish["Processors"]:
                self.getStatus(cpu, "cpu")

    def Memory(self):
        if "Memory" in self.redfish and self.redfish.get("Memory"):
            for mem in self.redfish["Memory"]:
                self.getStatus(mem, "mem")

    def Drives(self):
        if "Drives" in self.redfish and self.redfish.get("Drives"):
            for disk in self.redfish.get("Drives"):
                self.getStatus(disk, "disk")

    def Fans(self):
        if "Fans" in self.redfish and self.redfish.get("Fans"):
            for fan in self.redfish.get("Fans"):
                self.getStatus(fan, "fan")

    def Power(self):
        power = self.redfish.get("Power")
        if isinstance(power, dict):
            for psu in power.get("PowerSupplies") or []:
                self.getStatus(psu, "psu")

    def PCIeDevices(self):
        if self.redfish.get("PCIeDevices"):
            for pcie in self.redfish.get("PCIeDevices") or []:
                self.getStatus(pcie, "pcie")

    def Volumes(self):
        if "Volumes" in self.redfish and self.redfish.get("Volumes"):
            for vol in self.redfish.get("Volumes"):
                self.getStatus(vol, "volumes")

    def Temperatures(self):
        if "Temperatures" in self.redfish and self.redfish.get("Temperatures"):
            for temp in self.redfish.get("Temperatures"):
                if temp:
                    name = temp.get("Name")
                    if name and "dts" in name.lower():
                        continue
                    NonCritical = temp.get("UpperThresholdNonCritical", "")
                    Critical = temp.get("UpperThresholdCritical", "")
                    Fatal = temp.get("UpperThresholdFatal", "")
                    Reading = temp.get("ReadingCelsius", "")
                    if not Reading:
                        continue
                    if Fatal and Reading > Fatal:
                        device_status = 3
                        status_threshold = str(Fatal)
                    elif Critical and Reading > Critical:
                        device_status = 2
                        status_threshold = str(Critical)
                    elif NonCritical and Reading > NonCritical:
                        device_status = 1
                        status_threshold = str(NonCritical)
                    elif not Fatal and not Critical and not NonCritical:
                        device_status = 0
                        status_threshold = ""
                    else:
                        device_status = 0
                        status_threshold = ""
                    self.loader.append({
                        "dims": {
                            "device_id": name,
                            "device_type": temp.get("PhysicalContext", ""),
                            "status_threshold": status_threshold,
                        },
                        "vals": {
                            "temperatures": Reading,
                        }
                    })
                    self.loader.append({
                        "dims": {
                            "device_id": name,
                            "device_type": temp.get("PhysicalContext", ""),
                            "status_threshold": status_threshold,
                        },
                        "vals": {
                            "temperatures_status": device_status,
                        }
                    })

def collect():
    pc = PHYSICAL(host, user, password)
    pc.run()
    return pc.loader


def main():
    result = collect()
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception:
        sys.stdout.write('COLLECT_ERROR:\n')
        traceback.print_exc(file=sys.stdout)
        sys.stdout.flush()
        sys.exit(0)
