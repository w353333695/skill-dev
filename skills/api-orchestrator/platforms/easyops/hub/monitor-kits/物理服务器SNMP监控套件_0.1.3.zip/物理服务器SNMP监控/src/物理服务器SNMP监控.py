#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
ip = os.environ.get("EASYOPS_COLLECTOR_ip")
port = os.environ.get("EASYOPS_COLLECTOR_port")
version = os.environ.get("EASYOPS_COLLECTOR_version")
community = os.environ.get("EASYOPS_COLLECTOR_community")
username = os.environ.get("EASYOPS_COLLECTOR_username")
auth_key = os.environ.get("EASYOPS_COLLECTOR_auth_key")
auth_protocol = os.environ.get("EASYOPS_COLLECTOR_auth_protocol")
priv_key = os.environ.get("EASYOPS_COLLECTOR_priv_key")
priv_protocol = os.environ.get("EASYOPS_COLLECTOR_priv_protocol")

"""物理服务器 SNMP 监控：连通性/品牌识别、标准及私有 MIB 采集、统一指标输出。"""
import os, re, json, subprocess, logging, sys

port = port or os.environ.get("EASYOPS_COLLECTOR_snmpPort") or "161"
version = version or os.environ.get("EASYOPS_COLLECTOR_snmpVersion") or "2c"
community = community or "public"
username = username or os.environ.get("EASYOPS_COLLECTOR_securityName")
auth_key = auth_key or os.environ.get("EASYOPS_COLLECTOR_authKey")
auth_protocol = auth_protocol or os.environ.get("EASYOPS_COLLECTOR_authProtocol")
priv_key = priv_key or os.environ.get("EASYOPS_COLLECTOR_privKey")
priv_protocol = priv_protocol or os.environ.get("EASYOPS_COLLECTOR_privProtocol")
LOG_LEVEL=(os.environ.get("EASYOPS_LOG_LEVEL") or os.environ.get("LOG_LEVEL") or "ERROR").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.ERROR), format="%(asctime)s [%(levelname)s] %(message)s")
LOG=logging.getLogger("physical_server_monitor")

# 配置以 Python 内置 dict/list 保存，便于同一品牌增加多套 MIB 候选。
PROFILES = {
 "huawei": {"roots":["1.3.6.1.4.1.2011.2.235"], "mibs":["HUAWEI-SERVER-IBMC-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.2011.2.235.1.1.5.1.6","1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5"], "mem":["1.3.6.1.4.1.2011.2.235.1.1.7.1.6","1.3.6.1.4.1.2011.5.25.31.1.1.1.1.7"], "temp":["1.3.6.1.4.1.2011.2.235.1.1.20.1.5","1.3.6.1.2.1.99.1.1.1.4"], "fan":["1.3.6.1.4.1.2011.2.235.1.1.21.1.5"], "power":["1.3.6.1.4.1.2011.2.235.1.1.22.1.5"]},
 "dell": {"roots":["1.3.6.1.4.1.674.10892"], "mibs":["IDRAC-MIB-SMIv2","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.674.10892.5.4.1100.30.1.6"], "mem":["1.3.6.1.4.1.674.10892.5.4.1300.30.1.6"], "temp":["1.3.6.1.4.1.674.10892.5.4.700.30.1.6","1.3.6.1.2.1.99.1.1.1.4"], "fan":["1.3.6.1.4.1.674.10892.5.4.600.30.1.6"], "power":["1.3.6.1.4.1.674.10892.5.4.1000.30.1.5"]},
 "lenovo": {"roots":["1.3.6.1.4.1.19046","1.3.6.1.4.1.19046.11"], "mibs":["LENOVO-XCC-MIB","LENOVO-SMI-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.19046.11.1.1.1.1.6"], "mem":["1.3.6.1.4.1.19046.11.1.2.1.1.6"], "temp":["1.3.6.1.2.1.99.1.1.1.4"], "fan":[], "power":[]},
 "inspur": {"roots":["1.3.6.1.4.1.9603"], "mibs":["INSPUR-SERVER-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.9603.1.1.1.1.5"], "mem":["1.3.6.1.4.1.9603.1.1.2.1.5"], "temp":["1.3.6.1.2.1.99.1.1.1.4"], "fan":[], "power":[]},
 "h3c": {"roots":["1.3.6.1.4.1.25506"], "mibs":["HH3C-ENTITY-EXT-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":["1.3.6.1.4.1.25506.2.6.1.1.1.1.6"], "mem":["1.3.6.1.4.1.25506.2.6.1.1.1.1.8"], "temp":["1.3.6.1.4.1.25506.8.35.9.1.3.1.2","1.3.6.1.2.1.99.1.1.1.4"], "fan":["1.3.6.1.4.1.25506.8.35.9.1.1.1.2"], "power":["1.3.6.1.4.1.25506.8.35.9.1.2.1.2"]},
 "baixin": {"roots":["1.3.6.1.4.1.3902"], "mibs":["BAIXIN-SERVER-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":[], "mem":[], "temp":["1.3.6.1.2.1.99.1.1.1.4"], "fan":[], "power":[]},
 "generic": {"roots":[], "mibs":["SNMPv2-MIB","IF-MIB","ENTITY-MIB","ENTITY-SENSOR-MIB"], "cpu":[], "mem":[], "temp":["1.3.6.1.2.1.99.1.1.1.4"], "fan":[], "power":[]}
}
OID={"sysDescr":"1.3.6.1.2.1.1.1.0","sysObjectID":"1.3.6.1.2.1.1.2.0","ifName":"1.3.6.1.2.1.31.1.1.1.1","ifOper":"1.3.6.1.2.1.2.2.1.8","ifAdmin":"1.3.6.1.2.1.2.2.1.7","ifIn":"1.3.6.1.2.1.31.1.1.1.6","ifOut":"1.3.6.1.2.1.31.1.1.1.10","sensorValue":"1.3.6.1.2.1.99.1.1.1.4","sensorName":"1.3.6.1.2.1.99.1.1.1.2","sensorStatus":"1.3.6.1.2.1.99.1.1.1.5","hrSize":"1.3.6.1.2.1.25.2.3.1.5","hrUsed":"1.3.6.1.2.1.25.2.3.1.6","entDescr":"1.3.6.1.2.1.47.1.1.1.1.2"}

def parse(out):
 d={}
 for line in (out or "").splitlines():
  if "=" not in line: continue
  k,v=line.split("=",1); k=k.strip().lstrip("."); v=v.strip()
  if k.startswith("iso."): k="1."+k[4:]
  d[k]=v
 return d

def value(raw):
 if raw is None: return None
 s=str(raw).strip(); s=s.split(":",1)[-1].strip() if ":" in s else s
 if not s or s.lower().startswith(("no such","timeout","unknown")): return None
 m=re.search(r"\((-?\d+(?:\.\d+)?)\)",s) or re.match(r"(-?\d+(?:\.\d+)?)",s)
 if m:
  n=float(m.group(1)); return int(n) if n.is_integer() else n
 return s.strip('"')
class SNMP(object):
 def __init__(self): self.base=["-On","-t","5","-r","1"]
 def args(self):
  v=version.lower(); a=list(self.base)+["-v",v]
  if v=="3":
   a += ["-u",username or "","-l","authPriv"]
   if auth_protocol: a += ["-a",auth_protocol,"-A",auth_key or ""]
   if priv_protocol: a += ["-x",priv_protocol,"-X",priv_key or ""]
  else: a += ["-c",community]
  a += [str(ip)+":"+str(port)]; return a
 def run(self,cmd,oid):
  try: p=subprocess.Popen([cmd]+self.args()+[oid],stdout=subprocess.PIPE,stderr=subprocess.PIPE); out,err=p.communicate()
  except Exception as e: LOG.error("[snmp.%s] %s",cmd,e); return {}
  d=parse(out.decode("utf-8","replace") if not isinstance(out,str) else out); LOG.debug("[snmp.%s] oid=%s rc=%s rows=%s err=%s",cmd,oid,p.returncode,len(d),(err or b"")[:160]); return d
 def get(self,oid):
  d=self.run("snmpget",oid); return value(next(iter(d.values()))) if d else None
 def walk(self,oid): return self.run("snmpwalk",oid)
def vendor(s):
 so=str(s.get("sysObjectID") or ""); desc=str(s.get("sysDescr") or "").lower()
 checks=[("huawei",["2011","huawei"]),("dell",["674.10892","dell","idrac"]),("lenovo",["19046","lenovo","xcc"]),("inspur",["9603","inspur"]),("h3c",["25506","h3c","comware"]),("baixin",["3902","baixin"])]
 for name, keys in checks:
  if any(k in so.lower() or k in desc for k in keys): return name
 return "generic"
def rows(table, base):
 out=[]
 for k,v in table.items():
  if k.startswith(base+"."): out.append((k[len(base)+1:],value(v)))
 return out
def metric(key,val,dim=None):
 if val is None:return None
 return {"dims":({key+"_name":str(dim)} if dim is not None else {}),"vals":{key:val}}
def main():
 if not ip: raise RuntimeError("缺少 EASYOPS_COLLECTOR_ip")
 sn=SNMP(); sysd=sn.get(OID["sysDescr"]); syso=sn.get(OID["sysObjectID"])
 if sysd is None and syso is None: raise RuntimeError("SNMP基础连通性失败：sysDescr/sysObjectID均无响应")
 v=vendor({"sysDescr":sysd,"sysObjectID":syso}); profile=PROFILES[v]; LOG.info("[identify] ip=%s vendor=%s sysObjectID=%s sysDescr=%s",ip,v,syso,sysd)
 result=[]
 for kind,key in [("cpu","snmp.server.cpu.utilization"),("mem","snmp.server.memory.utilization"),("temp","snmp.server.temperature.value"),("fan","snmp.server.fan.status"),("power","snmp.server.power.status")]:
  found=False
  for oid in profile.get(kind,[]) or []:
   data=sn.walk(oid); vals=rows(data,oid)
   if not vals:
    x=sn.get(oid); vals=[("0",x)] if x is not None else []
   for idx,x in vals:
    if x is not None: result.append(metric(key,x,idx)); found=True
   if found: break
  LOG.info("[collect.%s] rows=%s",kind,sum(1 for r in result if key in r.get("vals",{})))
 # ENTITY-SENSOR-MIB 通用温度/风扇/电源兜底
 if not any("snmp.server.temperature.value" in r.get("vals",{}) for r in result):
  vals=rows(sn.walk(OID["sensorValue"]),OID["sensorValue"]); names=dict(rows(sn.walk(OID["sensorName"]),OID["sensorName"]))
  for idx,x in vals:
   if x is not None: result.append(metric("snmp.server.temperature.value",x,value(names.get(idx)) or idx))
 # 磁盘/存储：HOST-RESOURCES-MIB 标准表，按 used/size 计算利用率。
 sizes=dict(rows(sn.walk(OID["hrSize"]),OID["hrSize"])); used=dict(rows(sn.walk(OID["hrUsed"]),OID["hrUsed"]))
 disk_count=0
 for idx,sv in sizes.items():
  try:
   total=float(sv); cur=float(used.get(idx));
   if total > 0 and cur >= 0:
    result.append(metric("snmp.server.disk.utilization",round(cur/total*100.0,2),idx)); disk_count += 1
  except (TypeError,ValueError): pass
 LOG.info("[collect.disk] rows=%s",disk_count)
 # IF-MIB：状态、流量，并将 optical 属性以介质名称保留；光口无法识别时仍输出接口状态
 names=dict(rows(sn.walk(OID["ifName"]),OID["ifName"])); ops=dict(rows(sn.walk(OID["ifOper"]),OID["ifOper"])); admins=dict(rows(sn.walk(OID["ifAdmin"]),OID["ifAdmin"])); ins=dict(rows(sn.walk(OID["ifIn"]),OID["ifIn"])); outs=dict(rows(sn.walk(OID["ifOut"]),OID["ifOut"]))
 for idx,n in names.items():
  dim=value(n) or idx; base=[metric("snmp.server.interface.oper_status",value(ops.get(idx)),dim),metric("snmp.server.interface.admin_status",value(admins.get(idx)),dim),metric("snmp.server.interface.in_octets",value(ins.get(idx)),dim),metric("snmp.server.interface.out_octets",value(outs.get(idx)),dim)]
  if re.search(r"(光|optic|sfp|qsfp|fiber|fc|xe|xge)",str(dim),re.I): base.append(metric("snmp.server.optical.oper_status",value(ops.get(idx)),dim))
  result += [r for r in base if r]
 LOG.info("[collect.interfaces] rows=%s",len(names)); LOG.info("[collect.result] vendor=%s records=%s",v,len(result))
 if not result: raise RuntimeError("SNMP响应成功但未解析出监控指标")
 print("-----BEGIN GATHERING DATA-----"); print(json.dumps(result,ensure_ascii=False)); print("-----END GATHERING DATA-----")
if __name__=="__main__": main()
