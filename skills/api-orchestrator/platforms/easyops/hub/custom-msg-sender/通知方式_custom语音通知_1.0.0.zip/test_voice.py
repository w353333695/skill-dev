#! /usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
import os
import json
import logging
import requests
WEBSOCKET_SERVICE_IP = '127.0.0.1:8157'
ORG = "1888"
EASYOPS_USER = "easyops"
WEBSOCKET_SYSTEM = "msgsender"
TOPIC_PREFIX = "monitor.alert.notify"
def websocket_request(methond, url, **kwargs):
    base_url = "http://{}".format(WEBSOCKET_SERVICE_IP)
    headers = {
        "org": ORG,
        "user": EASYOPS_USER,
        "Content-Type": "application/json"
    }
    _url = "{}{}".format(base_url, url)
    if methond in ["GET", "POST", "DELETE", "PUT"]:
        response = requests.request(method=methond, url=_url, headers=headers, **kwargs)
        if response.status_code == 200:
            response = response.json()
            if response['code'] == 0:
                return response
            else:
                logging.error("请求错误，返回参数为:[{}]".format(response.text))
        else:
            logging.error("请求错误，返回参数为:[{}]".format(response.text))
    else:
        logging.error("错误的请求方式：{}".format(methond))
def need_push(topic):
    _url = '/api/websocket_service/v1/check_subscribe?system={}&topic={}'.format(WEBSOCKET_SYSTEM, topic)
    response = websocket_request("GET", url=_url)
    if response:
        return response["data"].get("isSubbed", False)
    else:
        logging.error("是否有人订阅请求失败-{}".format(response))
def send_msg(topic, payload):
    _url = '/api/websocket_service/v1/message'
    msg = {
        "system": WEBSOCKET_SYSTEM,
        "topic": topic,
        "message": {
            "code": 0,
            "codeExplain": "",
            "error": "",
            "data": payload
        }
    }
    response = websocket_request("POST", url=_url, data=json.dumps(msg))
    if response:
        return response
    else:
        logging.error("发送WEBSOCKET通知失败-{}".format(response))
def generate_topic(user_name):
    return TOPIC_PREFIX + ".{}".format(user_name)
# 框架收到通知的时候，如果命中此通知脚本，则会调起入口函数run:
# 请在run函数补充完通知逻辑即可
#  参数说明：
#  msgdata: {"subject": "通知消息标题", "content":"通知内容"}
#  users: 需要发送的用户信息字典.
#  {
#    "easyops": {
#       "dingding_userid": "",
#       "gender": "女",
#       "instanceId": "5b1fe26669fcc",
#       "name": "easyops",
#       "nickname": "easyops",
#       "state": "valid",
#       "user_email": "88@qq.com",
#       "user_tel": "18212341234"
#    }
#  }
#  cmdb_object_key:  cmdb用户模型字段；如user_email、dingding_userid、wework_userid等
def run(msg_data, users, cmdb_object_key='name', **kwargs):
    topics = []
    for user_name, information in users.iteritems():
        topic = generate_topic(user_name)
        if need_push(topic):
            topics.append(topic)
    extraData = msg_data.get("extraData", {})
    payload = {
        "time": extraData.get("time", 0),
        "level": extraData.get("level", ""),
        "target": extraData.get("target", ""),
        "eventId": extraData.get("eventId", ""),
        "content": extraData.get("originContent", ""),
        "originContent": extraData.get("originContent", ""),
        "voice": True
    }
    logging.info('will send msg to websocket topic %s' % (','.join(topics)))
    for topic in topics:
        send_msg(topic, payload)
    return []
