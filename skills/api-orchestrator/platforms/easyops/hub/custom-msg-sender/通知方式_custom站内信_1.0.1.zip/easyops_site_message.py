#! /usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-

import ens_api
import logging
import requests
import subprocess


SRC_NAME = "logic.msgsender"
DST_NAME = "logic.sys_setting"


def do_cmd(command, shell=False):
    p = subprocess.Popen(
        command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=shell
    )
    msg, err = p.communicate()
    return p.returncode, msg, err


def get_common_org():
    code, org, err = do_cmd(
        "/usr/local/easyops/deploy_init/tools/get_env.py common org", shell=True
    )
    if code == 0:
        return int(org.strip())
    else:
        raise Exception(
            "run command fail,code: {}, output: {}, msg: {}".format(code, org, err)
        )


def run(msg_data, users, cmdb_object_key="name", **kwargs):
    session_id, ip, port = ens_api.get_service_by_name(SRC_NAME, DST_NAME)
    if session_id < 0:
        logging.error(
            "easy name service error, src_name={} dst_name={}, session_id={}".format(
                SRC_NAME, DST_NAME, session_id
            )
        )
        raise ens_api.EnsError(
            session_id, "dst_name({}), session_id({}) < 0".format(DST_NAME, session_id)
        )
    logging.info("sending site message ...")
    receivers = []
    for user in users:
        receivers.append(user)
    try:
        response = requests.post(
            url="http://{}:{}/api/sys_setting/v1/site_msg".format(ip, port),
            json={
                "title": msg_data.get("subject", ""),
                "content": msg_data.get("content", ""),
                "source": "合规性检查",
                "extInfo": {},
                "receivers": receivers,
            },
            headers={
                "org": get_common_org(),
                "user": "defaultUser",
            },
        )
    except Exception:
        logging.exception("send site message request error")
        raise

    if response.status_code != 200:
        logging.error(
            "send site message http error, status_code={}, response={}".format(
                response.status_code, response.text
            )
        )
        raise Exception(
            "send site message http error, status_code={}".format(
                response.status_code
            )
        )

    try:
        result = response.json()
    except ValueError:
        logging.error(
            "send site message response json error, response={}".format(response.text)
        )
        raise

    if result["code"] != 0:
        logging.error(
            "send site message api error, code={}, response={}".format(
                result["code"], result
            )
        )
        raise Exception(
            "send site message api error, code={}".format(result["code"])
        )
    logging.info("send site message successfully")
    return receivers
