import json
import time
import traceback
try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen


def decode_json(value, expected_type):
    if isinstance(value, expected_type):
        return value
    if isinstance(value, (str, bytes)) or type(value).__name__ == "unicode":
        decoded = json.loads(value)
        if isinstance(decoded, expected_type):
            return decoded
    raise ValueError(u"JSON 参数类型不正确: %s" % expected_type.__name__)


def platform_request(service_name, path, body=None):
    address = globals().get(service_name)
    if not address:
        raise RuntimeError(u"缺少平台内置服务地址: %s" % service_name)
    base_url = str(address).rstrip("/")
    if not base_url.startswith(("http://", "https://")):
        base_url = "http://" + base_url
    headers = {"org": str(EASYOPS_ORG), "user": str(EASYOPS_USER), "Content-Type": "application/json"}
    payload = None if body is None else json.dumps(body).encode("utf-8")
    response = urlopen(Request(base_url + path, data=payload, headers=headers), timeout=30)
    try:
        result = json.loads(response.read().decode("utf-8"))
    finally:
        response.close()
    if result.get("code") != 0:
        raise RuntimeError(u"平台接口业务失败 %s: %s" % (path, result.get("error") or result.get("msg") or result.get("message")))
    return result.get("data")


def await_completion(service_name, path, status_field, success_status, timeout_seconds=600):
    deadline = time.time() + timeout_seconds
    terminal_failures = ("failed", "error", "terminated", "cancelled", "canceled", "timeout", "partial_success", "partialSuccess")
    while time.time() < deadline:
        data = platform_request(service_name, path)
        status = data.get(status_field)
        if status == success_status:
            return data
        if status in terminal_failures:
            raise RuntimeError(u"任务失败 %s: %s" % (path, status))
        time.sleep(2)
    raise RuntimeError(u"等待任务超时（%s 秒）: %s" % (timeout_seconds, path))


def execute_installation():
    hosts = decode_json(agents_json, list)
    if not hosts:
        raise ValueError("安装执行对象不能为空")
    extra_inputs = decode_json(install_tool_inputs or {}, dict)
    tool_inputs = dict(extra_inputs)
    tool_inputs.update({"@agents": hosts, "install_path": install_path})
    task = platform_request("EASYOPS_TOOLS_HOST", "/tools/execution", {
        "toolId": install_tool_id, "vId": "$latest_production", "inputs": tool_inputs, "needNotify": "false"})
    execution_id = task["execId"]
    PutStr("install_exec_id", execution_id)
    print(u"安装工具任务: %s" % execution_id)
    await_completion("EASYOPS_TOOLS_HOST", "/tools/execution/status/" + execution_id, "totalStatus", "success")
    result = platform_request("EASYOPS_TOOLS_HOST", "/tools/execution/result/" + execution_id)
    if result.get("totalStatus") != "success":
        raise RuntimeError("安装工具结果不是成功状态")
    PutStr("installation", "success")
    print(u"安装工具执行成功，生产版本: %s" % result.get("vId", ""))


try:
    execute_installation()
except Exception:
    print("[execute_installation] " + traceback.format_exc())
    raise