import os
import json
import signal
import subprocess
import tempfile
import threading
import traceback

def check_installation():
    process = str(process_name or "").strip()
    port_text = str(process_port or "").strip()
    command = str(version_command or "").strip()
    expected = str(expected_version or "")
    results = {"process": "skipped", "port": "skipped", "version": "skipped"}
    matching_pids = []
    if process:
        for entry in os.listdir("/proc"):
            if not entry.isdigit():
                continue
            comm_path = "/proc/%s/comm" % entry
            if not os.path.exists(comm_path):
                continue
            try:
                with open(comm_path) as handle:
                    if handle.read().strip() == process:
                        matching_pids.append(entry)
            except (IOError, OSError):
                print("[check_installation] 进程读取竞态: " + traceback.format_exc())
        if not matching_pids:
            raise RuntimeError("未找到精确进程名: %s" % process)
        results["process"] = "passed"
    if port_text:
        port = int(port_text)
        if not 1 <= port <= 65535:
            raise ValueError("端口必须介于 1 至 65535")
        socket_inodes = set()
        for protocol in ("tcp", "tcp6", "udp", "udp6"):
            table = "/proc/net/" + protocol
            if not os.path.exists(table):
                continue
            with open(table) as handle:
                for line in handle.readlines()[1:]:
                    columns = line.split()
                    if len(columns) > 9 and int(columns[1].split(":")[-1], 16) == port:
                        if columns[3] == ("0A" if protocol.startswith("tcp") else "07"):
                            socket_inodes.add(columns[9])
        if not socket_inodes:
            raise RuntimeError("未发现监听端口: %s" % port)
        if process:
            owned = False
            for pid in matching_pids:
                descriptor_path = "/proc/%s/fd" % pid
                if not os.path.isdir(descriptor_path):
                    continue
                for descriptor in os.listdir(descriptor_path):
                    try:
                        link = os.readlink(descriptor_path + "/" + descriptor)
                        if link.startswith("socket:[") and link[8:-1] in socket_inodes:
                            owned = True
                    except (IOError, OSError):
                        print("[check_installation] 文件描述符读取竞态: " + traceback.format_exc())
            if not owned:
                raise RuntimeError("端口不属于指定进程: %s:%s" % (process, port))
        results["port"] = "passed"
    if command and expected:
        with tempfile.TemporaryFile() as output:
            child = subprocess.Popen(command, shell=True, executable="/bin/sh", stdout=output, stderr=subprocess.STDOUT, preexec_fn=os.setsid)
            timed_out = []
            def terminate_command():
                timed_out.append(True)
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except OSError:
                    print("[terminate_command] " + traceback.format_exc())
            timer = threading.Timer(30, terminate_command)
            timer.start()
            try:
                return_code = child.wait()
            finally:
                timer.cancel()
            output.seek(0)
            text = output.read(65536).decode("utf-8", "replace")
        if timed_out:
            raise RuntimeError("版本命令执行超过 30 秒")
        if return_code != 0:
            raise RuntimeError("版本命令退出码不是 0: %s" % return_code)
        if expected not in text:
            raise RuntimeError("版本输出不包含期待字符串: %s" % expected)
        results["version"] = "passed"
    PutStr("verification", json.dumps(results, ensure_ascii=False))
    print(json.dumps(results, ensure_ascii=False))

try:
    check_installation()
except Exception:
    print("[check_installation] " + traceback.format_exc())
    raise