import json
import time
import traceback
try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen


def decode_json(value, expected_type):
    if isinstance(value, expected_type):
        return value
    if isinstance(value, (str, bytes)) or type(value).__name__ == "unicode":
        decoded = json.loads(value)
        if isinstance(decoded, expected_type):
            return decoded
    raise ValueError(u"JSON 参数类型不正确: %s" % expected_type.__name__)


def to_unicode(value):
    if isinstance(value, bytes) and not isinstance(value, type(u"")):
        return value.decode("utf-8", "replace")
    return value if type(value).__name__ == "unicode" else u"%s" % value


def platform_request(service_name, path, body=None):
    address = globals().get(service_name)
    if not address:
        raise RuntimeError(u"缺少平台内置服务地址: %s" % service_name)
    base_url = str(address).rstrip("/")
    if not base_url.startswith(("http://", "https://")):
        base_url = "http://" + base_url
    headers = {"org": str(EASYOPS_ORG), "user": str(EASYOPS_USER), "Content-Type": "application/json"}
    payload = None if body is None else json.dumps(body).encode("utf-8")
    response = urlopen(Request(base_url + path, data=payload, headers=headers), timeout=30)
    try:
        result = json.loads(response.read().decode("utf-8"))
    finally:
        response.close()
    if result.get("code") != 0:
        raise RuntimeError(u"平台接口业务失败 %s: %s" % (path, result.get("error") or result.get("msg") or result.get("message")))
    return result.get("data")


def await_completion(service_name, path, status_field, success_status, timeout_seconds=600):
    deadline = time.time() + timeout_seconds
    terminal_failures = ("failed", "error", "terminated", "cancelled", "canceled", "timeout", "partial_success", "partialSuccess")
    while time.time() < deadline:
        data = platform_request(service_name, path)
        status = data.get(status_field)
        if status == success_status:
            return data
        if status in terminal_failures:
            raise RuntimeError(u"任务失败 %s: %s" % (path, status))
        time.sleep(2)
    raise RuntimeError(u"等待任务超时（%s 秒）: %s" % (timeout_seconds, path))


def last_log_lines(value, count=20):
    """把平台返回的字符串/主机日志结构压成最后 count 行。"""
    chunks = []
    if isinstance(value, dict):
        for host, message in value.items():
            chunks.append(u"[%s]\n%s" % (to_unicode(host), to_unicode(message or "")))
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, dict):
                chunks.append(to_unicode(json.dumps(item, ensure_ascii=False)))
            else:
                chunks.append(to_unicode(item))
    elif value is not None:
        chunks.append(to_unicode(value))
    text = "\n".join(chunks)
    return "\n".join(text.splitlines()[-count:])


def put_failure_details(prefix, task_id, log_text, url):
    """失败时尽力输出可定位信息；日志接口异常不能覆盖原始失败。"""
    try:
        PutStr(prefix + "_url", url)
        PutStr(prefix + "_log_tail", last_log_lines(log_text, 20) or "（平台未返回日志）")
    except Exception:
        print("[%s] 输出失败详情异常: %s" % (prefix, traceback.format_exc()))


def failure_with_details(prefix, task_id, log_text, url, original_error):
    tail = last_log_lines(log_text, 20) or u"（平台未返回日志）"
    put_failure_details(prefix, task_id, tail, url)
    return RuntimeError(u"%s失败\n任务链接: %s\n日志最后20行:\n%s\n原始错误: %s" % (to_unicode(prefix), to_unicode(url), to_unicode(tail), to_unicode(original_error)))


def distribute_package():
    destination = str(install_path or "").strip()
    if not destination.startswith("/") or destination == "/" or ".." in destination.split("/"):
        raise ValueError("分发位置必须是非根目录的绝对路径，且不能包含 ..")
    selected_hosts = decode_json(agents, list)
    host_ids = []
    for selected in selected_hosts:
        instance_id = selected.get("instanceId") if isinstance(selected, dict) else selected
        if not instance_id:
            raise ValueError("目标主机缺少 instanceId")
        if instance_id not in host_ids:
            host_ids.append(instance_id)
    if not host_ids or len(host_ids) > 3000:
        raise ValueError("目标主机数量必须在 1 至 3000 之间")
    host_result = platform_request("EASYOPS_CMDB_HOST", "/object/HOST/instance/_search", {
        "query": {"instanceId": {"$in": host_ids}},
        "fields": {"instanceId": True, "ip": True, "_uuid": True},
        "page": 1, "page_size": 3000})
    hosts = host_result["list"]
    if set(host["instanceId"] for host in hosts) != set(host_ids):
        raise RuntimeError("目标主机解析不完整，终止分发")
    if any(not host.get("ip") or not host.get("_uuid") for host in hosts):
        raise RuntimeError("目标主机缺少 IP 或分发 UUID")
    versions = platform_request("EASYOPS_CMDB_HOST", "/object/_ARTIFACT_VERSION/instance/_search", {
        "query": {"instanceId": package_version},
        "fields": {"name": True, "description": True, "versionName": True, "_ARTIFACT.name": True, "_ARTIFACT.type": True},
        "page": 1, "page_size": 1})["list"]
    if len(versions) != 1:
        raise RuntimeError("找不到所选文件包版本")
    version = versions[0]
    artifacts = version.get("_ARTIFACT") or []
    if isinstance(artifacts, dict):
        artifacts = [artifacts]
    if len(artifacts) != 1 or artifacts[0].get("type") != "filepkg":
        raise ValueError(u"所选版本必须关联唯一文件包，解析结果: %s" % json.dumps(artifacts))
    task = platform_request("EASYOPS_EASYFLOW_HOST", "/deployTask", {
        "packageList": [{"packageId": artifacts[0]["name"], "versionId": version["name"], "type": "4", "installPath": destination, "platform": "linux"}],
        "targetList": [{"targetId": host["_uuid"]} for host in hosts]})
    task_id = task["taskId"]
    PutStr("deploy_task_id", task_id)
    task_url = "https://192.168.110.24/next/file-distrubute/task/%s?type=fileDelivery&event=deploy" % task_id
    print(u"文件分发任务: %s" % task_id)
    try:
        await_completion("EASYOPS_EASYFLOW_HOST", "/deployTask/" + task_id, "status", "ok")
    except Exception as error:
        log_text = ""
        try:
            detail = platform_request("EASYOPS_EASYFLOW_HOST", "/deployTask/" + task_id)
            log_text = [item.get("msg", "") for item in (detail.get("targetList") or []) if isinstance(item, dict)]
        except Exception:
            log_text = "获取部署任务详情失败: %s" % traceback.format_exc()
        raise failure_with_details("文件分发", task_id, log_text, task_url, error)
    PutStr("agents_json", json.dumps(hosts))
    PutStr("agent_ips", " ".join(host["ip"] for host in hosts))
    PutStr("package_label", u"%s / %s" % (version.get("description", ""), version.get("versionName", "")))
    print(u"文件分发完成，目标主机数: %s" % len(hosts))


try:
    distribute_package()
except Exception:
    print("[distribute_package] " + traceback.format_exc())
    raise