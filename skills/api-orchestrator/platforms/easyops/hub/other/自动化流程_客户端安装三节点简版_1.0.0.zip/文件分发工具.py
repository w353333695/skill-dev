import json
import time
import traceback
try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen


def decode_json(value, expected_type):
    if isinstance(value, expected_type):
        return value
    if isinstance(value, (str, bytes)) or type(value).__name__ == "unicode":
        decoded = json.loads(value)
        if isinstance(decoded, expected_type):
            return decoded
    raise ValueError(u"JSON 参数类型不正确: %s" % expected_type.__name__)


def platform_request(service_name, path, body=None):
    address = globals().get(service_name)
    if not address:
        raise RuntimeError(u"缺少平台内置服务地址: %s" % service_name)
    base_url = str(address).rstrip("/")
    if not base_url.startswith(("http://", "https://")):
        base_url = "http://" + base_url
    headers = {"org": str(EASYOPS_ORG), "user": str(EASYOPS_USER), "Content-Type": "application/json"}
    payload = None if body is None else json.dumps(body).encode("utf-8")
    response = urlopen(Request(base_url + path, data=payload, headers=headers), timeout=30)
    try:
        result = json.loads(response.read().decode("utf-8"))
    finally:
        response.close()
    if result.get("code") != 0:
        raise RuntimeError(u"平台接口业务失败 %s: %s" % (path, result.get("error") or result.get("msg") or result.get("message")))
    return result.get("data")


def await_completion(service_name, path, status_field, success_status, timeout_seconds=600):
    deadline = time.time() + timeout_seconds
    terminal_failures = ("failed", "error", "terminated", "cancelled", "canceled", "timeout", "partial_success", "partialSuccess")
    while time.time() < deadline:
        data = platform_request(service_name, path)
        status = data.get(status_field)
        if status == success_status:
            return data
        if status in terminal_failures:
            raise RuntimeError(u"任务失败 %s: %s" % (path, status))
        time.sleep(2)
    raise RuntimeError(u"等待任务超时（%s 秒）: %s" % (timeout_seconds, path))


def distribute_package():
    destination = str(install_path or "").strip()
    if not destination.startswith("/") or destination == "/" or ".." in destination.split("/"):
        raise ValueError("分发位置必须是非根目录的绝对路径，且不能包含 ..")
    selected_hosts = decode_json(agents, list)
    host_ids = []
    for selected in selected_hosts:
        instance_id = selected.get("instanceId") if isinstance(selected, dict) else selected
        if not instance_id:
            raise ValueError("目标主机缺少 instanceId")
        if instance_id not in host_ids:
            host_ids.append(instance_id)
    if not host_ids or len(host_ids) > 3000:
        raise ValueError("目标主机数量必须在 1 至 3000 之间")
    host_result = platform_request("EASYOPS_CMDB_HOST", "/object/HOST/instance/_search", {
        "query": {"instanceId": {"$in": host_ids}},
        "fields": {"instanceId": True, "ip": True, "_uuid": True},
        "page": 1, "page_size": 3000})
    hosts = host_result["list"]
    if set(host["instanceId"] for host in hosts) != set(host_ids):
        raise RuntimeError("目标主机解析不完整，终止分发")
    if any(not host.get("ip") or not host.get("_uuid") for host in hosts):
        raise RuntimeError("目标主机缺少 IP 或分发 UUID")
    versions = platform_request("EASYOPS_CMDB_HOST", "/object/_ARTIFACT_VERSION/instance/_search", {
        "query": {"instanceId": package_version},
        "fields": {"name": True, "description": True, "versionName": True, "_ARTIFACT.name": True, "_ARTIFACT.type": True},
        "page": 1, "page_size": 1})["list"]
    if len(versions) != 1:
        raise RuntimeError("找不到所选文件包版本")
    version = versions[0]
    artifacts = version.get("_ARTIFACT") or []
    if isinstance(artifacts, dict):
        artifacts = [artifacts]
    if len(artifacts) != 1 or artifacts[0].get("type") != "filepkg":
        raise ValueError(u"所选版本必须关联唯一文件包，解析结果: %s" % json.dumps(artifacts))
    task = platform_request("EASYOPS_EASYFLOW_HOST", "/deployTask", {
        "packageList": [{"packageId": artifacts[0]["name"], "versionId": version["name"], "type": "4", "installPath": destination, "platform": "linux"}],
        "targetList": [{"targetId": host["_uuid"]} for host in hosts]})
    task_id = task["taskId"]
    PutStr("deploy_task_id", task_id)
    print(u"文件分发任务: %s" % task_id)
    await_completion("EASYOPS_EASYFLOW_HOST", "/deployTask/" + task_id, "status", "ok")
    PutStr("agents_json", json.dumps(hosts))
    PutStr("agent_ips", " ".join(host["ip"] for host in hosts))
    PutStr("package_label", u"%s / %s" % (version.get("description", ""), version.get("versionName", "")))
    print(u"文件分发完成，目标主机数: %s" % len(hosts))


try:
    distribute_package()
except Exception:
    print("[distribute_package] " + traceback.format_exc())
    raise