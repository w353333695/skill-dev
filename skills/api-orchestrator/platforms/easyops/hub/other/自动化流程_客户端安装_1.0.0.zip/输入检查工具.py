if not str(install_path or "").startswith("/"):
    raise ValueError("安装包分发位置必须是绝对路径")
print("输入检查通过；后续节点读取 CMDB 并执行分发。")
PutStr("ready", "true")