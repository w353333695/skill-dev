# EasyOps 平台集群部署清单说明（cluster-1 · 单节点配置）

> 本清单基于 `cluster-1.yaml` 生成，描述 **单节点（1 台）集群**的组件部署拓扑。
>
> **交付说明**：组件表中「部署节点」列填写的是**节点 id**（host1、host2…），与具体 IP 解耦。交付不同项目时，**只需在下方「节点清单」中把各节点 id 对应的 IP 占位 `<待填写>` 替换为实际 IP，组件表无需任何改动**。

## 节点清单

| 节点 id | IP | 部署组件数 | 主要承载说明 |
|---------|----|-----------|--------------|
| host1 | `<待填写>` | 153 | 主控节点：全部资源包与数据初始化、图/列式/对象存储、缓存/消息/关系库、数据初始化脚本、接入网关、前端组件(30)、业务后端服务 |

**部署分布概览：**

- **全部节点部署**：153 个组件。

---

## 一、中间件与基础组件

注：含运行环境（JDK/Python）、Web 服务（Nginx）、缓存与消息（Redis/Kafka/ZooKeeper）、对象存储（SeaweedFS）等。

| 名称 | 类型 | 版本 | 开发语言 | 开放端口 | 部署路径 | 部署节点 | 用途说明 |
|------|------|------|------|------|------|------|------|
| jdk | 中间件 | 11.0.28 | java | - | /usr/local/easyops/jdk | 全部节点 | Java运行环境 |
| nginx | 中间件 | 1.26.3 | c | - | /usr/local/easyops/nginx | 全部节点 | 80/443：前端用户访问；4200：安装程序页面访问；1888：控制台管理页面；8820/5511：与Agent端通信端口，仅用于Proxy的Nginx |
| python3 | 中间件 | 3.x | python | - | /usr/local/easyops/python3 | 全部节点 | Python3 运行环境（平台组件依赖） |
| python_download | 中间件 | 2.7.18 | python | - | /usr/local/easyops/python_download | 全部节点 | 提供python安装包 |
| python_linux | 中间件 | 2.7.x | python | - | /usr/local/easyops/python_linux | 全部节点 | Linux 平台 Python 基础运行包 |
| redis | 缓存 | 7.4.6 | c | 6379 | /usr/local/easyops/redis | 全部节点 | 各类后台组件的数据缓存 |
| seaweedfs | 数据库 | 3.64 | go | 9336 | /usr/local/easyops/seaweedfs | 全部节点 | 支持全平台的对象存储，如图片、附件等 |

## 二、自研数据库

| 名称 | 类型 | 版本 | 开发语言 | 开放端口 | 部署路径 | 部署节点 | 用途说明 |
|------|------|------|------|------|------|------|------|
| easy_core | 图数据库 | 1.50.x | rust | 8070,8098 | /usr/local/easyops/easy_core | 全部节点 | 存储元数据，包括cmdb模型数据、实例数据和一些业务定义的数据（如指标定义），还有平台的基础数据（如名字服务、平台自身配置中心数据） |

## 三、后端组件

| 名称 | 类型 | 开发语言 | 开放端口 | 部署路径 | 部署节点 | 用途说明 |
|------|------|------|------|------|------|------|
| admin | 后端逻辑 | python | 8082 | /usr/local/easyops/admin | 全部节点 | 名字服务接口服务，已废弃 |
| agent_admin | 后端逻辑 | go | 8102 | /usr/local/easyops/agent_admin | 全部节点 | agent管理的后台服务 |
| agent_download | 数据脚本 | shell | - | /usr/local/easyops/agent_download | 全部节点 | agent的安装包 |
| aggregate_metric_process | 后端逻辑 | rust | 8299 | /usr/local/easyops/aggregate_metric_process | 全部节点 | 指标聚合流组件 |
| alert_metric_process | 后端逻辑 | rust | 8297 | /usr/local/easyops/alert_metric_process | 全部节点 | 告警流组件 |
| api_gateway | 后端逻辑 | go | 8107,8104,8109,80 | /usr/local/easyops/api_gateway | 全部节点 | 前端api接入网关 |
| apm_metric_process | 后端逻辑 | rust | 8298 | /usr/local/easyops/apm_metric_process | 全部节点 | apm trace数据处理流组件 |
| app_deploy_service | 后端逻辑 | go | 8270 | /usr/local/easyops/app_deploy_service | 全部节点 | 双态部署的后台服务 |
| appconfig | 后端逻辑 | go | 8100 | /usr/local/easyops/appconfig | 全部节点 | 应用配置中心的后台服务 |
| appconfig_init | 数据脚本 | python,shell | - | /usr/local/easyops/appconfig_init | 全部节点 | 应用配置中心的初始化服务 |
| auto_detect | 后端逻辑 | python | 8084 | /usr/local/easyops/auto_detect | 全部节点 | 安装agent后主机自动录入后台服务 |
| brick_next | 前端逻辑 | typescript | 80 | /usr/local/easyops/brick_next | 全部节点 | 前端低代码js框架库 |
| brick_next_v3 | 前端逻辑 | typescript | 80 | /usr/local/easyops/brick_next_v3 | 全部节点 | 前端低代码js v3框架库 |
| cmdb_mobile | 前端逻辑 | typescript,html | - | /usr/local/easyops/cmdb_mobile | 全部节点 | cmdb移动端前端组件 |
| cmdb_service | 后端逻辑 | go | 8079 | /usr/local/easyops/cmdb_service | 全部节点 | cmdb_service |
| code_service | 后端逻辑 | go | 8267 | /usr/local/easyops/code_service | 全部节点 | 低代码对接git的后台服务 |
| deploy_init | 后端逻辑 | python,shell | - | /usr/local/easyops/deploy_init | 全部节点 | 全平台环境配置初始化脚本 |
| deploy_init_update | 后端逻辑 | python,shell | - | /usr/local/easyops/deploy_init_update | 全部节点 | 全平台环境配置初始化脚本，升级组件 |
| easy_command | 后端逻辑 | go | 8060 | /usr/local/easyops/easy_command | 全部节点 | 命令通道的后台服务 |
| easy_framework | 后端逻辑 | go | - | /usr/local/easyops/easy_framework | 全部节点 | easyops framework，即将废弃，目前提供给service_registration使用 |
| easyadmin | 数据脚本 | python | - | /usr/local/easyops/easyadmin | 全部节点 | 用于守护制品部署实例，出问题可自动拉起 |
| easyhub_client | 后端逻辑 | go | 8212 | /usr/local/easyops/easyhub_client | 全部节点 | easyhub客户端的后台服务 |
| easyhub_server | 后端逻辑 | go | 8213 | /usr/local/easyops/easyhub_server | 全部节点 | easyhub服务端的后台服务 |
| easyops_exporter | 后端逻辑 | go | 8197,8200 | /usr/local/easyops/easyops_exporter | 全部节点 | 控制台的采集工具 |
| easyops_init | 数据脚本 | python,shell | - | /usr/local/easyops/easyops_init | 全部节点 | 平台安装完成后完成org及用户注册 |
| emergency_ms | 后端逻辑 | go | 8290 | /usr/local/easyops/emergency_ms | 全部节点 | 应急管理后台 |
| ens_client | 后端逻辑 | rust | - | /usr/local/easyops/ens_client | 全部节点 | 名字服务后台服务 |
| ens_sdk_rs | 数据脚本 | rust | - | /usr/local/easyops/ens_sdk_rs | 全部节点 | 名字服务的sdk |
| form_builder_service | 后端逻辑 | go | 8260 | /usr/local/easyops/form_builder_service | 全部节点 | form-builder后台服务 |
| gateway | 后端逻辑 | go | 5513 | /usr/local/easyops/gateway | 全部节点 | agent的命令通道接入网关 |
| hyper-deploy-PF | 后端逻辑 | rust | 12030 | /usr/local/easyops/pfs/hyper-deploy-PF | 全部节点 | 双态部署的后台服务 |
| idc_service | 后端逻辑 | go | 8306 | /usr/local/easyops/idc_service | 全部节点 | 给数据中心产品提供后台API服务 |
| idcmanager | 后端逻辑 | go | 8118 | /usr/local/easyops/idcmanager | 全部节点 | 机房机柜管理 |
| install_agent | 数据脚本 | python,shell | - | /usr/local/easyops/install_agent | 全部节点 | 平台安装完成后触发agent安装 |
| itsm-PF | 后端逻辑 | rust | 16014 | /usr/local/easyops/pfs/itsm-PF | 全部节点 | itsm编排接口后台服务 |
| micro_app_standalone_service | 后端逻辑 | go | 8259 | /usr/local/easyops/micro_app_standalone_service | 全部节点 | 微应用的后台服务（独立打包形态） |
| mock_server | 后端逻辑 | go | 8245,8247 | /usr/local/easyops/mock_server | 全部节点 | mock服务，用于低代码 |
| model_resource_tool | 后端逻辑 | go | 8246 | /usr/local/easyops/model_resource_tool | 全部节点 | 后台-M包的服务组件，提供统一的脚步处理-M包的内容 |
| msgsender | 后端逻辑 | python | 8095 | /usr/local/easyops/msgsender | 全部节点 | 通知通道的后台服务 |
| na_package_service | 后端逻辑 | go | 8302 | /usr/local/easyops/na_package_service | 全部节点 | 前端NA包服务组件，提供统一的脚本处理-NA包 |
| next_console_service | 后端逻辑 | go | 8182,8183,8188 | /usr/local/easyops/next_console_service | 全部节点 | 控制台的后台服务 |
| next_docs_website | 前端逻辑 | html | - | /usr/local/easyops/next_docs_website | 全部节点 | 低代码的技术文档 |
| next_tunnel_server | 后端逻辑 | go | - | /usr/local/easyops/next_tunnel_server | 全部节点 | next 控制台隧道服务 |
| notify | 后端逻辑 | go | 8069,8315 | /usr/local/easyops/notify | 全部节点 | 变更通知的后台服务 |
| offline_components | 数据脚本 | python,shell | - | /usr/local/easyops/offline_components | 全部节点 | 下线组件清单，根据配置的下线组件清单执行uninstall脚本 |
| one_ticket_service | 后端逻辑 | go | 8281 | /usr/local/easyops/one_ticket_service | 全部节点 | 双态部署发布单的后台服务 |
| open_platform-PF | 后端逻辑 | rust | 12101 | /usr/local/easyops/pfs/open_platform-PF | 全部节点 | 开放平台的后端逻辑 |
| permission_service | 后端逻辑 | go | 8269 | /usr/local/easyops/permission_service | 全部节点 | 权限的后台服务 |
| php_license | 数据脚本 | shell | - | /usr/local/easyops/php_license | 全部节点 | license文件 |
| py_script_runner | 后端逻辑 | python | 8319 | /usr/local/easyops/py_script_runner | 全部节点 | ITSM的工具执行框架 |
| rapid_flowable | 后端逻辑 | java | - | /usr/local/easyops/rapid_flowable | 全部节点 | flowable 工作流引擎（ITSC 依赖） |
| receiver | 后端逻辑 | rust | 8820 | /usr/local/easyops/receiver | 全部节点 | 数据通道的数据网关服务 |
| resource_package_tools | 后端逻辑 | go | 8126 | /usr/local/easyops/resource_package_tools | 全部节点 | 数据脚本-R包的服务组件，提供统一的脚本处理-R包的内容 |
| secret_service | 后端逻辑 | go | 8154 | /usr/local/easyops/secret_service | 全部节点 | 密钥管理的后台服务 |
| service_registration | 后端逻辑 | python | - | /usr/local/easyops/service_registration | 全部节点 | 名字服务注册及注销服务 |
| sso_adapter | 后端逻辑 | python | 8211 | /usr/local/easyops/sso_adapter | 全部节点 | sso的对接服务，可用插件的形式定制化开发客户现场的sso对接脚本 |
| state_workflow_service | 后端逻辑 | go | 8141 | /usr/local/easyops/state_workflow_service | 全部节点 | 敏捷的工作流后台服务 |
| sys_setting | 后端逻辑 | go | 8271 | /usr/local/easyops/sys_setting | 全部节点 | 系统管理的后台服务 |
| user_service | 后端逻辑 | go | 8111 | /usr/local/easyops/user_service | 全部节点 | 用户管理后台服务 |
| workflow_service | 后端逻辑 | go | 8307 | /usr/local/easyops/workflow_service | 全部节点 | 工作流通用服务组件 |

## 四、前端组件

注：`*-NA` 为独立前端应用，`*-NB` 为前端公共依赖库。

| 名称 | 开发语言 | 部署路径 | 部署节点 | 应用模块 | 用途说明 |
|------|------|------|------|------|------|
| autoops-union-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/autoops-union-standalone-NA | 全部节点 | EasyAutoOps | 前端页面 |
| base-layout-NB | typescript | /usr/local/easyops/bricks/base-layout-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| base-layout-v3-NB | typescript | /usr/local/easyops/bricks/base-layout-v3-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| basic-NB | typescript | /usr/local/easyops/bricks/basic-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| chart-v2-NB | typescript | /usr/local/easyops/bricks/chart-v2-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| cmdb-union-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/cmdb-union-standalone-NA | 全部节点 | EasyCMDB | 前端页面 |
| code-bricks-NB | typescript | /usr/local/easyops/bricks/code-bricks-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| containers-NB | typescript | /usr/local/easyops/bricks/containers-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| devops-union-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/devops-union-standalone-NA | 全部节点 | EasyDevOps | 前端页面 |
| digital-architecture-management-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/digital-architecture-management-standalone-NA | 全部节点 | EasyCMDB | 前端页面 |
| easy-hub-designer-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/easy-hub-designer-standalone-NA | 全部节点 | 全平台 | 前端页面 |
| forms-NB | typescript | /usr/local/easyops/bricks/forms-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| frame-bricks-NB | typescript | /usr/local/easyops/bricks/frame-bricks-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| general-auth-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/general-auth-standalone-NA | 全部节点 | 全平台 | 前端页面 |
| general-charts-NB | typescript | /usr/local/easyops/bricks/general-charts-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| hyper-insight-domain-union-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/hyper-insight-domain-union-standalone-NA | 全部节点 | HyperInsight | 前端页面 |
| hyper-insight-union-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/hyper-insight-union-standalone-NA | 全部节点 | HyperInsight | 前端页面 |
| icons-NB | typescript | /usr/local/easyops/bricks/icons-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| illustrations-NB | typescript | /usr/local/easyops/bricks/illustrations-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| itsc-union-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/itsc-union-standalone-NA | 全部节点 | EasyITSC | 前端页面 |
| mabuilder-union-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/mabuilder-union-standalone-NA | 全部节点 | EasyMABuilder | 前端页面 |
| nav-legacy-NB | typescript | /usr/local/easyops/bricks/nav-legacy-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| nav-NB | typescript | /usr/local/easyops/bricks/nav-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| next-console-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/next-console-standalone-NA | 全部节点 | 全平台 | 前端页面 |
| presentational-bricks-NB | typescript | /usr/local/easyops/bricks/presentational-bricks-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| shoelace-NB | typescript | /usr/local/easyops/bricks/shoelace-NB | 全部节点 | 全平台 | 前端公共依赖库 |
| sso-auth-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/sso-auth-standalone-NA | 全部节点 | 全平台 | 前端页面 |
| system-union-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/system-union-standalone-NA | 全部节点 | 全平台 | 前端页面 |
| topology-center-standalone-NA | typescript,html | /usr/local/easyops/applications_sa/topology-center-standalone-NA | 全部节点 | EasyCMDB | 前端页面 |
| v2-adapter-NB | typescript | /usr/local/easyops/bricks/v2-adapter-NB | 全部节点 | 全平台 | 前端公共依赖库 |

## 五、资源包

注：`*-M` 为模型定义文件，`*-R` 为数据割接脚本/产品文档。

| 名称 | 开发语言 | 部署路径 | 部署节点 | 应用模块 | 用途说明 |
|------|------|------|------|------|------|
| ACCESS_RESOURCE-M | json | /usr/local/easyops/resources/ACCESS_RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| ALICLOUD-M | json | /usr/local/easyops/ALICLOUD-M | 全部节点 | 全平台 | 阿里云资源模型定义文件 |
| APP_SERVICE-M | json | /usr/local/easyops/resources/APP_SERVICE-M | 全部节点 | 全平台 | 模型定义文件 |
| APPLICATION-M | json | /usr/local/easyops/resources/APPLICATION-M | 全部节点 | 全平台 | 模型定义文件 |
| ASSET_MANAGEMENT-M | json | /usr/local/easyops/ASSET_MANAGEMENT-M | 全部节点 | 全平台 | 资产管理模型定义文件 |
| autoops-union-R | shell | /usr/local/easyops/resources/autoops-union-R | 全部节点 | EasyAutoOps | 数据割接脚本 |
| AWSCLOUD-M | json | /usr/local/easyops/AWSCLOUD-M | 全部节点 | 全平台 | AWS 云资源模型定义文件 |
| CACHE_RESOURCE-M | json | /usr/local/easyops/resources/CACHE_RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| CLOUD_RESOURCE-M | json | /usr/local/easyops/resources/CLOUD_RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| cmdb-kits-R | shell | /usr/local/easyops/resources/cmdb-kits-R | 全部节点 | EasyCMDB | 数据割接脚本 |
| CMDB-M | json | /usr/local/easyops/resources/CMDB-M | 全部节点 | EasyCMDB | 模型定义文件 |
| cmdb-union-R | shell | /usr/local/easyops/resources/cmdb-union-R | 全部节点 | EasyCMDB | 数据割接脚本 |
| cmdb_service_db | shell | /usr/local/easyops/cmdb_service_db | 全部节点 | EasyCMDB | 数据割接脚本 |
| common-resources-R | shell | /usr/local/easyops/resources/common-resources-R | 全部节点 | 全平台 | 数据割接脚本 |
| console_db | rust | /usr/local/easyops/console_db | 全部节点 | — | 控制台的数据存储 |
| DASHBOARD-M | json | /usr/local/easyops/resources/DASHBOARD-M | 全部节点 | 全平台 | 模型定义文件 |
| DATABASE_RESOURCE-M | json | /usr/local/easyops/resources/DATABASE_RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| DATACENTER-M | json | /usr/local/easyops/resources/DATACENTER-M | 全部节点 | 全平台 | 模型定义文件 |
| developers-contracts-R | shell | /usr/local/easyops/resources/developers-contracts-R | 全部节点 | 全平台 | 数据割接脚本 |
| developers-docs-R | shell | /usr/local/easyops/resources/developers-docs-R | 全部节点 | EasyMABuilder | 低代码产品文档 |
| devops-docs-R | shell | /usr/local/easyops/resources/devops-docs-R | 全部节点 | EasyDevOps | devops产品文档 |
| devops-union-R | shell | /usr/local/easyops/resources/devops-union-R | 全部节点 | EasyDevOps | 数据割接脚本 |
| DOMAIN_RESOURCE-M | json | /usr/local/easyops/resources/DOMAIN_RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| easy-cmdb-docs-R | shell | /usr/local/easyops/resources/easy-cmdb-docs-R | 全部节点 | EasyCMDB | cmdb产品文档 |
| EASYHUB_CLIENT-M | json | /usr/local/easyops/resources/EASYHUB_CLIENT-M | 全部节点 | 全平台 | 模型定义文件 |
| EMERGENCY_MS-M | json | /usr/local/easyops/resources/EMERGENCY_MS-M | 全部节点 | 全平台 | 模型定义文件 |
| ens_client_db | shell | /usr/local/easyops/ens_client_db | 全部节点 | 全平台 | 数据割接脚本 |
| flowable_db | shell | /usr/local/easyops/flowable_db | 全部节点 | EasyITSC | 数据割接脚本 |
| FORM_BUILDER-M | json | /usr/local/easyops/resources/FORM_BUILDER-M | 全部节点 | 全平台 | 模型定义文件 |
| hyper-insight-docs-R | shell | /usr/local/easyops/resources/hyper-insight-docs-R | 全部节点 | HyperInsight | 监控产品文档 |
| hyper-insight-union-R | shell | /usr/local/easyops/resources/hyper-insight-union-R | 全部节点 | HyperInsight | 数据割接脚本 |
| itsc-union-R | shell | /usr/local/easyops/resources/itsc-union-R | 全部节点 | EasyITSC | 数据割接脚本 |
| itsc-workbench-docs-R | shell | /usr/local/easyops/resources/itsc-workbench-docs-R | 全部节点 | EasyITSC | itsc产品文档 |
| k8s-R | shell | /usr/local/easyops/resources/k8s-R | 全部节点 | 全平台 | 数据割接脚本 |
| K8SVIEW-M | json | /usr/local/easyops/resources/K8SVIEW-M | 全部节点 | 全平台 | 模型定义文件 |
| launchpad-configuration-docs-R | shell | /usr/local/easyops/resources/launchpad-configuration-docs-R | 全部节点 | 全平台 | 数据割接脚本 |
| LOGIC_RESOURCE-M | json | /usr/local/easyops/resources/LOGIC_RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| mabuilder-union-R | shell | /usr/local/easyops/resources/mabuilder-union-R | 全部节点 | EasyMABuilder | 数据割接脚本 |
| micro-app-factory-defaults-R | shell | /usr/local/easyops/resources/micro-app-factory-defaults-R | 全部节点 | 全平台 | 数据割接脚本 |
| monitor-kits-R | shell | /usr/local/easyops/resources/monitor-kits-R | 全部节点 | HyperInsight | 数据割接脚本 |
| notify_db | shell | /usr/local/easyops/notify_db | 全部节点 | 全平台 | 数据割接脚本 |
| ONETICKET-M | json | /usr/local/easyops/resources/ONETICKET-M | 全部节点 | 全平台 | 模型定义文件 |
| ops-automation-docs-R | shell | /usr/local/easyops/resources/ops-automation-docs-R | 全部节点 | EasyAutoOps | 运维自动化产品文档 |
| PLATFORM-M | json | /usr/local/easyops/resources/PLATFORM-M | 全部节点 | 全平台 | 模型定义文件 |
| QUEUE_RESOURCE-M | json | /usr/local/easyops/resources/QUEUE_RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| RESOURCE-M | json | /usr/local/easyops/resources/RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| SERVICE-M | json | /usr/local/easyops/resources/SERVICE-M | 全部节点 | 全平台 | 模型定义文件 |
| STORAGE_RESOURCE-M | json | /usr/local/easyops/resources/STORAGE_RESOURCE-M | 全部节点 | 全平台 | 模型定义文件 |
| SYS_SETTING-M | json | /usr/local/easyops/resources/SYS_SETTING-M | 全部节点 | 全平台 | 模型定义文件 |
| system-union-R | shell | /usr/local/easyops/resources/system-union-R | 全部节点 | 全平台 | 数据割接脚本 |
| TENCENTCLOUD-M | json | /usr/local/easyops/TENCENTCLOUD-M | 全部节点 | 全平台 | 腾讯云资源模型定义文件 |
| TOPO_CENTER-M | json | /usr/local/easyops/resources/TOPO_CENTER-M | 全部节点 | 全平台 | 模型定义文件 |
| UCLOUD-M | json | /usr/local/easyops/UCLOUD-M | 全部节点 | 全平台 | UCloud 资源模型定义文件 |
| VISUALBUILDER_RUNTIME-M | json | /usr/local/easyops/resources/VISUALBUILDER_RUNTIME-M | 全部节点 | 全平台 | 模型定义文件 |
| VMWARE-M | json | /usr/local/easyops/resources/VMWARE-M | 全部节点 | 全平台 | 模型定义文件 |
