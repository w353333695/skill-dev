# SNMP CMDB 兼容矩阵

本次扩展日期：2026-10-30。表中的“已映射”表示有原始 MIB 证据与离线回归，不表示实机验证。

|品牌/产品族|识别与私有树|已映射能力|尚未覆盖/条件|
|---|---|---|---|
|Dell iDRAC|674.10892.5；IDRAC-MIB-SMIv2|整机身份、CPU、内存、物理/逻辑盘、业务网口及网卡、电源、风扇、BMC 固件、宿主 OS 版本、电源状态、明确类型的 PCI GPU/HBA|依据归档 MIB；新代际字段差异待实测；其他 Dell agent 只通用回退|
|Lenovo XCC|19046.11.1；LENOVO-XCC-MIB|整机身份、CPU、内存、盘、网卡、融合以太网/FC端口、电源、风扇、GPU、BMC 固件、电源状态|XCC/XCC2/XCC3需以实际固件开放的表为准；不保证所有版本支持v2c GET|
|IBM IMM|2.3.51.3；IMM-MIB|整机身份、CPU、内存、网卡、融合端口、电源、风扇、GPU、BMC 固件、电源状态|只对IMM产品族启用该树；IBM Power/AIX不套用IMM列|
|Huawei iBMC|2011.2.235；HUAWEI-SERVER-IBMC-MIB|CPU、内存、物理/逻辑盘、网卡及业务网口、电源、风扇、BMC 固件、电源状态、明确类型的 PCI GPU/HBA|新旧iBMC固件、RAID控制器和业务网卡可见性待验证|
|百信|sysDescr名称识别+通用MIB|ENTITY、IF/IFX、FC-MGMT中实际实现的字段|官方按型号MIB附件访问403；尚无私有资产列实现|
|浪潮|sysDescr名称识别+通用MIB|ENTITY、IF/IFX、FC-MGMT中实际实现的字段|官方手册确认SNMP资产能力，但尚未取得可核验的原始私有MIB|
|其他或无法识别|generic|同上通用能力|不猜厂商树，可用明确的vendorProfile人工选已核验产品族|

## 通用方案能做到什么

1. SNMPv2-MIB基础字段用于识别；ENTITY-MIB整机机箱类提供序列号、厂商、型号（若实现）。
2. IF-MIB/IF-X-MIB提供被代理暴露的以太网口、MAC、速率、状态；不能认定BMC看到的接口就是全量业务网卡。
3. FC-MGMT-MIB（RFC4044，fcmPortEntry根1.3.6.1.2.1.10.56.1.3.1）提供WWPN，按ifIndex联IF-X速率和状态。
4. CPU插槽/内存条/物理盘全量清单没有强制跨厂商统一表。未用HOST-RESOURCES中的逻辑处理器数冒充物理CPU颗数，未把文件系统容量当物理盘容量。
5. 以太网光口仍是NETDPORT；只有证据明确才写isOpticalPort。当前不从速率、名称、SFP猜介质，不采DOM光功率。FC口单独进FIBER_CHANNEL_PORT，不混为光以太网口。

## 型号兼容策略

- 按管理控制器产品族和能力自适应，不枚举服务器型号，不因型号未知而拒采。
- 先sysObjectID，再sysDescr辅助；数字OID根严格按点分段匹配。未知品牌只走通用层。
- 自动识别可能被OEM固件误导；可配置vendorProfile，只有确认树一致后再指定。
- 读取私有表仅walk字典白名单列，处理稀疏、多段索引、空槽与unknown哨兵；不SET。
- 某表失败不提交这张表的半成品，不阻断有预算的其他表；预算用尽停止整机剩余请求。
- 空表/不支持/超时不输出空数组或假0；不删除旧网口/FC关系。部件可选字段缺失时按name合并旧值。
- 一张成功但设备自身漏报的表，不能凭SNMP证明其全量性；先对少量样本核对，再扩大采集范围。

## CMDB口径与身份保护

- memorySize顶层为GiB整数；memoryInfo.memorySize为GB十进制字符串；不能无损映射时不写汇总。
- diskSize顶层为GiB字符串；diskInfo.capacityGB为GB整数；logicalDrives.capacity为GB浮点。
- Dell归档表的MB容量当前按常见Net-SNMP/Zabbix设备模板的二进制MB口径映射，需首台样本核对控制器展示值；不能据此声称厂家所有代际口径一致。
- 联想memoryVpdSize原定义仅称GigaBytes，保留子项原数量，不推算顶层GiB；来源未明确的裸字符串容量不猜单位。
- cpuNum 依据有效 CPU 行；cpuCoreCount 对每颗 totalCores 求和，cpuThreadNum 独立对 totalThreads 求和。对应列必须完整、所有 CPU 行必须有效；其它可选列失败不阻断有效总数。
- NETDPORT.name优先父实例ID+MAC，无MAC时使用接口名/硬件位置；FC按合法WWPN唯一键。
- 默认不改人工整机 name；已确认的 brand/mdl/sn 默认写入。旧整结构配置显式 updateIdentity=false 可禁止身份更新；身份未知不补猜测值。
- 不更新运营deviceStatus，不做自动下架、删除或关系清理。

## 进入生产前的最低验收

每个实际BMC固件族至少选一台，核对CPU颗数/线程、内存单位、盘容量/RAID、业务网卡MAC、FC WWPN与关联。
OEM、新平台与旧固件需要独立验证。没有这些样本时只能交付资料及离线测试级兼容，不给出虚假的全型号兼容率。

## 新增字段限制

- 微码：没有已核验的 CPU 微码 OID，不使用 BIOS/BMC 版本替代。宿主 OS 版本仅 Dell 已有明确 systemOSVersion 来源，其他产品族不猜。
- PCI GPU/HBA：仅显式类型关键字归类，无法从描述确认类型时记入 INFO 日志而不写目标清单；不保证能识别仅给出产品型号的设备，不据厂商名认定 GPU。
- IBM/联想 HBA：FC 端口名称与网络功能表产品名唯一匹配时可提取卡信息；同名多卡不推测；端口数量只采用 MIB 返回值。
- FC 端口均为服务器本端；交换机远端 WWPN 未提供时不创建交换机对端关系，不将本端 WWPN 绑定为交换机端口。
- 百信、浪潮仍仅有标准 MIB 回退，没有本次新增的私有部件覆盖；不声称“全部品牌型号均支持”。
- 可选表/列失败时保留其它有效数据，摘要为 partial；基础连接、鉴权、本地依赖、非法参数失败仍是阻塞错误。
