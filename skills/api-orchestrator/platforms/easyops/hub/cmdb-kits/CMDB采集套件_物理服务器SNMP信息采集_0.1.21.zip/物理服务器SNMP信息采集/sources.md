# MIB调研来源与证据链

原始调研截至2026-10-27；本次根据已有原始 MIB 复核并扩展于2026-10-30。数值OID来自原始ASN.1定义的离线解析，不根据网页OID片段推断。
单文件采集脚本的原生 PROFILES 字典内置执行规则；oid-dictionary.json 提供符号、数值 OID、访问类型、描述及枚举；mib-evidence.json 保存本次复核对象的原始定义摘要、来源文件名及 SHA256。以上 JSON 不参与运行时读取。
完整MIB不随本包分发，避免把第三方版权文件当成自有代码；下面区分官方入口与原始文件镜像。

## 标准

- SNMPv2-MIB：RFC3418，https://www.rfc-editor.org/rfc/rfc3418
- ENTITY-MIB：RFC4133，https://www.rfc-editor.org/rfc/rfc4133
- IF-MIB/IF-X-MIB：RFC2863，https://www.rfc-editor.org/rfc/rfc2863
- FC-MGMT-MIB：RFC4044，https://www.rfc-editor.org/rfc/rfc4044
- 不把HOST-RESOURCES逻辑CPU/卷表包装成物理部件清单。

## Dell

原始归档IDRAC-MIB-SMIv2（修订2015-01-19，非最新代际全量声明）：
https://git.davidleutgeb.at/mibs.git/plain/MIBS/drac/IDRAC-MIB-SMIv2

厂商模块原始定义由第三方镜像承载，镜像本身不是Dell官方发布站。
CPU/内存/RAID表可证明列定义存在，不能证明每个型号/固件必然返回全部列。
容量MB的二进制换算参考直接实现（非厂商单位保证）：
https://github.com/zabbix/zabbix/blob/master/templates/server/dell_idrac_snmp/template_server_dell_idrac_snmp.yaml

## 联想

官方XCC2 MIB说明：https://pubs.lenovo.com/xcc2/mibs_introduction
官方命令说明：https://pubs.lenovo.com/xcc2/dw1lm_r_snmpcommand
官方MIB下载入口：https://datacentersupport.lenovo.com/gp/en/downloads/ds559710

原始模块镜像：
- https://git.davidleutgeb.at/mibs.git/plain/MIBS/lenovo/LENOVO-XCC-MIB
- https://git.davidleutgeb.at/mibs.git/plain/MIBS/lenovo/LENOVO-SMI-MIB
- https://git.davidleutgeb.at/mibs.git/plain/MIBS/lenovo/LENOVO-PRODUCTS-MIB

不能因支持v2c Trap就推定支持v2c GET；XCC2优先使用v3。

## IBM

IMM-MIB原始定义镜像：https://git.davidleutgeb.at/mibs.git/plain/MIBS/ibm/IMM-MIB
范围限IMM/x86管理控制器；IBM Power/HMC/AIX没有由此得到完整私有硬件采集支持。

## 华为

HUAWEI-SERVER-IBMC-MIB原始定义镜像：
https://git.davidleutgeb.at/mibs.git/plain/MIBS/huawei/HUAWEI-SERVER-IBMC-MIB
按实际列及单位字符串解析；不把同属iBMC的OEM设备直接认定为华为私有列兼容。

## 百信

官方按型号文件入口：https://www.100trust.cn/companyfile/8/
发现的TS02F-F30/TS02F-G39 SERVER-iBMC-MIB附件位于官方页面引用的cecdn域；请求返回403，未取得原始文件。
本次未绕过访问控制；错误网页不作为MIB。因此不编造百信私有OID、不复用华为私有树冒充支持。

## 浪潮

官方BMC V2.7用户手册：
https://en.inspur.com/eportal//fileDir/active_download/platformBookZh/6680/Inspur%C2%A0Server%C2%A0BMC%C2%A0User%C2%A0Manual%C2%A0V2.7.pdf
第21页确认SNMP GET/SET/Trap及资产查询，但本实现只有GET类只读操作。
没有取得可解析的厂商资产原始MIB，故不据手册推断列号和单位。

## 补齐私有覆盖的方法

后续从合法的厂商MIB包或用户已有MIB中获取原始定义，不需要先拿设备清单即可扩展产品族。
依照EasyOps现有套件开发流程，核对import依赖、MAX-ACCESS、INDEX、单位、枚举和空槽规则；修改包内脚本的产品族字典和离线模拟用例后发版。
拿到实际样本后再验证物理部件完整性、管理口/业务口区分、SNMP版本和容量口径。不以资料调研替代现场验收。

## 0.1.21 复核要点

- Dell processorDeviceThreadCount 的实际定义为 processorDeviceTableEntry 19，修正旧规则 OID 与 column 不一致；华为 logicalDriveName 为 logicalDriveDescriptionEntry 19，不再误请求第 20 列访问策略。
- Dell powerSupplyOutputWatts 明确为最大持续输出功率、单位十分之一瓦，写 powerCapacityWatts 时除以 10；不写成实时输出功率，不把额定输入瓦数当成电源输出容量。
- 风扇、PSU 使用各自 MIB 状态枚举，StateSettingsFlags 不按普通健康枚举理解；未掌握的状态和单位不补猜。
- IBM/联想 firmware VPD 按类型挑选 spFirmware/spFimware 的 BMC 版本；华为 firmwareType=iBMC 才作为 BMC 版本。BIOS、BMC、宿主 OS、CPU 微码各自区分。
- IBM IMM 中有同名符号，按 OBJECT-TYPE 的父 entry 精确解析，不采用同名最后一次声明覆盖。
- 本次证据来自已有本地原始 MIB，不代表这些归档文件是厂家最新版本，也不代替实际固件验证。
