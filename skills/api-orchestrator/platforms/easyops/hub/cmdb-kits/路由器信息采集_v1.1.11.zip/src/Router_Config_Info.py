#!/usr/local/easyops/python/bin/python
# -*- coding: utf-8 -*-
# tool_name: 路由器配置采集
# input: string ip 数据库用户名
# input: string auth 数据库密码

import sys
import json
import os
from xml.etree import ElementTree as ET
from pysnmp.hlapi import *

reload(sys)
sys.setdefaultencoding('utf8')

# 导入日志库
current_dir = os.path.dirname(os.path.abspath(__file__))
_SAMPLER_SCRIPTS = os.path.normpath(os.path.join(current_dir, '..', '..', '..', 'easy_process_sampler', 'scripts'))
if _SAMPLER_SCRIPTS not in sys.path:
    sys.path.insert(0, _SAMPLER_SCRIPTS)

try:
    from lib import task_logger
    logging = task_logger.get_logger()
except Exception:
    import logging
    FORMAT = '[%(asctime)s (line:%(lineno)d) %(levelname)s] %(message)s'
    logging.basicConfig(level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S', format=FORMAT)

instanceId = os.environ.get("EASYOPS_COLLECTOR_instanceId")
ip = os.environ.get("EASYOPS_COLLECTOR_ip")
port = os.environ.get("EASYOPS_COLLECTOR_port")
snmp_version = os.environ.get("EASYOPS_COLLECTOR_snmp_version")
community = os.environ.get("EASYOPS_COLLECTOR_community")
ignore_fields = os.environ.get("EASYOPS_COLLECTOR_ignoreFields")
ignore_collect_net = os.environ.get("EASYOPS_COLLECTOR_ignoreCollectNet")
# SNMP v3认证所需的环境变量
username = os.environ.get("EASYOPS_COLLECTOR_username")
authProtocol = os.environ.get("EASYOPS_COLLECTOR_authProtocol")
authKey = os.environ.get("EASYOPS_COLLECTOR_authKey")
privProtocol = os.environ.get("EASYOPS_COLLECTOR_privProtocol")
privKey = os.environ.get("EASYOPS_COLLECTOR_privKey")


# SNMP的常见错误返回值
SNMP_ERROR_VALUES = [
    "No more variables left in this MIB View",
    "No Such Object",
    "No Such Instance",
    "End of MIB View",
    "No Such Object available on this agent at this OID",
    "noSuchName",
    "NULL0",
    ""
]

OID_MAP = {
    "general": [
        {
            "oid": "1.3.6.1.2.1.1.5.0",  # sysName
            "cmdb_field": "cSysName",
            "regex_pattern": r"(.+)"
        },
        {
            "oid": "1.3.6.1.2.1.1.1.0",  # sysDescr
            "cmdb_field": "cMdl",
            "regex_pattern": r"Router \(([\w-]+)\)|H3C Series Router\s(\S+)|H3C\s(\S+?)\s+?Copyright|Huawei (\S+) Huawei Versatile Routing Platform Software|Ltd\.\s+HUAWEI (.+)|MyPower \(R\) Operating System Software\s+(\S+)\s+version|Cisco IOS Software.+Software \((.+?)\)"
        },
        {
            "oid": "1.3.6.1.2.1.1.1.0",  # sysDescr
            "cmdb_field": "cBrand",
            "regex_pattern": r"(VRP|New H3C|H3C|Huawei|HUAWEI|Cisco|DELL|Juniper|Digital China Networks Limited|ZTE|Ruijie|FiberHome|MyPower|gigamon)"
        },
        {
            "oid": "1.3.6.1.2.1.1.1.0",  # sysDescr
            "cmdb_field": "sysVersion",
            "regex_pattern": r"V(\d+\.\d+)|Version: (.+)|Version\s+([\d\.]+(?:\s+\([^)]+\))?)|version\s+([\d\._-]+)|\(\S+\s+(\S+?)\)\s+|Version\s+(\S+)|GigaVUE-OS\s(\S+)|JUNOS\s+([\d\.R]+)|kernel\s+JUNOS\s+([\d\.R]+)"
        },
        {
            "oid": "1.3.6.1.2.1.1.3.0",  # sysUpTimeInstance
            "cmdb_field": "cUpTime",
            "regex_pattern": r"(\d+)"
        },
        {
            "oid": "1.3.6.1.2.1.1.1.0",  # sysDescr
            "cmdb_field": "cSysDescr",
            "regex_pattern": r"([\s\S]+)"
        },
        {
            "oid": "1.3.6.1.2.1.47.1.1.1.1.11",  # entPhysicalSerialNum
            "cmdb_field": "cSn",
            "regex_pattern": r"(\w+)"
        },
    ]
}
DEVICE_STATUS_MAP = {
    "1": "不支持",
    "2": "已禁用",
    "3": "已启用",
    "4": "离线",
    "11": "正常",
    "12": "故障",
    "13": "已连接",
    "15": "协议已启动",
    "16": "链路已启动",
    "17": "链路已断开",
    "18": "在位",
    "19": "不在位"
}
BrandKeyCisco = "Cisco"
BrandKeyH3C = "H3C"
BrandKeyHuawei = "Huawei"
BrandKeyHillstone = "Hillstone"
BrandKeyJuniper = "Juniper"

# 添加SNMP v3协议映射
PROTOCOL_MAP = {
    "MD5": usmHMACMD5AuthProtocol,
    "SHA": usmHMACSHAAuthProtocol,
    "SHA224": usmHMAC128SHA224AuthProtocol,
    "SHA256": usmHMAC192SHA256AuthProtocol,
    "SHA384": usmHMAC256SHA384AuthProtocol,
    "SHA512": usmHMAC384SHA512AuthProtocol,
    "DES": usmDESPrivProtocol,
    "AES": usmAesCfb128Protocol,
    "AES128": usmAesCfb128Protocol,
    "AES192": usmAesCfb192Protocol,
    "AES256": usmAesCfb256Protocol,
}


class CollectException(Exception):
    pass


import subprocess
import tempfile
import re
import datetime
from threading import Thread, BoundedSemaphore
from pysnmp.hlapi import *
from pysnmp.entity.rfc3413.oneliner import cmdgen
import ipaddress


def do_cmd(command, shell=False, close_fds=False, stdin=None, only_stdout=False, **kwargs):
    """
    Run the given subprocess command and return it's output. Raise an Exception
    if an error occurs.
    """

    # Use tempfile, allowing a larger amount of memory. The subprocess.Popen
    # docs warn that the data read is buffered in memory. They suggest not to
    # use subprocess.PIPE if the data size is large or unlimited.
    env = dict(kwargs.pop('env', {})) if kwargs.get('env') else os.environ.copy()
    with tempfile.TemporaryFile() as stdout_f, tempfile.TemporaryFile() as stderr_f:
        proc = subprocess.Popen(
            command,
            close_fds=close_fds,  # only set to True when on Unix, for WIN compatibility
            shell=shell,
            stdin=stdin,
            stdout=stdout_f,
            stderr=stderr_f,
            env=env,
            **kwargs
        )

        proc.wait()
        stderr_f.seek(0)
        err = stderr_f.read()

        stdout_f.seek(0)
        output = stdout_f.read()

    if only_stdout:
        result = output
    else:
        result = err or output

    return proc.returncode, result


def is_snmp_error_value(value):
    if not value:
        return True
    value_str = str(value).strip()
    return value_str in SNMP_ERROR_VALUES


# ------------ lldp -----------------
class SnmpError(Exception):
    """Base class for snmp_api exceptions."""


def deco_return(f):
    def func(*args, **kwargs):
        errorIndication, errorStatus, errorIndex, varBindTable = f(*args, **kwargs)
        if errorIndication:
            oid_param = args[1] if len(args) > 1 else kwargs.get('oid', 'unknown')
            method_name = f.__name__ if hasattr(f, '__name__') else 'unknown'
            logging.error("Router SNMP {} response: oid={}, status=error_indication, response_text={}".format(
                method_name, oid_param, str(errorIndication)))
            raise SnmpError(errorIndication)
        else:
            if errorStatus:
                err = '%s at %s' % (errorStatus.prettyPrint(), errorIndex and varBindTable[int(errorIndex) - 1] or '?')
                oid_param = args[1] if len(args) > 1 else kwargs.get('oid', 'unknown')
                method_name = f.__name__ if hasattr(f, '__name__') else 'unknown'
                logging.error("Router SNMP {} response: oid={}, status=error_status, response_text={}".format(
                    method_name, oid_param, err))
                raise SnmpError(err)
            else:
                rval = {}
                if not varBindTable:
                    return rval
                for varBindTableRow in varBindTable:
                    for name, val in varBindTableRow:
                        rval[name.prettyPrint()] = val.prettyPrint()
                return rval

    return func


class BaseSnmp(object):
    def __init__(self, *args, **kwargs):
        self.ip = kwargs['ip']
        self.port = int(kwargs.get('port', 161)) or 161
        self.snmp_version = kwargs.get('snmp_version', '2c')

        # 支持SNMP v3认证
        if kwargs.get('auth_data'):
            self.rd = kwargs['auth_data']
            self.wr = kwargs['auth_data']
        else:
            self.rd = cmdgen.CommunityData(kwargs.get('rd') or 'public')
            self.wr = cmdgen.CommunityData(kwargs.get('wr') or 'public')

        self.target = cmdgen.UdpTransportTarget((self.ip, self.port))
        self.cmdGen = cmdgen.CommandGenerator()
        self.if_index_min = ''

    def __str__(self):
        return '%s(%s:%s)' % (self.__class__.__name__, self.ip, self.port)

    @deco_return
    def get_cmd(self, oid):
        """
        发起snmpget命令
        """
        return self.cmdGen.getCmd(self.rd, self.target, oid)

    @deco_return
    def next_cmd(self, oid):
        """
        发起snmpwalk命令
        """
        return self.cmdGen.nextCmd(self.rd, self.target, oid)

    def get_last_oid(self, oid):
        return oid.rpartition('.')[2]

    def get_except_last_oid(self, oid):
        return oid.rpartition('.')[0]

    def get_last_two_oid(self, oid):
        return '.'.join(oid.rsplit('.', 2)[1:])

    def get_last_n_oid(self, oid, n):
        return '.'.join(oid.rsplit('.', n)[1:])

    def list_port_index(self):
        res = {}
        tmp = self.next_cmd(self.oid_ifDescr)
        for oid, val in tmp.iteritems():
            if re.findall('\d/[0-9.]+$', val):  # 判断是否为物理接口
                res[self.get_last_oid(oid)] = val
        self.if_index_min = min(res.keys())  # 一定要是物理口才能这么做
        return res

    def list_port_if_index(self):
        res = {}
        tmp = self.next_cmd(self.oid_dot1dBasePortIfIndex)
        for oid, val in tmp.iteritems():
            res[val] = self.get_last_oid(oid)
        return res

    def list_mac_table(self):
        """
        获得全部port的对端mac
        格式为{'port': [mac,mac]}，如{'002': ['AA:BB:CC:DD:EE:FF', 'AA:BB:CC:DD:EE:GG']}
        """
        res = {}
        tmp = self.next_cmd(self.oid_dot1qTpFdbPort)
        for oid, val in tmp.iteritems():
            res.setdefault(val, []).append(oid_to_mac(self.get_last_n_oid(oid, 6)))
        return res

    def list_lldp_table(self):
        """
        获得lldp信息
        格式为{'port': [{'peer_device': 'core-5', 'peer_port': '1/0/5'}]}
        """
        res = {}
        ports = self.next_cmd(self.oid_lldpRemPortId)
        devices = self.next_cmd(self.oid_lldpRemSysName)
        for oid, val in devices.iteritems():
            res[self.get_last_two_oid(oid)] = {'peer_device': val, 'peer_port': ''}
        for oid, val in ports.iteritems():
            if val[:2] == "0x":
                val = val[2:].zfill(12)
                val = ':'.join([val[i:i + 2] for i in range(0, 12, 2)])
            res[self.get_last_two_oid(oid)]['peer_port'] = val
        data = {}
        for r, val in res.items():
            data.setdefault(r.partition('.')[0], []).append(val)
        return data

    def run(self):
        related_host = []
        related_port = []

        port_index = self.list_port_index()
        port_if_index = self.list_port_if_index()

        # 接入交换机获取mac表，不需要获取neighbor  接入交换机和主机的关系
        mac_table = self.list_mac_table()
        for index, port in port_index.items():
            macs = mac_table.get(port_if_index.get(index, None), [])
            if macs:
                related_host += [{'port': port, 'host_mac': mac, 'port_index': index} for mac in macs]

        lldp_table = self.list_lldp_table()
        for index, port in port_index.items():
            if index in lldp_table:
                related_port += [{'port': port, 'peer_device': peer['peer_device'], 'peer_port': peer['peer_port']} for
                                 peer in lldp_table[index]]
        return related_host, related_port


class CiscoSnmp(BaseSnmp):
    def __init__(self, *args, **kwargs):
        super(CiscoSnmp, self).__init__(*args, **kwargs)
        self.oid_ifDescr = '1.3.6.1.2.1.2.2.1.2'
        self.oid_dot1qTpFdbPort = '1.3.6.1.2.1.17.4.3.1.2'
        self.oid_vmVlan = '1.3.6.1.4.1.9.9.68.1.2.2.1.2'
        self.oid_lldpRemEntry = '1.3.6.1.4.1.9.9.23.1.2.1.1'  # 其实是cdp
        self.oid_lldpRemPortId = self.oid_lldpRemEntry + '.7'
        self.oid_lldpRemSysName = self.oid_lldpRemEntry + '.6'
        self.oid_dot1dBasePortIfIndex = '1.3.6.1.2.1.17.1.4.1.2'
        self.vlan_ids = set(self.list_vlan_id())

    def list_vlan_id(self):
        return self.next_cmd(self.oid_vmVlan).values()

    def list_mac_table(self):
        """
        获得全部port的对端mac
        格式为{'port': 'mac,mac'}，如{'002': 'AA:BB:CC:DD:EE:FF,AA:BB:CC:DD:EE:GG'}
        """
        res = {}
        if_index_prefix = self.if_index_min[:3]
        rd = self.rd.communityName
        for vlan in self.vlan_ids:
            self.rd = cmdgen.CommunityData(rd + '@' + vlan)
            tmp = super(CiscoSnmp, self).list_mac_table()
            res.update(tmp)
        self.rd = cmdgen.CommunityData(rd)
        return res

    def list_port_if_index(self):
        res = {}
        rd = self.rd.communityName
        for vlan in self.vlan_ids:
            self.rd = cmdgen.CommunityData(rd + '@' + vlan)
            tmp = super(CiscoSnmp, self).list_port_if_index()
            res.update(tmp)
        self.rd = cmdgen.CommunityData(rd)
        return res


class H3cSnmp(BaseSnmp):
    def __init__(self, *args, **kwargs):
        super(H3cSnmp, self).__init__(*args, **kwargs)
        self.oid_ifDescr = '1.3.6.1.2.1.2.2.1.2'
        self.oid_dot1qTpFdbPort = '1.3.6.1.2.1.17.7.1.2.2.1.2'
        self.oid_lldpRemEntry = '1.0.8802.1.1.2.1.4.1.1'
        self.oid_lldpRemPortId = self.oid_lldpRemEntry + '.7'
        self.oid_lldpRemSysName = self.oid_lldpRemEntry + '.9'
        self.oid_dot1dBasePortIfIndex = '1.3.6.1.2.1.17.1.4.1.2'


class JuniperSnmp(BaseSnmp):
    def __init__(self, *args, **kwargs):
        super(JuniperSnmp, self).__init__(*args, **kwargs)
        self.oid_ifDescr = '1.3.6.1.2.1.2.2.1.2'
        self.oid_dot1qTpFdbPort = '1.3.6.1.2.1.17.7.1.2.2.1.2'
        self.oid_lldpRemEntry = '1.0.8802.1.1.2.1.4.1.1'
        self.oid_lldpRemPortId = self.oid_lldpRemEntry + '.7'
        self.oid_lldpRemSysName = self.oid_lldpRemEntry + '.9'
        self.oid_dot1dBasePortIfIndex = '1.3.6.1.2.1.17.1.4.1.2'


class HuaweiSnmp(BaseSnmp):
    """
    华为路由器专用SNMP处理类
    支持多个OID备选方案，提高采集成功率
    """
    def __init__(self, *args, **kwargs):
        super(HuaweiSnmp, self).__init__(*args, **kwargs)
        self.oid_ifDescr = '1.3.6.1.2.1.2.2.1.2'
        # 华为路由器MAC地址表OID - 尝试多个可能的OID
        # 标准BRIDGE-MIB MAC地址表
        self.oid_dot1qTpFdbPort = '1.3.6.1.2.1.17.4.3.1.2'
        # 华为私有MAC地址表OID (如果标准的不工作)
        self.oid_huawei_mac_port = '1.3.6.1.4.1.2011.5.25.42.1.1.1.1.2'
        # 华为MAC地址表其他可能的OID
        self.oid_huawei_mac_alt = '1.3.6.1.4.1.2011.5.25.42.1.1.1.1.7'
        # 华为路由器LLDP OID - 标准LLDP-MIB
        self.oid_lldpRemEntry = '1.0.8802.1.1.2.1.4.1.1'
        self.oid_lldpRemPortId = self.oid_lldpRemEntry + '.7'
        self.oid_lldpRemSysName = self.oid_lldpRemEntry + '.9'
        # 华为私有LLDP OID (如果标准的不工作)
        self.oid_huawei_lldp_port = '1.3.6.1.4.1.2011.5.25.42.1.1.1.1.3'
        self.oid_huawei_lldp_sysname = '1.3.6.1.4.1.2011.5.25.42.1.1.1.1.4'
        # 华为其他可能的LLDP OID
        self.oid_huawei_lldp_alt_port = '1.3.6.1.4.1.2011.5.25.42.1.1.1.1.5'
        self.oid_huawei_lldp_alt_sysname = '1.3.6.1.4.1.2011.5.25.42.1.1.1.1.6'
        self.oid_dot1dBasePortIfIndex = '1.3.6.1.2.1.17.1.4.1.2'

    def list_mac_table(self):
        """
        华为路由器MAC地址表采集 - 尝试多个OID
        格式为{'port': [mac,mac]}，如{'002': ['AA:BB:CC:DD:EE:FF', 'AA:BB:CC:DD:EE:GG']}
        """
        res = {}
        # 先尝试标准MAC地址表OID
        tmp = self.next_cmd(self.oid_dot1qTpFdbPort)
        
        if not tmp:
            # 尝试华为私有MAC地址表OID
            tmp = self.next_cmd(self.oid_huawei_mac_port)
        
        if not tmp:
            # 尝试华为备用MAC地址表OID
            tmp = self.next_cmd(self.oid_huawei_mac_alt)
        
        if not tmp:
            # MAC地址表查询失败，可能OID不存在或权限不足
            return res
            
        for oid, val in tmp.iteritems():
            res.setdefault(val, []).append(oid_to_mac(self.get_last_n_oid(oid, 6)))
        return res

    def list_lldp_table(self):
        """
        华为路由器LLDP信息采集 - 尝试多个OID
        格式为{'port': [{'peer_device': 'core-5', 'peer_port': '1/0/5'}]}
        """
        res = {}
        # 先尝试标准LLDP OID
        ports = self.next_cmd(self.oid_lldpRemPortId)
        devices = self.next_cmd(self.oid_lldpRemSysName)
        
        # 如果标准LLDP OID没有数据，尝试华为私有OID
        if not ports:
            ports = self.next_cmd(self.oid_huawei_lldp_port)
        
        if not ports:
            ports = self.next_cmd(self.oid_huawei_lldp_alt_port)
        
        if not devices:
            devices = self.next_cmd(self.oid_huawei_lldp_sysname)
        
        if not devices:
            devices = self.next_cmd(self.oid_huawei_lldp_alt_sysname)
        
        for oid, val in devices.iteritems():
            # 清理可能的STRING:前缀和引号（兼容不同SNMP库的输出格式）
            val_str = str(val)
            if val_str.startswith('STRING: '):
                val_str = val_str[8:]
            if val_str.startswith('"') and val_str.endswith('"'):
                val_str = val_str[1:-1]
            res[self.get_last_two_oid(oid)] = {'peer_device': val_str, 'peer_port': ''}
        
        for oid, val in ports.iteritems():
            # 清理可能的STRING:前缀和引号
            val_str = str(val)
            if val_str.startswith('STRING: '):
                val_str = val_str[8:]
            if val_str.startswith('"') and val_str.endswith('"'):
                val_str = val_str[1:-1]
            if val_str[:2] == "0x":
                val_str = val_str[2:].zfill(12)
                val_str = ':'.join([val_str[i:i + 2] for i in range(0, 12, 2)])
            res[self.get_last_two_oid(oid)]['peer_port'] = val_str
        
        data = {}
        for r, val in res.items():
            data.setdefault(r.partition('.')[0], []).append(val)
        return data


def get_snmp_inst(device_type, ip, rd, wr, port=161, snmp_version='2c', auth_data=None):
    SNMP = {
        BrandKeyCisco: CiscoSnmp,
        BrandKeyH3C: H3cSnmp,
        BrandKeyHuawei: HuaweiSnmp,
        BrandKeyJuniper: JuniperSnmp
    }
    snmpClass = SNMP.get(device_type, H3cSnmp)
    if not snmpClass:
        raise SnmpError(u'暂不支持%s类型路由器' % (device_type))
    if not ip:
        raise SnmpError(u'没有IP')
    return snmpClass(ip=ip, rd=rd, wr=wr, port=port, snmp_version=snmp_version, auth_data=auth_data)


def chunks_string(s, size):
    return [s[i: i + size] for i in range(0, len(s), size)]


def oid_to_mac(oid):
    return ":".join(['{:0>2x}'.format(int(s)) for s in oid.split('.')]).upper()


def unicode2utf8(s):
    return s.encode('utf-8')


# -----------------------------


class BaseDeviceCollector(object):
    def __init__(self, ip, community, snmp_version="2c", auth_data=None, port=161):
        self.ip = ip
        self.port = port
        self.community = community
        self.snmp_version = snmp_version
        self.auth_data = auth_data
        self.target = UdpTransportTarget((self.ip, self.port), timeout=60, retries=5)
        self.context_data = ContextData()

        # 设置认证数据
        if self.auth_data is None:
            self.auth_data = CommunityData(community)

        self.ENTITY_PHYSICAL_CLASS_OID = "1.3.6.1.2.1.47.1.1.1.1.5"  # 实体类型
        self.ENTITY_NAME_OID = "1.3.6.1.2.1.47.1.1.1.1.7"  # 名称
        self.ENTITY_SERIAL_OID = "1.3.6.1.2.1.47.1.1.1.1.11"  # 序列号
        self.ENTITY_MANUFACTURER_OID = "1.3.6.1.2.1.47.1.1.1.1.12"  # 制造商
        self.ENTITY_MODEL_OID = "1.3.6.1.2.1.47.1.1.1.1.13"  # 型号
        self.ENTITY_TYPE_OID = "1.3.6.1.2.1.47.1.1.1.1.3"  # 类型
        self.ENTITY_CURRENT_OID = "1.3.6.1.2.1.99.1.1.1.4"  # 当前读数
        self.ENTITY_REMOVABLE_OID = "1.3.6.1.2.1.47.1.1.1.1.16"  # 是否可插拔
        self.ENTITY_DESCR_OID = "1.3.6.1.2.1.47.1.1.1.1.2"  # 描述信息

    def snmp_get(self, oid):
        """使用SNMP GET获取单个OID的值"""
        error_indication, error_status, error_index, var_binds = next(
            getCmd(SnmpEngine(),
                   self.auth_data,
                   self.target,
                   self.context_data,
                   ObjectType(ObjectIdentity(oid)))
        )

        if error_indication:
            raise Exception("SNMP GET failed: %s" % error_indication)
        elif error_status:
            raise Exception('SNMP GET error: %s at %s' % (
                error_status.prettyPrint(),
                error_index and var_binds[int(error_index) - 1][0] or '?'
            ))

        return var_binds[0][1].prettyPrint()

    def snmp_walk(self, oid):
        """使用SNMP WALK获取OID子树的所有值"""
        results = []
        for (error_indication, error_status, error_index, var_binds) in nextCmd(
                SnmpEngine(),
                self.auth_data,
                self.target,
                self.context_data,
                ObjectType(ObjectIdentity(oid)),
                lexicographicMode=False
        ):
            if error_indication:
                raise Exception("SNMP WALK failed: %s" % error_indication)
            elif error_status:
                raise Exception('SNMP WALK error: %s at %s' % (
                    error_status.prettyPrint(),
                    error_index and var_binds[int(error_index) - 1][0] or '?'
                ))

            for var_bind in var_binds:
                oid_str = str(var_bind[0])
                value = var_bind[1].prettyPrint()
                results.append((oid_str, value))

        return results
    # 如果与物理组件相关联的模型名称字符串对于代理是未知的，则entPhysicalModelName(.13)将包含零长度字符串。使用entPhysicalDescr(.2)进行替代,从描述信息中截取
    def get_model_with_fallback(self, index):
        try:
            model_val = self.snmp_get("{0}.{1}".format(self.ENTITY_MODEL_OID, index))
            if model_val and model_val not in SNMP_ERROR_VALUES:
                return model_val
        except Exception:
            pass
        try:
            descr_val = self.snmp_get("{0}.{1}".format(self.ENTITY_DESCR_OID, index))
            if descr_val and descr_val not in SNMP_ERROR_VALUES:
                extracted = self.extract_model_from_descr(descr_val)
                return extracted or descr_val
        except Exception:
            pass
        return ""

    def extract_model_from_descr(self, descr_text):
        """从描述文本中提取更像型号的片段。未匹配则返回空串。"""
        try:
            text = descr_text if isinstance(descr_text, basestring) else unicode(descr_text)
        except Exception:
            try:
                text = unicode(str(descr_text))
            except Exception:
                text = str(descr_text)

        # 优先匹配以 CR 开头的大写字母数字（华为常见部件码），长度>=6 避免短片段
        # 后续可以添加更多品牌特征
        patterns = [
            r"\bCR[0-9A-Z]{4,}\b",
            r"\b[0-9A-Z]{8,}\b"
        ]
        for pat in patterns:
            m = re.search(pat, text)
            if m:
                return m.group(0)
        return ""

    def get_current_reading_safe(self, index):
        """尝试获取ENTITY-SENSOR当前读数，获取失败返回空字符串"""
        try:
            val = self.snmp_get("{0}.{1}".format(self.ENTITY_CURRENT_OID, index))
            if not val:
                return ""
            lower_val = str(val).lower()
            error_phrases = [
                "no such object",
                "no such instance",
                "end of mib view",
                "no more variables left in this mib view"
            ]
            if any(p in lower_val for p in error_phrases):
                return ""
            if val not in SNMP_ERROR_VALUES:
                return val
        except Exception:
            return ""
        return ""

    def snmp_collect(self, oid):
        """使用snmp库采集数据，返回格式化的字符串以保持兼容性"""
        try:
            # 仅当标量以 .0 结尾时直接 GET；其他情况优先 WALK，若为空再回退 GET
            if oid.endswith('.0'):
                value = self.snmp_get(oid)
                return "%s = STRING: %s" % (oid, value)
            else:
                results = self.snmp_walk(oid)
                if not results:
                    try:
                        value = self.snmp_get(oid)
                        return "%s = STRING: %s" % (oid, value)
                    except Exception:
                        return ""

                output_lines = []
                for oid_str, value in results:
                    # 识别 label(number) 形式，例如 fan(7)、module(9)
                    m = re.match(r'^\w+\((\d+)\)$', value)
                    if m:
                        output_lines.append("%s = INTEGER: %s" % (oid_str, m.group(1)))
                    elif value.isdigit():
                        output_lines.append("%s = INTEGER: %s" % (oid_str, value))
                    elif value.startswith("1.3.6.1"):
                        output_lines.append("%s = OID: %s" % (oid_str, value))
                    else:
                        output_lines.append("%s = STRING: %s" % (oid_str, value))
                return '\n'.join(output_lines)
        except Exception as e:
            # 返回空字符串以保持兼容性
            return ""

    def extract_value(self, snmp_output):
        """从SNMP输出中提取值"""
        if not snmp_output:
            return ""

        # 处理STRING类型
        if "STRING:" in snmp_output:
            match = re.search(r'STRING: "(.*?)"$|STRING: (.*?)$', snmp_output)
            if match:
                return match.group(1) or match.group(2) or ""
        # 处理INTEGER类型
        elif "INTEGER:" in snmp_output:
            match = re.search(r'INTEGER: (\d+)', snmp_output)
            if match:
                return match.group(1)
        # 处理OID类型
        elif "OID:" in snmp_output:
            match = re.search(r'OID: ([^\s]+)$', snmp_output)
            if match:
                return match.group(1)
        else:
            # 检查是否包含SNMP错误值
            for error_value in SNMP_ERROR_VALUES:
                if error_value in snmp_output:
                    return ""

        # 如果无法匹配任何已知格式返回原始值
        return snmp_output.strip()

    def extract_index_from_oid(self, line):
        """从OID行提取索引值"""
        try:
            last_part = line.split(' = ')[0]
            index = last_part.split('.')[-1]
            return index
        except Exception:
            return None

    def convert_power_to_watts(self, power_value):
        """将功率值从mW转换为W"""
        try:
            power_mw = float(power_value)
            power_w = power_mw / 1000.0
            return power_w
        except (ValueError, TypeError):
            return 0.0

    def get_entity_indexes(self, entity_types):
        """获取指定类型的实体索引列表"""
        indexes = {6: [], 7: [], 9: []}  # 6:电源, 7:风扇, 9:模块
        entity_type_result = self.snmp_collect(self.ENTITY_PHYSICAL_CLASS_OID)

        for line in entity_type_result.splitlines():
            for entity_type in entity_types:
                if "INTEGER: {0}".format(entity_type) in line:
                    index = self.extract_index_from_oid(line)
                    if index:
                        indexes[entity_type].append(index)
        return indexes

    def get_removable_status(self, index):
        """获取设备是否可插拔状态"""
        try:
            removable_val = self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_REMOVABLE_OID, index)))
            if removable_val == "1":
                return "可插拔"
            elif removable_val == "2":
                return "不可插拔"
            return "未知"
        except Exception:
            return "未知"

    def collect_fan_info(self):
        """采集风扇信息的基础方法"""
        fan_info_list = []
        entity_indexes = self.get_entity_indexes([7])
        fan_indexes = entity_indexes[7]

        if not fan_indexes:
            print
            u"未找到风扇信息"
            return []

        for index in fan_indexes:
            try:
                fan_info = {
                    "name": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_NAME_OID, index))),
                    "brand": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_MANUFACTURER_OID, index))),
                    "model": self.get_model_with_fallback(index),
                    "sn": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_SERIAL_OID, index))),
                    "currentReading": self.get_current_reading_safe(index),
                    "type": self.get_removable_status(index)
                }

                # 子类通过重写get_additional_fan_info方法添加额外信息
                additional_info = self.get_additional_fan_info(index)
                if additional_info:
                    fan_info.update(additional_info)

                fan_info_list.append(fan_info)
            except Exception as e:
                print
                u"采集风扇 {0} 信息出错: {1}".format(index, unicode(e))
                continue

        return fan_info_list

    def collect_power_info(self):
        """采集电源信息"""
        power_info_list = []
        entity_indexes = self.get_entity_indexes([6])
        power_indexes = entity_indexes[6]

        if not power_indexes:
            print
            u"未找到电源信息"
            return []

        for index in power_indexes:
            try:
                power_info = {
                    "name": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_NAME_OID, index))),
                    "sn": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_SERIAL_OID, index))),
                    "brand": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_MANUFACTURER_OID, index))),
                    "model": self.get_model_with_fallback(index),
                    "type": self.get_removable_status(index)
                }

                # 添加额外信息
                additional_info = self.get_additional_power_info(index)
                if additional_info:
                    power_info.update(additional_info)

                power_info_list.append(power_info)
            except Exception as e:
                print
                u"采集电源 {0} 信息出错: {1}".format(index, unicode(e))
                continue

        return power_info_list

    def get_additional_fan_info(self, index):
        """获取风扇额外信息"""
        return {}

    def get_additional_power_info(self, index):
        """获取电源额外信息"""
        return {}

    def is_network_interface_card(self, index):
        """判断是否为网卡
        通过描述信息判断是否包含特定关键词来确定是否为网卡
        """
        try:
            description = self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_DESCR_OID, index)))
            if not description:
                return False

            # 网卡关键词列表
            keywords = [
                "Interface Card",
                "(PIC)",
                "10GE",
                "Network Interface"
            ]

            description = description.upper()
            return any(keyword.upper() in description for keyword in keywords)
        except Exception:
            return False

    def collect_network_info(self):
        """采集网卡信息"""
        network_info_list = []
        entity_indexes = self.get_entity_indexes([9])
        network_indexes = entity_indexes[9]

        if not network_indexes:
            print
            u"未找到网卡信息"
            return []

        for index in network_indexes:
            try:
                # 判断是否为网卡
                if not self.is_network_interface_card(index):
                    continue

                network_info = {
                    "name": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_NAME_OID, index))),
                    "brand": self.extract_value(
                        self.snmp_collect("{0}.{1}".format(self.ENTITY_MANUFACTURER_OID, index))),
                    "model": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_MODEL_OID, index))),
                    "sn": self.extract_value(self.snmp_collect("{0}.{1}".format(self.ENTITY_SERIAL_OID, index))),
                    "type": self.get_removable_status(index)
                }

                # 添加额外信息
                additional_info = self.get_additional_network_info(index)
                if additional_info:
                    network_info.update(additional_info)

                network_info_list.append(network_info)
            except Exception as e:
                print
                u"采集网卡 {0} 信息出错: {1}".format(index, unicode(e))
                continue

        return network_info_list

    def get_additional_network_info(self, index):
        """获取网卡额外信息"""
        return {}


class HuaweiDeviceCollector(BaseDeviceCollector):
    def __init__(self, ip, community, snmp_version="2c", auth_data=None, port=161):
        super(HuaweiDeviceCollector, self).__init__(ip, community, snmp_version, auth_data, port)
        # 华为特有的OID
        self.HUAWEI_ENTITY_HEALTH_OID = "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.2"  # 实体状态
        self.HUAWEI_ENTITY_POWER_OID = "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.24"  # 最后输出功率，该节点查询为0时代表无效值，不支持查询。默认查询结果为实时功耗。不支持实时功耗监控的设备，查询结果为额定功耗。
        self.HUAWEI_POWER_DESC_OID = "1.3.6.1.4.1.2011.5.25.31.1.1.2.1.2"  # 实体描述
        self.HUAWEI_PATCH_OID = "1.3.6.1.4.1.2011.5.25.19.1.8.5.1.1.4"

    def get_additional_fan_info(self, index):
        """获取华为风扇特有的额外信息"""
        try:
            health_val = self.extract_value(self.snmp_collect("{0}.{1}".format(self.HUAWEI_ENTITY_HEALTH_OID, index)))
            power_mw = self.extract_value(self.snmp_collect("{0}.{1}".format(self.HUAWEI_ENTITY_POWER_OID, index)))

            return {
                "health": DEVICE_STATUS_MAP.get(health_val, u"未知状态"),
                "lastPowerOutputWatts": self.convert_power_to_watts(power_mw)
            }
        except Exception:
            return {}

    def get_additional_power_info(self, index):
        """获取华为电源特有的额外信息"""
        try:
            health_val = self.extract_value(self.snmp_collect("{0}.{1}".format(self.HUAWEI_ENTITY_HEALTH_OID, index)))
            last_power_output_mw = self.extract_value(
                self.snmp_collect("{0}.{1}".format(self.HUAWEI_ENTITY_POWER_OID, index)))
            description = self.extract_value(self.snmp_collect("{0}.{1}".format(self.HUAWEI_POWER_DESC_OID, index)))

            power_output_watts = 0.0
            if description:
                power_match = re.search(r'(\d+\.?\d*)V/(\d+\.?\d*)A', description)
                if power_match:
                    try:
                        voltage = float(power_match.group(1))
                        current = float(power_match.group(2))
                        power_output_watts = round(voltage * current, 2)
                    except (ValueError, IndexError):
                        power_output_watts = 0.0

            return {
                "state": DEVICE_STATUS_MAP.get(health_val, u"未知状态"),
                "powerOutputWatts": power_output_watts,
                "lastPowerOutputWatts": self.convert_power_to_watts(last_power_output_mw)
            }
        except Exception:
            return {}

    def get_additional_network_info(self, index):
        """获取华为网卡特有的额外信息"""
        try:
            power_mw = self.extract_value(self.snmp_collect("{0}.{1}".format(self.HUAWEI_ENTITY_POWER_OID, index)))
            return {
                "lastPowerOutputWatts": self.convert_power_to_watts(power_mw)
            }
        except Exception:
            return {}

    def get_patch_info(self):
        try:
            patch_version = self.extract_value(self.snmp_collect(self.HUAWEI_PATCH_OID))
            return patch_version
        except Exception:
            return ""


class CollectPort(Thread):
    def __init__(self, ipinfo):
        Thread.__init__(self)
        self.ip = ipinfo.get("ip", None)
        self.port = ipinfo.get("port", 161)
        self.sysname = ipinfo.get("cSysName", None)
        self.auth_data = ipinfo.get("authData", None)
        self.snmp_version = ipinfo.get("snmpVersion", None)
        self.device_brand = ipinfo.get("brand", None)
        self.community = ipinfo.get("community", None)  # 添加community属性
        self.res_If = {}
        self.port2port = {}

    def snmp_func(self, oid):
        res = []
        # 创建新的target以增加超时时间
        target = UdpTransportTarget((self.ip, self.port), timeout=10, retries=1)

        # 检查是否是单一值OID
        if isinstance(oid, str):
            oid_to_use = ObjectIdentity(oid)
        else:
            oid_to_use = oid

        is_single_value = False
        if isinstance(oid, str) and oid.endswith('.0'):
            is_single_value = True
        # 针对特定的MIB对象特殊处理
        elif isinstance(oid, ObjectIdentity) or (isinstance(oid, tuple) and len(oid) >= 2):
            # 对于MIB对象，如ObjectIdentity('SNMPv2-MIB', 'sysName')，视为单值查询
            if isinstance(oid, tuple) and oid[1] in ['sysName', 'sysDescr', 'sysUpTime', 'sysLocation', 'sysContact']:
                is_single_value = True
            elif isinstance(oid, ObjectIdentity) and hasattr(oid, '_args') and len(oid._args) >= 2:
                if oid._args[1] in ['sysName', 'sysDescr', 'sysUpTime', 'sysLocation', 'sysContact']:
                    is_single_value = True

        if is_single_value:
            # 使用getCmd获取单一值
            errorIndication, errorStatus, errorIndex, varBinds = next(
                getCmd(SnmpEngine(),
                       self.auth_data,
                       target,
                       ContextData(),
                       ObjectType(oid_to_use))
            )
            if errorIndication:
                print
                "SNMP Get Error: %s" % errorIndication
                return res
            if errorStatus:
                print
                "SNMP Get Error: %s" % errorStatus
                return res
            if varBinds:
                for varBind in varBinds:
                    res.append((varBind[0].prettyPrint(), varBind[1].prettyPrint()))
        else:
            # 使用nextCmd获取多个值
            for (error, _, _, var) in nextCmd(SnmpEngine(),
                                              self.auth_data,
                                              target,
                                              ContextData(),
                                              ObjectType(oid_to_use),
                                              lexicographicMode=False):
                if error != None:
                    continue
                res.append((var[0][0].prettyPrint(), var[0][1].prettyPrint()))
        return res

    def run_cmd(self):
        self.run()
        return self.res_If.values()

    def run(self):
        # 申请线程资源
        threadLimiter = BoundedSemaphore(20)
        threadLimiter.acquire()

        # try:
        res = self.snmp_func(ObjectIdentity('SNMPv2-MIB', 'sysName'))
        if not res:
            print("ip:{} SNMP error, {}".format(self.ip, res))
            return
        if not self.sysname:
            print("{} not sysname, continue".format(self.ip))
            return
        if self.snmp_version == "2c" and not self.community:
            print("{} not add community, continue".format(self.ip))
            return
        if not self.snmp_version:
            print("{} not add snmpversion, continue".format(self.ip))
            return

        # 🔴各阶段独立异常防护（2026-10-19 修复：collect_info 异常曾中断 start_info_format，
        # 导致 res_If 已填充但 name 未生成——上报唯一键 name 缺失报错的根因）
        for stage in (self.collect_info, self.start_info_format, self.mac, self.arp, self.lldp):
            try:
                stage()
            except Exception as e:
                print("{} stage {} exception: {}".format(self.ip, stage.__name__, e))

        # 释放线程资源
        threadLimiter.release()

    def collect_info(self):
        '''
        采集cmdb中正则的snmp数据
        :return:
        '''
        '''
        采集cmdb中正则的snmp数据
        :return:
        '''
        for (errorIndication, _, _, line) in bulkCmd(SnmpEngine(),
                                                     self.auth_data,
                                                     UdpTransportTarget((self.ip, self.port), timeout=2, retries=0),
                                                     ContextData(),
                                                     0,
                                                     30,
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifName')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifType')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifMtu')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifSpeed')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifPhysAddress')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifAdminStatus')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifOperStatus')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifAlias')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifDescr')),
                                                     ObjectType(ObjectIdentity('IF-MIB', 'ifIndex')),
                                                     lexicographicMode=False):
            if errorIndication != None:
                continue
            else:
                key = str(line[9][1])
                name = line[0][1].prettyPrint()
                alias = line[7][1].prettyPrint()
                if is_snmp_error_value(name):
                    # 部分路由器没有ifName和ifAlias，使用ifDescr替代
                    name = line[8][1].prettyPrint()
                    alias = line[8][1].prettyPrint()
                self.res_If[key] = {
                    "ifName": name,
                    "type": line[1][1].prettyPrint(),
                    "mtu": line[2][1].prettyPrint(),
                    "speed": line[3][1].prettyPrint(),
                    "physAddress": line[4][1].prettyPrint(),
                    "adminStatus": line[5][1].prettyPrint(),
                    "operStatus": line[6][1].prettyPrint(),
                    "ifAlias": alias,
                    "ifDescr": line[8][1].prettyPrint(),
                    "ifIndex": key,
                }

    def start_info_format(self):
        '''
        处理采集的数据
        :return:
        '''
        self.netport_relation = []
        
        # 需要过滤掉的接口类型
        filter_patterns = [
            "Virtual-Template",
            "InLoopBack", 
            "NULL",
            "Loopback",
            "Vlan",
            "Management",
            "Mgmt"
        ]
        
        for _, value in self.res_If.items():
            # oid not found
            for key, val in value.items():
                if is_snmp_error_value(val):
                    value[key] = ""
            ifName = value.get('ifName') or value.get('ifDescr')
            
            # 过滤掉不需要的接口
            should_filter = False
            if ifName:
                for pattern in filter_patterns:
                    if pattern in ifName:
                        should_filter = True
                        break
            
            if should_filter:
                continue

            # ifName/ifDescr 均为空——无法生成有效唯一键，跳过该端口（防 "ip:" 脏数据）
            if not ifName:
                continue

            name = "%s:%s" % (self.ip, ifName)

            value['name'] = name
            value["deviceIP"] = self.ip
            # value['snmpIp'] = EASYOPS_LOCAL_IP
            value['sysName'] = "%s:%s" % (self.sysname, ifName)
            value['deviceType'] = "路由器"

            self.netport_relation.append(
                {"right_instance": {"cSysName": self.sysname}, "left_instance": {"name": name}})

    def lldp(self):
        # {"portDesc": idx}
        port_index = {v.get("ifDescr"): k for k, v in self.res_If.items()}

        snmp_inst = get_snmp_inst(
            device_type=self.device_brand,
            ip=self.ip,
            rd=self.community,
            wr="",
            port=self.port,
            snmp_version=self.snmp_version,
            auth_data=self.auth_data
        )
        related_host, related_ports = snmp_inst.run()
        
        # 如果接口信息为空，直接从LLDP信息创建端口信息
        if not self.res_If and related_ports:
            for i, item in enumerate(related_ports):
                port_idx = str(i + 1)  # 使用序号作为端口索引
                self.res_If[port_idx] = {
                    'ifDescr': item["port"],
                    'ifName': item["port"],
                    'name': "{}:{}".format(self.ip, item["port"]),
                    'deviceIP': self.ip,
                    'sysName': "{}:{}".format(self.sysname, item["port"]) if self.sysname else "{}:{}".format(self.ip, item["port"]),
                    'deviceType': "路由器",
                    'lldp': [{
                        "name": item["peer_device"] + ":" + item["peer_port"],
                        "peer_port": item["peer_port"],
                        "peer_device": item["peer_device"]
                    }]
                }
        else:
            # 正常的端口映射逻辑 - 改进端口名称匹配
            for item in related_ports:
                # 尝试多种端口名称匹配方式
                port_idx = None
                lldp_port = item["port"]
                
                # 清理端口名称中的STRING:前缀
                if isinstance(lldp_port, basestring) and lldp_port.startswith('STRING: '):
                    lldp_port = lldp_port[8:]
                
                # 1. 直接匹配
                port_idx = port_index.get(lldp_port)
                if not port_idx:
                    # 2. 尝试匹配端口名称的关键部分
                    for if_descr, idx in port_index.items():
                        # 提取端口名称的关键部分进行比较
                        if self._is_port_match(lldp_port, if_descr):
                            port_idx = idx
                            break
                
                if port_idx:
                    peer_name = "%s:%s" % (item["peer_device"], item["peer_port"])
                    self.port2port.setdefault(self.res_If[port_idx]['sysName'], peer_name)
                    self.res_If[port_idx]['lldp'] = [{
                        "name": item["peer_device"] + ":" + item["peer_port"],
                        "peer_port": item["peer_port"],
                        "peer_device": item["peer_device"]
                    }]

    def _is_port_match(self, lldp_port, if_descr):
        """
        判断LLDP端口名称和接口描述是否匹配
        支持模糊匹配，例如: "100GE0/11/0" 和 "100GE0/11/1" 应该匹配
        """
        # 如果完全匹配，直接返回True
        if lldp_port == if_descr:
            return True
        
        # 尝试按'/'分割，比较前两部分
        lldp_parts = str(lldp_port).split('/')
        if_parts = str(if_descr).split('/')
        
        if len(lldp_parts) >= 2 and len(if_parts) >= 2:
            # 比较前两部分（例如: "100GE0/11" vs "100GE0/11"）
            if lldp_parts[0] == if_parts[0] and lldp_parts[1] == if_parts[1]:
                return True
        
        # 尝试比较基础端口类型（例如: "100GE0" vs "100GE0"）
        if len(lldp_parts) >= 1 and len(if_parts) >= 1:
            if lldp_parts[0] == if_parts[0]:
                return True
        
        return False

    def mac(self):
        n = 0
        for (error, _, _, var) in nextCmd(SnmpEngine(),
                                          self.auth_data,
                                          UdpTransportTarget((self.ip, self.port)),
                                          ContextData(),
                                          ObjectType(ObjectIdentity('BRIDGE-MIB', 'dot1dTpFdbPort')),
                                          ObjectType(ObjectIdentity('BRIDGE-MIB', 'dot1dTpFdbAddress')),
                                          lexicographicMode=False):
            if error != None:
                continue
            n += 1
            idx = str(var[0][1])
            if idx in self.res_If:
                if "cam" in self.res_If[idx]:
                    self.res_If[idx]["cam"].append({"mac": var[1][1].prettyPrint()})
                else:
                    self.res_If[idx]["cam"] = [{"mac": var[1][1].prettyPrint()}, ]
            if n >= 1000:
                logging.warning("Router {} mac 表达到 1000 条，提前退出mac采集".format(self.ip))
                break

    def arp(self):
        '''
        处理arp表  oid = ipNetToMediaPhysAddress
        :param snmp_func:
        :param ip:
        :param community:
        :param oid:
        :return:
        '''
        ipNetToMediaPhysAddress = self.snmp_func(ObjectIdentity('IP-MIB', 'ipNetToMediaPhysAddress'))
        # [('30', '192.168.10.67', '94:f6:d6:20:85:40'),]
        n = 0
        for k, mac in ipNetToMediaPhysAddress:
            n += 1
            oidList = k.split(".", 2)
            idx = oidList[1]
            ip = oidList[2]
            if idx in self.res_If:
                if "arp" in self.res_If[idx]:
                    self.res_If[idx]["arp"].append({"mac": mac, "ip": ip})
                else:
                    self.res_If[idx]["arp"] = [{"mac": mac, "ip": ip}, ]
            if n >= 1000:
                logging.warning("Router {} arp 表达到 1000 条，提前退出arp采集".format(self.ip))
                break

    # 计算网段
    def collect_prefix(self):
        """
        采集IP-MIB::ipAdEntNetMask，并解析出IP地址及其对应的子网掩码
        """
        netmask_data = self.snmp_func(ObjectIdentity('IP-MIB', 'ipAdEntNetMask'))

        ip_netmask_mapping = {}
        ip_pattern = re.compile(r"(\d+\.\d+\.\d+\.\d+)")
        netmask_pattern = re.compile(r"(\d+\.\d+\.\d+\.\d+)")

        for oid, value in netmask_data:
            ip_match = ip_pattern.search(oid)
            netmask_match = netmask_pattern.search(value)

            if ip_match and netmask_match:
                ip_address = ip_match.group(1)
                netmask = netmask_match.group(1)
                ip_netmask_mapping[ip_address] = netmask

        prefix_data = []
        for ip_str, netmask in ip_netmask_mapping.items():
            ip_obj = ipaddress.ip_address(unicode(ip_str))
            if not ip_obj.is_private:
                continue

            network = ipaddress.IPv4Network(u"{}/{}".format(ip_str, netmask), strict=False)
            prefix_data.append({
                "dims": {
                    "objectId": "PREFIX@ONEMODEL",
                    "object_id": "PREFIX@ONEMODEL",
                    "pks": ["prefix"],
                    "upsert": True,
                },
                "vals": {
                    "prefix": str(network),
                    "status": "Active",
                    "family": "IPv4"
                }
            })

        return prefix_data


def get_cmd(auth_data, target, context_data, oids):
    res = []
    # 创建新的target以增加超时时间
    target = UdpTransportTarget((target.transportAddr[0], target.transportAddr[1]),
                                timeout=10,
                                retries=1,
                                tagList=target.tagList)
    for (error, _, _, var_binds) in getCmd(
            SnmpEngine(),
            auth_data,
            target,
            context_data,
            *[ObjectType(ObjectIdentity(oid)) for oid in oids]
    ):
        if error != None:
            raise Exception("SNMP getCmd failed, IP: %s, OID: %s, error: %s" % (target, oids, error))
        for var_bind in var_binds:
            res.append((str(var_bind[0]), var_bind[1].prettyPrint()))
    return res


def next_cmd(auth_data, target, context_data, oids):
    res = []
    # 创建新的target以增加超时时间
    target = UdpTransportTarget((target.transportAddr[0], target.transportAddr[1]),
                                timeout=10,
                                retries=1,
                                tagList=target.tagList)
    for (error, _, _, var_binds) in nextCmd(
            SnmpEngine(),
            auth_data,
            target,
            context_data,
            *[ObjectType(ObjectIdentity(oid)) for oid in oids],
            lexicographicMode=False
    ):
        if error != None:
            raise Exception("SNMP nextCmd failed, IP: %s, OID: %s, error: %s" % (target, oids, error))
        for var_bind in var_binds:
            res.append((str(var_bind[0]), var_bind[1].prettyPrint()))
    return res


class RouterCollector:
    def __init__(self, instance_id, ip, snmp_version, community, oid_type="general", ignore_fields=[],
                 ignore_collect_net="false",
                 username="", auth_protocol="MD5", auth_key="", priv_protocol="AES", priv_key="", port=161):
        self.instanceId = instance_id
        self.ip = ip
        if port is None or port == "null":
            self.port = 161
        else:
            self.port = port
        self.snmp_version = "2c"
        if snmp_version:
            self.snmp_version = snmp_version
        if self.snmp_version == "3":
            if PROTOCOL_MAP.get(auth_protocol) is None:
                raise Exception("Invalid auth protocol: %s" % auth_protocol)
            if PROTOCOL_MAP.get(priv_protocol) is None:
                raise Exception("Invalid priv protocol: %s" % priv_protocol)
            self.auth_data = UsmUserData(username,
                                         authKey=auth_key,
                                         privKey=priv_key,
                                         authProtocol=PROTOCOL_MAP.get(auth_protocol),
                                         privProtocol=PROTOCOL_MAP.get(priv_protocol))
        else:
            self.auth_data = CommunityData(community)
        # 增加超时和重试设置
        self.target = UdpTransportTarget((self.ip, self.port), timeout=10, retries=1)
        self.context_data = ContextData()
        self.community = community
        self.oid_type = oid_type
        self.ignore_fields = ignore_fields
        self.ignore_collect_net = ignore_collect_net

    def check_ip_accessible(self):
        import subprocess
        try:
            # 使用 nc 进行 UDP 端口探测
            with open(os.devnull, 'w') as devnull:
                result = subprocess.call(
                    ["nc", "-w", "3", "-zv", "-u", self.ip, str(self.port)],
                    stdout=devnull,
                    stderr=devnull,
                )
            return result == 0
        except Exception:
            return False

    def check_snmp_accessible(self):
        """
        使用 SNMP get 请求探测 SNMP 服务可用性
        使用 sysDescr OID (1.3.6.1.2.1.1.1.0) 进行探测
        """
        try:
            # 使用已有的 get_cmd 函数
            cmd_res = get_cmd(self.auth_data, self.target, self.context_data, ['1.3.6.1.2.1.1.1.0'])
            # 如果成功获取到结果，说明 SNMP 服务可用
            return len(cmd_res) > 0
        except Exception:
            return False

    def start(self):
        import logging
        if not self.instanceId:
            logging.error(u'设备 instanceId 信息为空，采集终止！')
            return []
        if not self.ip:
            logging.error(u'设备 IP 信息为空，采集终止！')
            return []

        # Check if the IP and port are accessible
        if not self.check_ip_accessible():
            logging.error(u'无法连接到IP: {} 端口: {}，采集终止！'.format(self.ip, self.port))
            exit(1)

        # Check if the SNMP service is accessible
        if not self.check_snmp_accessible():
            logging.error(u'无法连接到SNMP服务，采集终止！')
            exit(1)

        data_all = []
        vals = {
            "instanceId": self.instanceId,
        }

        oids = OID_MAP.get(self.oid_type)
        if not oids:
            print
            u'获取 oids 失败，oid_type={}，采集终止！'.format(self.oid_type)
            return []

        for oid_info in oids:
            oid = oid_info.get("oid")
            cmdb_field = oid_info.get("cmdb_field")
            regex_pattern = oid_info.get("regex_pattern")

            try:
                # 根据oid类型选择不同的获取方法
                if "1.3.6.1.2.1.1.5.0" in oid or "1.3.6.1.2.1.1.1.0" in oid or "1.3.6.1.2.1.1.3.0" in oid:
                    # 使用get_cmd获取系统信息
                    cmd_res = get_cmd(self.auth_data, self.target, self.context_data, [oid])
                else:
                    # 使用next_cmd获取其他信息
                    cmd_res = next_cmd(self.auth_data, self.target, self.context_data, [oid])

                for oid_result, value in cmd_res:
                    pattern = re.compile(regex_pattern)
                    match = pattern.search(value)
                    if match:
                        for group in match.groups():
                            if group:
                                vals[cmdb_field] = group
                                break
            except Exception as e:
                logging.error(u"获取 {} 信息失败: {}".format(oid, str(e)))
                continue

        # format
        vals = format_info(vals)

        # 端口信息采集
        collect_port = CollectPort({
            "ip": self.ip,
            "port": self.port,
            "authData": self.auth_data,
            "community": self.community,
            "cSysName": vals.get("cSysName"),
            "snmpVersion": self.snmp_version
        })
        netdports = collect_port.run_cmd()
        netdports_name = []
        if netdports:
            for netdport in netdports:
                # 终极防线：唯一键 name 缺失的行不上报（上报必被平台拒），告警留痕
                if not netdport.get("name"):
                    print("WARN: NETDPORT drop row without name: ifIndex=%s ifName=%s ifDescr=%s" % (
                        netdport.get("ifIndex"), netdport.get("ifName"), netdport.get("ifDescr")))
                    continue
                data_all.append({
                    "dims": {
                        "objectId": "NETDPORT@ONEMODEL",
                        "object_id": "NETDPORT@ONEMODEL",
                        "pks": ["name"],
                        "upsert": True,
                    },
                    "vals": netdport
                })
                if netdport.get("name"):
                    netdports_name.append({"name": netdport.get("name")})

        # 添加网段信息
        if self.ignore_collect_net == "false":
            prefix_data = collect_port.collect_prefix()
            data_all.extend(prefix_data)

        vals["netdports"] = netdports_name
        # 添加风扇和电源信息采集
        device_collector = None
        if vals.get("cBrand") == BrandKeyHuawei:
            device_collector = HuaweiDeviceCollector(self.ip, self.community, self.snmp_version, self.auth_data,
                                                     self.port)
        else:
            device_collector = BaseDeviceCollector(self.ip, self.community, self.snmp_version, self.auth_data,
                                                   self.port)

        # 采集风扇信息
        fan_info_list = device_collector.collect_fan_info()
        if fan_info_list:
            vals["fanInfo"] = fan_info_list

        # 采集电源信息
        power_info_list = device_collector.collect_power_info()
        if power_info_list:
            vals["powersInfo"] = power_info_list

        # 采集网卡信息
        network_info_list = device_collector.collect_network_info()
        if network_info_list:
            vals["networkInfo"] = network_info_list

        # 采集补丁
        if vals.get("cBrand") == BrandKeyHuawei:
            patch_version = device_collector.get_patch_info()
            if patch_version:
                vals["cPatch"] = [patch_version]

        for field in self.ignore_fields:
            if field in vals:
                del vals[field]

        data = {
            "dims": {
                "objectId": "ROUTER@ONEMODEL",
                "object_id": "ROUTER@ONEMODEL",
                "pks": ["instanceId"],
                "upsert": True,
                "set_relation_ids": [
                    "netdports"
                ]
            },
            "vals": vals
        }
        data_all.append(data)
        return data_all


def subtract_timeticks(timeticks_str):
    try:
        milliseconds = int(timeticks_str) * 10
    except ValueError:
        return timeticks_str

    current_time = datetime.datetime.now()
    delta = datetime.timedelta(milliseconds=milliseconds)
    result_time = current_time - delta
    return result_time.strftime("%Y-%m-%d")


def format_info(vals):
    # brand
    if vals.get("cBrand"):
        brand = vals.get("cBrand").lower()
        if "cisco" in brand:
            vals["cBrand"] = BrandKeyCisco
        elif "h3c" in brand:
            vals["cBrand"] = BrandKeyH3C
        elif "huawei" in brand:
            vals["cBrand"] = BrandKeyHuawei
        elif "hillstone" in brand:
            vals["cBrand"] = BrandKeyHillstone

    # date
    up_date = subtract_timeticks(vals.get("cUpTime", ""))
    vals["cUpTime"] = up_date

    return vals


if __name__ == "__main__":
    try:
        ignore_field_list = []
        if ignore_fields:
            ignore_field_list = ignore_fields.split(",")
        router_collector = RouterCollector(
            instanceId,
            ip,
            snmp_version=snmp_version,
            community=community,
            ignore_fields=ignore_field_list,
            ignore_collect_net=ignore_collect_net,
            username=username,
            auth_protocol=authProtocol,
            auth_key=authKey,
            priv_protocol=privProtocol,
            priv_key=privKey,
            port=port
        )
        data = router_collector.start()

        logging.info("Collect datas size: %d" % len(data))
        logging.info(json.dumps(data, indent=2))
        print("-----BEGIN GATHERING DATA-----")
        print(json.dumps(data, indent=2))
        print("-----END GATHERING DATA-----")
    except CollectException as e:
        print e.message

