# -*- coding: utf-8 -*-
import os

logLevel = os.environ.get("EASYOPS_COLLECTOR_logLevel")
instanceId = os.environ.get("EASYOPS_COLLECTOR_instanceId")
ip = os.environ.get("EASYOPS_COLLECTOR_ip")
snmpPort = os.environ.get("EASYOPS_COLLECTOR_snmpPort")
snmpVersion = os.environ.get("EASYOPS_COLLECTOR_snmpVersion")
community = os.environ.get("EASYOPS_COLLECTOR_community")
securityLevel = os.environ.get("EASYOPS_COLLECTOR_securityLevel")
securityName = os.environ.get("EASYOPS_COLLECTOR_securityName")
authProtocol = os.environ.get("EASYOPS_COLLECTOR_authProtocol")
authKey = os.environ.get("EASYOPS_COLLECTOR_authKey")
privProtocol = os.environ.get("EASYOPS_COLLECTOR_privProtocol")
privKey = os.environ.get("EASYOPS_COLLECTOR_privKey")
contextName = os.environ.get("EASYOPS_COLLECTOR_contextName")
old_cpuInfo = os.environ.get("EASYOPS_COLLECTOR_old_cpuInfo")
old_memoryInfo = os.environ.get("EASYOPS_COLLECTOR_old_memoryInfo")
old_diskInfo = os.environ.get("EASYOPS_COLLECTOR_old_diskInfo")
old_logicalDrives = os.environ.get("EASYOPS_COLLECTOR_old_logicalDrives")
old_networkInfo = os.environ.get("EASYOPS_COLLECTOR_old_networkInfo")
old_hbaInfo = os.environ.get("EASYOPS_COLLECTOR_old_hbaInfo")
"""EasyOps 原生 CMDB 采集脚本；单文件执行并输出 GATHERING DATA。"""

import binascii
import json
import logging
import math
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import traceback
import uuid

VERSION = "0.1.15"
PROFILES = json.loads('{"generic": {"id": "generic", "vendor": null, "prefixes": [], "aliases": [], "status": "standard-mibs-only", "scalars": {}, "tables": []}, "dell-idrac": {"id": "dell-idrac", "vendor": "Dell", "prefixes": ["1.3.6.1.4.1.674.10892.5"], "aliases": ["idrac"], "status": "mib-defined-not-device-tested", "scalars": {"sn": {"symbol": "systemServiceTag", "oid": "1.3.6.1.4.1.674.10892.5.1.3.2.0", "convert": "text"}, "mdl": {"symbol": "systemModelName", "oid": "1.3.6.1.4.1.674.10892.5.1.3.12.0", "convert": "text"}}, "tables": [{"kind": "cpuInfo", "root": "1.3.6.1.4.1.674.10892.5.4.1100.30.1", "fields": {"name": {"symbol": "processorDeviceFQDD", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.30.1.26", "column": "26", "convert": "text"}, "mdl": {"symbol": "processorDeviceBrandName", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.30.1.23", "column": "23", "convert": "text"}, "manufacturer": {"symbol": "processorDeviceManufacturerName", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.30.1.8", "column": "8", "convert": "text"}, "totalCores": {"symbol": "processorDeviceCoreCount", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.30.1.17", "column": "17", "convert": "positive"}, "totalThreads": {"symbol": "processorDeviceThreadCount", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.30.1.19", "column": "19", "convert": "positive"}, "maxSpeedMHz": {"symbol": "processorDeviceMaximumSpeed", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.30.1.11", "column": "11", "convert": "positive"}}, "required": ["mdl"]}, {"kind": "memoryInfo", "root": "1.3.6.1.4.1.674.10892.5.4.1100.50.1", "fields": {"name": {"symbol": "memoryDeviceLocationName", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.50.1.8", "column": "8", "convert": "text"}, "type": {"symbol": "memoryDeviceType", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.50.1.7", "column": "7", "convert": "enum", "values": {"3": "deviceTypeIsDRAM", "4": "deviceTypeIsEDRAM", "5": "deviceTypeIsVRAM", "6": "deviceTypeIsSRAM", "7": "deviceTypeIsRAM", "8": "deviceTypeIsROM", "9": "deviceTypeIsFLASH", "10": "deviceTypeIsEEPROM", "11": "deviceTypeIsFEPROM", "12": "deviceTypeIsEPROM", "13": "deviceTypeIsCDRAM", "14": "deviceTypeIs3DRAM", "15": "deviceTypeIsSDRAM", "16": "deviceTypeIsSGRAM", "17": "deviceTypeIsRDRAM", "18": "deviceTypeIsDDR", "19": "deviceTypeIsDDR2", "20": "deviceTypeIsDDR2FBDIMM", "24": "deviceTypeIsDDR3", "25": "deviceTypeIsFBD2", "26": "deviceTypeIsDDR4"}}, "frequencyMHz": {"symbol": "memoryDeviceSpeed", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.50.1.15", "column": "15", "convert": "positive_text"}, "memoryFactor": {"symbol": "memoryDeviceManufacturerName", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.50.1.21", "column": "21", "convert": "text"}, "memorySize": {"symbol": "memoryDeviceSize", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.50.1.15", "column": "14", "convert": "kib_to_gb_string", "unknown": [0, 2147483647]}}, "required": ["memorySize"], "presence": {"column": "14", "absent": [0], "unknown": [2147483647]}, "summary": {"field": "memorySize", "column": "14", "divisor": 1048576, "mode": "exact_int"}}, {"kind": "diskInfo", "root": "1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1", "fields": {"name": {"symbol": "physicalDiskName", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.2", "column": "2", "convert": "text"}, "mdl": {"symbol": "physicalDiskProductID", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.6", "column": "6", "convert": "text"}, "manufacturer": {"symbol": "physicalDiskManufacturer", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.3", "column": "3", "convert": "text"}, "capacityGB": {"symbol": "physicalDiskCapacityInMB", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.11", "column": "11", "convert": "mib_to_gb_int"}, "mediaType": {"symbol": "physicalDiskMediaType", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.35", "column": "35", "convert": "enum", "values": {"2": "hdd", "3": "ssd"}}, "status": {"symbol": "physicalDiskState", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.130.4.1.4", "column": "4", "convert": "enum", "values": {"2": "ready", "3": "online", "4": "foreign", "5": "offline", "6": "blocked", "7": "failed", "8": "nonraid", "9": "removed", "10": "readonly"}}}, "required": ["mdl"], "summary": {"field": "diskSize", "column": "11", "divisor": 1024, "mode": "text"}}, {"kind": "logicalDrives", "root": "1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1", "fields": {"name": {"symbol": "virtualDiskName", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.2", "column": "2", "convert": "text"}, "capacity": {"symbol": "virtualDiskSizeInMB", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.6", "column": "6", "convert": "mib_to_gb_float"}, "raidType": {"symbol": "virtualDiskLayout", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.13", "column": "13", "convert": "enum", "values": {"2": "r0", "3": "r1", "4": "r5", "5": "r6", "6": "r10", "7": "r50", "8": "r60", "9": "concatRaid1", "10": "concatRaid5"}}, "status": {"symbol": "virtualDiskState", "oid": "1.3.6.1.4.1.674.10892.5.5.1.20.140.1.1.4", "column": "4", "convert": "enum", "values": {"2": "online", "3": "failed", "4": "degraded"}}}, "required": ["capacity"]}, {"kind": "networkPorts", "root": "1.3.6.1.4.1.674.10892.5.4.1100.90.1", "fields": {"ifName": {"symbol": "networkDeviceFQDD", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.90.1.30", "column": "30", "convert": "text"}, "ifDescr": {"symbol": "networkDeviceProductName", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.90.1.6", "column": "6", "convert": "text"}, "physAddress": {"symbol": "networkDevicePermanentMACAddress", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.90.1.16", "column": "16", "convert": "mac"}, "operStatus": {"symbol": "networkDeviceConnectionStatus", "oid": "1.3.6.1.4.1.674.10892.5.4.1100.90.1.4", "column": "4", "convert": "enum", "values": {"1": "connected", "2": "disconnected", "3": "driverBad", "4": "driverDisabled", "10": "hardwareInitalizing", "11": "hardwareResetting", "12": "hardwareClosing", "13": "hardwareNotReady"}}}, "required": ["ifName"]}], "mib": "IDRAC-MIB-SMIv2", "mibSha256": "66ad6e8fb0b1f52659260e39e631297c3125d1bd8d8d04e167d7385a186a0c0e"}, "dell-other": {"id": "dell-other", "vendor": "Dell", "prefixes": ["1.3.6.1.4.1.674"], "aliases": ["dell"], "status": "standard-mibs-only", "scalars": {}, "tables": []}, "lenovo-xcc": {"id": "lenovo-xcc", "vendor": "Lenovo", "prefixes": ["1.3.6.1.4.1.19046.11.1"], "aliases": ["xclarity", "lenovo", "thinksystem"], "status": "mib-defined-not-device-tested", "scalars": {"sn": {"symbol": "machineLevelSerialNumber", "oid": "1.3.6.1.4.1.19046.11.1.1.5.2.1.3.0", "convert": "text"}, "mdl": {"symbol": "machineLevelProductName", "oid": "1.3.6.1.4.1.19046.11.1.1.5.2.1.5.0", "convert": "text"}, "machineUUID": {"symbol": "machineLevelUUID", "oid": "1.3.6.1.4.1.19046.11.1.1.5.2.1.4.0", "convert": "text"}}, "tables": [{"kind": "cpuInfo", "root": "1.3.6.1.4.1.19046.11.1.1.5.20.1", "fields": {"mdl": {"symbol": "cpuVpdDescription", "oid": "1.3.6.1.4.1.19046.11.1.1.5.20.1.2", "column": "2", "convert": "text"}, "id": {"symbol": "cpuVpdIdentifier", "oid": "1.3.6.1.4.1.19046.11.1.1.5.20.1.4", "column": "4", "convert": "text"}, "totalCores": {"symbol": "cpuVpdCores", "oid": "1.3.6.1.4.1.19046.11.1.1.5.20.1.7", "column": "7", "convert": "positive"}, "totalThreads": {"symbol": "cpuVpdThreads", "oid": "1.3.6.1.4.1.19046.11.1.1.5.20.1.8", "column": "8", "convert": "positive"}}, "required": ["mdl"]}, {"kind": "memoryInfo", "root": "1.3.6.1.4.1.19046.11.1.1.5.21.1", "fields": {"name": {"symbol": "memoryVpdDescription", "oid": "1.3.6.1.4.1.19046.11.1.1.5.21.1.2", "column": "2", "convert": "text"}, "type": {"symbol": "memoryVpdType", "oid": "1.3.6.1.4.1.19046.11.1.1.5.21.1.6", "column": "6", "convert": "text"}, "memorySize": {"symbol": "memoryVpdSize", "oid": "1.3.6.1.4.1.19046.11.1.1.5.21.1.7", "column": "7", "convert": "positive_text"}, "frequencyMHz": {"symbol": "memoryConfigSpeed", "oid": "1.3.6.1.4.1.19046.11.1.1.5.21.1.9", "column": "9", "convert": "positive_text"}}, "required": ["memorySize"]}, {"kind": "diskInfo", "root": "1.3.6.1.4.1.19046.11.1.1.13.1.3.1", "fields": {"name": {"symbol": "raidDriveName", "oid": "1.3.6.1.4.1.19046.11.1.1.13.1.3.1.2", "column": "2", "convert": "text"}, "mdl": {"symbol": "raidDriveVPDModel", "oid": "1.3.6.1.4.1.19046.11.1.1.13.1.3.1.16", "column": "16", "convert": "text"}, "manufacturer": {"symbol": "raidDriveVPDManufacture", "oid": "1.3.6.1.4.1.19046.11.1.1.13.1.3.1.13", "column": "13", "convert": "text"}, "capacityGB": {"symbol": "raidDriveCapacity", "oid": "1.3.6.1.4.1.19046.11.1.1.13.1.3.1.12", "column": "12", "convert": "quantity_gb_int"}, "mediaType": {"symbol": "raidDriveMediaType", "oid": "1.3.6.1.4.1.19046.11.1.1.13.1.3.1.8", "column": "8", "convert": "text"}, "status": {"symbol": "raidDriveState", "oid": "1.3.6.1.4.1.19046.11.1.1.13.1.3.1.4", "column": "4", "convert": "text"}}, "required": ["mdl"]}, {"kind": "networkInfo", "root": "1.3.6.1.4.1.19046.11.1.1.14.3.1", "fields": {"name": {"symbol": "adapterNetworkFunctionNetworkVPDProdName", "oid": "1.3.6.1.4.1.19046.11.1.1.14.3.1.2", "column": "2", "convert": "text"}, "model": {"symbol": "adapterNetworkFunctionNetworkVPDModel", "oid": "1.3.6.1.4.1.19046.11.1.1.14.3.1.6", "column": "6", "convert": "text"}, "manufacturer": {"symbol": "adapterNetworkFunctionNetworkVPDManufacturer", "oid": "1.3.6.1.4.1.19046.11.1.1.14.3.1.4", "column": "4", "convert": "text"}, "portCount": {"symbol": "adapterNetworkFunctionPhysicalPortNumber", "oid": "1.3.6.1.4.1.19046.11.1.1.14.3.1.12", "column": "12", "convert": "positive"}}, "required": ["model"]}, {"kind": "convergedPorts", "root": "1.3.6.1.4.1.19046.11.1.1.14.4.1", "fields": {"name": {"symbol": "adapterNetworkPortNetworkVPDProdName", "oid": "1.3.6.1.4.1.19046.11.1.1.14.4.1.2", "column": "2", "convert": "text"}, "address": {"symbol": "adapterNetworkPortPermanentAddress", "oid": "1.3.6.1.4.1.19046.11.1.1.14.4.1.8", "column": "8", "convert": "text"}, "protocol": {"symbol": "adapterNetworkPortCurrentProtocol", "oid": "1.3.6.1.4.1.19046.11.1.1.14.4.1.14", "column": "14", "convert": "text"}, "portNumber": {"symbol": "adapterNetworkPortPhyPortNo", "oid": "1.3.6.1.4.1.19046.11.1.1.14.4.1.3", "column": "3", "convert": "positive"}, "operStatus": {"symbol": "adapterNetworkPortPhyPortLinkStatus", "oid": "1.3.6.1.4.1.19046.11.1.1.14.4.1.20", "column": "20", "convert": "text"}, "speed": {"symbol": "adapterNetworkPortPhyPortLinkSpeed", "oid": "1.3.6.1.4.1.19046.11.1.1.14.4.1.21", "column": "21", "convert": "speed_mbps_text"}}, "required": ["address", "protocol"]}], "mib": "LENOVO-XCC-MIB", "mibSha256": "69ca39bab1803340ff83ae1d22d86216a67b7a1101d970b953716f31656b783d"}, "ibm-imm": {"id": "ibm-imm", "vendor": "IBM", "prefixes": ["1.3.6.1.4.1.2.3.51.3"], "aliases": ["integrated management module", "ibm imm"], "status": "mib-defined-not-device-tested", "scalars": {"sn": {"symbol": "machineLevelSerialNumber", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.2.1.3.0", "convert": "text"}, "mdl": {"symbol": "machineLevelProductName", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.2.1.5.0", "convert": "text"}, "machineUUID": {"symbol": "machineLevelUUID", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.2.1.4.0", "convert": "text"}}, "tables": [{"kind": "cpuInfo", "root": "1.3.6.1.4.1.2.3.51.3.1.5.20.1", "fields": {"mdl": {"symbol": "cpuVpdDescription", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.20.1.2", "column": "2", "convert": "text"}, "id": {"symbol": "cpuVpdIdentifier", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.20.1.4", "column": "4", "convert": "text"}, "totalCores": {"symbol": "cpuVpdCores", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.20.1.7", "column": "7", "convert": "positive"}, "totalThreads": {"symbol": "cpuVpdThreads", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.20.1.8", "column": "8", "convert": "positive"}}, "required": ["mdl"]}, {"kind": "memoryInfo", "root": "1.3.6.1.4.1.2.3.51.3.1.5.21.1", "fields": {"name": {"symbol": "memoryVpdDescription", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.21.1.2", "column": "2", "convert": "text"}, "type": {"symbol": "memoryVpdType", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.21.1.6", "column": "6", "convert": "text"}, "memorySize": {"symbol": "memoryVpdSize", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.21.1.7", "column": "7", "convert": "positive_text"}, "frequencyMHz": {"symbol": "memoryConfigSpeed", "oid": "1.3.6.1.4.1.2.3.51.3.1.5.21.1.9", "column": "9", "convert": "positive_text"}}, "required": ["memorySize"]}], "mib": "IMM-MIB", "mibSha256": "117c9729e8cf120f513630d572f1db4174eb69d7d02ab85cf2b9e5e0ed11ad40"}, "ibm-other": {"id": "ibm-other", "vendor": "IBM", "prefixes": ["1.3.6.1.4.1.2"], "aliases": ["ibm power", "hardware management console"], "status": "standard-mibs-only-no-power-inventory-claim", "scalars": {}, "tables": []}, "huawei-ibmc": {"id": "huawei-ibmc", "vendor": "Huawei", "prefixes": ["1.3.6.1.4.1.2011.2.235"], "aliases": ["huawei ibmc", "taishan"], "status": "mib-defined-not-device-tested", "scalars": {"sn": {"symbol": "deviceSerialNo", "oid": "1.3.6.1.4.1.2011.2.235.1.1.1.7.0", "convert": "text"}, "machineUUID": {"symbol": "systemGuid", "oid": "1.3.6.1.4.1.2011.2.235.1.1.1.10.0", "convert": "text"}}, "tables": [{"kind": "cpuInfo", "root": "1.3.6.1.4.1.2011.2.235.1.1.15.50.1", "fields": {"name": {"symbol": "cpuLocation", "oid": "1.3.6.1.4.1.2011.2.235.1.1.15.50.1.8", "column": "8", "convert": "text"}, "mdl": {"symbol": "cpuType", "oid": "1.3.6.1.4.1.2011.2.235.1.1.15.50.1.4", "column": "4", "convert": "text"}, "manufacturer": {"symbol": "cpuManufacturer", "oid": "1.3.6.1.4.1.2011.2.235.1.1.15.50.1.2", "column": "2", "convert": "text"}, "id": {"symbol": "cpuProcessorID", "oid": "1.3.6.1.4.1.2011.2.235.1.1.15.50.1.11", "column": "11", "convert": "text"}, "totalCores": {"symbol": "cpuCoreCount", "oid": "1.3.6.1.4.1.2011.2.235.1.1.15.50.1.12", "column": "12", "convert": "positive"}, "totalThreads": {"symbol": "cpuThreadCount", "oid": "1.3.6.1.4.1.2011.2.235.1.1.15.50.1.13", "column": "13", "convert": "positive"}}, "required": ["mdl"]}, {"kind": "memoryInfo", "root": "1.3.6.1.4.1.2011.2.235.1.1.16.50.1", "fields": {"name": {"symbol": "memoryLocation", "oid": "1.3.6.1.4.1.2011.2.235.1.1.16.50.1.8", "column": "8", "convert": "text"}, "type": {"symbol": "memoryType", "oid": "1.3.6.1.4.1.2011.2.235.1.1.16.50.1.11", "column": "11", "convert": "text"}, "frequencyMHz": {"symbol": "memoryClockRate", "oid": "1.3.6.1.4.1.2011.2.235.1.1.16.50.1.5", "column": "5", "convert": "clock_mhz_text"}, "memoryFactor": {"symbol": "memoryManufacturer", "oid": "1.3.6.1.4.1.2011.2.235.1.1.16.50.1.3", "column": "3", "convert": "text"}, "memorySize": {"symbol": "memorySize", "oid": "1.3.6.1.4.1.2011.2.235.1.1.16.50.1.4", "column": "4", "convert": "quantity_gb_text"}}, "required": ["name"]}, {"kind": "diskInfo", "root": "1.3.6.1.4.1.2011.2.235.1.1.18.50.1", "fields": {"name": {"symbol": "hardDiskLocation", "oid": "1.3.6.1.4.1.2011.2.235.1.1.18.50.1.4", "column": "4", "convert": "text"}, "mdl": {"symbol": "hardDiskModelNumber", "oid": "1.3.6.1.4.1.2011.2.235.1.1.18.50.1.8", "column": "8", "convert": "text"}, "manufacturer": {"symbol": "hardDiskManufacturer", "oid": "1.3.6.1.4.1.2011.2.235.1.1.18.50.1.9", "column": "9", "convert": "text"}, "capacityGB": {"symbol": "hardDiskCapacityInGB", "oid": "1.3.6.1.4.1.2011.2.235.1.1.18.50.1.12", "column": "12", "convert": "positive"}, "mediaType": {"symbol": "hardDiskMediaType", "oid": "1.3.6.1.4.1.2011.2.235.1.1.18.50.1.13", "column": "13", "convert": "enum", "values": {"1": "hdd", "2": "ssd", "3": "ssm"}}, "status": {"symbol": "hardDiskStatus", "oid": "1.3.6.1.4.1.2011.2.235.1.1.18.50.1.3", "column": "3", "convert": "enum", "values": {"1": "ok", "2": "minor", "3": "major", "4": "critical", "5": "absence"}}}, "required": ["mdl"], "presence": {"column": "2", "values": [2], "absent": [1], "unknown": [3]}}, {"kind": "logicalDrives", "root": "1.3.6.1.4.1.2011.2.235.1.1.37.50.1", "fields": {"name": {"symbol": "logicalDriveName", "oid": "1.3.6.1.4.1.2011.2.235.1.1.37.50.1.19", "column": "19", "convert": "text"}, "raidType": {"symbol": "logicalDriveRAIDLevel", "oid": "1.3.6.1.4.1.2011.2.235.1.1.37.50.1.3", "column": "3", "convert": "text"}, "status": {"symbol": "logicalDriveState", "oid": "1.3.6.1.4.1.2011.2.235.1.1.37.50.1.4", "column": "4", "convert": "enum", "values": {"1": "offline", "2": "partial-degraded", "3": "degraded", "4": "optimal"}}, "capacity": {"symbol": "logicalDriveSizeInMB", "oid": "1.3.6.1.4.1.2011.2.235.1.1.37.50.1.15", "column": "15", "convert": "mb_to_gb_float", "unknown": [4294967295]}}, "required": ["capacity"]}, {"kind": "networkInfo", "root": "1.3.6.1.4.1.2011.2.235.1.1.25.50.1", "fields": {"name": {"symbol": "netCardLocation", "oid": "1.3.6.1.4.1.2011.2.235.1.1.25.50.1.2", "column": "2", "convert": "text"}, "model": {"symbol": "netCardNICModel", "oid": "1.3.6.1.4.1.2011.2.235.1.1.25.50.1.5", "column": "5", "convert": "text"}, "manufacturer": {"symbol": "netCardNICManufacturer", "oid": "1.3.6.1.4.1.2011.2.235.1.1.25.50.1.9", "column": "9", "convert": "text"}}, "required": ["model"]}, {"kind": "networkPorts", "root": "1.3.6.1.4.1.2011.2.235.1.1.43.50.1", "fields": {"ifName": {"symbol": "businessPortLocation", "oid": "1.3.6.1.4.1.2011.2.235.1.1.43.50.1.3", "column": "3", "convert": "text"}, "physAddress": {"symbol": "businessPortMacAddr", "oid": "1.3.6.1.4.1.2011.2.235.1.1.43.50.1.5", "column": "5", "convert": "mac"}, "operStatus": {"symbol": "businessPortLinkStatus", "oid": "1.3.6.1.4.1.2011.2.235.1.1.43.50.1.4", "column": "4", "convert": "text"}}, "required": ["physAddress"], "nameParts": ["3", "2"]}], "mib": "HUAWEI-SERVER-IBMC-MIB", "mibSha256": "5a0bc632bdb6f26be0bf86271105f4873cb13a9f32de5ada4b17d52703074694"}, "baixin-bmc": {"id": "baixin-bmc", "vendor": "Baixin", "prefixes": [], "aliases": ["baixin", "\\u767e\\u4fe1", "hengshan"], "status": "standard-mibs-only-private-mib-download-blocked", "scalars": {}, "tables": []}, "inspur-bmc": {"id": "inspur-bmc", "vendor": "Inspur", "prefixes": ["1.3.6.1.4.1.37945", "1.3.6.1.4.1.48512"], "aliases": ["inspur", "\\u6d6a\\u6f6e"], "status": "standard-mibs-only-private-mib-not-obtained", "scalars": {}, "tables": []}}')
LOGGER = logging.getLogger("server_snmp")
CLOCK = getattr(time, "monotonic", time.time)
SYS_DESCR = "1.3.6.1.2.1.1.1.0"
SYS_OBJECT = "1.3.6.1.2.1.1.2.0"
SYS_NAME = "1.3.6.1.2.1.1.5.0"
ENTITY = "1.3.6.1.2.1.47.1.1.1.1"
INTERFACE = "1.3.6.1.2.1.2.2.1"
IFX = "1.3.6.1.2.1.31.1.1.1"
FC_PORT = "1.3.6.1.2.1.10.56.1.3.1"
SERVER_MODEL = "PHYSICAL_SERVER@ONEMODEL"
SECRET_KEYS = ("community", "authKey", "privKey")
try:
    TEXT = unicode
except NameError:
    TEXT = str


class ConfigError(Exception):
    pass


class CollectionError(Exception):
    pass


class UnsupportedOID(CollectionError):
    pass


class BudgetExceeded(CollectionError):
    pass


class HexValue(TEXT):
    def __new__(cls, raw):
        octets = binascii.unhexlify(re.sub(r"\s+", "", raw).encode("ascii"))
        try:
            value = octets.decode("utf-8")
            if any(ord(character) < 32 and character not in "\t\n\r" for character in value):
                value = raw
        except UnicodeError:
            value = raw
        result = TEXT.__new__(cls, value)
        result.raw_hex = binascii.hexlify(octets).decode("ascii")
        return result


def safe_text(value):
    if value is None:
        return ""
    if isinstance(value, bytes) and not isinstance(value, TEXT):
        return value.decode("utf-8", "replace")
    try:
        return TEXT(value)
    except UnicodeError:
        return TEXT(str(value)).decode("utf-8", "replace") if isinstance(TEXT(str(value)), bytes) else TEXT(str(value))


def redact(message, secrets):
    result = safe_text(message)
    variants = set()
    for item in secrets:
        if not item:
            continue
        secret = safe_text(item)
        variants.add(secret)
        variants.add(secret.replace("\\", "\\\\").replace('"', '\\"'))
        variants.add(json.dumps(secret, ensure_ascii=True)[1:-1])
        hexadecimal = binascii.hexlify(secret.encode("utf-8", "replace")).decode("ascii")
        spaced = " ".join(hexadecimal[index:index + 2] for index in range(0, len(hexadecimal), 2))
        variants.update((hexadecimal, hexadecimal.upper(), spaced, spaced.upper()))
    for secret in sorted(variants, key=len, reverse=True):
        result = result.replace(secret, "<redacted>")
    return result


def log_failure(stage, secrets):
    LOGGER.error("[%s] %s", stage, redact(traceback.format_exc(), secrets))


def log_phase(stage, message=""):
    LOGGER.info("[collect.phase] %s%s", stage, (" " + message) if message else "")


class DiagnosticFilter(logging.Filter):
    def __init__(self, trace_id, secrets):
        logging.Filter.__init__(self)
        self.trace_id = trace_id
        self.secrets = secrets

    def filter(self, entry):
        entry.msg = "[trace=%s] %s" % (self.trace_id, redact(entry.getMessage(), self.secrets))
        entry.args = ()
        return True


def configure_logging(environment, configuration=None):
    level = (environment.get("EASYOPS_COLLECTOR_logLevel") or (configuration or {}).get("logLevel") or environment.get("EASYOPS_LOG_LEVEL") or environment.get("LOG_LEVEL") or "ERROR").upper()
    if level not in ("DEBUG", "INFO", "WARNING", "ERROR"):
        raise ConfigError("logLevel must be DEBUG, INFO, WARNING or ERROR")
    logging.basicConfig(level=getattr(logging, level), format="%(asctime)s %(levelname)s %(message)s")
    LOGGER.setLevel(getattr(logging, level))


def diagnostic_status(error):
    if isinstance(error, BudgetExceeded):
        return "budget_exhausted"
    if isinstance(error, UnsupportedOID):
        return "unsupported"
    if isinstance(error, OSError):
        return "missing_executable" if error.errno == 2 else "local_os_error"
    message = TEXT(error).lower()
    if "timeout" in message or "no response" in message:
        return "no_response"
    if "authentication" in message or "authorization" in message or "unknown user" in message:
        return "security_error"
    if "output limit" in message:
        return "output_limit"
    return "request_error"


def clean_text(value):
    if value is None:
        return None
    result = TEXT(value).strip().strip('"').strip()
    if result.lower() in ("", "unknown", "not available", "not present", "not installed", "unpopulated", "n/a", "none", "null"):
        return None
    return result


def integer(value):
    if isinstance(value, bool) or value is None:
        return None
    match = re.match(r"^[+-]?\d+$", TEXT(value).strip())
    return int(match.group()) if match else None


def positive(value):
    number = integer(value)
    return number if number is not None and 0 < number else None


def flag(value, default=False):
    if value is None or value == "":
        return default
    if value in (True, "true", "True", "1", 1):
        return True
    if value in (False, "false", "False", "0", 0):
        return False
    raise ConfigError("invalid boolean configuration")


def bounded_number(value, default, minimum, maximum):
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        raise ConfigError("invalid numeric configuration")
    try:
        result = float(value)
    except (ValueError, TypeError):
        raise ConfigError("invalid numeric configuration")
    if math.isnan(result) or math.isinf(result):
        raise ConfigError("invalid numeric configuration")
    if not minimum <= result <= maximum:
        raise ConfigError("configuration exceeds allowed range")
    return result


def resolve_credentials(settings, environment):
    reference = clean_text(settings.get("credentialRef"))
    if reference:
        try:
            bundle = json.loads(environment.get("EASYOPS_COLLECTOR_credentialBundle") or "{}")
        except (ValueError, TypeError):
            raise ConfigError("encrypted credential bundle is not valid JSON")
        if not isinstance(bundle, dict) or not isinstance(bundle.get(reference), dict):
            raise ConfigError("credential reference has no exact encrypted bundle match")
        return dict((key, bundle[reference][key]) for key in SECRET_KEYS if key in bundle[reference])
    return dict((key, environment.get("EASYOPS_COLLECTOR_" + key)) for key in SECRET_KEYS)


def configuration_from_parameters(environment):
    """组装网络套件风格的分拆参数；旧整结构参数由调用方继续兼容。"""
    settings = {}
    mapping = (
        ("snmpPort", "snmpPort"),
        ("snmpVersion", "snmpVersion"),
        ("community", "community"),
        ("securityLevel", "securityLevel"),
        ("securityName", "securityName"),
        ("authProtocol", "authProtocol"),
        ("authKey", "authKey"),
        ("privProtocol", "privProtocol"),
        ("privKey", "privKey"),
        ("contextName", "contextName"),
    )
    for target, source in mapping:
        value = environment.get("EASYOPS_COLLECTOR_" + source)
        if clean_text(value) is not None:
            settings[target] = value
    return settings


def normalize_configuration(configuration, environment):
    settings = dict(configuration or {})
    if not settings:
        settings.update(configuration_from_parameters(environment))
    for source, target in (("snmpVersion", "version"), ("securityName", "username"), ("snmpPort", "port")):
        value = settings.get(source)
        if clean_text(value) is not None:
            previous = settings.get(target)
            if previous is not None and previous != "" and TEXT(previous) != TEXT(value):
                raise ConfigError("conflicting legacy and network authentication fields: " + source + "/" + target)
            settings[target] = value
        settings.pop(source, None)
    if "enabled" not in settings:
        settings["enabled"] = any(clean_text(settings.get(key)) for key in ("version", "username", "community", "authKey", "privKey", "credentialRef"))
    settings["target"] = settings.get("target") or environment.get("EASYOPS_COLLECTOR_ip")
    return settings


def runtime_configuration(configuration, environment, secrets):
    settings = dict(configuration)
    parameters = dict(environment)
    for key in SECRET_KEYS + ("credentialBundle",):
        value = settings.pop(key, None)
        if key in SECRET_KEYS and value:
            secrets.append(value)
        parameter = "EASYOPS_COLLECTOR_" + key
        if not parameters.get(parameter) and value is not None:
            parameters[parameter] = json.dumps(value, ensure_ascii=True) if isinstance(value, dict) else value
    reference = clean_text(settings.get("credentialRef"))
    if reference:
        try:
            bundle = json.loads(parameters.get("EASYOPS_COLLECTOR_credentialBundle") or "{}")
        except (ValueError, TypeError):
            raise ConfigError("credential bundle is not valid JSON")
        if isinstance(bundle, dict):
            for credential_group in bundle.values():
                if isinstance(credential_group, dict):
                    secrets.extend(credential_group.get(key) for key in SECRET_KEYS if isinstance(credential_group.get(key), (TEXT, str, bytes)))
    credentials = resolve_credentials(settings, parameters)
    secrets.extend(value for value in credentials.values() if isinstance(value, (TEXT, str, bytes)))
    return settings, credentials


def connection_config(settings, credentials):
    if not isinstance(settings, dict) or not isinstance(credentials, dict):
        raise ConfigError("configuration must be an object")
    if any(key in settings for key in SECRET_KEYS):
        raise ConfigError("credentials must use encrypted parameters, not snmp_conf")
    config = dict(settings)
    target = clean_text(config.get("target"))
    if not target or len(target) > 253 or not re.match(r"^[A-Za-z0-9:][A-Za-z0-9._:%-]*$", target):
        raise ConfigError("an explicit SNMP hostname or address is required")
    if ":" in target:
        try:
            socket.inet_pton(socket.AF_INET6, target.split("%", 1)[0])
        except (socket.error, ValueError):
            raise ConfigError("invalid IPv6 target")
    elif "%" in target:
        raise ConfigError("invalid target")
    config["target"] = target
    version = TEXT(config.get("version") or "3").lower().replace("v", "")
    if version not in ("1", "2c", "3"):
        raise ConfigError("unsupported SNMP version")
    config["version"] = version
    config["timeoutSec"] = bounded_number(config.get("timeoutSec"), 3.0, 0.1, 10.0)
    config["budgetSec"] = bounded_number(config.get("budgetSec"), 90.0, 1.0, 300.0)
    raw_port = config.get("port")
    if clean_text(raw_port) is None:
        LOGGER.info("[collect.config] snmpPort=%r treated as unset; using default port=161", raw_port)
        raw_port = 161
    port_value = bounded_number(raw_port, 161, 1, 65535)
    if int(port_value) != port_value:
        raise ConfigError("port must be an integer")
    config["port"] = int(port_value)
    retry_value = bounded_number(config.get("retries"), 0, 0, 2)
    if int(retry_value) != retry_value:
        raise ConfigError("retries must be an integer")
    config["retries"] = int(retry_value)
    for key in SECRET_KEYS:
        value = credentials.get(key)
        if value is not None:
            if not isinstance(value, (TEXT, str, bytes)):
                raise ConfigError("credential value must be text")
            value = TEXT(value)
            if any(ord(character) < 32 or ord(character) == 127 for character in value):
                raise ConfigError("credential contains a control character")
            config[key] = value
    if version != "3":
        if not config.get("community"):
            raise ConfigError("encrypted community parameter is required; no default community")
        return config
    config["securityLevel"] = config.get("securityLevel") or "authPriv"
    if config["securityLevel"] not in ("noAuthNoPriv", "authNoPriv", "authPriv"):
        raise ConfigError("unsupported SNMPv3 security level")
    config["username"] = clean_text(config.get("username"))
    if not config["username"]:
        raise ConfigError("SNMPv3 username is required")
    for key in ("username", "contextName"):
        value = TEXT(config.get(key) or "")
        if any(ord(character) < 32 or ord(character) == 127 for character in value):
            raise ConfigError("security identity contains a control character")
    if config["securityLevel"] != "noAuthNoPriv":
        config["authProtocol"] = (config.get("authProtocol") or "SHA").upper()
        config["authProtocol"] = {"SHA224": "SHA-224", "SHA256": "SHA-256", "SHA384": "SHA-384", "SHA512": "SHA-512"}.get(config["authProtocol"], config["authProtocol"])
        if config["authProtocol"] not in ("MD5", "SHA", "SHA-224", "SHA-256", "SHA-384", "SHA-512"):
            raise ConfigError("unsupported authentication algorithm; no downgrade")
        if len(config.get("authKey") or "") < 8:
            raise ConfigError("SNMPv3 authentication passphrase requires at least 8 characters")
    if config["securityLevel"] == "authPriv":
        config["privProtocol"] = (config.get("privProtocol") or "AES").upper()
        if config["privProtocol"] not in ("DES", "AES"):
            raise ConfigError("unsupported privacy algorithm; no downgrade")
        if len(config.get("privKey") or "") < 8:
            raise ConfigError("SNMPv3 privacy passphrase requires at least 8 characters")
    return config


def oid_under(oid, root):
    return oid == root or oid.startswith(root + ".")


def numeric_oid(value):
    result = TEXT(value or "").strip().lstrip(".")
    return result if re.match(r"^[0-9]+(?:\.[0-9]+)+$", result) else None


def parse_walk(raw):
    result = {}
    previous = None
    for line in raw.splitlines():
        if not line.strip():
            continue
        match = re.match(r"^\s*\.?([0-9]+(?:\.[0-9]+)+)\s*=\s*(.*)$", line)
        if not match:
            if previous and line[:1].isspace() and isinstance(result.get(previous), HexValue):
                prior = result[previous].raw_hex
                addition = re.sub(r"\s+", "", line)
                if re.match(r"^(?:[0-9a-fA-F]{2})+$", addition):
                    result[previous] = HexValue(prior + addition)
                    continue
            if "No more variables left" in line:
                continue
            raise CollectionError("invalid or incomplete numeric SNMP output")
        oid, payload = match.groups()
        previous = None
        if any(marker in payload for marker in ("No Such Object", "No Such Instance", "No more variables left", "End of MIB")):
            continue
        if ":" not in payload:
            raise CollectionError("SNMP output is missing its value type")
        value_type, value = payload.split(":", 1)
        value = value.strip()
        if value_type in ("INTEGER", "Gauge32", "Counter32", "Counter64", "Unsigned32", "Timeticks"):
            number = integer(value)
            if number is None:
                enum = re.match(r"^[A-Za-z][A-Za-z0-9_-]*\((-?\d+)\)$", value)
                number = int(enum.group(1)) if enum else None
            if number is None:
                raise CollectionError("invalid numeric varbind")
            result[oid] = number
        elif value_type == "OID":
            result[oid] = numeric_oid(value)
        elif value_type == "Hex-STRING":
            try:
                result[oid] = HexValue(value)
            except (ValueError, TypeError, binascii.Error):
                raise CollectionError("invalid hexadecimal varbind")
        elif value_type in ("STRING", "IpAddress", "BITS", "Opaque"):
            result[oid] = value.strip('"')
        else:
            raise CollectionError("unsupported varbind representation")
        previous = oid
    return result


def table_rows(values, root):
    rows = {}
    for oid, value in values.items():
        if oid.startswith(root + "."):
            suffix = oid[len(root) + 1:].split(".", 1)
            if len(suffix) == 2:
                rows.setdefault(suffix[1], {})[suffix[0]] = value
    return rows


def normalize_octets(value, length):
    if hasattr(value, "raw_hex"):
        digits = value.raw_hex
    else:
        text = TEXT(value or "").strip().replace("0x", "")
        if not re.match(r"^[0-9a-fA-F:\s-]+$", text):
            return None
        digits = re.sub(r"[:\s-]", "", text)
    if len(digits) != length * 2 or not re.match(r"^[0-9a-fA-F]+$", digits) or not int(digits, 16):
        return None
    return ":".join(digits[index:index + 2].lower() for index in range(0, len(digits), 2))


def normalize_wwpn(value):
    return normalize_octets(value, 8)


def select_profile(object_id, description, explicit=None):
    if explicit and explicit != "auto":
        if explicit not in PROFILES:
            raise ConfigError("unknown vendor profile")
        return PROFILES[explicit]
    text = TEXT(description or "").lower()
    candidates = []
    for profile in PROFILES.values():
        if profile["id"] == "generic":
            continue
        prefix_score = max([len(root) for root in profile.get("prefixes", []) if oid_under(object_id, root)] or [0])
        alias_score = max([len(alias) for alias in profile.get("aliases", []) if alias.lower() in text] or [0])
        if prefix_score or alias_score:
            candidates.append((prefix_score, alias_score, profile["id"]))
    if candidates:
        return PROFILES[max(candidates)[2]]
    return PROFILES.get("generic", {"id": "generic", "vendor": None, "tables": [], "scalars": {}})


def snmp_quote(value):
    return '"' + TEXT(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


class NetSnmp(object):
    def __init__(self, config, runtime_dir):
        self.config = config
        self.runtime_dir = runtime_dir
        self.directory = None
        self.config_path = None
        self.environment = None
        self.deadline = CLOCK() + config["budgetSec"]
        self.secrets = [config.get(key) for key in SECRET_KEYS if config.get(key)]
        self.requests = []

    def __enter__(self):
        try:
            return self.prepare()
        except Exception:
            self.__exit__(None, None, None)
            raise

    def prepare(self):
        if not os.path.isdir(self.runtime_dir):
            os.makedirs(self.runtime_dir, 0o700)
        self.directory = tempfile.mkdtemp(prefix="snmp-", dir=self.runtime_dir)
        os.chmod(self.directory, 0o700)
        self.config_path = os.path.join(self.directory, "snmp.conf")
        descriptors = [("defCommunity", "community")]
        if self.config["version"] == "3":
            descriptors = [("defSecurityName", "username"), ("defSecurityLevel", "securityLevel"),
                           ("defAuthType", "authProtocol"), ("defPrivType", "privProtocol"),
                           ("defAuthPassphrase", "authKey"), ("defPrivPassphrase", "privKey"),
                           ("defContext", "contextName")]
        contents = "\n".join(token + " " + snmp_quote(self.config[key]) for token, key in descriptors if self.config.get(key)) + "\n"
        descriptor = os.open(self.config_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(contents.encode("utf-8"))
        self.environment = dict(os.environ)
        self.environment.update({"SNMPCONFPATH": self.directory, "SNMP_PERSISTENT_DIR": self.directory,
                                 "NETSNMP_DONT_PERSIST_STATE": "1", "MIBS": "", "LC_ALL": "C"})
        for key in list(self.environment):
            if key.startswith("EASYOPS_COLLECTOR_") or key.startswith("SERVER_SNMP_"):
                del self.environment[key]
        return self

    def __exit__(self, exception_type, exception, tb):
        if self.directory:
            shutil.rmtree(self.directory)

    def command(self, operation, oids, timeout, retries):
        executable = "snmpget" if operation == "get" else ("snmpwalk" if self.config["version"] == "1" else "snmpbulkwalk")
        target = self.config["target"]
        if ":" in target:
            target = "udp6:[%s]:%s" % (target, self.config["port"])
        else:
            target = "udp:%s:%s" % (target, self.config["port"])
        return [executable, "-On", "-Oe", "-Ot", "-Ox", "-v", self.config["version"],
                "-t", TEXT(timeout), "-r", TEXT(retries), target] + list(oids)

    def execute(self, operation, oids, timeout=None, retries=None):
        started = CLOCK()
        remaining = self.deadline - started
        request = {"requestId": len(self.requests) + 1, "stage": getattr(self, "stage", "unspecified"), "operation": operation, "oids": list(oids), "status": "starting"}
        self.requests.append(request)
        process = None
        raw = ""
        errors = ""
        output_path = os.path.join(self.directory, "stdout")
        error_path = os.path.join(self.directory, "stderr")
        try:
            if remaining <= 0:
                raise BudgetExceeded("target collection budget exhausted")
            timeout = self.config["timeoutSec"] if timeout is None else timeout
            retries = self.config["retries"] if retries is None else retries
            timeout = min(timeout, remaining)
            limit = min(remaining, timeout * (retries + 1) + 0.75) if operation == "get" else remaining
            command = self.command(operation, oids, timeout, retries)
            request.update({"executable": command[0], "timeoutSec": timeout, "retries": retries, "limitSec": round(limit, 3), "remainingSec": round(remaining, 3)})
            LOGGER.debug("[snmp.begin] %s", redact(json.dumps(request, ensure_ascii=True), self.secrets))
            for path in (output_path, error_path):
                descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                os.close(descriptor)
            with open(output_path, "wb") as output, open(error_path, "wb") as error:
                process = subprocess.Popen(command, stdout=output, stderr=error, env=self.environment, preexec_fn=os.setsid)
                try:
                    end = CLOCK() + limit
                    while process.poll() is None:
                        if CLOCK() >= end:
                            raise BudgetExceeded("SNMP command deadline exhausted")
                        if os.path.getsize(output_path) + os.path.getsize(error_path) > 8 * 1024 * 1024:
                            raise CollectionError("SNMP output limit exceeded")
                        time.sleep(0.02)
                finally:
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
            with open(output_path, "rb") as stream:
                raw = stream.read(8 * 1024 * 1024 + 1)
            with open(error_path, "rb") as stream:
                errors = stream.read(8 * 1024 * 1024 + 1)
            if len(raw) + len(errors) > 8 * 1024 * 1024:
                raise CollectionError("SNMP output limit exceeded")
            raw = raw.decode("utf-8", "replace")
            errors = errors.decode("utf-8", "replace")
            if process.returncode or "Timeout" in errors or "Error in packet" in errors:
                if "noSuchName" in errors:
                    raise UnsupportedOID("SNMPv1 OID is not implemented")
                error_summary = redact(errors, self.secrets)
                if len(error_summary) > 32768:
                    error_summary = "<truncated>" + error_summary[-32768:]
                raise CollectionError("SNMP command failed: " + error_summary)
            values = parse_walk(raw)
            request["status"] = "ok" if values else "empty_or_inaccessible"
            request["varbinds"] = len(values)
            return values
        except Exception as error:
            request["status"] = diagnostic_status(error)
            raise
        finally:
            request.update({"elapsedSec": round(CLOCK() - started, 3), "returncode": process.returncode if process is not None else None, "remainingSec": round(max(0, self.deadline - CLOCK()), 3)})
            if process is not None:
                for label, path in (("stdout", output_path), ("stderr", error_path)):
                    try:
                        with open(path, "rb") as stream:
                            size = os.fstat(stream.fileno()).st_size
                            if size <= 8 * 1024 * 1024:
                                snippet = redact(stream.read().decode("utf-8", "replace"), self.secrets)[-32768:]
                            else:
                                snippet = "<omitted: output limit>"
                        request[label + "Bytes"] = size
                        if LOGGER.isEnabledFor(logging.DEBUG):
                            LOGGER.debug("[snmp.output] requestId=%s %sBytes=%s truncated=%s %s=%s", request["requestId"], label, size, size > 32768, label, redact(snippet, self.secrets))
                    except Exception:
                        log_failure("snmp_diagnostic_output", self.secrets)
            LOGGER.debug("[snmp.end] %s", redact(json.dumps(request, ensure_ascii=True), self.secrets))

    def get(self, oids, timeout=None, retries=None):
        return self.execute("get", oids, timeout, retries)

    def walk(self, root):
        return self.execute("walk", [root])


class ReplayTransport(object):
    def __init__(self, values, failures=None):
        self.values = values
        self.failures = failures or {}
        self.calls = []

    def get(self, oids, timeout=None, retries=None):
        self.calls.append(("get", oids))
        for oid in oids:
            if oid in self.failures:
                raise CollectionError("offline fixture failure")
        return dict((oid, self.values[oid]) for oid in oids if oid in self.values)

    def walk(self, root):
        self.calls.append(("walk", root))
        if root in self.failures:
            raise CollectionError("offline fixture failure")
        return dict((oid, value) for oid, value in self.values.items() if oid.startswith(root + "."))


def record(model, values, pks):
    return {"dims": {"object_id": model, "pks": pks, "upsert": True}, "vals": values}


def parent_relation(instance_id):
    return [{"_object_id": SERVER_MODEL, "instanceId": instance_id}]


def collect_entities(values, identity):
    for index, row in sorted(table_rows(values, ENTITY).items()):
        if integer(row.get("5")) == 3 and integer(row.get("4")) in (None, 0):
            for field, column in (("sn", "11"), ("brand", "12"), ("mdl", "13")):
                value = clean_text(row.get(column))
                if value:
                    identity.setdefault(field, value)
            break


def collect_interfaces(base, extended, instance_id):
    records = []
    names = set()
    extensions = table_rows(extended, IFX)
    for index, row in sorted(table_rows(base, INTERFACE).items()):
        if integer(row.get("3")) not in (6, 117):
            continue
        extra = extensions.get(index, {})
        name = clean_text(extra.get("1"))
        mac = normalize_octets(row.get("6"), 6)
        if mac:
            key = instance_id + ":mac:" + mac
        elif name:
            key = instance_id + ":ifName:" + name
        else:
            continue
        if key in names:
            continue
        names.add(key)
        result = {"name": key, "ifIndex": index, "physicalServer": parent_relation(instance_id)}
        for target, source in (("ifDescr", row.get("2")), ("mtu", row.get("4")), ("ifAlias", extra.get("18")), ("type", row.get("3"))):
            value = clean_text(source)
            if value:
                result[target] = value
        if name:
            result["ifName"] = name
        if mac:
            result["physAddress"] = mac
        high_speed = positive(extra.get("15"))
        low_speed = positive(row.get("5"))
        if high_speed:
            result["speed"] = TEXT(high_speed)
        elif low_speed and low_speed != 4294967295:
            result["speed"] = "%g" % (low_speed / 1000000.0)
        for target, column in (("adminStatus", "7"), ("operStatus", "8")):
            state = {1: "up", 2: "down", 3: "testing", 4: "unknown", 5: "dormant", 6: "notPresent", 7: "lowerLayerDown"}.get(integer(row.get(column)))
            if state:
                result[target] = state
        records.append(record("NETDPORT@ONEMODEL", result, ["name"]))
    return records


def collect_fc(values, interfaces, extended, instance_id):
    result = []
    seen = set()
    interface_rows = table_rows(interfaces, INTERFACE)
    extended_rows = table_rows(extended, IFX)
    for index, row in sorted(table_rows(values, FC_PORT).items()):
        wwpn = normalize_wwpn(row.get("2"))
        if not wwpn or wwpn in seen:
            continue
        seen.add(wwpn)
        values = {"wwpn": wwpn, "portIndex": index, "protocol": "FC", "physicalServer": parent_relation(instance_id)}
        name = clean_text(extended_rows.get(index, {}).get("1"))
        if name:
            values["portName"] = name
        speed = positive(extended_rows.get(index, {}).get("15"))
        if speed and speed % 1000 == 0:
            values["portSpeed"] = speed // 1000
        state = integer(interface_rows.get(index, {}).get("8"))
        if state in (1, 2, 3, 4, 5, 6, 7):
            values["portState"] = {1: "up", 2: "down", 3: "testing", 4: "unknown", 5: "dormant", 6: "notPresent", 7: "lowerLayerDown"}[state]
        result.append(record("FIBER_CHANNEL_PORT@ONEMODEL", values, ["wwpn"]))
    return result


def quantity(value, units):
    match = re.match(r"^([0-9]+(?:\.[0-9]+)?)\s*([A-Za-z/]+)$", TEXT(value or "").strip())
    if not match:
        return None
    multiplier = units.get(match.group(2).lower())
    if multiplier is None:
        return None
    number = float(match.group(1)) * multiplier
    return number if number > 0 and not math.isnan(number) and not math.isinf(number) else None


def converted(value, specification):
    if value is None or value in specification.get("unknown", []):
        return None
    conversion = specification.get("convert") or "text"
    if conversion == "text":
        return clean_text(value)
    if conversion == "enum":
        return specification.get("values", {}).get(TEXT(value))
    if conversion == "wwpn":
        return normalize_wwpn(value)
    if conversion == "mac":
        return normalize_octets(value, 6)
    if conversion == "positive":
        return positive(value)
    if conversion == "positive_text":
        number = positive(value)
        return TEXT(number) if number else None
    if conversion in ("quantity_gb_text", "quantity_gb_int"):
        number = quantity(value, {"b": 1e-9, "kb": 1e-6, "mb": 1e-3, "gb": 1, "tb": 1000,
                                  "kib": 1024e-9, "mib": 1048576e-9, "gib": 1073741824e-9, "tib": 1099511627776e-9})
        if number is None:
            return None
        if conversion == "quantity_gb_int":
            return int(number) if number >= 1 else None
        return "%.12g" % number
    if conversion in ("clock_mhz_text", "speed_mbps_text"):
        units = {"mhz": 1, "ghz": 1000} if conversion == "clock_mhz_text" else {"mbps": 1, "gbps": 1000, "mb/s": 1, "gb/s": 1000}
        number = quantity(value, units)
        return "%.12g" % number if number else None
    number = positive(value)
    if number is None:
        return None
    if conversion == "kib_to_gb_string":
        return "%.12g" % (number * 1024 / 1000000000.0)
    if conversion == "mib_to_gb_int":
        return int(number * 1048576 // 1000000000) or None
    if conversion == "mib_to_gb_float":
        return number * 1048576 / 1000000000.0
    if conversion == "mb_to_gb_float":
        return number / 1000.0
    raise ConfigError("unknown profile conversion")


def merge_inventory(current, previous):
    if not isinstance(previous, list):
        return current
    indexed = {}
    for item in previous:
        if isinstance(item, dict) and clean_text(item.get("name")):
            indexed.setdefault(TEXT(item["name"]), item)
    result = []
    for item in current:
        merged = dict(indexed.get(TEXT(item.get("name") or ""), {}))
        merged.update(item)
        result.append(merged)
    return result


def hardware_port_record(item, instance_id):
    mac = normalize_octets(item.get("physAddress"), 6)
    name = clean_text(item.get("ifName"))
    if not mac and not name:
        return None
    item["name"] = instance_id + (":mac:" + mac if mac else ":hardware:" + name)
    if mac:
        item["physAddress"] = mac
    item["physicalServer"] = parent_relation(instance_id)
    return record("NETDPORT@ONEMODEL", item, ["name"])


def collect_private_table(values, specification, server, records, instance_id):
    rows = table_rows(values, specification["root"])
    output = []
    summary_values = []
    for index, row in sorted(rows.items()):
        presence = specification.get("presence")
        if presence:
            state = row.get(TEXT(presence["column"]))
            if state in presence.get("absent", []):
                continue
            if state is None or state in presence.get("unknown", []):
                return
            if presence.get("values") and state not in presence["values"]:
                return
        item = {}
        for field, rule in specification["fields"].items():
            value = converted(row.get(TEXT(rule["column"])), rule)
            if value is not None:
                item[field] = value
        if any(not item.get(required) for required in specification.get("required", [])):
            LOGGER.debug("[collect_private_table] incomplete kind=%s row=%s", specification["kind"], index)
            return
        if not item:
            continue
        item.setdefault("name", specification["kind"] + ":" + index)
        if specification.get("nameParts"):
            parts = [clean_text(row.get(TEXT(column))) for column in specification["nameParts"]]
            item.pop("ifName", None)
            if all(parts):
                item["ifName"] = "/".join(parts)
        output.append(item)
        summary = specification.get("summary")
        if summary:
            summary_values.append(positive(row.get(TEXT(summary["column"]))))
    kind = specification["kind"]
    if not output:
        return
    if kind in ("cpuInfo", "memoryInfo", "diskInfo", "logicalDrives", "networkInfo", "hbaInfo", "powers", "fans"):
        server[kind] = output
    if kind == "cpuInfo":
        server["cpuNum"] = len(output)
        if all(positive(item.get("totalThreads")) for item in output):
            server["cpuThreadNum"] = sum(item["totalThreads"] for item in output)
    summary = specification.get("summary")
    if summary and summary_values and all(value is not None for value in summary_values):
        value = sum(summary_values) / float(summary["divisor"])
        if summary["mode"] == "exact_int" and value >= 1 and int(value) == value:
            server[summary["field"]] = int(value)
        elif summary["mode"] == "text":
            server[summary["field"]] = "%.12g" % value
    if kind == "networkPorts":
        for item in output:
            item.pop("name", None)
            result = hardware_port_record(item, instance_id)
            if result:
                records.append(result)
    if kind == "convergedPorts":
        for item in output:
            protocol = TEXT(item.get("protocol") or "").lower().replace(" ", "")
            if protocol in ("fc", "fibrechannel", "fiberchannel", "fcoe"):
                wwpn = normalize_wwpn(item.get("address"))
                if not wwpn:
                    continue
                values = {"wwpn": wwpn, "portName": item["name"], "protocol": "FCoE" if protocol == "fcoe" else "FC", "physicalServer": parent_relation(instance_id)}
                if positive(item.get("portNumber")):
                    values["portIndex"] = TEXT(item["portNumber"])
                if item.get("operStatus"):
                    values["portState"] = item["operStatus"]
                speed = positive(item.get("speed"))
                if speed and speed % 1000 == 0:
                    values["portSpeed"] = speed // 1000
                records.append(record("FIBER_CHANNEL_PORT@ONEMODEL", values, ["wwpn"]))
            elif protocol in ("ethernet", "eth", "ieee802.3"):
                mac = normalize_octets(item.get("address"), 6)
                if not mac:
                    continue
                values = {"physAddress": mac}
                if positive(item.get("portNumber")):
                    values["ifName"] = item["name"] + "/" + TEXT(item["portNumber"])
                for field in ("operStatus", "speed"):
                    if item.get(field):
                        values[field] = item[field]
                result = hardware_port_record(values, instance_id)
                if result:
                    records.append(result)


def private_values(transport, specification):
    columns = set(rule["column"] for rule in specification["fields"].values())
    for key in ("presence", "summary"):
        if specification.get(key):
            columns.add(TEXT(specification[key]["column"]))
    columns.update(TEXT(column) for column in specification.get("nameParts", []))
    values = {}
    for column in sorted(columns, key=int):
        try:
            values.update(transport.walk(specification["root"] + "." + column))
        except UnsupportedOID:
            continue
    return values


def collect(context, transport):
    configuration = context.get("snmp_conf") or {}
    if not flag(configuration.get("enabled"), False):
        return []
    secrets = [getattr(transport, "config", {}).get(key) for key in SECRET_KEYS]
    instance_id = clean_text(context.get("instanceId"))
    if not instance_id:
        raise ConfigError("CMDB instanceId is required")
    transport.stage = "preflight"
    log_phase("preflight", "instanceId=%s" % redact(instance_id, secrets))
    try:
        identity_response = transport.get([SYS_OBJECT, SYS_DESCR], timeout=3.0, retries=0)
        object_id = numeric_oid(identity_response.get(SYS_OBJECT))
        if not object_id:
            raise CollectionError("preflight returned no valid sysObjectID")
        profile = select_profile(object_id, identity_response.get(SYS_DESCR), configuration.get("vendorProfile"))
        LOGGER.info("[collect.identity] profile=%s sysObjectID=%s sysDescr=%s", profile["id"], object_id, redact(identity_response.get(SYS_DESCR) or "", secrets))
    except Exception:
        log_failure("collect.preflight", secrets)
        raise
    server = {"instanceId": instance_id}
    records = []
    identity = {}
    tables = {}
    failed = False
    for root in (ENTITY, INTERFACE, IFX, FC_PORT):
        try:
            transport.stage = {ENTITY: "ENTITY", INTERFACE: "INTERFACE", IFX: "IFX", FC_PORT: "FC_PORT"}[root]
            log_phase("standard.%s" % transport.stage, "oid=%s" % root)
            tables[root] = transport.walk(root)
            LOGGER.info("[collect.result] standard=%s varbinds=%s", root, len(tables[root]))
        except UnsupportedOID:
            tables[root] = {}
            LOGGER.warning("[collect.skip] standard=%s unsupported_or_empty", root)
        except BudgetExceeded:
            log_failure("collect_table_budget", secrets)
            failed = True
            break
        except Exception:
            log_failure("collect.standard.%s" % transport.stage, secrets)
            raise
    collect_entities(tables.get(ENTITY, {}), identity)
    records.extend(collect_interfaces(tables.get(INTERFACE, {}), tables.get(IFX, {}), instance_id))
    records.extend(collect_fc(tables.get(FC_PORT, {}), tables.get(INTERFACE, {}), tables.get(IFX, {}), instance_id))
    if not failed:
        for field, rule in profile.get("scalars", {}).items():
            try:
                transport.stage = "private.scalar." + field
                response = transport.get([rule["oid"]])
                value = converted(response.get(rule["oid"]), rule)
                if value is not None:
                    if field in ("brand", "mdl", "sn", "name"):
                        identity[field] = value
                    else:
                        server[field] = value
            except UnsupportedOID:
                LOGGER.warning("[collect.skip] private.scalar.%s unsupported_or_empty", field)
            except BudgetExceeded:
                log_failure("collect_scalar_budget", secrets)
                failed = True
                break
            except Exception:
                log_failure("collect.private.scalar.%s" % field, secrets)
                raise
    if not failed:
        for specification in profile.get("tables", []):
            try:
                transport.stage = "private.table." + specification["kind"]
                log_phase(transport.stage)
                values = private_values(transport, specification)
                collect_private_table(values, specification, server, records, instance_id)
                LOGGER.info("[collect.result] private=%s varbinds=%s", specification["kind"], len(values))
            except UnsupportedOID:
                LOGGER.warning("[collect.skip] private.table.%s unsupported_or_empty", specification["kind"])
            except BudgetExceeded:
                log_failure("collect_private_budget", secrets)
                break
            except Exception:
                log_failure("collect.private.table.%s" % specification["kind"], secrets)
                raise
    previous = context.get("previous") or {}
    for field, value in list(server.items()):
        if isinstance(value, list):
            server[field] = merge_inventory(value, previous.get(field))
    if flag(configuration.get("updateIdentity"), False):
        server.update(identity)
    if len(server) > 1:
        records.insert(0, record(SERVER_MODEL, server, ["instanceId"]))
    unique = {}
    for item in records:
        key = (item["dims"]["object_id"], tuple(item["vals"][field] for field in item["dims"]["pks"]))
        if key in unique:
            unique[key]["vals"].update(item["vals"])
        else:
            unique[key] = item
    result = [unique[key] for key in sorted(unique)]
    LOGGER.info("[collect.result] records=%s serverFields=%s identityFields=%s", len(result), len(server), len(identity))
    if not result:
        raise CollectionError("collection completed but returned no records; inspect [collect.skip] and SNMP request logs")
    LOGGER.debug("[collect.data] %s", redact(json.dumps(result, ensure_ascii=True), secrets))
    return result


def emit(records, stream=None):
    stream = sys.stdout if stream is None else stream
    stream.write("-----BEGIN GATHERING DATA-----\n")
    stream.write(json.dumps(records, ensure_ascii=True) + "\n")
    stream.write("-----END GATHERING DATA-----\n")


def agent_main():
    secrets = [os.environ.get("EASYOPS_COLLECTOR_" + key) for key in SECRET_KEYS]
    diagnostic_filter = DiagnosticFilter(uuid.uuid4().hex, secrets)
    LOGGER.addFilter(diagnostic_filter)
    started = CLOCK()
    transport = None
    enabled = False
    failed = False
    result = []
    try:
        log_phase("configuration", "loading snmp_conf and EASYOPS_COLLECTOR_* parameters")
        raw_configuration = os.environ.get("EASYOPS_COLLECTOR_snmp_conf")
        configuration = json.loads(raw_configuration or "{}")
        if configuration is None:
            configuration = {}
        if not isinstance(configuration, dict):
            raise ConfigError("snmp_conf must be an object")
        if not configuration:
            configuration = configuration_from_parameters(os.environ)
        configure_logging(os.environ, configuration)
        configuration = normalize_configuration(configuration, os.environ)
        LOGGER.info("[collect.config] version=%s target=%s port=%s snmpVersion=%s enabled=%s", VERSION, redact(configuration.get("target"), secrets), configuration.get("port") or configuration.get("snmpPort") or 161, configuration.get("version") or configuration.get("snmpVersion"), configuration.get("enabled"))
        if not flag(configuration.get("enabled"), False):
            raise ConfigError("SNMP collection prerequisites are incomplete or collection is disabled")
        enabled = True
        configuration["target"] = configuration.get("target") or os.environ.get("EASYOPS_COLLECTOR_ip")
        configuration, credentials = runtime_configuration(configuration, os.environ, secrets)
        config = connection_config(configuration, credentials)
        diagnostic_context = dict((key, config.get(key)) for key in ("target", "port", "version", "securityLevel", "username", "contextName", "authProtocol", "privProtocol", "timeoutSec", "retries", "budgetSec"))
        diagnostic_context.update({"versionOfKit": VERSION, "instanceId": os.environ.get("EASYOPS_COLLECTOR_instanceId"), "pythonVersion": sys.version.split()[0], "preflightTimeoutSec": 3.0, "preflightRetries": 0, "walkMethod": "snmpwalk" if config["version"] == "1" else "snmpbulkwalk"})
        LOGGER.info("[collect.context] %s", json.dumps(diagnostic_context, ensure_ascii=True))
        runtime = os.environ.get("SERVER_SNMP_RUNTIME_DIR") or os.path.join(os.path.dirname(os.path.abspath(__file__)), ".local")
        with NetSnmp(config, runtime) as transport:
            previous = {}
            for field in ("cpuInfo", "memoryInfo", "diskInfo", "logicalDrives", "networkInfo", "hbaInfo"):
                previous[field] = json.loads(os.environ.get("EASYOPS_COLLECTOR_old_" + field) or "null")
            result = collect({"instanceId": os.environ.get("EASYOPS_COLLECTOR_instanceId"), "snmp_conf": configuration, "previous": previous}, transport)
    except Exception:
        failed = True
        log_failure("agent_main", secrets)
    finally:
        if enabled or failed:
            requests = getattr(transport, "requests", [])
            counts = {}
            for request in requests:
                counts[request["status"]] = counts.get(request["status"], 0) + 1
            request_failures = any(request["status"] not in ("ok", "unsupported", "empty_or_inaccessible") for request in requests)
            outcome = "agent_error" if failed else ("request_failures" if request_failures else ("completed" if result else "completed_no_records"))
            summary = {"outcome": outcome, "elapsedSec": round(CLOCK() - started, 3), "recordCount": len(result), "requestCount": len(requests), "statuses": counts, "agentError": failed, "lastRequest": requests[-1] if requests else None}
            LOGGER.error("[collect.summary] %s", json.dumps(summary, ensure_ascii=True) if failed or request_failures or not result else json.dumps(summary, ensure_ascii=True))
        LOGGER.removeFilter(diagnostic_filter)
    emit(result)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(agent_main())
