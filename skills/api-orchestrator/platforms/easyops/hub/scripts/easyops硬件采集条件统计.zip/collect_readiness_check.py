#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EasyOps 模型数据采集条件准备情况确认脚本

功能：
    1. 获取父模型 BASE_ASSET@ONEMODEL 的所有子模型实例（一次翻页拉全量，统一处理）。
    2. 按实例的鉴权结构体判定采集协议，做「网络可达」检测（不同协议不同端口）：
         - 有 out_of_band 结构体 -> redfish 协议 -> TCP 443
         - 有 auth 结构体        -> snmp 协议   -> UDP snmpPort(默认 161)
    3. 按鉴权结构体做「账密正确」探测（不同协议不同探测逻辑）：
         - redfish: HTTPS 基础认证 GET /redfish/v1/，返回 200 为通过
         - snmp:    snmpget 探测（优先 pysnmp，无则降级系统命令 snmpget）
    4. 汇总输出 Excel：模型ID / 名称 / IP / 鉴权信息 / 网络可达 / 账密正确 / 已具备条件。

可扩展性（新增协议 = 追加一个配置 dict，不改主流程）：
    - 所有协议的「判定 + 端口 + 网络检测 + 账密探测」都收敛在 PROTOCOL_CONFIGS 里，
      每个协议一个 dict。新增协议只需：
        1) 写好该协议的网络检测函数 + 账密探测函数（鉴权属性用 **kwargs 接收结构体）；
        2) 在 PROTOCOL_CONFIGS 里 append 一个 dict 描述它（auth_field/default_port/
           port_field/checker/prober）；
      主流程 pick_protocol / assess_instance 完全不用动。

交付形态（遵循 api-calling 交付脚本规范）：
    - 单文件自包含，不 import 项目内任何模块；客户端传输层内联精简实现。
    - 不动态引用 api-calling；参数（连接/开关）一律放在 __main__ 下的常量里，不用 argparse。

依赖：requests / openpyxl / pysnmp(可选，无则降级系统 snmpget)
运行：python3 collect_readiness_check.py
"""

import json
import logging
import os
import shutil
import socket
import subprocess
from typing import Any, Callable, Dict, List, Optional, Tuple

import requests
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("collect_readiness")

# 脚本所在目录（Excel 产物落同级目录）
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 绕过本地代理直连内网（requests/socket 都不走系统代理）
for _k in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY", "all_proxy", "ALL_PROXY"):
    os.environ.pop(_k, None)
os.environ["NO_PROXY"] = "*"


# =====================================================================
# 内联 EasyOps 客户端（通用基座精简版：内网直连 + 翻页 + code 判定）
#   机制等价于 knowledge/concepts/api-calling 的 EasyOpsClient，
#   物理内联进本脚本，保证独立可分发。只放调用机制，不塞业务方法。
# =====================================================================
class EasyOpsClient:
    """EasyOps 内网直连客户端（精简）：user/org 头鉴权 + 自动翻页 + code 判定"""

    def __init__(self, host: str, org: str, user: str = "defaultUser", timeout: int = 30):
        """
        :param host: EasyOps 服务器地址（内网 IP）
        :param org: 组织 ID
        :param user: 内网调用用户名（默认 defaultUser 管理员）
        :param timeout: 单次请求超时秒
        """
        self.host = host
        self.org = org
        self.timeout = timeout
        self.headers = {
            "user": user,
            "org": str(org),
            "Content-Type": "application/json",
        }

    def post(self, path: str, port: int, body: Dict) -> Dict:
        """
        发 POST 请求并做 code 判定（响应包装 {code,error,message,data}，code==0 成功）。

        :param path: API 路径（不含 host:port）
        :param port: 服务端口（cmdb=8079）
        :param body: 请求体 dict
        :return: 响应 JSON 的 data 字段
        :raises RuntimeError: HTTP 非 2xx 或业务 code != 0
        """
        url = f"http://{self.host}:{port}/{path.lstrip('/')}"
        resp = requests.post(url, headers=self.headers, json=body, timeout=self.timeout)
        resp.raise_for_status()
        payload = resp.json()
        if payload.get("code") != 0:
            raise RuntimeError(
                f"业务码非0: code={payload.get('code')} message={payload.get('message')} url={url}"
            )
        return payload.get("data", {})

    def get(self, path: str, port: int, params: Optional[Dict] = None) -> Any:
        """
        发 GET 请求并做 code 判定（响应包装 {code,error,message,data}，code==0 成功）。

        :param path: API 路径（不含 host:port）
        :param port: 服务端口（cmdb=8079）
        :param params: URL 查询参数（dict 值含 @ 等特殊字符由 requests 自动编码）
        :return: 响应 JSON 的 data 字段（可能是 list 或 dict）
        :raises RuntimeError: HTTP 非 2xx 或业务 code != 0
        """
        url = f"http://{self.host}:{port}/{path.lstrip('/')}"
        resp = requests.get(url, headers=self.headers, params=params, timeout=self.timeout)
        resp.raise_for_status()
        payload = resp.json()
        if payload.get("code") != 0:
            raise RuntimeError(
                f"业务码非0: code={payload.get('code')} message={payload.get('message')} url={url}"
            )
        return payload.get("data")

    def search_instances(self, object_id: str, query: Optional[Dict] = None,
                         fields: Optional[List[str]] = None,
                         port: int = 8079, page_size: int = 1000) -> List[Dict]:
        """
        搜索指定模型的全部实例（自动翻页：page 递增直到 len(items) < page_size）。

        EasyOps API: PostSearchV3  服务: logic.cmdb.service  端口: 8079

        :param object_id: 模型 ID（父模型则返回其下所有子模型实例）
        :param query: 查询条件，如 {"deviceName": {"$like": "%xx%"}}
        :param fields: 返回字段，None 表示全部
        :param port: 服务端口
        :param page_size: 每页条数
        :return: 实例列表（全量）
        """
        path = f"v3/object/{object_id}/instance/_search"
        body = {
            "fields": fields if fields else ["*"],
            "query": query if query else {},
            "page": 1,
            "page_size": page_size,
        }
        all_list: List[Dict] = []
        page = 1
        while True:
            body["page"] = page
            data = self.post(path, port=port, body=body)
            items = data.get("list", [])
            all_list.extend(items)
            total = data.get("total", 0)
            logger.info("[%s] 已获取 %d/%d 条", object_id, len(all_list), total)
            if len(items) < page_size or not items:
                break
            page += 1
        return all_list


# =====================================================================
# 网络可达检测函数（不同协议不同端口；签名统一: (ip, port, timeout, **auth) -> bool）
# =====================================================================

def check_tcp(ip: str, port: int, timeout: float = 5.0, **_: Any) -> bool:
    """TCP 端口可达检测（connect 成功即通）。适用 redfish(443) 等 TCP 协议。"""
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except OSError:
        return False


def check_udp(ip: str, port: int, timeout: float = 3.0, **_: Any) -> bool:
    """
    UDP 端口可达检测。UDP 无连接，靠 connect+send 触发 ICMP 端口不可达来判断：
    发送后未收到 RST/不可达即认为「可能可达」（UDP 检测本质是 best-effort）。
    适用 snmp(161) 等 UDP 协议。
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)
    try:
        sock.connect((ip, port))
        sock.send(b"\x00")
        try:
            sock.recv(1)  # 收到 ICMP 端口不可达会抛 ConnectionRefusedError
        except socket.timeout:
            pass  # 超时无响应 -> UDP 对端可能存在（不拒绝即可达）
        return True
    except (ConnectionRefusedError, OSError):
        return False
    finally:
        sock.close()


# =====================================================================
# 账密正确探测函数（不同协议不同逻辑；签名统一: (ip, port, timeout, **auth) -> bool）
#   auth 即鉴权结构体展开（usr/pwd 或 snmpVersion/community/...）。
# =====================================================================

def probe_redfish(ip: str, port: int = 443, timeout: float = 8.0, **auth: Any) -> bool:
    """
    redfish 账密探测：HTTPS 基础认证 GET https://<ip>/redfish/v1/，HTTP 200 为通过。
    等价于 curl -k -u usr:pwd https://<ip>/redfish/v1/（-k 即忽略证书校验）。

    :param auth: out_of_band 结构体展开（usr/pwd）
    """
    usr = auth.get("usr")
    pwd = auth.get("pwd")
    if not usr:
        logger.debug("redfish 缺 usr，无法探测 ip=%s", ip)
        return False
    url = f"https://{ip}:{port}/redfish/v1/"
    try:
        resp = requests.get(url, auth=(usr, pwd or ""), timeout=timeout, verify=False)
        logger.debug("redfish %s -> HTTP %s", ip, resp.status_code)
        return resp.status_code == 200
    except requests.RequestException as e:
        logger.debug("redfish %s 探测异常: %s", ip, e)
        return False


def _snmp_get_pysnmp(ip: str, port: int, timeout: float, auth: Dict) -> Optional[bool]:
    """
    用 pysnmp 发 snmpget（读 sysDescr.0）判账密/团体字是否正确。
    返回 True/False；pysnmp 不可用或运行异常返回 None（交上层降级系统命令）。

    注意：pysnmp 7.1.x 已移除旧的同步 hlapi（getCmd），仅提供 asyncio 协程 API
    （pysnmp.hlapi.asyncio.get_cmd），故此处用 asyncio.run() 包一层同步调用。
    """
    try:
        import asyncio
        from pysnmp.hlapi.asyncio import (
            SnmpEngine, UdpTransportTarget, ContextData, ObjectType, ObjectIdentity,
            get_cmd, CommunityData, UsmUserData,
            usmHMACMD5AuthProtocol, usmHMACSHAAuthProtocol,
            usmDESPrivProtocol, usmAesCfb128Protocol,
            usmNoAuthProtocol, usmNoPrivProtocol,
        )
    except Exception as e:  # ImportError 等（含 pysnmp 未装 -> 走降级）
        logger.debug("pysnmp 不可用: %s", e)
        return None

    version = str(auth.get("snmpVersion", "2c")).lower()
    timeout_s = max(1, int(timeout))
    try:
        if version in ("1", "2", "2c"):
            # v1/v2c 团体字认证；mpModel: 0=v1, 1=v2c
            mp_model = 0 if version == "1" else 1
            auth_data = CommunityData(auth.get("community", "public"), mpModel=mp_model)
        elif version == "3":
            # v3 USM：按 securityLevel 组装认证/加密协议
            auth_proto_map = {
                "MD5": usmHMACMD5AuthProtocol, "SHA": usmHMACSHAAuthProtocol,
                "SHA224": usmHMACSHAAuthProtocol, "SHA256": usmHMACSHAAuthProtocol,
                "SHA512": usmHMACSHAAuthProtocol,
            }
            priv_proto_map = {"DES": usmDESPrivProtocol, "AES": usmAesCfb128Protocol,
                              "AES192": usmAesCfb128Protocol, "AES256": usmAesCfb128Protocol}
            sec_level = str(auth.get("securityLevel", "noAuthNoPriv"))
            auth_proto = auth_proto_map.get(str(auth.get("authProtocol", "")).upper(),
                                            usmNoAuthProtocol)
            priv_proto = priv_proto_map.get(str(auth.get("privProtocol", "")).upper(),
                                            usmNoPrivProtocol)
            auth_data = UsmUserData(
                auth.get("securityName", ""),
                authKey=auth.get("authKey") if sec_level != "noAuthNoPriv" else None,
                privKey=auth.get("privKey") if sec_level == "authPriv" else None,
                authProtocol=auth_proto,
                privProtocol=priv_proto,
            )
        else:
            logger.debug("未知 snmpVersion=%s", version)
            return False

        async def _query() -> bool:
            """协程：发一次 get_cmd，判错误指示/状态，有绑定值即账密对。"""
            error_indication, error_status, _, var_binds = await get_cmd(
                SnmpEngine(),
                auth_data,
                await UdpTransportTarget.create((ip, port), timeout=timeout_s, retries=0),
                ContextData(),
                ObjectType(ObjectIdentity("1.3.6.1.2.1.1.1.0")),  # sysDescr.0
                lookupMib=False,
            )
            if error_indication:
                logger.debug("snmp %s 失败: %s", ip, error_indication)
                return False
            if error_status:
                logger.debug("snmp %s 错误: %s", ip, error_status.prettyPrint())
                return False
            return bool(var_binds)

        return asyncio.run(_query())
    except Exception as e:
        logger.debug("pysnmp 探测 %s 异常: %s", ip, e)
        return None  # 异常降级系统命令再试


def _snmp_get_syscmd(ip: str, port: int, timeout: float, auth: Dict) -> bool:
    """降级方案：调用系统命令 snmpget（需机器装 net-snmp）判账密/团体字。"""
    if not shutil.which("snmpget"):
        logger.debug("系统无 snmpget 命令，无法降级探测")
        return False
    version = str(auth.get("snmpVersion", "2c")).lower()
    timeout_s = max(1, int(timeout))
    oid = "1.3.6.1.2.1.1.1.0"  # sysDescr.0
    target = f"udp:{ip}:{port}"

    if version in ("1", "2", "2c"):
        cmd = ["snmpget", "-v", "2c" if version == "2" else version,
               "-c", auth.get("community", "public"),
               "-t", str(timeout_s), "-r", "0", "-O", "qv", target, oid]
    elif version == "3":
        sec_level = str(auth.get("securityLevel", "noAuthNoPriv"))
        cmd = ["snmpget", "-v", "3", "-l", sec_level,
               "-u", auth.get("securityName", ""),
               "-t", str(timeout_s), "-r", "0", "-O", "qv"]
        if sec_level != "noAuthNoPriv":
            cmd += ["-a", str(auth.get("authProtocol", "MD5")),
                    "-A", auth.get("authKey", "")]
        if sec_level == "authPriv":
            cmd += ["-x", str(auth.get("privProtocol", "DES")),
                    "-X", auth.get("privKey", "")]
        cmd += [target, oid]
    else:
        return False

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s + 5)
        ok = proc.returncode == 0 and bool(proc.stdout.strip())  # 退出码0且有输出=账密对
        if not ok:
            logger.debug("snmpget %s 失败: rc=%s err=%s", ip, proc.returncode,
                         proc.stderr.strip()[:200])
        return ok
    except (subprocess.TimeoutExpired, OSError) as e:
        logger.debug("snmpget %s 异常: %s", ip, e)
        return False


def probe_snmp(ip: str, port: int = 161, timeout: float = 5.0, **auth: Any) -> bool:
    """
    snmp 账密探测：优先 pysnmp，pysnmp 不可用/异常则降级系统命令 snmpget。

    :param auth: auth 结构体展开（snmpVersion/community/securityLevel/...）
    """
    result = _snmp_get_pysnmp(ip, port, timeout, auth)
    if result is not None:
        return result
    logger.debug("snmp %s 降级系统 snmpget", ip)
    return _snmp_get_syscmd(ip, port, timeout, auth)


# =====================================================================
# 协议配置注册表（新增协议只追加一个 dict，主流程不改）
#   每个 dict 字段:
#     kind        协议类别名（日志/调试显示用）
#     auth_field  实例上判定该协议的鉴权结构体字段名（存在且非空 dict 即命中）
#     default_port 协议默认端口
#     port_field  实例上覆盖端口的字段名（None 表示固定用 default_port）
#     checker     网络可达检测函数 (ip, port, timeout, **auth) -> bool
#     prober      账密正确探测函数 (ip, port, timeout, **auth) -> bool
# =====================================================================
PROTOCOL_CONFIGS: List[Dict[str, Any]] = [
    {
        "kind": "redfish",
        "auth_field": "out_of_band",
        "default_port": 443,
        "port_field": None,            # redfish 固定 443
        "checker": check_tcp,
        "prober": probe_redfish,
    },
    {
        "kind": "snmp",
        "auth_field": "auth",
        "default_port": 161,
        "port_field": "snmpPort",      # 实例 snmpPort 覆盖默认 161
        "checker": check_udp,
        "prober": probe_snmp,
    },
    # 新增协议示例：再 append 一个 dict 即可，例如
    # {
    #     "kind": "ssh",
    #     "auth_field": "ssh_auth",
    #     "default_port": 22,
    #     "port_field": "sshPort",
    #     "checker": check_tcp,
    #     "prober": probe_ssh,
    # },
]


def pick_protocol(instance: Dict) -> Tuple[Optional[Dict], Dict, int]:
    """
    按实例的鉴权结构体，在 PROTOCOL_CONFIGS 里匹配命中的协议配置。

    :param instance: CMDB 实例 dict
    :return: (协议配置 dict 或 None, 鉴权结构体, 端口)。无命中返回 (None, {}, 0)
    """
    for cfg in PROTOCOL_CONFIGS:
        auth = instance.get(cfg["auth_field"])
        if isinstance(auth, dict) and auth:
            port = cfg["default_port"]
            if cfg.get("port_field"):
                raw = instance.get(cfg["port_field"])
                try:
                    port = int(raw) if raw else cfg["default_port"]
                except (TypeError, ValueError):
                    port = cfg["default_port"]
            return cfg, auth, port
    return None, {}, 0


# =====================================================================
# 主流程
# =====================================================================

def assess_instance(instance: Dict, model_names: Dict[str, str],
                    timeout: float = 5.0) -> Dict:
    """
    评估单个实例的采集条件准备情况。

    :param instance: CMDB 实例 dict
    :param model_names: objectId -> 模型显示名 映射（来自 object_basic_all）
    :param timeout: 网络/探测超时秒
    :return: 报表行 dict（模型名称/名称/IP/鉴权信息/网络可达/账密正确/已具备条件）
    """
    object_id = instance.get("_object_id", "")
    # 模型名称：优先显示名，取不到则回退 objectId
    model_name = model_names.get(object_id) or object_id
    name = instance.get("deviceName") or ""
    ip = instance.get("ip", "")
    cfg, auth_struct, port = pick_protocol(instance)

    net_ok = False
    cred_ok = False
    if cfg is not None and ip:
        # 网络可达检测：鉴权属性用 **kwargs 传入检测函数
        try:
            net_ok = bool(cfg["checker"](ip, port, timeout=timeout, **auth_struct))
        except Exception as e:
            logger.warning("网络检测异常 %s(%s:%s): %s", model_id, ip, port, e)
            net_ok = False
        # 账密正确探测：网络通了才探测（不通则账密无从谈起）
        if net_ok:
            try:
                cred_ok = bool(cfg["prober"](ip, port, timeout=timeout, **auth_struct))
            except Exception as e:
                logger.warning("账密探测异常 %s(%s:%s): %s", model_id, ip, port, e)
                cred_ok = False

    ready = net_ok and cred_ok
    return {
        "模型名称": model_name,
        "名称": name,
        "IP": ip,
        "鉴权信息": json.dumps(auth_struct, ensure_ascii=False) if auth_struct else "",
        "网络可达": "是" if net_ok else "否",
        "账密正确": "是" if cred_ok else "否",
        "已具备条件": "是" if ready else "否",
    }


def export_excel(rows: List[Dict], out_path: str) -> None:
    """把评估结果写成 Excel（带表头样式 + 条件配色）。"""
    headers = ["模型名称", "名称", "IP", "鉴权信息", "网络可达", "账密正确", "已具备条件"]
    wb = Workbook()
    ws = wb.active
    ws.title = "采集条件确认"

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="4472C4")
    ok_fill = PatternFill("solid", fgColor="C6EFCE")   # 绿
    ng_fill = PatternFill("solid", fgColor="FFC7CE")   # 红

    ws.append(headers)
    for c in ws[1]:
        c.font = header_font
        c.fill = header_fill
        c.alignment = Alignment(horizontal="center", vertical="center")

    for r in rows:
        ws.append([r.get(h, "") for h in headers])

    # 后三列按 是/否 配色
    for row in ws.iter_rows(min_row=2, min_col=5, max_col=7):
        for cell in row:
            cell.alignment = Alignment(horizontal="center", vertical="center")
            if cell.value == "是":
                cell.fill = ok_fill
            elif cell.value == "否":
                cell.fill = ng_fill

    # 列宽
    widths = {"A": 22, "B": 20, "C": 16, "D": 46, "E": 10, "F": 10, "G": 12}
    for col, w in widths.items():
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"

    wb.save(out_path)
    logger.info("Excel 已输出: %s（共 %d 行）", out_path, len(rows))


if __name__ == "__main__":
    # ======================== 可调参数（改这里） ========================
    HOST = "172.30.0.90"                 # EasyOps 内网地址
    ORG = "8888"                         # 组织 ID
    USER = "defaultUser"                 # 内网调用用户名
    PARENT_MODEL = "BASE_ASSET@ONEMODEL"  # 父模型（取所有子模型实例）
    CMDB_PORT = 8079                     # cmdb 服务端口
    PROBE_TIMEOUT = 5.0                  # 网络/探测超时秒
    QUERY = None                         # 实例过滤条件，如 {"deviceName": {"$like": "%xx%"}}
    OUTPUT_XLSX = os.path.join(SCRIPT_DIR, "collect_readiness.xlsx")
    # ===================================================================

    # 忽略 redfish 的 HTTPS 自签证书告警（-k 语义）
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    client = EasyOpsClient(host=HOST, org=ORG, user=USER)

    # 拉子模型的 objectId -> 模型显示名 映射（object_basic_all 按父模型过滤）
    logger.info("拉取父模型 %s 的子模型名称映射(object_basic_all) ...", PARENT_MODEL)
    basics = client.get("object_basic_all", port=CMDB_PORT,
                        params={"parentObjectId": PARENT_MODEL}) or []
    model_names = {m.get("objectId"): m.get("name") for m in basics if m.get("objectId")}
    logger.info("子模型映射共 %d 个: %s", len(model_names),
                {k: v for k, v in list(model_names.items())[:5]})

    logger.info("拉取父模型 %s 全部子模型实例 ...", PARENT_MODEL)
    instances = client.search_instances(
        PARENT_MODEL, query=QUERY, fields=["*"], port=CMDB_PORT,
    )
    logger.info("共 %d 个实例，逐个评估采集条件 ...", len(instances))

    rows = []
    for idx, inst in enumerate(instances, 1):
        row = assess_instance(inst, model_names, timeout=PROBE_TIMEOUT)
        rows.append(row)
        cfg, _, _ = pick_protocol(inst)
        logger.info(
            "[%d/%d] %s | %s | %s | 协议=%s | 网络=%s 账密=%s 具备=%s",
            idx, len(instances), row["模型名称"], row["名称"], row["IP"],
            cfg["kind"] if cfg else "none",
            row["网络可达"], row["账密正确"], row["已具备条件"],
        )

    export_excel(rows, OUTPUT_XLSX)

    # 控制台汇总
    ready_cnt = sum(1 for r in rows if r["已具备条件"] == "是")
    net_cnt = sum(1 for r in rows if r["网络可达"] == "是")
    cred_cnt = sum(1 for r in rows if r["账密正确"] == "是")
    logger.info(
        "汇总: 总数=%d 网络可达=%d 账密正确=%d 已具备条件=%d",
        len(rows), net_cnt, cred_cnt, ready_cnt,
    )
